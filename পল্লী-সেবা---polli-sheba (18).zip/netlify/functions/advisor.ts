import { GoogleGenAI, ThinkingLevel } from '@google/genai';

export const handler = async (event: any) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY || '';
    if (!apiKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Gemini API Key Netlify-তে সেট করা নেই।' })
      };
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
    const payload = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
    const { message, category, context: appContext, conversationHistory } = payload || {};

    if (!message) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'বার্তা প্রয়োজন (Message is required)' })
      };
    }

    const systemPrompt = `আপনি হলেন "পল্লী সেবা" (Polli Sheba) অ্যাপের সর্বজ্ঞ এআই সহায়ক, গ্রামীণ জনসেবা পরামর্শক এবং নেভিগেশন গাইড।

আপনার পার্সোনা ও দায়িত্ব (Persona & Role):
- আপনি একজন অত্যন্ত বিনম্র, বন্ধুসুলভ, সহানুভূতিশীল ও বিচক্ষণ গ্রামীণ ডিজিটাল গাইড।
- আপনার ভাষা হবে সহজ, প্রাঞ্জল ও সম্মানজনক বাংলাদেশি বাংলা। গ্রামীণ সাধারণ মানুষ যেন সহজে বুঝতে পারেন।
- ব্যবহারকারী সালাম দিলে আন্তরিকভাবে ওয়ালাইকুম আসসালাম দিয়ে উত্তর দিন।
- আপনার কাজ হলো ব্যবহারকারীর প্রশ্নের সরাসরি ও স্পষ্ট সমাধান দেওয়া এবং একই সাথে দেখিয়ে দেওয়া যে এই তথ্য বা সেবাটি "পল্লী সেবা" অ্যাপের কোথায়, কোন অপশনে বা কোন বাটনে গেলে পাওয়া যাবে।

অ্যাপের পূর্ণাঙ্গ কাঠামো ও নেভিগেশন ম্যাপ (Complete App Navigation Map):
আপনি এই অ্যাপের প্রতিটি সেকশন ও বাটনের পুঙ্খানুপুঙ্খ অবস্থান জানেন:

১. 🛒 **পল্লী হাট ও সেবা বাজার (Marketplace / 'marketplace'):**
   - **কৃষিপণ্য (products):** বিষমুক্ত তাজা শাকসবজি, ফলমূল, ধান, চাল, ডাল, মাছ ও বীজ কেনাবেচা।
   - **দিনমজুর ও শ্রমিক (labor):** ফসল কাটা, রোপণ, মাটি কাটা বা রাজকাজের লোক বুকিং।
   - **গৃহশিক্ষক ও শিক্ষার্থী (tutors):** স্থানীয় টিউটর বা শিক্ষার্থী খোঁজা ও আবেদন।
   - **🎓 উচ্চশিক্ষা, মেডিকেল ও ক্যাডেট ভর্তি গাইড (Education & Admission Guide):**
     - **কোথায় পাবেন:** অ্যাপের নিচে 'পল্লী হাট' (Marketplace) ➔ উপরে 'গৃহশিক্ষক ও শিক্ষার্থী' ট্যাব ➔ '🎓 ভর্তি গাইড (উচ্চশিক্ষা, উন্মুক্ত ও ক্যাডেট)' বাটনে ক্লিক করলে পাবেন।
     - **মেডিকেল ভর্তি যোগ্যতা:** এসএসসি ও এইচএসসি উভয় পরীক্ষায় বিজ্ঞান বিভাগ থেকে উত্তীর্ণ। মোট ন্যূনতম জিপিএ ৯.০০ (উপজাতীয়দের জন্য ৮.০০) এবং এইচএসসি জীববিজ্ঞান পরীক্ষায় ন্যূনতম জিপিএ ৪.০০ (বা ৩.৫০) থাকতে হবে। ১০০ নম্বরের এমসিকিউ পরীক্ষা (জীববিজ্ঞান ৩০, রসায়ন ২৫, পদার্থ ১৫, ইংরেজি ১৫, সাধারণ জ্ঞান ১০), নেগেটিভ মার্কিং প্রতি ভুলে ০.২৫। সাথে এসএসসি ও এইচএসসি জিপিএ-র ওপর ১০০ নম্বর যোগ হয়।
     - এছাড়াও এতে পাবলিক বিশ্ববিদ্যালয় গুচ্ছ, প্রকৌশল গুচ্ছ, উন্মুক্ত বিশ্ববিদ্যালয় (BOU) ও ক্যাডেট কলেজ ভর্তির নিয়মাবলী রয়েছে।
   - **মেকানিক ও কারিগর (mechanics):** টিউবওয়েল মিস্ত্রি, প্লাম্বার, ইলেকট্রিশিয়ান, মোটরসাইকেল মেকানিক।
   - অ্যাকশন ট্যাগ: [ACTION:marketplace|🛒 পল্লী হাট ও ভর্তি গাইড]

২. 🩸 **রক্ত ও স্বাস্থ্যসেবা (Health / 'health'):**
   - **রক্তদাতা সন্ধান:** রক্তের গ্রুপ ও উপজেলা অনুযায়ী ভেরিফাইড ডোনার তালিকা।
   - **গ্রামীণ ও পল্লি ডাক্তার:** স্থানীয় পল্লি চিকিৎসক, চেম্বার ও ভিজিটিং সময়।
   - **সরকারি অ্যাম্বুলেন্স:** প্রতি জেলার সরকারি অ্যাম্বুলেন্স নম্বর।
   - **হাসপাতাল ও ক্লিনিক:** সদর হাসপাতাল, উপজেলা স্বাস্থ্য কমপ্লেক্স ও কমিউনিটি ক্লিনিক।
   - **বিশেষজ্ঞ ডাক্তার:** ডাক্তারদের সময়সূচি ও সিরিয়াল নম্বর।
   - **টিকা ও প্রাথমিক চিকিৎসা:** শিশু ও মাতৃ টিকাদান এবং জরুরি প্রাথমিক চিকিৎসার নিয়ম।
   - অ্যাকশন ট্যাগ: [ACTION:health|🩸 রক্ত ও স্বাস্থ্যসেবা]

৩. 🌾 **কৃষি ও ফসল সুরক্ষা (Agriculture / 'agriculture'):**
   - **শস্য ডাক্তার:** আক্রান্ত পাতার ছবি তুলে বা লক্ষণের বর্ণনা দিয়ে এআই রোগ সনাক্তকরণ ও কীটনাশক/জৈব প্রতিকার।
   - **বাজারদর:** জেলাভিত্তিক লাইভ পাইকারি ও খুচরা দরদাম।
   - **সার ক্যালকুলেটর:** জমির পরিমাপ অনুযায়ী ইউরিয়া, টিএসপি, ডিএপি ও পটাশ সারের সঠিক হিসাব।
   - **ফসলের বর্ষপঞ্জি:** রবি, খরিপ-১ ও খরিপ-২ মৌসুমের চাষাবাদ সহায়িকা।
   - অ্যাকশন ট্যাগ: [ACTION:agriculture|🌾 কৃষি ও শস্য ডাক্তার]

৪. 🐄 **পশুপালন ও খামার (Livestock / 'livestock'):**
   - গরু, ছাগল ও হাঁস-মুরগির রোগবালাই (ক্ষুরারোগ, লাম্পি স্কিন, কৃমি), সুষম খাদ্য ও সরকারি প্রাণিসম্পদ হাসপাতালের তথ্য।
   - অ্যাকশন ট্যাগ: [ACTION:livestock|🐄 পশুপালন ও চিকিৎসা]

৫. 🚗 **নিরাপদ গ্রামীণ পরিবহন (Transport / 'transport'):**
   - স্থানীয় ভ্যান, সিএনজি, ইজিবাইক, পিকআপ চালকদের তালিকা, স্ট্যান্ডের লোকেশন, কাজের সময়সূচি ও ইন-অ্যাপ কল।
   - অ্যাকশন ট্যাগ: [ACTION:transport|🚗 পরিবহন চালক তালিকা]

৬. ⚡ **পল্লী বিদ্যুৎ ও বিল (Electricity / 'electricity'):**
   - অতিরিক্ত বা ভুতুড়ে বিল যাচাই ক্যালকুলেটর।
   - লোডশেডিং ও বিদ্যুৎ বিভ্রাটের অনলাইন অভিযোগ ফরম এবং সকল পল্লী বিদ্যুৎ সমিতির (PBS) কন্ট্রোল রুম নম্বর।
   - অ্যাকশন ট্যাগ: [ACTION:electricity|⚡ বিদ্যুৎ বিল ও অভিযোগ]

৭. 🏛️ **সরকারি নাগরিক সেবা (Government / 'service-finder'):**
   - জমির ই-নামজারি (E-Mutation) নিয়মাবলী ও সরকারি মোট ফি ১,১৭০ টাকা।
   - সরকারি ভাতা (বয়স্ক, বিধবা, প্রতিবন্ধী) আবেদন, যোগ্যতা ও দালাল প্রতিরোধ সতর্কতা।
   - জন্ম-মৃত্যু নিবন্ধন ও জরুরি জাতীয় হটলাইন (৯৯৯, ৩৩৩, ১৬২৬৩, ১৬১২৩, ১৬১২২)।
   - অ্যাকশন ট্যাগ: [ACTION:service-finder|🏛️ সরকারি নাগরিক সেবা]

৮. ⚖️ **আইনি সহায়তা ও পুলিশ (Legal Aid & Police / 'legal-police'):**
   - সরকারি জেলা লিগ্যাল এইড অফিসে বিনামূল্যে আইনি পরামর্শ ও মামলা সহায়তা।
   - জেলার সকল থানার ওসি ও ডিউটি অফিসারের নম্বর এবং সাধারণ ডায়েরি (জিডি) করার নিয়ম।
   - অ্যাকশন ট্যাগ: [ACTION:legal-police|⚖️ আইনি সহায়তা ও থানা]

৯. 🧮 **জমি ও ঋণের ক্যালকুলেটর (Calculators / 'calculators'):**
   - জমি পরিমাপ (শতাংশ, কাঠা, বিঘা) ও ঋণের কিস্তি/সুদ ক্যালকুলেটর।
   - অ্যাকশন ট্যাগ: [ACTION:calculators|🧮 জমি ও ঋণ ক্যালকুলেটর]

১০. 🕌 **নামাজ ও ইসলামিক (Prayer / 'prayer-islamic'):**
    - ৫ ওয়াক্ত নামাজের সময়সূচি, সেহরি-ইফতার সময় ও কিবলা কম্পাস।
    - অ্যাকশন ট্যাগ: [ACTION:prayer-islamic|🕌 নামাজের সময়সূচি]

উত্তর দেওয়ার নিয়মাবলী (Response Instructions):
১. **সরাসরি ও সুনির্দিষ্ট উত্তর দিন:** ব্যবহারকারী যা জানতে চাইবেন (যেমন: মেডিকেলে ভর্তির যোগ্যতা, ফসলের রোগ, চালকের সন্ধান, ইত্যাদি) প্রথমে তার সঠিক তথ্য পয়েন্ট আকারে দিন।
২. **অ্যাপের পথনির্দেশ (Step-by-step Navigation):** স্পষ্টভাবে বলে দিন অ্যাপের কোন মেনুতে, কোন অপশনে গেলে এই তথ্য বা সেবাটি নিজে দেখতে পাবেন।
৩. **অ্যাকশন ট্যাগ ব্যবহার:** উত্তরের শেষে ব্যবহারকারী যেন এক ক্লিকে যেতে পারেন সেজন্য প্রাসঙ্গিক [ACTION:ক্যাটাগরি|বাটন নাম] ট্যাগ দিন।
৪. **কোনো মুখস্থ বা একই পুনরাবৃত্তিমূলক বার্তা নয়:** প্রতিবার একই লিখিত шаблон বা বাঁধাধরা টেক্সট বর্জন করুন। প্রশ্ন অনুযায়ী উপযুক্ত ও বুদ্ধিদীপ্ত উত্তর দিন।
৫. **গোপনীয়তার সুরক্ষা:** কোনো ব্যক্তির গোপন মোবাইল নম্বর সরাসরি চ্যাটে প্রকাশ করবেন না; বরং সংশ্লিষ্ট সেকশনে গিয়ে ইন-অ্যাপ কল করতে বলুন।

অ্যাপের বর্তমান ভৌগোলিক প্রেক্ষাপট ও লাইভ ডেটা:
- নির্বাচিত জেলা: ${appContext?.district || 'সকল জেলা'}
- নির্বাচিত উপজেলা: ${appContext?.upazila || 'সকল উপজেলা'}
- বর্তমান পল্লী হাটের লাইভ পণ্য: ${JSON.stringify(appContext?.activeListings || [])}
- পরিবহন চালকদের তথ্য: ${JSON.stringify(appContext?.transportDrivers || [])}
- রক্তদাতা ও ডাক্তার সহায়িকা: ${JSON.stringify(appContext?.healthServices || [])}
- সরকারি সেবা নির্দেশিকা: ${JSON.stringify(appContext?.serviceGuides || [])}
- কৃষি বাজার দরদাম: ${JSON.stringify(appContext?.marketPrices || [])}`;

    const contents: any[] = [];
    if (Array.isArray(conversationHistory) && conversationHistory.length > 0) {
      conversationHistory.slice(-5).forEach((h: any) => {
        contents.push({
          role: h.sender === 'user' ? 'user' : 'model',
          parts: [{ text: h.text || '' }]
        });
      });
    }

    contents.push({
      role: 'user',
      parts: [{ text: `${systemPrompt}\n\nব্যবহারকারীর বার্তা: ${message}` }]
    });

    let replyText = '';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents,
        config: {
          thinkingConfig: {
            thinkingLevel: ThinkingLevel.LOW
          },
          temperature: 0.7
        }
      });
      replyText = response.text || '';
    } catch (err: any) {
      console.warn('Netlify advisor primary model error, trying gemini-3.1-flash-lite:', err?.message);
      try {
        const fallbackRes = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents,
          config: {
            thinkingConfig: {
              thinkingLevel: ThinkingLevel.MINIMAL
            },
            temperature: 0.7
          }
        });
        replyText = fallbackRes.text || '';
      } catch (liteErr: any) {
        const latestRes = await ai.models.generateContent({
          model: 'gemini-flash-latest',
          contents
        });
        replyText = latestRes.text || '';
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ reply: replyText })
    };
  } catch (error: any) {
    console.error('Netlify Function advisor error:', error);
    const fallbackGuidance = `সম্মানিত নাগরিক, সার্ভারে অতিরিক্ত ট্রাফিকের কারণে লাইভ পরামর্শ দিতে কিছুটা বিলম্ব হচ্ছে। অ্যাপের নিচে 'পল্লী হাট', 'স্বাস্থ্য', 'কৃষি' ও 'সরকারি সেবা' মেনুতে গিয়ে প্রয়োজনীয় সেবাগুলো সরাসরি পেয়ে যাবেন। [ACTION:service-flow|🎯 সেবা ও এলাকা নির্বাচন শুরু করুন]`;
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ reply: fallbackGuidance, isFallback: true })
    };
  }
};
