import { GoogleGenAI, ThinkingLevel } from '@google/genai';

export const handler = async (event: any) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY || '';
    if (!apiKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Gemini API Key Netlify-তে সেট করা নেই।' })
      };
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
    const payload = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
    const { cropName, symptom, imageBase64, mimeType } = payload || {};

    if (!cropName && !symptom && !imageBase64) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'ফসলের নাম, লক্ষণ বা ছবি প্রদান করুন' })
      };
    }

    const parts: any[] = [];
    if (imageBase64 && mimeType) {
      parts.push({
        inlineData: {
          mimeType: mimeType || 'image/jpeg',
          data: imageBase64
        }
      });
    }

    const prompt = `আপনি একজন অভিজ্ঞ কৃষিবিদ ও ফসল বিশেষজ্ঞ।
ফসলের নাম: ${cropName || 'অনির্দিষ্ট'}
রোগের লক্ষণ ও সমস্যা: ${symptom || 'ছবিটি নিবিড়ভাবে পর্যবেক্ষণ করে সমস্যা বিশ্লেষণ করুন'}

অনুগ্রহ করে নিচের সুস্পষ্ট ধারায় বাংলায় উত্তর দিন:
1. 🌾 রোগের নাম ও প্রাথমিক সনাক্তকরণ
2. 🔍 আক্রান্ত হওয়ার মূল কারণ
3. 💊 দ্রুত প্রতিকার ও কার্যকর কীটনাশক/ছত্রাকনাশক (মাত্রা ও স্প্রে করার নিয়মসহ)
4. 🌿 ভেষজ ও প্রাকৃতিক জৈব সমাধান
5. 🛡️ পরবর্তী মৌসুমে বা জমিতে প্রতিরোধমূলক ব্যবস্থা`;

    parts.push({ text: prompt });

    let diagnosis = '';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [{ role: 'user', parts }],
        config: {
          thinkingConfig: {
            thinkingLevel: ThinkingLevel.LOW
          }
        }
      });
      diagnosis = response.text || '';
    } catch (err: any) {
      console.warn('diagnose-crop primary model failed, attempting gemini-3.1-flash-lite:', err?.message);
      try {
        const fallbackRes = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: [{ role: 'user', parts }]
        });
        diagnosis = fallbackRes.text || '';
      } catch (liteErr: any) {
        const latestRes = await ai.models.generateContent({
          model: 'gemini-flash-latest',
          contents: [{ role: 'user', parts }]
        });
        diagnosis = latestRes.text || '';
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ diagnosis })
    };
  } catch (error: any) {
    console.error('Netlify Function diagnose-crop error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message || 'রোগ নির্ণয়ে ত্রুটি হয়েছে।' })
    };
  }
};
