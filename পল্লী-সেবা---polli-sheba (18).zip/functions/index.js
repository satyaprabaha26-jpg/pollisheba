/**
 * পল্লী সেবা (Polli Sheba) - Firebase Cloud Functions (Node.js)
 * 
 * ডিপ্লয় করার নিয়মাবলী:
 * ১. আপনার কম্পিউটারে Firebase CLI ইনস্টল করুন: npm install -g firebase-tools
 * ২. functions ডিরেক্টরিতে ডিপেন্ডেন্সি নিশ্চিত করুন: npm install firebase-admin firebase-functions
 * ৩. ডিপ্লয় কমান্ড চালান: firebase deploy --only functions
 */

const functions = require('firebase-functions');
const admin = require('firebase-admin');

if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();
const messaging = admin.messaging();

/**
 * ১. ঐচ্ছিক লোকেশন অনুযায়ী ডাটাবেজ থেকে কাঙ্ক্ষিত ইউজারদের ফিল্টার করা
 * - শুধু জেলা দিলে ➔ পুরো জেলার রেজিস্টার্ড সেবাদাতা/নাগরিক
 * - জেলা + উপজেলা দিলে ➔ নির্দিষ্ট উপজেলার ইউজার
 * - জেলা + উপজেলা + ইউনিয়ন দিলে ➔ নির্দিষ্ট ইউনিয়ন/ওয়ার্ডের ইউজার
 */
async function getTargetedUsersByLocation(location) {
  let query = db.collection('registered_users');

  if (location.district) {
    query = query.where('district', '==', location.district.trim());
  }
  if (location.upazila && location.upazila.trim()) {
    query = query.where('upazila', '==', location.upazila.trim());
  }
  if (location.union && location.union.trim()) {
    query = query.where('union', '==', location.union.trim());
  }

  const snapshot = await query.get();
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

/**
 * ২. পণ্য কেনাবেচা পোস্ট ট্রিগার (Marketplace Post Trigger)
 * যখন কেউ হাটে নতুন পণ্য পোস্ট করেন:
 * - পণ্যের ক্যাটাগরি পরীক্ষা করে কৃষি (notifyAgriProducts) বা গৃহস্থালি (notifyHouseholdProducts) টার্গেট করা হয়।
 * - ঐ এলাকার যাদের নোটিফিকেশন সুইচ অন রয়েছে কেবল তাদের ফোনে নোটিফিকেশন পৌঁছায়।
 */
exports.onMarketplacePostCreated = functions.firestore
  .document('haat_listings/{listingId}')
  .onCreate(async (snap, context) => {
    const postData = snap.data();
    if (!postData) return null;

    const {
      title,
      price,
      unit,
      category,
      district,
      upazila,
      unionOrWard,
      sellerName,
      sellerId
    } = postData;

    console.log(`[Haat Post Alert] নতুন পণ্য: ${title}, এলাকা: ${district}, উপজেলা: ${upazila || 'সকল'}`);

    // পণ্যের ধরন নির্ধারণ
    const isAgriProduct = /কৃষি|সবজি|ধান|ফসল|ফল|মাছ|গরু|ছাগল|agri/i.test(category || '');
    const notificationKey = isAgriProduct ? 'notifyAgriProducts' : 'notifyHouseholdProducts';

    // লোকেশন অনুযায়ী ফিল্টার
    const usersInArea = await getTargetedUsersByLocation({
      district,
      upazila,
      union: unionOrWard
    });

    const eligibleTokens = [];
    const batch = db.batch();

    for (const user of usersInArea) {
      if (user.id === sellerId) continue; // বিক্রেতা নিজে বাদ

      // নোটিফিকেশন সেটিংস সুইচ চেক (ডিফল্ট: true)
      const switches = user.notificationSwitches || user.notificationSettings || {};
      const isAllowed = switches[notificationKey] !== false;

      if (!isAllowed) continue;

      if (user.fcmToken) {
        eligibleTokens.push(user.fcmToken);
      }

      // ইন-অ্যাপ নোটিফিকেশন হিস্ট্রিতে রেকর্ড যোগ
      const notifRef = db.collection('notifications').doc();
      batch.set(notifRef, {
        id: notifRef.id,
        recipientId: user.id,
        type: isAgriProduct ? 'agri_product_post' : 'household_product_post',
        title: isAgriProduct ? '🌱 নতুন কৃষি পণ্যের পোস্ট' : '🏡 নতুন গৃহস্থালি পণ্যের পোস্ট',
        body: `${sellerName || 'এক বিক্রেতা'} "${title}" বিক্রির জন্য দিয়েছেন (৳${price}/${unit})`,
        listingId: context.params.listingId,
        district,
        upazila: upazila || '',
        isRead: false,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
    }

    await batch.commit();

    // FCM পুশ নোটিফিকেশন পাঠানো
    if (eligibleTokens.length > 0) {
      await messaging.sendEachForMulticast({
        tokens: eligibleTokens,
        notification: {
          title: isAgriProduct ? '🌱 পল্লী হাট: নতুন কৃষিজ পণ্য' : '🏡 পল্লী হাট: নতুন গৃহস্থালি পণ্য',
          body: `${title} - ৳${price}/${unit} (${district}${upazila ? `, ${upazila}` : ''})`
        },
        data: {
          listingId: context.params.listingId,
          type: 'market_post'
        }
      });
      console.log(`[FCM] ${eligibleTokens.length} টি ফোনে পুশ নোটিফিকেশন পাঠানো হয়েছে।`);
    }

    return null;
  });

/**
 * ৩. নির্দিষ্ট সেবা বা চালক রিকোয়েস্ট ট্রিগার (Targeted Service Request Trigger)
 * রওনা দেওয়ার স্থান (Pick-up location) এবং সাব-ক্যাটাগরি (যেমন সিএনজি চালক বা পশু চিকিৎসক) অনুযায়ী
 * শুধুমাত্র সংশ্লিষ্ট এলাকার যোগ্য সেবাদাতাদের নোটিফিকেশন পাঠানো হয়।
 */
exports.onServiceRequestCreated = functions.firestore
  .document('service_requests/{requestId}')
  .onCreate(async (snap, context) => {
    const requestData = snap.data();
    if (!requestData) return null;

    const {
      serviceCategory, // e.g. driver, health_worker, electrician_mechanic, laborer
      subCategory,     // e.g. cng, ambulance, veterinary, house_electrician
      pickupDistrict,
      pickupUpazila,
      pickupUnion,
      requesterName,
      destination
    } = requestData;

    console.log(`[Service Request] সেবা: ${serviceCategory} (${subCategory}), স্থান: ${pickupDistrict} > ${pickupUpazila}`);

    const providersInArea = await getTargetedUsersByLocation({
      district: pickupDistrict,
      upazila: pickupUpazila,
      union: pickupUnion
    });

    const eligibleTokens = [];
    const batch = db.batch();

    for (const provider of providersInArea) {
      // মূল ক্যাটাগরি রোল চেক
      const roleMatches = provider.role === serviceCategory || provider.mainCategory === serviceCategory;
      if (!roleMatches) continue;

      // সাব-ক্যাটাগরি ম্যাচিং (যেমন সিএনজি, বাইক, ভেটেরিনারি)
      if (subCategory && subCategory !== 'all') {
        const pSub = provider.subCategory || provider.driverInfo?.vehicleType || provider.mechanicType || provider.laborerType;
        const subMatches = pSub === subCategory || (typeof pSub === 'string' && pSub.toLowerCase().includes(subCategory.toLowerCase()));
        if (!subMatches) continue;
      }

      // পেশাগত সেবার নোটিফিকেশন অন আছে কি না (notifyProfessionalServices)
      const switches = provider.notificationSwitches || provider.notificationSettings || {};
      if (switches.notifyProfessionalServices === false) continue;

      if (provider.fcmToken) {
        eligibleTokens.push(provider.fcmToken);
      }

      const notifRef = db.collection('notifications').doc();
      batch.set(notifRef, {
        id: notifRef.id,
        recipientId: provider.id,
        type: 'service_request_alert',
        title: '🔔 আপনার এলাকায় নতুন সেবার ডাক!',
        body: `${requesterName || 'একজন নাগরিক'} আপনার সেবা চেয়েছেন${destination ? ` (গন্তব্য: ${destination})` : ''}।`,
        requestId: context.params.requestId,
        category: serviceCategory,
        subCategory: subCategory || '',
        pickupLocation: `${pickupDistrict}${pickupUpazila ? `, ${pickupUpazila}` : ''}`,
        isRead: false,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
    }

    await batch.commit();

    if (eligibleTokens.length > 0) {
      await messaging.sendEachForMulticast({
        tokens: eligibleTokens,
        notification: {
          title: '🚨 জরুরি সেবার ডাক!',
          body: `${requesterName || 'নাগরিক'} আপনার এলাকায় ${subCategory || serviceCategory} খুঁজছেন।`
        },
        data: {
          requestId: context.params.requestId,
          type: 'service_request'
        }
      });
      console.log(`[FCM Service Alert] ${eligibleTokens.length} জন সেবাদাতাকে নোটিফিকেশন পাঠানো হয়েছে।`);
    }

    return null;
  });

/**
 * ৪. এগোরা ডায়নামিক আরটিসি টোকেন জেনারেশন (Agora Dynamic RTC Token Generator)
 * কলার এবং প্রাপক উভয়ই চ্যানেল নেম এবং ইউজার ইউআইডি (UID) দিয়ে সিকিউর ডায়নামিক টোকেন গ্রহণ করে।
 */
let RtcTokenBuilder, RtcRole;
try {
  const agoraPkg = require('agora-token');
  RtcTokenBuilder = agoraPkg.RtcTokenBuilder;
  RtcRole = agoraPkg.RtcRole;
} catch (err) {
  console.warn('agora-token module load note:', err.message);
}

const AGORA_APP_ID = process.env.AGORA_APP_ID || '7658b328207c4c42b1e8c7b3a1a9e7a9';
const AGORA_APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE || '';

function createAgoraRtcToken(channelName, uid, role = 'publisher') {
  if (!AGORA_APP_CERTIFICATE) {
    return {
      token: '',
      appId: AGORA_APP_ID,
      hasCertificate: false,
      message: 'No App Certificate configured. Running in testing mode.'
    };
  }

  if (!RtcTokenBuilder) {
    throw new Error('RtcTokenBuilder is not available');
  }

  const rtcRole = role === 'publisher' ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER;
  const expirationTimeInSeconds = 3600; // ১ ঘণ্টা মেয়াদ
  const currentTimestamp = Math.floor(Date.now() / 1000);
  const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;

  const numUid = Number(uid);
  let token = '';
  if (!isNaN(numUid) && numUid > 0 && numUid < 4294967295) {
    token = RtcTokenBuilder.buildTokenWithUid(
      AGORA_APP_ID,
      AGORA_APP_CERTIFICATE,
      channelName,
      numUid,
      rtcRole,
      expirationTimeInSeconds,
      privilegeExpiredTs
    );
  } else {
    token = RtcTokenBuilder.buildTokenWithUserAccount(
      AGORA_APP_ID,
      AGORA_APP_CERTIFICATE,
      channelName,
      String(uid || 'user'),
      rtcRole,
      expirationTimeInSeconds,
      privilegeExpiredTs
    );
  }

  return {
    token,
    appId: AGORA_APP_ID,
    channelName,
    uid,
    hasCertificate: true,
    expiresIn: expirationTimeInSeconds
  };
}

// HTTP API: /getAgoraRtcToken
exports.getAgoraRtcToken = functions.https.onRequest((req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.status(204).send('');
    return;
  }

  try {
    const { channelName, uid, role } = req.body || req.query;
    if (!channelName) {
      res.status(400).json({ error: 'channelName is required' });
      return;
    }

    const tokenData = createAgoraRtcToken(channelName, uid, role);
    res.json(tokenData);
  } catch (err) {
    console.error('Error generating Agora token:', err);
    res.status(500).json({ error: err.message });
  }
});

// Callable Function: getAgoraTokenCallable
exports.getAgoraTokenCallable = functions.https.onCall(async (data, context) => {
  const { channelName, uid, role } = data || {};
  if (!channelName) {
    throw new functions.https.HttpsError('invalid-argument', 'channelName is required');
  }
  const effectiveUid = uid || (context.auth ? context.auth.uid : 'user');
  return createAgoraRtcToken(channelName, effectiveUid, role);
});

/**
 * ৫. ইন-অ্যাপ হাই-প্রায়োরিটি কল সিগনালিং ট্রিগার (High-Priority FCM Call Signaling & CallKit Trigger)
 * যখন কেউ কল ডায়াল করে এবং 'call_sessions' তৈরি হয়:
 * - সাথে সাথে প্রাপকের ডিভাইসে হাই-প্রায়োরিটি পুশ সিগনাল পাঠানো হয়।
 * - প্রাপকের স্ক্রিন অফ বা অ্যাপ ব্যাকগ্রাউন্ডে থাকলেও CallKit / ফুল-স্ক্রিন ইনকামিং রিংটোন স্ক্রিন সক্রিয় হবে।
 * - এগোরা ডায়নামিক টোকেন প্রি-জেনারেট করে ডকুমেন্টে সিঙ্ক করে দেওয়া হয়।
 */
exports.onCallSessionCreated = functions.firestore
  .document('call_sessions/{channelId}')
  .onCreate(async (snap, context) => {
    const sessionData = snap.data();
    if (!sessionData) return null;

    const {
      channelId,
      callerId,
      callerName,
      callerAvatar,
      callerRole,
      recipientId,
      recipientName
    } = sessionData;

    console.log(`[Incoming Call Signaling] ${callerName} -> ${recipientName} (Channel: ${channelId})`);

    // ডায়নামিক টোকেন জেনারেশন এবং সেশনে যুক্ত করা
    let callerToken = '';
    let recipientToken = '';
    try {
      if (AGORA_APP_CERTIFICATE) {
        callerToken = createAgoraRtcToken(channelId, callerId, 'publisher').token;
        recipientToken = createAgoraRtcToken(channelId, recipientId, 'publisher').token;
        await snap.ref.update({
          callerToken,
          recipientToken,
          appId: AGORA_APP_ID
        });
      }
    } catch (tokenErr) {
      console.warn('Token pre-generation notice:', tokenErr.message);
    }

    // প্রাপকের এফসিএম টোকেন অনুসন্ধান
    let recipientFcmToken = sessionData.recipientFcmToken || null;
    if (!recipientFcmToken && recipientId) {
      const userDoc = await db.collection('registered_users').doc(recipientId).get();
      if (userDoc.exists) {
        recipientFcmToken = userDoc.data().fcmToken || null;
      }
    }

    if (!recipientFcmToken) {
      console.log(`[Call Signaling] Recipient ${recipientId} has no registered FCM token.`);
      return null;
    }

    // High-Priority FCM Payload for Background & Screen-Off Ringing
    const message = {
      token: recipientFcmToken,
      data: {
        type: 'incoming_call',
        channelId: String(channelId),
        callerId: String(callerId),
        callerName: String(callerName || 'নাগরিক'),
        callerAvatar: String(callerAvatar || ''),
        callerRole: String(callerRole || 'পল্লী সেবা অডিও কল'),
        hasVideo: 'false',
        ringDuration: '45', // ঠিক ৪৫ সেকেন্ড রিংটাইম
        timestamp: String(Date.now())
      },
      android: {
        priority: 'high',
        ttl: 45, // ৪৫ সেকেন্ড টিটিএল (টাইমআউটের পর বাতিল)
        notification: {
          channelId: 'polli_call_channel',
          sound: 'ringtone',
          priority: 'max',
          visibility: 'public',
          clickAction: 'FLUTTER_NOTIFICATION_CLICK'
        }
      },
      apns: {
        headers: {
          'apns-priority': '10',
          'apns-push-type': 'voip',
          'apns-expiration': String(Math.floor(Date.now() / 1000) + 45)
        },
        payload: {
          aps: {
            alert: {
              title: 'ইনকামিং অডিও কল',
              body: `${callerName || 'নাগরিক'} থেকে কল আসছে...`
            },
            sound: 'ringtone.caf',
            contentAvailable: true
          }
        }
      }
    };

    try {
      await messaging.send(message);
      console.log(`[Call Signaling] High-Priority FCM payload successfully sent to recipient ${recipientId}`);
    } catch (fcmErr) {
      console.error('[Call Signaling Error] Failed to send high-priority FCM:', fcmErr);
    }

    return null;
  });

/**
 * ৬. কল বাতিল / সমাপ্তি সিগনালিং ট্রিগার (Cancel CallKit on Session Ended / Rejected / Missed)
 * কল ৪৫ সেকেন্ডে উত্তর না দিলে (missed) অথবা কলার আগে কেটে দিলে সাথে সাথে রিং বন্ধের সাইড-ইফেক্ট পাঠায়।
 */
exports.onCallSessionUpdated = functions.firestore
  .document('call_sessions/{channelId}')
  .onUpdate(async (change, context) => {
    const beforeData = change.before.data();
    const afterData = change.after.data();

    if (!beforeData || !afterData) return null;

    const previousStatus = beforeData.status;
    const currentStatus = afterData.status;

    // যদি স্ট্যাটাস ringing থেকে missed, ended, বা rejected এ পরিবর্তিত হয়
    if (previousStatus === 'ringing' && (currentStatus === 'missed' || currentStatus === 'ended' || currentStatus === 'rejected')) {
      console.log(`[Call Terminated] Channel ${context.params.channelId} changed to ${currentStatus}. Cancelling ringing UI...`);

      const recipientId = afterData.recipientId;
      if (!recipientId) return null;

      const userDoc = await db.collection('registered_users').doc(recipientId).get();
      const fcmToken = userDoc.exists ? userDoc.data().fcmToken : null;

      if (fcmToken) {
        try {
          await messaging.send({
            token: fcmToken,
            data: {
              type: 'cancel_call',
              channelId: String(context.params.channelId),
              reason: currentStatus
            },
            android: {
              priority: 'high',
              ttl: 10
            }
          });
        } catch (e) {
          console.warn('Failed to send cancel_call push:', e.message);
        }
      }
    }

    return null;
  });
