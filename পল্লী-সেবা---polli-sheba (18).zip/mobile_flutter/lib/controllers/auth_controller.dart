import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:url_launcher/url_launcher.dart';

class AuthController extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // টেস্ট মোবাইল নম্বরগুলোর জন্য ওটিপি বাইপাস তালিকা
  static const Map<String, String> TEST_PHONE_OTP_BYPASS = {
    '+8801700000000': '123456',
    '+8801800000000': '123456',
    '+8801900000000': '123456',
    '+8801300000000': '123456',
    '+8801500000000': '123456',
  };

  User? _currentUser;
  String _verificationId = '';
  bool _isLoading = false;
  String? _errorMessage;

  User? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  AuthController() {
    _currentUser = _auth.currentUser;
    _auth.authStateChanges().listen((user) {
      _currentUser = user;
      notifyListeners();
    });
  }

  /// ফোন নম্বর ইনপুট ফরম্যাটিং ও স্বয়ংক্রিয় '+880' প্রিফিক্স লজিক
  /// ইনপুট: "01712345678" -> আউটপুট: "+8801712345678"
  /// ইনপুট: "1712345678"  -> আউটপুট: "+8801712345678"
  static String formatBangladeshPhoneNumber(String rawInput) {
    String clean = rawInput.replaceAll(RegExp(r'[^0-9+]'), '');

    if (clean.startsWith('+880')) {
      return clean;
    }
    if (clean.startsWith('880')) {
      return '+$clean';
    }
    if (clean.startsWith('0')) {
      clean = clean.substring(1);
    }

    return '+880$clean';
  }

  /// ফোন নম্বর ভ্যালিডেশন (১০ ডিজিটের বাংলাদেশি মোবাইল নম্বর)
  static bool isValidBangladeshNumber(String formattedPhone) {
    final clean = formattedPhone.replaceAll(RegExp(r'[^0-9]'), '');
    // 8801XXXXXXXXX -> মোট ১৩ ডিজিট (880 + 10 ডিজিট)
    final regex = RegExp(r'^8801[3-9]\d{8}$');
    return regex.hasMatch(clean);
  }

  /// ওটিপি পাঠানো (Firebase Phone Auth with Bypass Check)
  Future<bool> sendOtp({
    required String rawPhone,
    required Function(String verificationId) onCodeSent,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    final formattedPhone = formatBangladeshPhoneNumber(rawPhone);

    if (!isValidBangladeshNumber(formattedPhone)) {
      _isLoading = false;
      _errorMessage = 'অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর লিখুন (যেমন: 01712345678)';
      notifyListeners();
      return false;
    }

    // ১. টেস্ট ওটিপি বাইপাস চেক
    if (TEST_PHONE_OTP_BYPASS.containsKey(formattedPhone)) {
      _verificationId = 'test_bypass_id';
      _isLoading = false;
      notifyListeners();
      onCodeSent(_verificationId);
      return true;
    }

    // ২. ফায়ারবেস ফোন অথেনটিকেশন
    try {
      await _auth.verifyPhoneNumber(
        phoneNumber: formattedPhone,
        verificationCompleted: (PhoneAuthCredential credential) async {
          await _auth.signInWithCredential(credential);
          _isLoading = false;
          notifyListeners();
        },
        verificationFailed: (FirebaseAuthException e) {
          _isLoading = false;
          _errorMessage = e.message ?? 'ওটিপি পাঠাতে সমস্যা হয়েছে। পুনরায় চেষ্টা করুন।';
          notifyListeners();
        },
        codeSent: (String verId, int? resendToken) {
          _verificationId = verId;
          _isLoading = false;
          notifyListeners();
          onCodeSent(verId);
        },
        codeAutoRetrievalTimeout: (String verId) {
          _verificationId = verId;
        },
      );
      return true;
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'ত্রুটি: $e';
      notifyListeners();
      return false;
    }
  }

  /// ওটিপি ভেরিফাই করা
  Future<bool> verifyOtp({
    required String rawPhone,
    required String otpCode,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    final formattedPhone = formatBangladeshPhoneNumber(rawPhone);

    // ১. টেস্ট বাইপাস ওটিপি ম্যাচ চেক
    if (TEST_PHONE_OTP_BYPASS.containsKey(formattedPhone)) {
      final expectedOtp = TEST_PHONE_OTP_BYPASS[formattedPhone];
      if (otpCode == expectedOtp) {
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _isLoading = false;
        _errorMessage = 'ভুল ওটিপি কোড। সঠিক কোডটি লিখুন।';
        notifyListeners();
        return false;
      }
    }

    // ২. ফায়ারবেস ওটিপি ভেরিফিকেশন
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: _verificationId,
        smsCode: otpCode,
      );
      await _auth.signInWithCredential(credential);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'ওটিপি মিলছে না অথবা মেয়াদ শেষ হয়ে গেছে।';
      notifyListeners();
      return false;
    }
  }

  /// অফলাইন ডায়ালার লঞ্চার (Android ACTION_DIAL)
  static Future<void> launchNativeDialer(String rawPhone) async {
    final cleanPhone = rawPhone.replaceAll(RegExp(r'[^0-9+]'), '');
    final Uri uri = Uri.parse('tel:$cleanPhone');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }
}
