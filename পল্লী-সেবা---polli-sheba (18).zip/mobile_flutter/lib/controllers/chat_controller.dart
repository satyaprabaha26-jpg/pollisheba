import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ChatMessageModel {
  final String id;
  final String senderId;
  final String senderName;
  final String? senderRole;
  final String recipientId;
  final String recipientName;
  final String conversationId;
  final String text;
  final DateTime timestamp;
  final String messageType; // 'text' | 'voice'
  final String? audioUrl;
  final int? audioDuration;
  bool isRead;

  ChatMessageModel({
    required this.id,
    required this.senderId,
    required this.senderName,
    this.senderRole,
    required this.recipientId,
    required this.recipientName,
    required this.conversationId,
    required this.text,
    required this.timestamp,
    this.messageType = 'text',
    this.audioUrl,
    this.audioDuration,
    this.isRead = false,
  });

  factory ChatMessageModel.fromMap(Map<String, dynamic> map, String docId) {
    return ChatMessageModel(
      id: docId,
      senderId: map['senderId'] ?? '',
      senderName: map['senderName'] ?? '',
      senderRole: map['senderRole'],
      recipientId: map['recipientId'] ?? '',
      recipientName: map['recipientName'] ?? '',
      conversationId: map['conversationId'] ?? '',
      text: map['text'] ?? '',
      timestamp: map['timestamp'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['timestamp'])
          : DateTime.now(),
      messageType: map['messageType'] ?? 'text',
      audioUrl: map['audioUrl'],
      audioDuration: map['audioDuration'],
      isRead: map['isRead'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'senderId': senderId,
      'senderName': senderName,
      'senderRole': senderRole,
      'recipientId': recipientId,
      'recipientName': recipientName,
      'conversationId': conversationId,
      'text': text,
      'timestamp': timestamp.millisecondsSinceEpoch,
      'messageType': messageType,
      'audioUrl': audioUrl,
      'audioDuration': audioDuration,
      'isRead': isRead,
    };
  }
}

class ChatController extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // সার্ভিস অনুযায়ী মেসেজ রিটেনশন পলিসি (১ থেকে ৭ দিন পর্যন্ত সংরক্ষণ)
  static const int RETENTION_DAYS = 7;

  List<ChatMessageModel> _activeMessages = [];
  bool _isLoading = false;
  StreamSubscription<QuerySnapshot>? _chatSubscription;

  List<ChatMessageModel> get activeMessages => _activeMessages;
  bool get isLoading => _isLoading;

  /// চ্যাট কনভারসেশন লিসেনার চালু করা
  void openConversation({
    required String currentUserId,
    required String targetUserId,
    String? itemId,
  }) async {
    _isLoading = true;
    notifyListeners();

    final ids = [currentUserId, targetUserId]..sort();
    final conversationId = "${ids.join('_')}${itemId != null ? '_$itemId' : ''}";

    // ১. লোকাল ক্যাশ থেকে তাৎক্ষণিক লোড (যাতে অ্যাপ ব্যাকগ্রাউন্ডে গিয়ে ফিরে আসলেও শূন্য না দেখায়)
    await _loadCachedMessages(conversationId);

    // ২. ফায়ারবেস থেকে ৭ দিনের মধ্যে থাকা মেসেজগুলো রিয়েলটাইমে সিঙ্ক
    final retentionCutoff = DateTime.now().subtract(const Duration(days: RETENTION_DAYS)).millisecondsSinceEpoch;

    _chatSubscription?.cancel();
    _chatSubscription = _firestore
        .collection('conversations')
        .doc(conversationId)
        .collection('messages')
        .where('timestamp', isGreaterThanOrEqualTo: retentionCutoff)
        .orderBy('timestamp', descending: false)
        .snapshots()
        .listen((snapshot) {
      _activeMessages = snapshot.docs
          .map((doc) => ChatMessageModel.fromMap(doc.data(), doc.id))
          .toList();

      _cacheMessages(conversationId, _activeMessages);
      _isLoading = false;
      notifyListeners();
    }, onError: (err) {
      debugPrint("Chat stream error: $err");
      _isLoading = false;
      notifyListeners();
    });
  }

  /// টেক্সট মেসেজ পাঠানো
  Future<void> sendTextMessage({
    required String currentUserId,
    required String currentUserName,
    String? currentUserRole,
    required String targetUserId,
    required String targetUserName,
    required String text,
    String? itemId,
  }) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;

    final ids = [currentUserId, targetUserId]..sort();
    final conversationId = "${ids.join('_')}${itemId != null ? '_$itemId' : ''}";
    final msgId = "msg_${DateTime.now().millisecondsSinceEpoch}";

    final newMsg = ChatMessageModel(
      id: msgId,
      senderId: currentUserId,
      senderName: currentUserName,
      senderRole: currentUserRole,
      recipientId: targetUserId,
      recipientName: targetUserName,
      conversationId: conversationId,
      text: trimmed,
      timestamp: DateTime.now(),
      messageType: 'text',
      isRead: false,
    );

    // অপ্টিমিস্টিক লোকাল আপডেট
    _activeMessages.add(newMsg);
    notifyListeners();

    try {
      await _firestore
          .collection('conversations')
          .doc(conversationId)
          .collection('messages')
          .doc(msgId)
          .set(newMsg.toMap());

      // কনভারসেশন সামারি আপডেট
      await _firestore.collection('conversations_summary').doc(conversationId).set({
        'lastMessage': trimmed,
        'senderId': currentUserId,
        'senderName': currentUserName,
        'recipientId': targetUserId,
        'recipientName': targetUserName,
        'unreadBy': targetUserId,
        'updatedAt': DateTime.now().millisecondsSinceEpoch,
      }, SetOptions(merge: true));
    } catch (e) {
      debugPrint("Failed to send message: $e");
    }
  }

  /// লোকাল ক্যাশে সেভ করা (৭ দিনের মেয়াদ উত্তীর্ণ মেসেজ স্বয়ংক্রিয় ক্লিনআপ)
  Future<void> _cacheMessages(String convId, List<ChatMessageModel> msgs) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cutoff = DateTime.now().subtract(const Duration(days: RETENTION_DAYS));
      final validMsgs = msgs.where((m) => m.timestamp.isAfter(cutoff)).toList();

      final encoded = jsonEncode(validMsgs.map((m) => m.toMap()).toList());
      await prefs.setString('chat_cache_$convId', encoded);
    } catch (e) {
      debugPrint("Local chat cache error: $e");
    }
  }

  /// লোকাল ক্যাশ থেকে রিড করা
  Future<void> _loadCachedMessages(String convId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedStr = prefs.getString('chat_cache_$convId');
      if (cachedStr != null && cachedStr.isNotEmpty) {
        final List<dynamic> decoded = jsonDecode(cachedStr);
        final cutoff = DateTime.now().subtract(const Duration(days: RETENTION_DAYS));

        _activeMessages = decoded
            .map((item) => ChatMessageModel.fromMap(item, item['id'] ?? ''))
            .where((m) => m.timestamp.isAfter(cutoff))
            .toList();
        notifyListeners();
      }
    } catch (e) {
      debugPrint("Load cached chat error: $e");
    }
  }

  void closeConversation() {
    _chatSubscription?.cancel();
    _activeMessages = [];
  }
}
