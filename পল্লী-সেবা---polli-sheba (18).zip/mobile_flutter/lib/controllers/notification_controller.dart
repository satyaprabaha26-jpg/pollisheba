import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/notification_model.dart';
import '../services/fcm_callkit_service.dart';

class NotificationController extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FCMCallKitService _fcmCallKitService = FCMCallKitService();

  List<PolliNotification> _notifications = [];
  int _unreadBadgeCount = 0;
  bool _isLoading = false;
  String? _fcmToken;

  List<PolliNotification> get notifications => _notifications;
  int get unreadBadgeCount => _unreadBadgeCount;
  bool get isLoading => _isLoading;
  String? get fcmToken => _fcmToken;

  /// ১. নোটিফিকেশন লিসেনার ও এফসিএম কলকিট ইনিশিয়ালাইজেশন
  void initNotificationListener({
    required String userId,
    required String userDistrict,
    required String userUpazila,
    required String userRole,
    required String userPhone,
    Function(String channelId, String callerId)? onAcceptCall,
    Function(String channelId)? onDeclineCall,
  }) async {
    _isLoading = true;
    notifyListeners();

    // এফসিএম টোকেন গ্রহণ ও ডাটাবেজে ইউজার ডকুমেন্টে সিঙ্ক
    try {
      _fcmToken = await _fcmCallKitService.getDeviceFCMToken();
      if (_fcmToken != null && userId.isNotEmpty) {
        await _firestore.collection('registered_users').doc(userId).set({
          'fcmToken': _fcmToken,
          'lastTokenUpdate': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
        debugPrint("[NotificationController] FCM Token synced for user $userId");
      }

      // কলকিট সার্ভিস ইনিশিয়ালাইজেশন
      if (onAcceptCall != null && onDeclineCall != null) {
        await _fcmCallKitService.initialize(
          onAcceptCall: onAcceptCall,
          onDeclineCall: onDeclineCall,
        );
      }
    } catch (e) {
      debugPrint("[FCM Init Note] Token or callkit setup note: $e");
    }

    final prefs = await SharedPreferences.getInstance();
    final lastReadTimestamp = prefs.getInt('last_notification_read_time') ?? 0;

    _firestore
        .collection('demand_notifications')
        .orderBy('createdAt', descending: true)
        .limit(50)
        .snapshots()
        .listen((snapshot) {
      final now = DateTime.now().millisecondsSinceEpoch;

      final all = snapshot.docs.map((doc) {
        return PolliNotification.fromMap(doc.data(), doc.id);
      }).where((notif) {
        // এক্সপায়ার হওয়া নোটিফিকেশন বাদ দেওয়া
        if (notif.expiresAt != null && notif.expiresAt!.millisecondsSinceEpoch < now) {
          return false;
        }

        // এলাকা ও রোল ফিল্টারিং (লোকাল ডিপার্টমেন্ট)
        final matchDistrict = notif.targetDistrict == 'সকল জেলা' || notif.targetDistrict == userDistrict;
        final matchUpazila = notif.targetUpazila == 'সকল উপজেলা' || notif.targetUpazila == userUpazila;

        // এফসিএম রাউটিং নিয়ম:
        // ১. সাধারণ পরিবহনে যাত্রী পোস্ট / ফিরতি পরিবহনে যাত্রীর রিকোয়েস্ট: targetRole == 'driver' -> শুধুমাত্র চালক পাবেন
        // ২. ফিরতি পরিবহনে চালকের খালি গাড়ি পোস্ট: targetRole == 'all' -> সাধারণ যাত্রীরা পাবেন
        bool matchRole = false;
        if (notif.targetRole == 'driver') {
          // শুধুমাত্র চালকেরা পাবেন (শিক্ষক, কৃষক ইত্যাদি সাধারণ নাগরিকরা পাবেন না)
          matchRole = userRole == 'driver';
        } else if (notif.targetRole == 'all') {
          // ফিরতি গাড়ির চালকের পোস্ট সাধারণ যাত্রীদের আকর্ষণ করার জন্য; চালকদের বাদ দিয়ে সাধারণ নাগরিকরা প্রাধান্য পাবেন
          if (notif.targetCategory == 'return_transport' || notif.targetCategory == 'transport') {
            matchRole = userRole != 'driver';
          } else {
            matchRole = true;
          }
        } else {
          matchRole = notif.targetRole == userRole;
        }

        return matchDistrict && matchUpazila && matchRole;
      }).toList();

      _notifications = all;

      // নতুন বা অপঠিত নোটিফিকেশন সংখ্যা নির্ধারণ
      _unreadBadgeCount = _notifications.where((n) {
        return n.createdAt.millisecondsSinceEpoch > lastReadTimestamp && !n.isRead;
      }).length;

      _isLoading = false;
      notifyListeners();
    }, onError: (err) {
      debugPrint('Notification sync error: $err');
      _isLoading = false;
      notifyListeners();
    });
  }

  /// নোটিফিকেশন তালিকা ওপেন করা মাত্রই আনরেড ব্যাজ কাউন্ট ০ করা
  Future<void> markAllNotificationsAsRead() async {
    _unreadBadgeCount = 0;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('last_notification_read_time', DateTime.now().millisecondsSinceEpoch);

      // লোকাল অবজেক্টগুলোর স্ট্যাটাস আপডেট
      for (var n in _notifications) {
        n.isRead = true;
      }
      notifyListeners();
    } catch (e) {
      debugPrint('Failed to persist notification read time: $e');
    }
  }

  /// নির্দিষ্ট নোটিফিকেশনে ক্লিক করা এবং সরাসরি বিজ্ঞাপন/সার্ভিস পেজে ডিপ-লিংক রিডাইরেক্ট
  void handleNotificationTap(BuildContext context, PolliNotification notif) {
    // এই নোটিফিকেশনটি পঠিত হিসেবে মার্ক করা
    notif.isRead = true;
    if (_unreadBadgeCount > 0) {
      _unreadBadgeCount--;
    }
    notifyListeners();

    // ডিপ লিংকিং এক্সিকিউশন
    final route = notif.deepLinkRoute;
    debugPrint('Navigating directly via Deep Link: $route');

    // নির্দিষ্ট পেজ অনুযায়ী রাউটিং
    if (notif.targetCategory == 'marketplace') {
      if (notif.itemId != null) {
        Navigator.of(context).pushNamed('/marketplace/product', arguments: {
          'productId': notif.itemId,
          'title': notif.title,
        });
      } else {
        Navigator.of(context).pushNamed('/marketplace', arguments: {
          'initialTab': notif.targetSubTab ?? 'products',
        });
      }
    } else if (notif.targetCategory == 'transport') {
      Navigator.of(context).pushNamed('/transport', arguments: {
        'driverId': notif.itemId,
        'action': 'call_or_book',
      });
    } else if (notif.targetCategory == 'health' || notif.targetRole == 'blood_donor') {
      Navigator.of(context).pushNamed('/health/blood-request', arguments: {
        'requestId': notif.itemId,
        'urgency': notif.urgency.name,
      });
    } else if (notif.targetCategory == 'tutor') {
      Navigator.of(context).pushNamed('/tutor/detail', arguments: {
        'tutorId': notif.itemId,
      });
    } else {
      // সাধারণ ফলব্যাক রাউট
      Navigator.of(context).pushNamed(route);
    }
  }
}
