import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:flutter_callkit_incoming/flutter_callkit_incoming.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/call_record_model.dart';
import '../services/fcm_callkit_service.dart';

enum ActiveCallState {
  idle,
  dialing,
  ringing,
  connected,
  ended,
  missed,
  offlinePrompt,
}

class AgoraVoiceCallController extends ChangeNotifier {
  // এগোরা অ্যাপ আইডি (কনসোল থেকে প্রাপ্ত)
  static const String AGORA_APP_ID = "7658b328207c4c42b1e8c7b3a1a9e7a9";
  
  // ব্যাকএন্ড ডায়নামিক টোকেন এন্ডপয়েন্ট (ক্লাউড ফাংশন বা নোড সার্ভার)
  static const String TOKEN_SERVER_URL = "https://ais-dev-ffygxpubjswuwe4v2comze-467110571400.asia-east1.run.app/api/agora/token";

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  RtcEngine? _engine;
  ActiveCallState _callState = ActiveCallState.idle;
  String _currentChannelId = '';
  String _currentUserId = '';
  int _callDurationSeconds = 0;
  Timer? _durationTimer;
  Timer? _ringTimeoutTimer; // ঠিক ৪৫ সেকেন্ড রিংটাইম টাইমার

  bool _isMuted = false;
  bool _isSpeakerOn = true;

  // অপর প্রান্তের ইউজারের বিস্তারিত (ফোন নম্বর সম্পূর্ণ গোপন রাখা হয়েছে)
  String _peerName = '';
  String? _peerAvatar;
  String? _peerRole;
  String _peerId = '';
  String _rawPhoneNumber = ''; // শুধুমাত্র ইউজার চাইলে ৪৫ সে. পর অফলাইন ডায়ালারে ব্যবহারের জন্য

  StreamSubscription<DocumentSnapshot>? _sessionSubscription;

  ActiveCallState get callState => _callState;
  String get currentChannelId => _currentChannelId;
  int get callDurationSeconds => _callDurationSeconds;
  bool get isMuted => _isMuted;
  bool get isSpeakerOn => _isSpeakerOn;
  String get peerName => _peerName;
  String? get peerAvatar => _peerAvatar;
  String? get peerRole => _peerRole;
  String get peerId => _peerId;

  /// ১. এগোরা আরটিসি ইঞ্জিন ইনিশিয়ালাইজেশন
  Future<void> initAgoraEngine() async {
    if (_engine != null) return;
    try {
      _engine = createAgoraRtcEngine();
      await _engine!.initialize(const RtcEngineContext(
        appId: AGORA_APP_ID,
        channelProfile: ChannelProfileType.channelProfileCommunication,
      ));

      _engine!.registerEventHandler(
        RtcEngineEventHandler(
          onJoinChannelSuccess: (RtcConnection connection, int elapsed) async {
            debugPrint("[Agora RTC] Joined Channel: ${connection.channelId} (Elapsed: $elapsed ms)");
            await _engine?.enableAudio();
            await _engine?.enableLocalAudio(true);
            await _engine?.muteLocalAudioStream(false);
            await _engine?.setEnableSpeakerphone(true);
          },
          onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) async {
            debugPrint("[Agora RTC] Remote User Connected: $remoteUid");
            await _engine?.enableAudio();
            await _engine?.enableLocalAudio(true);
            await _engine?.muteLocalAudioStream(false);
            await _engine?.setEnableSpeakerphone(true);
            _onCallConnected();
          },
          onUserOffline: (RtcConnection connection, int remoteUid, UserOfflineReasonType reason) {
            debugPrint("[Agora RTC] Remote User Offline: $reason");
            endCall(status: CallStatus.ended, isRemote: true);
          },
          onTokenPrivilegeWillExpire: (RtcConnection connection, String token) async {
            debugPrint("[Agora RTC] Token expiring soon. Refreshing dynamic token...");
            final newToken = await _fetchDynamicToken(_currentChannelId, _currentUserId);
            if (newToken != null && newToken.isNotEmpty) {
              await _engine?.renewToken(newToken);
            }
          },
          onError: (ErrorCodeType err, String msg) {
            debugPrint("[Agora RTC Error] $err: $msg");
          },
        ),
      );

      // In the Agora call session, immediately execute audio and speakerphone initialization
      await _engine!.enableAudio();
      await _engine!.enableLocalAudio(true);
      await _engine!.muteLocalAudioStream(false);
      await _engine!.setEnableSpeakerphone(true);
      _isSpeakerOn = true;
      _isMuted = false;
    } catch (e) {
      debugPrint("Agora init error: $e");
    }
  }

  /// ২. ব্যাকএন্ড থেকে ডায়নামিক আরটিসি টোকেন গ্রহণ (Token Synchronization)
  Future<String?> _fetchDynamicToken(String channelName, String userUid) async {
    try {
      // প্রথমে সেশন ডকুমেন্ট চেক করা (ক্লাউড ফাংশন প্রি-জেনারেট করে রাখলে)
      final sessionDoc = await _firestore.collection('call_sessions').doc(channelName).get();
      if (sessionDoc.exists) {
        final data = sessionDoc.data() as Map<String, dynamic>;
        if (data['callerId'] == userUid && data['callerToken'] != null && (data['callerToken'] as String).isNotEmpty) {
          return data['callerToken'];
        }
        if (data['recipientId'] == userUid && data['recipientToken'] != null && (data['recipientToken'] as String).isNotEmpty) {
          return data['recipientToken'];
        }
      }

      // সার্ভার এপিআই থেকে টোকেন নিয়ে আসা
      final response = await http.post(
        Uri.parse(TOKEN_SERVER_URL),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'channelName': channelName,
          'uid': userUid,
          'role': 'publisher',
        }),
      ).timeout(const Duration(seconds: 6));

      if (response.statusCode == 200) {
        final resData = jsonDecode(response.body);
        final token = resData['token'];
        if (token != null && token is String && token.isNotEmpty) {
          debugPrint("[Agora Token] Dynamic token fetched successfully for $userUid");
          return token;
        }
      }
    } catch (e) {
      debugPrint("[Agora Token Notice] Token fetch error or fallback: $e");
    }
    return '';
  }

  /// ৩. আউটগোয়িং কল শুরু করা (Dialing & Calling with 45s Exact Ringtime)
  /// সতর্কতা: ডায়ালিং বা রিং হওয়া মাত্রই মিসড কল রেকর্ড করা সম্পূর্ণ নিষিদ্ধ।
  Future<void> startVoiceCall({
    required String currentUserId,
    required String currentUserName,
    String? currentUserAvatar,
    String? currentUserRole,
    required String targetUserId,
    required String targetUserName,
    String? targetUserAvatar,
    String? targetUserRole,
    required String targetRawPhone, // শুধুমাত্র ৪৫ সেকেন্ড পর ইউজার সম্মতি দিলে অফলাইন সিম কলের জন্য
    String? targetFcmToken,
  }) async {
    // ১. Ensure that runtime microphone permission is requested via permission_handler before launching any call
    final micPermission = await Permission.microphone.request();
    if (!micPermission.isGranted) {
      debugPrint("[Agora RTC] Microphone permission not granted: $micPermission");
      return;
    }

    await initAgoraEngine();

    // ২. In the Agora call session, immediately execute audio enabling, unmuting, and default speakerphone
    await _engine?.enableAudio();
    await _engine?.enableLocalAudio(true);
    await _engine?.muteLocalAudioStream(false);
    await _engine?.setEnableSpeakerphone(true);
    _isSpeakerOn = true;
    _isMuted = false;

    _currentUserId = currentUserId;
    _callState = ActiveCallState.dialing;
    _peerId = targetUserId;
    _peerName = targetUserName;
    _peerAvatar = targetUserAvatar;
    _peerRole = targetUserRole;
    _rawPhoneNumber = targetRawPhone;
    _callDurationSeconds = 0;
    notifyListeners();

    // ডায়াল টোন চালু
    FlutterRingtonePlayer().play(
      android: AndroidSounds.ringtone,
      ios: IosSounds.glass,
      looping: true,
      volume: 0.5,
    );

    // ডিটারমিনিস্টিক চ্যানেল আইডি তৈরি (User UIDs ভিত্তিক - ফোন নম্বর ছাড়া)
    final ids = [currentUserId, targetUserId]..sort();
    _currentChannelId = "polli_${ids.join('_')}_${DateTime.now().millisecondsSinceEpoch % 100000}";

    // Firestore লাইভ কল সেশন তৈরি (ক্লাউড ফাংশন এর মাধ্যমে হাই-প্রায়োরিটি এফসিএম পুশ যাবে)
    final sessionRef = _firestore.collection('call_sessions').doc(_currentChannelId);
    await sessionRef.set({
      'channelId': _currentChannelId,
      'callerId': currentUserId,
      'callerName': currentUserName,
      'callerAvatar': currentUserAvatar,
      'callerRole': currentUserRole ?? 'নাগরিক',
      'recipientId': targetUserId,
      'recipientName': targetUserName,
      'recipientFcmToken': targetFcmToken,
      'status': 'ringing',
      'ringDuration': 45, // ঠিক ৪৫ সেকেন্ড রিংটাইম
      'createdAt': FieldValue.serverTimestamp(),
    });

    // প্রাপকের রেসপন্স শোনার জন্য রিয়েল-টাইম স্ন্যাপশট লিসেনার
    _sessionSubscription?.cancel();
    _sessionSubscription = sessionRef.snapshots().listen((snap) {
      if (!snap.exists) return;
      final data = snap.data() as Map<String, dynamic>;
      final status = data['status'];

      if (status == 'ringing') {
        _callState = ActiveCallState.ringing;
        notifyListeners();
      } else if (status == 'accepted') {
        _joinAgoraChannel(_currentChannelId, currentUserId);
      } else if (status == 'rejected') {
        endCall(status: CallStatus.rejected, isRemote: true);
      } else if (status == 'ended') {
        endCall(status: CallStatus.ended, isRemote: true);
      } else if (status == 'missed') {
        // টাইমআউট বা মিসড কল
        FlutterRingtonePlayer().stop();
        _callState = ActiveCallState.offlinePrompt;
        notifyListeners();
      }
    });

    // ঠিক ৪৫ সেকেন্ড রিংটাইম টাইমার (45 Seconds Exact Ringing Window)
    _ringTimeoutTimer?.cancel();
    _ringTimeoutTimer = Timer(const Duration(seconds: 45), () {
      if (_callState == ActiveCallState.dialing || _callState == ActiveCallState.ringing) {
        debugPrint("[Call Ringtime] 45 seconds expired without answer. Logging single missed call...");
        _handleCallTimeout(currentUserId, targetUserId, currentUserName, targetUserName);
      }
    });
  }

  /// ৪. এগোরা অডিও চ্যানেলে কানেক্ট হওয়া (Dynamic Token সহ)
  Future<void> _joinAgoraChannel(String channelId, String userId) async {
    FlutterRingtonePlayer().stop();
    _ringTimeoutTimer?.cancel();

    try {
      // ডায়নামিক টোকেন সিঙ্ক
      final token = await _fetchDynamicToken(channelId, userId);
      final numericUid = int.tryParse(userId.replaceAll(RegExp(r'[^0-9]'), '').padRight(6, '0').substring(0, 6)) ?? 101010;

      // In the Agora call session, immediately execute:
      await _engine?.enableAudio();
      await _engine?.enableLocalAudio(true);
      await _engine?.muteLocalAudioStream(false);
      await _engine?.setEnableSpeakerphone(true);
      _isSpeakerOn = true;
      _isMuted = false;

      await _engine?.joinChannel(
        token: token ?? '',
        channelId: channelId,
        uid: numericUid,
        options: const ChannelMediaOptions(
          clientRoleType: ClientRoleType.clientRoleBroadcaster,
          autoSubscribeAudio: true,
          publishMicrophoneTrack: true,
        ),
      );

      // Re-assert audio state immediately after join
      await _engine?.enableAudio();
      await _engine?.enableLocalAudio(true);
      await _engine?.muteLocalAudioStream(false);
      await _engine?.setEnableSpeakerphone(true);
    } catch (e) {
      debugPrint("Agora Channel Join Error: $e");
    }
  }

  void _onCallConnected() async {
    FlutterRingtonePlayer().stop();
    _ringTimeoutTimer?.cancel();
    FlutterCallkitIncoming.endAllCalls(); // কানেক্ট হলে নেটিভ রিংগিং বন্ধ
    _callState = ActiveCallState.connected;
    notifyListeners();

    // In the Agora call session, immediately execute:
    try {
      await _engine?.enableAudio();
      await _engine?.enableLocalAudio(true);
      await _engine?.muteLocalAudioStream(false);
      await _engine?.setEnableSpeakerphone(true);
      _isSpeakerOn = true;
      _isMuted = false;
    } catch (e) {
      debugPrint("[Agora RTC] Audio configuration error on call connected: $e");
    }

    // কথা বলার সময় গণনা টাইমার চালু
    _durationTimer?.cancel();
    _durationTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _callDurationSeconds++;
      notifyListeners();
    });
  }

  /// ৫. ইনকামিং কল রিসিভ করা (Accept Call from CallKit or In-App UI)
  Future<void> acceptIncomingCall([String? channelId, String? currentUserId]) async {
    // Ensure that runtime microphone permission is requested via permission_handler before launching/answering any call
    final micPermission = await Permission.microphone.request();
    if (!micPermission.isGranted) {
      debugPrint("[Agora RTC] Microphone permission not granted on accept: $micPermission");
    }

    FlutterRingtonePlayer().stop();
    _ringTimeoutTimer?.cancel();
    await FlutterCallkitIncoming.endAllCalls();
    await initAgoraEngine();

    // In the Agora call session, immediately execute audio and speakerphone setup
    await _engine?.enableAudio();
    await _engine?.enableLocalAudio(true);
    await _engine?.muteLocalAudioStream(false);
    await _engine?.setEnableSpeakerphone(true);
    _isSpeakerOn = true;
    _isMuted = false;

    final targetChannel = (channelId != null && channelId.isNotEmpty) ? channelId : _currentChannelId;
    final uid = currentUserId ?? _currentUserId;

    _currentChannelId = targetChannel;
    _callState = ActiveCallState.connected;
    notifyListeners();

    // Firestore সেশন স্ট্যাটাস 'accepted' করা
    if (targetChannel.isNotEmpty) {
      await _firestore.collection('call_sessions').doc(targetChannel).update({
        'status': 'accepted',
      });
    }

    await _joinAgoraChannel(targetChannel, uid);
  }

  /// ৬. ইনকামিং কল রিজেক্ট করা (Decline Call)
  Future<void> rejectIncomingCall(String channelId) async {
    FlutterRingtonePlayer().stop();
    _ringTimeoutTimer?.cancel();
    await FlutterCallkitIncoming.endAllCalls();

    if (channelId.isNotEmpty) {
      await _firestore.collection('call_sessions').doc(channelId).update({
        'status': 'rejected',
      });
    }

    _callState = ActiveCallState.idle;
    _currentChannelId = '';
    notifyListeners();
  }

  /// ৭. কল সমাপ্ত করা (Hangup / End)
  Future<void> endCall({CallStatus status = CallStatus.ended, bool isRemote = false}) async {
    FlutterRingtonePlayer().stop();
    _ringTimeoutTimer?.cancel();
    _durationTimer?.cancel();
    _sessionSubscription?.cancel();
    await FlutterCallkitIncoming.endAllCalls();

    if (!isRemote && _currentChannelId.isNotEmpty) {
      await _firestore.collection('call_sessions').doc(_currentChannelId).update({
        'status': 'ended',
      });
    }

    try {
      await _engine?.leaveChannel();
    } catch (_) {}

    _callState = ActiveCallState.ended;
    notifyListeners();

    Future.delayed(const Duration(seconds: 1), () {
      _callState = ActiveCallState.idle;
      _currentChannelId = '';
      _callDurationSeconds = 0;
      notifyListeners();
    });
  }

  /// ৮. ঠিক ৪৫ সেকেন্ড পর একক "Missed Call" লগ ও স্বয়ংক্রিয় বাতিল হ্যান্ডলার
  Future<void> _handleCallTimeout(
    String callerId,
    String recipientId,
    String callerName,
    String recipientName,
  ) async {
    FlutterRingtonePlayer().stop();
    _ringTimeoutTimer?.cancel();
    await FlutterCallkitIncoming.endAllCalls();

    _callState = ActiveCallState.offlinePrompt;
    notifyListeners();

    // ফায়ারবেসে শুধুমাত্র একটি একক "Missed Call" রেকর্ড তৈরি
    final recordId = "missed_${DateTime.now().millisecondsSinceEpoch}_${callerId.substring(0, 4)}";
    final record = CallRecord(
      id: recordId,
      callerId: callerId,
      callerName: callerName,
      callerPhone: '🔒 নম্বর গোপন (ইন্টারনেট অডিও কল)',
      recipientId: recipientId,
      recipientName: recipientName,
      recipientPhone: '🔒 নম্বর গোপন (ইন্টারনেট অডিও কল)',
      timestamp: DateTime.now(),
      status: CallStatus.missed,
      durationSeconds: 0,
      channelId: _currentChannelId,
    );

    // ১টি মাত্র রেকর্ড সেভ করা
    await _firestore.collection('call_records').doc(record.id).set(record.toMap());

    // কল সেশন ডকুমেন্টে missed মার্ক করা যাতে প্রাপক প্রান্তে রিং অটো-ক্লোজ হয়
    if (_currentChannelId.isNotEmpty) {
      await _firestore.collection('call_sessions').doc(_currentChannelId).update({
        'status': 'missed',
      });
    }
  }

  /// ৯. অফলাইন সিম ডায়ালারে রিডাইরেক্ট (Android ACTION_DIAL)
  /// ইউজার ৪৫ সে. অপেক্ষার পর সরাসরি মোবাইল ডায়ালারে যেতে চাইলে
  Future<void> triggerOfflineSimCall() async {
    endCall();
    if (_rawPhoneNumber.isEmpty) return;

    final cleanPhone = _rawPhoneNumber.replaceAll(RegExp(r'[^0-9+]'), '');
    final Uri telUri = Uri.parse('tel:$cleanPhone');

    if (await canLaunchUrl(telUri)) {
      await launchUrl(telUri, mode: LaunchMode.externalApplication);
    } else {
      debugPrint("Cannot launch native phone dialer for $cleanPhone");
    }
  }

  /// মাইক্রোফোন মিউট / আনমিউট টগল
  void toggleMute() {
    _isMuted = !_isMuted;
    _engine?.muteLocalAudioStream(_isMuted);
    notifyListeners();
  }

  /// লাউডস্পিকার অন / অফ টগল
  void toggleSpeaker() {
    _isSpeakerOn = !_isSpeakerOn;
    _engine?.setEnableSpeakerphone(_isSpeakerOn);
    notifyListeners();
  }
}
