import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/call_record_model.dart';

class CallHistoryController extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  List<CallRecord> _allCallRecords = [];
  Map<DateTime, List<GroupedCallLog>> _groupedHistoryByDate = {};
  bool _isLoading = false;

  List<CallRecord> get allCallRecords => _allCallRecords;
  Map<DateTime, List<GroupedCallLog>> get groupedHistoryByDate => _groupedHistoryByDate;
  bool get isLoading => _isLoading;

  /// নির্দিষ্ট ইউজারের কল হিস্ট্রি সিঙ্ক করা
  void initCallHistoryListener(String currentUserId) {
    if (currentUserId.isEmpty) return;

    _isLoading = true;
    notifyListeners();

    _firestore
        .collection('call_records')
        .where(Filter.or(
          Filter('callerId', isEqualTo: currentUserId),
          Filter('recipientId', isEqualTo: currentUserId),
        ))
        .orderBy('timestamp', descending: true)
        .snapshots()
        .listen((snapshot) {
      _allCallRecords = snapshot.docs
          .map((doc) => CallRecord.fromMap(doc.data(), doc.id))
          .toList();

      _processGrouping(currentUserId);
      _isLoading = false;
      notifyListeners();
    }, onError: (err) {
      debugPrint('Call History sync error: $err');
      _isLoading = false;
      notifyListeners();
    });
  }

  /// হোয়াটসঅ্যাপ ও ডায়ালারের মতো গ্রুপিং অ্যালগরিদম
  /// ১. ক্যালেন্ডার ডেট অনুযায়ী বিভাজন (আজকে, গতকাল, নির্দিষ্ট তারিখ)
  /// ২. একদিনের ভেতর একই ইউজারের একাধিক কল/মিসড কলকে একটি সারিতে আনা এবং মোট সংখ্যা ব্র্যাকেটে প্রদর্শন: e.g. Shahina Sarmin (5)
  void _processGrouping(String currentUserId) {
    final Map<DateTime, Map<String, List<CallRecord>>> tempMap = {};

    for (var record in _allCallRecords) {
      // এই কলের অপর প্রান্তের ব্যক্তি (Peer) কে?
      final isOutgoing = record.callerId == currentUserId;
      final peerId = isOutgoing ? record.recipientId : record.callerId;
      final peerName = isOutgoing ? record.recipientName : record.callerName;
      final peerPhone = isOutgoing ? record.recipientPhone : record.callerPhone;
      final peerAvatar = isOutgoing ? null : record.callerAvatar;
      final peerRole = isOutgoing ? null : record.callerRole;

      // শুধুমাত্র তারিখ অংশ নিয়ে গ্রুপ করা (সময় বাদ দিয়ে)
      final callDate = DateTime(
        record.timestamp.year,
        record.timestamp.month,
        record.timestamp.day,
      );

      tempMap.putIfAbsent(callDate, () => {});
      tempMap[callDate]!.putIfAbsent(peerId, () => []);
      tempMap[callDate]![peerId]!.add(record);
    }

    final Map<DateTime, List<GroupedCallLog>> result = {};

    tempMap.forEach((date, peerMap) {
      final List<GroupedCallLog> dailyGroups = [];

      peerMap.forEach((peerId, calls) {
        // সাম্প্রতিক কলটি সবার উপরে
        calls.sort((a, b) => b.timestamp.compareTo(a.timestamp));
        final firstCall = calls.first;
        final isOutgoing = firstCall.callerId == currentUserId;

        final peerName = isOutgoing ? firstCall.recipientName : firstCall.callerName;
        final peerPhone = isOutgoing ? firstCall.recipientPhone : firstCall.callerPhone;
        final maskedPhone = GroupedCallLog.maskPhoneNumber(peerPhone);

        dailyGroups.add(GroupedCallLog(
          peerId: peerId,
          peerName: peerName.isEmpty ? 'অজ্ঞাত ব্যবহারকারী' : peerName,
          peerAvatar: firstCall.callerAvatar,
          peerRole: firstCall.callerRole,
          maskedPhone: maskedPhone,
          dateGroup: date,
          calls: calls,
        ));
      });

      // দিনের মধ্যে সর্বশেষ কল অনুযায়ী সর্ট করা
      dailyGroups.sort((a, b) => b.latestCall.timestamp.compareTo(a.latestCall.timestamp));
      result[date] = dailyGroups;
    });

    _groupedHistoryByDate = result;
  }

  /// নতুন কল হিস্ট্রি রেকর্ড সেভ করা
  Future<void> logCallRecord(CallRecord record) async {
    try {
      await _firestore.collection('call_records').doc(record.id).set(record.toMap());
    } catch (e) {
      debugPrint('Failed to save call record: $e');
    }
  }

  /// মিসড কল ব্যাক সম্পন্ন হিসেবে মার্ক করা
  Future<void> markCallbackDone(String recordId) async {
    try {
      await _firestore.collection('call_records').doc(recordId).update({
        'isCallbackDone': true,
      });
    } catch (e) {
      debugPrint('Failed to mark callback done: $e');
    }
  }
}
