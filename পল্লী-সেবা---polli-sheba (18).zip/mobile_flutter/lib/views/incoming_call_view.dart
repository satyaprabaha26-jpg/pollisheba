import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/agora_voice_call_controller.dart';
import '../models/call_record_model.dart';

class IncomingCallView extends StatefulWidget {
  final String currentUserId;

  const IncomingCallView({
    Key? key,
    required this.currentUserId,
  }) : super(key: key);

  @override
  State<IncomingCallView> createState() => _IncomingCallViewState();
}

class _IncomingCallViewState extends State<IncomingCallView> with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.18).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final callCtrl = context.watch<AgoraVoiceCallController>();

    if (callCtrl.callState == ActiveCallState.idle) {
      return const SizedBox.shrink();
    }

    final isOfflinePrompt = callCtrl.callState == ActiveCallState.offlinePrompt;
    final isConnected = callCtrl.callState == ActiveCallState.connected;
    final isDialing = callCtrl.callState == ActiveCallState.dialing;
    final isRinging = callCtrl.callState == ActiveCallState.ringing;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0F2610), // গাঢ় অলিভ গ্রীন (WhatsApp/Imo কল গ্র্যাডিয়েন্ট)
              Color(0xFF1E3A1A),
              Color(0xFF0D1D0E),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // ১. টপ বার ও ১০০% গোপনীয়তা সুরক্ষা ব্যাজ (End-to-End Private VOIP)
                Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFFD4E4BC).withOpacity(0.3)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.shield_outlined, size: 14, color: Color(0xFFD4E4BC)),
                          SizedBox(width: 6),
                          Text(
                            '🔒 সুরক্ষিত ইন্টারনেট অডিও কল • মোবাইল নম্বর ১০০% গোপন',
                            style: TextStyle(
                              color: Color(0xFFD4E4BC),
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),

                    // স্ট্যাটাস ও টাইমার
                    Text(
                      isConnected
                          ? 'কথা বলছেন • ${GroupedCallLog.formatDuration(callCtrl.callDurationSeconds)}'
                          : (isOfflinePrompt
                              ? '⏳ প্রাপক ইন্টারনেটে উত্তর দেননি (৪৫ সেকেন্ড সমাপ্ত)'
                              : (isDialing ? 'কল দেওয়া হচ্ছে (Dialing)...' : '🔔 রিং হচ্ছে (৪৫ সে. স্বয়ংক্রিয় সময়)...')),
                      style: TextStyle(
                        color: isOfflinePrompt
                            ? const Color(0xFFE8924A)
                            : (isConnected ? const Color(0xFF7DDA58) : Colors.white70),
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),

                // ২. সেন্ট্রাল কলার প্রোফাইল ও পালসিং রিং অ্যানিমেশন
                Column(
                  children: [
                    ScaleTransition(
                      scale: (isRinging || isDialing) ? _pulseAnimation : const AlwaysStoppedAnimation(1.0),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isConnected
                                ? const Color(0xFF27AE60)
                                : const Color(0xFFD4E4BC).withOpacity(0.5),
                            width: 3,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: isConnected
                                  ? const Color(0xFF27AE60).withOpacity(0.4)
                                  : const Color(0xFF2D5A27).withOpacity(0.6),
                              blurRadius: 28,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                        child: CircleAvatar(
                          radius: 58,
                          backgroundColor: const Color(0xFF2D5A27),
                          backgroundImage: callCtrl.peerAvatar != null && callCtrl.peerAvatar!.isNotEmpty
                              ? NetworkImage(callCtrl.peerAvatar!)
                              : null,
                          child: (callCtrl.peerAvatar == null || callCtrl.peerAvatar!.isEmpty)
                              ? Text(
                                  callCtrl.peerName.isNotEmpty ? callCtrl.peerName.substring(0, 1) : 'U',
                                  style: const TextStyle(
                                    fontSize: 44,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                )
                              : null,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // নাম (প্রাপক বা কলার)
                    Text(
                      callCtrl.peerName.isNotEmpty ? callCtrl.peerName : 'পল্লী নাগরিক',
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        letterSpacing: 0.3,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),

                    // রোল ব্যাজ (যেমন: কৃষক, সিএনজি চালক, ডাক্তার)
                    if (callCtrl.peerRole != null && callCtrl.peerRole!.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFD4E4BC).withOpacity(0.25),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFD4E4BC).withOpacity(0.5)),
                        ),
                        child: Text(
                          callCtrl.peerRole!,
                          style: const TextStyle(
                            color: Color(0xFFD4E4BC),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),

                    const SizedBox(height: 10),
                    const Text(
                      'উভয় পক্ষের ব্যক্তিগত মোবাইল নম্বর সম্পূর্ণ গোপন রাখা হয়েছে',
                      style: TextStyle(color: Colors.white54, fontSize: 10.5),
                    ),
                  ],
                ),

                // ৩. অ্যাকশন বাটনস (WhatsApp / Imo স্টাইলের অ্যাকসেপ্ট ও ডিক্লাইন বাটন)
                if (isOfflinePrompt) ...[
                  // ৪৫ সেকেন্ড রিংয়ের পর ফলব্যাক অপশন
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.white.withOpacity(0.15)),
                    ),
                    child: Column(
                      children: [
                        const Text(
                          'প্রাপক ৪৫ সেকেন্ডে ইন্টারনেটে কল ধরেননি। আপনি কি সরাসরি মোবাইল সিমে কল দিতে চান?',
                          style: TextStyle(color: Colors.white, fontSize: 13, height: 1.4),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFE8924A),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            elevation: 4,
                          ),
                          icon: const Icon(Icons.phone_forwarded, size: 18),
                          label: const Text(
                            'সরাসরি মোবাইল সিম ডায়ালারে যান',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                          onPressed: () {
                            callCtrl.triggerOfflineSimCall();
                          },
                        ),
                        const SizedBox(height: 10),
                        TextButton(
                          child: const Text('বন্ধ করুন', style: TextStyle(color: Colors.white70, fontSize: 12)),
                          onPressed: () => callCtrl.endCall(),
                        ),
                      ],
                    ),
                  ),
                ] else if (isConnected) ...[
                  // কানেক্টেড অবস্থায় মিউট, লাউডস্পিকার ও কল কাটার বাটন
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // মিউট বাটন
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              iconSize: 32,
                              icon: Icon(
                                callCtrl.isMuted ? Icons.mic_off : Icons.mic,
                                color: callCtrl.isMuted ? Colors.redAccent : Colors.white,
                              ),
                              onPressed: () => callCtrl.toggleMute(),
                            ),
                            Text(
                              callCtrl.isMuted ? 'আনমিউট' : 'মিউট',
                              style: const TextStyle(color: Colors.white70, fontSize: 11),
                            ),
                          ],
                        ),

                        // লাল রঙের হ্যাং-আপ বাটন
                        FloatingActionButton(
                          heroTag: 'end_call_active',
                          backgroundColor: Colors.red,
                          elevation: 6,
                          child: const Icon(Icons.call_end, color: Colors.white, size: 28),
                          onPressed: () => callCtrl.endCall(status: CallStatus.ended),
                        ),

                        // স্পিকার বাটন
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              iconSize: 32,
                              icon: Icon(
                                callCtrl.isSpeakerOn ? Icons.volume_up : Icons.volume_down,
                                color: callCtrl.isSpeakerOn ? const Color(0xFF7DDA58) : Colors.white,
                              ),
                              onPressed: () => callCtrl.toggleSpeaker(),
                            ),
                            Text(
                              callCtrl.isSpeakerOn ? 'স্পিকার অন' : 'স্পিকার অফ',
                              style: const TextStyle(color: Colors.white70, fontSize: 11),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ] else ...[
                  // ইনকামিং / আউটগোয়িং রিং হচ্ছে: সবুজ এক্সেপ্ট ও লাল ক্যানসেল বাটন
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        // বাতিল বাটন (লাল)
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            FloatingActionButton(
                              heroTag: 'reject_call_btn',
                              backgroundColor: Colors.red.shade600,
                              elevation: 6,
                              child: const Icon(Icons.call_end, color: Colors.white, size: 28),
                              onPressed: () {
                                if (isDialing) {
                                  callCtrl.endCall(status: CallStatus.ended);
                                } else {
                                  callCtrl.rejectIncomingCall(callCtrl.currentChannelId);
                                }
                              },
                            ),
                            const SizedBox(height: 8),
                            const Text('বাতিল', style: TextStyle(color: Colors.white70, fontSize: 12)),
                          ],
                        ),

                        // গ্রহণ বাটন (সবুজ - শুধুমাত্র ইনকামিং রিং হলে শো করবে)
                        if (!isDialing)
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              FloatingActionButton(
                                heroTag: 'accept_call_btn',
                                backgroundColor: const Color(0xFF27AE60),
                                elevation: 6,
                                child: const Icon(Icons.call, color: Colors.white, size: 28),
                                onPressed: () {
                                  callCtrl.acceptIncomingCall(callCtrl.currentChannelId, widget.currentUserId);
                                },
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                'গ্রহণ করুন',
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
                              ),
                            ],
                          ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
