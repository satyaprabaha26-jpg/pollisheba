import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/call_history_controller.dart';
import '../controllers/agora_voice_call_controller.dart';
import '../controllers/auth_controller.dart';
import '../models/call_record_model.dart';

class CallHistoryView extends StatelessWidget {
  final String currentUserId;
  final String currentUserName;

  const CallHistoryView({
    Key? key,
    required this.currentUserId,
    required this.currentUserName,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<CallHistoryController>();
    final callVoiceCtrl = context.read<AgoraVoiceCallController>();

    if (controller.isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFF2D5A27)),
      );
    }

    if (controller.groupedHistoryByDate.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFD4E4BC).withOpacity(0.5),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.phone_missed, size: 40, color: Color(0xFF2D5A27)),
            ),
            const SizedBox(height: 12),
            const Text(
              'কোনো পূর্ববর্তী কল হিস্ট্রি নেই',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF2D3A3A)),
            ),
            const SizedBox(height: 4),
            const Text(
              'আপনার ইনকামিং ও আউটগোয়িং কল এখানে জমা থাকবে',
              style: TextStyle(fontSize: 12, color: Color(0xFF736B5E)),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      itemCount: controller.groupedHistoryByDate.keys.length,
      itemBuilder: (context, index) {
        final date = controller.groupedHistoryByDate.keys.elementAt(index);
        final dailyGroups = controller.groupedHistoryByDate[date]!;
        final dateHeader = GroupedCallLog.getBengaliDateHeader(date);

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ডেট সেপারেটর হেডার (যেমন: "আজকে", "গতকাল", "২৬ সেপ্টেম্বর ২০২৬")
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFFAF8F5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFE6E0D4)),
                ),
                child: Text(
                  dateHeader,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2D5A27),
                  ),
                ),
              ),
            ),

            // সেই দিনের গ্রুপ করা কল তালিকা (WhatsApp / Dialer Style)
            ...dailyGroups.map((group) {
              final isMissed = group.hasMissedCall;

              return Card(
                elevation: 0.5,
                margin: const EdgeInsets.symmetric(vertical: 3),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: BorderSide(
                    color: isMissed ? Colors.red.shade100 : const Color(0xFFE6E0D4),
                  ),
                ),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  onTap: () {
                    // ঐ সারিতে ক্লিক করলে বিস্তারিত কলের ইতিহাস পপ-আপ করা
                    _showDetailedCallListModal(context, group);
                  },
                  leading: CircleAvatar(
                    radius: 22,
                    backgroundColor: isMissed ? Colors.red.shade50 : const Color(0xFFD4E4BC),
                    backgroundImage: group.peerAvatar != null ? NetworkImage(group.peerAvatar!) : null,
                    child: group.peerAvatar == null
                        ? Text(
                            group.peerName.isNotEmpty ? group.peerName.substring(0, 1) : 'U',
                            style: TextStyle(
                              color: isMissed ? Colors.red.shade700 : const Color(0xFF2D5A27),
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          )
                        : null,
                  ),
                  title: Row(
                    children: [
                      Expanded(
                        child: Text(
                          // হোয়াটসঅ্যাপের মতো একই ইউজারের একাধিক কল ব্র্যাকেটে প্রদর্শন: Shahina Sarmin (5)
                          group.displayNameWithCount,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            color: isMissed ? Colors.red.shade800 : const Color(0xFF2D3A3A),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (group.peerRole != null)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFF2D5A27).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            group.peerRole!,
                            style: const TextStyle(fontSize: 10, color: Color(0xFF2D5A27), fontWeight: FontWeight.bold),
                          ),
                        ),
                    ],
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Row(
                      children: [
                        Icon(
                          isMissed
                              ? Icons.call_missed
                              : (group.latestCall.status == CallStatus.outgoing
                                  ? Icons.call_made
                                  : Icons.call_received),
                          size: 14,
                          color: isMissed ? Colors.red : Colors.green.shade700,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          isMissed ? 'মিসড কল' : (group.latestCall.status == CallStatus.outgoing ? 'আউটগোয়িং' : 'ইনকামিং'),
                          style: TextStyle(
                            fontSize: 11,
                            color: isMissed ? Colors.red.shade700 : const Color(0xFF736B5E),
                            fontWeight: isMissed ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '• ${group.formattedLatestTime}',
                          style: const TextStyle(fontSize: 11, color: Color(0xFF736B5E)),
                        ),
                      ],
                    ),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // সরাসরি ফ্রি অডিও কল বাটন
                      IconButton(
                        icon: const Icon(Icons.phone, color: Color(0xFF2D5A27), size: 22),
                        tooltip: 'ফ্রি ইন-অ্যাপ অডিও কল',
                        onPressed: () {
                          callVoiceCtrl.startVoiceCall(
                            currentUserId: currentUserId,
                            currentUserName: currentUserName,
                            targetUserId: group.peerId,
                            targetUserName: group.peerName,
                            targetUserAvatar: group.peerAvatar,
                            targetUserRole: group.peerRole,
                            targetRawPhone: group.latestCall.recipientPhone,
                          );
                        },
                      ),
                      // সরাসরি অফলাইন সিম ডায়াল বাটন
                      IconButton(
                        icon: const Icon(Icons.dialer_sip, color: Color(0xFFE8924A), size: 20),
                        tooltip: 'অফলাইন মোবাইল কল (ACTION_DIAL)',
                        onPressed: () {
                          AuthController.launchNativeDialer(group.latestCall.recipientPhone);
                        },
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ],
        );
      },
    );
  }

  /// ঐ নোটিফিকেশন বা সারিতে ক্লিক করলে তারিখ ও সময় অনুযায়ী বিস্তারিত কলের তালিকা
  void _showDetailedCallListModal(BuildContext context, GroupedCallLog group) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      backgroundColor: Colors.white,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // হেডার
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        group.peerName,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF2D3A3A)),
                      ),
                      Text(
                        'ফোন: ${group.maskedPhone} (সুরক্ষিত)',
                        style: const TextStyle(fontSize: 12, color: Color(0xFF736B5E)),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFD4E4BC),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'মোট কল: ${group.callCount} টি',
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF2D5A27)),
                    ),
                  )
                ],
              ),
              const Divider(height: 24),

              // প্রতিটি কলের সুনির্দিষ্ট সময় ও বিবরণ তালিকা
              Flexible(
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: group.calls.length,
                  separatorBuilder: (_, __) => const Divider(height: 12),
                  itemBuilder: (context, idx) {
                    final call = group.calls[idx];
                    final isMissed = call.status == CallStatus.missed;

                    return Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Icon(
                              isMissed
                                  ? Icons.call_missed
                                  : (call.status == CallStatus.outgoing ? Icons.call_made : Icons.call_received),
                              size: 16,
                              color: isMissed ? Colors.red : Colors.green.shade700,
                            ),
                            const SizedBox(width: 8),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  isMissed ? 'মিসড কল' : (call.status == CallStatus.outgoing ? 'আউটগোয়িং কল' : 'ইনকামিং কল'),
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: isMissed ? Colors.red.shade700 : const Color(0xFF2D3A3A),
                                  ),
                                ),
                                Text(
                                  'কথা বলা: ${GroupedCallLog.formatDuration(call.durationSeconds)}',
                                  style: const TextStyle(fontSize: 11, color: Color(0xFF736B5E)),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Text(
                          '${call.timestamp.hour}:${call.timestamp.minute.toString().padLeft(2, '0')}',
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF2D3A3A)),
                        ),
                      ],
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }
}
