import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/notification_controller.dart';
import '../controllers/agora_voice_call_controller.dart';
import '../controllers/chat_controller.dart';
import '../models/notification_model.dart';

class NotificationListView extends StatefulWidget {
  final String currentUserId;
  final String currentUserName;

  const NotificationListView({
    Key? key,
    required this.currentUserId,
    required this.currentUserName,
  }) : super(key: key);

  @override
  State<NotificationListView> createState() => _NotificationListViewState();
}

class _NotificationListViewState extends State<NotificationListView> {
  @override
  void initState() {
    super.initState();
    // ব্যবহারকারী নোটিফিকেশন লিস্ট ওপেন করা মাত্রই প্রোফাইলের বিজ্ঞপ্তির সংখ্যা (Unread Badge Count) ০ (শূন্য) করা
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<NotificationController>().markAllNotificationsAsRead();
    });
  }

  @override
  Widget build(BuildContext context) {
    final notifCtrl = context.watch<NotificationController>();
    final callVoiceCtrl = context.read<AgoraVoiceCallController>();
    final chatCtrl = context.read<ChatController>();

    if (notifCtrl.isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFF2D5A27)),
      );
    }

    if (notifCtrl.notifications.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                color: Color(0xFFFAF8F5),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.notifications_none, size: 40, color: Color(0xFF736B5E)),
            ),
            const SizedBox(height: 12),
            const Text(
              'বর্তমানে কোনো নতুন বিজ্ঞপ্তি নেই',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF2D3A3A)),
            ),
            const SizedBox(height: 4),
            const Text(
              'আপনার এলাকার জরুরি হাট ও সেবা বিজ্ঞপ্তি এখানে আসবে',
              style: TextStyle(fontSize: 12, color: Color(0xFF736B5E)),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      itemCount: notifCtrl.notifications.length,
      itemBuilder: (context, index) {
        final notif = notifCtrl.notifications[index];
        final isUrgent = notif.urgency == NotificationUrgency.urgent;

        return Card(
          elevation: notif.isRead ? 0.5 : 2,
          margin: const EdgeInsets.symmetric(vertical: 4),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(
              color: isUrgent
                  ? Colors.red.shade200
                  : (notif.isRead ? const Color(0xFFE6E0D4) : const Color(0xFF2D5A27).withOpacity(0.4)),
              width: notif.isRead ? 1 : 1.5,
            ),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () {
              // নোটিফিকেশনে ক্লিক করলে সরাসরি নির্দিষ্ট বিজ্ঞাপন বা প্রোডাক্ট পেজে নিয়ে যাওয়া (Deep Linking)
              notifCtrl.handleNotificationTap(context, notif);
            },
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // টাইটেল এবং জরুরি ব্যাজ
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          notif.title,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: notif.isRead ? FontWeight.w600 : FontWeight.bold,
                            color: const Color(0xFF2D3A3A),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (isUrgent)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.red.shade600,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Text(
                            'জরুরি',
                            style: TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.bold),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 6),

                  // বার্তা বিবরণ
                  Text(
                    notif.message,
                    style: const TextStyle(fontSize: 12, color: Color(0xFF5A6B6B), height: 1.3),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 10),

                  // প্রেরকের নাম ও লোকেশন
                  Row(
                    children: [
                      const Icon(Icons.location_on, size: 12, color: Color(0xFF2D5A27)),
                      const SizedBox(width: 4),
                      Text(
                        '${notif.targetUpazila}, ${notif.targetDistrict}',
                        style: const TextStyle(fontSize: 11, color: Color(0xFF736B5E)),
                      ),
                      const Spacer(),
                      Text(
                        notif.senderName,
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF2D3A3A)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),

                  const Divider(height: 12),

                  // ৪. নোটিফিকেশন কার্ডের ভেতর 'ফ্রি কল', 'ভয়েস' এবং 'মেসেজ/চ্যাট' বাটন
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      // সরাসরি টেক্সট চ্যাট বাটন
                      OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          side: const BorderSide(color: Color(0xFF2D5A27)),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        icon: const Icon(Icons.chat_bubble_outline, size: 14, color: Color(0xFF2D5A27)),
                        label: const Text(
                          'মেসেজ / চ্যাট',
                          style: TextStyle(fontSize: 11, color: Color(0xFF2D5A27), fontWeight: FontWeight.bold),
                        ),
                        onPressed: () {
                          // সরাসরি চ্যাট ওপেন করা
                          chatCtrl.openConversation(
                            currentUserId: widget.currentUserId,
                            targetUserId: notif.senderPhone ?? notif.id,
                            itemId: notif.itemId,
                          );
                          Navigator.of(context).pushNamed('/chat', arguments: {
                            'targetName': notif.senderName,
                            'targetId': notif.senderPhone ?? notif.id,
                            'itemId': notif.itemId,
                          });
                        },
                      ),
                      const SizedBox(width: 8),

                      // ফ্রি ভয়েস কল বাটন
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2D5A27),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        icon: const Icon(Icons.phone, size: 14),
                        label: const Text(
                          'ফ্রি কল',
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                        ),
                        onPressed: () {
                          callVoiceCtrl.startVoiceCall(
                            currentUserId: widget.currentUserId,
                            currentUserName: widget.currentUserName,
                            targetUserId: notif.senderPhone ?? notif.id,
                            targetUserName: notif.senderName,
                            targetUserAvatar: notif.senderAvatar,
                            targetUserRole: notif.targetRole,
                            targetRawPhone: notif.senderPhone ?? '',
                          );
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
