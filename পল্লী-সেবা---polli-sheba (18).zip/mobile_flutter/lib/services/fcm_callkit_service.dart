import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_callkit_incoming/flutter_callkit_incoming.dart';
import 'package:flutter_callkit_incoming/entities/entities.dart';

/// ব্যাকগ্রাউন্ড ও স্ক্রিন অফ অবস্থায় এফসিএম হাই-প্রায়োরিটি কল হ্যান্ডলার
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  debugPrint("[FCM Background] Data payload received: ${message.data}");

  final data = message.data;
  final type = data['type'];

  if (type == 'incoming_call') {
    final channelId = data['channelId'] ?? '';
    final callerName = data['callerName'] ?? 'পল্লী নাগরিক';
    final callerAvatar = data['callerAvatar'];
    final callerRole = data['callerRole'] ?? 'পল্লী সেবা অডিও কল';
    final callerId = data['callerId'] ?? '';

    // WhatsApp / Imo এর মতো ফুল-স্ক্রিন ইনকামিং কলকিট ডিসপ্লে
    await FCMCallKitService.showNativeCallKit(
      channelId: channelId,
      callerId: callerId,
      callerName: callerName,
      callerAvatar: callerAvatar,
      callerRole: callerRole,
    );
  } else if (type == 'cancel_call') {
    debugPrint("[FCM Background] Incoming call cancelled by remote or timed out.");
    await FlutterCallkitIncoming.endAllCalls();
  }
}

class FCMCallKitService {
  static final FCMCallKitService _instance = FCMCallKitService._internal();
  factory FCMCallKitService() => _instance;
  FCMCallKitService._internal();

  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  StreamSubscription? _callKitSubscription;

  Function(String channelId, String callerId)? _onAcceptCall;
  Function(String channelId)? _onDeclineCall;

  /// ১. সার্ভিস ইনিশিয়ালাইজেশন এবং কলকিট ইভেন্ট লিসেনার সেটআপ
  Future<void> initialize({
    required Function(String channelId, String callerId) onAcceptCall,
    required Function(String channelId) onDeclineCall,
  }) async {
    _onAcceptCall = onAcceptCall;
    _onDeclineCall = onDeclineCall;

    // হাই-প্রায়োরিটি নোটিফিকেশন পারমিশন রিকোয়েস্ট
    final settings = await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      announcement: true,
      criticalAlert: true,
    );
    debugPrint("[FCM] Permission status: ${settings.authorizationStatus}");

    // ফোরগ্রাউন্ড পুশ মেসেজ লিসেনার
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      debugPrint("[FCM Foreground] Message received: ${message.data}");
      final data = message.data;
      if (data['type'] == 'incoming_call') {
        showNativeCallKit(
          channelId: data['channelId'] ?? '',
          callerId: data['callerId'] ?? '',
          callerName: data['callerName'] ?? 'পল্লী নাগরিক',
          callerAvatar: data['callerAvatar'],
          callerRole: data['callerRole'] ?? 'পল্লী সেবা অডিও কল',
        );
      } else if (data['type'] == 'cancel_call') {
        FlutterCallkitIncoming.endAllCalls();
      }
    });

    // কলকিট ইউআই বাটন ইভেন্ট লিসেনার (Accept / Decline / Timeout)
    _callKitSubscription?.cancel();
    _callKitSubscription = FlutterCallkitIncoming.onEvent.listen((CallEvent? event) {
      if (event == null) return;
      debugPrint("[CallKit Event] Action: ${event.event}");

      final extra = event.body['extra'] ?? {};
      final channelId = (extra['channelId'] ?? event.body['id'] ?? '').toString();
      final callerId = (extra['callerId'] ?? '').toString();

      switch (event.event) {
        case Event.actionCallAccept:
          debugPrint("[CallKit] Call accepted via native screen for channel: $channelId");
          if (_onAcceptCall != null && channelId.isNotEmpty) {
            _onAcceptCall!(channelId, callerId);
          }
          break;

        case Event.actionCallDecline:
          debugPrint("[CallKit] Call declined via native screen for channel: $channelId");
          if (_onDeclineCall != null && channelId.isNotEmpty) {
            _onDeclineCall!(channelId);
          }
          FlutterCallkitIncoming.endAllCalls();
          break;

        case Event.actionCallEnded:
        case Event.actionCallTimeout:
          debugPrint("[CallKit] Call ended or timed out.");
          FlutterCallkitIncoming.endAllCalls();
          break;

        default:
          break;
      }
    });
  }

  /// ২. ফুল-স্ক্রিন রিংগিং ইউআই এবং রিংটোন প্রদর্শন (WhatsApp / Imo এর মতো ৪৫ সেকেন্ড রিংটাইম)
  static Future<void> showNativeCallKit({
    required String channelId,
    required String callerId,
    required String callerName,
    String? callerAvatar,
    String? callerRole,
  }) async {
    final CallKitParams params = CallKitParams(
      id: channelId,
      nameCaller: callerName,
      appName: 'পল্লী সেবা (Polli Sheba)',
      avatar: callerAvatar ?? '',
      handle: callerRole ?? 'সুরক্ষিত ইন্টারনেট অডিও কল',
      type: 0, // 0 = Audio Call, 1 = Video Call
      duration: 45000, // ঠিক ৪৫ সেকেন্ড রিং হবে (45 seconds exact ring window)
      textAccept: 'গ্রহণ করুন',
      textDecline: 'বাতিল',
      missedCallNotification: const NotificationParams(
        showNotification: false, // তাৎক্ষণিক মিসড কল শো না করা (৪৫ সে. পর রেকর্ড হবে)
        isShowCallback: false,
      ),
      extra: <String, dynamic>{
        'channelId': channelId,
        'callerId': callerId,
        'callerName': callerName,
        'role': callerRole,
      },
      headers: <String, dynamic>{
        'apiKey': 'polli_callkit',
      },
      android: const AndroidParams(
        isCustomNotification: true,
        isShowLogo: false,
        ringtonePath: 'system_ringtone_default',
        backgroundColor: '#1E3A1A',
        backgroundUrl: 'assets/images/call_bg.png',
        actionColor: '#27AE60',
        textColor: '#FFFFFF',
        incomingCallNotificationChannelName: 'পল্লী সেবা ইনকামিং কল',
        missedCallNotificationChannelName: 'পল্লী সেবা মিসড কল',
        isShowCallID: false, // ফোন নম্বর গোপন রাখা (VOIP Internet UID Only)
      ),
      ios: const IOSParams(
        iconName: 'CallKitLogo',
        handleType: 'generic',
        supportsVideo: false,
        maximumCallGroups: 1,
        maximumCallsPerCallGroup: 1,
        audioSessionMode: 'voiceChat',
        audioSessionActive: true,
        audioSessionPreferredSampleRate: 44100.0,
        audioSessionPreferredIOBufferDuration: 0.005,
        supportsDTMF: false,
        supportsHolding: false,
        supportsGrouping: false,
        supportsUngrouping: false,
        ringtonePath: 'system_ringtone_default',
      ),
    );

    await FlutterCallkitIncoming.showCallkitIncoming(params);
  }

  /// ৩. সকল কলকিট স্ক্রিন তাৎক্ষণিক বন্ধ করা
  static Future<void> endAllCalls() async {
    await FlutterCallkitIncoming.endAllCalls();
  }

  /// ৪. ইউজারের বর্তমান এফসিএম টোকেন গ্রহণ
  Future<String?> getDeviceFCMToken() async {
    try {
      return await _fcm.getToken();
    } catch (e) {
      debugPrint("Error fetching FCM Token: $e");
      return null;
    }
  }
}
