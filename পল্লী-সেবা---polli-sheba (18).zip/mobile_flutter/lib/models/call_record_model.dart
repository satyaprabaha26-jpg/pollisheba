import 'package:intl/intl.dart';

enum CallStatus {
  incoming,
  outgoing,
  missed,
  rejected,
  ended,
}

/// একক কল রেকর্ডের মডেল
class CallRecord {
  final String id;
  final String callerId;
  final String callerName;
  final String? callerAvatar;
  final String? callerRole; // e.g., 'ড্রাইভার', 'মেকানিক', 'কৃষক'
  final String callerPhone; // সংরক্ষিত কিন্তু UI-তে মাস্ক করা
  final String recipientId;
  final String recipientName;
  final String recipientPhone;
  final DateTime timestamp;
  final CallStatus status;
  final int durationSeconds; // কথা বলার সময় (সেকেন্ড)
  final String channelId;

  CallRecord({
    required this.id,
    required this.callerId,
    required this.callerName,
    this.callerAvatar,
    this.callerRole,
    required this.callerPhone,
    required this.recipientId,
    required this.recipientName,
    required this.recipientPhone,
    required this.timestamp,
    required this.status,
    this.durationSeconds = 0,
    required this.channelId,
  });

  factory CallRecord.fromMap(Map<String, dynamic> map, String docId) {
    return CallRecord(
      id: docId,
      callerId: map['callerId'] ?? '',
      callerName: map['callerName'] ?? 'অজ্ঞাত নাগরিক',
      callerAvatar: map['callerAvatar'],
      callerRole: map['callerRole'],
      callerPhone: map['callerPhone'] ?? '',
      recipientId: map['recipientId'] ?? '',
      recipientName: map['recipientName'] ?? '',
      recipientPhone: map['recipientPhone'] ?? '',
      timestamp: map['timestamp'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['timestamp']) 
          : DateTime.now(),
      status: _parseStatus(map['status']),
      durationSeconds: map['durationSeconds'] ?? 0,
      channelId: map['channelId'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'callerId': callerId,
      'callerName': callerName,
      'callerAvatar': callerAvatar,
      'callerRole': callerRole,
      'callerPhone': callerPhone,
      'recipientId': recipientId,
      'recipientName': recipientName,
      'recipientPhone': recipientPhone,
      'timestamp': timestamp.millisecondsSinceEpoch,
      'status': status.name,
      'durationSeconds': durationSeconds,
      'channelId': channelId,
    };
  }

  static CallStatus _parseStatus(dynamic val) {
    if (val == 'missed') return CallStatus.missed;
    if (val == 'outgoing') return CallStatus.outgoing;
    if (val == 'rejected') return CallStatus.rejected;
    if (val == 'ended') return CallStatus.ended;
    return CallStatus.incoming;
  }
}

/// একদিনের মধ্যে একই ইউজারের একাধিক কলের গ্রুপ মডেল (WhatsApp / SIM Style)
class GroupedCallLog {
  final String peerId;
  final String peerName;
  final String? peerAvatar;
  final String? peerRole;
  final String maskedPhone;
  final DateTime dateGroup; // শুধুমাত্র দিন ভিত্তিক (Year-Month-Day)
  final List<CallRecord> calls; // সেই দিনের সব কল

  GroupedCallLog({
    required this.peerId,
    required this.peerName,
    this.peerAvatar,
    this.peerRole,
    required this.maskedPhone,
    required this.dateGroup,
    required this.calls,
  });

  /// মোট কলের সংখ্যা
  int get callCount => calls.length;

  /// সর্বশেষ কল
  CallRecord get latestCall => calls.first;

  /// সবকল কি মিসড কল ছিল কিনা
  bool get hasMissedCall => calls.any((c) => c.status == CallStatus.missed);

  /// ডিসপ্লে নাম যেমন: "Shahina Sarmin (5)"
  String get displayNameWithCount {
    if (callCount > 1) {
      return '$peerName ($callCount)';
    }
    return peerName;
  }

  /// দিন অনুযায়ী বাংলা হেডার (যেমন: "আজকে", "গতকাল", "২৬ সেপ্টেম্বর ২০২৬")
  static String getBengaliDateHeader(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final checkDate = DateTime(date.year, date.month, date.day);

    if (checkDate == today) {
      return 'আজকে';
    } else if (checkDate == yesterday) {
      return 'গতকাল';
    } else {
      return DateFormat('d MMMM yyyy', 'bn').format(date);
    }
  }

  /// কলের সময় বাংলা ফরম্যাট (যেমন: "১০:৪৫ মিনিট")
  String get formattedLatestTime {
    return DateFormat('hh:mm a', 'bn').format(latestCall.timestamp);
  }

  /// কথা বলার সময় ফরম্যাট (যেমন: "২ মিনিট ৩৫ সে.")
  static String formatDuration(int totalSeconds) {
    if (totalSeconds <= 0) return '০ সে.';
    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;
    if (minutes > 0) {
      return '$minutes মিনিট $seconds সে.';
    }
    return '$seconds সে.';
  }

  /// ফোন নম্বর সুরক্ষিতভাবে মাস্ক করা (প্রথম ৫ এবং শেষ ২ ডিজিট রেখে মাঝের ডিজিট গোপন)
  static String maskPhoneNumber(String phone) {
    final clean = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (clean.length < 8) return clean;
    final start = clean.substring(0, clean.startsWith('+880') ? 7 : 5);
    final end = clean.substring(clean.length - 2);
    return '$start****$end';
  }
}
