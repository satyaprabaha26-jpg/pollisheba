import 'package:flutter/material.dart';

enum NotificationUrgency {
  urgent,    // 'জরুরি'
  normal,    // 'সাধারণ'
  alert,     // 'সতর্কবার্তা'
}

class PolliNotification {
  final String id;
  final String title;
  final String message;
  final NotificationUrgency urgency;
  final String targetDistrict;
  final String targetUpazila;
  final String? targetUnion;
  final String targetRole;
  final String senderName;
  final String? senderPhone;
  final String? senderAvatar;
  final String? itemId;            // সুনির্দিষ্ট পণ্য, ড্রাইভার বা শ্রমিকের আইডি
  final String? targetCategory;    // e.g., 'marketplace', 'transport', 'health', 'tutor'
  final String? targetSubTab;      // e.g., 'products', 'labor', 'drivers', 'blood'
  final String? actionUrl;         // deep link URL
  final DateTime createdAt;
  final DateTime? expiresAt;
  bool isRead;

  PolliNotification({
    required this.id,
    required this.title,
    required this.message,
    required this.urgency,
    required this.targetDistrict,
    required this.targetUpazila,
    this.targetUnion,
    required this.targetRole,
    required this.senderName,
    this.senderPhone,
    this.senderAvatar,
    this.itemId,
    this.targetCategory,
    this.targetSubTab,
    this.actionUrl,
    required this.createdAt,
    this.expiresAt,
    this.isRead = false,
  });

  factory PolliNotification.fromMap(Map<String, dynamic> map, String docId) {
    return PolliNotification(
      id: docId,
      title: map['title'] ?? 'পল্লী সেবা নোটিফিকেশন',
      message: map['message'] ?? '',
      urgency: _parseUrgency(map['urgency']),
      targetDistrict: map['targetDistrict'] ?? 'সকল জেলা',
      targetUpazila: map['targetUpazila'] ?? 'সকল উপজেলা',
      targetUnion: map['targetUnion'],
      targetRole: map['targetRole'] ?? 'all',
      senderName: map['senderName'] ?? 'পল্লী সেবা',
      senderPhone: map['senderPhone'] ?? map['contactNumber'],
      senderAvatar: map['senderAvatar'],
      itemId: map['itemId'],
      targetCategory: map['targetCategory'],
      targetSubTab: map['targetSubTab'],
      actionUrl: map['actionUrl'],
      createdAt: map['createdAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['createdAt'])
          : DateTime.now(),
      expiresAt: map['expiresAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['expiresAt'])
          : null,
      isRead: map['isRead'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'message': message,
      'urgency': urgency.name,
      'targetDistrict': targetDistrict,
      'targetUpazila': targetUpazila,
      'targetUnion': targetUnion,
      'targetRole': targetRole,
      'senderName': senderName,
      'senderPhone': senderPhone,
      'senderAvatar': senderAvatar,
      'itemId': itemId,
      'targetCategory': targetCategory,
      'targetSubTab': targetSubTab,
      'actionUrl': actionUrl,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'expiresAt': expiresAt?.millisecondsSinceEpoch,
      'isRead': isRead,
    };
  }

  static NotificationUrgency _parseUrgency(dynamic val) {
    if (val == 'জরুরি' || val == 'urgent') return NotificationUrgency.urgent;
    if (val == 'সতর্কবার্তা' || val == 'alert') return NotificationUrgency.alert;
    return NotificationUrgency.normal;
  }

  /// ডিপ লিংকিং রাউটিং পাথ জেনারেটর
  String get deepLinkRoute {
    if (actionUrl != null && actionUrl!.isNotEmpty) {
      return actionUrl!;
    }
    final category = targetCategory ?? 'marketplace';
    if (itemId != null && itemId!.isNotEmpty) {
      return '/$category/detail/$itemId';
    }
    if (targetSubTab != null && targetSubTab!.isNotEmpty) {
      return '/$category?tab=$targetSubTab';
    }
    return '/$category';
  }
}
