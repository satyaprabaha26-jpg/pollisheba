// Polli Sheba PWA Service Worker (PWABuilder & Netlify Compliant)
const CACHE_NAME = 'polli-sheba-v3.0.0';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.ico',
  '/logo.png',
  '/apple-touch-icon.png',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
  '/icons/icon-maskable-512x512.png',
  '/icons/icon-144x144.png',
  '/icons/icon-96x96.png'
];

// Install Event
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch((err) => {
        console.warn('PWA: Some assets failed to precache:', err);
      });
    })
  );
  self.skipWaiting();
});

// Activate Event
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    })
  );
  self.clients.claim();
});

// Fetch Event - Stale While Revalidate / Network First with Cache Fallback
self.addEventListener('fetch', (event) => {
  // Only handle GET requests
  if (event.request.method !== 'GET') return;

  const url = new URL(event.request.url);

  // Do not intercept API, dev scripts, Vite internals, node_modules, or hot updates
  if (
    url.pathname.startsWith('/api/') || 
    url.pathname.startsWith('/.netlify/') ||
    url.pathname.startsWith('/@') ||
    url.pathname.startsWith('/src/') ||
    url.pathname.startsWith('/node_modules/') ||
    url.pathname.includes('hot-update') ||
    url.search.includes('v=') ||
    url.hostname === 'localhost' ||
    url.port === '3000'
  ) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      const fetchPromise = fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200 && networkResponse.type === 'basic') {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone).catch(() => {});
            });
          }
          return networkResponse;
        })
        .catch(() => {
          // If offline and request is for HTML navigation, return /index.html
          if (event.request.mode === 'navigate' || event.request.headers.get('accept')?.includes('text/html')) {
            return caches.match('/index.html');
          }
          return cachedResponse;
        });

      return cachedResponse || fetchPromise;
    })
  );
});

// Push Event - Background Push Notifications (FCM / Web Push / High Priority Call Channel)
self.addEventListener('push', (event) => {
  let data = {
    title: '🌾 পল্লী সেবা নোটিফিকেশন',
    body: 'আপনার এলাকার নতুন সেবা বা নোটিফিকেশন এসেছে।',
    icon: '/logo.png',
    badge: '/logo.png',
    url: '/',
    tag: 'polli-push-' + Date.now()
  };

  if (event.data) {
    try {
      const payload = event.data.json();
      data = { ...data, ...payload };
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const isCall = data.type === 'INCOMING_CALL' || data.category === 'incoming_call' || (data.tag && data.tag.includes('call'));

  let options;
  if (isCall) {
    // High-Priority Foreground Service Calling Notification (Bypasses DND, lockscreen wake, full action buttons)
    options = {
      body: data.body || 'পল্লী সেবা থেকে ফ্রি ইন্টারনেট অডিও কল আসছে...',
      icon: data.callerAvatar || data.icon || '/logo.png',
      badge: '/logo.png',
      tag: data.tag || `polli-incoming-call-${data.channelId || Date.now()}`,
      vibrate: [600, 200, 600, 200, 800, 300, 1000],
      requireInteraction: true,
      renotify: true,
      silent: false,
      data: {
        type: 'INCOMING_CALL',
        channelId: data.channelId,
        session: data.session || data,
        url: data.channelId ? `/?action=accept_call&channelId=${encodeURIComponent(data.channelId)}` : '/'
      },
      actions: [
        { action: 'accept_call', title: '📞 রিসিভ করুন' },
        { action: 'reject_call', title: '❌ বাতিল' }
      ]
    };
  } else {
    options = {
      body: data.body,
      icon: data.icon || '/logo.png',
      badge: data.badge || '/logo.png',
      tag: data.tag,
      vibrate: [300, 100, 300, 100, 400], // High priority vibration pattern
      requireInteraction: true,
      renotify: true,
      data: {
        url: data.url || (data.targetCategory ? `/?category=${encodeURIComponent(data.targetCategory)}${data.subTab ? `&subtab=${encodeURIComponent(data.subTab)}` : ''}` : '/'),
        targetCategory: data.targetCategory,
        subTab: data.subTab
      },
      actions: [
        { action: 'open_app', title: '📲 অ্যাপে দেখুন' },
        { action: 'close', title: '✕ বন্ধ করুন' }
      ]
    };
  }

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Notification Click Event - Deep Linking & Calling Actions (Accept / Reject)
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'close') {
    return;
  }

  const notifData = event.notification.data || {};
  const isCall = notifData.type === 'INCOMING_CALL' || (event.notification.tag && event.notification.tag.includes('incoming-call'));

  // If user tapped "❌ বাতিল" (Reject call)
  if (event.action === 'reject_call') {
    event.waitUntil(
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
        clientList.forEach((client) => {
          client.postMessage({
            type: 'REJECT_INCOMING_CALL',
            channelId: notifData.channelId
          });
        });
      })
    );
    return;
  }

  // If user tapped "📞 রিসিভ করুন" (Accept call) or tapped notification banner
  const isAcceptAction = event.action === 'accept_call';
  const targetUrl = notifData.url || (isCall ? `/?action=accept_call&channelId=${encodeURIComponent(notifData.channelId || '')}` : '/');
  const targetCategory = notifData.targetCategory;
  const subTab = notifData.subTab;

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // Check if an app window is already open
      for (const client of clientList) {
        if ('focus' in client) {
          client.focus();
          // Dispatch appropriate message
          if (isCall) {
            client.postMessage({
              type: isAcceptAction ? 'ACCEPT_INCOMING_CALL' : 'FOCUS_INCOMING_CALL',
              channelId: notifData.channelId,
              session: notifData.session
            });
          } else {
            client.postMessage({
              type: 'DEEP_LINK',
              url: targetUrl,
              targetCategory: targetCategory,
              subTab: subTab
            });
          }
          return;
        }
      }
      // If no window is open, open a new window
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});
