import React, { createContext, useContext, useState, useEffect } from 'react';
import bnDict from '../locales/bn.json';
import enDict from '../locales/en.json';

export type AppLanguage = 'bn' | 'en';

interface LanguageContextType {
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  toggleLanguage: () => void;
  /** Direct inline translator */
  t: (bn: string, en: string) => string;
  /** Key-based dictionary translator (e.g. 'notifications.agri_products') */
  tKey: (path: string, fallbackBn?: string, fallbackEn?: string) => string;
  /** Category & Sub-category name resolver */
  translateCategory: (categoryId: string, subCategoryId?: string) => { categoryName: string; subCategoryName?: string };
}

const LanguageContext = createContext<LanguageContextType>({
  language: 'bn',
  setLanguage: () => {},
  toggleLanguage: () => {},
  t: (bn) => bn,
  tKey: (_path, fallbackBn) => fallbackBn || '',
  translateCategory: (catId) => ({ categoryName: catId })
});

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<AppLanguage>(() => {
    try {
      const saved = localStorage.getItem('polli_app_language');
      return saved === 'en' ? 'en' : 'bn';
    } catch {
      return 'bn';
    }
  });

  const setLanguage = (lang: AppLanguage) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('polli_app_language', lang);
      window.dispatchEvent(new CustomEvent('polli_language_changed', { detail: { language: lang } }));
    } catch {}
  };

  const toggleLanguage = () => {
    setLanguage(language === 'bn' ? 'en' : 'bn');
  };

  const t = (bn: string, en: string): string => {
    return language === 'en' ? (en || bn) : bn;
  };

  // Helper to read nested dictionary paths: 'notifications.agri_products'
  const tKey = (path: string, fallbackBn?: string, fallbackEn?: string): string => {
    const dict = language === 'en' ? enDict : bnDict;
    const parts = path.split('.');
    let current: any = dict;
    for (const part of parts) {
      if (current && typeof current === 'object' && part in current) {
        current = current[part];
      } else {
        return language === 'en' ? (fallbackEn || fallbackBn || path) : (fallbackBn || path);
      }
    }
    return typeof current === 'string' ? current : (language === 'en' ? (fallbackEn || path) : (fallbackBn || path));
  };

  // Helper to resolve localized category & sub-category names
  const translateCategory = (categoryId: string, subCategoryId?: string) => {
    const dict: any = language === 'en' ? enDict : bnDict;
    const categoryName = dict.categories?.[categoryId] || categoryId;
    const subCategoryName = subCategoryId ? (dict.subcategories?.[subCategoryId] || subCategoryId) : undefined;
    return { categoryName, subCategoryName };
  };

  useEffect(() => {
    const handleLangChange = (e: any) => {
      if (e.detail?.language && e.detail.language !== language) {
        setLanguageState(e.detail.language);
      }
    };
    window.addEventListener('polli_language_changed', handleLangChange);
    return () => window.removeEventListener('polli_language_changed', handleLangChange);
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, toggleLanguage, t, tKey, translateCategory }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);

