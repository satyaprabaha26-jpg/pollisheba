/**
 * পল্লী সেবা (Polli Sheba) - ব্যাকএন্ড ক্লাউড ফাংশনস ও নোটিফিকেশন ইঞ্জিন
 * 
 * প্রযুক্তি: Node.js / Firebase Cloud Functions / Firebase Admin
 * 
 * এই কোডটি ২টি প্রধান ইভেন্ট হ্যান্ডল করে:
 * ১. পণ্য কেনাবেচা পোস্ট (Marketplace Post Trigger) ➔ কৃষি বা গৃহস্থালি পণ্য নোটিফিকেশন ফিল্টারিং
 * ২. নির্দিষ্ট সেবা বা চালক রিকোয়েস্ট (Targeted Service Request Trigger) ➔ এলাকা + সাব-ক্যাটাগরি ফিল্টারিং
 */

export interface LocationFilterParams {
  district: string;        // আবশ্যক (জেলা)
  upazila?: string;       // ঐচ্ছিক (উপজেলা)
  union?: string;         // ঐচ্ছিক (ইউনিয়ন বা ওয়ার্ড)
}

export interface TargetedUserRecord {
  id: string;
  name: string;
  role: string;
  subCategory?: string;
  district: string;
  upazila?: string;
  union?: string;
  fcmToken?: string;
  notificationSwitches?: {
    notifyAgriProducts?: boolean;
    notifyHouseholdProducts?: boolean;
    notifyProfessionalServices?: boolean;
  };
  notificationSettings?: {
    notifyAgriProducts?: boolean;
    notifyHouseholdProducts?: boolean;
    notifyProfessionalServices?: boolean;
  };
  driverInfo?: {
    vehicleType?: string;
  };
}

/**
 * ইউজার প্রদত্ত লোকেশন অনুযায়ী ডাটাবেজ থেকে কাঙ্ক্ষিত ইউজারদের ফিল্টার করে আনা
 * - শুধু জেলা দিলে ➔ পুরো জেলার ইউজার
 * - জেলা + উপজেলা দিলে ➔ ঐ উপজেলার ইউজার
 * - জেলা + উপজেলা + ইউনিয়ন দিলে ➔ নির্দিষ্ট ইউনিয়নের ইউজার
 */
export async function filterTargetedUsers(
  firestoreInstance: any,
  location: LocationFilterParams
): Promise<TargetedUserRecord[]> {
  let query = firestoreInstance.collection('registered_users');

  // বাধ্যতামূলক জেলা কুয়েরি
  if (location.district) {
    query = query.where('district', '==', location.district.trim());
  }

  // যদি উপজেলা নির্বাচন করা থাকে
  if (location.upazila && location.upazila.trim()) {
    query = query.where('upazila', '==', location.upazila.trim());
  }

  // যদি ইউনিয়ন বা ওয়ার্ড নির্বাচন করা থাকে
  if (location.union && location.union.trim()) {
    query = query.where('union', '==', location.union.trim());
  }

  const snapshot = await query.get();
  return snapshot.docs.map((doc: any) => ({ id: doc.id, ...doc.data() }));
}

/**
 * ১. পণ্য কেনাবেচা পোস্ট হ্যান্ডলার (Marketplace Post Handler)
 */
export async function handleMarketplacePostNotification(
  adminSdk: any,
  postData: {
    listingId: string;
    title: string;
    price: string | number;
    unit: string;
    category: string;
    district: string;
    upazila?: string;
    unionOrWard?: string;
    sellerName?: string;
    sellerId?: string;
  }
) {
  const db = adminSdk.firestore();
  const messaging = adminSdk.messaging();

  const {
    listingId,
    title,
    price,
    unit,
    category,
    district,
    upazila,
    unionOrWard,
    sellerName,
    sellerId
  } = postData;

  // ১. পণ্যের ক্যাটাগরি অনুযায়ী নোটিফিকেশন টাইপ নির্ধারণ
  const isAgriProduct = category?.includes('কৃষি') || category?.includes('সবজি') || category?.includes('ফল') || category?.includes('মাছ');
  const notificationKey = isAgriProduct ? 'notifyAgriProducts' : 'notifyHouseholdProducts';

  // ২. ঐচ্ছিক লোকেশন অনুযায়ী ইউজারদের তালিকা সংগ্রহ
  const targetUsers = await filterTargetedUsers(db, {
    district,
    upazila,
    union: unionOrWard
  });

  // ৩. নোটিফিকেশন সুইচ এবং নিজের আইডি ফিল্টার
  const eligibleTokens: string[] = [];
  const inAppBatch = db.batch();

  for (const user of targetUsers) {
    // বিক্রেতা নিজে নোটিফিকেশন পাবেন না
    if (user.id === sellerId) continue;

    // প্রোফাইল নোটিফিকেশন সুইচ চেক (ডিফল্ট: true)
    const userSwitches = user.notificationSwitches || user.notificationSettings || {};
    const isNotificationEnabled = (userSwitches as any)[notificationKey] !== false;

    if (!isNotificationEnabled) {
      continue;
    }

    if (user.fcmToken) {
      eligibleTokens.push(user.fcmToken);
    }

    // ইন-অ্যাপ নোটিফিকেশন রেকর্ড তৈরি
    const notificationRef = db.collection('notifications').doc();
    inAppBatch.set(notificationRef, {
      id: notificationRef.id,
      recipientId: user.id,
      type: isAgriProduct ? 'agri_product_post' : 'household_product_post',
      title: isAgriProduct ? '🌱 নতুন কৃষি পণ্যের পোস্ট' : '🏡 নতুন গৃহস্থালি পণ্যের পোস্ট',
      body: `${sellerName || 'এক বিক্রেতা'} "${title}" বিক্রির জন্য দিয়েছেন (দাম: ৳${price}/${unit})`,
      listingId,
      district,
      upazila: upazila || '',
      isRead: false,
      createdAt: new Date().toISOString()
    });
  }

  await inAppBatch.commit();

  // ৪. পুশ নোটিফিকেশন (FCM) প্রেরণ
  if (eligibleTokens.length > 0) {
    await messaging.sendEachForMulticast({
      tokens: eligibleTokens,
      notification: {
        title: isAgriProduct ? '🌱 পল্লী হাট: নতুন ফসল/কৃষি পণ্য' : '🏡 পল্লী হাট: নতুন গৃহস্থালি পণ্য',
        body: `${title} - ৳${price}/${unit} (${district}${upazila ? `, ${upazila}` : ''})`
      },
      data: {
        click_action: 'FLUTTER_NOTIFICATION_CLICK',
        listingId,
        type: 'market_post'
      }
    });
  }

  return { notifiedCount: eligibleTokens.length };
}

/**
 * ২. নির্দিষ্ট সেবা বা চালক রিকোয়েস্ট হ্যান্ডলার (Targeted Service Request Handler)
 */
export async function handleTargetedServiceRequestNotification(
  adminSdk: any,
  requestData: {
    requestId: string;
    serviceCategory: string; // e.g. 'driver', 'health_worker', 'electrician_mechanic', 'laborer'
    subCategory?: string;     // e.g. 'cng', 'ambulance', 'veterinary', 'house_electrician'
    pickupDistrict: string;   // রওনা দেওয়ার জেলা
    pickupUpazila?: string;   // রওনা দেওয়ার উপজেলা
    pickupUnion?: string;     // রওনা দেওয়ার ইউনিয়ন/ওয়ার্ড
    requesterName?: string;
    destination?: string;
  }
) {
  const db = adminSdk.firestore();
  const messaging = adminSdk.messaging();

  const {
    requestId,
    serviceCategory,
    subCategory,
    pickupDistrict,
    pickupUpazila,
    pickupUnion,
    requesterName,
    destination
  } = requestData;

  // ১. ঐচ্ছিক লোকেশন অনুযায়ী সেবাদাতা ইউজারদের প্রাথমিক ফিল্টারিং
  const potentialProviders = await filterTargetedUsers(db, {
    district: pickupDistrict,
    upazila: pickupUpazila,
    union: pickupUnion
  });

  const eligibleTokens: string[] = [];
  const inAppBatch = db.batch();

  // ২. সুনির্দিষ্ট রোল ও সাব-ক্যাটাগরি ম্যাচিং
  for (const provider of potentialProviders) {
    const roleMatches = provider.role === serviceCategory || (provider as any).mainCategory === serviceCategory;
    if (!roleMatches) continue;

    // সাব-ক্যাটাগরি মিলছে কি না (যদি নির্দিষ্ট করা থাকে)
    if (subCategory && subCategory !== 'all') {
      const providerSubCategory = 
        provider.subCategory || 
        provider.driverInfo?.vehicleType || 
        (provider as any).mechanicType || 
        (provider as any).laborerType;

      const isSubMatch = 
        providerSubCategory === subCategory || 
        (typeof providerSubCategory === 'string' && providerSubCategory.toLowerCase().includes(subCategory.toLowerCase()));

      if (!isSubMatch) continue;
    }

    // পেশাগত নোটিফিকেশন সুইচ চেক (notifyProfessionalServices)
    const switches = provider.notificationSwitches || provider.notificationSettings || {};
    const isProfServiceEnabled = switches.notifyProfessionalServices !== false;

    if (!isProfServiceEnabled) {
      continue;
    }

    if (provider.fcmToken) {
      eligibleTokens.push(provider.fcmToken);
    }

    // ইন-অ্যাপ নোটিফিকেশন তৈরি
    const notificationRef = db.collection('notifications').doc();
    inAppBatch.set(notificationRef, {
      id: notificationRef.id,
      recipientId: provider.id,
      type: 'service_request_alert',
      title: '🔔 নতুন সেবা রিকোয়েস্ট এসেছে!',
      body: `${requesterName || 'একজন নাগরিক'} আপনার এলাকায় সেবা চেয়েছেন${destination ? ` (গন্তব্য: ${destination})` : ''}।`,
      requestId,
      category: serviceCategory,
      subCategory: subCategory || '',
      pickupLocation: `${pickupDistrict}${pickupUpazila ? `, ${pickupUpazila}` : ''}`,
      isRead: false,
      createdAt: new Date().toISOString()
    });
  }

  await inAppBatch.commit();

  // ৩. চালক বা সেবাদাতাদের ফোনে সরাসরি পুশ অ্যালার্ট পাঠানো
  if (eligibleTokens.length > 0) {
    await messaging.sendEachForMulticast({
      tokens: eligibleTokens,
      notification: {
        title: '🚨 জরুরি সেবার ডাক!',
        body: `${requesterName || 'নাগরিক'} আপনার এলাকায় ${subCategory || serviceCategory} খুঁজছেন।`
      },
      data: {
        click_action: 'FLUTTER_NOTIFICATION_CLICK',
        requestId,
        type: 'service_request'
      }
    });
  }

  return { notifiedCount: eligibleTokens.length };
}

/**
 * ৩. ফিরতি পরিবহন নোটিফিকেশন হ্যান্ডলার (Return Transport Push & FCM Routing)
 * 
 * এফসিএম রাউটিং নিয়ম:
 * ক) চালকের পোস্ট ("ফিরতি গাড়ি যুক্ত করুন"):
 *    - নোটিফিকেশন যাবে ঐ এলাকার সকল সাধারণ নিবন্ধিত নাগরিক/যাত্রীদের ফোনে।
 * খ) যাত্রীর পোস্ট ("ফিরতি গাড়ি খুঁজুন"):
 *    - নোটিফিকেশন যাবে শুধুমাত্র ঐ এলাকার নির্দিষ্ট বাহন বা সংশ্লিষ্ট চালকদের ফোনে (সাধারণ ব্যবহারকারীরা পাবেন না)।
 */
export async function handleReturnTransportNotification(
  adminSdk: any,
  rideData: {
    rideId: string;
    postType: 'driver_return' | 'passenger_request'; // চালকের পোস্ট নাকি যাত্রীর পোস্ট
    vehicleType: string;
    capacity: string;
    fromDistrict: string;
    fromUpazila?: string;
    fromUnion?: string;
    fromLocation?: string;
    toDistrict: string;
    toLocation?: string;
    departureDate: string;
    departureTime: string;
    creatorId: string;
    creatorName: string;
    fareType: 'negotiable' | 'fixed';
    fareAmount?: number;
  }
) {
  const db = adminSdk.firestore();
  const messaging = adminSdk.messaging();

  const {
    rideId,
    postType,
    vehicleType,
    capacity,
    fromDistrict,
    fromUpazila,
    fromUnion,
    fromLocation,
    toDistrict,
    toLocation,
    departureDate,
    departureTime,
    creatorId,
    creatorName,
    fareType,
    fareAmount
  } = rideData;

  const isDriverPost = postType === 'driver_return';

  // প্রস্থান এলাকার সকল সম্ভাব্য নিবন্ধিত ইউজার
  const targetUsers = await filterTargetedUsers(db, {
    district: fromDistrict,
    upazila: fromUpazila,
    union: fromUnion
  });

  const eligibleTokens: string[] = [];
  const inAppBatch = db.batch();

  for (const user of targetUsers) {
    if (user.id === creatorId) continue; // নিজের ফোনে নোটিফিকেশন যাবে না

    if (isDriverPost) {
      // চালকের পোস্ট ➔ নোটিফিকেশন যাবে সকল সাধারণ যাত্রী/নাগরিকের ফোনে
      if (user.role === 'driver' && user.id !== creatorId) {
        continue;
      }
    } else {
      // যাত্রীর পোস্ট ➔ নোটিফিকেশন যাবে শুধুমাত্র ঐ এলাকার চালকদের কাছে
      const isDriver = user.role === 'driver' || (user as any).mainCategory === 'driver';
      if (!isDriver) {
        continue; // সাধারণ ইউজার (কৃষক, শিক্ষক ইত্যাদি) পাবেন না
      }

      if (user.driverInfo?.vehicleType && vehicleType) {
        const dType = user.driverInfo.vehicleType.toLowerCase();
        const reqType = vehicleType.toLowerCase();
        if (!dType.includes(reqType) && !reqType.includes(dType)) {
          continue;
        }
      }
    }

    if (user.fcmToken) {
      eligibleTokens.push(user.fcmToken);
    }

    // ইন-অ্যাপ নোটিফিকেশন রেকর্ড সংরক্ষণ
    const notifRef = db.collection('notifications').doc();
    inAppBatch.set(notifRef, {
      id: notifRef.id,
      recipientId: user.id,
      type: isDriverPost ? 'return_transport_available' : 'return_transport_passenger_need',
      title: isDriverPost 
        ? `🚗 খালি ফিরতি গাড়ি (${vehicleType}): ${fromLocation || fromDistrict} ➔ ${toLocation || toDistrict}`
        : `🙋‍♂️ ফিরতি গাড়ির যাত্রী রিকোয়েস্ট (${vehicleType}): ${fromLocation || fromDistrict} ➔ ${toLocation || toDistrict}`,
      body: isDriverPost
        ? `সাশ্রয়ী ভাড়ায় ফিরতি ট্রিপ! সিট: ${capacity}। যাত্রা: ${departureDate} (${departureTime})। ভাড়া: ${fareType === 'fixed' && fareAmount ? `৳${fareAmount}` : 'আলোচনা সাপেক্ষে'}।`
        : `যাত্রী ${creatorName} ফিরতি গাড়ি খুঁজছেন। সিট: ${capacity}। সময়: ${departureDate} (${departureTime})।`,
      rideId,
      vehicleType,
      fromDistrict,
      toDistrict,
      isRead: false,
      createdAt: new Date().toISOString()
    });
  }

  await inAppBatch.commit();

  // এফসিএম হাই-প্রায়োরিটি বার্তা প্রেরণ
  if (eligibleTokens.length > 0) {
    await messaging.sendEachForMulticast({
      tokens: eligibleTokens,
      notification: {
        title: isDriverPost ? '🚗 খালি ফিরতি গাড়ি উপলভ্য!' : '🙋‍♂️ ফিরতি গাড়ির যাত্রী রিকোয়েস্ট!',
        body: `${vehicleType} (${fromDistrict} ➔ ${toDistrict}) - ${isDriverPost ? 'কম ভাড়ায় যাতায়াত করুন' : 'যাত্রী নিতে যোগাযোগ করুন'}`
      },
      data: {
        click_action: 'FLUTTER_NOTIFICATION_CLICK',
        rideId,
        type: 'return_transport',
        postType
      }
    });
  }

  return { notifiedCount: eligibleTokens.length };
}

