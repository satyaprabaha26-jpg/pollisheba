// Location Detection and "আমার এলাকা" Management Service

import { BANGLADESH_DISTRICT_COORDINATES, findNearestDistrict, DistrictGeoData } from '../data/districtCoordinates';
import { BANGLADESH_LOCATIONS } from '../data/bangladeshLocations';

export interface UserSavedLocation {
  district: string;
  upazila?: string;
  union?: string;
  isGpsDetected?: boolean;
  detectedAt?: number;
  latitude?: number;
  longitude?: number;
}

const STORAGE_KEY = 'polli_user_location';

export function getSavedLocation(): UserSavedLocation | null {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error('Failed to parse saved location', e);
  }
  return null;
}

export function saveUserLocation(location: UserSavedLocation): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(location));
    // Trigger storage event for other components in same window
    window.dispatchEvent(new CustomEvent('polli_location_changed', { detail: location }));
  } catch (e) {
    console.error('Failed to save location', e);
  }
}

export interface GeolocationResult {
  success: boolean;
  district?: string;
  division?: string;
  latitude?: number;
  longitude?: number;
  errorMessage?: string;
}

// Request Browser GPS Geolocation and find closest Bangladesh District
export async function detectCurrentLocationGPS(): Promise<GeolocationResult> {
  if (!navigator.geolocation) {
    return {
      success: false,
      errorMessage: 'আপনার ব্রাউজারে জিপিএস বা লোকেশন সুবিধা সমর্থন করে না।'
    };
  }

  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const nearest = findNearestDistrict(latitude, longitude);
        
        const locData: UserSavedLocation = {
          district: nearest.name,
          isGpsDetected: true,
          latitude,
          longitude,
          detectedAt: Date.now()
        };

        // Try to pick primary upazila from database
        const distEntry = BANGLADESH_LOCATIONS.find(d => d.district === nearest.name);
        if (distEntry && distEntry.upazilas.length > 0) {
          locData.upazila = distEntry.upazilas[0].name;
        }

        saveUserLocation(locData);

        resolve({
          success: true,
          district: nearest.name,
          division: nearest.division,
          latitude,
          longitude
        });
      },
      (error) => {
        let msg = 'লোকেশন পাওয়া যায়নি। অনুগ্রহ করে ডিভাইসের জিপিএস পারমিশন চালু করুন।';
        if (error.code === error.PERMISSION_DENIED) {
          msg = 'লোকেশন ব্যবহারের অনুমতি দেওয়া হয়নি। জেলা তালিকা থেকে আপনার জেলা নির্বাচন করুন।';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          msg = 'ডিভাইস লোকেশন সিগন্যাল পাওয়া যাচ্ছে না।';
        } else if (error.code === error.TIMEOUT) {
          msg = 'লোকেশন পেতে অতিরিক্ত সময় লাগছে।';
        }
        resolve({
          success: false,
          errorMessage: msg
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      }
    );
  });
}
