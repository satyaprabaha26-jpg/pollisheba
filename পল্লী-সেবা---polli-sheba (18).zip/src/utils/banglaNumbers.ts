// Bengali Number & Date Utilities

export const toBanglaNumber = (num: number | string | undefined | null): string => {
  if (num === undefined || num === null) return '০';
  const banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return num.toString().replace(/\d/g, (d) => banglaDigits[parseInt(d, 10)]);
};

export const toEnglishNumber = (str: string): number => {
  const banglaDigits: Record<string, string> = {
    '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
    '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
  };
  const engStr = str.replace(/[০-৯]/g, (d) => banglaDigits[d] || d);
  return parseFloat(engStr) || 0;
};

export const formatTaka = (amount: number): string => {
  return `৳${toBanglaNumber(amount.toLocaleString('en-IN'))}`;
};

export const getBanglaCurrentDate = (): {
  englishFormatted: string;
  banglaDate: string;
  banglaDateWithDay: string;
  dayName: string;
  season: string;
  hijriDate: string;
} => {
  const today = new Date();
  
  // English formatted in Bangla
  const monthsBn = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];
  const daysBn = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
  
  const dayName = daysBn[today.getDay()];
  const day = toBanglaNumber(today.getDate());
  const monthName = monthsBn[today.getMonth()];
  const year = toBanglaNumber(today.getFullYear());
  const englishFormatted = `${dayName}, ${day} ${monthName}, ${year}`;

  // Approximate Bangla calendar calculation
  const month = today.getMonth(); // 0-11
  const date = today.getDate();

  let banglaMonth = 'বৈশাখ';
  let banglaDay = 1;
  let banglaYear = today.getFullYear() - 593;
  let season = 'গ্রীষ্মকাল';

  // Bangla Calendar month mapping
  if ((month === 3 && date >= 14) || (month === 4 && date <= 14)) {
    banglaMonth = 'বৈশাখ';
    banglaDay = month === 3 ? date - 13 : date + 17;
    season = 'গ্রীষ্মকাল';
  } else if ((month === 4 && date >= 15) || (month === 5 && date <= 14)) {
    banglaMonth = 'জ্যৈষ্ঠ';
    banglaDay = month === 4 ? date - 14 : date + 17;
    season = 'গ্রীষ্মকাল';
  } else if ((month === 5 && date >= 15) || (month === 6 && date <= 15)) {
    banglaMonth = 'আষাঢ়';
    banglaDay = month === 5 ? date - 14 : date + 16;
    season = 'বর্ষাকাল';
  } else if ((month === 6 && date >= 16) || (month === 7 && date <= 15)) {
    banglaMonth = 'শ্রাবণ';
    banglaDay = month === 6 ? date - 15 : date + 16;
    season = 'বর্ষাকাল';
  } else if ((month === 7 && date >= 16) || (month === 8 && date <= 15)) {
    banglaMonth = 'ভাদ্র';
    banglaDay = month === 7 ? date - 15 : date + 16;
    season = 'শরৎকাল';
  } else if ((month === 8 && date >= 16) || (month === 9 && date <= 15)) {
    banglaMonth = 'আশ্বিন';
    banglaDay = month === 8 ? date - 15 : date + 15;
    season = 'শরৎকাল';
  } else if ((month === 9 && date >= 16) || (month === 10 && date <= 15)) {
    banglaMonth = 'কার্তিক';
    banglaDay = month === 9 ? date - 15 : date + 15;
    season = 'হেমন্তকাল';
  } else if ((month === 10 && date >= 16) || (month === 11 && date <= 14)) {
    banglaMonth = 'অগ্রহায়ণ';
    banglaDay = month === 10 ? date - 15 : date + 15;
    season = 'হেমন্তকাল';
  } else if ((month === 11 && date >= 15) || (month === 0 && date <= 13)) {
    banglaMonth = 'পৌষ';
    banglaDay = month === 11 ? date - 14 : date + 17;
    season = 'শীতকাল';
  } else if ((month === 0 && date >= 14) || (month === 1 && date <= 12)) {
    banglaMonth = 'মাঘ';
    banglaDay = month === 0 ? date - 13 : date + 18;
    season = 'শীতকাল';
  } else if ((month === 1 && date >= 13) || (month === 2 && date <= 14)) {
    banglaMonth = 'ফাল্গুন';
    banglaDay = month === 1 ? date - 12 : date + 16;
    season = 'বসন্তকাল';
  } else {
    banglaMonth = 'চৈত্র';
    banglaDay = month === 2 ? date - 14 : date + 17;
    season = 'বসন্তকাল';
  }

  const banglaDate = `${toBanglaNumber(banglaDay)} ${banglaMonth}, ${toBanglaNumber(banglaYear)} বঙ্গাব্দ`;
  const banglaDateWithDay = `${dayName}, ${toBanglaNumber(banglaDay)} ${banglaMonth}, ${toBanglaNumber(banglaYear)} বঙ্গাব্দ`;

  // Islamic Hijri Date calculation
  const hijriMonthsBn = [
    'মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল আউয়াল', 'জমাদিউস সানি',
    'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জিলকদ', 'জিলহজ'
  ];

  let hijriDate = '১২ সফর, ১৪৪৮ হিজরি';
  try {
    const islamicFormatter = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric'
    });
    const parts = islamicFormatter.formatToParts(today);
    let hDay = 1;
    let hMonth = 1;
    let hYear = 1448;

    parts.forEach(p => {
      if (p.type === 'day') hDay = parseInt(p.value, 10) || 1;
      if (p.type === 'month') hMonth = parseInt(p.value, 10) || 1;
      if (p.type === 'year') hYear = parseInt(p.value, 10) || 1448;
    });

    const monthIndex = Math.max(0, Math.min(11, hMonth - 1));
    hijriDate = `${toBanglaNumber(hDay)} ${hijriMonthsBn[monthIndex]}, ${toBanglaNumber(hYear)} হিজরি`;
  } catch (e) {
    hijriDate = '১২ সফর, ১৪৪৮ হিজরি';
  }

  return {
    englishFormatted,
    banglaDate,
    banglaDateWithDay,
    dayName,
    season,
    hijriDate
  };
};

