import { ServiceCategory } from '../types';
import { UserProfile } from '../types/auth';
import { BANGLADESH_LOCATIONS, getUpazilasForDistrict, getUnionsForUpazila, getDistrictForUpazila } from '../data/bangladeshLocations';
import { BANGLADESH_DISTRICTS } from '../data/mockData';
import { DOCTOR_SCHEDULES_DATA } from '../data/extendedData';

export interface AIProviderCard {
  id: string;
  name: string;
  roleLabel: string;
  avatar?: string;
  category: 
    | 'transport' 
    | 'return_transport' 
    | 'marketplace' 
    | 'health' 
    | 'housing' 
    | 'labor' 
    | 'mechanic' 
    | 'tutor' 
    | 'doctor';
  district: string;
  upazila: string;
  unionOrArea?: string;
  highlightDetail: string;
  availabilityBadge?: string;
  rating?: number;
  // STRICT PRIVACY PROTOCOL:
  // These internal identifiers are passed to in-app calling (Agora) and chatting without displaying phone numbers in the UI
  uid: string;
  privatePhoneRef?: string;
  actionCategory: ServiceCategory;
  subTab?: string;
  originalItem?: any;
}

export type DetectedServiceCategory =
  | 'transport_cng'
  | 'transport_general'
  | 'return_transport'
  | 'honey_seller'
  | 'haat_produce'
  | 'blood_donor'
  | 'housing_rental'
  | 'day_labor'
  | 'tutor_teacher'
  | 'mechanic_electrician'
  | 'doctor_health'
  | 'general_inquiry';

export interface ParsedSearchQuery {
  detectedCategory: DetectedServiceCategory;
  categoryLabelBengali: string;
  extractedDistrict?: string;
  extractedUpazila?: string;
  extractedUnion?: string;
  bloodGroup?: string;
  keywordMatch: string;
  isSpecificSearch: boolean;
}

export interface SmartSearchResult {
  isSearchQuery: boolean;
  parsed: ParsedSearchQuery;
  cards: AIProviderCard[];
  isFallback: boolean;
  fallbackType?: 'nearby_upazila' | 'no_providers_in_district';
  introMessage: string;
  actions: Array<{ target: ServiceCategory; label: string; subTab?: string }>;
}

/**
 * 1. NATURAL LANGUAGE BANGLA PARSER
 * Extracts District, Upazila, Union, and Service Category from conversational Bangla.
 */
export function parseLocationAndServiceQuery(
  rawQuery: string,
  defaultDistrict: string = 'পটুয়াখালী',
  defaultUpazila: string = 'বাউফল'
): ParsedSearchQuery {
  const text = rawQuery.trim();
  const lower = text.toLowerCase();

  // 1. Identify Service Category & Keywords
  let detectedCategory: DetectedServiceCategory = 'general_inquiry';
  let categoryLabelBengali = 'সেবা';
  let keywordMatch = '';
  let bloodGroup: string | undefined = undefined;

  // A. Return Transport (ফিরতি পরিবহন / ফিরতি গাড়ি)
  if (/(ফিরতি গাড়ি|ফিরতি গাড়ি|ফিরতি পরিবহন|ফিরতি ট্রিপ|খালি গাড়ি|খালি গাড়ি|ফিরতি সিএনজি|ফিরতি কার)/i.test(text)) {
    detectedCategory = 'return_transport';
    categoryLabelBengali = 'ফিরতি পরিবহন ও খালি গাড়ি';
    keywordMatch = 'ফিরতি পরিবহন';
  }
  // B. CNG Driver (সিএনজি চালক)
  else if (/(সিএনজি|cng|সি এন জি)/i.test(text)) {
    detectedCategory = 'transport_cng';
    categoryLabelBengali = 'সিএনজি চালক';
    keywordMatch = 'সিএনজি';
  }
  // C. General Driver & Vehicles (অটোরিকশা, কার, মাইক্রো, বাইক, পিকআপ, ট্রলার, মাঝি ইত্যাদি)
  else if (/(চালক|ড্রাইভার|অটোরিকশা|অটো|ইজিবাইক|বাইক|মোটরসাইকেল|পিকআপ|ট্রাক|ভ্যান|নসিমন|করিমন|ট্রলার|মাঝি|নৌকা|খেয়া|গাড়ি|গাড়ি|যাতায়াত)/i.test(text)) {
    detectedCategory = 'transport_general';
    categoryLabelBengali = 'নিরাপদ পরিবহন ও চালক';
    if (text.includes('মাঝি') || text.includes('নৌকা') || text.includes('ট্রলার')) {
      categoryLabelBengali = 'নৌকা, ট্রলার ও মাঝি';
    } else if (text.includes('পিকআপ') || text.includes('ট্রাক')) {
      categoryLabelBengali = 'পিকআপ ও ট্রাক চালক';
    } else if (text.includes('অটোরিকশা') || text.includes('ইজিবাইক')) {
      categoryLabelBengali = 'অটোরিকশা ও ইজিবাইক চালক';
    }
    keywordMatch = 'পরিবহন চালক';
  }
  // D. Honey Seller (মধু বিক্রেতা)
  else if (/(মধু|খাঁটি মধু|সুন্দরবনের মধু|মৌমাছি|মধু বিক্রেতা)/i.test(text)) {
    detectedCategory = 'honey_seller';
    categoryLabelBengali = 'খাঁটি মধু বিক্রেতা';
    keywordMatch = 'মধু';
  }
  // E. Blood Donors (রক্তের ডোনার ও রক্তদাতা)
  else if (/(রক্ত|রক্তদাতা|ব্লাড|ডোনার|blood|পজিটিভ|নেগেটিভ)/i.test(text)) {
    detectedCategory = 'blood_donor';
    categoryLabelBengali = 'জরুরি রক্তের ডোনার';
    keywordMatch = 'রক্তদাতা';

    // Extract blood group if specified
    if (/(a\+|এ\s*পজিটিভ|এ\+)/i.test(text)) bloodGroup = 'A+';
    else if (/(b\+|বি\s*পজিটিভ|বি\+)/i.test(text)) bloodGroup = 'B+';
    else if (/(o\+|ও\s*পজিটিভ|ও\+)/i.test(text)) bloodGroup = 'O+';
    else if (/(ab\+|এবি\s*পজিটিভ|এবি\+)/i.test(text)) bloodGroup = 'AB+';
    else if (/(a-|এ\s*নেগেটিভ|এ-)/i.test(text)) bloodGroup = 'A-';
    else if (/(b-|বি\s*নেগেটিভ|বি-)/i.test(text)) bloodGroup = 'B-';
    else if (/(o-|ও\s*নেগেটিভ|ও-)/i.test(text)) bloodGroup = 'O-';
    else if (/(ab-|এবি\s*নেগেটিভ|এবি-)/i.test(text)) bloodGroup = 'AB-';

    if (bloodGroup) {
      categoryLabelBengali = `${bloodGroup} গ্রুপের রক্তের ডোনার`;
    }
  }
  // F. Housing & Rentals (বাসা ভাড়া, মেস, দোকান)
  else if (/(বাসা ভাড়া|বাসা ভাড়া|বাড়ি ভাড়া|বাড়ি ভাড়া|রুম ভাড়া|রুম ভাড়া|মেস|দোকান ভাড়া|দোকান ভাড়া|সাবলেট|ফ্ল্যাট)/i.test(text)) {
    detectedCategory = 'housing_rental';
    categoryLabelBengali = 'বাসা ও বাড়ি ভাড়া';
    keywordMatch = 'বাসা ভাড়া';
  }
  // G. Day Laborers & Agricultural Workers (দিনমজুর ও কৃষি শ্রমিক)
  else if (/(দিনমজুর|কৃষি শ্রমিক|কামলা|শ্রমিক|ধান কাটা|মাটি কাটা|মজুর|কামলা লাগবে|শ্রমিক দরকার)/i.test(text)) {
    detectedCategory = 'day_labor';
    categoryLabelBengali = 'দিনমজুর ও কৃষি শ্রমিক';
    keywordMatch = 'দিনমজুর';
  }
  // H. Tutors & Teachers (গৃহশিক্ষক ও শিক্ষার্থী)
  else if (/(গৃহশিক্ষক|টিউটর|শিক্ষক|প্রাইভেট টিউটর|পড়াতে চাই|পড়ানোর|মাস্টার|টিচার|পড়াতে চাই)/i.test(text)) {
    detectedCategory = 'tutor_teacher';
    categoryLabelBengali = 'গৃহশিক্ষক ও টিউটর';
    keywordMatch = 'গৃহশিক্ষক';
  }
  // I. Mechanics & Electricians (ইলেকট্রিশিয়ান, মেকার, মেকানিক, মিস্ত্রি)
  else if (/(ইলেকট্রিশিয়ান|ইলেকট্রিশিয়ান|মেকার|মেকানিক|মিস্ত্রি|টিউবওয়েল|টিউবয়েল|প্লাম্বার|মোটর মেরামত|ফ্যান মেরামত|কারিগর|ওয়ার্কশপ)/i.test(text)) {
    detectedCategory = 'mechanic_electrician';
    categoryLabelBengali = 'ইলেকট্রিশিয়ান, মেকার ও মেকানিক';
    keywordMatch = 'মেকার ও মেকানিক';
  }
  // J. Doctors & Healthcare (ডাক্তার, হাসপাতাল, ক্লিনিক)
  else if (/(ডাক্তার|চিকিৎসক|ক্লিনিক|হাসপাতাল|এমবিবিএস|পল্লি চিকিৎসক)/i.test(text)) {
    detectedCategory = 'doctor_health';
    categoryLabelBengali = 'ডাক্তার ও স্বাস্থ্য বিশেষজ্ঞ';
    keywordMatch = 'ডাক্তার';
  }
  // K. Haat Products & Organic Produce (শাকসবজি, ফলমূল, খাদ্যশস্য)
  else if (/(সবজি|শাকসবজি|ডিম|দুধ|মাছ|চাল|গম|ধান|সার|বীজ|ফলমূল|আম|লিচু|কৃষিপণ্য|বিক্রেতা)/i.test(text)) {
    detectedCategory = 'haat_produce';
    categoryLabelBengali = 'পল্লী হাটের তাজা পণ্য ও বিক্রেতা';
    keywordMatch = 'হাটের পণ্য';
  }

  // 2. Identify Upazila first (or alongside district) across all districts
  let extractedUpazila: string | undefined = undefined;
  let extractedDistrict: string | undefined = undefined;

  // Check if any explicit upazila is mentioned across Bangladesh
  for (const dLoc of BANGLADESH_LOCATIONS) {
    for (const u of dLoc.upazilas) {
      const cleanU = u.name.replace(' সদর', '').trim();
      if (cleanU.length >= 3 && (text.includes(u.name) || text.includes(cleanU))) {
        extractedUpazila = u.name;
        extractedDistrict = dLoc.district;
        break;
      }
    }
    if (extractedUpazila) break;
  }

  // Also check if user explicitly mentioned a district
  for (const dist of BANGLADESH_DISTRICTS) {
    if (dist === 'সকল জেলা') continue;
    if (text.includes(dist) || lower.includes(dist.toLowerCase())) {
      // If user explicitly named a district, that takes precedence unless an upazila belonging to another district was already found
      if (!extractedUpazila || getDistrictForUpazila(extractedUpazila) === dist) {
        extractedDistrict = dist;
      }
      break;
    }
  }

  // If upazila was not found yet, check within the district (either extracted or default)
  if (!extractedUpazila) {
    const districtToCheck = extractedDistrict || defaultDistrict;
    const districtUpazilas = getUpazilasForDistrict(districtToCheck);
    for (const upz of districtUpazilas) {
      if (upz === 'সকল উপজেলা') continue;
      const cleanUpz = upz.replace(' সদর', '').trim();
      if (text.includes(cleanUpz) || text.includes(upz)) {
        extractedUpazila = upz;
        if (!extractedDistrict) extractedDistrict = districtToCheck;
        break;
      }
    }
  }

  // Ensure district and upazila consistency: if upazila is detected, verify parent district
  if (extractedUpazila) {
    const parentDist = getDistrictForUpazila(extractedUpazila);
    if (parentDist) {
      extractedDistrict = parentDist;
    }
  }

  const finalDistrict = extractedDistrict || defaultDistrict;
  const finalUpazila = extractedUpazila || (extractedDistrict ? getUpazilasForDistrict(extractedDistrict)[0] : defaultUpazila);

  // 4. Identify Union
  let extractedUnion: string | undefined = undefined;
  const currentUnions = getUnionsForUpazila(finalDistrict, finalUpazila);
  for (const un of currentUnions) {
    const cleanUn = un.replace(/ ইউনিয়ন.*/, '').replace(/১নং|২নং|৩নং/, '').trim();
    if (cleanUn.length >= 3 && text.includes(cleanUn)) {
      extractedUnion = un;
      break;
    }
  }

  // Common unions in Bauphal/Patuakhali quick match
  if (!extractedUnion && (finalDistrict === 'পটুয়াখালী' || finalUpazila === 'বাউফল')) {
    const commonUnions = ['কালিশুরী', 'কালাইয়া', 'বগা', 'কাছিপাড়া', 'ধুলিয়া', 'কনকদিয়া', 'সূর্যমণি', 'মদনপুরা', 'নওমালা', 'দশমিনা', 'গলাচিপা', 'কেশবপুর'];
    for (const cu of commonUnions) {
      if (text.includes(cu)) {
        extractedUnion = cu;
        break;
      }
    }
  }

  const isSpecificSearch = detectedCategory !== 'general_inquiry';

  return {
    detectedCategory,
    categoryLabelBengali,
    extractedDistrict: finalDistrict,
    extractedUpazila: finalUpazila,
    extractedUnion,
    bloodGroup,
    keywordMatch,
    isSpecificSearch
  };
}

/**
 * 2. LIVE FIRESTORE & DATASET SEARCH RUNNER
 * Queries registered drivers, return rides, haat sellers, blood donors, housing, users, etc.
 * Enforces strict 100% phone number privacy (numbers are never exposed in text).
 */
export function executeSmartSearch(
  query: string,
  currentDistrict: string,
  currentUpazila: string,
  datasets: {
    drivers?: any[];
    returnRides?: any[];
    haatItems?: any[];
    bloodDonors?: any[];
    housingListings?: any[];
    registeredUsers?: UserProfile[];
  }
): SmartSearchResult {
  const parsed = parseLocationAndServiceQuery(query, currentDistrict, currentUpazila);

  if (!parsed.isSpecificSearch) {
    return {
      isSearchQuery: false,
      parsed,
      cards: [],
      isFallback: false,
      introMessage: '',
      actions: []
    };
  }

  const targetDist = parsed.extractedDistrict || currentDistrict || 'পটুয়াখালী';
  const targetUpz = parsed.extractedUpazila || currentUpazila || 'বাউফল';
  const targetUnion = parsed.extractedUnion;

  const matchedCards: AIProviderCard[] = [];
  const nearbyCards: AIProviderCard[] = [];

  // Helper matcher
  const isMatchDist = (d?: string) => !d || d === 'সকল জেলা' || d === targetDist || targetDist === 'সকল জেলা';
  const isMatchUpz = (u?: string) => !u || u === 'সকল উপজেলা' || u.includes(targetUpz) || targetUpz.includes(u);
  const isMatchUnion = (un?: string) => !targetUnion || (un && (un.includes(targetUnion) || targetUnion.includes(un)));

  // CATEGORY 1: CNG & Drivers (Transport)
  if (parsed.detectedCategory === 'transport_cng' || parsed.detectedCategory === 'transport_general') {
    const allDrivers = datasets.drivers || [];
    const isCngOnly = parsed.detectedCategory === 'transport_cng';

    allDrivers.forEach((driver) => {
      const vType = (driver.vehicleType || '').toLowerCase();
      if (isCngOnly && !vType.includes('সিএনজি')) return;

      const isExact = isMatchDist(driver.district) && isMatchUpz(driver.upazila) && isMatchUnion(driver.unionOrWard || driver.standLocation);
      const isNearby = isMatchDist(driver.district) && !isExact;

      const card: AIProviderCard = {
        id: `driver-${driver.id || Math.random()}`,
        name: driver.driverName || 'সম্মানিত চালক',
        roleLabel: driver.vehicleType || 'নিরাপদ চালক',
        avatar: driver.facePhotoUrl,
        category: 'transport',
        district: driver.district || targetDist,
        upazila: driver.upazila || targetUpz,
        unionOrArea: driver.standLocation || driver.unionOrWard || 'স্ট্যান্ড',
        highlightDetail: `গাড়ি: ${driver.vehicleType} • শিফট: ${driver.serviceShift || (driver.isNightActive ? 'দিন ও রাত (২৪ ঘণ্টা)' : 'দিনে')} • রেটিং: ★ ${driver.rating || 4.9}`,
        availabilityBadge: driver.status === 'ব্যস্ত' ? '🟡 ট্রিপে আছেন' : '🟢 সরাসরি প্রস্তুত',
        rating: driver.rating || 4.9,
        // STRICT PRIVACY: Masked/secured UID only
        uid: driver.phone ? driver.phone.replace(/[^0-9]/g, '') : (driver.id || 'driver'),
        privatePhoneRef: driver.phone,
        actionCategory: 'transport',
        originalItem: driver
      };

      if (isExact) {
        matchedCards.push(card);
      } else if (isNearby) {
        nearbyCards.push(card);
      }
    });
  }

  // CATEGORY 2: Return Transport (ফিরতি পরিবহন)
  else if (parsed.detectedCategory === 'return_transport') {
    const rides = datasets.returnRides || [];
    rides.forEach((ride) => {
      if (ride.status === 'completed' || ride.status === 'cancelled') return;

      const matchesOrigin = isMatchDist(ride.fromDistrict) && (isMatchUpz(ride.fromUpazila) || !ride.fromUpazila);
      const matchesDest = isMatchDist(ride.toDistrict) && (isMatchUpz(ride.toUpazila) || !ride.toUpazila);

      const isExact = matchesOrigin || matchesDest;
      const isNearby = !isExact && (ride.fromDistrict === targetDist || ride.toDistrict === targetDist);

      const card: AIProviderCard = {
        id: `return-${ride.id}`,
        name: ride.creatorName || 'সম্মানিত চালক',
        roleLabel: `ফিরতি গাড়ি (${ride.vehicleType})`,
        avatar: ride.creatorAvatar,
        category: 'return_transport',
        district: ride.fromDistrict,
        upazila: ride.fromUpazila || ride.fromLocation,
        unionOrArea: `রুট: ${ride.fromLocation} ➔ ${ride.toLocation}`,
        highlightDetail: `সিট: ${ride.capacity} • সময়: ${ride.departureDate} (${ride.departureTime}) • ভাড়া: ${ride.fareType === 'fixed' ? `${ride.fareAmount} টাকা` : 'আলোচনা সাপেক্ষে'}`,
        availabilityBadge: '🔵 খালি ফিরতি গাড়ি',
        uid: ride.creatorPhone ? ride.creatorPhone.replace(/[^0-9]/g, '') : (ride.creatorId || 'ride'),
        privatePhoneRef: ride.creatorPhone,
        actionCategory: 'transport',
        originalItem: ride
      };

      if (isExact) matchedCards.push(card);
      else if (isNearby) nearbyCards.push(card);
    });
  }

  // CATEGORY 3: Honey & Haat Produce (মধু ও কৃষিপণ্য বিক্রেতা)
  else if (parsed.detectedCategory === 'honey_seller' || parsed.detectedCategory === 'haat_produce') {
    const items = datasets.haatItems || [];
    const isHoney = parsed.detectedCategory === 'honey_seller';

    items.forEach((item) => {
      if (item.isSold || item.isHidden) return;
      const itemTitle = (item.title || '').toLowerCase();
      const itemCat = (item.category || '').toLowerCase();
      const itemDesc = (item.description || '').toLowerCase();

      if (isHoney && !itemTitle.includes('মধু') && !itemDesc.includes('মধু')) return;

      const isExact = isMatchDist(item.district) && isMatchUpz(item.upazila);
      const isNearby = isMatchDist(item.district) && !isExact;

      const card: AIProviderCard = {
        id: `haat-${item.id}`,
        name: item.sellerName || 'কৃষক ও বিক্রেতা',
        roleLabel: isHoney ? 'খাঁটি মধু বিক্রেতা' : (item.itemType || item.category || 'পণ্য বিক্রেতা'),
        avatar: item.imageUrl,
        category: 'marketplace',
        district: item.district || targetDist,
        upazila: item.upazila || targetUpz,
        unionOrArea: item.unionOrWard || item.location || 'স্থানীয় হাট',
        highlightDetail: `পণ্য: ${item.title} • দর: ৳${item.price}/${item.unit} • পরিমাণ: ${item.quantity || 'মজুদ আছে'}`,
        availabilityBadge: '🥬 তাজা ও বিষমুক্ত',
        uid: item.phone ? item.phone.replace(/[^0-9]/g, '') : (item.id || 'seller'),
        privatePhoneRef: item.phone,
        actionCategory: 'marketplace',
        subTab: 'products',
        originalItem: item
      };

      if (isExact) matchedCards.push(card);
      else if (isNearby) nearbyCards.push(card);
    });
  }

  // CATEGORY 4: Blood Donors (রক্তের ডোনার)
  else if (parsed.detectedCategory === 'blood_donor') {
    const donors = datasets.bloodDonors || [];
    const grp = parsed.bloodGroup;

    donors.forEach((donor) => {
      if (grp && donor.bloodGroup !== grp) return;

      const isExact = isMatchDist(donor.district) && isMatchUpz(donor.upazila);
      const isNearby = isMatchDist(donor.district) && !isExact;

      const card: AIProviderCard = {
        id: `donor-${donor.id}`,
        name: donor.name || 'রক্তদাতা ভাই',
        roleLabel: `🩸 ${donor.bloodGroup} রক্তদাতা`,
        category: 'health',
        district: donor.district || targetDist,
        upazila: donor.upazila || targetUpz,
        unionOrArea: donor.villageOrArea || 'নিকটস্থ এলাকা',
        highlightDetail: `গ্রুপ: ${donor.bloodGroup} • মোট দান: ${donor.totalDonations || 1} বার • অবস্থা: ${donor.isAvailable ? 'রক্তদানে প্রস্তুত' : 'সাময়িক বিরতি'}`,
        availabilityBadge: donor.isAvailable ? '🟢 রক্তদানে প্রস্তুত' : '🟡 বিরতি',
        uid: donor.phone ? donor.phone.replace(/[^0-9]/g, '') : (donor.id || 'donor'),
        privatePhoneRef: donor.phone,
        actionCategory: 'health',
        subTab: 'donors',
        originalItem: donor
      };

      if (isExact) matchedCards.push(card);
      else if (isNearby) nearbyCards.push(card);
    });
  }

  // CATEGORY 5: Housing Rentals (বাসা ও মেস ভাড়া)
  else if (parsed.detectedCategory === 'housing_rental') {
    const housings = datasets.housingListings || [];
    housings.forEach((h) => {
      if (h.status !== 'approved' && h.status !== 'active') return;

      const isExact = isMatchDist(h.district) && isMatchUpz(h.upazila);
      const isNearby = isMatchDist(h.district) && !isExact;

      const card: AIProviderCard = {
        id: `housing-${h.id}`,
        name: h.ownerName || 'বাড়িওয়ালা',
        roleLabel: `বাসা ভাড়া (${h.propertyType})`,
        avatar: h.images?.[0],
        category: 'housing',
        district: h.district || targetDist,
        upazila: h.upazila || targetUpz,
        unionOrArea: h.unionOrWard || h.address || 'আবাসিক এলাকা',
        highlightDetail: `${h.title} • ভাড়া: ৳${h.rentAmount}/মাস • বেডরুম: ${h.bedrooms || 2}`,
        availabilityBadge: '🏠 খালি বাসা',
        uid: h.ownerPhone ? h.ownerPhone.replace(/[^0-9]/g, '') : (h.ownerId || 'housing'),
        privatePhoneRef: h.ownerPhone,
        actionCategory: 'housing',
        originalItem: h
      };

      if (isExact) matchedCards.push(card);
      else if (isNearby) nearbyCards.push(card);
    });
  }

  // CATEGORY 6: Day Laborers & Agricultural Workers (দিনমজুর ও কৃষি শ্রমিক)
  else if (parsed.detectedCategory === 'day_labor') {
    // 1. Check registered users with role laborer
    const users = datasets.registeredUsers || [];
    users.forEach((u) => {
      const r = (u.role || '').toLowerCase();
      const isLaborer = r.includes('labor') || r.includes('শ্রমিক') || r.includes('কৃষক') || r.includes('দিনমজুর');
      if (!isLaborer) return;

      const isExact = isMatchDist(u.district) && isMatchUpz(u.upazila);
      const isNearby = isMatchDist(u.district) && !isExact;

      const card: AIProviderCard = {
        id: `labor-${u.id}`,
        name: u.name || 'সম্মানিত শ্রমিক',
        roleLabel: '🌾 অভিজ্ঞ দিনমজুর ও কৃষি শ্রমিক',
        avatar: u.customAvatarUrl,
        category: 'labor',
        district: u.district || targetDist,
        upazila: u.upazila || targetUpz,
        unionOrArea: u.union || u.village || 'এলাকা',
        highlightDetail: `দক্ষতা: ধান কাটা, জমি তৈরি, রোপণ ও ভারী কাজ • রেটিং: ★ ৪.৮`,
        availabilityBadge: '🌾 বুকিংয়ের জন্য প্রস্তুত',
        uid: u.phone ? u.phone.replace(/[^0-9]/g, '') : (u.id || 'labor'),
        privatePhoneRef: u.phone,
        actionCategory: 'marketplace',
        subTab: 'labor',
        originalItem: u
      };

      if (isExact) matchedCards.push(card);
      else if (isNearby) nearbyCards.push(card);
    });

    // 2. Also check haat items with labor category
    const items = datasets.haatItems || [];
    items.forEach((item) => {
      if (item.category === 'কৃষিন ও দিনমজুর শ্রমিক' || item.laborType) {
        const isExact = isMatchDist(item.district) && isMatchUpz(item.upazila);
        const card: AIProviderCard = {
          id: `labor-haat-${item.id}`,
          name: item.sellerName || 'শ্রমিক দলনেতা',
          roleLabel: item.workType || 'কৃষি শ্রমিক দল',
          category: 'labor',
          district: item.district || targetDist,
          upazila: item.upazila || targetUpz,
          unionOrArea: item.unionOrWard || 'ইউনিয়ন',
          highlightDetail: `দল: ${item.teamSize || '৫ জন'} • মজুরি: ৳${item.price} • কাজ: ${item.workType || 'ফসল কাটা'}`,
          availabilityBadge: '🟢 সরাসরি বুকিং',
          uid: item.phone ? item.phone.replace(/[^0-9]/g, '') : (item.id || 'labor'),
          privatePhoneRef: item.phone,
          actionCategory: 'marketplace',
          subTab: 'labor',
          originalItem: item
        };
        if (isExact) matchedCards.push(card);
      }
    });
  }

  // CATEGORY 7: Tutors & Teachers (গৃহশিক্ষক)
  else if (parsed.detectedCategory === 'tutor_teacher') {
    const users = datasets.registeredUsers || [];
    users.forEach((u) => {
      const r = (u.role || '').toLowerCase();
      const isTutor = r.includes('tutor') || r.includes('teacher') || r.includes('শিক্ষক') || (u.tutorInfo && u.tutorInfo.tutorType === 'teacher');
      if (!isTutor) return;

      const isExact = isMatchDist(u.district) && isMatchUpz(u.upazila);
      const isNearby = isMatchDist(u.district) && !isExact;

      const card: AIProviderCard = {
        id: `tutor-${u.id}`,
        name: u.name || 'সম্মানিত শিক্ষক',
        roleLabel: '📚 অভিজ্ঞ গৃহশিক্ষক',
        avatar: u.customAvatarUrl,
        category: 'tutor',
        district: u.district || targetDist,
        upazila: u.upazila || targetUpz,
        unionOrArea: u.union || 'পৌরসভা/ইউনিয়ন',
        highlightDetail: `বিষয়: গণিত, বিজ্ঞান ও ইংরেজি • শ্রেণি: ৫ম - ১০ম শ্রেণি`,
        availabilityBadge: '📖 নতুন ব্যাচ সচল',
        uid: u.phone ? u.phone.replace(/[^0-9]/g, '') : (u.id || 'tutor'),
        privatePhoneRef: u.phone,
        actionCategory: 'marketplace',
        subTab: 'tutors',
        originalItem: u
      };

      if (isExact) matchedCards.push(card);
      else if (isNearby) nearbyCards.push(card);
    });
  }

  // CATEGORY 8: Mechanics & Electricians (ইলেকট্রিশিয়ান ও মেকার)
  else if (parsed.detectedCategory === 'mechanic_electrician') {
    const users = datasets.registeredUsers || [];
    users.forEach((u) => {
      const r = (u.role || '').toLowerCase();
      const isMech = r.includes('mechanic') || r.includes('electrician') || r.includes('মেকানিক') || r.includes('কারিগর');
      if (!isMech) return;

      const isExact = isMatchDist(u.district) && isMatchUpz(u.upazila);
      const isNearby = isMatchDist(u.district) && !isExact;

      const card: AIProviderCard = {
        id: `mech-${u.id}`,
        name: u.name || 'অভিজ্ঞ মেকার',
        roleLabel: '🔧 ইলেকট্রিশিয়ান ও মেকানিক',
        avatar: u.customAvatarUrl,
        category: 'mechanic',
        district: u.district || targetDist,
        upazila: u.upazila || targetUpz,
        unionOrArea: u.union || 'বাজার ওয়ার্কশপ',
        highlightDetail: `দক্ষতা: ফ্যান-মোটর ওয়্যারিং, টিউবওয়েল ও পাম্প মেরামত • রেটিং: ★ ৪.৯`,
        availabilityBadge: '⚡ জরুরি সেবা সচল',
        uid: u.phone ? u.phone.replace(/[^0-9]/g, '') : (u.id || 'mech'),
        privatePhoneRef: u.phone,
        actionCategory: 'marketplace',
        subTab: 'mechanics',
        originalItem: u
      };

      if (isExact) matchedCards.push(card);
      else if (isNearby) nearbyCards.push(card);
    });

    // Also check haat items with mechanic category
    const items = datasets.haatItems || [];
    items.forEach((item) => {
      if (item.category === 'ইলেকট্রিশিয়ান ও মেকানিক' || (item.title && item.title.includes('মেকানিক'))) {
        const isExact = isMatchDist(item.district) && isMatchUpz(item.upazila);
        const card: AIProviderCard = {
          id: `mech-haat-${item.id}`,
          name: item.sellerName || 'দক্ষ মেকার',
          roleLabel: item.title || 'ইলেকট্রিশিয়ান',
          category: 'mechanic',
          district: item.district || targetDist,
          upazila: item.upazila || targetUpz,
          unionOrArea: item.unionOrWard || 'বাজার',
          highlightDetail: `সেবা: ${item.title} • ভিজিট ফি: ৳${item.price} • রেটিং: ★ ৫.০`,
          availabilityBadge: '🔧 তাৎক্ষণিক কল প্রস্তুত',
          uid: item.phone ? item.phone.replace(/[^0-9]/g, '') : (item.id || 'mech'),
          privatePhoneRef: item.phone,
          actionCategory: 'marketplace',
          subTab: 'mechanics',
          originalItem: item
        };
        if (isExact) matchedCards.push(card);
      }
    });
  }

  // CATEGORY 9: Doctors (ডাক্তার)
  else if (parsed.detectedCategory === 'doctor_health') {
    DOCTOR_SCHEDULES_DATA.forEach((doc) => {
      const isExact = isMatchDist(doc.district);
      const card: AIProviderCard = {
        id: `doc-${doc.id}`,
        name: doc.doctorName,
        roleLabel: `${doc.speciality} (${doc.designation})`,
        category: 'doctor',
        district: doc.district || targetDist,
        upazila: targetUpz,
        unionOrArea: doc.hospitalOrClinic,
        highlightDetail: `চেম্বার: ${doc.hospitalOrClinic} • সময়: ${doc.visitingHours} • ফি: ৳${doc.fee}`,
        availabilityBadge: '🏥 সিরিয়াল চালু',
        uid: `doc_${doc.id}`,
        actionCategory: 'health',
        subTab: 'doctors',
        originalItem: doc
      };
      if (isExact) matchedCards.push(card);
      else nearbyCards.push(card);
    });
  }

  // Deduplicate matched cards by unique identifier
  const uniqueMatched = Array.from(new Map(matchedCards.map(c => [c.uid + c.name, c])).values()).slice(0, 5);
  const uniqueNearby = Array.from(new Map(nearbyCards.map(c => [c.uid + c.name, c])).values()).slice(0, 4);

  // BUILD INTRO MESSAGES & FALLBACK RESPONSES
  let introMessage = '';
  let finalCards: AIProviderCard[] = [];
  let isFallback = false;
  let fallbackType: 'nearby_upazila' | 'no_providers_in_district' | undefined = undefined;
  const actions: Array<{ target: ServiceCategory; label: string; subTab?: string }> = [];

  const locationLabel = targetUnion 
    ? `${targetUnion}, ${targetUpz}, ${targetDist}` 
    : `${targetUpz}, ${targetDist}`;

  if (uniqueMatched.length > 0) {
    // SUCCESS CASE: Exact local matches found
    finalCards = uniqueMatched;
    introMessage = `আলহামদুলিল্লাহ! আপনার কাঙ্ক্ষিত এলাকা **${locationLabel}**-এ নিবন্ধিত **${parsed.categoryLabelBengali}** পাওয়া গেছে।\n\n🔒 **নিরাপত্তা ও গোপনীয়তা গাইড:** গ্রাহক ও সেবাদাতা উভয়ের ফোন নম্বর সম্পূর্ণ গোপন রাখতে নিচে সরাসরি **"ইন-অ্যাপ কল"** (ফ্রি ইন্টারনেট কল) অথবা **"চ্যাট"** বাটনে ট্যাপ করুন।`;

    if (parsed.detectedCategory === 'transport_cng' || parsed.detectedCategory === 'transport_general') {
      actions.push({ target: 'transport', label: '🚗 নিরাপদ চালক সেবায় সম্পূর্ণ তালিকা দেখুন' });
      actions.push({ target: 'transport', label: '📢 ফিরতি গাড়ি ও যাত্রী রিকোয়েস্ট' });
    } else if (parsed.detectedCategory === 'return_transport') {
      actions.push({ target: 'transport', label: '🚗 সকল ফিরতি পরিবহন ও খালি গাড়ি' });
      actions.push({ target: 'transport', label: '➕ ফিরতি গাড়ির পোস্ট দিন' });
    } else if (parsed.detectedCategory === 'honey_seller' || parsed.detectedCategory === 'haat_produce') {
      actions.push({ target: 'marketplace', label: '🛒 পল্লী হাটের সকল পণ্য দেখুন', subTab: 'products' });
      actions.push({ target: 'marketplace', label: '➕ হাটে আপনার পণ্য বিক্রি করুন' });
    } else if (parsed.detectedCategory === 'blood_donor') {
      actions.push({ target: 'health', label: '🩸 রক্তদাতা ডিরেক্টরি খুলুন', subTab: 'donors' });
      actions.push({ target: 'health', label: '🏥 জরুরি হাসপাতাল ও অ্যাম্বুলেন্স' });
    } else if (parsed.detectedCategory === 'housing_rental') {
      actions.push({ target: 'housing', label: '🏠 সকল বাসা ও মেস ভাড়া দেখুন' });
      actions.push({ target: 'housing', label: '➕ আপনার খালি বাসা পোস্ট করুন' });
    } else if (parsed.detectedCategory === 'day_labor') {
      actions.push({ target: 'marketplace', label: '🌾 দিনমজুর ও কৃষি শ্রমিক বোর্ড', subTab: 'labor' });
    } else if (parsed.detectedCategory === 'tutor_teacher') {
      actions.push({ target: 'marketplace', label: '📚 গৃহশিক্ষক ও শিক্ষার্থী বোর্ড', subTab: 'tutors' });
    } else if (parsed.detectedCategory === 'mechanic_electrician') {
      actions.push({ target: 'marketplace', label: '🔧 মেকার ও কারিগর বোর্ড', subTab: 'mechanics' });
    }
  } else if (uniqueNearby.length > 0) {
    // FALLBACK 1: Not found in specific upazila/union, but found in same district
    isFallback = true;
    fallbackType = 'nearby_upazila';
    finalCards = uniqueNearby;
    introMessage = `সম্মানিত ব্যবহারকারী, দুঃখিত! আপনার নির্দিষ্ট এলাকা **${locationLabel}**-এ এই মুহূর্তে কোনো নিবন্ধিত **${parsed.categoryLabelBengali}** পাওয়া যায়নি।\n\nতবে একই **${targetDist}** জেলার নিকটস্থ উপজেলায় নিবন্ধিত সেবাদাতাদের তালিকা নিচে দেওয়া হলো। আপনি চাইলে সরাসরি এদের সাথে নিরাপদ সংযোগে যোগাযোগ করতে পারেন অথবা আপনার এলাকায় প্রয়োজন জানিয়ে একটি পোস্ট দিতে পারেন:`;

    actions.push({ target: 'services', label: '📢 চাহিদাসম্পন্ন পোস্ট দিন' });
    if (parsed.detectedCategory.includes('transport')) {
      actions.push({ target: 'transport', label: '🚗 পরিবহন ডিরেক্টরিতে যান' });
    } else if (parsed.detectedCategory.includes('honey') || parsed.detectedCategory.includes('haat')) {
      actions.push({ target: 'marketplace', label: '🛒 পল্লী হাট খুলুন' });
    } else if (parsed.detectedCategory.includes('blood')) {
      actions.push({ target: 'health', label: '🩸 রক্তদাতা তালিকায় যান' });
    } else {
      actions.push({ target: 'services', label: '📋 সকল সেবা তালিকা দেখুন' });
    }
  } else {
    // FALLBACK 2: None in district
    isFallback = true;
    fallbackType = 'no_providers_in_district';
    finalCards = [];
    introMessage = `সম্মানিত ব্যবহারকারী, দুঃখিত!\n\nআপনার কাঙ্ক্ষিত এলাকা **${locationLabel}**-এ বর্তমানে কোনো নিবন্ধিত **${parsed.categoryLabelBengali}** পাওয়া যায়নি।\n\n💡 **বিকল্প পরামর্শ:**\n• আপনি অ্যাপের সংশ্লিষ্ট বিভাগে গিয়ে একটি সরাসরি **"চাহিদা বিজ্ঞাপন"** দিতে পারেন, যাতে ওই এলাকার সেবাদাতারা নোটিফিকেশন পেয়ে দ্রুত যোগাযোগ করতে পারেন।\n• অথবা পার্শ্ববর্তী জেলা/উপজেলার তালিকা দেখতে পারেন।`;

    actions.push({ target: 'services', label: '📢 এই সেবায় একটি পোস্ট রিকোয়েস্ট করুন' });
    actions.push({ target: 'services', label: '📋 ২৬টি নাগরিক সেবা ডিরেক্টরি' });
    if (parsed.detectedCategory.includes('transport')) {
      actions.push({ target: 'transport', label: '🚗 নিরাপদ পরিবহন সেবায় যান' });
    } else if (parsed.detectedCategory.includes('honey') || parsed.detectedCategory.includes('haat')) {
      actions.push({ target: 'marketplace', label: '🛒 পল্লী হাটে পণ্য খুঁজুন' });
    } else if (parsed.detectedCategory.includes('blood')) {
      actions.push({ target: 'health', label: '🩸 রক্তদাতা ও হাসপাতাল' });
    }
  }

  return {
    isSearchQuery: true,
    parsed,
    cards: finalCards,
    isFallback,
    fallbackType,
    introMessage,
    actions
  };
}
