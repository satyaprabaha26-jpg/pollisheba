/**
 * Polli Sheba System-wide Push Notifications & Audio Chime Service
 * Supports Service Worker Background Push, High Priority Channel, and Deep Linking
 */

export interface SystemNotificationPayload {
  title: string;
  body: string;
  icon?: string;
  tag?: string;
  sound?: boolean;
  targetCategory?: string;
  subTab?: string;
  actionUrl?: string;
  data?: Record<string, any>;
}

/**
 * Play a high-priority, pleasant notification alert chime using Web Audio API
 */
export function playNotificationChime(): void {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();

    const now = ctx.currentTime;
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    // Two-tone cheerful announcement chime (E5 -> G#5)
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(659.25, now); // E5
    osc1.frequency.setValueAtTime(830.61, now + 0.12); // G#5

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1318.51, now); // E6 harmonic
    osc2.frequency.setValueAtTime(1661.22, now + 0.12);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.6);
    osc2.stop(now + 0.6);

    setTimeout(() => {
      try {
        if (ctx.state !== 'closed') ctx.close();
      } catch (e) {}
    }, 800);
  } catch (e) {
    console.warn('Notification chime note:', e);
  }
}

/**
 * Request notification permissions from user
 */
export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }

  if (Notification.permission === 'granted') {
    return 'granted';
  }

  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch (err) {
    console.warn('Notification permission request error:', err);
    return Notification.permission;
  }
}

/**
 * Trigger a system-wide high-priority notification (shutter / heads-up notification)
 */
export async function sendSystemNotification(payload: SystemNotificationPayload): Promise<void> {
  if (typeof window === 'undefined') return;

  // 1. Play audible sound chime if sound enabled (default true)
  if (payload.sound !== false) {
    playNotificationChime();
  }

  // 2. Build deep link target
  let deepLinkUrl = payload.actionUrl || '/';
  if (payload.targetCategory) {
    deepLinkUrl = `/?category=${encodeURIComponent(payload.targetCategory)}${payload.subTab ? `&subtab=${encodeURIComponent(payload.subTab)}` : ''}`;
  }

  // 3. Check Web Notification API
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      // Prefer ServiceWorkerRegistration.showNotification if SW is active
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.getRegistration();
        if (registration && registration.showNotification) {
          await (registration as any).showNotification(payload.title, {
            body: payload.body,
            icon: payload.icon || '/logo.png',
            badge: '/logo.png',
            tag: payload.tag || `notif-${Date.now()}`,
            vibrate: [300, 100, 300, 100, 400],
            requireInteraction: true,
            renotify: true,
            data: {
              url: deepLinkUrl,
              targetCategory: payload.targetCategory,
              subTab: payload.subTab,
              ...payload.data
            }
          });
          return;
        }
      }

      // Fallback to standard window Notification
      const notif = new Notification(payload.title, {
        body: payload.body,
        icon: payload.icon || '/logo.png',
        tag: payload.tag || `notif-${Date.now()}`,
        data: { url: deepLinkUrl }
      });

      notif.onclick = () => {
        window.focus();
        // Dispatch in-app deep link event
        window.dispatchEvent(new CustomEvent('polli_deep_link', {
          detail: {
            targetCategory: payload.targetCategory,
            subTab: payload.subTab,
            url: deepLinkUrl
          }
        }));
        if (deepLinkUrl && deepLinkUrl !== '/' && window.location.pathname !== deepLinkUrl) {
          window.location.href = deepLinkUrl;
        }
        notif.close();
      };
    } catch (err) {
      console.warn('System notification display note:', err);
    }
  }
}

/**
 * Trigger a high-priority incoming call foreground notification alert
 * Operates across screen lock, background tabs, and other apps with action buttons
 */
export async function showIncomingCallForegroundAlert(session: {
  channelId: string;
  callerName: string;
  callerRole?: string;
  callerAvatar?: string;
  callerPhone?: string;
}): Promise<void> {
  if (typeof window === 'undefined') return;

  const title = `📞 ইনকামিং অডিও কল: ${session.callerName || 'পল্লী সেবা'}`;
  const body = `পল্লী সেবা ফ্রি ইন্টারনেট কল আসছে। কথা বলতে রিসিভ করুন।`;
  const tag = `polli-incoming-call-${session.channelId}`;

  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.getRegistration();
        if (registration && registration.showNotification) {
          await (registration as any).showNotification(title, {
            body,
            icon: session.callerAvatar || '/logo.png',
            badge: '/logo.png',
            tag,
            vibrate: [600, 200, 600, 200, 800, 300, 1000],
            requireInteraction: true,
            renotify: true,
            silent: false,
            data: {
              type: 'INCOMING_CALL',
              channelId: session.channelId,
              session,
              url: `/?action=accept_call&channelId=${encodeURIComponent(session.channelId)}`
            },
            actions: [
              { action: 'accept_call', title: '📞 রিসিভ করুন' },
              { action: 'reject_call', title: '❌ বাতিল' }
            ]
          });
          return;
        }
      }

      // Fallback
      const notif = new Notification(title, {
        body,
        icon: session.callerAvatar || '/logo.png',
        tag,
        requireInteraction: true
      });
      notif.onclick = () => {
        window.focus();
        window.dispatchEvent(new CustomEvent('polli_accept_incoming_call', {
          detail: { channelId: session.channelId }
        }));
        notif.close();
      };
    } catch (e) {
      console.warn('Incoming call notification error:', e);
    }
  }
}

/**
 * Dismiss incoming call notification when call is answered, rejected, or missed
 */
export async function dismissIncomingCallAlert(channelId: string): Promise<void> {
  if (typeof window === 'undefined') return;
  const tag = `polli-incoming-call-${channelId}`;

  try {
    if ('serviceWorker' in navigator) {
      const registration = await navigator.serviceWorker.getRegistration();
      if (registration && registration.getNotifications) {
        const notifs = await registration.getNotifications({ tag });
        notifs.forEach(n => n.close());
      }
    }
  } catch {}
}

/**
 * Checks for newly arrived targeted notifications and triggers real-time heads-up alerts
 * exactly like WhatsApp / Messenger / YouTube when data/internet connection is active.
 */
export function checkAndDispatchBackgroundAlerts(
  notifications: any[],
  isTargetedFn: (notif: any) => boolean
): number {
  if (typeof window === 'undefined' || !Array.isArray(notifications) || notifications.length === 0) {
    return 0;
  }

  let shownIds: string[] = [];
  try {
    shownIds = JSON.parse(localStorage.getItem('polli_shown_system_notifications') || '[]');
  } catch {
    shownIds = [];
  }

  let newlyTriggeredCount = 0;
  const newShownIds = [...shownIds];

  // Process only fresh unread notifications (e.g. within last 24 hours)
  const now = Date.now();
  const freshNotifications = notifications.filter(n => {
    const age = now - (n.createdAtTimestamp || n.createdAt || now);
    return age < 24 * 60 * 60 * 1000;
  });

  for (const notif of freshNotifications) {
    if (!notif.id || newShownIds.includes(notif.id)) continue;

    // Check if notification is targeted to this user's area and preferences
    if (isTargetedFn(notif)) {
      newShownIds.push(notif.id);
      newlyTriggeredCount++;

      // Trigger system-level heads up notification with sound & vibration
      sendSystemNotification({
        title: `🌾 ${notif.title || 'পল্লী সেবা নতুন বিজ্ঞপ্তি'}`,
        body: notif.message || notif.description || 'আপনার নির্বাচিত এলাকায় একটি নতুন সেবা বা নোটিফিকেশন যুক্ত হয়েছে। বিস্তারিত দেখতে ট্যাপ করুন।',
        icon: '/logo.png',
        tag: `polli-alert-${notif.id}`,
        sound: true,
        targetCategory: notif.targetCategory || 'account',
        subTab: typeof notif.targetSubTab === 'string' ? notif.targetSubTab : notif.targetSubTab?.main,
        data: {
          notifId: notif.id,
          district: notif.targetDistrict,
          upazila: notif.targetUpazila
        }
      });
    }
  }

  if (newlyTriggeredCount > 0) {
    // Keep max 150 tracked shown IDs
    localStorage.setItem('polli_shown_system_notifications', JSON.stringify(newShownIds.slice(-150)));
  }

  return newlyTriggeredCount;
}
