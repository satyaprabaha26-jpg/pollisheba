/**
 * পল্লী সেবা (Polli Sheba) - ডায়নামিক দূরত্ব ও সম্ভাব্য ভাড়া ক্যালকুলেটর
 * 
 * লজিক নিয়মাবলী:
 * ১. গন্তব্য (Destination) না দিলে কোনো দূরত্ব বা ভাড়া হিসাব হবে না; সরাসরি "আলোচনা সাপেক্ষে" দেখাবে।
 * ২. বিশেষ যানবাহন (হেস্কোভেটর, পাওয়ার ট্রিলার, নৌকার মাঝি): কিমি হিসাব প্রযোজ্য নয়; সময়/বিঘা/চুক্তি বা আলোচনা সাপেক্ষে।
 * ৩. স্ট্যান্ডার্ড বাহন (বাইক, সিএনজি, ইজিবাইক, কার, মাইক্রো, অ্যাম্বুলেন্স):
 *    - চালকের নিজস্ব কিমি রেট (ঐচ্ছিক) অথবা গাড়ির আদর্শ রেট ও বেস ফেয়ার অনুযায়ী হিসাব হবে।
 */

import { DriverFareProfile } from '../types/registration';

export interface FareCalculationParams {
  vehicleType: string;
  subCategory?: string;
  driverFareProfile?: DriverFareProfile | null;
  pickupLocation?: string;
  destinationLocation?: string;
  distanceKm?: number; // যদি গন্তব্য সিলেক্ট থাকে এবং দূরত্ব জানা থাকে
  isNightTime?: boolean;
}

export interface FareEstimateResult {
  isCalculated: boolean;
  fareDisplayBn: string;
  fareDisplayEn: string;
  reasonBn: string;
  reasonEn: string;
  estimatedAmountMin?: number;
  estimatedAmountMax?: number;
  ratePerKmApplied?: number;
  isSpecialVehicle: boolean;
  pricingType: 'negotiable' | 'calculated_per_km' | 'special_contract';
}

// বিশেষ যানবাহনসমূহের শনাক্তকারী তালিকা
const SPECIAL_VEHICLES_REGEX = /(হেস্কোভেটর|এক্সকাভেটর|ট্র্যাক্টর|পাওয়ার\s*টিলার|পাওয়ার\s*ট্রিলার|নৌকা|মাঝি|খেয়া|হার্ভেস্টার|excavator|tiller|tractor|boatman)/i;

// গাড়ির ধরন অনুযায়ী স্ট্যান্ডার্ড বেস রেট (যদি চালক নিজে নির্দিষ্ট না করে থাকেন)
const DEFAULT_VEHICLE_BASE_RATES: Record<string, { baseFare: number; perKm: number }> = {
  bike: { baseFare: 30, perKm: 15 },
  cng: { baseFare: 40, perKm: 20 },
  easybike: { baseFare: 20, perKm: 12 },
  van: { baseFare: 15, perKm: 10 },
  private_car: { baseFare: 100, perKm: 35 },
  microbus: { baseFare: 150, perKm: 45 },
  ambulance: { baseFare: 300, perKm: 50 },
};

/**
 * বাংলা সংখ্যা রূপান্তর হেল্পার
 */
export const toBnNumber = (num: number | string): string => {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/\d/g, (d) => bnDigits[parseInt(d, 10)] || d);
};

/**
 * ডায়নামিক ভাড়া হিসাব করার মূল ফাংশন
 */
export function calculateDynamicFare(params: FareCalculationParams): FareEstimateResult {
  const {
    vehicleType,
    subCategory,
    driverFareProfile,
    destinationLocation,
    distanceKm,
    isNightTime = false
  } = params;

  // ১. বিশেষ যানবাহন কি না পরীক্ষা (হেস্কোভেটর, পাওয়ার ট্রিলার, নৌকার মাঝি)
  const isSpecial = 
    (subCategory && ['excavator', 'power_tiller', 'boatman'].includes(subCategory)) ||
    SPECIAL_VEHICLES_REGEX.test(vehicleType);

  if (isSpecial) {
    const customSpecialRate = driverFareProfile?.specialUnitRateText || 'আলোচনা সাপেক্ষে (ঘণ্টা / বিঘা / চুক্তি)';
    return {
      isCalculated: false,
      fareDisplayBn: customSpecialRate,
      fareDisplayEn: 'Negotiable (Per Hour / Bigha / Contract)',
      reasonBn: 'বিশেষ কৃষিজ ও মাটি কাটার যানে কিমি হিসাব প্রযোজ্য নয়, কাজের ধরন অনুযায়ী চুক্তি হয়।',
      reasonEn: 'Km calculation is not applicable for special machinery; charged per hour or agreement.',
      isSpecialVehicle: true,
      pricingType: 'special_contract'
    };
  }

  // ২. ইউজার যদি গন্তব্য (Destination) সিলেক্ট না করেন
  if (!destinationLocation || !destinationLocation.trim() || !distanceKm || distanceKm <= 0) {
    return {
      isCalculated: false,
      fareDisplayBn: 'আলোচনা সাপেক্ষে',
      fareDisplayEn: 'Negotiable / To be discussed',
      reasonBn: 'গন্তব্য নির্দিষ্ট করা হয়নি। দূরত্ব অনুযায়ী ভাড়া নির্ধারণের জন্য গন্তব্য নির্বাচন করুন।',
      reasonEn: 'No destination selected. Select destination to estimate fare.',
      isSpecialVehicle: false,
      pricingType: 'negotiable'
    };
  }

  // ৩. চালক যদি স্পষ্টভাবে শুধুমাত্র "আলোচনা সাপেক্ষে" পছন্দ করে থাকেন
  if (driverFareProfile?.fareType === 'negotiable' && !driverFareProfile?.ratePerKm) {
    return {
      isCalculated: false,
      fareDisplayBn: 'আলোচনা সাপেক্ষে (চালকের পছন্দ)',
      fareDisplayEn: 'Negotiable (Driver Preference)',
      reasonBn: 'এই চালক দূরত্ব অনুযায়ী ভাড়ার বদলে যাত্রীর সাথে সরাসরি আলোচনা করতে স্বাচ্ছন্দ্যবোধ করেন।',
      reasonEn: 'Driver prefers direct discussion rather than fixed rate calculation.',
      isSpecialVehicle: false,
      pricingType: 'negotiable'
    };
  }

  // ৪. দূরত্ব এবং গাড়ির ধরন অনুযায়ী সম্ভাব্য ভাড়া হিসাব
  const defaultRate = DEFAULT_VEHICLE_BASE_RATES[subCategory || ''] || { baseFare: 30, perKm: 18 };
  const perKmRate = driverFareProfile?.ratePerKm && driverFareProfile.ratePerKm > 0 
    ? driverFareProfile.ratePerKm 
    : defaultRate.perKm;

  const baseFare = driverFareProfile?.baseFare && driverFareProfile.baseFare > 0 
    ? driverFareProfile.baseFare 
    : defaultRate.baseFare;

  // দূরত্ব অনুযায়ী প্রাথমিক ফেয়ার
  let calculatedAmount = baseFare + (distanceKm * perKmRate);

  // রাতে ১০-১৫% অতিরিক্ত সহনশীল চার্জ হিসাব (যদি প্রযোজ্য হয়)
  if (isNightTime) {
    calculatedAmount *= 1.15;
  }

  // রাউন্ড ফিগারে একটি সম্ভাব্য রেঞ্জ তৈরি (±১০%)
  const minFare = Math.round((calculatedAmount * 0.95) / 5) * 5;
  const maxFare = Math.round((calculatedAmount * 1.10) / 5) * 5;

  return {
    isCalculated: true,
    fareDisplayBn: `আনুমানিক ৳${toBnNumber(minFare)} - ৳${toBnNumber(maxFare)}`,
    fareDisplayEn: `Approx ৳${minFare} - ৳${maxFare}`,
    reasonBn: `দূরত্ব: প্রায় ${toBnNumber(distanceKm.toFixed(1))} কিমি (প্রতি কিমি ৳${toBnNumber(perKmRate)})`,
    reasonEn: `Distance: ~${distanceKm.toFixed(1)} km (৳${perKmRate}/km applied)`,
    estimatedAmountMin: minFare,
    estimatedAmountMax: maxFare,
    ratePerKmApplied: perKmRate,
    isSpecialVehicle: false,
    pricingType: 'calculated_per_km'
  };
}
