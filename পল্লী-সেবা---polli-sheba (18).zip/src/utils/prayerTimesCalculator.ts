import { toBanglaNumber } from './banglaNumbers';
import { DISTRICT_PRAYER_OFFSETS } from '../data/extendedData';

export interface PrayerTimeItem {
  name: string;
  banglaName: string;
  icon: string;
  hour: number;
  minute: number;
  totalMinutes: number;
  formattedTime: string; // e.g. "১২:০৫"
  periodLabel: string; // "সকাল/দুপুর/বিকাল/রাত"
}

export interface DailyPrayerSchedule {
  fajr: PrayerTimeItem;
  sunrise: PrayerTimeItem;
  dhuhr: PrayerTimeItem;
  asr: PrayerTimeItem;
  maghrib: PrayerTimeItem;
  isha: PrayerTimeItem;
  tahajjud: PrayerTimeItem;
  offsetMinutes: number;
  district: string;
}

export interface WaqtCountdownStatus {
  targetWaqtName: string;
  currentWaqtName: string;
  targetPhrase: string; // e.g. "যোহরের ওয়াক্তের বাকি: ৫ ঘণ্টা ২০ মিনিট"
  hours: number;
  minutes: number;
  seconds: number;
  remainingTotalSeconds: number;
  elapsedPercent: number;
  nextStartTimeFormatted: string;
  isAfterMaghrib: boolean;
}

export interface HijriDateInfo {
  day: number;
  month: number;
  year: number;
  dayBangla: string;
  monthNameBangla: string;
  yearBangla: string;
  fullBanglaDate: string; // e.g. "১২ রবিউল আউয়াল, ১৪৪৮ হিজরী"
  isAfterMaghrib: boolean;
}

// Arabic Hijri months in Bengali
export const HIJRI_MONTHS_BANGLA = [
  'মুহাররম',
  'সফর',
  'রবিউল আউয়াল',
  'রবিউস সানি',
  'জমাদিউল আউয়াল',
  'জমাদিউস সানি',
  'রজব',
  'শাবান',
  'রমজান',
  'শাওয়াল',
  'জিলকদ',
  'জিলহজ'
];

// Normalize Bengali district names (handling ড়/ড়, য়/য়, ণ/ন, etc.)
export function normalizeDistrictName(name: string): string {
  if (!name) return 'ঢাকা';
  const clean = name.trim().replace(' জেলা', '');
  // Map common variants
  const map: Record<string, string> = {
    'বগুড়া': 'বগুড়া',
    'নারায়ণগঞ্জ': 'নারায়ণগঞ্জ',
    'রাজবাড়ী': 'রাজবাড়ী',
    'শরীয়তপুর': 'শরীয়তপুর',
    'ব্রাহ্মণবাড়িয়া': 'ব্রাহ্মণবাড়িয়া',
    'কুড়িগ্রাম': 'কুড়িগ্রাম',
    'পঞ্চগড়': 'পঞ্চগড়'
  };
  return map[clean] || clean;
}

// Format 24h total minutes to Bengali display time
export function formatMinutesToBanglaTime(totalMinutes: number): { formattedTime: string; periodLabel: string } {
  let m = totalMinutes % (24 * 60);
  if (m < 0) m += 24 * 60;
  let h = Math.floor(m / 60);
  let min = m % 60;

  let periodLabel = 'সকাল';
  if (h >= 4 && h < 6) periodLabel = 'ভোর';
  else if (h >= 6 && h < 12) periodLabel = 'সকাল';
  else if (h >= 12 && h < 15) periodLabel = 'দুপুর';
  else if (h >= 15 && h < 18) periodLabel = 'বিকাল';
  else if (h >= 18 && h < 20) periodLabel = 'সন্ধ্যা';
  else periodLabel = 'রাত';

  const displayH = h % 12 === 0 ? 12 : h % 12;
  const padMin = min < 10 ? `০${toBanglaNumber(min)}` : toBanglaNumber(min);
  return {
    formattedTime: `${toBanglaNumber(displayH)}:${padMin}`,
    periodLabel
  };
}

/**
 * Calculates accurate Bangladesh prayer times for a given date and district.
 * Uses monthly interpolated baseline for Dhaka, then applies 64-district official offsets.
 */
export function calculateDailyPrayerSchedule(date: Date, districtName: string): DailyPrayerSchedule {
  const normDist = normalizeDistrictName(districtName);
  const offsetObj = DISTRICT_PRAYER_OFFSETS[normDist] || { fajar: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 };

  const month = date.getMonth(); // 0 = Jan, 11 = Dec
  const day = date.getDate();

  // Islamic Foundation Bangladesh monthly mid-month baseline for Dhaka (hours, minutes)
  // Interpolated smoothly by day of month
  const monthlyDhakaBase = [
    { f: [5, 20], s: [6, 43], d: [12, 8], a: [15, 52], m: [17, 35], i: [18, 54], t: [3, 45] }, // Jan
    { f: [5, 10], s: [6, 32], d: [12, 12], a: [16, 12], m: [17, 55], i: [19, 10], t: [3, 35] }, // Feb
    { f: [4, 48], s: [6, 8], d: [12, 8], a: [16, 26], m: [18, 10], i: [19, 24], t: [3, 15] }, // Mar
    { f: [4, 18], s: [5, 39], d: [12, 1], a: [16, 32], m: [18, 22], i: [19, 38], t: [2, 50] }, // Apr
    { f: [3, 56], s: [5, 18], d: [11, 58], a: [16, 38], m: [18, 37], i: [19, 57], t: [2, 30] }, // May
    { f: [3, 48], s: [5, 11], d: [12, 1], a: [16, 47], m: [18, 49], i: [20, 12], t: [2, 25] }, // Jun
    { f: [3, 55], s: [5, 18], d: [12, 5], a: [16, 49], m: [18, 49], i: [20, 11], t: [2, 35] }, // Jul
    { f: [4, 12], s: [5, 32], d: [12, 4], a: [16, 38], m: [18, 32], i: [19, 51], t: [2, 55] }, // Aug
    { f: [4, 26], s: [5, 46], d: [11, 58], a: [16, 18], m: [18, 3], i: [19, 20], t: [3, 10] }, // Sep
    { f: [4, 40], s: [5, 58], d: [11, 50], a: [15, 56], m: [17, 34], i: [18, 51], t: [3, 25] }, // Oct
    { f: [4, 58], s: [6, 18], d: [11, 49], a: [15, 42], m: [17, 15], i: [18, 34], t: [3, 40] }, // Nov
    { f: [5, 15], s: [6, 36], d: [11, 58], a: [15, 44], m: [17, 15], i: [18, 37], t: [3, 50] }  // Dec
  ];

  const currBase = monthlyDhakaBase[month];
  const nextMonthIdx = (month + 1) % 12;
  const nextBase = monthlyDhakaBase[nextMonthIdx];
  const factor = Math.min(Math.max((day - 1) / 30, 0), 1);

  const interpolateMin = (curr: number[], next: number[]) => {
    const cTotal = curr[0] * 60 + curr[1];
    const nTotal = next[0] * 60 + next[1];
    return Math.round(cTotal + (nTotal - cTotal) * factor);
  };

  const fajrMin = interpolateMin(currBase.f, nextBase.f) + (offsetObj.fajar || 0);
  const sunriseMin = interpolateMin(currBase.s, nextBase.s) + (offsetObj.sunrise || 0);
  const dhuhrMin = interpolateMin(currBase.d, nextBase.d) + (offsetObj.dhuhr || 0);
  const asrMin = interpolateMin(currBase.a, nextBase.a) + (offsetObj.asr || 0);
  const maghribMin = interpolateMin(currBase.m, nextBase.m) + (offsetObj.maghrib || 0);
  const ishaMin = interpolateMin(currBase.i, nextBase.i) + (offsetObj.isha || 0);
  const tahajjudMin = interpolateMin(currBase.t, nextBase.t) + (offsetObj.fajar || 0);

  const makeItem = (name: string, banglaName: string, icon: string, totalMin: number): PrayerTimeItem => {
    const { formattedTime, periodLabel } = formatMinutesToBanglaTime(totalMin);
    return {
      name,
      banglaName,
      icon,
      hour: Math.floor(totalMin / 60) % 24,
      minute: totalMin % 60,
      totalMinutes: totalMin,
      formattedTime,
      periodLabel
    };
  };

  return {
    fajr: makeItem('Fajr', 'ফজর', '🌌', fajrMin),
    sunrise: makeItem('Sunrise', 'সূর্যোদয় / ইশরাক', '🌅', sunriseMin),
    dhuhr: makeItem('Dhuhr', 'যোহর', '☀️', dhuhrMin),
    asr: makeItem('Asr', 'আসর', '🌤️', asrMin),
    maghrib: makeItem('Maghrib', 'মাগরিব', '🌆', maghribMin),
    isha: makeItem('Isha', 'এশা ও বিতর', '🌙', ishaMin),
    tahajjud: makeItem('Tahajjud', 'তাহাজ্জুদ', '✨', tahajjudMin),
    offsetMinutes: offsetObj.dhuhr || 0,
    district: normDist
  };
}

/**
 * Calculates current countdown status to the next Waqt strictly following the user's rules:
 * 1. Fajr to Dhuhr: "যোহরের ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
 * 2. Dhuhr to Asr: "আসরের ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
 * 3. Asr to Maghrib: "মাগরিবের ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
 * 4. Maghrib to Isha: "এশার ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
 * 5. Isha to Tahajjud: "তাহাজ্জুদের ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
 * 6. Tahajjud to Fajr: "ফজরের ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
 */
export function getWaqtCountdownStatus(now: Date, schedule: DailyPrayerSchedule): WaqtCountdownStatus {
  const currentTotalSeconds = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  const currentMinutes = currentTotalSeconds / 60;

  const f = schedule.fajr.totalMinutes;
  const d = schedule.dhuhr.totalMinutes;
  const a = schedule.asr.totalMinutes;
  const m = schedule.maghrib.totalMinutes;
  const i = schedule.isha.totalMinutes;
  const t = schedule.tahajjud.totalMinutes;

  let targetWaqtName = 'যোহর';
  let currentWaqtName = 'ফজর';
  let targetTotalMinutes = d;
  let intervalStartMinutes = f;
  let prefix = 'যোহরের ওয়াক্তের বাকি:';
  let nextStartTimeFormatted = schedule.dhuhr.formattedTime;

  // Check which interval the current time falls into:
  if (currentMinutes >= f && currentMinutes < d) {
    // ১. ফজরের পর থেকে যোহর পর্যন্ত
    targetWaqtName = 'যোহর';
    currentWaqtName = 'ফজর / সকাল';
    intervalStartMinutes = f;
    targetTotalMinutes = d;
    prefix = 'যোহরের ওয়াক্তের বাকি:';
    nextStartTimeFormatted = schedule.dhuhr.formattedTime;
  } else if (currentMinutes >= d && currentMinutes < a) {
    // ২. যোহরের পর থেকে আসর পর্যন্ত
    targetWaqtName = 'আসর';
    currentWaqtName = 'যোহর';
    intervalStartMinutes = d;
    targetTotalMinutes = a;
    prefix = 'আসরের ওয়াক্তের বাকি:';
    nextStartTimeFormatted = schedule.asr.formattedTime;
  } else if (currentMinutes >= a && currentMinutes < m) {
    // ৩. আসরের পর থেকে মাগরিব পর্যন্ত
    targetWaqtName = 'মাগরিব';
    currentWaqtName = 'আসর';
    intervalStartMinutes = a;
    targetTotalMinutes = m;
    prefix = 'মাগরিবের ওয়াক্তের বাকি:';
    nextStartTimeFormatted = schedule.maghrib.formattedTime;
  } else if (currentMinutes >= m && currentMinutes < i) {
    // ৪. মাগরিবের পর থেকে এশা পর্যন্ত
    targetWaqtName = 'এশা';
    currentWaqtName = 'মাগরিব';
    intervalStartMinutes = m;
    targetTotalMinutes = i;
    prefix = 'এশার ওয়াক্তের বাকি:';
    nextStartTimeFormatted = schedule.isha.formattedTime;
  } else if (currentMinutes >= i || currentMinutes < t) {
    // ৫. এশার পর থেকে মধ্যরাত/তাহাজ্জুদ পর্যন্ত
    targetWaqtName = 'তাহাজ্জুদ';
    currentWaqtName = 'এশা / মধ্যরাত';
    intervalStartMinutes = i;
    // If current time is >= Isha (before midnight), target tahajjud is in next day (t + 24*60)
    targetTotalMinutes = currentMinutes >= i ? t + 24 * 60 : t;
    prefix = 'তাহাজ্জুদের ওয়াক্তের বাকি:';
    nextStartTimeFormatted = schedule.tahajjud.formattedTime;
  } else {
    // ৬. তাহাজ্জুদের সময় থেকে ফজর পর্যন্ত (t <= currentMinutes < f)
    targetWaqtName = 'ফজর';
    currentWaqtName = 'তাহাজ্জুদ / শেষরাত';
    intervalStartMinutes = t;
    targetTotalMinutes = f;
    prefix = 'ফজরের ওয়াক্তের বাকি:';
    nextStartTimeFormatted = schedule.fajr.formattedTime;
  }

  // Calculate remaining seconds
  const targetTotalSeconds = targetTotalMinutes * 60;
  let remainingTotalSeconds = Math.round(targetTotalSeconds - currentTotalSeconds);
  if (remainingTotalSeconds < 0) remainingTotalSeconds += 24 * 3600;

  const hours = Math.floor(remainingTotalSeconds / 3600);
  const minutes = Math.floor((remainingTotalSeconds % 3600) / 60);
  const seconds = remainingTotalSeconds % 60;

  // Calculate elapsed percentage of current interval
  const totalIntervalMinutes = (targetTotalMinutes - intervalStartMinutes + 24 * 60) % (24 * 60) || 1;
  const elapsedMinutes = (currentMinutes - intervalStartMinutes + 24 * 60) % (24 * 60);
  const elapsedPercent = Math.min(Math.max(Math.round((elapsedMinutes / totalIntervalMinutes) * 100), 0), 100);

  // Exact required text string
  const targetPhrase = `${prefix} ${toBanglaNumber(hours)} ঘণ্টা ${toBanglaNumber(minutes)} মিনিট`;

  // Islamic date rolls over at Maghrib
  const isAfterMaghrib = currentMinutes >= schedule.maghrib.totalMinutes;

  return {
    targetWaqtName,
    currentWaqtName,
    targetPhrase,
    hours,
    minutes,
    seconds,
    remainingTotalSeconds,
    elapsedPercent,
    nextStartTimeFormatted,
    isAfterMaghrib
  };
}

/**
 * Calculates current Islamic Hijri date for Bangladesh.
 * Automatically updates after Maghrib (sunset) as per Islamic calendar jurisprudence.
 */
export function getHijriDateInfo(now: Date, isAfterMaghrib: boolean, manualDayOffset = 0): HijriDateInfo {
  const targetDate = new Date(now);
  if (isAfterMaghrib) {
    targetDate.setDate(targetDate.getDate() + 1);
  }
  if (manualDayOffset !== 0) {
    targetDate.setDate(targetDate.getDate() + manualDayOffset);
  }

  let day = 1;
  let month = 1;
  let year = 1448;

  try {
    const formatter = new Intl.DateTimeFormat('en-US-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric'
    });
    const parts = formatter.formatToParts(targetDate);
    for (const p of parts) {
      if (p.type === 'day') day = parseInt(p.value, 10) || 1;
      if (p.type === 'month') month = parseInt(p.value, 10) || 1;
      if (p.type === 'year') year = parseInt(p.value, 10) || 1448;
    }
  } catch (e) {
    // Fallback calculation if umalqura locale is unsupported
    day = 12;
    month = 3;
    year = 1448;
  }

  const dayBangla = toBanglaNumber(day);
  const monthNameBangla = HIJRI_MONTHS_BANGLA[(month - 1) % 12] || 'রবিউল আউয়াল';
  const yearBangla = toBanglaNumber(year);
  const fullBanglaDate = `${dayBangla} ${monthNameBangla}, ${yearBangla} হিজরী`;

  return {
    day,
    month,
    year,
    dayBangla,
    monthNameBangla,
    yearBangla,
    fullBanglaDate,
    isAfterMaghrib
  };
}
