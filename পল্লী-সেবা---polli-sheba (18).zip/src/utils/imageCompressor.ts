/**
 * High-performance browser-side Image Compression utility.
 * Resizes camera and gallery photos to lightweight dimensions (max 640px)
 * and compresses them to ~30-50KB base64 strings so they never exceed
 * Firestore's 1MB document limit and load instantly on mobile networks.
 */

export async function compressImage(
  fileOrBlob: File | Blob,
  maxWidth = 640,
  maxHeight = 640,
  quality = 0.75
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          // Fallback to original string if canvas context fails
          resolve(event.target?.result as string);
          return;
        }

        // Draw and compress to JPEG
        ctx.drawImage(img, 0, 0, width, height);
        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedDataUrl);
      };

      img.onerror = () => {
        reject(new Error('ইমেজ লোড করতে সমস্যা হয়েছে।'));
      };

      img.src = event.target?.result as string;
    };

    reader.onerror = () => {
      reject(new Error('ফাইল পড়তে সমস্যা হয়েছে।'));
    };

    reader.readAsDataURL(fileOrBlob);
  });
}
