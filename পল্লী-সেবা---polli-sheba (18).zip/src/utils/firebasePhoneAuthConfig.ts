/**
 * Firebase Phone Authentication & Android Keystore SHA Fingerprints Configuration
 * 
 * This module provides the configuration structure for Firebase Phone Auth,
 * SHA-1 / SHA-256 fingerprints, and test OTP bypass for Polli Sheba.
 */

export interface FirebasePhoneAuthConfig {
  // Firebase Web Config
  apiKey: string;
  authDomain: string;
  projectId: string;
  appId: string;
  
  // Android Keystore Fingerprints for Firebase Phone Auth SMS Retreiver API
  androidPackageName: string;
  sha1DebugFingerprint: string;
  sha1ReleaseFingerprint: string;
  sha256DebugFingerprint: string;
  sha256ReleaseFingerprint: string;
  
  // Test / Bypass OTP configuration for development & staging
  isBypassEnabled: boolean;
  universalBypassOtp: string;
  allowedCountryCodes: string[];
}

export const POLLI_PHONE_AUTH_CONFIG: FirebasePhoneAuthConfig = {
  apiKey: "AIzaSyA96VX5EmSwCM3aNk84vsLs0hvxjErN004",
  authDomain: "resounding-aurora-qwgw1.firebaseapp.com",
  projectId: "resounding-aurora-qwgw1",
  appId: "1:294834933251:web:0f344bd7d977730fb4c836",
  
  androidPackageName: "com.pollisheba.app",
  
  // SHA-1 and SHA-256 structure for Android APK Firebase Phone Auth:
  // To generate these on your local system, run:
  // keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
  sha1DebugFingerprint: "6E:8B:2A:4F:19:5C:3D:8E:9F:01:23:45:67:89:AB:CD:EF:01:23:45",
  sha1ReleaseFingerprint: "B4:3A:89:E1:92:0D:5F:7A:1C:3E:45:67:89:01:23:45:67:89:AB:CD",
  sha256DebugFingerprint: "A1:B2:C3:D4:E5:F6:78:90:12:34:56:78:9A:BC:DE:F0:12:34:56:78:9A:BC:DE:F0:12:34:56:78:9A:BC:DE:F0",
  sha256ReleaseFingerprint: "F0:E1:D2:C3:B4:A5:96:87:78:69:5A:4B:3C:2D:1E:0F:F0:E1:D2:C3:B4:A5:96:87:78:69:5A:4B:3C:2D:1E:0F",
  
  // Active Test OTP / Bypass service
  isBypassEnabled: true,
  universalBypassOtp: "1234",
  allowedCountryCodes: ["+880"]
};

/**
 * Normalizes any Bangladeshi phone input into standard international E.164 (+8801XXXXXXXXX)
 * Handles English and Bengali numerals (০-৯) and removes non-digit characters.
 */
export function formatBangladeshiPhone(input: string): {
  displayLocal: string;     // e.g. "01712-345678"
  nationalNumber: string;   // e.g. "01712345678"
  e164: string;             // e.g. "+8801712345678"
  isValid: boolean;
  prefix: string;           // "+880"
} {
  if (!input) {
    return { displayLocal: '', nationalNumber: '', e164: '', isValid: false, prefix: '+880' };
  }

  // Convert Bengali numerals to English
  const bnToEn: Record<string, string> = {
    '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
    '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
  };
  const normalized = input.replace(/[০-৯]/g, (d) => bnToEn[d] || d);
  
  // Extract all digits
  let digits = normalized.replace(/\D/g, '');

  // Strip leading 880 if already provided
  if (digits.startsWith('880')) {
    digits = digits.substring(3);
  }

  // Ensure digits start with 01 or 1
  if (digits.startsWith('1') && digits.length === 10) {
    digits = '0' + digits;
  }

  const isValid = digits.length === 11 && digits.startsWith('01');
  const nationalNumber = digits;
  const e164 = digits.length === 11 ? `+880${digits.substring(1)}` : '';

  // Friendly formatting: 01712-345678
  let displayLocal = digits;
  if (digits.length > 5) {
    displayLocal = `${digits.substring(0, 5)}-${digits.substring(5, 11)}`;
  }

  return {
    displayLocal,
    nationalNumber,
    e164,
    isValid,
    prefix: '+880'
  };
}

/**
 * Checks if entered OTP matches either the dynamically generated code or universal test bypass
 */
export function verifyOtpCode(enteredOtp: string, expectedOtp: string): boolean {
  const cleanEntered = enteredOtp.trim().replace(/[০-৯]/g, (d) => {
    const map: Record<string, string> = { '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4', '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9' };
    return map[d] || d;
  });

  if (cleanEntered === expectedOtp) return true;
  if (POLLI_PHONE_AUTH_CONFIG.isBypassEnabled && cleanEntered === POLLI_PHONE_AUTH_CONFIG.universalBypassOtp) {
    return true;
  }
  return false;
}
