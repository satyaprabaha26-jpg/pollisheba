// Live Meteorological & Agro-weather Service for all 64 Districts of Bangladesh
import { getDistrictGeo, DistrictGeoData } from '../data/districtCoordinates';
import { toBanglaNumber } from './banglaNumbers';

export interface WeatherCondition {
  label: string;
  iconType: 'sun' | 'cloud-sun' | 'cloud' | 'cloud-rain' | 'cloud-lightning' | 'cloud-fog' | 'cloud-drizzle';
  alertLevel: 'normal' | 'caution' | 'warning' | 'severe';
  alertTitle?: string;
  alertDesc?: string;
}

export interface DayForecast {
  dayName: string;
  dateStr: string;
  maxTemp: number;
  minTemp: number;
  rainProbability: number;
  condition: string;
  iconType: WeatherCondition['iconType'];
}

export interface DistrictWeatherData {
  district: string;
  division: string;
  currentTemp: number;
  feelsLike: number;
  maxTemp: number;
  minTemp: number;
  humidity: number;
  rainChance: number;
  precipitationMm: number;
  windSpeedKmH: number;
  windDirectionText: string;
  conditionText: string;
  iconType: WeatherCondition['iconType'];
  uvIndex: number;
  airQuality: string;
  sunriseTime: string;
  sunsetTime: string;
  lastUpdated: string;
  isLiveApi: boolean;
  agroAdvisory: string;
  safetyAlert?: {
    type: 'rain' | 'storm' | 'heat' | 'cold' | 'flood' | 'lightning';
    title: string;
    message: string;
    level: 'yellow' | 'orange' | 'red';
  };
  weeklyForecast: DayForecast[];
}

// Map WMO Weather Interpretation Codes (WW)
function parseWMOCode(code: number): WeatherCondition {
  if (code === 0) {
    return { label: 'পরিষ্কার রৌদ্রোজ্জ্বল', iconType: 'sun', alertLevel: 'normal' };
  } else if (code === 1 || code === 2) {
    return { label: 'আংশিক মেঘলা', iconType: 'cloud-sun', alertLevel: 'normal' };
  } else if (code === 3) {
    return { label: 'মেঘলা আকাশ', iconType: 'cloud', alertLevel: 'normal' };
  } else if (code === 45 || code === 48) {
    return { 
      label: 'কুয়াশাচ্ছন্ন আবহাওয়া', 
      iconType: 'cloud-fog', 
      alertLevel: 'caution',
      alertTitle: 'কুয়াশা সতর্কতা',
      alertDesc: 'সকালে দৃষ্টিসীমা কম থাকতে পারে। নদীপথে নৌকা ও যান চলাচলে সতর্ক থাকুন।'
    };
  } else if (code >= 51 && code <= 55) {
    return { label: 'হালকা গুঁড়ি গুঁড়ি বৃষ্টি', iconType: 'cloud-drizzle', alertLevel: 'normal' };
  } else if (code >= 61 && code <= 65) {
    return { 
      label: code === 65 ? 'ভারী বৃষ্টিপাত' : 'মাঝারি বৃষ্টি', 
      iconType: 'cloud-rain', 
      alertLevel: code === 65 ? 'warning' : 'caution',
      alertTitle: 'বৃষ্টিপাতের সম্ভাবনা',
      alertDesc: 'মাঠের পাকা ফসল কেটে নিরাপদ স্থানে রাখুন ও নিকাশ নালা সচল রাখুন।'
    };
  } else if (code >= 80 && code <= 82) {
    return { 
      label: 'ঝড়ো হাওয়া ও বৃষ্টি', 
      iconType: 'cloud-rain', 
      alertLevel: 'warning',
      alertTitle: 'বৃষ্টি ও দমকা হাওয়া',
      alertDesc: 'ফসলের জমিতে পানি জমে না যাওয়ার ব্যবস্থা নিন এবং গাছপালা থেকে সাবধানে থাকুন।'
    };
  } else if (code >= 95) {
    return { 
      label: 'বজ্রবিদ্যুৎসহ কালবৈশাখী ঝড়', 
      iconType: 'cloud-lightning', 
      alertLevel: 'severe',
      alertTitle: 'বজ্রপাত ও কালবৈশাখী সতর্কতা',
      alertDesc: 'খোলা মাঠে থাকবেন না, ধাতব বস্তু স্পর্শ থেকে বিরত থাকুন এবং পশুদের নিরাপদ ছাউনিতে রাখুন।'
    };
  }
  return { label: 'স্বাভাবিক আবহাওয়া', iconType: 'cloud-sun', alertLevel: 'normal' };
}

// Generate District-specific Agricultural Advice based on climate zone & weather conditions
function generateDistrictAgroAdvisory(geo: DistrictGeoData, temp: number, rainChance: number, humidity: number): string {
  const cropStr = geo.dominantCrops.slice(0, 3).join(', ');
  
  if (rainChance >= 60) {
    if (geo.climateZone === 'haor') {
      return `${geo.name} অঞ্চলের হাওর এলাকায় বৃষ্টির সম্ভাবনা ${toBanglaNumber(rainChance)}%। দ্রুত বোরো ধান ও চরের ফসল সংগ্রহ করুন। ফসল শুকানোর জন্য নিরাপদ পলিথিন ছাউনি প্রস্তুত রাখুন। সেচ সম্পূর্ণ বন্ধ রাখুন।`;
    }
    if (geo.climateZone === 'coastal') {
      return `উপকূলীয় ${geo.name} জেলায় বৃষ্টি ও দমকা বাতাসের সম্ভাবনা রয়েছে। পানের বরজ, সবজির মাচায় বাড়তি খুঁটি দিন। মাছের ঘেরের চারপাশের নেট শক্ত করে বাঁধুন যেন পানি উপচে মাছ ভেসে না যায়।`;
    }
    return `${geo.name} জেলায় বৃষ্টিপাতের সম্ভাবনা বেশি। জমিতে সার ও কীটনাশক স্প্রে করা আপাতত স্থগিত রাখুন। নিচু জমিতে রোপণকৃত ${cropStr} ক্ষেতের নিকাশ নালা কেটে অতিরিক্ত পানি অপসারণের ব্যবস্থা নিন।`;
  }

  if (temp >= 35) {
    return `${geo.name} জেলায় প্রখর রোদ ও উচ্চ তাপমাত্রা (${toBanglaNumber(Math.round(temp))}° সে.) বিরাজ করছে। ${cropStr} ক্ষেতে সকাল বা বিকেলে হালকা সেচ দিন। ফলন্ত গাছে পানি স্প্রে করুন এবং গবাদিপশুকে পর্যাপ্ত ছায়াযুক্ত স্থানে রেখে স্যালাইন পানি খাওয়ান।`;
  }

  if (humidity >= 80) {
    return `${geo.name} এলাকায় বাতাসে উচ্চ আর্দ্রতা (${toBanglaNumber(humidity)}%) রয়েছে। এতে ${cropStr} ফসলে ছত্রাক বা ব্লাইট রোগের প্রাদুর্ভাব ঘটতে পারে। ক্ষেত নিয়মিত পর্যবেক্ষণ করুন এবং আগাম ছত্রাকনাশক প্রস্তুত রাখুন।`;
  }

  return `${geo.name} জেলায় রৌদ্রোজ্জ্বল অনুকূল আবহাওয়া। ${cropStr} ফসল পরিচর্যা, সার প্রয়োগ ও মাড়াই করার জন্য আজ খুব উপযুক্ত দিন। মাটির আর্দ্রতা দেখে সেচ নিশ্চিত করুন।`;
}

// Convert wind degrees to Bangla cardinal direction
function getWindDirectionBangla(deg: number): string {
  if (deg >= 337.5 || deg < 22.5) return 'উত্তর দিক';
  if (deg >= 22.5 && deg < 67.5) return 'উত্তর-পূর্ব দিক';
  if (deg >= 67.5 && deg < 112.5) return 'পূর্ব দিক';
  if (deg >= 112.5 && deg < 157.5) return 'দক্ষিণ-পূর্ব দিক';
  if (deg >= 157.5 && deg < 202.5) return 'দক্ষিণ দিক (বঙ্গোপসাগর)';
  if (deg >= 202.5 && deg < 247.5) return 'দক্ষিণ-পশ্চিম দিক';
  if (deg >= 247.5 && deg < 292.5) return 'পশ্চিম দিক';
  return 'উত্তর-পশ্চিম দিক';
}

const BANGLA_DAYS = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];

// Real-time Weather Fetching with Fallback
export async function fetchDistrictWeather(districtName: string): Promise<DistrictWeatherData> {
  const geo = getDistrictGeo(districtName);
  const now = new Date();
  const timeStr = `আজ ${toBanglaNumber(now.getHours())}:${toBanglaNumber(now.getMinutes().toString().padStart(2, '0'))}`;

  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${geo.lat}&longitude=${geo.lng}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,weather_code,wind_speed_10m,wind_direction_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset,uv_index_max&timezone=Asia%2FDhaka&forecast_days=7`;
    
    const response = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!response.ok) {
      throw new Error(`Weather API returned ${response.status}`);
    }

    const data = await response.json();
    const current = data.current;
    const daily = data.daily;

    const condition = parseWMOCode(current.weather_code || 0);
    const temp = Math.round(current.temperature_2m || 30);
    const feelsLike = Math.round(current.apparent_temperature || temp);
    const humidity = Math.round(current.relative_humidity_2m || 70);
    const rainChance = Math.round(daily.precipitation_probability_max?.[0] || (current.rain > 0 ? 80 : 20));
    const maxTemp = Math.round(daily.temperature_2m_max?.[0] || (temp + 3));
    const minTemp = Math.round(daily.temperature_2m_min?.[0] || (temp - 5));
    const windSpeed = Math.round(current.wind_speed_10m || 10);
    const windDir = getWindDirectionBangla(current.wind_direction_10m || 180);
    const uvIndex = Math.round(daily.uv_index_max?.[0] || 6);

    const sunriseIso = daily.sunrise?.[0];
    const sunsetIso = daily.sunset?.[0];
    const sunriseTime = sunriseIso ? formatIsoToBanglaTime(sunriseIso) : 'সকাল ৫:৩৮';
    const sunsetTime = sunsetIso ? formatIsoToBanglaTime(sunsetIso) : 'সন্ধ্যা ৬:১২';

    // Format 7-Day forecast
    const weeklyForecast: DayForecast[] = [];
    if (daily.time && Array.isArray(daily.time)) {
      for (let i = 0; i < Math.min(daily.time.length, 7); i++) {
        const d = new Date(daily.time[i]);
        const dayName = i === 0 ? 'আজ' : i === 1 ? 'আগামীকাল' : BANGLA_DAYS[d.getDay()];
        const code = daily.weather_code?.[i] ?? 1;
        const cond = parseWMOCode(code);
        weeklyForecast.push({
          dayName,
          dateStr: `${toBanglaNumber(d.getDate())}/${toBanglaNumber(d.getMonth() + 1)}`,
          maxTemp: Math.round(daily.temperature_2m_max?.[i] ?? 32),
          minTemp: Math.round(daily.temperature_2m_min?.[i] ?? 24),
          rainProbability: Math.round(daily.precipitation_probability_max?.[i] ?? 20),
          condition: cond.label,
          iconType: cond.iconType
        });
      }
    }

    const agroAdvisory = generateDistrictAgroAdvisory(geo, temp, rainChance, humidity);

    // Formulate alerts if severe
    let safetyAlert: DistrictWeatherData['safetyAlert'] = undefined;
    if (current.weather_code >= 95) {
      safetyAlert = {
        type: 'storm',
        title: 'বজ্রপাত ও ঝড় সতর্কতা',
        message: `${geo.name} জেলায় বজ্রবিদ্যুৎসহ কালবৈশাখী ঝড়ের আশঙ্কা রয়েছে। নিরাপদ আশ্রয়ে থাকুন।`,
        level: 'red'
      };
    } else if (rainChance >= 75) {
      safetyAlert = {
        type: 'rain',
        title: 'ভারী বৃষ্টিপাতের সতর্কতা',
        message: `${geo.name} এলাকায় টানা বৃষ্টি হতে পারে। মাঠের ফসল দ্রুত গোলায় তুলুন।`,
        level: 'orange'
      };
    } else if (temp >= 37) {
      safetyAlert = {
        type: 'heat',
        title: 'তীব্র তাপপ্রবাহ সতর্কতা',
        message: `${geo.name} জেলায় তীব্র তাপদাহ বিরাজ করছে। দুপুরে ছায়ায় থাকুন ও প্রচুর পানি পান করুন।`,
        level: 'yellow'
      };
    }

    return {
      district: geo.name,
      division: geo.division,
      currentTemp: temp,
      feelsLike,
      maxTemp,
      minTemp,
      humidity,
      rainChance,
      precipitationMm: current.precipitation || 0,
      windSpeedKmH: windSpeed,
      windDirectionText: windDir,
      conditionText: condition.label,
      iconType: condition.iconType,
      uvIndex,
      airQuality: uvIndex > 7 ? 'মাঝারি (ধূলিকণা বেশি)' : 'ভালো (স্বাভাবিক)',
      sunriseTime,
      sunsetTime,
      lastUpdated: timeStr,
      isLiveApi: true,
      agroAdvisory,
      safetyAlert,
      weeklyForecast
    };
  } catch (err) {
    console.warn(`Live weather fetch failed for ${districtName}, using localized meteorological model:`, err);
    return getSimulatedDistrictWeather(geo, timeStr);
  }
}

function formatIsoToBanglaTime(isoString: string): string {
  try {
    const d = new Date(isoString);
    const h = d.getHours();
    const m = d.getMinutes().toString().padStart(2, '0');
    const period = h < 12 ? 'সকাল' : h < 15 ? 'দুপুর' : h < 18 ? 'বিকেল' : 'সন্ধ্যা';
    const displayH = h % 12 || 12;
    return `${period} ${toBanglaNumber(displayH)}:${toBanglaNumber(m)}`;
  } catch {
    return 'সকাল ৫:৪০';
  }
}

// Realistic Division-calibrated Weather Simulation for offline / instant fast fallback
function getSimulatedDistrictWeather(geo: DistrictGeoData, timeStr: string): DistrictWeatherData {
  const currentMonth = new Date().getMonth(); // 0 to 11
  
  // Base climate variance by zone
  let baseTemp = 31;
  let baseRain = 25;
  let baseHumidity = 72;
  let condLabel = 'আংশিক মেঘলা';
  let icon: WeatherCondition['iconType'] = 'cloud-sun';

  if (geo.climateZone === 'coastal') {
    baseTemp = 30;
    baseRain = 45;
    baseHumidity = 84;
    condLabel = 'উপকূলীয় বাতাস ও মেঘলা';
    icon = 'cloud-sun';
  } else if (geo.climateZone === 'haor') {
    baseTemp = 29;
    baseRain = 55;
    baseHumidity = 86;
    condLabel = 'হাওরীয় বৃষ্টি ও মেঘলা আকাশ';
    icon = 'cloud-rain';
  } else if (geo.climateZone === 'barind' || geo.climateZone === 'northern') {
    baseTemp = 34;
    baseRain = 15;
    baseHumidity = 62;
    condLabel = 'পরিষ্কার রৌদ্রোজ্জ্বল ও শুষ্ক';
    icon = 'sun';
  } else if (geo.climateZone === 'hilly') {
    baseTemp = 28;
    baseRain = 40;
    baseHumidity = 78;
    condLabel = 'পাহাড়ি কুয়াশা ও মেঘ';
    icon = 'cloud-sun';
  }

  // Winter adjustment (Dec, Jan, Feb)
  if (currentMonth === 11 || currentMonth === 0 || currentMonth === 1) {
    baseTemp -= 10;
    baseRain = 5;
    baseHumidity = 65;
    condLabel = 'শীতল হাওয়া ও হালকা কুয়াশা';
    icon = 'cloud-fog';
  }

  // Generate 7-day realistic weekly forecast
  const weeklyForecast: DayForecast[] = [];
  const today = new Date();
  for (let i = 0; i < 7; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    const dayName = i === 0 ? 'আজ' : i === 1 ? 'আগামীকাল' : BANGLA_DAYS[d.getDay()];
    const variance = (i * 2) % 3;
    weeklyForecast.push({
      dayName,
      dateStr: `${toBanglaNumber(d.getDate())}/${toBanglaNumber(d.getMonth() + 1)}`,
      maxTemp: baseTemp + 2 - variance,
      minTemp: baseTemp - 6 - variance,
      rainProbability: Math.min(95, Math.max(5, baseRain + (i % 2 === 0 ? 10 : -10))),
      condition: i % 3 === 0 ? 'আংশিক মেঘলা' : i % 3 === 1 ? 'রৌদ্রোজ্জ্বল' : 'হালকা বৃষ্টি',
      iconType: i % 3 === 0 ? 'cloud-sun' : i % 3 === 1 ? 'sun' : 'cloud-drizzle'
    });
  }

  const agroAdvisory = generateDistrictAgroAdvisory(geo, baseTemp, baseRain, baseHumidity);

  let safetyAlert: DistrictWeatherData['safetyAlert'] = undefined;
  if (condLabel.includes('বজ্র')) {
    safetyAlert = {
      type: 'lightning',
      title: 'বজ্রপাত ও কালবৈশাখীর সতর্কতা',
      message: `${geo.name} জেলায় বজ্রবিদ্যুৎসহ ঝড়ো হাওয়া ও বজ্রপাতের আশঙ্কা রয়েছে। মাঠে থাকা কৃষকদের নিরাপদ পাকা আশ্রয়ে থাকার অনুরোধ করা হচ্ছে।`,
      level: 'red'
    };
  } else if (baseRain >= 70) {
    safetyAlert = {
      type: 'rain',
      title: 'ভারী বৃষ্টিপাতের সতর্কতা',
      message: `${geo.name} এলাকায় টানা ভারী বৃষ্টি হতে পারে। পাকা ফসল দ্রুত গোলায় তুলুন।`,
      level: 'orange'
    };
  }

  return {
    district: geo.name,
    division: geo.division,
    currentTemp: baseTemp,
    feelsLike: baseTemp + 2,
    maxTemp: baseTemp + 3,
    minTemp: baseTemp - 5,
    humidity: baseHumidity,
    rainChance: baseRain,
    precipitationMm: baseRain > 40 ? 4.5 : 0,
    windSpeedKmH: geo.climateZone === 'coastal' ? 18 : 11,
    windDirectionText: geo.climateZone === 'coastal' ? 'দক্ষিণ দিক (সাগর মুখী)' : 'দক্ষিণ-পূর্ব দিক',
    conditionText: condLabel,
    iconType: icon,
    uvIndex: 6,
    airQuality: 'ভালো (স্বাভাবিক)',
    sunriseTime: 'সকাল ৫:৩৯',
    sunsetTime: 'সন্ধ্যা ৬:১১',
    lastUpdated: timeStr,
    isLiveApi: false,
    agroAdvisory,
    safetyAlert,
    weeklyForecast
  };
}

export const getDistrictWeather = fetchDistrictWeather;
