import { HaatListing } from '../types';
import { UserProfile } from '../types/auth';

/**
 * Cleans district name by removing common suffixes like "জেলা"
 */
export function cleanDistrictName(name?: string): string {
  if (!name) return '';
  return name.replace(/\s*জেলা\s*$/i, '').trim();
}

/**
 * Cleans upazila name by removing common suffixes like "উপজেলা", "থানা"
 */
export function cleanUpazilaName(name?: string): string {
  if (!name) return '';
  return name.replace(/\s*(উপজেলা|থানা)\s*$/i, '').trim();
}

/**
 * Cleans union name by removing common suffixes like "ইউনিয়ন", "ইউনিয়ন পরিষদ", "পৌরসভা", "ওয়ার্ড"
 */
export function cleanUnionName(name?: string): string {
  if (!name) return '';
  return name.replace(/\s*(ইউনিয়ন\s*পরিষদ|ইউনিয়ন|ইউনিয়ন পরিষদ|পৌরসভা|ওয়ার্ড)\s*$/i, '').trim();
}

/**
 * Converts a registered UserProfile (role === 'tutor_student' or having tutorInfo)
 * into a standardized HaatListing so it seamlessly appears in the Tutor Network Board
 * and search feeds.
 */
export function convertRegisteredUserToTutorListing(user: UserProfile): HaatListing {
  const isTeacher = !user.tutorInfo || user.tutorInfo.tutorType === 'teacher';
  const tutorInfo = user.tutorInfo;

  const subjects = tutorInfo?.preferredSubjects || '';
  const targetClasses = tutorInfo?.targetClasses || 'সকল শ্রেণি';
  const qualification = tutorInfo?.qualification || '';
  const remuneration = tutorInfo?.remuneration || 'আলোচনা সাপেক্ষে';
  const teachingDays = tutorInfo?.teachingDaysPerWeek || 'সপ্তাহে ৩ দিন';
  const medium = tutorInfo?.preferredMedium || 'বাংলা মাধ্যম';

  // Numeric price extraction if available
  const numericPrice = parseFloat(remuneration.replace(/[^0-9.]/g, '')) || 0;

  // Clean location components
  const dist = cleanDistrictName(user.district);
  const upz = cleanUpazilaName(user.upazila);
  const un = cleanUnionName(user.union);
  const vlg = user.village ? user.village.trim() : '';

  const compiledLocation = [
    (!user.hideVillage && vlg) ? `গ্রাম: ${vlg}` : '',
    un ? `${un} ইউনিয়ন` : '',
    upz ? `উপজেলা: ${upz}` : '',
    dist ? `${dist} জেলা` : ''
  ].filter(Boolean).join(', ') || `${dist || user.district || ''} জেলা`;

  const title = isTeacher
    ? (subjects ? `${subjects} - গৃহশিক্ষক` : `গৃহশিক্ষক (${user.name})`)
    : (subjects ? `${subjects} - শিক্ষক আবশ্যক` : `গৃহশিক্ষক আবশ্যক`);

  const description = [
    qualification ? `যোগ্যতা/প্রতিষ্ঠান: ${qualification}` : '',
    targetClasses ? `শ্রেণি: ${targetClasses}` : '',
    subjects ? `বিষয়: ${subjects}` : '',
    teachingDays ? `দিন: ${teachingDays}` : '',
    medium ? `মাধ্যম: ${medium}` : ''
  ].filter(Boolean).join(' • ');

  const now = Date.now();
  const createdTs = user.createdAt ? (Date.parse(user.createdAt) || now) : now;

  return {
    id: `registered-tutor-${user.id || user.phone.replace(/[^0-9]/g, '')}`,
    title,
    category: 'গৃহশিক্ষক ও শিক্ষার্থী',
    itemType: isTeacher ? 'গৃহশিক্ষক' : 'শিক্ষার্থী',
    price: numericPrice,
    unit: remuneration ? remuneration : 'টাকা / মাসিক',
    sellerName: user.name,
    sellerRole: isTeacher ? 'teacher' : 'citizen',
    sellerId: user.id,
    phone: user.phone,
    location: compiledLocation,
    district: dist || user.district,
    upazila: upz || user.upazila,
    unionOrWard: un || user.union,
    village: vlg || user.village,
    hideVillage: user.hideVillage !== false,
    allowOfflineCall: !!user.allowOfflineCall,
    description: description || 'সম্মানিত নিবন্ধিত শিক্ষক',
    createdAt: user.createdAt || 'নিবন্ধিত শিক্ষক',
    createdAtTimestamp: createdTs,
    isNegotiable: true,
    isPerishable: false,
    expiryDays: 365,
    expiryDateTimestamp: now + 365 * 24 * 60 * 60 * 1000,
    isSold: false,
    tutorType: isTeacher ? 'tutor_avail' : 'tutor_need',
    targetClasses,
    subjects,
    qualification,
    teachingDays,
    medium
  };
}
