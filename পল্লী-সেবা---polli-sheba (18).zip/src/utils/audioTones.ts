/**
 * Audio Tones & Vibration Service for In-App Voice Calling
 * Provides realistic telephone dialing tones (caller side), ringing tones (callee side),
 * call end tones, and device vibration control.
 */

class AudioTonesService {
  private audioCtx: AudioContext | null = null;
  private dialInterval: any = null;
  private ringInterval: any = null;
  private vibrateInterval: any = null;
  private isDialing: boolean = false;
  private isRinging: boolean = false;

  private getAudioContext(): AudioContext | null {
    try {
      if (!this.audioCtx || this.audioCtx.state === 'closed') {
        const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtxClass) {
          this.audioCtx = new AudioCtxClass();
        }
      }
      if (this.audioCtx && this.audioCtx.state === 'suspended') {
        this.audioCtx.resume().catch(() => {});
      }
      return this.audioCtx;
    } catch (e) {
      console.warn('AudioContext init note:', e);
      return null;
    }
  }

  /**
   * Play localized telephone Dialing Tone on caller's device while waiting for callee to answer.
   * Standard dual-frequency ringback tone (400 Hz + 450 Hz) with 1.4s pulse and 3s pause.
   */
  public playDialingTone(): void {
    if (this.isDialing) return;
    this.stopAll();
    this.isDialing = true;

    const playBurst = () => {
      if (!this.isDialing) return;
      const ctx = this.getAudioContext();
      if (!ctx || ctx.state === 'closed') return;

      try {
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.type = 'sine';
        osc2.type = 'sine';
        osc1.frequency.value = 400; // European / Asian standard dialback tone
        osc2.frequency.value = 450;

        const now = ctx.currentTime;
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.08, now + 0.05);
        gain.gain.setValueAtTime(0.08, now + 1.35);
        gain.gain.linearRampToValueAtTime(0, now + 1.45);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + 1.5);
        osc2.stop(now + 1.5);
      } catch (err) {
        console.warn('Dialing tone burst note:', err);
      }
    };

    playBurst();
    this.dialInterval = setInterval(playBurst, 4000);
  }

  public stopDialingTone(): void {
    this.isDialing = false;
    if (this.dialInterval) {
      clearInterval(this.dialInterval);
      this.dialInterval = null;
    }
  }

  /**
   * Play loud, clear, repeating telephone Ringtone on callee's device when incoming call arrives.
   * Multi-frequency pleasant phone ring with rhythmic vibration.
   */
  public playRingingTone(): void {
    if (this.isRinging) return;
    this.stopAll();
    this.isRinging = true;

    const startVibration = () => {
      try {
        if ('vibrate' in navigator && typeof navigator.vibrate === 'function') {
          navigator.vibrate([800, 300, 800, 300, 1000]);
        }
      } catch {}
    };

    const playRingBurst = () => {
      if (!this.isRinging) return;
      const ctx = this.getAudioContext();
      if (!ctx || ctx.state === 'closed') return;

      try {
        // Double-ring phone chime pattern (ring-ring ... ring-ring)
        const now = ctx.currentTime;

        const createRing = (startTime: number, duration: number) => {
          const osc1 = ctx.createOscillator();
          const osc2 = ctx.createOscillator();
          const gain = ctx.createGain();

          osc1.type = 'sine';
          osc2.type = 'triangle';
          osc1.frequency.value = 753; // High-pitch phone bell
          osc2.frequency.value = 852;

          gain.gain.setValueAtTime(0, startTime);
          gain.gain.linearRampToValueAtTime(0.18, startTime + 0.04);
          gain.gain.setValueAtTime(0.18, startTime + duration - 0.05);
          gain.gain.linearRampToValueAtTime(0, startTime + duration);

          osc1.connect(gain);
          osc2.connect(gain);
          gain.connect(ctx.destination);

          osc1.start(startTime);
          osc2.start(startTime);
          osc1.stop(startTime + duration + 0.05);
          osc2.stop(startTime + duration + 0.05);
        };

        // 1st chirp: 0.8s, gap: 0.3s, 2nd chirp: 0.8s
        createRing(now, 0.8);
        createRing(now + 1.1, 0.9);
      } catch (err) {
        console.warn('Ringing tone burst note:', err);
      }
    };

    playRingBurst();
    startVibration();

    this.ringInterval = setInterval(() => {
      playRingBurst();
      startVibration();
    }, 3800);
  }

  public stopRingingTone(): void {
    this.isRinging = false;
    if (this.ringInterval) {
      clearInterval(this.ringInterval);
      this.ringInterval = null;
    }
    try {
      if ('vibrate' in navigator && typeof navigator.vibrate === 'function') {
        navigator.vibrate(0); // Cancel ongoing vibration
      }
    } catch {}
  }

  /**
   * Play short call end tone (disconnect beep) when either side hangs up
   */
  public playCallEndTone(): void {
    this.stopAll();
    const ctx = this.getAudioContext();
    if (!ctx || ctx.state === 'closed') return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(480, now);
      osc.frequency.setValueAtTime(320, now + 0.12);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.linearRampToValueAtTime(0, now + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.32);
    } catch {}
  }

  /**
   * Stop all playing tones and vibration
   */
  public stopAll(): void {
    this.stopDialingTone();
    this.stopRingingTone();
  }
}

export const audioTones = new AudioTonesService();

/**
 * Check device microphone permission state
 */
export async function getMicrophonePermissionState(): Promise<'granted' | 'prompt' | 'denied' | 'unsupported'> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    return 'unsupported';
  }

  try {
    if ('permissions' in navigator && navigator.permissions.query) {
      const res = await navigator.permissions.query({ name: 'microphone' as any });
      return res.state;
    }
  } catch {
    // navigator.permissions.query for microphone may fail in some mobile browsers
  }

  return 'prompt';
}

/**
 * Request microphone access explicitly from user
 */
export async function requestMicrophoneAccess(): Promise<{ granted: boolean; error?: string }> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    return { granted: false, error: 'আপনার ডিভাইসে মাইক্রোফোন সমর্থিত নয়।' };
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      },
      video: false
    });
    // Release test tracks immediately
    stream.getTracks().forEach(t => t.stop());
    return { granted: true };
  } catch (err: any) {
    const name = err?.name || '';
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
      return {
        granted: false,
        error: 'মাইক্রোফোনের অনুমতি প্রদান করা হয়নি। অনুগ্রহ করে ব্রাউজারের অ্যাড্রেস বারের তালা (Lock) আইকন চেপে মাইক্রোফোন Allow করুন।'
      };
    }
    return {
      granted: false,
      error: 'মাইক্রোফোন চালু করতে সমস্যা হয়েছে: ' + (err?.message || 'অজানা ত্রুটি')
    };
  }
}
