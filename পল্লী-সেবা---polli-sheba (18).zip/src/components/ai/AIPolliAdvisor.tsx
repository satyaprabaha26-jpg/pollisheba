import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Copy, 
  Check, 
  Loader2, 
  User,
  ShoppingBag,
  Car,
  Heart,
  Landmark,
  Zap,
  Sprout,
  ShieldCheck,
  MapPin,
  HelpCircle,
  ArrowRight,
  ExternalLink,
  Info,
  Scale,
  RefreshCw,
  AlertTriangle,
  ShieldAlert,
  PhoneCall,
  Phone,
  MessageSquare,
  Lock,
  Eye,
  Star,
  Search,
  Mic,
  MicOff
} from 'lucide-react';
import { ServiceCategory, AIComplaintRecord } from '../../types';
import { UserProfile } from '../../types/auth';
import { 
  saveCloudAIComplaint, 
  saveDemandNotification,
  subscribeToDrivers,
  subscribeToReturnRides,
  subscribeToHaatItems,
  subscribeToDonors,
  subscribeToHousingListings,
  subscribeToRegisteredUsers
} from '../../lib/cloudSync';
import { sendSystemNotification } from '../../utils/notificationService';
import { 
  INITIAL_HAAT_LISTINGS, 
  CROP_DISEASES_DATA, 
  MARKET_PRICES_DATA, 
  HOTLINES_DATA,
  LIVESTOCK_CARE_DATA,
  BANGLADESH_DISTRICTS
} from '../../data/mockData';
import { 
  SERVICE_OFFICE_GUIDES, 
  INITIAL_BLOOD_DONORS, 
  DOCTOR_SCHEDULES_DATA, 
  INITIAL_TRANSPORT_DRIVERS,
  HOSPITALS_DATA 
} from '../../data/extendedData';
import { getUpazilasForDistrict } from '../../data/bangladeshLocations';
import { executeSmartSearch, AIProviderCard, parseLocationAndServiceQuery } from '../../utils/aiSmartSearchEngine';

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  categoryTag?: string;
  actions?: Array<{ target: ServiceCategory; label: string; subTab?: string }>;
  providerCards?: Array<AIProviderCard>;
  isFallback?: boolean;
  complaintBadge?: {
    trackingId: string;
    type: string;
    severity: string;
    summary?: string;
  };
}

interface AIPolliAdvisorProps {
  currentDistrict: string;
  currentUser?: UserProfile | null;
  onNavigateCategory?: (category: ServiceCategory, subTab?: string) => void;
  onStartInAppCall?: (targetUser: { id?: string; name: string; phone?: string; role?: string; avatar?: string; vehicle?: string }) => void;
  onStartChat?: (targetUser: { id?: string; name: string; phone?: string; role?: string; avatar?: string; itemTitle?: string }) => void;
  onViewProfile?: (targetUser: Partial<UserProfile>) => void;
  onOpenAuth?: (actionName?: string) => void;
}

type AdvisorCategory = 
  | 'all'
  | 'marketplace'
  | 'transport'
  | 'health'
  | 'government'
  | 'electricity'
  | 'agriculture'
  | 'livestock'
  | 'calculators';

export const AIPolliAdvisor: React.FC<AIPolliAdvisorProps> = ({ 
  currentDistrict,
  currentUser,
  onNavigateCategory,
  onStartInAppCall,
  onStartChat,
  onViewProfile,
  onOpenAuth
}) => {
  const [selectedCategory, setSelectedCategory] = useState<AdvisorCategory>('all');
  const [activeDistrict, setActiveDistrict] = useState<string>(
    currentDistrict && currentDistrict !== 'সকল জেলা' ? currentDistrict : 'পটুয়াখালী'
  );
  const [activeUpazila, setActiveUpazila] = useState<string>(() => {
    if (currentDistrict && currentDistrict !== 'সকল জেলা') {
      const upz = getUpazilasForDistrict(currentDistrict);
      return upz && upz.length > 0 ? upz[0] : 'বাউফল';
    }
    return 'বাউফল';
  });
  const [showLocationPicker, setShowLocationPicker] = useState<boolean>(false);

  // Sync if parent district changes
  useEffect(() => {
    if (currentDistrict && currentDistrict !== 'সকল জেলা' && currentDistrict !== activeDistrict) {
      setActiveDistrict(currentDistrict);
      const upz = getUpazilasForDistrict(currentDistrict);
      if (upz && upz.length > 0) {
        setActiveUpazila(upz[0]);
      }
    }
  }, [currentDistrict]);

  const availableUpazilas = useMemo(() => {
    if (!activeDistrict || activeDistrict === 'সকল জেলা') return [];
    return getUpazilasForDistrict(activeDistrict);
  }, [activeDistrict]);

  // Default welcome message when conversation is fresh
  const DEFAULT_WELCOME_MESSAGE: ChatMessage = useMemo(() => ({
    id: 'msg-welcome',
    sender: 'bot',
    text: `আসসালামু আলাইকুম! আমি **পল্লী সেবা এআই সহকারী**। 🌾

আপনার এলাকা বা দেশের যেকোনো প্রান্তের **হাটবাজারের পণ্যের দরদাম ও প্রাপ্যতা, পরিবহন ও গাড়ি, জরুরি রক্তদাতা ও স্বাস্থ্যসেবা, সরকারি ভাতা ও ই-নামজারি, কিংবা বিদ্যুৎ ও কৃষিসংক্রান্ত** যেকোনো তথ্য জানতে নিচে প্রশ্ন করুন।

🔒 *আপনার ব্যক্তিগত তথ্যের গোপনীয়তা ও সুরক্ষা নিশ্চিত রাখা হয়।*`,
    timestamp: 'এখন',
    actions: [
      { target: 'marketplace', label: '🛒 পল্লী হাট' },
      { target: 'transport', label: '🚗 পরিবহন' },
      { target: 'agriculture', label: '🌾 শস্য ডাক্তার' },
      { target: 'health', label: '🩸 রক্ত ও স্বাস্থ্য' },
      { target: 'government', label: '🏛️ সরকারি সেবা' },
      { target: 'electricity', label: '⚡ বিদ্যুৎ বিল' }
    ]
  }), []);

  // Chat messages stored in sessionStorage so navigating to other services/tabs inside the app keeps the chat history intact until exiting the app
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const stored = sessionStorage.getItem('polli_ai_advisor_chat_messages');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read session chat:', e);
    }
    return [
      {
        id: 'msg-welcome',
        sender: 'bot',
        text: `আসসালামু আলাইকুম! আমি **পল্লী সেবা এআই সহকারী**। 🌾

আপনার এলাকা বা দেশের যেকোনো প্রান্তের **হাটবাজারের পণ্যের দরদাম ও প্রাপ্যতা, পরিবহন ও গাড়ি, জরুরি রক্তদাতা ও স্বাস্থ্যসেবা, সরকারি ভাতা ও ই-নামজারি, কিংবা বিদ্যুৎ ও কৃষিসংক্রান্ত** যেকোনো তথ্য জানতে নিচে প্রশ্ন করুন।

🔒 *আপনার ব্যক্তিগত তথ্যের গোপনীয়তা ও সুরক্ষা নিশ্চিত রাখা হয়।*`,
        timestamp: 'এখন',
        actions: [
          { target: 'marketplace', label: '🛒 পল্লী হাট' },
          { target: 'transport', label: '🚗 পরিবহন' },
          { target: 'agriculture', label: '🌾 শস্য ডাক্তার' },
          { target: 'health', label: '🩸 রক্ত ও স্বাস্থ্য' },
          { target: 'government', label: '🏛️ সরকারি সেবা' },
          { target: 'electricity', label: '⚡ বিদ্যুৎ বিল' }
        ]
      }
    ];
  });

  // Sync messages to sessionStorage whenever updated
  useEffect(() => {
    try {
      sessionStorage.setItem('polli_ai_advisor_chat_messages', JSON.stringify(messages));
    } catch (e) {
      console.warn('Could not save session chat:', e);
    }
  }, [messages]);

  const handleClearChat = () => {
    if (confirm('আপনি কি পূর্বের কথোপকথন মুছে নতুনভাবে চ্যাট শুরু করতে চান?')) {
      const fresh = [{ ...DEFAULT_WELCOME_MESSAGE, id: `msg-welcome-${Date.now()}` }];
      setMessages(fresh);
      try {
        sessionStorage.setItem('polli_ai_advisor_chat_messages', JSON.stringify(fresh));
      } catch (e) {}
    }
  };
  const [showQuickPrompts, setShowQuickPrompts] = useState<boolean>(false);

  const [inputPrompt, setInputPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const lastQuestionRef = useRef<HTMLDivElement>(null);
  const lastUserMessageIdRef = useRef<string | null>(null);

  // Voice-to-Text Speech Recognition States
  const [isListening, setIsListening] = useState<boolean>(false);
  const [voiceStatusText, setVoiceStatusText] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Live Real-Time Datasets from Firestore Cloud
  const [liveDrivers, setLiveDrivers] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('polli_transport_drivers');
      return saved ? JSON.parse(saved) : INITIAL_TRANSPORT_DRIVERS;
    } catch {
      return INITIAL_TRANSPORT_DRIVERS;
    }
  });

  const [liveReturnRides, setLiveReturnRides] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('polli_return_rides');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [liveHaatItems, setLiveHaatItems] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('polli_haat_listings_v2') || localStorage.getItem('polli_haat_listings');
      return saved ? JSON.parse(saved) : INITIAL_HAAT_LISTINGS;
    } catch {
      return INITIAL_HAAT_LISTINGS;
    }
  });

  const [liveDonors, setLiveDonors] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('polli_blood_donors');
      return saved ? JSON.parse(saved) : INITIAL_BLOOD_DONORS;
    } catch {
      return INITIAL_BLOOD_DONORS;
    }
  });

  const [liveHousingListings, setLiveHousingListings] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('polli_housing_listings');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [liveRegisteredUsers, setLiveRegisteredUsers] = useState<UserProfile[]>([]);

  useEffect(() => {
    const unsubDrivers = subscribeToDrivers(setLiveDrivers);
    const unsubRides = subscribeToReturnRides(setLiveReturnRides);
    const unsubHaat = subscribeToHaatItems(setLiveHaatItems);
    const unsubDonors = subscribeToDonors(setLiveDonors);
    const unsubHousing = subscribeToHousingListings(setLiveHousingListings);
    const unsubUsers = subscribeToRegisteredUsers(setLiveRegisteredUsers);

    return () => {
      unsubDrivers?.();
      unsubRides?.();
      unsubHaat?.();
      unsubDonors?.();
      unsubHousing?.();
      unsubUsers?.();
    };
  }, []);

  // Sync prop district changes
  useEffect(() => {
    if (currentDistrict && currentDistrict !== 'সকল জেলা' && currentDistrict !== activeDistrict) {
      setActiveDistrict(currentDistrict);
      const upz = getUpazilasForDistrict(currentDistrict);
      if (upz && upz.length > 0) {
        setActiveUpazila(upz[0]);
      }
    }
  }, [currentDistrict]);

  // Smoothly scroll to the start of the user question & AI answer
  // Prevents scrolling down to the footer/admin dashboard and lets the user read the reply from the beginning
  useEffect(() => {
    if (messages.length <= 1) return;

    const timer = setTimeout(() => {
      const container = chatContainerRef.current;
      let targetEl = lastQuestionRef.current;

      if (!targetEl && container) {
        const lastUserMsg = [...messages].reverse().find(m => m.sender === 'user');
        if (lastUserMsg) {
          const el = container.querySelector(`[data-msg-id="${lastUserMsg.id}"]`) as HTMLElement;
          if (el) targetEl = el;
        }
      }

      if (targetEl && container) {
        // 1. Scroll chat container so question is positioned at the top of the chat area
        const targetOffsetTop = targetEl.offsetTop;
        container.scrollTo({
          top: Math.max(0, targetOffsetTop - 12),
          behavior: 'smooth'
        });

        // 2. Adjust window scroll smoothly on mobile to bring the question and answer top into view
        // while strictly preventing any scroll down to the bottom footer or admin dashboard
        const rect = targetEl.getBoundingClientRect();
        const currentScrollY = window.scrollY || window.pageYOffset;
        const targetWindowY = currentScrollY + rect.top - 75;

        if (rect.top < 50 || rect.top > 250) {
          window.scrollTo({
            top: Math.max(0, targetWindowY),
            behavior: 'smooth'
          });
        }
      }
    }, 60);

    return () => clearTimeout(timer);
  }, [messages, isLoading]);

  // Dynamic Preset Questions based on Selected Category & Location (Compact & Clean)
  const presetQuestions = useMemo(() => {
    switch (selectedCategory) {
      case 'marketplace':
        return [
          { 
            label: `🥬 ${activeDistrict} ${activeUpazila ? activeUpazila : ''} হাটের সবজি ও বাজারদর`, 
            query: `${activeDistrict} জেলা ${activeUpazila ? activeUpazila + ' উপজেলায়' : ''} বর্তমানে কী কী তাজা শাকসবজি বা তরিতরকারি বিক্রি হচ্ছে, দাম কত এবং বিক্রেতা কে আছেন?` 
          },
          { 
            label: '🛒 হাটে নিজের পণ্য বিক্রির বিজ্ঞাপন দেওয়ার নিয়ম', 
            query: 'আমি কৃষক, আমার জমির উদ্বৃত্ত শাকসবজি পল্লী হাটে কীভাবে বিজ্ঞাপন দিয়ে সরাসরি ক্রেতার কাছে বিক্রি করতে পারি?' 
          }
        ];

      case 'transport':
        return [
          { 
            label: `🚗 ${activeDistrict} এলাকার গাড়ি ও চালকের তথ্য`, 
            query: `${activeDistrict} জেলার ${activeUpazila ? activeUpazila + ' উপজেলায়' : ''} দিনে বা রাতে যাতায়াতের জন্য কোনো ভ্যান, ইজিবাইক, সিএনজি বা পিকআপ চালক আছেন কি?` 
          },
          { 
            label: '🚚 ফসল পরিবহনে পিকআপ বুকিংয়ের নিয়ম', 
            query: 'জমি বা আড়ত থেকে ফসল হাটে নেওয়ার জন্য পিকআপ বা নসিমন চালকের সাথে যোগাযোগ করার সঠিক পদ্ধতি কী?' 
          }
        ];

      case 'health':
        return [
          { 
            label: `🩸 ${activeDistrict} জেলায় জরুরি রক্তদাতার সন্ধান`, 
            query: `${activeDistrict} জেলায় জরুরি রক্তদাতা এবং ব্লাড ডোনারদের সাথে কীভাবে যোগাযোগ করব?` 
          },
          { 
            label: '🏥 ইউনিয়ন কমিউনিটি ক্লিনিকে বিনামূল্যে ২৭ প্রকার ওষুধ', 
            query: 'গ্রামীণ কমিউনিটি ক্লিনিক থেকে সাধারণ মানুষ ও গর্ভবতী মায়েরা কোন কোন ওষুধ সম্পূর্ণ বিনামূল্যে পান?' 
          }
        ];

      case 'government':
        return [
          { 
            label: '📝 অনলাইনে জমির নামজারি (ই-নামজারি) ও সরকারি ফি', 
            query: 'অনলাইনে জমির খারিজ বা ই-নামজারি করার সঠিক নিয়ম কী, কী কী কাগজ লাগে এবং সরকারি মোট ফি কত?' 
          },
          { 
            label: '👴 বয়স্ক, বিধবা ও প্রতিবন্ধী ভাতার কার্ড পাওয়ার নিয়ম', 
            query: 'সমাজসেবা অধিদপ্তর থেকে বয়স্ক ভাতা ও বিধবা ভাতার কার্ড পেতে বয়স ও অন্যান্য কী কী শর্ত পূরণ করতে হয়?' 
          }
        ];

      case 'electricity':
        return [
          { 
            label: '⚡ পল্লী বিদ্যুৎ মিটারে ভুতুড়ে বিল সংশোধনের নিয়ম', 
            query: 'পল্লী বিদ্যুতের মিটারে এই মাসে অতিরিক্ত ইউনিট বা অস্বাভাবিক বিল এসেছে। এটি সংশোধন বা অভিযোগ করার সঠিক নিয়ম কী?' 
          },
          { 
            label: '💡 কৃষির সেচ পাম্পে বিদ্যুতের সাশ্রয়ী রেট', 
            query: 'ফসলের জমিতে সেচ কাজের মোটরে কৃষিবান্ধব সাশ্রয়ী বিদ্যুৎ বিল ও নতুন সংযোগ পাওয়ার নিয়ম কী?' 
          }
        ];

      case 'agriculture':
        return [
          { 
            label: '🌾 ধানের ব্লাস্ট ও আলুর নাভিধসা রোগের প্রতিকার', 
            query: 'ধানের ব্লাস্ট রোগ ও আলুর নাভিধসা রোগ দমনে কোন ছত্রাকনাশক কতটুকু মাত্রায় স্প্রে করব?' 
          },
          { 
            label: '🍆 বেগুনের পোকা দমনে জৈব ফেরোমোন ফাঁদ', 
            query: 'বেগুনে কোনো কীটনাশক বিষ ছাড়া সেক্স ফেরোমোন ফাঁদ ও নিম তেলের স্প্রে কীভাবে ব্যবহার করব?' 
          }
        ];

      case 'livestock':
        return [
          { 
            label: '🐄 গরুর ক্ষুরা ও লাম্পি স্কিন রোগের ঘরোয়া চিকিৎসা', 
            query: 'গরুর প্রচণ্ড জ্বর, মুখে ঘা ও পায়ে ক্ষতের সৃষ্টি হলে দ্রুত কী প্রাথমিক চিকিৎসা ও পটাশ পানির ব্যবহার করব?' 
          },
          { 
            label: '🐟 পুকুরের মাছের ক্ষত রোগ ও চুন প্রয়োগ', 
            query: 'পুকুরে রুই ও পাঙ্গাশ মাছের গায়ে লাল দাগ ও ঘা দেখা যাচ্ছে। প্রতি শতকে চুন ও পটাশ কতটুকু দিতে হবে?' 
          }
        ];

      case 'calculators':
        return [
          { 
            label: '📐 ১ বিঘা বা ১ কাঠায় কত শতক/শতাংশ জমি?', 
            query: 'বাংলাদেশে ১ বিঘা = কত শতাংশ বা কাঠা এবং ১ শতাংশে কত বর্গফুট জমি থাকে?' 
          },
          { 
            label: '💰 কৃষি ব্যাংক ঋণের মাসিক কিস্তির হিসাব', 
            query: 'কৃষি ব্যাংক থেকে ৫০,০০০ টাকা বার্ষিক ৮% সুদে ১ বছরের জন্য ঋণ নিলে প্রতি মাসে কিস্তি কত টাকা দিতে হবে?' 
          }
        ];

      case 'all':
      default:
        return [
          { 
            label: `🚗 ${activeUpazila} উপজেলায় সিএনজি চালক খুঁজুন`, 
            query: `${activeUpazila} উপজেলায় সিএনজি চালক কে আছেন?` 
          },
          { 
            label: `🍯 খাঁটি মধু বিক্রেতা খুঁজুন`, 
            query: `${activeDistrict} এলাকায় খাঁটি মধু বিক্রেতা কে আছেন?` 
          },
          { 
            label: `🩸 জরুরি রক্তের ডোনার খুঁজুন`, 
            query: `${activeDistrict} জেলায় রক্তের ডোনার দরকার` 
          },
          { 
            label: `🔧 ইলেকট্রিশিয়ান ও মেকার সেবা`, 
            query: `${activeUpazila} উপজেলায় অভিজ্ঞ ইলেকট্রিশিয়ান বা মেকার লাগবে` 
          },
          { 
            label: `🌾 দিনমজুর ও কৃষি শ্রমিক`, 
            query: `${activeUpazila} এলাকায় দিনমজুর ও কৃষি শ্রমিক কীভাবে পাব?` 
          },
          { 
            label: `🔄 ফিরতি পরিবহন ও খালি গাড়ি`, 
            query: `${activeUpazila} থেকে খালি ফিরতি গাড়ি বা ফিরতি পরিবহন আছে কি?` 
          },
          { 
            label: `🏠 বাসা ও মেস ভাড়া`, 
            query: `${activeDistrict} এলাকায় বাসা ভাড়া বা রুম ভাড়া আছে কি?` 
          },
          { 
            label: '📝 অনলাইনে জমির নামজারি নিয়ম', 
            query: 'অনলাইনে জমির খারিজ বা ই-নামজারি করার নিয়ম কী এবং মোট সরকারি ফি কত টাকা?' 
          }
        ];
    }
  }, [selectedCategory, activeDistrict, activeUpazila]);

  // Extract Live Public Platform Context for Grounding
  const gatherAppContext = () => {
    // 1. Live Haat Listings
    let liveListings: any[] = [];
    try {
      const savedHaat = localStorage.getItem('polli_haat_listings_v2') || localStorage.getItem('polli_haat_listings');
      if (savedHaat) {
        liveListings = JSON.parse(savedHaat);
      } else {
        liveListings = INITIAL_HAAT_LISTINGS;
      }
    } catch (e) {
      liveListings = INITIAL_HAAT_LISTINGS;
    }

    // 2. Transport Drivers
    let drivers: any[] = [];
    try {
      const savedDrivers = localStorage.getItem('polli_transport_drivers');
      if (savedDrivers) {
        drivers = JSON.parse(savedDrivers);
      } else {
        drivers = INITIAL_TRANSPORT_DRIVERS;
      }
    } catch (e) {
      drivers = INITIAL_TRANSPORT_DRIVERS;
    }

    return {
      district: activeDistrict,
      upazila: activeUpazila,
      activeListings: liveListings.map(item => ({
        title: item.title,
        category: item.category,
        price: item.price,
        unit: item.unit,
        quantity: item.quantity,
        district: item.district,
        upazila: item.upazila,
        union: item.unionOrWard,
        seller: item.sellerName,
        isSold: item.isSold
      })),
      transportDrivers: drivers.map(d => ({
        name: d.driverName,
        vehicle: d.vehicleType,
        district: d.district,
        upazila: d.upazila,
        stand: d.standLocation,
        routes: d.regularRoutes,
        shift: d.serviceShift || (d.isNightActive ? 'দিন ও রাত (২৪ ঘণ্টা)' : 'দিনে'),
        rating: d.rating
      })),
      healthServices: {
        bloodDonors: INITIAL_BLOOD_DONORS.map(b => ({
          name: b.name,
          group: b.bloodGroup,
          district: b.district,
          upazila: b.upazila,
          area: b.villageOrArea,
          available: b.isAvailable
        })),
        doctors: DOCTOR_SCHEDULES_DATA.map(doc => ({
          name: doc.doctorName,
          speciality: doc.speciality,
          hospital: doc.hospitalOrClinic,
          district: doc.district,
          timing: doc.visitingHours,
          fee: doc.fee
        }))
      },
      serviceGuides: SERVICE_OFFICE_GUIDES.map(s => ({
        service: s.serviceName,
        office: s.officeName,
        room: s.roomOrDesk,
        fees: s.fees,
        helpline: s.contactHelpline
      })),
      marketPrices: MARKET_PRICES_DATA.slice(0, 10)
    };
  };

  // Parse Action Tags from Bot Response (e.g., [ACTION:marketplace|পল্লী হাটে দেখুন] or [ACTION:marketplace:tutors|ভর্তি গাইড])
  const parseBotReply = (rawReply: string): { cleanText: string; actions: Array<{ target: ServiceCategory; label: string; subTab?: string }> } => {
    const actionRegex = /\[ACTION:([a-zA-Z0-9_:-]+)(?:\|([^\]]+))?\]/g;
    const actions: Array<{ target: ServiceCategory; label: string; subTab?: string }> = [];
    
    let cleanText = rawReply.replace(actionRegex, (_, targetCategoryWithSub, label) => {
      let targetCategory = targetCategoryWithSub;
      let subTab: string | undefined = undefined;

      if (targetCategoryWithSub.includes(':')) {
        const parts = targetCategoryWithSub.split(':');
        targetCategory = parts[0];
        subTab = parts[1];
      }

      const validTarget = targetCategory as ServiceCategory;
      const cleanLabel = label || 'সেবায় সরাসরি যান';

      // Infer subTab if not explicitly set in tag
      if (!subTab) {
        if (validTarget === 'marketplace' && (cleanLabel.includes('ভর্তি') || cleanLabel.includes('শিক্ষক') || cleanLabel.includes('টিউটর'))) {
          subTab = 'tutors';
        } else if (validTarget === 'health' && (cleanLabel.includes('ডাক্তার') || cleanLabel.includes('হাসপাতাল'))) {
          subTab = 'doctors';
        } else if (validTarget === 'agriculture' && (cleanLabel.includes('ডাক্তার') || cleanLabel.includes('রোগ'))) {
          subTab = 'doctor';
        } else if (validTarget === 'agriculture' && cleanLabel.includes('সার')) {
          subTab = 'fertilizer';
        } else if (validTarget === 'electricity' && cleanLabel.includes('অভিযোগ')) {
          subTab = 'complaints';
        } else if (validTarget === 'service-finder' && cleanLabel.includes('ভাতা')) {
          subTab = 'allowances';
        } else if (validTarget === 'calculators' && cleanLabel.includes('ঋণ')) {
          subTab = 'loan';
        } else if (validTarget === 'calculators' && cleanLabel.includes('জমি')) {
          subTab = 'land';
        }
      }

      actions.push({
        target: validTarget,
        label: cleanLabel,
        subTab
      });
      return '';
    }).trim();

    // If query or reply was clearly about specific services and no action was generated, append appropriate direct action
    if (actions.length === 0) {
      if (rawReply.includes('সেবা ফ্লো') || rawReply.includes('ধাপে ধাপে') || rawReply.includes('এলাকাভিত্তিক') || rawReply.includes('ওয়ার্ড/গ্রাম')) {
        actions.push({ target: 'services', label: '📋 ২৬টি সেবা তালিকা' });
      } else if (rawReply.includes('টিউটর') || rawReply.includes('গৃহশিক্ষক') || rawReply.includes('পড়াতে চাই') || rawReply.includes('শিক্ষার্থী')) {
        actions.push({ target: 'marketplace', label: '📚 গৃহশিক্ষক ও শিক্ষার্থী', subTab: 'tutors' });
      } else if (rawReply.includes('মেকানিক') || rawReply.includes('মিস্ত্রি') || rawReply.includes('ওয়ার্কশপ') || rawReply.includes('ইলেকট্রিশিয়ান')) {
        actions.push({ target: 'marketplace', label: '🔧 মেকানিক ও কারিগর', subTab: 'mechanics' });
      } else if (rawReply.includes('দিনমজুর') || rawReply.includes('শ্রমিক') || rawReply.includes('কামলা') || rawReply.includes('কৃষি শ্রমিক')) {
        actions.push({ target: 'marketplace', label: '🌾 দিনমজুর ও কৃষি শ্রমিক', subTab: 'labor' });
      } else if (rawReply.includes('ভর্তি') || rawReply.includes('মেডিকেল') || rawReply.includes('বিশ্ববিদ্যালয়')) {
        actions.push({ target: 'marketplace', label: '🎓 ভর্তি গাইড ও টিউটর দেখুন', subTab: 'tutors' });
      } else if (rawReply.includes('পল্লী হাট') || rawReply.includes('শাকসবজি') || rawReply.includes('কেজি') || rawReply.includes('মণ')) {
        actions.push({ target: 'marketplace', label: '🛒 পল্লী হাটে সরাসরি পণ্য দেখুন' });
      } else if (rawReply.includes('গাড়ি') || rawReply.includes('চালক') || rawReply.includes('ইজিবাইক') || rawReply.includes('পরিবহন')) {
        actions.push({ target: 'transport', label: '🚗 এলাকার গাড়ি ও চালক দেখুন' });
      } else if (rawReply.includes('রক্ত') || rawReply.includes('ডাক্তার') || rawReply.includes('হাসপাতাল')) {
        actions.push({ target: 'health', label: '🏥 স্বাস্থ্য ও ডাক্তার তালিকা' });
      } else if (rawReply.includes('নামজারি') || rawReply.includes('ভাতা') || rawReply.includes('জন্ম নিবন্ধন')) {
        actions.push({ target: 'service-finder', label: '🏛️ সরকারি সেবা সহায়িকা' });
      } else if (rawReply.includes('বিদ্যুৎ') || rawReply.includes('মিটার')) {
        actions.push({ target: 'electricity', label: '⚡ বিদ্যুৎ বিল ও অভিযোগ' });
      }
    }

    return { cleanText, actions };
  };

  // Local Intelligent Knowledge Responder Fallback (Empathetic, Conversational & Context-Aware)
  const generateLocalKnowledgeReply = (query: string): { text: string; actions: Array<{ target: ServiceCategory; label: string; subTab?: string }> } => {
    const rawQ = query.trim();
    const q = rawQ.toLowerCase();
    const appContext = gatherAppContext();

    // 1. Islamic & Cultural Greetings (সালাম, আদাব, নমস্কার, শুভেচ্ছা)
    const isGreeting = /(আসসালামু|সালাম|আদাব|নমস্কার|hello|hi|hey|slm|salam|assalamu)/i.test(q);
    if (isGreeting) {
      const salamReply = q.includes('সালাম') || q.includes('salam') || q.includes('আসসালামু')
        ? 'ওয়ালাইকুম আসসালাম ওয়া রাহমাতুল্লাহ!'
        : 'নমস্কার ও আন্তরিক শুভেচ্ছা!';

      return {
        text: `${salamReply} 🌸\n\nআলহামদুলিল্লাহ, আমি ভালো আছি। আশা করি আপনিও সুস্থ ও নিরাপদে আছেন।\n\nআমি "পল্লী সেবা" অ্যাপের সার্বক্ষণিক এআই সহায়ক ও গাইড। অ্যাপের যেকোনো বিভাগ (পল্লী হাট, ভর্তি গাইড, শস্য ডাক্তার, রক্তদাতা, পরিবহন, বিদ্যুৎ ও সরকারি সেবা) কোথায় পাবেন এবং কীভাবে ব্যবহার করবেন, তা জানতে আমাকে যেকোনো প্রশ্ন করতে পারেন।`,
        actions: [
          { target: 'marketplace', label: '🛒 পল্লী হাট ও ভর্তি গাইড', subTab: 'tutors' },
          { target: 'health', label: '🩸 রক্ত ও স্বাস্থ্যসেবা' },
          { target: 'service-finder', label: '🏛️ সরকারি সেবা গাইড' }
        ]
      };
    }

    // 2. Education & Admission Guide (মেডিকেল ভর্তি, বিশ্ববিদ্যালয়, ক্যাডেট, উন্মুক্ত)
    const isEducationOrAdmission = /(ভর্তি|মেডিকেল|এমবিবিএস|mbbs|বিশ্ববিদ্যালয়|বিশ্ববিদ্যালয়|ক্যাডেট|উন্মুক্ত|bou|টিশন|টিউটর|গৃহশিক্ষক|শিক্ষার্থী|পড়াশোনা|পড়াশোনা|এডমিশন|admission)/i.test(q);
    if (isEducationOrAdmission) {
      return {
        text: `🎓 **উচ্চশিক্ষা ও মেডিকেল ভর্তি গাইড এবং গৃহশিক্ষক সেবা:**\n\n` +
          `**১. মেডিকেল (MBBS) ভর্তি পরীক্ষার যোগ্যতা:**\n` +
          `• **বিভাগ:** এসএসসি (SSC) ও এইচএসসি (HSC) উভয় পরীক্ষায় বিজ্ঞান বিভাগ আবশ্যক।\n` +
          `• **মোট জিপিএ:** মোট ন্যূনতম জিপিএ **৯.০০** থাকতে হবে (উপজাতীয়দের জন্য ৮.০০)।\n` +
          `• **জীববিজ্ঞান:** এইচএসসিতে জীববিজ্ঞানে ন্যূনতম জিপিএ **৪.০০** থাকতে হবে।\n` +
          `• **পরীক্ষার মানবণ্টন (১০০ নম্বর):** জীববিজ্ঞান ৩০, রসায়ন ২৫, পদার্থ ১৫, ইংরেজি ১৫, সাধারণ জ্ঞান ১০। (প্রতি ভুল উত্তরে ০.২৫ নম্বর কাটা যায়)।\n` +
          `• **জিপিএ স্কোর:** এসএসসি ও এইচএসসি জিপিএ-র ওপর ১০০ নম্বর যোগ হয়।\n\n` +
          `**২. গৃহশিক্ষক ও শিক্ষার্থী নেটওয়ার্ক:**\n` +
          `• আপনার এলাকায় বিষয়ভিত্তিক গৃহশিক্ষক খুঁজতে বা পড়ানোর বিজ্ঞপ্তি দিতে নিচের বাটনে ক্লিক করুন।\n\n` +
          `---\n` +
          `📱 **অ্যাপের ঠিক কোথায় এই পূর্ণাঙ্গ নির্দেশিকা পাবেন:**\n` +
          `অ্যাপের পল্লী হাট থেকে 'গৃহশিক্ষক ও শিক্ষার্থী' ট্যাবে ক্লিক করলে ভর্তি গাইড ও টিউটরদের সরাসরি তালিকা দেখতে পাবেন।`,
        actions: [
          { target: 'marketplace', label: '📚 গৃহশিক্ষক ও শিক্ষার্থী বোর্ড', subTab: 'tutors' },
          { target: 'services', label: '📋 ২৬টি নাগরিক সেবা তালিকা' }
        ]
      };
    }

    // 2A. Hierarchical Service & Citizen Services Directory (২৬টি উন্মুক্ত সেবা)
    const isServiceFlow = /(সেবা ফ্লো|এলাকাভিত্তিক|ধাপে ধাপে সেবা|সার্ভিস ফ্লো|২৪টি সেবা|২৬টি সেবা|নাগরিক সেবা|service flow|step by step)/i.test(q);
    if (isServiceFlow) {
      return {
        text: `📋 **পল্লী সেবার ২৬টি উন্মুক্ত নাগরিক সেবা:**\n\n` +
          `পল্লী সেবা প্ল্যাটফর্মে গ্রামীণ জীবনের প্রয়োজনীয় ২৬টি সেবা সরাসরি উন্মুক্ত করা হয়েছে:\n\n` +
          `• ১. পল্লী হাট ও তরিতরকারি\n` +
          `• ২. পল্লী পরিবহন ও নিরাপদ চালক\n` +
          `• ৩. কৃষিন ও দিনমজুর শ্রমিক বাজার\n` +
          `• ৪. ইলেকট্রিশিয়ান ও জরুরি মেকানিক\n` +
          `• ৫. গৃহশিক্ষক ও শিক্ষার্থী সংযোগ\n` +
          `• ৬. জরুরি রক্তদাতা ও ব্লাড ব্যাংক\n` +
          `• ৭. কী সেবা কোথায় কীভাবে পাবেন\n` +
          `• ৮. নামাজের সময়সূচি, সালাত ও সূরা\n` +
          `• ২৫. আবাসন ও বাসা ভাড়া সার্ভিস\n` +
          `• ২৬. পাত্র-পাত্রীর সন্ধান (ছবিমুক্ত মেচমেকিং) এবং অন্যান্য জরুরি নাগরিক সেবা।\n\n` +
          `সরাসরি সকল সেবা দেখতে নিচের বাটনে ক্লিক করুন:`,
        actions: [
          { target: 'services', label: '📋 ২৬টি নাগরিক সেবা দেখুন' },
          { target: 'marketplace', label: '🛒 সরাসরি পল্লী হাট দেখুন' }
        ]
      };
    }

    // 2B. Mechanics & Local Technicians (মেকানিক, মিস্ত্রি, টিউবওয়েল, মোটরসাইকেল, ওয়ার্কশপ)
    const isMechanic = /(মেকানিক|মিস্ত্রি|ইলেকট্রিশিয়ান|মোটরসাইকেল|টিউবওয়েল|শ্যালো মেশিন|ওয়ার্কশপ|প্লাম্বার|কারিগর)/i.test(q);
    if (isMechanic) {
      return {
        text: `🔧 **স্থানীয় মেকানিক ও কারিগর নেটওয়ার্ক:**\n\n` +
          `গ্রামীণ এলাকায় কৃষি যন্ত্রপাতি, গৃহস্থালি বৈদ্যুতিক কাজ ও যানবাহনের জন্য বিশ্বস্ত মেকানিক পাওয়া এখন সহজ:\n\n` +
          `• **সেবাসমূহ:** টিউবওয়েল ও পাম্প মেরামত, মোটরসাইকেল সার্ভিসিং, শ্যালো মেশিন, ফ্যান-মোটর ওয়্যারিং ও প্লাম্বিং।\n` +
          `• **সরাসরি যোগাযোগ:** মেকানিকদের ফোন নম্বর, এলাকা ও রেটিং দেখে সরাসরি কল দিতে পারেন।\n` +
          `• **জরুরি বিজ্ঞাপন:** আপনার কোনো মেরামত কাজের প্রয়োজন হলে সরাসরি জরুরি মেকানিক চেয়ে বিজ্ঞাপন পোস্ট করতে পারেন।`,
        actions: [
          { target: 'marketplace', label: '🔧 মেকানিক ও কারিগর বোর্ড খুলুন', subTab: 'mechanics' },
          { target: 'services', label: '📋 সকল সেবা তালিকা' }
        ]
      };
    }

    // 2C. Daily Wage Labor & Agricultural Workers (দিনমজুর, কৃষি শ্রমিক, কামলা, ধান কাটা)
    const isLabor = /(শ্রমিক|কামলা|দিনমজুর|ধান কাটা|কৃষি শ্রমিক|মজুর|মাটি কাটা|রাজমিস্ত্রি)/i.test(q);
    if (isLabor) {
      return {
        text: `🌾 **দিনমজুর ও কৃষি শ্রমিক নেটওয়ার্ক:**\n\n` +
          `ফসল রোপণ, ধান কাটা, জমি তৈরি বা নির্মাণ কাজের জন্য স্থানীয় অভিজ্ঞ দিনমজুরের দল পেতে পারেন:\n\n` +
          `• **মজুরির হার:** আপনার ইউনিয়ন ও উপজেলায় দৈনিক চলতি মজুরির হার (দৈনিক খাবারসহ/ছাড়া) দেখা যায়।\n` +
          `• **দলগত বুকিং:** একক শ্রমিক বা দলনেতা (সর্দার)-এর সাথে অগ্রিম কাজের দিন নির্ধারণ করে বুকিং করা যায়।\n` +
          `• **সরাসরি সংযোগ:** কোনো মধ্যস্বত্বভোগী বা দালাল ছাড়া সরাসরি কৃষকের সাথে শ্রমিকের ফোন বা মেসেজ সংযোগ।`,
        actions: [
          { target: 'marketplace', label: '🌾 দিনমজুর ও শ্রমিক তালিকা দেখুন', subTab: 'labor' },
          { target: 'services', label: '📋 সকল সেবা তালিকা' }
        ]
      };
    }

    // 3. App Navigation & All Features Inquiries (অ্যাপসের যাবতীয় তথ্য, কোথায় কি আছে, গাইড)
    const isAppNavOrKnowledge = /(অ্যাপসের যাবতীয়|অ্যাপসের যাবতীয়|কি কি তথ্য|কী তথ্য|সব তথ্য|সহায়ক|সহায়ক|গাইড|কোথায় গেলে|কোন অপশন|কোন বাটনে|অ্যাপ সম্পর্কে|সব অপশন|হাতে কি আছে)/i.test(q);
    if (isAppNavOrKnowledge) {
      return {
        text: `📱 **"পল্লী সেবা" অ্যাপের সম্পূর্ণ নেভিগেশন ম্যাপ ও সেবা তালিকা:**\n\n` +
          `ব্যক্তিগত গোপনীয়তা রক্ষা করে অ্যাপের যাবতীয় সেবা ও নির্দেশিকা পাওয়ার সম্পূর্ণ গাইড নিচে তুলে ধরা হলো:\n\n` +
          `১. 🛒 **পল্লী হাট ও সেবা বাজার (Marketplace):**\n` +
          `   - বিষমুক্ত কৃষিপণ্য ও ফলমূল বেচাকেনা।\n` +
          `   - 'গৃহশিক্ষক ও শিক্ষার্থী' ট্যাবে গেলে পাবেন **🎓 ভর্তি গাইড** (মেডিকেল, বিশ্ববিদ্যালয়, ক্যাডেট ও উন্মুক্ত)।\n` +
          `   - স্থানীয় দিনমজুর ও টিউবওয়েল মিস্ত্রি বুকিং।\n\n` +
          `২. 🩸 **রক্ত ও জরুরি স্বাস্থ্যসেবা (Health):**\n` +
          `   - রক্তের গ্রুপ অনুযায়ী রক্তদাতা সন্ধান, পল্লি ডাক্তার ও সরকারি অ্যাম্বুলেন্স তালিকা।\n\n` +
          `৩. 🌾 **কৃষি ও শস্য ডাক্তার (Agriculture):**\n` +
          `   - ফসলের আক্রান্ত পাতার ছবি দিয়ে রোগ সনাক্তকরণ, সার ক্যালকুলেটর ও লাইভ বাজারদর।\n\n` +
          `৪. 🚗 **নিরাপদ পরিবহন (Transport):**\n` +
          `   - স্থানীয় ভ্যান, সিএনজি, ইজিবাইক ও পিকআপ চালকের তালিকা এবং ইন-অ্যাপ কল।\n\n` +
          `৫. ⚡ **পল্লী বিদ্যুৎ ও বিল (Electricity):**\n` +
          `   - ভুতুড়ে বিল যাচাই ক্যালকুলেটর ও লোডশেডিং অভিযোগ ফরম।\n\n` +
          `৬. 🏛️ **সরকারি সেবা ও হটলাইন (Government):**\n` +
          `   - জমির ই-নামজারি (১,১৭০ টাকা ফি), সরকারি বয়স্ক/বিধবা ভাতা এবং জরুরি হেল্পলাইন (৯৯৯, ৩৩৩, ১৬১২২)।\n\n` +
          `৭. 🧮 **ক্যালকুলেটর:** জমি পরিমাপ (শতাংশ, কাঠা) ও ঋণের কিস্তির হিসাব।\n\n` +
          `আপনি যেকোনো সেবায় সরাসরি যেতে নিচের বাটনে ক্লিক করতে পারেন।`,
        actions: [
          { target: 'marketplace', label: '🛒 পল্লী হাট ও ভর্তি গাইড', subTab: 'tutors' },
          { target: 'health', label: '🩸 রক্ত ও স্বাস্থ্যসেবা' },
          { target: 'service-finder', label: '🏛️ সরকারি সেবা' }
        ]
      };
    }

    // 2. Well-being & Courtesy Inquiries (কেমন আছেন, কুশল বিনিময়)
    const isWellBeing = /(কেমন আছেন|কেমন আছো|ভালো আছেন|ভালো আছো|শরীর কেমন|কী খবর|কি খবর|how are you|kemon achen)/i.test(q);
    if (isWellBeing) {
      return {
        text: `আলহামদুলিল্লাহ, পরম করুণাময়ের অশেষ রহমতে আমি বেশ ভালো আছি! 😊\n\nআশা করি আপনার দিনটি সুন্দর ও শান্তিময় কাটছে। গ্রামীণ জীবনের দৈনন্দিন সুযোগ-সুবিধা ও সেবা সহজ করতেই আমার উপস্থিতি।\n\nআপনার এলাকায় ফসলের সমস্যা, হাটবাজারের দরদাম, স্থানীয় গাড়িচালক, জরুরি রক্ত কিংবা সরকারি সহায়তার কোনো তথ্য প্রয়োজন হলে নির্দ্বিধায় আমাকে জিজ্ঞেস করুন।`,
        actions: [
          { target: 'marketplace', label: '🛒 বাজারদর ও পণ্য' },
          { target: 'health', label: '🏥 স্বাস্থ্য ও রক্তদাতা' },
          { target: 'service-finder', label: '🏛️ সরকারি সেবা গাইড' }
        ]
      };
    }

    // 3. Identity & Assistant Role (কে তুমি, আপনি কে, পরিচয়, তোমার কাজ কি)
    const isIdentity = /(কে তুমি|আপনি কে|তোমার নাম|আপনার নাম|তোমার পরিচয়|আপনার পরিচয়|তোমার কাজ|পল্লী সহায়ক কি|এআই কি|who are you|what can you do)/i.test(q);
    if (isIdentity) {
      return {
        text: `আমি **পল্লী সেবা এআই সহকারী**—বাংলাদেশের গ্রামীণ কৃষক ও সাধারণ মানুষের ডিজিটাল বন্ধু ও বিশ্বস্ত তথ্য গাইড। 🌾\n\n**আমার মূল কাজ ও সহায়তার ক্ষেত্রসমূহ:**\n• **🌾 কৃষি ও ফসল:** ধানের রোগবালাই দমন, সার-কীটনাশকের সঠিক মাত্রা ও আধুনিক চাষাবাদ পরামর্শ।\n• **🛒 পল্লী হাট:** আপনার জেলা ও উপজেলার কৃষকদের তাজা শাকসবজি, শস্য ও লাইভ বাজারদর।\n• **🚗 নিরাপদ পরিবহন:** এলাকার ভ্যান, ইজিবাইক, সিএনজি ও পিকআপ চালকদের তালিকা ও রুট।\n• **🩸 রক্তদাতা ও স্বাস্থ্য:** জরুরি প্রয়োজনে রক্তের গ্রুপের ডোনার এবং সরকারি স্বাস্থ্যকেন্দ্রের তথ্য।\n• **🏛️ সরকারি সেবা ও বিদ্যুৎ:** জমিজমার ই-নামজারি, বয়স্ক/বিধবা ভাতা ও বিদ্যুৎ বিলের সঠিক নিয়ম।\n\nআপনার যেকোনো প্রয়োজনীয় সেবার নাম লিখে প্রশ্ন করুন!`,
        actions: [
          { target: 'marketplace', label: '🛒 পল্লী হাট দেখুন' },
          { target: 'transport', label: '🚗 পরিবহন চালক খুঁজুন' },
          { target: 'health', label: '🩸 রক্তদাতা সন্ধান' }
        ]
      };
    }

    // 4. Gratitude & Politeness (ধন্যবাদ, শুকরিয়া, জাযাকাল্লাহ)
    const isGratitude = /(ধন্যবাদ|থ্যাংক|থ্যাংকস|শুকরিয়া|শুকরিয়া|জাযাকাল্লাহ|অনেক ভালো|ভালো লাগল|thanks|thank you)/i.test(q);
    if (isGratitude) {
      return {
        text: `আপনাকেও অনেক অনেক ধন্যবাদ ও আন্তরিক কৃতজ্ঞতা! 😊\n\nআপনার সেবায় আসতে পেরে আমি আনন্দিত। পল্লী সেবা অ্যাপ সবসময় আপনার পাশে আছে। ভবিষ্যতে ফসলের রোগ, হাটবাজার, গাড়ি কিংবা জরুরি রক্তের প্রয়োজনে যেকোনো সময় আমার সাহায্য নিতে পারেন।\n\nআপনার দিনটি মঙ্গলময় ও আনন্দময় হোক! 🌾`,
        actions: [
          { target: 'marketplace', label: '🛒 পল্লী হাট' },
          { target: 'agriculture', label: '🌾 কৃষি পরামর্শ' }
        ]
      };
    }

    // 5. Privacy, Confidentiality & Anti-Fraud Guidelines (ব্যক্তিগত তথ্য, গোপন নম্বর, টাকা পাঠানো)
    const isPrivacyOrSecurity = /(মোবাইল নম্বর|ফোন নম্বর|ব্যক্তিগত তথ্য|পাসওয়ার্ড|পাসওয়ার্ড|টাকা পাঠাব|অগ্রিম টাকা|বিকাশ নম্বর|নগদ নম্বর|হ্যাক|এনআইডি কার্ড|গোপন নম্বর|টাকা দেওয়া)/i.test(q);
    if (isPrivacyOrSecurity) {
      return {
        text: `🔒 **ব্যক্তিগত তথ্য ও নিরাপত্তা সুরক্ষা সতর্কতা:**\n\nপল্লী সেবা প্ল্যাটফর্ম ব্যবহারকারীদের ব্যক্তিগত গোপনীয়তা ও আর্থিক নিরাপত্তাকে সর্বোচ্চ গুরুত্ব দেয়।\n\n• **গোপনীয়তার নীতি:** রক্তদাতা, কৃষক বা চালকদের ব্যক্তিগত ফোন নম্বর বা গোপনীয় তথ্য উন্মুক্তভাবে সরাসরি চ্যাটে প্রচার করা হয় না।\n• **অনুমোদিত যোগাযোগ:** রক্তদাতা বা চালকদের অনুমোদিত যোগাযোগের জন্য অ্যাপের 'স্বাস্থ্য ও রক্তদাতা' অথবা 'পরিবহন' বিভাগে গিয়ে সরাসরি ইন-অ্যাপ কল বা মেসেজ ব্যবহার করুন।\n• **আর্থিক প্রতারণা সতর্কতা:** কোনো অপরিচিত ব্যক্তিকে অগ্রিম বিকাশ বা নগদ অ্যাকাউন্টে টাকা পাঠাবেন না। হাটের পণ্য সরাসরি দেখে যাচাই করে লেনদেন করুন।\n• **দালালমুক্ত সরকারি সেবা:** জমি নামজারি বা সরকারি ভাতার জন্য কোনো মধ্যস্বত্বভোগী বা দালালকে অর্থ দেবেন না; সকল সরকারি সেবা সম্পূর্ণ নির্ধারিত নীতিমালায় চলে।`,
        actions: [
          { target: 'health', label: '🩸 নিরাপদ রক্তদাতা যোগাযোগ' },
          { target: 'transport', label: '🚗 ভেরিফাইড চালক তালিকা' }
        ]
      };
    }

    // 6. Blood Donors & Health Care (রক্ত, রক্তদাতা, ব্লাড, ডাক্তার, হাসপাতাল)
    const isBloodOrHealth = /(রক্ত|রক্তদাতা|ব্লাড|blood|ডোনার|ডাক্তার|হাসপাতাল|ক্লিনিক|চেম্বার|চিকিৎসা|ওষুধ|ঔষধ|রোগী)/i.test(q);
    if (isBloodOrHealth) {
      const donors = appContext.healthServices?.bloodDonors || [];
      const districtDonors = donors.filter((d: any) => 
        activeDistrict === 'সকল জেলা' || d.district === activeDistrict || q.includes(d.district?.toLowerCase() || '')
      );
      const doctors = appContext.healthServices?.doctors || [];

      let responseText = `🩸 **${activeDistrict} ও গ্রামীণ স্বাস্থ্য ও জরুরি রক্ত সহায়তা:**\n\n`;
      if (q.includes('রক্ত') || q.includes('blood') || q.includes('ডোনার')) {
        responseText += `• **নিবন্ধিত রক্তদাতা সংখ্যা:** ${districtDonors.length > 0 ? `${districtDonors.length} জন স্বেচ্ছাসেবী প্রস্তুত` : 'বর্তমানে এলাকাভিত্তিক রক্তদাতা তালিকা অ্যাপে সংরক্ষিত রয়েছে'}\n`;
        if (districtDonors.length > 0) {
          responseText += districtDonors.slice(0, 3).map((d: any, i: number) => 
            `  ${i + 1}. **${d.name}** (গ্রুপ: **${d.group}**) — ${d.upazila || d.area}, ${d.district} (${d.status === 'available' ? '✅ প্রস্তুত' : '⏳ কিছুদিন আগে দিয়েছেন'})`
          ).join('\n') + '\n';
        }
        responseText += `\n💡 **রক্তদাতার সাথে যোগাযোগ:** রোগীর জরুরি রক্তের গ্রুপ মিলিয়ে সরাসরি তালিকা থেকে কল করতে নিচের বাটনটি চাপুন।\n\n`;
      }

      if (q.includes('ডাক্তার') || q.includes('হাসপাতাল') || q.includes('চিকিৎসা') || q.includes('রোগ')) {
        responseText += `🏥 **জরুরি চিকিৎসা ও হাসপাতাল নির্দেশিকা:**\n`;
        if (doctors.length > 0) {
          responseText += doctors.slice(0, 2).map((doc: any, i: number) => 
            `• **${doc.name}** (${doc.specialty}) — ${doc.hospital}, রোগী দেখার সময়: ${doc.visitingHours}`
          ).join('\n') + '\n';
        }
        responseText += `• **উপজেলা স্বাস্থ্য কমপ্লেক্স:** সরকারি হাসপাতালে সকাল ৮টা থেকে দুপুর ২টা পর্যন্ত মাত্র ৩-৫ টাকার টিকিটে বিশেষজ্ঞ সেবা পাওয়া যায়।\n`;
      }

      responseText += `\n📞 **জরুরি জাতীয় হটলাইন:**\n• জাতীয় জরুরি সেবা: **৯৯৯**\n• স্বাস্থ্য বাতায়ন (২৪ ঘণ্টা ফ্রি ডাক্তার পরামর্শ): **১৬২৬৩**`;

      return {
        text: responseText,
        actions: [
          { target: 'health', label: '🩸 রক্তদাতা ও ডাক্তার তালিকায় যান' }
        ]
      };
    }

    // 7. Agriculture, Crops, Fertilizer & Pests (কৃষি, ফসল, সার, পোকা, ছত্রাক)
    const isAgriculture = /(কৃষি|ফসল|ধান|গম|পাট|আলু|বেগুন|টমেটো|মরিচ|পোকা|কীটনাশক|ছত্রাক|ব্লাস্ট|মাজরা|ইউরিয়া|টিএসপি|ডিএপি|পটাশ|সার|চাষাবাদ|বোরো|আমন)/i.test(q);
    if (isAgriculture) {
      return {
        text: `🌾 **কৃষি ও ফসল সুরক্ষা নির্দেশিকা (${activeDistrict}):**\n\n` +
          `• **সুষম সার প্রয়োগ:** ধানের জমিতে এককভাবে বেশি ইউরিয়া না দিয়ে বিঘাপ্রতি সঠিক মাত্রায় ডিএপি, টিএসপি, এমওপি (পটাশ) ও জিপসাম ব্যবহার করুন। শেষ চাষের সময় টিএসপি ও পটাশের অর্ধেক প্রয়োগ করুন।\n` +
          `• **পোকা ও রোগবালাই দমন:**\n` +
          `  - **মাজরা পোকা:** জমিতে ডালপালা পুঁতে পার্চিং (পাখি বসার ব্যবস্থা) করুন এবং আলোর ফাঁদ ব্যবহার করুন। আক্রমণ বেশি হলে অনুমোদিত দানাদার কীটনাশক ব্যবহার করুন।\n` +
          `  - **ধানের ব্লাস্ট বা পাতা পোড়া রোগ:** জমিতে জমাট পানি সরিয়ে দিন, ইউরিয়া বন্ধ রাখুন এবং ট্রাইসাইক্লাজল বা অ্যাজোক্সিস্ট্রবিন গ্রুপের ছত্রাকনাশক অনুমোদিত মাত্রায় বিকেলে স্প্রে করুন।\n` +
          `• **জৈব বালাইনাশক:** নিম পাতার রস ও ছাই প্রয়োগে প্রাথমিক পোকামাকড় কার্যকরভাবে দূর করা সম্ভব।\n\n` +
          `📞 **কৃষি কল সেন্টার:** যেকোনো ফসলের জটিল সমস্যায় সরাসরি কৃষিবিদদের সাথে কথা বলতে কল করুন **১৬১২৩** (সকাল ৯টা - বিকেল ৫টা)।`,
        actions: [
          { target: 'agriculture', label: '🌾 শস্য ডাক্তার ও সার ক্যালকুলেটর' },
          { target: 'marketplace', label: '🛒 কৃষি উপকরণ ও সার হাট' }
        ]
      };
    }

    // 8. Livestock & Animal Husbandry (পশুপালন, গরু, ছাগল, মুরগি, খামার)
    const isLivestock = /(গরু|ছাগল|বাছুর|মহিষ|মুরগি|হাঁস|পশুপালন|খামার|পক্স|তড়কা|ক্ষুরারোগ|কৃমি|পশুর চিকিৎসা|দুধ)/i.test(q);
    if (isLivestock) {
      return {
        text: `🐄 **গবাদিপশু ও হাঁস-মুরগি লালন-পালন সহায়িকা:**\n\n` +
          `• **ক্ষুরারোগ ও তড়কা প্রতিরোধ:** বর্ষা ও শীতের শুরুতে নিকটস্থ উপজেলা প্রাণিসম্পদ দপ্তর থেকে গবাদিপশুকে নিয়মমাফিক ভ্যাকসিন বা টিকা প্রদান করুন।\n` +
          `• **নিয়মিত কৃমিনাশক:** প্রতি ৩-৪ মাস পর পর পশুর শারীরিক ওজন অনুযায়ী পশু চিকিৎসকের পরামর্শে কৃমিনাশক ট্যাবলেট খাওয়ান।\n` +
          `• **পুষ্টিকর খাদ্য ও পরিচর্যা:** কাঁচা ঘাসের সাথে শুকনো খড়, খৈল, ভুসি ও পরিমিত লবণ মিশিয়ে সুষম খাদ্য দিন। সর্বদা বিশুদ্ধ খাবার পানি নিশ্চিত করুন।\n` +
          `• **হাঁস-মুরগির রানীক্ষেত ও বসন্ত:** খামার সবসময় শুকনো ও জীবাণুমুক্ত রাখুন। অসুস্থ পাখিকে দ্রুত আলাদা করে কোয়ারেন্টাইনে রাখুন।\n\n` +
          `📞 **প্রাণিসম্পদ হটলাইন:** যেকোনো জরুরি পশুর চিকিৎসায় কৃষি কল সেন্টার **১৬১২৩** অথবা উপজেলা প্রাণিসম্পদ হাসপাতালে যোগাযোগ করুন।`,
        actions: [
          { target: 'livestock', label: '🐄 পশুপালন চিকিৎসা ও খামার গাইড' }
        ]
      };
    }

    // 9. Specific District / Haat / Marketplace Checks
    if (q.includes('পটুয়াখালী') || q.includes('পটুয়াখালী') || q.includes('বাউফল') || (activeDistrict === 'পটুয়াখালী' && (q.includes('সবজি') || q.includes('পণ্য') || q.includes('দরদাম') || q.includes('দাম')))) {
      const patuakhaliItems = appContext.activeListings.filter(item => item.district === 'পটুয়াখালী' || item.upazila === 'বাউফল');
      let responseText = `**পটুয়াখালী জেলার বাউফল উপজেলার বর্তমান পল্লী হাটের লাইভ পণ্যের তথ্য:** 🥬\n\n`;
      if (patuakhaliItems.length > 0) {
        patuakhaliItems.forEach((item, idx) => {
          responseText += `${idx + 1}. **${item.title}**\n   - **দাম:** ৳${item.price} (${item.unit})\n   - **পরিমাণ:** ${item.quantity}\n   - **স্থান:** ${item.union || 'বাউফল'}, ${item.upazila}\n   - **বিক্রেতা:** ${item.seller}\n\n`;
        });
      } else {
        responseText += `• **দেশি মিষ্টি লাউ ও শিম:** ৪০-৫০ টাকা/পিস (কালাইয়া বন্দর আড়ত)\n• **তাজা গোল বেগুন ও কাঁচামরিচ:** ৪৫ টাকা/কেজি ও ৮০ টাকা/কেজি (বাউফল কাঁচাবাজার)\n• **কাঁচা পেঁপে ও মিষ্টি কুমড়া:** ৩০-৩৫ টাকা/কেজি\n\n`;
      }
      responseText += `🚗 **বাউফলের স্থানীয় পরিবহন সুবিধা:** কালাইয়া বন্দর ও বাউফল লঞ্চঘাট থেকে মোঃ কালাম হাওলাদারের ইজিবাইক ও মোঃ শাহিন মিয়ার পণ্যবাহী পিকআপ সচল রয়েছে।\n\n🛡️ **নিরাপত্তা সতর্কতা:** পণ্য সরাসরি দেখে যাচাই করে মূল্য পরিশোধ করুন। কোনো অপরিচিতকে অগ্রিম বিকাশ বা নগদে টাকা পাঠাবেন না।`;
      return {
        text: responseText,
        actions: [
          { target: 'marketplace', label: '🛒 বাউফলের পণ্য পল্লী হাটে দেখুন' },
          { target: 'transport', label: '🚗 বাউফলের গাড়ি ও চালক দেখুন' }
        ]
      };
    }

    if (q.includes('দিনাজপুর') || q.includes('বীরগঞ্জ') || (activeDistrict === 'দিনাজপুর' && (q.includes('চাল') || q.includes('লিচু') || q.includes('আলু') || q.includes('পণ্য')))) {
      const dinajpurItems = appContext.activeListings.filter(item => item.district === 'দিনাজপুর');
      let responseText = `**দিনাজপুর জেলার বর্তমান কৃষি পণ্য ও হাটের দরদাম:** 🌾\n\n`;
      if (dinajpurItems.length > 0) {
        dinajpurItems.forEach((item, idx) => {
          responseText += `${idx + 1}. **${item.title}**\n   - **দাম:** ৳${item.price} (${item.unit})\n   - **পরিমাণ:** ${item.quantity}\n   - **স্থান:** ${item.district} (${item.upazila})\n   - **বিক্রেতা:** ${item.seller}\n\n`;
        });
      } else {
        responseText += `• **দিনাজপুরের সুগন্ধি কাটারিভোগ চাল:** ৮২ টাকা/কেজি (বাহাদুর বাজার)\n• **নতুন কার্ডিনাল গোল আলু:** ২৮ টাকা/কেজি\n• **রসালো বোম্বাই লিচু (বীরগঞ্জ):** ৩৮০ টাকা/শতক\n\n`;
      }
      responseText += `🚗 **দিনাজপুর পরিবহন:** বাহাদুর বাজার ও রেলওয়ে স্টেশন স্ট্যান্ডে মোঃ নুরুল ইসলামের সিএনজি (দিন ও রাত ২৪ ঘণ্টা) সচল রয়েছে।`;
      return {
        text: responseText,
        actions: [
          { target: 'marketplace', label: '🛒 দিনাজপুরের পণ্য হাটে দেখুন' },
          { target: 'transport', label: '🚗 দিনাজপুরের পরিবহন তালিকা' }
        ]
      };
    }

    if (q.includes('সাতক্ষীরা') || q.includes('কলারোয়া') || q.includes('কলারোয়া') || q.includes('শ্যামনগর') || (activeDistrict === 'সাতক্ষীরা' && (q.includes('ওলকচু') || q.includes('মধু') || q.includes('পণ্য')))) {
      let responseText = `**সাতক্ষীরা জেলার (কলারোয়া ও শ্যামনগর) লাইভ পণ্যের তথ্য:** 🌿\n\n`;
      responseText += `১. **কলারোয়ার মিষ্টি ওলকচু ও পেঁপে:** ৩৫ টাকা/কেজি (বিক্রেতা: শফিকুল ইসলাম, জয়নগর ইউনিয়ন, কলারোয়া)\n২. **সুন্দরবনের ১০০% খাঁটি প্রাকৃতিক মধু:** ৮৫০ টাকা/কেজি (মৌয়াল রবিউল ইসলাম, বুড়িগোয়ালিনী, শ্যামনগর)\n\n🚗 **কলারোয়া পরিবহন:** কলারোয়া বাসস্ট্যান্ড ও কলারোয়া মোড়ে মোঃ শরিফুল ইসলামের ইজিবাইক (দিন-রাত সচল) সেবা দিচ্ছে।`;
      return {
        text: responseText,
        actions: [
          { target: 'marketplace', label: '🛒 কলারোয়ার পণ্য পল্লী হাটে দেখুন' },
          { target: 'transport', label: '🚗 কলারোয়ার গাড়ি ও চালক দেখুন' }
        ]
      };
    }

    // 10. General Market / Haat / Commodity Inquiries (বাজার, দরদাম, সবজি, মাছ)
    const isMarket = /(বাজার|হাট|দরদাম|দাম|সবজি|শাকসবজি|পণ্য|আলু|পেঁয়াজ|পেঁয়াজ|রসুন|মরিচ|বেগুন|টমেটো|চাল|ডাল|মাছ|পণ্য)/i.test(q);
    if (isMarket) {
      const items = appContext.activeListings.filter(i => activeDistrict === 'সকল জেলা' || i.district === activeDistrict);
      let responseText = `🛒 **${activeDistrict} ও গ্রামীণ পল্লী হাটের পণ্যের দরদাম:**\n\n`;
      if (items.length > 0) {
        items.slice(0, 4).forEach((item, idx) => {
          responseText += `${idx + 1}. **${item.title}** — ৳${item.price} (${item.unit})\n   - স্থান: ${item.union || item.upazila}, ${item.district} | বিক্রেতা: ${item.seller}\n`;
        });
      } else {
        responseText += `• **নতুন আলু:** ২৫-৩০ টাকা/কেজি\n• **দেশি পেঁয়াজ:** ৫০-৫৫ টাকা/কেজি\n• **গোল বেগুন ও শসা:** ৪০-৪৫ টাকা/কেজি\n• **তাজা কাঁচামরিচ:** ৭০-৮০ টাকা/কেজি\n• **মিনিকেট/বিআর-২৮ চাল:** ৫৮-৬৫ টাকা/কেজি\n`;
      }
      responseText += `\n💡 কৃষকদের কাছ থেকে সরাসরি তাজা পণ্য কিনতে বা নিজের পণ্য হাটে তুলতে নিচে ক্লিক করুন।`;
      return {
        text: responseText,
        actions: [
          { target: 'marketplace', label: '🛒 পল্লী হাটের সরাসরি পণ্য দেখুন' }
        ]
      };
    }

    // 11. Transport & Driver Inquiries (গাড়ি, চালক, ড্রাইভার, ভ্যান, সিএনজি, পিকআপ)
    if (q.includes('গাড়ি') || q.includes('গাড়ি') || q.includes('চালক') || q.includes('ড্রাইভার') || q.includes('ভ্যান') || q.includes('সিএনজি') || q.includes('ইজিবাইক') || q.includes('পিকআপ') || q.includes('পরিবহন')) {
      const filteredDrivers = appContext.transportDrivers.filter(d => activeDistrict === 'সকল জেলা' || d.district === activeDistrict);
      let responseText = `🚗 **${activeDistrict} এলাকার নিবন্ধিত পরিবহন সেবা:**\n\n`;
      if (filteredDrivers.length > 0) {
        filteredDrivers.slice(0, 3).forEach((d, idx) => {
          responseText += `${idx + 1}. **${d.name}** (${d.vehicle})\n   - **স্ট্যান্ড:** ${d.stand}\n   - **রুট:** ${d.routes}\n   - **সময়সূচি:** ${d.shift}\n   - **রেটিং:** ⭐ ${d.rating || 5.0}\n\n`;
        });
      } else {
        responseText += `• **সাভার (ঢাকা):** মোঃ রফিকুল ইসলাম (ইজিবাইক - দিন ও রাত ২৪ ঘণ্টা)\n• **বগুড়া চারমাথা:** আব্দুল কাদের (সিএনজি - দিন ও রাত)\n• **বাউফল (পটুয়াখালী):** মোঃ কালাম হাওলাদার (ইজিবাইক) ও মোঃ শাহিন মিয়া (পিকআপ)\n• **কলারোয়া (সাতক্ষীরা):** মোঃ শরিফুল ইসলাম (ইজিবাইক)\n\n`;
      }
      responseText += `🔒 **নিরাপত্তা নির্দেশিকা:** চালকের সাথে অ্যাপের নিরাপদ কলিং ও ইন-অ্যাপ ট্রিপ ট্র্যাকিংয়ের মাধ্যমে ভ্রমণ করুন।`;
      return {
        text: responseText,
        actions: [{ target: 'transport', label: '🚗 পরিবহন তালিকা ও চালক বুকিং' }]
      };
    }

    // 12. Land, E-Mutation & Property (নামজারি, খারিজ, পর্চা, খতিয়ান, জমি)
    if (q.includes('নামজারি') || q.includes('খারিজ') || q.includes('জমিজমা') || q.includes('পর্চা') || q.includes('খতিয়ান') || q.includes('খতিয়ান') || q.includes('দলিল')) {
      return {
        text: `🏛️ **অনলাইন ই-নামজারি (E-Mutation) আবেদন ও সঠিক নিয়মাবলী:**\n\n` +
          `• **আবেদনের ওয়েবসাইট:** [mutation.land.gov.bd](https://mutation.land.gov.bd)\n` +
          `• **সরকারি মোট ফি:** সর্বমোট **১,১৭০ টাকা** (আবেদন কোর্ট ফি ২০ + নোটিশ জারি ৫০ + রেকর্ড সংশোধন ফি ১০০ + ডিসিআর ১,০০০ টাকা)।\n` +
          `• **প্রয়োজনীয় কাগজপত্র:** মূল দলিলের কপি, পূর্ববর্তী খতিয়ান/পর্চা, হালনাগাদ ভূমি উন্নয়ন কর (খাজনা) দাখিলা ও আবেদনকারীর এনআইডি।\n` +
          `• **সময়সীমা:** সরকারি বিধিমতে ২৮ কার্যদিবসের মধ্যে নামজারি সম্পন্ন ও ডিসিআর কিউআর কোডসহ অনলাইনে পাওয়া যায়।\n\n` +
          `🚫 **দালাল প্রতিরোধ সতর্কতা:** নামজারির জন্য কাউকে অতিরিক্ত নগদ টাকা দেবেন না; সকল ফি সরাসরি মোবাইল ব্যাংকিংয়ে সরকারি চালানে জমা হয়। যেকোনো তথ্যে ভূমি হেল্পলাইন **১৬১২২**-এ কল করুন।`,
        actions: [{ target: 'service-finder', label: '🏛️ জমিজমা ও নামজারি ডেস্ক' }]
      };
    }

    // 13. Social Safety Net Allowances (ভাতা, বয়স্ক, বিধবা, প্রতিবন্ধী)
    if (q.includes('ভাতা') || q.includes('বয়স্ক') || q.includes('বিধবা') || q.includes('প্রতিবন্ধী')) {
      return {
        text: `👴👵 **সরকারি সামাজিক নিরাপত্তা ভাতা (বয়স্ক, বিধবা ও প্রতিবন্ধী) নির্দেশিকা:**\n\n` +
          `• **যোগ্যতার বয়স:** বয়স্ক ভাতার ক্ষেত্রে পুরুষের বয়স ন্যূনতম ৬৫ বছর এবং নারীর বয়স ন্যূনতম ৬২ বছর।\n` +
          `• **আবেদনের স্থান:** ইউনিয়ন ডিজিটাল সেন্টার (UDC) বা mis.bhata.gov.bd অনলাইন পোর্টাল।\n` +
          `• **প্রয়োজনীয় কাগজপত্র:** স্মার্ট এনআইডি কার্ড, সচল মোবাইল ব্যাংকিং (বিকাশ/নগদ) নিবন্ধিত সিম ও ছবি। প্রতিবন্ধী ভাতার ক্ষেত্রে সমাজসেবা অধিদপ্তরের সুবর্ণ নাগরিক কার্ড বাধ্যতামূলক।\n` +
          `• **সরকারি ফি:** **সম্পূর্ণ বিনামূল্যে** (আবেদনে কোনো টাকা লাগে না)।\n` +
          `• **ভাতা প্রদান:** জিটুপি (G2P) পদ্ধতিতে সরাসরি উপকারভোগীর নিজস্ব মোবাইল ব্যাংকিং অ্যাকাউন্টে টাকা চলে যায়।\n\n` +
          `🚫 **সতর্কতা:** ভাতা পাওয়ার জন্য কোনো মধ্যস্বত্বভোগী বা দালালকে অর্থ দেবেন না। যেকোনো অনিয়মে উপজেলা নির্বাহী অফিসার (UNO) বা ৩৩৩ নম্বরে অভিযোগ করুন।`,
        actions: [{ target: 'government', label: '🏛️ সামাজিক ভাতা ও আবেদন ফরম' }]
      };
    }

    // 14. Electricity Bill & Meter Inquiries (বিদ্যুৎ, মিটার, বিল, লোডশেডিং)
    if (q.includes('বিদ্যুৎ') || q.includes('মিটার') || q.includes('বিল') || q.includes('ভুতুড়ে') || q.includes('লোডশেডিং')) {
      return {
        text: `⚡ **পল্লী বিদ্যুৎ মিটারে অতিরিক্ত বা ভুতুড়ে বিলের তাৎক্ষণিক সমাধান:**\n\n` +
          `১. **মিটার রিডিং যাচাই:** আপনার মিটারের বর্তমান রিডিং ও বিদ্যুৎ বিলের কাগজের 'বর্তমান রিডিং' মিলিয়ে দেখুন। ভুল রিডিং এন্ট্রি হলে বিল বেশি আসতে পারে।\n` +
          `২. **সংশোধন পদ্ধতি:** বিলের মূল কপিসহ স্থানীয় পল্লী বিদ্যুৎ সমিতি (PBS) অথবা সাব-জোনাল অফিসের 'বিলিং শাখায়' আবেদন করুন। তাৎক্ষণিক যাচাই করে বিল সংশোধন করে দেওয়া হয়।\n` +
          `৩. **জরুরি হেল্পলাইন:** কেন্দ্রীয় বিদ্যুৎ অভিযোগ সেল **১৬৯৯৯** অথবা জাতীয় তথ্য সেবা **৩৩৩**-এ সরাসরি কল করতে পারেন।\n\n` +
          `💡 **সাশ্রয়ী পরামর্শ:** পিক-আওয়ারে (সন্ধ্যা ৬টা - রাত ১১টা) ভারী সেচ পাম্প বা ওয়াটার হিটার চালানো পরিহার করুন।`,
        actions: [{ target: 'electricity', label: '⚡ বিদ্যুৎ বিল হিসাব ও অভিযোগ' }]
      };
    }

    // 15. Contextual Fallback for Specific or Complex Queries (Empathetic & Guiding)
    return {
      text: `🌾 **পল্লী সেবা ডিজিটাল সহায়তা (${activeDistrict}):**\n\n` +
        `আপনি জানতে চেয়েছেন: "*${rawQ}*"\n\n` +
        `আপনার প্রশ্নের আলোকে পল্লী সেবা প্ল্যাটফর্মের উপযুক্ত তথ্য ও সেবাসমূহ নিচে দেওয়া হলো:\n\n` +
        `• **🛒 পল্লী হাট ও কৃষি বিপণন:** আপনার এলাকার কৃষকদের উৎপাদিত তাজা শস্য, শাকসবজি ও খামারের লাইভ পণ্য সরাসরি দালালমুক্ত মূল্যে বেচাকেনা করুন।\n` +
        `• **🚗 নিরাপদ গ্রামীণ পরিবহন:** স্থানীয় ভ্যান, সিএনজি, ইজিবাইক বা পিকআপ চালকদের স্ট্যান্ড, রুট ও সময়সূচি দেখে নিরাপদে যাতায়াত করুন।\n` +
        `• **🩸 স্বাস্থ্য ও রক্তদাতা সহায়িকা:** জরুরি রক্তের প্রয়োজনে স্থানীয় ভেরিফাইড রক্তদাতাদের সাথে যোগাযোগ করুন।\n` +
        `• **🏛️ সরকারি জরুরি হটলাইনসমূহ:**\n` +
        `  - জরুরি পুলিশ/অ্যাম্বুলেন্স: **৯৯৯**\n` +
        `  - সরকারি সেবা ও তথ্য: **৩৩৩**\n` +
        `  - স্বাস্থ্য বাতায়ন: **১৬২৬৩**\n` +
        `  - কৃষি কল সেন্টার: **১৬১২৩**\n` +
        `  - ভূমি সেবা: **১৬১২২**\n` +
        `  - পল্লী বিদ্যুৎ অভিযোগ: **১৬৯৯৯**\n\n` +
        `🛡️ **পরামর্শ:** কোনো নির্দিষ্ট সেবা বা পণ্যের বিস্তারিত জানতে বিষয়টির নাম লিখে সরাসরি প্রশ্ন করতে পারেন।`,
      actions: [
        { target: 'marketplace', label: '🛒 পল্লী হাট দেখুন' },
        { target: 'health', label: '🩸 জরুরি রক্ত ও স্বাস্থ্য' },
        { target: 'transport', label: '🚗 পরিবহন তালিকা' }
      ]
    };
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputPrompt;
    if (!text.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: 'এইমাত্র'
    };

    lastUserMessageIdRef.current = userMessage.id;
    setMessages((prev) => [...prev, userMessage]);
    setInputPrompt('');
    setIsLoading(true);

    const appContext = gatherAppContext();
    let replyText: string | null = null;
    let replyActions: Array<{ target: ServiceCategory; label: string; subTab?: string }> = [];
    let incomingComplaintData: any = null;
    let providerCards: AIProviderCard[] | undefined = undefined;
    let isFallbackSearch = false;

    // Step 0: Smart Search for Natural Language Location & Service / Product Queries
    const smartSearch = executeSmartSearch(text.trim(), activeDistrict, activeUpazila, {
      drivers: liveDrivers,
      returnRides: liveReturnRides,
      haatItems: liveHaatItems,
      bloodDonors: liveDonors,
      housingListings: liveHousingListings,
      registeredUsers: liveRegisteredUsers
    });

    if (smartSearch.isSearchQuery) {
      replyText = smartSearch.introMessage;
      replyActions = smartSearch.actions;
      providerCards = smartSearch.cards;
      isFallbackSearch = smartSearch.isFallback;

      // Dynamically update activeDistrict & activeUpazila to match user's explicit request
      if (smartSearch.parsed.extractedDistrict && smartSearch.parsed.extractedDistrict !== activeDistrict) {
        setActiveDistrict(smartSearch.parsed.extractedDistrict);
      }
      if (smartSearch.parsed.extractedUpazila && smartSearch.parsed.extractedUpazila !== activeUpazila) {
        setActiveUpazila(smartSearch.parsed.extractedUpazila);
      }
    } else {
      // Step 1: Call Server API route (/api/gemini/advisor)
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000);

        let res = await fetch('/api/gemini/advisor', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            message: text.trim(),
            category: selectedCategory === 'all' ? 'সর্বজনীন পল্লী সেবা' : selectedCategory,
            context: appContext,
            conversationHistory: messages.slice(-4).map(m => ({ sender: m.sender, text: m.text }))
          })
        });
        clearTimeout(timeoutId);

        // Fallback to direct Netlify function if /api/ returned non-200
        if (!res.ok) {
          try {
            const netlifyController = new AbortController();
            const netlifyTimeout = setTimeout(() => netlifyController.abort(), 12000);
            const netlifyRes = await fetch('/.netlify/functions/advisor', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              signal: netlifyController.signal,
              body: JSON.stringify({
                message: text.trim(),
                category: selectedCategory === 'all' ? 'সর্বজনীন পল্লী সেবা' : selectedCategory,
                context: appContext,
                conversationHistory: messages.slice(-4).map(m => ({ sender: m.sender, text: m.text }))
              })
            });
            clearTimeout(netlifyTimeout);
            if (netlifyRes.ok) {
              res = netlifyRes;
            }
          } catch (e) {
            // continue
          }
        }

        incomingComplaintData = null;

        const rawText = await res.text();
        if (rawText && !rawText.trim().startsWith('<') && !rawText.trim().startsWith('<!DOCTYPE')) {
          try {
            const data = JSON.parse(rawText);
            if (data && data.reply) {
              const parsed = parseBotReply(data.reply);
              replyText = parsed.cleanText;
              replyActions = parsed.actions;
              if (data.complaintData) {
                incomingComplaintData = data.complaintData;
              }
            }
          } catch (jsonErr) {
            console.warn('JSON parse error from advisor:', jsonErr);
          }
        }
      } catch (fetchErr) {
        console.warn('Backend /api/gemini/advisor call note:', fetchErr);
      }

      // Step 2: Instant Local Knowledge Responder if API is offline or busy
      if (!replyText) {
        const fallback = generateLocalKnowledgeReply(text.trim());
        replyText = fallback.text;
        replyActions = fallback.actions;
      }
    }

    // Step 3: Complaint & Grievance Detection & Cloud Submission
    let complaintBadge: any = null;
    let complaintData = incomingComplaintData;
    if (!complaintData) {
      const isComplaintText = /(অভিযোগ|নালিশ|প্রতারণা|দালাল|অতিরিক্ত ভাড়া|বেশি দাম|নকল পণ্য|বাজে ব্যবহার|নষ্ট|খারাপ আচরণ|সমস্যা হচ্ছে|কাজ করেনি|ঠকিয়েছে|জাল|ঘুষ|অনিয়ম)/i.test(text.trim());
      if (isComplaintText) {
        let detType: any = 'সাধারণ';
        if (text.includes('ভাড়া') || text.includes('গাড়ি') || text.includes('চালক')) detType = 'পরিবহন ও চালক';
        else if (text.includes('দাম') || text.includes('পণ্য') || text.includes('বাজার') || text.includes('সার')) detType = 'পণ্য ও বাজার';
        else if (text.includes('বিদ্যুৎ') || text.includes('বিল')) detType = 'বিদ্যুৎ ও সেবা';
        else if (text.includes('দালাল') || text.includes('প্রতারণা') || text.includes('ঘুষ')) detType = 'দালাল বা প্রতারণা';
        else if (text.includes('রক্ত') || text.includes('ডাক্তার') || text.includes('হাসপাতাল')) detType = 'স্বাস্থ্য ও রক্ত';

        complaintData = {
          detected: true,
          type: detType,
          severity: text.includes('দালাল') || text.includes('প্রতারণা') || text.includes('জরুরি') ? 'জরুরি' : 'সাধারণ',
          summary: text.trim().slice(0, 120)
        };
      }
    }

    if (complaintData && complaintData.detected) {
      const trackingId = `COMP-${Date.now().toString().slice(-6)}`;
      const complaintRecord: AIComplaintRecord = {
        id: `comp-${Date.now()}`,
        trackingId,
        userId: currentUser?.id,
        userName: currentUser?.name || 'সম্মানিত নাগরিক',
        userPhone: currentUser?.phone || '০১৭xxxxxxxx',
        userDistrict: activeDistrict,
        userUpazila: activeUpazila,
        rawUserQuery: text.trim(),
        detectedComplaintType: complaintData.type || 'সাধারণ',
        severity: complaintData.severity || 'জরুরি',
        aiSummary: complaintData.summary || text.trim().slice(0, 120),
        createdAt: Date.now(),
        formattedDate: new Date().toLocaleDateString('bn-BD'),
        formattedTime: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
        status: 'নতুন'
      };

      complaintBadge = {
        trackingId,
        type: complaintRecord.detectedComplaintType,
        severity: complaintRecord.severity,
        summary: complaintRecord.aiSummary
      };

      // 1. Save Complaint into Firestore Cloud Database
      saveCloudAIComplaint(complaintRecord).catch(e => console.warn('Cloud complaint save note:', e));

      // 2. Dispatch real-time Admin Demand Notification
      saveDemandNotification({
        id: `notif-${complaintRecord.id}`,
        title: `🚨 নতুন অভিযোগ: ${complaintRecord.detectedComplaintType} (${trackingId})`,
        message: `${complaintRecord.userName} (${activeDistrict}, ${activeUpazila}): ${complaintRecord.aiSummary}`,
        urgency: 'জরুরি',
        targetDistrict: 'সকল জেলা',
        targetUpazila: 'সকল উপজেলা',
        targetRole: 'admin',
        categoryName: 'নাগরিক অভিযোগ',
        senderName: complaintRecord.userName,
        contactNumber: complaintRecord.userPhone,
        actionUrl: `complaints:${complaintRecord.id}`,
        itemId: complaintRecord.id,
        targetCategory: 'admin',
        createdAt: Date.now(),
        expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
        createdAtFormatted: 'এইমাত্র'
      }).catch(() => {});

      // 3. System-wide notification sound & alert
      sendSystemNotification({
        title: `🚨 অভিযোগ ফায়ারবেসে জমা হয়েছে (${trackingId})`,
        body: `আপনার উত্থাপিত সমস্যাটি প্ল্যাটফর্ম অ্যাডমিন প্যানেলে পাঠানো হয়েছে।`,
        sound: true,
        targetCategory: 'ai-advisor'
      });
    }

    const botReply: ChatMessage = {
      id: `bot-${Date.now()}`,
      sender: 'bot',
      text: replyText || 'সম্মানিত নাগরিক, কীভাবে আপনাকে সহায়তা করতে পারি?',
      timestamp: 'এইমাত্র',
      actions: replyActions,
      providerCards: providerCards,
      isFallback: isFallbackSearch,
      complaintBadge: complaintBadge || undefined
    };

    setMessages((prev) => [...prev, botReply]);
    setIsLoading(false);
  };

  // Cleanup speech recognition on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {}
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        try {
          mediaRecorderRef.current.stop();
        } catch {}
      }
    };
  }, []);

  // Voice-to-Text Speech Recognition (Web Speech API with Gemini Fallback)
  const handleToggleVoiceRecognition = async () => {
    if (isListening) {
      // Stop listening
      setIsListening(false);
      setVoiceStatusText(null);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        try {
          mediaRecorderRef.current.stop();
        } catch {}
      }
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognitionRef.current = recognition;
        recognition.lang = 'bn-BD';
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.maxAlternatives = 1;

        setIsListening(true);
        setVoiceStatusText('🎙️ আপনার কথা শুনছি... বাংলায় বলুন (যেমন: "আমার এলাকায় সিএনজি চালক খুঁজছি")');

        recognition.onstart = () => {
          setIsListening(true);
        };

        recognition.onresult = (event: any) => {
          const results = event.results;
          if (results && results.length > 0) {
            const transcript = results[0][0].transcript;
            setInputPrompt(transcript);
            setVoiceStatusText(`🗣️ "${transcript}"`);
            
            // If final, auto-send after a brief pause
            if (results[0].isFinal) {
              setIsListening(false);
              setVoiceStatusText(null);
              if (transcript.trim()) {
                setTimeout(() => {
                  handleSendMessage(transcript.trim());
                }, 400);
              }
            }
          }
        };

        recognition.onerror = (event: any) => {
          console.warn('SpeechRecognition error:', event?.error);
          setIsListening(false);
          if (event.error === 'not-allowed') {
            setVoiceStatusText('⚠️ মাইক্রোফোন ব্যবহারের অনুমতি দিন');
          } else {
            setVoiceStatusText('⚠️ কথা স্পষ্টভাবে বোঝা যায়নি, পুনরায় চেষ্টা করুন');
          }
          setTimeout(() => setVoiceStatusText(null), 3500);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognition.start();
        return;
      } catch (err) {
        console.warn('SpeechRecognition start failed, trying MediaRecorder fallback:', err);
      }
    }

    // Fallback: MediaRecorder + Server /api/gemini/voice-to-text
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert('আপনার ব্রাউজারে মাইক্রোফোন সাপোর্ট নেই। দয়া করে ক্রোম বা এজ ব্রাউজার ব্যবহার করুন।');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4'
      });
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        stream.getTracks().forEach(track => track.stop());
        const audioBlob = new Blob(audioChunksRef.current, { type: mediaRecorder.mimeType || 'audio/webm' });

        if (audioBlob.size < 500) {
          setIsListening(false);
          setVoiceStatusText(null);
          return;
        }

        setVoiceStatusText('⚡ ভয়েস প্রসেসিং হচ্ছে...');

        // Convert Blob to Base64
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Audio = reader.result as string;
          try {
            const res = await fetch('/api/gemini/voice-to-text', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                audioBase64: base64Audio,
                mimeType: mediaRecorder.mimeType || 'audio/webm'
              })
            });

            if (res.ok) {
              const data = await res.json();
              if (data.transcript && data.transcript.trim()) {
                setInputPrompt(data.transcript.trim());
                setVoiceStatusText(null);
                setTimeout(() => {
                  handleSendMessage(data.transcript.trim());
                }, 300);
                return;
              }
            }
          } catch (e) {
            console.warn('Voice-to-text API fallback error:', e);
          }

          setIsListening(false);
          setVoiceStatusText('⚠️ ভয়েস স্পষ্ট শোনা যায়নি, পুনরায় বলুন');
          setTimeout(() => setVoiceStatusText(null), 3000);
        };
      };

      mediaRecorder.start();
      setIsListening(true);
      setVoiceStatusText('🎙️ রেকর্ডিং চলছে... কথা বলা শেষ হলে লাল বাটনে চাপুন (যেমন: "আমার এলাকায় সিএনজি চালক খুঁজছি")');

      // Auto stop after 7 seconds max
      setTimeout(() => {
        if (mediaRecorder.state === 'recording') {
          mediaRecorder.stop();
          setIsListening(false);
        }
      }, 7000);

    } catch (micErr) {
      console.warn('Microphone access denied:', micErr);
      setIsListening(false);
      setVoiceStatusText('⚠️ মাইক্রোফোন পারমিশন প্রয়োজন');
      setTimeout(() => setVoiceStatusText(null), 3000);
    }
  };

  const handleSpeech = (text: string) => {
    if (!('speechSynthesis' in window)) {
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#_`]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'bn-BD';
    utterance.rate = 0.95;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const categoryTabs: Array<{ id: AdvisorCategory; label: string; icon: any }> = [
    { id: 'all', label: '🌟 সকল সেবা ও গাইড', icon: Sparkles },
    { id: 'marketplace', label: '🛒 হাটবাজার ও শাকসবজি', icon: ShoppingBag },
    { id: 'transport', label: '🚗 পরিবহন ও গাড়ি', icon: Car },
    { id: 'government', label: '🏛️ সরকারি সেবা ও ভাতা', icon: Landmark },
    { id: 'health', label: '🏥 স্বাস্থ্য ও রক্তদাতা', icon: Heart },
    { id: 'electricity', label: '⚡ পল্লী বিদ্যুৎ', icon: Zap },
    { id: 'agriculture', label: '🌾 কৃষি ও ফসল', icon: Sprout },
    { id: 'livestock', label: '🐄 পশুপালন ও মৎস্য', icon: ShieldCheck },
    { id: 'calculators', label: '📐 জমি ও ঋণ ক্যালকুলেটর', icon: Scale },
  ];

  return (
    <div className="space-y-3 max-w-4xl mx-auto pb-3">
      {/* Top Header - Compact, Professional & Non-Intrusive */}
      <div className="bg-[#2D5A27] text-white px-4 py-2.5 rounded-2xl shadow-xs">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-bold shadow-xs flex-shrink-0">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm sm:text-base font-bold font-['Noto_Sans_Bengali'] leading-tight">
                  পল্লী সেবা এআই সহকারী
                </h2>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse inline-block" title="অনলাইন" />
              </div>
              <p className="text-[#D4E4BC] text-[11px] hidden sm:block">
                বাজারদর, পরিবহন, স্বাস্থ্য, সরকারি ভাতা ও কৃষিসংক্রান্ত ডিজিটাল গাইড
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 flex-shrink-0">
            {/* New Chat Reset Button */}
            {messages.length > 1 && (
              <button
                onClick={handleClearChat}
                className="flex items-center gap-1 bg-[#23491E] border border-[#3D7A35] hover:border-[#D4E4BC] px-2.5 py-1.5 rounded-xl text-[#D4E4BC] text-xs font-semibold transition cursor-pointer"
                title="নতুন আলোচনা শুরু করুন"
              >
                <RefreshCw className="w-3.5 h-3.5 text-[#D4E4BC]" />
                <span className="hidden sm:inline">নতুন চ্যাট</span>
              </button>
            )}

            {/* Suggested Prompts Toggle */}
            <button
              onClick={() => setShowQuickPrompts(!showQuickPrompts)}
              className="flex items-center gap-1 bg-[#23491E] border border-[#3D7A35] hover:border-[#D4E4BC] px-2.5 py-1.5 rounded-xl text-[#D4E4BC] text-xs font-semibold transition cursor-pointer"
              title="নমুনা প্রশ্ন দেখুন"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#E8924A]" />
              <span className="hidden sm:inline">নমুনা প্রশ্ন</span>
            </button>

            {/* District & Location Badge with Quick Switch */}
            <button
              onClick={() => setShowLocationPicker(!showLocationPicker)}
              className="flex items-center gap-1 bg-[#23491E] border border-[#3D7A35] hover:border-[#D4E4BC] px-2.5 py-1.5 rounded-xl text-[#D4E4BC] text-xs font-semibold transition cursor-pointer shadow-xs"
              title="এলাকা পরিবর্তন করুন"
            >
              <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
              <span>{activeDistrict}</span>
              <span className="text-[10px] bg-[#2D5A27] px-1 py-0.5 rounded text-white underline">
                বদল
              </span>
            </button>
          </div>
        </div>

        {/* Location Dropdown Accordion if opened */}
        {showLocationPicker && (
          <div className="bg-[#23491E] border border-[#3D7A35] p-3 rounded-xl text-xs space-y-2 mt-2.5">
            <div className="font-bold text-white flex items-center justify-between">
              <span>আপনার জেলা ও উপজেলা নির্বাচন করুন:</span>
              <button 
                onClick={() => setShowLocationPicker(false)}
                className="text-[#D4E4BC] hover:text-white underline cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="block text-[#D4E4BC] mb-1 font-medium text-[11px]">জেলা:</label>
                <select
                  value={activeDistrict}
                  onChange={(e) => {
                    const dist = e.target.value;
                    setActiveDistrict(dist);
                    const upz = getUpazilasForDistrict(dist);
                    if (upz && upz.length > 0) setActiveUpazila(upz[0]);
                  }}
                  className="w-full bg-[#2D5A27] border border-[#3D7A35] rounded-xl px-3 py-1.5 text-white font-medium focus:outline-none"
                >
                  <option value="পটুয়াখালী">পটুয়াখালী</option>
                  <option value="দিনাজপুর">দিনাজপুর</option>
                  <option value="সাতক্ষীরা">সাতক্ষীরা</option>
                  <option value="বগুড়া">বগুড়া</option>
                  <option value="ঢাকা">ঢাকা</option>
                  <option value="যশোর">যশোর</option>
                  <option value="মানিকগঞ্জ">মানিকগঞ্জ</option>
                  <option value="সিরাজগঞ্জ">সিরাজগঞ্জ</option>
                  {BANGLADESH_DISTRICTS.filter(d => !['পটুয়াখালী', 'দিনাজপুর', 'সাতক্ষীরা', 'বগুড়া', 'ঢাকা', 'যশোর', 'মানিকগঞ্জ', 'সিরাজগঞ্জ'].includes(d)).map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[#D4E4BC] mb-1 font-medium text-[11px]">উপজেলা / থানা:</label>
                <select
                  value={activeUpazila}
                  onChange={(e) => setActiveUpazila(e.target.value)}
                  className="w-full bg-[#2D5A27] border border-[#3D7A35] rounded-xl px-3 py-1.5 text-white font-medium focus:outline-none"
                >
                  {availableUpazilas.length > 0 ? (
                    availableUpazilas.map(u => (
                      <option key={u} value={u}>{u}</option>
                    ))
                  ) : (
                    <option value="সদর">সদর</option>
                  )}
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Quick Question Chips if opened */}
        {showQuickPrompts && (
          <div className="bg-[#23491E] border border-[#3D7A35] p-2.5 rounded-xl text-xs space-y-1.5 mt-2.5">
            <div className="flex items-center justify-between text-[#D4E4BC] text-[11px] font-semibold">
              <span>যেকোনো প্রশ্নে সরাসরি ট্যাপ করুন:</span>
              <button onClick={() => setShowQuickPrompts(false)} className="hover:text-white underline">বন্ধ</button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {presetQuestions.slice(0, 4).map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setShowQuickPrompts(false);
                    handleSendMessage(q.query);
                  }}
                  disabled={isLoading}
                  className="bg-[#2D5A27] hover:bg-[#3D7A35] border border-[#4E9A44] text-white text-[11px] font-medium px-2.5 py-1 rounded-lg transition text-left cursor-pointer"
                >
                  {q.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Chat Messages History */}
      <div 
        ref={chatContainerRef}
        className="relative bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl p-3 sm:p-4 shadow-xs min-h-[360px] max-h-[560px] overflow-y-auto space-y-3.5"
      >
        {messages.map((msg) => {
          const isBot = msg.sender === 'bot';
          const isTargetQuestion = msg.id === lastUserMessageIdRef.current;
          return (
            <div
              key={msg.id}
              data-msg-id={msg.id}
              ref={isTargetQuestion ? lastQuestionRef : null}
              className={`flex gap-3 ${isBot ? 'justify-start' : 'justify-end'}`}
            >
              {isBot && (
                <div className="w-9 h-9 rounded-full bg-white border border-[#E6E0D4] flex items-center justify-center flex-shrink-0 mt-1 shadow-xs overflow-hidden p-0.5">
                  <img src="/logo.png" alt="পল্লী সেবা এআই" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                </div>
              )}

              <div
                className={`max-w-[90%] sm:max-w-[85%] rounded-3xl p-4 sm:p-5 text-xs sm:text-sm leading-relaxed shadow-xs ${
                  isBot
                    ? 'bg-white border border-[#E6E0D4] text-[#2D3A3A]'
                    : 'bg-[#2D5A27] text-white font-medium'
                }`}
              >
                {/* Bot Message Content with formatted bullet styling */}
                <div className="whitespace-pre-wrap font-['Noto_Sans_Bengali'] space-y-2">
                  {msg.text}
                </div>

                {/* AI-Identified Grievance / Complaint Receipt Banner */}
                {isBot && msg.complaintBadge && (
                  <div className="mt-3 bg-amber-50 border-2 border-amber-300 rounded-2xl p-3 sm:p-3.5 space-y-1.5 text-amber-950 shadow-xs">
                    <div className="flex items-center justify-between font-bold">
                      <span className="flex items-center gap-1.5 text-amber-900 text-xs">
                        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>অভিযোগ ও মতামত ফায়ারবেসে নথিভুক্ত</span>
                      </span>
                      <span className="bg-amber-200 text-amber-900 text-[10px] px-2 py-0.5 rounded-full font-mono font-bold">
                        {msg.complaintBadge.trackingId}
                      </span>
                    </div>
                    <p className="text-[11px] text-amber-800 leading-tight">
                      বিভাগ: <strong>{msg.complaintBadge.type}</strong> • তীব্রতা: <strong>{msg.complaintBadge.severity}</strong> • অবস্থা: <strong>অ্যাডমিন নোটিফিকেশন প্রেরিত</strong>
                    </p>
                    <p className="text-[10px] text-amber-700/90 pt-0.5 border-t border-amber-200 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-600 inline" />
                      <span>অ্যাপস অ্যাডমিন পর্যালোচনার জন্য সংরক্ষণ করা হয়েছে।</span>
                    </p>
                  </div>
                )}

                {/* Smart Search Dynamic Provider Cards (100% Privacy & Security Preserved) */}
                {isBot && msg.providerCards && msg.providerCards.length > 0 && (
                  <div className="mt-3.5 space-y-2.5">
                    {/* Privacy & Security Banner */}
                    <div className="bg-emerald-50 border border-emerald-200 rounded-2xl px-3 py-2 text-[11px] text-emerald-900 flex items-center justify-between">
                      <div className="flex items-center gap-1.5 font-semibold">
                        <Lock className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                        <span>১০০% নিরাপদ যোগাযোগ • ফোন নম্বর সম্পূর্ণ অপ্রকাশ্য ও সুরক্ষিত</span>
                      </div>
                      <span className="text-[10px] bg-emerald-200/80 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                        {msg.providerCards.length} জন সেবাদাতা
                      </span>
                    </div>

                    {/* Cards List */}
                    <div className="grid grid-cols-1 gap-2.5">
                      {msg.providerCards.map((card) => (
                        <div
                          key={card.id}
                          className="bg-[#FAF8F5] border border-[#E6E0D4] hover:border-emerald-500/50 rounded-2xl p-3 sm:p-3.5 space-y-2.5 transition shadow-2xs text-[#2D3A3A]"
                        >
                          {/* Card Header: Avatar, Name, Role, Area */}
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-start gap-2.5">
                              <div className="w-10 h-10 rounded-2xl bg-white border border-[#E6E0D4] flex items-center justify-center font-bold text-sm text-[#2D5A27] shrink-0 overflow-hidden shadow-2xs">
                                {card.avatar ? (
                                  <img src={card.avatar} alt={card.name} className="w-full h-full object-cover" />
                                ) : (
                                  <span>{card.name.charAt(0)}</span>
                                )}
                              </div>
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">{card.name}</h5>
                                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                </div>
                                <div className="flex flex-wrap items-center gap-1.5 mt-0.5 text-[11px]">
                                  <span className="font-bold text-emerald-800 bg-emerald-100/70 px-2 py-0.5 rounded-md">
                                    {card.roleLabel}
                                  </span>
                                  <span className="text-[#5A6B6B] flex items-center gap-0.5">
                                    <MapPin className="w-3 h-3 text-[#2D5A27]" />
                                    <span>{card.unionOrArea ? `${card.unionOrArea}, ` : ''}{card.upazila}</span>
                                  </span>
                                </div>
                              </div>
                            </div>

                            {card.availabilityBadge && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white border border-emerald-200 text-emerald-800 shadow-2xs shrink-0">
                                {card.availabilityBadge}
                              </span>
                            )}
                          </div>

                          {/* Card Middle: Highlight Detail */}
                          <div className="bg-white/80 rounded-xl px-2.5 py-1.5 border border-[#E6E0D4] text-[11px] text-[#5A6B6B]">
                            {card.highlightDetail}
                          </div>

                          {/* Card Bottom: In-App Direct Action Buttons (Zero Phone Number Exposure) */}
                          <div className="pt-1 flex items-center gap-2">
                            {/* 1. In-App Call Button */}
                            <button
                              type="button"
                              onClick={() => {
                                if (!currentUser && onOpenAuth) {
                                  onOpenAuth('কল করার জন্য লগইন করুন');
                                  return;
                                }
                                if (onStartInAppCall) {
                                  onStartInAppCall({
                                    id: card.uid,
                                    name: card.name,
                                    phone: card.privatePhoneRef,
                                    role: card.roleLabel,
                                    avatar: card.avatar,
                                    vehicle: card.roleLabel
                                  });
                                } else if (onNavigateCategory) {
                                  onNavigateCategory(card.actionCategory, card.subTab);
                                }
                              }}
                              className="flex-1 py-1.5 px-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
                              title="ফোন নম্বর গোপন রেখে ইন-অ্যাপ কল করুন"
                            >
                              <PhoneCall className="w-3.5 h-3.5" />
                              <span>ইন-অ্যাপ কল</span>
                            </button>

                            {/* 2. In-App Chat Button */}
                            <button
                              type="button"
                              onClick={() => {
                                if (!currentUser && onOpenAuth) {
                                  onOpenAuth('মেসেজ পাঠানোর জন্য লগইন করুন');
                                  return;
                                }
                                if (onStartChat) {
                                  onStartChat({
                                    id: card.uid,
                                    name: card.name,
                                    phone: card.privatePhoneRef,
                                    role: card.roleLabel,
                                    avatar: card.avatar,
                                    itemTitle: card.roleLabel
                                  });
                                } else if (onNavigateCategory) {
                                  onNavigateCategory(card.actionCategory, card.subTab);
                                }
                              }}
                              className="flex-1 py-1.5 px-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
                              title="সুরক্ষিত ইন-অ্যাপ মেসেজ পাঠান"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              <span>চ্যাট</span>
                            </button>

                            {/* 3. View Profile Button */}
                            {onViewProfile && card.originalItem && (
                              <button
                                type="button"
                                onClick={() => {
                                  onViewProfile({
                                    id: card.uid,
                                    name: card.name,
                                    role: card.roleLabel,
                                    phone: card.privatePhoneRef,
                                    customAvatarUrl: card.avatar,
                                    district: card.district,
                                    upazila: card.upazila,
                                    union: card.unionOrArea
                                  });
                                }}
                                className="py-1.5 px-2.5 bg-white hover:bg-gray-100 text-[#2D3A3A] border border-[#E6E0D4] rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1 shadow-2xs"
                                title="প্রোফাইল দেখুন"
                              >
                                <Eye className="w-3.5 h-3.5 text-[#5A6B6B]" />
                                <span className="hidden sm:inline">প্রোফাইল</span>
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Interactive Action Deep-Link Buttons - Displayed in pairs of two */}
                {isBot && msg.actions && msg.actions.length > 0 && (
                  <div className={`mt-3 pt-2.5 border-t border-[#E6E0D4]/80 ${
                    msg.actions.length >= 2 ? 'grid grid-cols-2 gap-2' : 'flex flex-wrap gap-2'
                  }`}>
                    {msg.actions.map((act, actIdx) => (
                      <button
                        key={actIdx}
                        onClick={() => {
                          if (onNavigateCategory) {
                            onNavigateCategory(act.target, act.subTab);
                          }
                        }}
                        className="bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold px-3 py-2 rounded-xl flex items-center justify-between shadow-xs transition cursor-pointer"
                      >
                        <span className="truncate">{act.label}</span>
                        <ExternalLink className="w-3.5 h-3.5 text-[#D4E4BC] flex-shrink-0 ml-1" />
                      </button>
                    ))}
                  </div>
                )}

                {/* Footer Controls: Audio, Copy, Timestamp */}
                {isBot && (
                  <div className="mt-3 pt-2.5 border-t border-[#E6E0D4] flex items-center justify-between text-[11px] text-[#736B5E]">
                    <span>{msg.timestamp}</span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleSpeech(msg.text)}
                        className="hover:text-[#2D5A27] flex items-center gap-1 bg-[#FDFBF7] px-2.5 py-1 rounded-xl border border-[#E6E0D4] cursor-pointer"
                        title="বাংলায় অডিও শুনুন"
                      >
                        {isSpeaking ? <VolumeX className="w-3.5 h-3.5 text-[#C0392B]" /> : <Volume2 className="w-3.5 h-3.5 text-[#2D5A27]" />}
                        <span>{isSpeaking ? 'থামান' : 'শুনুন'}</span>
                      </button>

                      <button
                        onClick={() => handleCopy(msg.id, msg.text)}
                        className="hover:text-[#2D5A27] flex items-center gap-1 bg-[#FDFBF7] px-2.5 py-1 rounded-xl border border-[#E6E0D4] cursor-pointer"
                        title="কপি করুন"
                      >
                        {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-[#2D5A27]" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedId === msg.id ? 'কপি হয়েছে' : 'কপি'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {!isBot && (
                <div className="w-9 h-9 rounded-full bg-[#E6E0D4] text-[#2D3A3A] flex items-center justify-center flex-shrink-0 mt-1 font-bold text-xs">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-3 justify-start items-center">
            <div className="w-9 h-9 rounded-full bg-[#2D5A27] text-white flex items-center justify-center flex-shrink-0">
              <Bot className="w-4 h-4 animate-bounce" />
            </div>
            <div className="bg-white border border-[#E6E0D4] rounded-2xl px-4 py-3 text-xs text-[#736B5E] flex items-center gap-2 shadow-xs">
              <Loader2 className="w-4 h-4 animate-spin text-[#2D5A27]" />
              <span>পল্লী সেবা এআই সম্পূর্ণ তথ্য অনুসন্ধান করছে...</span>
            </div>
          </div>
        )}
      </div>

      {/* Live Voice Status Indicator */}
      {voiceStatusText && (
        <div className="bg-[#2D5A27] text-white px-4 py-2.5 rounded-2xl text-xs font-semibold flex items-center justify-between shadow-sm border border-emerald-400/50 animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-400 animate-ping shrink-0" />
            <span>{voiceStatusText}</span>
          </div>
          {isListening && (
            <button
              type="button"
              onClick={handleToggleVoiceRecognition}
              className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white rounded-xl text-[11px] font-bold cursor-pointer transition shadow-2xs"
            >
              থামান
            </button>
          )}
        </div>
      )}

      {/* Message Input Box with Voice-to-Text */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="flex gap-2 items-center"
      >
        <div className="relative flex-1">
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            placeholder={`আপনার প্রশ্ন বাংলায় লিখুন বা মুখে বলুন (যেমন: আমার এলাকায় সিএনজি চালক খুঁজছি)...`}
            className="w-full bg-white border border-[#D4C3A3] rounded-2xl pl-4 pr-12 py-3.5 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] shadow-xs font-medium"
          />
          {/* Integrated Microphone Button */}
          <button
            type="button"
            onClick={handleToggleVoiceRecognition}
            className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-xl transition cursor-pointer flex items-center justify-center ${
              isListening
                ? 'bg-red-600 text-white animate-pulse shadow-md ring-2 ring-red-300'
                : 'text-[#2D5A27] hover:bg-emerald-50 hover:text-emerald-700'
            }`}
            title={isListening ? 'কথা বলা বন্ধ করুন' : 'মাইক্রোফোনে মুখে বলে খুঁজুন (যেমন: আমার এলাকায় সিএনজি চালক খুঁজছি)'}
          >
            {isListening ? <MicOff className="w-4 h-4 animate-bounce" /> : <Mic className="w-4 h-4" />}
          </button>
        </div>

        <button
          type="submit"
          disabled={isLoading || !inputPrompt.trim()}
          className="bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold px-4 sm:px-6 py-3.5 rounded-2xl text-xs sm:text-sm shadow-xs transition disabled:opacity-50 flex items-center gap-1.5 cursor-pointer shrink-0"
        >
          <Send className="w-4 h-4" />
          <span className="hidden sm:inline">পাঠান</span>
        </button>
      </form>
    </div>
  );
};
