import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Search, 
  PlusCircle, 
  Store, 
  Check
} from 'lucide-react';
import { MARKET_PRICES_DATA, BANGLADESH_DISTRICTS } from '../../data/mockData';
import { MarketPriceItem } from '../../types';
import { toBanglaNumber, formatTaka } from '../../utils/banglaNumbers';

interface MarketPricesProps {
  currentDistrict: string;
}

export const MarketPrices: React.FC<MarketPricesProps> = ({ currentDistrict }) => {
  const [items, setItems] = useState<MarketPriceItem[]>(() => {
    const saved = localStorage.getItem('polli_market_prices');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return MARKET_PRICES_DATA;
      }
    }
    return MARKET_PRICES_DATA;
  });

  useEffect(() => {
    localStorage.setItem('polli_market_prices', JSON.stringify(items));
  }, [items]);

  const [selectedCategory, setSelectedCategory] = useState<string>('সকল ক্যাটাগরি');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // Form State for reporting new market price
  const [newItemName, setNewItemName] = useState('');
  const [newItemCategory, setNewItemCategory] = useState<'খাদ্যশস্য' | 'শাকসবজি' | 'মাছ-মাংস-ডিম' | 'তেল ও মশলা' | 'কৃষি উপকরণ/সার'>('শাকসবজি');
  const [newItemUnit, setNewItemUnit] = useState('কেজি');
  const [newItemRetail, setNewItemRetail] = useState('');
  const [newItemWholesale, setNewItemWholesale] = useState('');
  const [newItemDistrict, setNewItemDistrict] = useState(currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা');
  const [districtFilter, setDistrictFilter] = useState<string>(currentDistrict);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    setDistrictFilter(currentDistrict);
    setNewItemDistrict(currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা');
  }, [currentDistrict]);

  const categories = ['সকল ক্যাটাগরি', 'খাদ্যশস্য', 'শাকসবজি', 'মাছ-মাংস-ডিম', 'তেল ও মশলা', 'কৃষি উপকরণ/সার'];

  const filteredItems = items
    .filter((item) => {
      const matchesCat = selectedCategory === 'সকল ক্যাটাগরি' || item.category === selectedCategory;
      const matchesDist = districtFilter === 'সকল জেলা' || item.district === districtFilter || item.district === 'জাতীয় গড়';
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.district.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCat && matchesDist && matchesSearch;
    })
    .sort((a, b) => {
      // Prioritize user's district
      if (districtFilter !== 'সকল জেলা') {
        if (a.district === districtFilter && b.district !== districtFilter) return -1;
        if (b.district === districtFilter && a.district !== districtFilter) return 1;
      }
      return 0;
    });

  const handleAddNewPrice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName || !newItemRetail) return;

    const retail = parseFloat(newItemRetail) || 0;
    const wholesale = parseFloat(newItemWholesale) || (retail * 0.85);

    const newItem: MarketPriceItem = {
      id: `mp-custom-${Date.now()}`,
      name: newItemName,
      category: newItemCategory,
      unit: newItemUnit,
      retailPrice: retail,
      wholesalePrice: wholesale,
      previousPrice: retail,
      district: newItemDistrict,
      updatedDate: 'এইমাত্র যোগ করা হয়েছে',
      trend: 'stable'
    };

    setItems([newItem, ...items]);
    setShowAddModal(false);
    setNewItemName('');
    setNewItemRetail('');
    setNewItemWholesale('');
    setToastMessage('আপনার স্থানীয় বাজারদর সফলভাবে যুক্ত করা হয়েছে!');
    setTimeout(() => setToastMessage(null), 4000);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
            📊 দৈনিক বাজার তথ্য
          </span>
          <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
            কৃষিপণ্য ও নিত্যপ্রয়োজনীয় দ্রব্যমূল্য দর
          </h2>
          <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
            বাংলাদেশের বিভিন্ন জেলা ও পাইকারি আড়তের হালনাগাদ খুচরা ও পাইকারি দর
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-2xl shadow-md transition cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" />
          <span>আপনার বাজারের দর যোগ করুন</span>
        </button>
      </div>

      {toastMessage && (
        <div className="p-3.5 bg-[#D4E4BC] border border-[#2D5A27]/30 text-[#2D5A27] rounded-2xl text-xs sm:text-sm flex items-center gap-2 font-semibold">
          <Check className="w-4 h-4 text-[#2D5A27]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Filter & Search Bar */}
      <div className="flex flex-col md:flex-row gap-3 items-center justify-between bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full md:w-auto pb-1 md:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-2xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#2D5A27] text-white shadow-xs'
                  : 'bg-[#FDFBF7] text-[#2D3A3A] hover:bg-[#F9E5D4]/50 border border-[#E6E0D4]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          {/* District Filter Pill */}
          <select
            value={districtFilter}
            onChange={(e) => setDistrictFilter(e.target.value)}
            className="px-3 py-2 bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl text-xs font-medium text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] cursor-pointer"
          >
            <option value="সকল জেলা">সকল জেলা (সমগ্র বাংলাদেশ)</option>
            {BANGLADESH_DISTRICTS.map((d) => (
              <option key={d} value={d}>{d} জেলা</option>
            ))}
          </select>

          <div className="relative flex-1 md:w-60">
            <Search className="w-4 h-4 text-[#736B5E] absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="পণ্য বা বাজারের নাম..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3.5 py-2 bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] focus:bg-white transition-colors"
            />
          </div>
        </div>
      </div>

      {/* Price Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredItems.map((item) => {
          const isUp = item.trend === 'up';
          const isDown = item.trend === 'down';
          const diff = Math.abs(item.retailPrice - item.previousPrice);

          return (
            <div
              key={item.id}
              className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 shadow-xs transition hover:shadow-md"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div>
                  <span className="text-[11px] font-semibold text-[#2D5A27] bg-[#D4E4BC]/40 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                    {item.category}
                  </span>
                  <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A] mt-1.5 font-['Noto_Sans_Bengali']">
                    {item.name}
                  </h3>
                  <span className="text-xs text-[#736B5E] flex items-center gap-1 mt-0.5">
                    <Store className="w-3.5 h-3.5 text-[#A65E2E]" />
                    <span>বাজার: {item.district} জেলা</span>
                  </span>
                </div>

                {/* Trend Badge */}
                <div
                  className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                    isUp
                      ? 'bg-[#FADBD8] text-[#C0392B]'
                      : isDown
                      ? 'bg-[#D5F5E3] text-[#239B56]'
                      : 'bg-[#FDFBF7] border border-[#E6E0D4] text-[#736B5E]'
                  }`}
                >
                  {isUp && <TrendingUp className="w-3 h-3" />}
                  {isDown && <TrendingDown className="w-3 h-3" />}
                  {!isUp && !isDown && <Minus className="w-3 h-3" />}
                  <span>
                    {isUp && `৳${toBanglaNumber(diff)} বৃদ্ধি`}
                    {isDown && `৳${toBanglaNumber(diff)} হ্রাস`}
                    {!isUp && !isDown && 'অপরিবর্তিত'}
                  </span>
                </div>
              </div>

              {/* Price Details */}
              <div className="grid grid-cols-2 gap-2.5 mt-3.5 pt-3.5 border-t border-[#E6E0D4]">
                <div className="bg-[#FDFBF7] p-2.5 rounded-2xl border border-[#E6E0D4]">
                  <span className="text-[11px] text-[#736B5E] block">খুচরা দর ({item.unit})</span>
                  <span className="text-base sm:text-lg font-bold text-[#2D5A27] font-['Noto_Sans_Bengali']">
                    {formatTaka(item.retailPrice)}
                  </span>
                </div>

                <div className="bg-[#FDFBF7] p-2.5 rounded-2xl border border-[#E6E0D4]">
                  <span className="text-[11px] text-[#736B5E] block">পাইকারি দর ({item.unit})</span>
                  <span className="text-base sm:text-lg font-bold text-[#A65E2E] font-['Noto_Sans_Bengali']">
                    {formatTaka(item.wholesalePrice)}
                  </span>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between text-[11px] text-[#736B5E]">
                <span>পূর্বমূল্য: {formatTaka(item.previousPrice)}</span>
                <span>{item.updatedDate}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Price Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-xl border border-[#E6E0D4] animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3 mb-4">
              <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                আপনার স্থানীয় বাজারদর রিপোর্ট করুন
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddNewPrice} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  পণ্যের নাম *
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: মিনিকেট চাল, দেশি রসুন, ফুলকপি"
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  className="w-full border border-[#D4C3A3] rounded-2xl px-3.5 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    ক্যাটাগরি
                  </label>
                  <select
                    value={newItemCategory}
                    onChange={(e) => setNewItemCategory(e.target.value as any)}
                    className="w-full border border-[#D4C3A3] rounded-2xl px-3 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  >
                    <option value="শাকসবজি">শাকসবজি</option>
                    <option value="খাদ্যশস্য">খাদ্যশস্য</option>
                    <option value="মাছ-মাংস-ডিম">মাছ-মাংস-ডিম</option>
                    <option value="তেল ও মশলা">তেল ও মশলা</option>
                    <option value="কৃষি উপকরণ/সার">কৃষি উপকরণ/সার</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    পরিমাপের একক
                  </label>
                  <input
                    type="text"
                    value={newItemUnit}
                    onChange={(e) => setNewItemUnit(e.target.value)}
                    placeholder="কেজি / মণ / ডজন"
                    className="w-full border border-[#D4C3A3] rounded-2xl px-3.5 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    খুচরা মূল্য (টাকা) *
                  </label>
                  <input
                    type="number"
                    required
                    placeholder="যেমন: ৫০"
                    value={newItemRetail}
                    onChange={(e) => setNewItemRetail(e.target.value)}
                    className="w-full border border-[#D4C3A3] rounded-2xl px-3.5 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    পাইকারি মূল্য (টাকা)
                  </label>
                  <input
                    type="number"
                    placeholder="যেমন: ৪২"
                    value={newItemWholesale}
                    onChange={(e) => setNewItemWholesale(e.target.value)}
                    className="w-full border border-[#D4C3A3] rounded-2xl px-3.5 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  জেলা
                </label>
                <select
                  value={newItemDistrict}
                  onChange={(e) => setNewItemDistrict(e.target.value)}
                  className="w-full border border-[#D4C3A3] rounded-2xl px-3 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                >
                  {BANGLADESH_DISTRICTS.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#E6E0D4]">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-2xl text-xs font-semibold text-[#736B5E] bg-[#FDFBF7] hover:bg-[#E6E0D4] cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-2xl text-xs font-semibold text-white bg-[#2D5A27] hover:bg-[#23491E] cursor-pointer shadow-xs"
                >
                  দাখিল করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
