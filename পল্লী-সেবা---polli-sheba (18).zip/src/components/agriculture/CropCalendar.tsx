import React, { useState } from 'react';
import { Sun, CloudRain, Snowflake, Check } from 'lucide-react';

interface SeasonPlan {
  id: string;
  seasonName: string;
  banglaMonths: string;
  englishMonths: string;
  icon: React.ReactNode;
  keyCrops: string[];
  activities: string[];
  warning: string;
}

export const CropCalendar: React.FC = () => {
  const [selectedSeason, setSelectedSeason] = useState<string>('rabi');

  const seasons: SeasonPlan[] = [
    {
      id: 'rabi',
      seasonName: 'রবি মৌসুম (শীতকালীন ফসল)',
      banglaMonths: 'কার্তিক থেকে ফাল্গুন',
      englishMonths: 'অক্টোবর - মার্চ',
      icon: <Snowflake className="w-5 h-5 text-[#2B6CB0]" />,
      keyCrops: ['বোরো ধান', 'আলু', 'গম', 'সরিষা', 'ভুট্টা', 'টমেটো', 'ফুলকপি/বাঁধাকপি', 'মসুর ও ছোলা', 'পেঁয়াজ/রসুন'],
      activities: [
        'কার্তিক-অগ্রহায়ণে আলু ও সরিষা বপন সম্পন্ন করা।',
        'পৌষ মাসে বোরো ধানের বীজতলা তৈরি ও চারা রোপণ।',
        'শীতকালীন শাকসবজিতে নিয়মিত সান্ধ্যকালীন কুয়াশা প্রতিরোধক স্প্রে ও নিড়ানি দেওয়া।',
        'মাঘ মাসে গম ও সরিষায় প্রয়োজনমাফিক হালকা সেচ প্রদান।'
      ],
      warning: 'শৈত্যপ্রবাহ ও ঘন কুয়াশায় আলুর নাভিধসা এবং ধানের চারা হলুদ হওয়া রোধে আগাম ছত্রাকনাশক স্প্রে নিশ্চিত করুন।'
    },
    {
      id: 'kharif1',
      seasonName: 'খরিপ-১ মৌসুম (গ্রীষ্মকালীন ফসল)',
      banglaMonths: 'চৈত্র থেকে জ্যৈষ্ঠ',
      englishMonths: 'মার্চ - জুন',
      icon: <Sun className="w-5 h-5 text-[#A65E2E]" />,
      keyCrops: ['আউশ ধান', 'তোষা পাট', 'গ্রীষ্মকালীন তিল', 'ঢ্যাঁড়শ', 'করলা ও ঝিঙা', 'মুগ ডাল', 'মিষ্টি কুমড়া'],
      activities: [
        'চৈত্র মাসের বৃষ্টির পরপরই পাটের বীজ জমিতে বপন করা।',
        'বোনার আউশ ও রোপা আউশের বীজতলার প্রস্তুতি নেওয়া।',
        'গ্রীষ্মকালীন শাকসবজির মাচা তৈরি ও মালচিং ব্যবহার করে আর্দ্রতা ধরে রাখা।',
        'ফলদ বৃক্ষ যেমন আম ও লিচুর গুটি ঝরা রোধে হরমোন ও ছত্রাকনাশক স্প্রে।'
      ],
      warning: 'কালবৈশাখী ঝড় ও আকস্মিক শিলাবৃষ্টি থেকে পাকা বোরো ধান ও ফসল রক্ষায় ৮০% পাকলেই কেটে ফেলুন।'
    },
    {
      id: 'kharif2',
      seasonName: 'খরিপ-২ মৌসুম (বর্ষাকালীন ফসল)',
      banglaMonths: 'আষাঢ় থেকে কার্তিক',
      englishMonths: 'জুন - অক্টোবর',
      icon: <CloudRain className="w-5 h-5 text-[#2D5A27]" />,
      keyCrops: ['রোপা আমন ধান', 'নাব্যতা সহনশীল ধান (ব্রি ধান-৫১, ৫২)', 'বর্ষাকালীন শসা', 'বরবটি', 'লাউ', 'ওলকচু'],
      activities: [
        'আষাঢ় মাসে আমন ধানের বীজতলায় বীজ বপন ও শ্রাবণ মাসে ৩০-৩৫ দিনের চারা মূল জমিতে রোপণ।',
        'জমির আইল উঁচু ও মজবুত করা যাতে বৃষ্টির পানি আটকে রাখা যায়।',
        'পাট কাটা, জাগ দেওয়া এবং উন্নত পচন পদ্ধতিতে রিবন রেটিং করা।',
        'ভাদ্র মাসে আমন ধানের জমিতে মাজরা ও বাদামি ঘাসফড়িং দমনে পার্চিং ও আলোক ফাঁদ ব্যবহার।'
      ],
      warning: 'বন্যাপ্রবণ নিচু জমিতে জলমগ্নতা সহনশীল ধানের জাত যেমন ব্রি ধান৫১ বা ব্রি ধান৭৯ রোপণ করুন।'
    }
  ];

  const currentPlan = seasons.find(s => s.id === selectedSeason) || seasons[0];

  return (
    <div className="space-y-5">
      {/* Header Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm">
        <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
          📅 বার্ষিক কৃষি পঞ্জিকা
        </span>
        <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
          মৌসুমী ফসল চাষাবাদ ও পরিচর্যা ক্যালেন্ডার
        </h2>
        <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
          বাংলাদেশের জলবায়ু ও ঋতু অনুযায়ী কোন মাসে কী চাষ করবেন এবং কখন কী পরিচর্যা করবেন
        </p>
      </div>

      {/* Season Picker Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {seasons.map((s) => {
          const isSelected = selectedSeason === s.id;
          return (
            <button
              key={s.id}
              onClick={() => setSelectedSeason(s.id)}
              className={`p-5 rounded-3xl border-2 text-left transition-all cursor-pointer ${
                isSelected
                  ? 'border-[#2D5A27] bg-[#D4E4BC]/30 shadow-sm ring-2 ring-[#2D5A27]/20'
                  : 'border-[#E6E0D4] bg-white hover:bg-[#FDFBF7]'
              }`}
            >
              <div className="flex items-center gap-2 mb-1.5">
                {s.icon}
                <span className="font-bold text-sm sm:text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">{s.seasonName}</span>
              </div>
              <p className="text-xs text-[#736B5E]">
                {s.banglaMonths} ({s.englishMonths})
              </p>
            </button>
          );
        })}
      </div>

      {/* Selected Season Detail */}
      <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-[#2D3A3A] font-['Noto_Sans_Bengali']">
              {currentPlan.seasonName} - বিস্তারিত নির্দেশিকা
            </h3>
            <span className="text-xs text-[#736B5E]">
              সময়কাল: {currentPlan.banglaMonths} ({currentPlan.englishMonths})
            </span>
          </div>
        </div>

        {/* Crops List */}
        <div>
          <h4 className="text-xs sm:text-sm font-bold text-[#2D3A3A] mb-2.5">
            🌱 এ মৌসুমের প্রধান লাভজনক ফসলসমূহ:
          </h4>
          <div className="flex flex-wrap gap-2">
            {currentPlan.keyCrops.map((crop, idx) => (
              <span
                key={idx}
                className="bg-[#D4E4BC]/50 text-[#2D5A27] border border-[#D4E4BC] text-xs font-semibold px-3.5 py-1 rounded-full"
              >
                {crop}
              </span>
            ))}
          </div>
        </div>

        {/* Key Activities */}
        <div>
          <h4 className="text-xs sm:text-sm font-bold text-[#2D3A3A] mb-2.5">
            📋 কৃষকের প্রধান করণীয় ও কাজের সময়সূচি:
          </h4>
          <div className="space-y-2.5">
            {currentPlan.activities.map((act, idx) => (
              <div key={idx} className="flex items-start gap-3 bg-[#FDFBF7] p-3 rounded-2xl border border-[#E6E0D4] text-xs sm:text-sm text-[#2D3A3A]">
                <Check className="w-4 h-4 text-[#2D5A27] flex-shrink-0 mt-0.5" />
                <span>{act}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Advisory Warning */}
        <div className="p-4 bg-[#F9E5D4]/60 border border-[#F9E5D4] rounded-2xl text-xs text-[#A65E2E] leading-relaxed">
          <strong>⚠️ দুর্যোগ ও প্রতিকূল আবহাওয়া সতর্কতা: </strong>
          {currentPlan.warning}
        </div>
      </div>
    </div>
  );
};
