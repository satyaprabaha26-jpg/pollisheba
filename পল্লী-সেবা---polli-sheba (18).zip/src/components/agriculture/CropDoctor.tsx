import React, { useState, useRef } from 'react';
import { 
  Search, 
  ShieldAlert, 
  FlaskConical, 
  Leaf, 
  Sparkles, 
  Upload, 
  Camera,
  X,
  Info, 
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Loader2
} from 'lucide-react';
import { CROP_DISEASES_DATA } from '../../data/mockData';
import { CropDisease } from '../../types';

export const CropDoctor: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('সকল ফসল');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedDisease, setSelectedDisease] = useState<CropDisease | null>(CROP_DISEASES_DATA[0]);

  // AI Diagnostic State
  const [aiCropName, setAiCropName] = useState<string>('');
  const [aiSymptom, setAiSymptom] = useState<string>('');
  const [aiImageBase64, setAiImageBase64] = useState<string | null>(null);
  const [isDiagnosing, setIsDiagnosing] = useState<boolean>(false);
  const [aiDiagnosisResult, setAiDiagnosisResult] = useState<string | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);

  // Live Camera State
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const categories = ['সকল ফসল', 'ধান ও খাদ্যশস্য', 'শাকসবজি', 'অর্থকরী ফসল', 'ডাল ও তেলবীজ'];
  const POPULAR_CROPS = ['ধান', 'আলু', 'ভুট্টা', 'গম', 'মরিচ', 'সরিষা', 'টমেটো', 'বেগুন', 'পেঁয়াজ', 'আম', 'পাট', 'শসা', 'লাউ'];
  const [selectedCropFilter, setSelectedCropFilter] = useState<string>('সকল নির্দিষ্ট ফসল');

  const filteredDiseases = CROP_DISEASES_DATA.filter((item) => {
    const matchesCategory = selectedCategory === 'সকল ফসল' || item.cropCategory === selectedCategory;
    const matchesCropFilter = selectedCropFilter === 'সকল নির্দিষ্ট ফসল' || item.cropName.includes(selectedCropFilter) || selectedCropFilter.includes(item.cropName);
    const matchesSearch = searchQuery === '' || 
      item.cropName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.diseaseName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.symptoms.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesCropFilter && matchesSearch;
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        const pureBase64 = base64String.split(',')[1];
        setAiImageBase64(pureBase64);
      };
      reader.readAsDataURL(file);
    }
  };

  // Start Live Camera
  const handleStartCamera = async () => {
    setCameraError(null);
    setIsCameraActive(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.error('Camera access error:', err);
      setCameraError('ক্যামেরা চালু করতে ব্রাউজারের পারমিশন দিন অথবা সাধারণ ফাইল আপলোড ব্যবহার করুন।');
    }
  };

  // Stop Live Camera
  const handleStopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
    setCameraError(null);
  };

  // Snap Photo from Video
  const handleSnapPhoto = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      const pureBase64 = dataUrl.split(',')[1];
      setAiImageBase64(pureBase64);
    }
    handleStopCamera();
  };

  const handleRunAiDiagnosis = async () => {
    if (!aiCropName.trim() && !aiSymptom.trim() && !aiImageBase64) {
      setAiError('অনুগ্রহ করে ফসলের নাম, লক্ষণ বা ছবি প্রদান করুন।');
      return;
    }

    setIsDiagnosing(true);
    setAiError(null);
    setAiDiagnosisResult(null);

    try {
      let diagnosisText: string | null = null;

      // 1. Try server or Netlify serverless functions with safe text parsing
      try {
        const payload = JSON.stringify({
          cropName: aiCropName,
          symptom: aiSymptom,
          imageBase64: aiImageBase64,
          mimeType: 'image/jpeg'
        });

        // First attempt standard endpoint
        let res = await fetch('/api/gemini/diagnose-crop', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: payload
        });

        // Fallback to direct Netlify function if /api/ redirected to HTML or failed
        if (!res.ok) {
          try {
            const netlifyRes = await fetch('/.netlify/functions/diagnose-crop', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: payload
            });
            if (netlifyRes.ok) {
              res = netlifyRes;
            }
          } catch (e) {
            // continue
          }
        }

        const rawText = await res.text();
        if (rawText && !rawText.trim().startsWith('<') && !rawText.trim().startsWith('<!DOCTYPE')) {
          try {
            const data = JSON.parse(rawText);
            if (data && data.diagnosis) {
              diagnosisText = data.diagnosis;
            }
          } catch (jsonErr) {
            console.warn('JSON parse error from crop diagnosis:', jsonErr);
          }
        }
      } catch (fetchErr) {
        console.warn('Backend diagnose-crop route note:', fetchErr);
      }

      // 2. Smart local agricultural knowledge match if API is unavailable / network error
      if (!diagnosisText) {
        const queryTerm = (aiCropName + ' ' + aiSymptom).toLowerCase();
        const matchedDisease = CROP_DISEASES_DATA.find(d => 
          (aiCropName && (d.cropName.toLowerCase().includes(aiCropName.toLowerCase()) || aiCropName.toLowerCase().includes(d.cropName.toLowerCase()))) ||
          d.symptoms.some(s => queryTerm.includes(s.slice(0, 5)))
        );

        if (matchedDisease) {
          diagnosisText = `🌾 **রোগের নাম:** ${matchedDisease.diseaseName} (${matchedDisease.cropName})\n\n` +
            `🔍 **কারণ ও লক্ষণ:** ${matchedDisease.causes} (তীব্রতা: ${matchedDisease.severity})\n\n` +
            `💊 **কার্যকর রাসায়নিক প্রতিকার:** ${matchedDisease.chemicalRemedy}\n\n` +
            `🌿 **ভেষজ ও প্রাকৃতিক জৈব সমাধান:** ${matchedDisease.organicRemedy}\n\n` +
            `🛡️ **প্রতিরোধমূলক ব্যবস্থা:** ${matchedDisease.preventiveMeasures}\n\n` +
            `📞 **বিশেষজ্ঞ পরামর্শ:** সরাসরি কৃষি বিশেষজ্ঞের সাথে কথা বলতে কল করুন **১৬১২৩**।`;
        } else {
          diagnosisText = `🌾 **ফসল রোগ বিশ্লেষণ ও প্রাথমিক প্রেসক্রিপশন (${aiCropName || 'সাধারণ ফসল'}):**\n\n` +
            `🔍 **পর্যবেক্ষণ ও লক্ষণ:** ${aiSymptom || 'আক্রান্ত অংশে দাগ বা পচন পরিলক্ষিত হয়েছে'}\n\n` +
            `💊 **দ্রুত নিরাময় ও বালাইনাশক:**\n` +
            `• ছত্রাকজনিত সমস্যা হলে: প্রতি লিটার পানিতে ২ গ্রাম ম্যানকোজেব বা কার্বেনডাজিম মিশিয়ে বিকেলে স্প্রে করুন।\n` +
            `• পোকা দমনে: অনুমোদিত ইমিডাক্লোপ্রিড (০.৫ মিলি/লিটার) অথবা অ্যাসিফেট ব্যবহার করুন।\n\n` +
            `🌿 **প্রাকৃতিক জৈব প্রতিকার:**\n` +
            `• আক্রান্ত পাতা ও ডালপালা কেটে নিরাপদ দূরত্বে পুড়িয়ে ফেলুন।\n` +
            `• নিম তেলের স্প্রে (প্রতি লিটার পানিতে ৫ মিলি নিম তেল + হালকা গুঁড়া সাবান) প্রয়োগ করুন।\n\n` +
            `📞 **জরুরি কৃষি বাতায়ন:** নিকটস্থ উপজেলা কৃষি কর্মকর্তা বা কৃষি কল সেন্টারে **১৬১২৩** নম্বরে যোগাযোগ করুন।`;
        }
      }

      setAiDiagnosisResult(diagnosisText);
    } catch (err: any) {
      // Never show technical JSON syntax errors to user
      setAiError('নেটওয়ার্ক সংযোগে সমস্যা হচ্ছে। আপনার নিকটস্থ কৃষি কর্মকর্তা বা ১৬১২৩ নম্বরে সহায়তা নিতে পারেন।');
    } finally {
      setIsDiagnosing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="inline-block bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2">
              🌾 ডিজিটাল শস্য ডাক্তার
            </span>
            <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
              ফসলের রোগবালাই ও বালাইদমন নির্দেশিকা
            </h2>
            <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1 max-w-2xl">
              ফসলের রোগ লক্ষণ শনাক্ত করুন এবং সঠিক কীটনাশক, ছত্রাকনাশক ও জৈব ঘরোয়া সমাধান জেনে নিন।
            </p>
          </div>

          <div className="bg-[#23491E] border border-[#3D7A35] p-3.5 rounded-2xl text-xs text-[#D4E4BC]">
            <p className="font-semibold text-[#F9E5D4] flex items-center gap-1.5">
              <Info className="w-4 h-4 text-[#E8924A]" />
              কৃষি বিশেষজ্ঞ কল সেন্টার
            </p>
            <p className="mt-1">সরাসরি পরামর্শ পেতে ১৬১২৩ নম্বরে ডায়াল করুন</p>
          </div>
        </div>
      </div>

      {/* AI Smart Disease Scanner Card in Warm Earthy Theme */}
      <div className="bg-[#E8924A]/10 border border-[#E8924A]/25 rounded-3xl p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-[#E8924A] text-white rounded-2xl flex items-center justify-center shadow-xs">
            <Sparkles className="w-5 h-5 fill-white" />
          </div>
          <div>
            <h3 className="font-bold text-base sm:text-lg text-[#A65E2E]">
              এআই শস্য রোগ নির্ণয়ক (AI Crop Doctor)
            </h3>
            <p className="text-xs text-[#5A6B6B]">
              আপনার ফসলের লক্ষণ লিখুন অথবা পাতা/গাছের ছবি আপলোড করুন—AI তাৎক্ষণিক প্রতিকার জানাবে
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-4">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-[#2D3A3A]">
                ফসলের নাম (বাছাই করুন বা লিখে দিন):
              </label>
              {aiCropName && (
                <button
                  type="button"
                  onClick={() => setAiCropName('')}
                  className="text-[10px] text-[#A65E2E] hover:underline cursor-pointer"
                >
                  ক্লিয়ার
                </button>
              )}
            </div>
            <input
              type="text"
              placeholder="উদা: ব্রি ধান-২৮, গোল আলু, মরিচ..."
              value={aiCropName}
              onChange={(e) => setAiCropName(e.target.value)}
              className="w-full bg-white border border-[#D4C3A3] rounded-2xl px-3.5 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] shadow-2xs"
            />
            {/* Quick Crop Selector Pills */}
            <div className="flex flex-wrap gap-1 mt-1.5 max-h-16 overflow-y-auto no-scrollbar">
              {POPULAR_CROPS.map((crop) => (
                <button
                  key={crop}
                  type="button"
                  onClick={() => setAiCropName(crop)}
                  className={`text-[10px] px-2 py-0.5 rounded-lg border transition cursor-pointer ${
                    aiCropName.includes(crop)
                      ? 'bg-[#2D5A27] text-white border-[#2D5A27] font-bold'
                      : 'bg-white text-[#5A6B6B] border-[#E6E0D4] hover:bg-[#FDFBF7]'
                  }`}
                >
                  {crop}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#2D3A3A] mb-1.5">
              লক্ষণ বা সমস্যার বিবরণ
            </label>
            <input
              type="text"
              placeholder="উদা: পাতা হলুদ হয়ে পোড়ার মতো দাগ"
              value={aiSymptom}
              onChange={(e) => setAiSymptom(e.target.value)}
              className="w-full bg-white border border-[#D4C3A3] rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] shadow-2xs"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#2D3A3A] mb-1.5">
              আক্রান্ত পাতা/গাছের ছবি (সরাসরি ক্যামেরা / গ্যালারি)
            </label>
            {aiImageBase64 ? (
              <div className="flex items-center justify-between gap-2 p-2 bg-white border border-[#2D5A27] rounded-2xl shadow-2xs">
                <div className="flex items-center gap-2 overflow-hidden">
                  <img
                    src={`data:image/jpeg;base64,${aiImageBase64}`}
                    alt="Uploaded Crop"
                    className="w-10 h-10 object-cover rounded-xl border border-[#E6E0D4]"
                  />
                  <span className="text-xs text-[#2D5A27] font-bold truncate">ছবি যুক্ত হয়েছে ✓</span>
                </div>
                <button
                  type="button"
                  onClick={() => setAiImageBase64(null)}
                  className="p-1.5 bg-[#F9E5D4] hover:bg-[#FADBD8] text-[#C0392B] rounded-xl transition cursor-pointer"
                  title="ছবি মুছুন"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleStartCamera}
                  className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white rounded-2xl py-2 px-2 text-xs flex items-center justify-center gap-1.5 font-bold shadow-2xs transition cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  <span>ক্যামেরা</span>
                </button>

                <div className="relative w-full">
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="crop-image-upload"
                  />
                  <label
                    htmlFor="crop-image-upload"
                    className="w-full bg-white hover:bg-[#FDFBF7] border border-dashed border-[#2D5A27] rounded-2xl py-2 px-2 text-xs flex items-center justify-center gap-1 text-[#2D5A27] cursor-pointer font-bold shadow-2xs text-center"
                  >
                    <Upload className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>গ্যালারি</span>
                  </label>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Live Camera Stream Modal */}
        {isCameraActive && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl border border-[#E6E0D4] space-y-4">
              <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-2.5">
                <h4 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-2">
                  <Camera className="w-4 h-4 text-[#2D5A27]" />
                  <span>আক্রান্ত ফসলের ছবি তুলুন</span>
                </h4>
                <button
                  onClick={handleStopCamera}
                  className="p-1 rounded-full text-gray-500 hover:text-black cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {cameraError ? (
                <div className="p-3 bg-red-50 text-red-700 text-xs rounded-xl border border-red-200">
                  {cameraError}
                </div>
              ) : (
                <div className="relative rounded-2xl overflow-hidden bg-black aspect-4/3 flex items-center justify-center">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 border-2 border-dashed border-white/50 rounded-2xl pointer-events-none m-4" />
                </div>
              )}

              <div className="flex items-center justify-between gap-3 pt-2">
                <button
                  onClick={handleStopCamera}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-2xl text-xs cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  onClick={handleSnapPhoto}
                  disabled={!!cameraError}
                  className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 px-4 rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
                >
                  <Camera className="w-4 h-4" />
                  <span>ছবি ধারণ করুন (Snap)</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {aiError && (
          <div className="mt-3.5 p-3 bg-[#FADBD8] border border-[#C0392B]/30 text-[#C0392B] text-xs rounded-2xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{aiError}</span>
          </div>
        )}

        <div className="mt-4 flex justify-end">
          <button
            onClick={handleRunAiDiagnosis}
            disabled={isDiagnosing}
            className="flex items-center gap-2 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-2xl shadow-sm transition disabled:opacity-50 cursor-pointer"
          >
            {isDiagnosing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>AI বিশ্লেষণ করছে...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-[#D4E4BC]" />
                <span>রোগ নির্ণয় ও প্রেসক্রিপশন পান</span>
              </>
            )}
          </button>
        </div>

        {/* AI Diagnosis Result Display */}
        {aiDiagnosisResult && (
          <div className="mt-5 p-5 bg-white border border-[#E6E0D4] rounded-2xl shadow-sm text-[#2D3A3A] space-y-3">
            <div className="flex items-center gap-2 text-[#2D5A27] border-b border-[#E6E0D4] pb-2.5">
              <CheckCircle2 className="w-5 h-5 text-[#2D5A27]" />
              <h4 className="font-bold text-sm sm:text-base">
                এআই কৃষি ডাক্তারের পরামর্শ ও প্রেসক্রিপশন:
              </h4>
            </div>
            <div className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap font-['Hind_Siliguri'] text-[#2D3A3A]">
              {aiDiagnosisResult}
            </div>
          </div>
        )}
      </div>

      {/* Disease Catalog Section */}
      <div className="space-y-4">
        {/* Search & Filter Bar */}
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full sm:w-auto pb-1 sm:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-2xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <select
              value={selectedCropFilter}
              onChange={(e) => setSelectedCropFilter(e.target.value)}
              className="bg-white border border-[#E6E0D4] focus:border-[#2D5A27] rounded-2xl px-3 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none shadow-xs"
            >
              <option value="সকল নির্দিষ্ট ফসল">🌾 সব ফসল</option>
              {POPULAR_CROPS.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-[#736B5E] absolute left-3.5 top-3" />
              <input
                type="text"
                placeholder="ফসলের বা রোগের নাম লিখুন..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3.5 py-2 bg-white border border-[#E6E0D4] focus:border-[#2D5A27] rounded-2xl text-xs sm:text-sm text-[#2D3A3A] focus:outline-none shadow-xs"
              />
            </div>
          </div>
        </div>

        {/* Master-Detail Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Disease List */}
          <div className="lg:col-span-5 space-y-2.5 max-h-[620px] overflow-y-auto pr-1">
            {filteredDiseases.length === 0 ? (
              <div className="text-center py-10 bg-white rounded-3xl border border-[#E6E0D4] p-6">
                <HelpCircle className="w-10 h-10 text-[#D4C3A3] mx-auto mb-2" />
                <p className="text-[#736B5E] text-sm">কোনো রোগ পাওয়া যায়নি।</p>
                <p className="text-xs text-[#736B5E]/80 mt-1">অন্য কীওয়ার্ড দিয়ে অনুসন্ধান করুন।</p>
              </div>
            ) : (
              filteredDiseases.map((d) => {
                const isSelected = selectedDisease?.id === d.id;
                return (
                  <div
                    key={d.id}
                    onClick={() => setSelectedDisease(d)}
                    className={`p-4 rounded-2xl border transition cursor-pointer text-left ${
                      isSelected
                        ? 'bg-[#D4E4BC]/30 border-[#2D5A27] shadow-xs'
                        : 'bg-white border-[#E6E0D4] hover:border-[#2D5A27] hover:bg-[#FDFBF7]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl select-none">{d.icon}</span>
                        <div>
                          <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">
                            {d.diseaseName}
                          </h4>
                          <span className="text-[11px] font-semibold text-[#2D5A27]">
                            {d.cropName}
                          </span>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${
                          d.severity === 'গুরুতর'
                            ? 'bg-[#FADBD8] text-[#C0392B]'
                            : 'bg-[#F9E5D4] text-[#A65E2E]'
                        }`}
                      >
                        {d.severity}
                      </span>
                    </div>

                    <p className="text-xs text-[#5A6B6B] line-clamp-2 mt-2 leading-relaxed">
                      {d.symptoms[0]}
                    </p>
                  </div>
                );
              })
            )}
          </div>

          {/* Detailed Solution View */}
          <div className="lg:col-span-7">
            {selectedDisease ? (
              <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-sm space-y-4 sticky top-36">
                <div className="flex items-start justify-between gap-3 border-b border-[#E6E0D4] pb-4">
                  <div className="flex items-center gap-3.5">
                    <span className="text-3xl p-2.5 bg-[#FDFBF7] rounded-2xl border border-[#E6E0D4]">
                      {selectedDisease.icon}
                    </span>
                    <div>
                      <span className="text-xs font-semibold bg-[#D4E4BC] text-[#2D5A27] px-2.5 py-0.5 rounded-full">
                        {selectedDisease.cropCategory} • {selectedDisease.cropName}
                      </span>
                      <h3 className="text-lg sm:text-xl font-bold text-[#2D3A3A] mt-1 font-['Noto_Sans_Bengali']">
                        {selectedDisease.diseaseName}
                      </h3>
                    </div>
                  </div>
                </div>

                {/* Symptoms */}
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-[#2D3A3A] flex items-center gap-1.5 mb-2">
                    <ShieldAlert className="w-4 h-4 text-[#E8924A]" />
                    <span>রোগের প্রধান লক্ষণসমূহ:</span>
                  </h4>
                  <ul className="space-y-1.5">
                    {selectedDisease.symptoms.map((sym, idx) => (
                      <li key={idx} className="text-xs sm:text-sm text-[#2D3A3A] flex items-start gap-2 bg-[#FDFBF7] p-2.5 rounded-xl border border-[#E6E0D4]/60">
                        <span className="text-[#2D5A27] font-bold">•</span>
                        <span>{sym}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Cause */}
                <div className="p-3.5 bg-[#F9E5D4]/60 border border-[#F9E5D4] rounded-2xl">
                  <span className="font-bold text-xs text-[#A65E2E] block mb-0.5">আক্রমণের মূল কারণ:</span>
                  <p className="text-xs text-[#A65E2E] leading-relaxed">{selectedDisease.causes}</p>
                </div>

                {/* Chemical Remedy */}
                <div className="p-4 bg-[#D1E5F0]/40 border border-[#D1E5F0] rounded-2xl space-y-1">
                  <h4 className="text-xs sm:text-sm font-bold text-[#2B6CB0] flex items-center gap-1.5">
                    <FlaskConical className="w-4 h-4 text-[#2B6CB0]" />
                    <span>রাসায়নিক বালাইনাশক ও স্প্রে প্রয়োগ বিধি:</span>
                  </h4>
                  <p className="text-xs sm:text-sm text-[#2D3A3A] leading-relaxed">
                    {selectedDisease.chemicalRemedy}
                  </p>
                </div>

                {/* Organic / Natural Remedy */}
                <div className="p-4 bg-[#D5F5E3]/40 border border-[#D5F5E3] rounded-2xl space-y-1">
                  <h4 className="text-xs sm:text-sm font-bold text-[#239B56] flex items-center gap-1.5">
                    <Leaf className="w-4 h-4 text-[#239B56]" />
                    <span>ঘরোয়া ও প্রাকৃতিক জৈব প্রতিকার:</span>
                  </h4>
                  <p className="text-xs sm:text-sm text-[#2D3A3A] leading-relaxed">
                    {selectedDisease.organicRemedy}
                  </p>
                </div>

                {/* Prevention */}
                <div className="text-xs sm:text-sm text-[#5A6B6B] bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#E6E0D4]">
                  <strong className="text-[#2D3A3A]">ভবিষ্যতে প্রতিরোধে করণীয়: </strong>
                  {selectedDisease.preventiveMeasures}
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-[#736B5E] bg-white rounded-3xl border border-[#E6E0D4]">
                বাম পাশের তালিকা থেকে যেকোনো রোগ নির্বাচন করুন।
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
