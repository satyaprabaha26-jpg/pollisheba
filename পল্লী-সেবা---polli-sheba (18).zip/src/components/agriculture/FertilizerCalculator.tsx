import React, { useState } from 'react';
import { Sprout, Info, CheckCircle, Scale } from 'lucide-react';
import { toBanglaNumber } from '../../utils/banglaNumbers';

interface CropFertilizerSpec {
  name: string;
  category: string;
  perDecimal: {
    ureaKg: number;
    tspKg: number;
    mopKg: number;
    gypsumKg: number;
    zincKg: number;
    organicKg: number;
  };
  schedule: string[];
  tips: string;
}

const CROP_SPECS: Record<string, CropFertilizerSpec> = {
  'boro_rice': {
    name: 'বোরো ধান (উচ্চ ফলনশীল/হাইব্রিড)',
    category: 'ধান ও খাদ্যশস্য',
    perDecimal: { ureaKg: 1.1, tspKg: 0.4, mopKg: 0.6, gypsumKg: 0.4, zincKg: 0.04, organicKg: 4.0 },
    schedule: [
      'জমি তৈরির শেষ চাষে: সমুদয় টিএসপি, এমপি সারের অর্ধেক, জিপসাম, জিংক ও পচা গোবর সার মাটিতে মিশিয়ে দিন।',
      '১ম কিস্তি: চারা রোপণের ১৫-২০ দিন পর ইউরিয়া সারের এক-তৃতীয়াংশ উপরিপ্রয়োগ করুন।',
      '২য় কিস্তি: চারা রোপণের ৩৫-৪০ দিন পর (কুশি আসার সময়) ইউরিয়ার দ্বিতীয় কিস্তি ও বাকি এমপি সার দিন।',
      '৩য় কিস্তি: কাইচ থোড় আসার ৫-৭ দিন আগে ইউরিয়ার শেষ কিস্তি উপরিপ্রয়োগ করুন।'
    ],
    tips: 'ইউরিয়া সার প্রয়োগের সময় জমিতে ছিপছিপে ১-২ ইঞ্চি পানি রাখুন। প্রখর রোদে সার ছিটাবেন না, বিকেলে প্রয়োগ করা উত্তম।'
  },
  'amon_rice': {
    name: 'রোপা আমন ধান (উফশী)',
    category: 'ধান ও খাদ্যশস্য',
    perDecimal: { ureaKg: 0.8, tspKg: 0.35, mopKg: 0.45, gypsumKg: 0.3, zincKg: 0.03, organicKg: 3.5 },
    schedule: [
      'শেষ চাষে: সমুদয় টিএসপি, অর্ধেক এমপি, সম্পূর্ণ জিপসাম ও জিংক প্রয়োগ করুন।',
      '১ম কিস্তি: চারা লাগানোর ১০-১৫ দিন পর ইউরিয়ার এক-তৃতীয়াংশ।',
      '২য় কিস্তি: কুশি গজানোর সময় (রোপণের ৩০-৩৫ দিন পর) ইউরিয়ার দ্বিতীয় কিস্তি ও বাকি এমপি সার।',
      '৩য় কিস্তি: থোড় আসার সময় ইউরিয়ার শেষ কিস্তি।'
    ],
    tips: 'আমন মৌসুমে জমিতে পর্যাপ্ত জৈব সার দিলে ইউরিয়ার কার্যকারিতা বৃদ্ধি পায় এবং খরা সহনশীলতা বাড়ে।'
  },
  'potato': {
    name: 'আলু (উচ্চ ফলনশীল)',
    category: 'কন্দাল ফসল',
    perDecimal: { ureaKg: 1.4, tspKg: 0.9, mopKg: 1.1, gypsumKg: 0.5, zincKg: 0.06, organicKg: 8.0 },
    schedule: [
      'জমি তৈরিতে: অর্ধেক ইউরিয়া, সমুদয় টিএসপি, অর্ধেক এমপি, জিপসাম, বোরন ও ট্রাইকো-গোবর মাটির সাথে ভালোভাবে মিশিয়ে দিন।',
      'উপরিপ্রয়োগ: গাছ গজানোর ৩০-৩৫ দিন পর ১ম সেচের আগে বাকি ইউরিয়া ও বাকি এমপি সার গাছের গোড়ায় দিয়ে মাটি তুলে দিন।'
    ],
    tips: 'আলুর গুটি বাঁধার সময় জমিতে যেন রসের অভাব না হয়। তবে অতিরিক্ত পানি জমলে নাভিধসা রোগ হতে পারে।'
  },
  'maize': {
    name: 'ভুট্টা (হাইব্রিড ভুট্টা)',
    category: 'খাদ্যশস্য',
    perDecimal: { ureaKg: 2.0, tspKg: 1.0, mopKg: 0.9, gypsumKg: 0.7, zincKg: 0.05, organicKg: 5.0 },
    schedule: [
      'শেষ চাষে: সমুদয় টিএসপি, জিপসাম, জিংক এবং ইউরিয়া ও এমপির এক-তৃতীয়াংশ মাটিতে দিন।',
      '৮-১০ পাতা অবস্থায় (বপনের ৩০-৩৫ দিন পর): এক-তৃতীয়াংশ ইউরিয়া ও এক-তৃতীয়াংশ এমপি সার দিয়ে সেচ দিন।',
      'মোচা বের হওয়ার আগে (৫৫-৬০ দিন পর): বাকি ইউরিয়া ও এমপি উপরিপ্রয়োগ করুন।'
    ],
    tips: 'ভুট্টা গাছে বেশি পুষ্টি লাগে। মাটিতে নাইট্রোজেন ও জিংকের অভাব হলে ফলন কমে যায়।'
  },
  'mustard': {
    name: 'সরিষা (উফশী ও বারি সরিষা)',
    category: 'তেলবীজ',
    perDecimal: { ureaKg: 1.0, tspKg: 0.7, mopKg: 0.35, gypsumKg: 0.65, zincKg: 0.03, organicKg: 4.0 },
    schedule: [
      'জমি তৈরির শেষ চাষে: অর্ধেক ইউরিয়া এবং সমুদয় টিএসপি, এমপি, জিপসাম, জিংক ও বোরন সার প্রয়োগ করুন।',
      'গাছ গজানোর ২০-২৫ দিন পর (ফুল আসার পূর্বে): বাকি অর্ধেক ইউরিয়া সার উপরিপ্রয়োগ করে হালকা সেচ দিন।'
    ],
    tips: 'সরিষায় সালফার বা জিপসাম সার অত্যন্ত জরুরি, এটি সরিষা দানায় তেলের শতকরা পরিমাণ বহুগুণ বাড়ায়।'
  },
  'chili': {
    name: 'মরিচ (কাঁচা ও শুকনা মরিচ)',
    category: 'মশলা ও শাকসবজি',
    perDecimal: { ureaKg: 1.1, tspKg: 0.8, mopKg: 0.7, gypsumKg: 0.45, zincKg: 0.04, organicKg: 6.0 },
    schedule: [
      'জমি তৈরিতে: অর্ধেক গোবর, সমুদয় টিএসপি, জিপসাম ও বোরন দিন।',
      'চারা রোপণের ২৫ দিন, ৫০ দিন এবং ৭৫ দিন পর ইউরিয়া ও পটাশ ৩ কিস্তিতে সমান ভাগে উপরিপ্রয়োগ করুন।'
    ],
    tips: 'মরিচ গাছের গোড়ায় কখনো যেন অতিরিক্ত পানি না জমে। উঁচু বেড তৈরি করে চাষ করা উত্তম।'
  }
};

export const FertilizerCalculator: React.FC = () => {
  const [selectedCrop, setSelectedCrop] = useState<string>('boro_rice');
  const [landUnit, setLandUnit] = useState<'decimal' | 'bigha' | 'acre'>('decimal');
  const [landSize, setLandSize] = useState<string>('১০');

  const crop = CROP_SPECS[selectedCrop] || CROP_SPECS['boro_rice'];

  const getDecimals = (): number => {
    const size = parseFloat(landSize) || 0;
    if (landUnit === 'bigha') return size * 33; // 1 Bigha = 33 Decimal in standard BD
    if (landUnit === 'acre') return size * 100; // 1 Acre = 100 Decimal
    return size; // Decimal / শতক
  };

  const totalDecimals = getDecimals();

  const totalUrea = (crop.perDecimal.ureaKg * totalDecimals).toFixed(1);
  const totalTsp = (crop.perDecimal.tspKg * totalDecimals).toFixed(1);
  const totalMop = (crop.perDecimal.mopKg * totalDecimals).toFixed(1);
  const totalGypsum = (crop.perDecimal.gypsumKg * totalDecimals).toFixed(1);
  const totalZinc = (crop.perDecimal.zincKg * totalDecimals).toFixed(2);
  const totalOrganic = (crop.perDecimal.organicKg * totalDecimals).toFixed(0);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm">
        <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
          ⚖️ সুষম সার ক্যালকুলেটর
        </span>
        <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
          জমির মাপ ও ফসল অনুযায়ী সারের সঠিক ডোজ নির্ধারণ
        </h2>
        <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
          বাংলাদেশ কৃষি গবেষণা কাউন্সিল (BARC) অনুমোদিত সুপারিশ অনুযায়ী সারের পরিমাণ হিসাব করুন
        </p>
      </div>

      {/* Input Form Card */}
      <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-bold text-[#2D3A3A] mb-1.5">
              ফসল নির্বাচন করুন:
            </label>
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="w-full border border-[#D4C3A3] rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] font-medium bg-[#FDFBF7]"
            >
              <option value="boro_rice">বোরো ধান (উচ্চ ফলনশীল)</option>
              <option value="amon_rice">রোপা আমন ধান</option>
              <option value="potato">আলু (গোল আলু)</option>
              <option value="maize">ভুট্টা (হাইব্রিড)</option>
              <option value="mustard">সরিষা (উফশী)</option>
              <option value="chili">মরিচ (কাঁচা/শুকনা)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2D3A3A] mb-1.5">
              পরিমাপের একক:
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setLandUnit('decimal')}
                className={`py-2.5 rounded-2xl text-xs font-bold transition cursor-pointer ${
                  landUnit === 'decimal'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-[#FDFBF7] text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                শতক
              </button>
              <button
                type="button"
                onClick={() => setLandUnit('bigha')}
                className={`py-2.5 rounded-2xl text-xs font-bold transition cursor-pointer ${
                  landUnit === 'bigha'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-[#FDFBF7] text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                বিঘা (৩৩ শতক)
              </button>
              <button
                type="button"
                onClick={() => setLandUnit('acre')}
                className={`py-2.5 rounded-2xl text-xs font-bold transition cursor-pointer ${
                  landUnit === 'acre'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-[#FDFBF7] text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                একর (১০০ শতক)
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2D3A3A] mb-1.5">
              জমির পরিমাণ ({landUnit === 'decimal' ? 'শতকে' : landUnit === 'bigha' ? 'বিঘায়' : 'একরে'}):
            </label>
            <input
              type="number"
              min="0.1"
              step="0.5"
              value={landSize}
              onChange={(e) => setLandSize(e.target.value)}
              placeholder="যেমন: ১০"
              className="w-full border border-[#D4C3A3] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D5A27] bg-[#FDFBF7]"
            />
          </div>
        </div>

        {totalDecimals > 0 && (
          <div className="mt-3.5 text-xs text-[#5A6B6B] bg-[#FDFBF7] p-2.5 rounded-2xl border border-[#E6E0D4] flex items-center gap-2">
            <Scale className="w-4 h-4 text-[#A65E2E]" />
            <span>মোট পরিমাপ: <strong className="text-[#2D3A3A]">{toBanglaNumber(totalDecimals)} শতক জমি</strong></span>
          </div>
        )}
      </div>

      {/* Calculated Dose Cards in Natural Tones */}
      <div>
        <h3 className="text-sm sm:text-base font-bold text-[#2D3A3A] mb-3 flex items-center gap-2">
          <Sprout className="w-4 h-4 text-[#2D5A27]" />
          <span>আপনার {crop.name} ফসলের জন্য প্রয়োজনীয় সারের মোট পরিমাণ:</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
          <div className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-4 text-center shadow-xs">
            <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC] px-2.5 py-0.5 rounded-full">
              ইউরিয়া (Urea)
            </span>
            <p className="text-xl sm:text-2xl font-extrabold text-[#2D5A27] mt-2 font-['Noto_Sans_Bengali']">
              {toBanglaNumber(totalUrea)}
            </p>
            <span className="text-xs text-[#736B5E]">কেজি</span>
          </div>

          <div className="bg-white border border-[#E6E0D4] hover:border-[#2B6CB0] rounded-3xl p-4 text-center shadow-xs">
            <span className="text-[11px] font-bold text-[#2B6CB0] bg-[#D1E5F0] px-2.5 py-0.5 rounded-full">
              টিএসপি / ডিএপি
            </span>
            <p className="text-xl sm:text-2xl font-extrabold text-[#2B6CB0] mt-2 font-['Noto_Sans_Bengali']">
              {toBanglaNumber(totalTsp)}
            </p>
            <span className="text-xs text-[#736B5E]">কেজি</span>
          </div>

          <div className="bg-white border border-[#E6E0D4] hover:border-[#A65E2E] rounded-3xl p-4 text-center shadow-xs">
            <span className="text-[11px] font-bold text-[#A65E2E] bg-[#F9E5D4] px-2.5 py-0.5 rounded-full">
              এমওপি / পটাশ
            </span>
            <p className="text-xl sm:text-2xl font-extrabold text-[#A65E2E] mt-2 font-['Noto_Sans_Bengali']">
              {toBanglaNumber(totalMop)}
            </p>
            <span className="text-xs text-[#736B5E]">কেজি</span>
          </div>

          <div className="bg-white border border-[#E6E0D4] rounded-3xl p-4 text-center shadow-xs">
            <span className="text-[11px] font-bold text-[#736B5E] bg-[#E6E0D4] px-2.5 py-0.5 rounded-full">
              জিপসাম (Gypsum)
            </span>
            <p className="text-xl sm:text-2xl font-extrabold text-[#2D3A3A] mt-2 font-['Noto_Sans_Bengali']">
              {toBanglaNumber(totalGypsum)}
            </p>
            <span className="text-xs text-[#736B5E]">কেজি</span>
          </div>

          <div className="bg-white border border-[#E6E0D4] hover:border-[#8E44AD] rounded-3xl p-4 text-center shadow-xs">
            <span className="text-[11px] font-bold text-[#8E44AD] bg-[#E8DAEF] px-2.5 py-0.5 rounded-full">
              জিংক সালফেট
            </span>
            <p className="text-xl sm:text-2xl font-extrabold text-[#8E44AD] mt-2 font-['Noto_Sans_Bengali']">
              {toBanglaNumber(totalZinc)}
            </p>
            <span className="text-xs text-[#736B5E]">কেজি</span>
          </div>

          <div className="bg-white border border-[#E6E0D4] hover:border-[#239B56] rounded-3xl p-4 text-center shadow-xs">
            <span className="text-[11px] font-bold text-[#239B56] bg-[#D5F5E3] px-2.5 py-0.5 rounded-full">
              জৈব / গোবর
            </span>
            <p className="text-xl sm:text-2xl font-extrabold text-[#239B56] mt-2 font-['Noto_Sans_Bengali']">
              {toBanglaNumber(totalOrganic)}
            </p>
            <span className="text-xs text-[#736B5E]">কেজি</span>
          </div>
        </div>
      </div>

      {/* Application Schedule Guide */}
      <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
        <h4 className="text-sm sm:text-base font-bold text-[#2D3A3A] flex items-center gap-2 font-['Noto_Sans_Bengali']">
          <CheckCircle className="w-5 h-5 text-[#2D5A27]" />
          <span>সার প্রয়োগের সঠিক ধাপ ও সময়সূচী:</span>
        </h4>

        <div className="space-y-2.5">
          {crop.schedule.map((step, idx) => (
            <div key={idx} className="flex items-start gap-3 bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#E6E0D4]">
              <span className="w-6 h-6 rounded-full bg-[#2D5A27] text-white font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5 shadow-2xs">
                {toBanglaNumber(idx + 1)}
              </span>
              <p className="text-xs sm:text-sm text-[#2D3A3A] leading-relaxed font-medium">
                {step}
              </p>
            </div>
          ))}
        </div>

        <div className="p-4 bg-[#F9E5D4]/60 border border-[#F9E5D4] rounded-2xl flex items-start gap-3">
          <Info className="w-4 h-4 text-[#A65E2E] flex-shrink-0 mt-0.5" />
          <div className="text-xs text-[#A65E2E] leading-relaxed">
            <strong>বিশেষ পরামর্শ: </strong>{crop.tips}
          </div>
        </div>
      </div>
    </div>
  );
};
