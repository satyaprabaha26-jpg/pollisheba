import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Mail, 
  Send, 
  Check, 
  FileText, 
  AlertCircle, 
  HeartHandshake, 
  MessageSquareHeart, 
  Lock, 
  UserCheck, 
  AlertTriangle, 
  PhoneOff, 
  Share2, 
  Sparkles,
  HelpCircle,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { UserProfile } from '../../types/auth';

interface TermsAndPolicyPageProps {
  currentUser?: UserProfile | null;
}

export const TermsAndPolicyPage: React.FC<TermsAndPolicyPageProps> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'policy' | 'feedback' | 'faq'>('policy');
  const [lang, setLang] = useState<'bn' | 'en'>('bn');

  // Feedback form state
  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState('পরামর্শ ও মতামত');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  // FAQ Expand state
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message) return;

    // Save citizen feedback locally
    const feedbackList = JSON.parse(localStorage.getItem('polli_citizen_feedbacks') || '[]');
    const newFeedback = {
      id: `fb-${Date.now()}`,
      name: name || currentUser?.name || 'বেনামী নাগরিক',
      phone: currentUser?.phone || '০১৭xxxxxxxx',
      email: email || undefined,
      category: (category.includes('অভিযোগ') ? 'অভিযোগ' : category.includes('পরামর্শ') ? 'পরামর্শ' : 'অন্যান্য') as any,
      message,
      createdAt: new Date().toLocaleDateString('bn-BD'),
      status: 'নতুন' as const
    };

    localStorage.setItem('polli_citizen_feedbacks', JSON.stringify([newFeedback, ...feedbackList]));

    // Construct Mailto for direct communication to admin email
    const subject = encodeURIComponent(`পল্লী সেবা মতামত: ${category} - ${name || currentUser?.name || 'ব্যবহারকারী'}`);
    const body = encodeURIComponent(
      `নাম: ${name || currentUser?.name || 'বেনামী'}\nইমেইল: ${email || 'নাই'}\nবিষয়: ${category}\n\nমতামত/অভিযোগ:\n${message}`
    );

    setIsSubmitted(true);

    try {
      window.location.href = `mailto:polliseba26@gmail.com?subject=${subject}&body=${body}`;
    } catch (e) {}
  };

  const faqs = [
    {
      q: '১. "পল্লী সেবা" কী এবং এটি কীভাবে গ্রামীণ মানুষের উপকার করে?',
      a: 'পল্লী সেবা হলো প্রত্যন্ত পল্লী অঞ্চলের সাধারণ নাগরিক, কৃষক, খামারি ও চালকদের জন্য নির্মিত একটি সমন্বিত সেবা প্ল্যাটফর্ম। এখানে বিনামূল্যে কৃষিপণ্যের কেনাবেচা, সরাসরি পরিবহন চালক ও যাত্রীর নিরাপদ যোগাযোগ, ফসলের রোগবালাই সমাধান, সার পরিমাপক, সরকারি ভাতার নিয়মাবলী, নামাজের সময়সূচি এবং জরুরি রক্তের ডোনার খুঁজে পাওয়া যায়।'
    },
    {
      q: '২. চালক ও যাত্রীর ফোন নম্বর কি সরাসরি দেখা যায়?',
      a: 'না। উভয় পক্ষের নিরাপত্তা ও গোপনীয়তা রক্ষার জন্য কোনো সাধারণ ব্যবহারকারী বা চালক কারো মূল ফোন নম্বর দেখতে পাবেন না। অ্যাপের ভেতরে সুরক্ষিত ইন্টারনেট অডিও কল এবং সুরক্ষিত মেসেজিং সুবিধা দেওয়া হয়েছে।'
    },
    {
      q: '৩. কৃষিপণ্যের বিজ্ঞাপন কতদিন পর স্বয়ংক্রিয়ভাবে হাইড হয়ে যায়?',
      a: 'শাকসবজি ও পচনশীল পণ্যের ক্ষেত্রে ২-৩ দিন, সাধারণ কাঁচাবাজারের ক্ষেত্রে ৫-৭ দিন এবং আলু বা দানাদার শস্যের ক্ষেত্রে ১৫-৩০ দিন পর বিজ্ঞাপন স্বয়ংক্রিয়ভাবে আর্কাইভ/হাইড হয়ে যায়। এতে প্ল্যাটফর্মে সবসময় কেবল টাটকা ও সতেজ পণ্যের তথ্য থাকে।'
    },
    {
      q: '৪. অ্যাপে কোনো পণ্য ক্রয়-বিক্রয়ে কি ফি বা কমিশন দিতে হয়?',
      a: 'সম্পূর্ণ বিনামূল্যে! কোনো প্রকার কমিশন, সাবস্ক্রিপশন বা মধ্যস্বত্বভোগী ফি নেই।'
    },
    {
      q: '৫. কোনো চালক বা বিক্রেতা অসংগত আচরণ করলে কী করব?',
      a: 'প্রতিটি চালক প্রোফাইল ও পণ্য বিজ্ঞাপনের সাথে "রিপোর্ট / অসংগতি জানান" লাল বাটন রয়েছে। আপনি সেখানে সুনির্দিষ্ট কারণ লিখে পাঠালে অ্যাডমিন টিম দ্রুত ব্যবস্থা গ্রহণ করে এবং ভুয়া প্রোফাইল ব্লক করে।'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 font-['Noto_Sans_Bengali'] space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-[#E6E0D4] shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E6E0D4] pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center shadow-xs">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-[#2D3A3A]">
                শর্তাবলী, দায়মুক্তি ও প্রাইভেসী নীতিমালা
              </h2>
              <p className="text-xs text-[#736B5E]">
                নিরাপদ ও জনবান্ধব সেবা পরিচালনায় পল্লী সেবার নিয়মকানুন
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('policy')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeTab === 'policy' ? 'bg-[#2D5A27] text-white' : 'bg-[#FAF8F5] text-[#5A6B6B] border border-[#E6E0D4]'
              }`}
            >
              📜 নীতিমালা
            </button>
            <button
              onClick={() => setActiveTab('faq')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeTab === 'faq' ? 'bg-[#2D5A27] text-white' : 'bg-[#FAF8F5] text-[#5A6B6B] border border-[#E6E0D4]'
              }`}
            >
              ❓ সাধারণ জিজ্ঞাসা
            </button>
            <button
              onClick={() => setActiveTab('feedback')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeTab === 'feedback' ? 'bg-[#E8924A] text-white' : 'bg-[#FAF8F5] text-[#5A6B6B] border border-[#E6E0D4]'
              }`}
            >
              ✉️ উদ্যোক্তাকে বার্তা
            </button>
          </div>
        </div>

        {/* TAB 1: POLICY */}
        {activeTab === 'policy' && (
          <div className="space-y-4 text-xs sm:text-sm text-[#2D3A3A] leading-relaxed">
            
            {/* Language Switch */}
            <div className="flex justify-end">
              <div className="bg-[#FAF8F5] p-0.5 rounded-xl border border-[#D4C3A3] flex items-center gap-1">
                <button
                  onClick={() => setLang('bn')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                    lang === 'bn' ? 'bg-[#2D5A27] text-white' : 'text-[#5A6B6B]'
                  }`}
                >
                  বাংলা
                </button>
                <button
                  onClick={() => setLang('en')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                    lang === 'en' ? 'bg-[#2D5A27] text-white' : 'text-[#5A6B6B]'
                  }`}
                >
                  English
                </button>
              </div>
            </div>

            {lang === 'bn' ? (
              <div className="space-y-4">
                {/* ১. সেবার ধরন ও উদ্দেশ্য */}
                <div className="bg-[#D4E4BC]/30 border border-[#D4E4BC] p-4 sm:p-5 rounded-2xl">
                  <h4 className="font-bold text-[#2D5A27] text-sm sm:text-base mb-2 flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-[#2D5A27]" />
                    <span>১. সেবার ধরন ও উদ্দেশ্য</span>
                  </h4>
                  <p className="text-[#3E4D4D] text-xs sm:text-sm leading-relaxed">
                    "পল্লী সেবা" একটি স্বাধীন, অলাভজনক এবং তথ্যপ্রযুক্তিভিত্তিক ডিজিটাল প্ল্যাটফর্ম। এই অ্যাপের প্রধান উদ্দেশ্য হলো গ্রামীণ নাগরিক, কৃষক, শ্রমিক, চালক, কারিগর ও সেবাগ্রহীতাদের মধ্যে পারস্পরিক যোগাযোগের তথ্যগত সংযোগ ঘটানো। <strong>অ্যাপ কর্তৃপক্ষ নিজে কোনো পণ্য কেনাবেচা করে না, কোনো যানবাহনের মালিক নয় এবং কোনো প্রকার নিয়োগকর্তা বা আর্থিক লেনদেনকারী প্রতিষ্ঠান নয়।</strong>
                  </p>
                </div>

                {/* ২. পরিচয় সুরক্ষা ও গোপনীয়তা */}
                <div className="bg-[#FAF8F5] p-4 sm:p-5 rounded-2xl border border-[#E6E0D4] space-y-2">
                  <h4 className="font-bold text-[#2D5A27] flex items-center gap-2 text-sm sm:text-base">
                    <Lock className="w-4 h-4 text-[#E8924A]" />
                    <span>২. পরিচয় সুরক্ষা ও গোপনীয়তা</span>
                  </h4>
                  <ul className="space-y-1.5 text-xs sm:text-sm text-[#3E4D4D] list-disc list-inside">
                    <li>ব্যবহারকারীর মোবাইল নম্বর সুরক্ষিত রাখতে এবং অনাকাঙ্ক্ষিত কল এড়াতে অ্যাপের অভ্যন্তরে সুরক্ষিত কল (Masked Call) প্রযুক্তি ব্যবহারের সুবিধা রাখা হয়েছে।</li>
                    <li>ব্যবহারকারীর ব্যক্তিগত তথ্য কোনো বাণিজ্যিক বিজ্ঞাপনী প্রতিষ্ঠানের কাছে বিক্রি বা বিনিময় করা হয় না।</li>
                    <li>নিবন্ধনের জন্য ব্যবহৃত ওটিপি (OTP) ভেরিফাইড ডেটা আমাদের কেন্দ্রীয় ডেটাবেজে সম্পূর্ণ সুরক্ষিত রাখা হয়।</li>
                  </ul>
                </div>

                {/* ৩. সম্পূর্ণ দায়মুক্তি (Absolute Disclaimer) */}
                <div className="bg-[#FAF8F5] p-4 sm:p-5 rounded-2xl border border-[#E6E0D4] space-y-3">
                  <div className="flex items-center gap-2 border-b border-[#E6E0D4] pb-2">
                    <AlertTriangle className="w-5 h-5 text-[#C0392B]" />
                    <h4 className="font-bold text-[#C0392B] text-sm sm:text-base">
                      ৩. সম্পূর্ণ দায়মুক্তি (Absolute Disclaimer)
                    </h4>
                  </div>

                  <ul className="space-y-3 text-xs sm:text-sm text-[#3E4D4D]">
                    <li className="flex items-start gap-2">
                      <span className="text-[#C0392B] font-bold text-base leading-none mt-0.5">•</span>
                      <div>
                        <strong>পণ্য কেনাবেচা (পল্লী হাট ও বাজারদর):</strong> পণ্যের সঠিক মান, সতেজতা, ওজন এবং টাকা লেনদেনের সম্পূর্ণ দায়িত্ব ক্রেতা ও বিক্রেতার। কোনো প্রকার অগ্রিম টাকা দেওয়ার আগে সরজমিনে পণ্য দেখে নেওয়ার অনুরোধ করা হচ্ছে। অ্যাপে প্রদর্শিত দৈনিক কৃষি বাজারদর কেবল ধারণামূলক তথ্য।
                      </div>
                    </li>

                    <li className="flex items-start gap-2">
                      <span className="text-[#C0392B] font-bold text-base leading-none mt-0.5">•</span>
                      <div>
                        <strong>শ্রমিক ও কৃষাণ নিয়োগ:</strong> "শ্রমিকদের গায়ের ঘাম শুকানোর আগেই তাদের মজুরি পরিশোধ করার চেষ্টা করুন।" (সুনানে ইবনে মাজাহ: ২৪৪৩)। তবে কোনো শ্রমিকের বকেয়া মজুরি আদায় বা শ্রম বিরোধ মীমাংসায় অ্যাপ কর্তৃপক্ষ আইনত বাধ্য নয়। যেকোনো শ্রম বিরোধে সরকারি জাতীয় শ্রম হেল্পলাইন <strong>১৬১৯৯</strong> (16199) এ যোগাযোগ করুন।
                      </div>
                    </li>

                    <li className="flex items-start gap-2">
                      <span className="text-[#C0392B] font-bold text-base leading-none mt-0.5">•</span>
                      <div>
                        <strong>পরিবহন যাত্রা, নিরাপত্তা ও লাইভ ট্র্যাকিং:</strong> পরিবহন সেবা বা যাত্রা চলাকালীন কোনো দুর্ঘটনা, মালামাল হারানো বা আর্থিক ক্ষতির দায় অ্যাপ কর্তৃপক্ষ বহন করবে না। যাত্রীর সুরক্ষায় অ্যাপে ব্যবহৃত লাইভ ট্র্যাকিং লিঙ্কটি যাত্রা সম্পন্ন হওয়ার সাথে সাথে স্বয়ংক্রিয়ভাবে নিষ্ক্রিয় হয়ে যাবে।
                      </div>
                    </li>

                    <li className="flex items-start gap-2">
                      <span className="text-[#C0392B] font-bold text-base leading-none mt-0.5">•</span>
                      <div>
                        <strong>স্বাস্থ্য ও চিকিৎসা গাইড (হাসপাতাল, ডাক্তার, টিকা ও ফার্স্ট এইড):</strong> অ্যাপে প্রদর্শিত হাসপাতাল তথ্য, ডাক্তারদের চেম্বার, ইপিআই টিকাদান শিডিউল ও জরুরি প্রাথমিক চিকিৎসা (ফার্স্ট এইড) কেবল সাধারণ নাগরিক সচেতনতার জন্য। "পল্লী সেবা" কোনো সরাসরি চিকিৎসা প্রদানকারী প্রতিষ্ঠান নয়। জরুরি চিকিৎসায় তাৎক্ষণিক নিকটস্থ হাসপাতালে যোগাযোগের অনুরোধ করা হচ্ছে।
                      </div>
                    </li>

                    <li className="flex items-start gap-2">
                      <span className="text-[#C0392B] font-bold text-base leading-none mt-0.5">•</span>
                      <div>
                        <strong>আইন, সরকারি লিগ্যাল এইড ও থানা/কোর্ট গাইড:</strong> অ্যাপে প্রদর্শিত সরকারি লিগ্যাল এইড (Legal Aid), নির্বাহী ম্যাজিস্ট্রেট কোর্ট ও জজ কোর্ট সংক্রান্ত তথ্য নির্দেশিকামূলক। অ্যাপ কর্তৃপক্ষ কোনো আইনি ফার্ম নয়। যেকোনো দেওয়ানি বা ফৌজদারি মামলায় সরাসরি জেলা জজ কোর্টের সরকারি লিগ্যাল এইড অফিস (হটলাইন: <strong>১৬৪৩০</strong>) বা নিবন্ধিত আইনজীবীর পরামর্শ নিন।
                      </div>
                    </li>

                    <li className="flex items-start gap-2">
                      <span className="text-[#C0392B] font-bold text-base leading-none mt-0.5">•</span>
                      <div>
                        <strong>মিস্ত্রি, কারিগর ও গৃহশিক্ষক (টিউটর):</strong> কাজ দেওয়া বা নেওয়ার পূর্বে সংশ্লিষ্ট মিস্ত্রি বা টিউটরের পরিচয় ও কাজের দক্ষতা নিজ দায়িত্বে যাচাই করে নিন। ব্যক্তিগত কোনো অঘটন বা আর্থিক ক্ষতির দায় অ্যাপ বহন করবে না।
                      </div>
                    </li>

                    <li className="flex items-start gap-2">
                      <span className="text-[#C0392B] font-bold text-base leading-none mt-0.5">•</span>
                      <div>
                        <strong>কৃষি পরামর্শ, ক্যালকুলেটর ও কিস্তি হিসাব (সার, জমি ও ঋণ):</strong> সার ক্যালকুলেটর, আমিন ক্যালকুলেটর বা কৃষি ঋণ হিসাবকের তথ্যগুলো সাধারণ গাণিতিক ফলাফলের ওপর ভিত্তি করে তৈরি। চূড়ান্ত সিদ্ধান্ত নেওয়ার পূর্বে অনুমোদিত উপজেলা কৃষি অফিসার, স্থানীয় আমিন (সার্ভেয়ার) বা সংশ্লিষ্ট ব্যাংক কর্মকর্তার পরামর্শ নিন।
                      </div>
                    </li>

                    <li className="flex items-start gap-2">
                      <span className="text-[#C0392B] font-bold text-base leading-none mt-0.5">•</span>
                      <div>
                        <strong>এআই পল্লী পরামর্শক (AI Assistant):</strong> কৃত্রিম বুদ্ধিমত্তা থেকে প্রাপ্ত উত্তরগুলো প্রযুক্তিভিত্তিক। প্রাপ্ত পরামর্শের বাস্তবিক ব্যবহারের পূর্বে ব্যবহারকারীর নিজ দায়িত্বে এর সত্যতা যাচাই করা উচিত।
                      </div>
                    </li>

                    <li className="flex items-start gap-2">
                      <span className="text-[#C0392B] font-bold text-base leading-none mt-0.5">•</span>
                      <div>
                        <strong>আইনি বাধ্যবাধকতা ও ডাটা শেয়ারিং:</strong> অ্যাপে কোনো ফৌজদারি অপরাধ সংঘটিত হলে বা আইনি বাধ্যবাধকতায় কেবল আইন প্রয়োগকারী সংস্থার লিখিত আবেদনের প্রেক্ষিতে সার্ভার লগ ও নিবন্ধিত তথ্য প্রদান করা হবে।
                      </div>
                    </li>
                  </ul>
                </div>

                {/* ৪. অ্যাকাউন্ট বাতিল করার অধিকার */}
                <div className="bg-[#FAF8F5] p-4 sm:p-5 rounded-2xl border border-[#E6E0D4] space-y-1.5">
                  <h4 className="font-bold text-[#2D5A27] flex items-center gap-2 text-sm sm:text-base">
                    <UserCheck className="w-4 h-4 text-[#E8924A]" />
                    <span>৪. অ্যাকাউন্ট বাতিল করার অধিকার</span>
                  </h4>
                  <p className="text-[#3E4D4D] text-xs sm:text-sm">
                    কোনো ব্যবহারকারী ভুয়া ফোন নম্বর, ভুল তথ্য, অশালীন আচরণ বা বিভ্রান্তিকর বিজ্ঞপ্তি পোস্ট করলে অ্যাপ কর্তৃপক্ষ পূর্বসংকেত ছাড়াই তার অ্যাকাউন্ট বাতিল বা পোস্ট মুছে ফেলার পূর্ণ অধিকার রাখে।
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* 1. Nature & Scope */}
                <div className="bg-[#D4E4BC]/30 border border-[#D4E4BC] p-4 sm:p-5 rounded-2xl">
                  <h4 className="font-bold text-[#2D5A27] text-sm sm:text-base mb-1.5">
                    1. Nature & Purpose of Service
                  </h4>
                  <p className="text-[#3E4D4D] text-xs sm:text-sm">
                    "Polli Sheba" is an independent, non-profit, and information-technology-based digital platform. Its primary mission is to create an informational communication bridge between rural citizens, farmers, laborers, drivers, artisans, and service seekers. <strong>The app authority does not buy or sell goods, does not own vehicles, and is neither an employer nor a financial transaction entity.</strong>
                  </p>
                </div>

                {/* 2. Identity & Privacy */}
                <div className="bg-[#FAF8F5] p-4 sm:p-5 rounded-2xl border border-[#E6E0D4] space-y-1.5">
                  <h4 className="font-bold text-[#2D5A27] text-sm sm:text-base">
                    2. Identity Protection & Privacy
                  </h4>
                  <ul className="space-y-1 text-xs sm:text-sm text-[#3E4D4D] list-disc list-inside">
                    <li>Masked call technology is provided inside the app to protect user phone numbers and avoid unsolicited calls.</li>
                    <li>User personal data is never sold or shared with any commercial advertising companies.</li>
                    <li>OTP-verified registration credentials are fully encrypted and secured in our central database.</li>
                  </ul>
                </div>

                {/* 3. Absolute Disclaimer */}
                <div className="bg-[#FAF8F5] p-4 sm:p-5 rounded-2xl border border-[#E6E0D4] space-y-2.5">
                  <h4 className="font-bold text-[#C0392B] text-sm sm:text-base border-b border-[#E6E0D4] pb-2">
                    3. Absolute Disclaimer of Liability
                  </h4>
                  <ul className="space-y-2 text-xs sm:text-sm text-[#3E4D4D] list-disc list-inside">
                    <li><strong>Marketplace & Daily Prices:</strong> Quality, freshness, weight, and payments are entirely the responsibility of buyers and sellers. Always inspect items in person before making any advance payments. Daily market rates are advisory.</li>
                    <li><strong>Labor & Harvester Hiring:</strong> "Give the worker his wages before his sweat dries." (Sunan Ibn Majah: 2443). The platform bears no legal obligation for wage recovery or labor dispute arbitration. For labor disputes, contact the National Labor Helpline at <strong>16199</strong>.</li>
                    <li><strong>Transport & Live Tracking:</strong> The platform bears no liability for accidents, transit loss, or financial damages. Temporary live tracking links automatically deactivate once a journey ends.</li>
                    <li><strong>Health & Medical Guide:</strong> Hospital directories, doctors' chambers, vaccination routines, and emergency first aid are for general citizen awareness. Polli Sheba is not a healthcare provider. In critical situations, visit the nearest hospital immediately.</li>
                    <li><strong>Legal, Legal Aid & Court Guide:</strong> Information regarding Government Legal Aid (16430), Executive Magistrate Courts, and District Judge Courts is strictly instructional. The app is not a law firm. Consult the District Judge Court Legal Aid office (16430) or a certified advocate for litigation.</li>
                    <li><strong>Mechanics, Technicians & Home Tutors:</strong> Verify background, certifications, and skills before hiring. The platform accepts no liability for personal disputes or property loss.</li>
                    <li><strong>Agri Advisory & Calculators:</strong> Fertilizer, land measurement (Amin), and agri-loan calculators generate approximate mathematical outputs. For critical matters, seek official guidance from Upazila Agriculture Officers, certified Amins, or bank officials.</li>
                    <li><strong>AI Polli Advisor:</strong> Artificial Intelligence responses are algorithmically generated. Users must independently verify advice prior to real-world application.</li>
                    <li><strong>Legal Mandates & Data Sharing:</strong> Server logs and registered numbers are disclosed only upon official written request from authorized law enforcement agencies.</li>
                  </ul>
                </div>

                {/* 4. Right to Terminate */}
                <div className="bg-[#FAF8F5] p-4 sm:p-5 rounded-2xl border border-[#E6E0D4] space-y-1.5">
                  <h4 className="font-bold text-[#2D5A27] text-sm sm:text-base">
                    4. Right to Terminate Accounts
                  </h4>
                  <p className="text-[#3E4D4D] text-xs sm:text-sm">
                    The app authority reserves the unconditional right to suspend accounts or remove listings without prior notice if fraudulent numbers, false statements, abusive behavior, or deceptive ads are detected.
                  </p>
                </div>
              </div>
            )}

            {/* ADMIN CONTACT BOX (STYLIZED WITH ANIMATED PULSING GLOW EMAIL) */}
            <div className="bg-[#FAF8F5] border-2 border-[#15803D]/40 p-5 rounded-3xl space-y-3 mt-6 shadow-2xs">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2 text-[#2D5A27]">
                  <Mail className="w-5 h-5 text-[#15803D]" />
                  <h4 className="font-bold text-sm sm:text-base">অফিসিয়াল ইমেইল সাপোর্ট ও অ্যাডমিন যোগাযোগ</h4>
                </div>
              </div>
              <p className="text-xs text-[#5A6B6B] leading-relaxed">
                তথ্য সংশোধন, নতুন ইউনিয়ন বা উপজেলা সংযোজন এবং যেকোনো সহায়তার জন্য সরাসরি নিচের অফিসিয়াল ইমেইলে যোগাযোগ করুন:
              </p>
              <div className="bg-white p-4 rounded-2xl border border-[#E6E0D4] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-[#15803D] text-white flex items-center justify-center font-bold shadow-2xs shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-[#736B5E] block font-medium">অফিসিয়াল ইমেইল সাপোর্ট</span>
                    <a 
                      href="mailto:polliseba26@gmail.com" 
                      className="inline-flex items-center gap-2 bg-gradient-to-r from-[#15803D] via-[#22C55E] to-[#15803D] text-white px-4 py-2 rounded-xl font-bold text-xs sm:text-sm shadow-md transition cursor-pointer border-2 border-emerald-300 animate-pulse mt-1 tracking-wide"
                      title="অ্যাডমিনকে ইমেইল পাঠান"
                    >
                      <Mail className="w-4 h-4 text-white" />
                      <span>polliseba26@gmail.com</span>
                    </a>
                  </div>
                </div>

                <button
                  onClick={() => setActiveTab('feedback')}
                  className="px-4 py-2 bg-[#E8924A] hover:bg-[#D97D35] text-white rounded-xl text-xs font-bold cursor-pointer self-start sm:self-auto shadow-2xs"
                >
                  ✉️ মতামত ফর্ম পূরণ করুন
                </button>
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: FAQ */}
        {activeTab === 'faq' && (
          <div className="space-y-3 pt-2">
            {faqs.map((faq, index) => {
              const isExp = expandedFaq === index;
              return (
                <div
                  key={index}
                  className="bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] overflow-hidden transition"
                >
                  <button
                    onClick={() => setExpandedFaq(isExp ? null : index)}
                    className="w-full p-4 text-left flex items-center justify-between gap-3 cursor-pointer hover:bg-[#F9E5D4]/30"
                  >
                    <span className="font-bold text-xs sm:text-sm text-[#2D3A3A]">{faq.q}</span>
                    {isExp ? <ChevronUp className="w-4 h-4 text-[#2D5A27]" /> : <ChevronDown className="w-4 h-4 text-[#736B5E]" />}
                  </button>

                  {isExp && (
                    <div className="px-4 pb-4 pt-1 text-xs sm:text-sm text-[#5A6B6B] leading-relaxed border-t border-[#E6E0D4]/60 bg-white/60">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 3: FEEDBACK FORM */}
        {activeTab === 'feedback' && (
          <div className="pt-2">
            {isSubmitted ? (
              <div className="text-center py-10 space-y-3 bg-[#FAF8F5] rounded-3xl p-6 border border-[#D4C3A3]">
                <div className="w-16 h-16 bg-[#D4E4BC] text-[#2D5A27] rounded-full flex items-center justify-center mx-auto shadow-xs">
                  <Check className="w-8 h-8" />
                </div>
                <h3 className="font-bold text-lg text-[#2D3A3A]">
                  আপনার বার্তা সফলভাবে গ্রহণ করা হয়েছে!
                </h3>
                <p className="text-xs text-[#736B5E] max-w-md mx-auto">
                  আপনার মতামত পল্লী সেবার কেন্দ্রীয় তথ্যভাণ্ডারে সংরক্ষিত হয়েছে এবং উদ্যোক্তার ইমেইলে প্রেরণ করা হয়েছে। পল্লী সেবার সাথে থাকার জন্য আন্তরিক ধন্যবাদ।
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => {
                      setIsSubmitted(false);
                      setMessage('');
                    }}
                    className="px-6 py-2 bg-[#2D5A27] text-white rounded-xl text-xs font-bold cursor-pointer"
                  >
                    আরেকটি বার্তা পাঠান
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="bg-[#F9E5D4]/40 border border-[#F9E5D4] p-3.5 rounded-2xl text-xs text-[#A65E2E]">
                  💡 <strong>উদ্যোক্তার প্রতি বার্তা:</strong> অ্যাপ সম্পর্কিত কোনো মতামত, ত্রুটি সংশোধন বা আপনার এলাকার সেবামূলক তথ্য যুক্ত করার প্রস্তাব থাকলে নিচে লিখে পাঠান।
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-[#2D3A3A] mb-1">আপনার নাম</label>
                    <input
                      type="text"
                      placeholder="যেমন: মো: কামরুল হাসান"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2 text-xs font-semibold text-[#2D3A3A] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#2D3A3A] mb-1">ইমেইল ঠিকানা (ঐচ্ছিক)</label>
                    <input
                      type="email"
                      placeholder="example@mail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2 text-xs font-semibold text-[#2D3A3A] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1">বার্তার বিষয়</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2 text-xs font-semibold text-[#2D3A3A] focus:outline-none"
                  >
                    <option value="পরামর্শ ও মতামত">পরামর্শ ও মতামত</option>
                    <option value="নতুন তথ্য বা এলাকা সংযোজন">নতুন তথ্য বা এলাকা সংযোজন</option>
                    <option value="অভিযোগ বা ত্রুটি">অভিযোগ বা ত্রুটি</option>
                    <option value="অন্যান্য">অন্যান্য</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                    আপনার বিস্তারিত বার্তা <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="আপনার মতামত, পরামর্শ বা যেকোনো প্রস্তাব বিস্তারিত লিখুন..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-2xl p-3.5 text-xs text-[#2D3A3A] focus:outline-none"
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#E8924A] hover:bg-[#D97D35] shadow-xs cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>ইমেইল পাঠান</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
