import React, { useState } from 'react';
import { 
  Scale, 
  Shield, 
  Gavel, 
  Building2, 
  PhoneCall, 
  FileText, 
  HelpCircle, 
  CheckCircle2, 
  AlertTriangle, 
  Users, 
  ExternalLink,
  ChevronRight,
  Sparkles,
  Info,
  MapPin,
  Clock,
  Landmark,
  BadgeAlert,
  Search
} from 'lucide-react';
import { Prominent999Banner } from '../common/Prominent999Banner';

interface LegalAidAndPoliceProps {
  currentDistrict?: string;
}

export const LegalAidAndPolice: React.FC<LegalAidAndPoliceProps> = ({
  currentDistrict = 'সকল জেলা'
}) => {
  const [activeTab, setActiveTab] = useState<'legalaid' | 'executive' | 'judge' | 'police' | 'village_court' | 'court_selector'>('legalaid');
  const [selectedDisputeType, setSelectedDisputeType] = useState<string>('');

  // Interactive Court Finder options
  const disputeOptions = [
    {
      id: 'no_money',
      title: 'টাকা নেই বলে মামলা লড়তে পারছেন না',
      sub: 'অসচ্ছল, দরিদ্র বা নির্যাতিত নাগরিক',
      court: 'সরকারি লিগ্যাল এইড (Legal Aid)',
      destination: 'জেলা জজ কোর্ট লিগ্যাল এইড অফিস অথবা জাতীয় হেল্পলাইন ১৬৪৩০',
      badge: 'সম্পূর্ণ বিনামূল্যে উকিল ও খরচ',
      tabKey: 'legalaid' as const
    },
    {
      id: 'land_grab_144',
      title: 'জমি দখল প্রতিরোধ / এলাকার শান্তি-শৃঙ্খলা রক্ষা / ১৪৪ ধারা',
      sub: 'তাৎক্ষণিক মারামারির আশঙ্কা বা দখল উচ্ছেদ',
      court: 'নির্বাহী আদালত (Executive Court)',
      destination: 'উপজেলা নির্বাহী অফিসার (UNO) বা অতিরিক্ত জেলা ম্যাজিস্ট্রেট (ADM)',
      badge: 'শান্তি রক্ষা আদেশ ও মোবাইল কোর্ট',
      tabKey: 'executive' as const
    },
    {
      id: 'land_ownership',
      title: 'জমির স্থায়ী স্বত্ব, দলিল বাতিল বা বণ্টন ও মালিকানা সংক্রান্ত মামলা',
      sub: 'দেওয়ানি প্রকৃতির দীর্ঘস্থায়ী বিরোধ',
      court: 'দেওয়ানি বিচারিক আদালত (Civil Judge Court)',
      destination: 'জেলা সদর সিনিয়র সহকারী জজ বা যুগ্ম জেলা জজ আদালত',
      badge: 'স্থায়ী স্বত্ব ঘোষণা ও ডিক্রি',
      tabKey: 'judge' as const
    },
    {
      id: 'criminal_offense',
      title: 'চুরি, ডাকাতি, গুরুতর মারামারি বা ফৌজদারি অপরাধ',
      sub: 'থানায় মামলা বা আদালতে সিআর মামলা',
      court: 'থানা ও জুডিশিয়াল ম্যাজিস্ট্রেট আদালত',
      destination: 'নিকটস্থ থানা (ডিউটি অফিসার / OC) অথবা চিফ জুডিশিয়াল ম্যাজিস্ট্রেট কোর্ট',
      badge: 'জিডি, এজাহার ও বিচারিক ট্রায়াল',
      tabKey: 'police' as const
    },
    {
      id: 'village_petty',
      title: 'গ্রামের ছোটখাটো মারামারি, হাঁস-মুরগি, সীমানা বা ৩ লক্ষ টাকা পর্যন্ত পাওনা বিরোধ',
      sub: 'সামাজিক আপোষ ও স্থানীয় সমাধান',
      court: 'ইউনিয়ন পরিষদ গ্রাম আদালত (Village Court)',
      destination: 'স্থানীয় ইউনিয়ন পরিষদ ভবন (চেয়ারম্যান ও ইউপি সচিব)',
      badge: 'মাত্র ১০-২০ টাকা ফি, উকিল মুক্ত',
      tabKey: 'village_court' as const
    }
  ];

  return (
    <div className="space-y-6 font-['Noto_Sans_Bengali']">
      
      {/* Top Banner */}
      <div className="bg-[#1B365D] text-white p-6 rounded-3xl shadow-sm space-y-3 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="bg-[#D4E4BC] text-[#1B365D] font-extrabold text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-xs">
                <Scale className="w-3.5 h-3.5" />
                <span>আইন, আদালত ও সরকারি সাহায্য</span>
              </span>
              <span className="text-xs text-blue-200 bg-white/10 px-2.5 py-0.5 rounded-full">
                দালালমুক্ত আইনি পরামর্শ ও দিকনির্দেশনা
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali'] leading-snug">
              নাগরিক আইনি সহায়তা ও আদালত নির্দেশিকা
            </h2>
            <p className="text-blue-100 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
              টাকা নেই বলে বিচার পাবেন না তা নয়। সরকারি লিগ্যাল এইড, নির্বাহী আদালত, জজ কোর্ট ও পুলিশের সাধারণ ডায়েরি (GD) সংক্রান্ত পূর্ণ তথ্য জানুন।
            </p>
          </div>

          <div className="flex sm:flex-col items-center sm:items-end gap-2 shrink-0">
            <a
              href="tel:16430"
              className="bg-[#2D5A27] hover:bg-[#23491E] text-white px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 shadow-sm transition cursor-pointer border border-[#D4E4BC]/30"
              title="লিগ্যাল এইড কল করুন"
            >
              <PhoneCall className="w-4 h-4 text-[#D4E4BC]" />
              <span>লিগ্যাল এইড: ১৬৪৩০</span>
            </a>
            <span className="text-[11px] text-blue-200">সরকারি টোল-ফ্রি জাতীয় সেবা</span>
          </div>
        </div>
      </div>

      {/* Prominent Stylized 999 Emergency Banner */}
      <Prominent999Banner />

      {/* Interactive Quick Court Selector Card */}
      <div className="bg-white border-2 border-[#1B365D]/20 rounded-3xl p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#E8924A]" />
            <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A]">
              আপনার সমস্যাটি কোন আদালতে প্রযোজ্য? (কোর্ট নির্দেশক)
            </h3>
          </div>
          <span className="text-xs text-[#736B5E]">নিচের যেকোনো সমস্যায় ক্লিক করে সঠিক নিয়ম দেখুন</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-1">
          {disputeOptions.map((opt) => (
            <div
              key={opt.id}
              onClick={() => {
                setSelectedDisputeType(opt.id);
                setActiveTab(opt.tabKey);
              }}
              className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                selectedDisputeType === opt.id 
                  ? 'bg-[#1B365D] text-white border-[#1B365D] shadow-md scale-101'
                  : 'bg-[#FDFBF7] hover:bg-[#F9E5D4]/40 border-[#E6E0D4] hover:border-[#1B365D] text-[#2D3A3A]'
              }`}
            >
              <div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full inline-block mb-1.5 ${
                  selectedDisputeType === opt.id 
                    ? 'bg-[#D4E4BC] text-[#1B365D]' 
                    : 'bg-[#E6E0D4] text-[#2D3A3A]'
                }`}>
                  {opt.badge}
                </span>
                <h4 className="font-bold text-xs sm:text-sm leading-snug">
                  {opt.title}
                </h4>
                <p className={`text-[11px] mt-1 line-clamp-2 ${
                  selectedDisputeType === opt.id ? 'text-blue-100' : 'text-[#736B5E]'
                }`}>
                  {opt.sub}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-current/15 flex items-center justify-between text-[11px] font-bold">
                <span>{opt.court}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex gap-2 border-b border-[#E6E0D4] pb-2 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('legalaid')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'legalaid'
              ? 'bg-[#2D5A27] text-white shadow-xs'
              : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
          }`}
        >
          <Scale className="w-4 h-4" />
          <span>১. সরকারি আইনি সহায়তা (১৬৪৩০)</span>
        </button>

        <button
          onClick={() => setActiveTab('executive')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'executive'
              ? 'bg-[#2D5A27] text-white shadow-xs'
              : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
          }`}
        >
          <Landmark className="w-4 h-4" />
          <span>২. নির্বাহী আদালত (ম্যাজিস্ট্রেট কোর্ট)</span>
        </button>

        <button
          onClick={() => setActiveTab('judge')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'judge'
              ? 'bg-[#2D5A27] text-white shadow-xs'
              : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
          }`}
        >
          <Gavel className="w-4 h-4" />
          <span>৩. জজ কোর্ট (বিচারিক আদালত)</span>
        </button>

        <button
          onClick={() => setActiveTab('police')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'police'
              ? 'bg-[#C0392B] text-white shadow-xs'
              : 'bg-white text-[#2D3A3A] hover:bg-[#FADBD8]/40 border border-[#E6E0D4]'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>৪. জরুরি পুলিশ ও জিডি গাইড (৯৯৯)</span>
        </button>

        <button
          onClick={() => setActiveTab('village_court')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'village_court'
              ? 'bg-[#2D5A27] text-white shadow-xs'
              : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>৫. ইউনিয়ন পরিষদ গ্রাম আদালত</span>
        </button>
      </div>

      {/* TAB 1: সরকারি আইনি সহায়তা (LEGAL AID) */}
      {activeTab === 'legalaid' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          
          {/* Main Hero Callout requested by user */}
          <div className="bg-gradient-to-r from-[#2D5A27] to-[#1E3F1A] text-white p-6 rounded-3xl shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-extrabold text-sm">
                ✓
              </span>
              <span className="text-xs font-bold bg-white/20 text-white px-3 py-0.5 rounded-full">
                আইন ও বিচার বিভাগ • বাংলাদেশ সরকার
              </span>
            </div>

            <div className="space-y-2">
              <h3 className="text-xl sm:text-2xl font-black font-['Noto_Sans_Bengali'] text-amber-200 leading-snug">
                "টাকা নেই বলে মামলা লড়তে পারছেন না? জেলা জজ কোর্টে সরকার সম্পূর্ণ বিনামূল্যে উকিল ও আইনি খরচ বহন করে।"
              </h3>
              <p className="text-xs sm:text-sm text-[#D4E4BC] max-w-2xl leading-relaxed">
                জাতীয় আইনগত সহায়তা প্রদান সংস্থা (National Legal Aid Services Organization) এর অধীনে প্রতিটি জেলায় জেলা জজ আদালতে একজন সিনিয়র সহকারী জজ লিগ্যাল এইড অফিসার হিসেবে নিয়োজিত থাকেন।
              </p>
            </div>

            {/* Helpline Call CTA */}
            <div className="bg-white/10 border border-white/20 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-white text-[#2D5A27] font-black text-xl flex items-center justify-center font-['Noto_Sans_Bengali'] shadow-xs shrink-0">
                  ১৬৪৩০
                </div>
                <div>
                  <h4 className="font-bold text-sm sm:text-base text-white">
                    জাতীয় লিগ্যাল এইড টোল-ফ্রি হেল্পলাইন
                  </h4>
                  <p className="text-xs text-amber-200">
                    যেকোনো মোবাইল থেকে ফ্রিতে সরাসরি কল করে আইনি পরামর্শ নিন
                  </p>
                </div>
              </div>

              <a
                href="tel:16430"
                className="w-full sm:w-auto bg-[#E8924A] hover:bg-[#D97D35] text-white font-extrabold px-6 py-3 rounded-xl text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
              >
                <PhoneCall className="w-4 h-4 animate-pulse" />
                <span>সরাসরি ডায়াল করুন ১৬৪৩০</span>
              </a>
            </div>
          </div>

          {/* Details Grid: Eligibility, Benefits, Steps */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* কারা পাবেন লিগ্যাল এইড? */}
            <div className="bg-white border border-[#E6E0D4] rounded-3xl p-5 shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-[#2D5A27] font-bold text-sm sm:text-base border-b border-[#E6E0D4] pb-2.5">
                <Users className="w-5 h-5" />
                <h4>কারা বিনামূল্যে আইনি সহায়তা পাওয়ার যোগ্য?</h4>
              </div>
              <ul className="space-y-2 text-xs sm:text-sm text-[#3E4D4D] list-none">
                <li className="flex items-start gap-2">
                  <span className="text-[#2D5A27] font-bold mt-0.5">১.</span>
                  <span>যেকোনো আর্থিকভাবে অসচ্ছল নাগরিক (কৃষক, দিনমজুর, রিকশাচালক, শ্রমিক)।</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#2D5A27] font-bold mt-0.5">২.</span>
                  <span>সহিংসতা, যৌতুক, পারিবারিক নির্যাতন বা এসিড সন্ত্রাসের শিকার যেকোনো নারী ও শিশু।</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#2D5A27] font-bold mt-0.5">৩.</span>
                  <span>বীর মুক্তিযোদ্ধা, বয়োবৃদ্ধ, বিধবা, তালাকপ্রাপ্ত বা দুস্থ নারী।</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#2D5A27] font-bold mt-0.5">৪.</span>
                  <span>শারীরিক বা মানসিক প্রতিবন্ধী ব্যক্তি।</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#2D5A27] font-bold mt-0.5">৫.</span>
                  <span>টাকা দিয়ে আইনজীবী নিয়োগ করতে না পেরে কারাগারে আটক কোনো হাজতি বা কয়েদি।</span>
                </li>
              </ul>
            </div>

            {/* সরকার কী কী খরচ বহন করে? */}
            <div className="bg-white border border-[#E6E0D4] rounded-3xl p-5 shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-[#2D5A27] font-bold text-sm sm:text-base border-b border-[#E6E0D4] pb-2.5">
                <CheckCircle2 className="w-5 h-5" />
                <h4>সরকার কী কী খরচ বিনামূল্যে বহন করে?</h4>
              </div>
              <ul className="space-y-2 text-xs sm:text-sm text-[#3E4D4D]">
                <li className="flex items-start gap-2">
                  <span className="text-[#2D5A27] font-bold mt-0.5">✓</span>
                  <span><strong>অভিজ্ঞ আইনজীবী নিয়োগ:</strong> প্যানেল আইনজীবীর সম্পূর্ণ পারিশ্রমিক সরকার সরাসরি পরিশোধ করে।</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#2D5A27] font-bold mt-0.5">✓</span>
                  <span><strong>কোর্ট ফি ও নকল খরচ:</strong> মামলার ফাইলিং কোর্ট ফি, প্রসেস ফি এবং রায়/ডিক্রির জাবেদা নকল তোলার খরচ।</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#2D5A27] font-bold mt-0.5">✓</span>
                  <span><strong>ডিএনএ টেস্ট বা বিশেষজ্ঞ মতামত:</strong> আদালতের আদেশে ফরেনসিক বা ডিএনএ টেস্ট প্রয়োজন হলে সরকারি অনুদান।</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#2D5A27] font-bold mt-0.5">✓</span>
                  <span><strong>মামলা ছাড়া আপোষ (ADR):</strong> দীর্ঘ বছর মামলা না করে উভয় পক্ষকে ডেকে অফিসে বসে বিনামূল্যে বিরোধ নিষ্পত্তি।</span>
                </li>
              </ul>
            </div>

          </div>

          {/* কীভাবে আবেদন করবেন? */}
          <div className="bg-[#FAF8F5] border border-[#D4C3A3] rounded-3xl p-5 sm:p-6 space-y-3">
            <h4 className="font-bold text-sm sm:text-base text-[#2D3A3A] flex items-center gap-2">
              <Building2 className="w-5 h-5 text-[#2D5A27]" />
              <span>কোথায় যাবেন এবং কীভাবে আবেদন করবেন?</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="bg-white p-4 rounded-2xl border border-[#E6E0D4] space-y-1">
                <span className="text-xs font-bold text-[#2D5A27] bg-[#D4E4BC] px-2 py-0.5 rounded-full">ধাপ ১: জেলা কোর্ট</span>
                <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">জেলা জজ আদালত ভবন</h5>
                <p className="text-xs text-[#5A6B6B] leading-relaxed">
                  আপনার জেলা জজ কোর্টের নিচতলায় "জেলা লিগ্যাল এইড অফিস"-এ গিয়ে সাদা কাগজে বা নির্দিষ্ট ফরমে আবেদনপত্র জমা দিন।
                </p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-[#E6E0D4] space-y-1">
                <span className="text-xs font-bold text-[#A65E2E] bg-[#F9E5D4] px-2 py-0.5 rounded-full">ধাপ ২: উপজেলা পরিষদ</span>
                <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">উপজেলা লিগ্যাল এইড কমিটি</h5>
                <p className="text-xs text-[#5A6B6B] leading-relaxed">
                  জেলায় যেতে না পারলে উপজেলা নির্বাহী অফিসার (UNO) মহোদয়ের কার্যালয়ে উপজেলা কমিটির কাছে আবেদন দিন।
                </p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-[#E6E0D4] space-y-1">
                <span className="text-xs font-bold text-[#1B365D] bg-[#D1E5F0] px-2 py-0.5 rounded-full">ধাপ ৩: ইউনিয়ন পরিষদ</span>
                <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">ইউপি চেয়ারম্যান ও সচিব</h5>
                <p className="text-xs text-[#5A6B6B] leading-relaxed">
                  ইউনিয়ন পরিষদ লিগ্যাল এইড কমিটির মাধ্যমে সরাসরি বিনামূল্যে আবেদন জেলা অফিসে পাঠিয়ে দেওয়া হয়।
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: নির্বাহী আদালত / ম্যাজিস্ট্রেট কোর্ট গাইড (EXECUTIVE COURT) */}
      {activeTab === 'executive' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          
          <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 border-b border-[#E6E0D4] pb-3">
              <div className="w-12 h-12 rounded-2xl bg-[#F9E5D4] text-[#A65E2E] flex items-center justify-center font-bold">
                <Landmark className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A]">
                  নির্বাহী আদালত / ম্যাজিস্ট্রেট কোর্ট গাইড (Executive Court)
                </h3>
                <p className="text-xs text-[#736B5E]">
                  জমির দখল, শান্তি-শৃঙ্খলা, ১৪৪ ধারা, মোবাইল কোর্ট ও পারিবারিক জরুরি বিষয়ের তড়িৎ নিষ্পত্তি
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* কাদের জন্য */}
              <div className="bg-[#FAF8F5] p-4.5 rounded-2xl border border-[#E6E0D4] space-y-2">
                <h4 className="font-bold text-sm text-[#A65E2E] flex items-center gap-1.5">
                  <BadgeAlert className="w-4 h-4 text-[#C0392B]" />
                  <span>কাদের জন্য এই আদালত প্রযোজ্য?</span>
                </h4>
                <ul className="space-y-1.5 text-xs sm:text-sm text-[#3E4D4D] list-disc list-inside">
                  <li><strong>জমিজমা দখল ও মারামারির আশঙ্কা:</strong> দখলকৃত জমিতে সীমানা নিয়ে উত্তেজনা বা রক্তক্ষয়ী সংঘর্ষের উপক্রম হলে।</li>
                  <li><strong>১৪৪ ও ১৪৫ ধারা জারি:</strong> বিরোধীয় সম্পত্তিতে শান্তি-শৃঙ্খলা বজায় রাখতে ১৪৪ বা ১৪৫ ধারার নিষেধাজ্ঞা প্রার্থনা।</li>
                  <li><strong>পারিবারিক জরুরি সুরক্ষা:</strong> বৃদ্ধ পিতা-মাতাকে বাড়ি থেকে উচ্ছেদ, ভরণপোষণ না দেওয়া বা নারীর জরুরি নিরাপত্তা।</li>
                  <li><strong>মোবাইল কোর্ট (ভ্রাম্যমাণ আদালত):</strong> ভেজাল খাদ্য, ওজনে কম দেওয়া, অবৈধ ড্রেজার দিয়ে নদী বা কৃষিজমি খনন ও শব্দদূষণ।</li>
                  <li><strong>১০৭ ও ১১৭ ধারা:</strong> প্রতিপক্ষ কর্তৃক প্রাণনাশের হুমকি বা এলাকায় অরাজকতার আশঙ্কা থাকলে শান্তি রক্ষা মুচলেকা।</li>
                </ul>
              </div>

              {/* কোথায় যাবেন */}
              <div className="bg-[#FAF8F5] p-4.5 rounded-2xl border border-[#E6E0D4] space-y-2">
                <h4 className="font-bold text-sm text-[#2D5A27] flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[#2D5A27]" />
                  <span>কোথায় যাবেন এবং কার নিকট আবেদন করবেন?</span>
                </h4>
                <div className="space-y-2.5 text-xs sm:text-sm text-[#3E4D4D]">
                  <div className="p-2.5 bg-white rounded-xl border border-[#E6E0D4]">
                    <strong className="text-[#2D3A3A] block">১. উপজেলা নির্বাহী অফিসার (UNO):</strong>
                    <span>উপজেলা নির্বাহী ম্যাজিস্ট্রেট হিসেবে তাৎক্ষণিক তদন্ত, পুলিশকে নির্দেশ এবং মোবাইল কোর্ট পরিচালনা করেন।</span>
                  </div>
                  <div className="p-2.5 bg-white rounded-xl border border-[#E6E0D4]">
                    <strong className="text-[#2D3A3A] block">২. সহকারী কমিশনার (ভূমি) / এসি ল্যান্ড:</strong>
                    <span>খাসজমি উদ্ধার, নদী রক্ষা, সরকারি সম্পত্তির দখল রোধ ও রাজস্ব সংক্রান্ত ম্যাজিস্ট্রেট ক্ষমতাপ্রাপ্ত।</span>
                  </div>
                  <div className="p-2.5 bg-white rounded-xl border border-[#E6E0D4]">
                    <strong className="text-[#2D3A3A] block">৩. জেলা ম্যাজিস্ট্রেট (জেলা প্রশাসক / ডিসি কার্যালয়):</strong>
                    <span>অতিরিক্ত জেলা ম্যাজিস্ট্রেট (ADM) কোর্টে ১৪৪ ও ১৪৫ ধারার মিস পিটিশন মামলা দায়ের করা যায়।</span>
                  </div>
                </div>
              </div>

            </div>

            {/* দরখাস্ত লেখার নিয়ম ও টিপস */}
            <div className="p-4 bg-[#FFF9E6] border border-[#F6E05E] rounded-2xl space-y-1.5 text-xs text-[#8C5D17]">
              <h5 className="font-bold text-sm flex items-center gap-1.5">
                <Info className="w-4 h-4" />
                <span>নির্বাহী ম্যাজিস্ট্রেট কোর্টে দরখাস্ত জমা দেওয়ার নিয়ম:</span>
              </h5>
              <p>
                সাদা কাগজে জেলা ম্যাজিস্ট্রেট (ADM) বা উপজেলা নির্বাহী অফিসার (UNO) বরাবর স্পষ্ট ভাষায় অভিযোগ লিখুন। সাথে জমি সংক্রান্ত খতিয়ান/দলিলের ফটোকপি এবং ঘটনার স্থান-কাল উল্লেখ করুন। সাধারণত কোনো লম্বা মামলার ব্যয় ছাড়াই পুলিশ বা ভূমি অফিসের নিরপেক্ষ প্রতিবেদনের ভিত্তিতে দ্রুত আদেশ দেওয়া হয়।
              </p>
            </div>
          </div>

        </div>
      )}

      {/* TAB 3: জজ কোর্ট বা বিচারিক আদালত গাইড (JUDGE COURT) */}
      {activeTab === 'judge' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          
          <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 border-b border-[#E6E0D4] pb-3">
              <div className="w-12 h-12 rounded-2xl bg-[#D1E5F0] text-[#1B365D] flex items-center justify-center font-bold">
                <Gavel className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A]">
                  জজ কোর্ট বা বিচারিক আদালত গাইড (Judge Court)
                </h3>
                <p className="text-xs text-[#736B5E]">
                  দেওয়ানি ও ফৌজদারি বিচার ব্যবস্থা, দলিলের স্বত্ব সাব্যস্ত এবং বড় অপরাধের পূর্ণাঙ্গ বিচার
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* দেওয়ানি জজ কোর্ট */}
              <div className="bg-[#FAF8F5] p-4.5 rounded-2xl border border-[#E6E0D4] space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-blue-100 text-blue-800 text-xs font-bold flex items-center justify-center">১</span>
                  <h4 className="font-bold text-sm text-[#1B365D]">দেওয়ানি আদালত (Civil Courts)</h4>
                </div>
                <p className="text-xs text-[#5A6B6B]">
                  <strong>কাদের জন্য:</strong> জমির মালিকানা বা স্থায়ী স্বত্ব ঘোষণা (Declaration Suit), জাল দলিল বাতিল, এজমালি সম্পত্তির বাটোয়ারা বা বণ্টন (Partition Suit), চুক্তি বলবৎ ও ক্ষতিপূরণ দাবি।
                </p>
                <div className="text-xs space-y-1 text-[#3E4D4D] pt-1">
                  <p><strong>যেখানে যাবেন:</strong> জেলা সদর জজ কোর্ট ভবন।</p>
                  <p><strong>আদালতের স্তর:</strong> সহকারী জজ আদালত ➔ সিনিয়র সহকারী জজ ➔ যুগ্ম জেলা জজ ➔ অতিরিক্ত জেলা জজ ➔ জেলা জজ আদালত।</p>
                  <p><strong>আইনজীবী:</strong> বাংলাদেশ বার কাউন্সিল সনদপ্রাপ্ত সিভিল অভিজ্ঞ আইনজীবীর পরামর্শ নিন।</p>
                </div>
              </div>

              {/* ফৌজদারি জজ কোর্ট */}
              <div className="bg-[#FAF8F5] p-4.5 rounded-2xl border border-[#E6E0D4] space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-red-100 text-red-800 text-xs font-bold flex items-center justify-center">২</span>
                  <h4 className="font-bold text-sm text-[#C0392B]">ফৌজদারি আদালত (Criminal Courts)</h4>
                </div>
                <p className="text-xs text-[#5A6B6B]">
                  <strong>কাদের জন্য:</strong> ডাকাতি, খুন, গুরুতর জখম, নারী ও শিশু নির্যাতন, অপহরণ, সাইবার ক্রাইম বা মাদক সংক্রান্ত ফৌজদারি অপরাধ।
                </p>
                <div className="text-xs space-y-1 text-[#3E4D4D] pt-1">
                  <p><strong>যেখানে যাবেন:</strong> চিফ জুডিশিয়াল ম্যাজিস্ট্রেট কোর্ট (CJM) অথবা দায়রা জজ আদালত।</p>
                  <p><strong>পদ্ধতি:</strong> থানায় এজাহার দায়েরের পর পুলিশ তদন্ত করে চার্জশিট দিলে বা সরাসরি কোর্টে সিআর (CR) নালিশি মামলা দায়ের করা যায়।</p>
                  <p><strong>জামিন ও বিচার:</strong> আইনজীবী মারফত জামিন আবেদন এবং স্বাক্ষী উপস্থাপনের মাধ্যমে বিচার সম্পন্ন হয়।</p>
                </div>
              </div>

            </div>

            {/* পরামর্শ ও সতকর্তা */}
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900 space-y-1">
              <span className="font-bold block">💡 দালাল ও প্রতারক থেকে সাবধান:</span>
              <p>
                কোর্ট চত্বরে কোনো অজ্ঞাত দালাল বা মধ্যস্বত্বভোগীর সাথে টাকা লেনদেন করবেন না। সরাসরি জেলা বার সমিতির নির্দিষ্ট ভবনে গিয়ে নিবন্ধিত আইনজীবীর টেবিলে কথা বলুন অথবা জেলা লিগ্যাল এইড কর্মকর্তার সাহায্য নিন।
              </p>
            </div>
          </div>

        </div>
      )}

      {/* TAB 4: জরুরি পুলিশ সহায়তা ও জিডি গাইড (POLICE & GD GUIDE) */}
      {activeTab === 'police' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          
          <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-5">
            
            <div className="flex items-center gap-3 border-b border-[#E6E0D4] pb-3">
              <div className="w-12 h-12 rounded-2xl bg-[#FADBD8] text-[#C0392B] flex items-center justify-center font-bold">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A]">
                  জরুরি পুলিশ সহায়তা ও সাধারণ ডায়েরি (GD) গাইড
                </h3>
                <p className="text-xs text-[#736B5E]">
                  থানার ডিউটি অফিসার, ফ্রি সাধারণ ডায়েরি ও পুলিশি নাগরিক সেবা নির্দেশিকা
                </p>
              </div>
            </div>

            {/* Police Help Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* সাধারণ ডায়েরি (GD) করার নিয়ম */}
              <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E6E0D4] space-y-3">
                <h4 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#2D5A27]" />
                  <span>থানায় সাধারণ ডায়েরি (GD) করার সহজ নিয়ম</span>
                </h4>
                <p className="text-xs text-[#5A6B6B] leading-relaxed">
                  জিডি হলো কোনো হারানো জিনিস বা সম্ভাব্য হুমকির বিষয়ে পুলিশকে আনুষ্ঠানিকভাবে অবগত করা। <strong>থানায় জিডি করতে কোনো সরকারি ফি লাগে না (সম্পূর্ণ ফ্রি)।</strong>
                </p>
                <div className="space-y-1.5 text-xs text-[#3E4D4D]">
                  <p><strong>কখন জিডি করবেন:</strong> এনআইডি কার্ড, ড্রাইভিং লাইসেন্স, পাসপোর্ট, সার্টিফিকেট বা মোবাইল ফোন হারিয়ে গেলে; অথবা কেউ হুমকি দিলে।</p>
                  <p><strong>কী লাগবে:</strong> আবেদনকারীর এনআইডি কার্ডের কপি ও সচল মোবাইল নম্বর।</p>
                  <p><strong>কার কাছে যাবেন:</strong> নিকটস্থ মডেল থানার 'ডিউটি অফিসার' রুমে গিয়ে সাদা কাগজে অফিসার ইনচার্জ (OC) বরাবর দরখাস্ত দিন।</p>
                  <p><strong>অনলাইন জিডি:</strong> ঘরে বসে বাংলাদেশ পুলিশের <em>Online GD</em> মোবাইল অ্যাপ বা gd.police.gov.bd দিয়ে যেকোনো হারানো জিনিসের অনলাইন জিডি করা যায়।</p>
                </div>
              </div>

              {/* ডিউটি অফিসার ও থানার সেবা */}
              <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E6E0D4] space-y-3">
                <h4 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-2">
                  <BadgeAlert className="w-4 h-4 text-[#C0392B]" />
                  <span>ডিউটি অফিসার ও থানার জরুরি সেবা</span>
                </h4>
                <ul className="space-y-2 text-xs text-[#3E4D4D]">
                  <li className="p-2.5 bg-white rounded-xl border border-[#E6E0D4]">
                    <strong>ডিউটি অফিসার ২৪ ঘণ্টা নিয়োজিত:</strong> যেকোনো জরুরি পরিস্থিতিতে থানায় গিয়ে ডিউটি অফিসারের শরণাপন্ন হোন। তিনি আপনার অভিযোগ রেকর্ড করবেন।
                  </li>
                  <li className="p-2.5 bg-white rounded-xl border border-[#E6E0D4]">
                    <strong>নারী, শিশু ও প্রবীণ হেল্পডেস্ক:</strong> প্রতিটি থানায় নারী ও শিশুদের জন্য নারী এসআই কর্মকর্তার পরিচালনায় পৃথক নিরাপদ সেবা ডেস্ক রয়েছে।
                  </li>
                  <li className="p-2.5 bg-white rounded-xl border border-[#E6E0D4]">
                    <strong>পুলিশ ক্লিয়ারেন্স সার্টিফিকেট:</strong> বিদেশ গমন বা চাকরির জন্য pcc.police.gov.bd ওয়েবসাইটে অনলাইনে ৫০০ টাকা সরকারি ফি দিয়ে আবেদন করুন।
                  </li>
                </ul>
              </div>

            </div>

            {/* Quick Police Helplines */}
            <div className="bg-[#FADBD8]/30 border border-[#FADBD8] p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3">
              <div>
                <span className="font-bold text-xs sm:text-sm text-[#C0392B] block">জরুরি পুলিশ সেবা:</span>
                <span className="text-xs text-[#736B5E]">সারাদেশের যেকোনো স্থান থেকে কল করুন</span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href="tel:999"
                  className="bg-[#C0392B] text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>৯৯৯ জাতীয় পুলিশ সেবা</span>
                </a>
                <a
                  href="tel:109"
                  className="bg-[#2D5A27] text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>১০৯ নারী ও শিশু সহায়তা</span>
                </a>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* TAB 5: ইউনিয়ন পরিষদ গ্রাম আদালত (VILLAGE COURT) */}
      {activeTab === 'village_court' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          
          <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 border-b border-[#E6E0D4] pb-3">
              <div className="w-12 h-12 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-bold">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A]">
                  ইউনিয়ন পরিষদ গ্রাম আদালত (Village Court) ও সালিশ
                </h3>
                <p className="text-xs text-[#736B5E]">
                  গ্রাম আদালত আইন ২০০৬ অনুযায়ী স্থানীয় পর্যায়ে স্বল্প খরচে ও দালাল-উকিল ছাড়া আপোষ
                </p>
              </div>
            </div>

            <div className="space-y-3 text-xs sm:text-sm text-[#3E4D4D] leading-relaxed">
              <div className="p-4 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] space-y-2">
                <h4 className="font-bold text-[#2D5A27] text-sm">গ্রাম আদালতের এখতিয়ার ও আর্থিক সীমা:</h4>
                <p>
                  গ্রাম আদালত অনধিক <strong>৩ লক্ষ টাকা পর্যন্ত</strong> স্থাবর বা অস্থাবর সম্পত্তির ক্ষতিপূরণ, বকেয়া পাওনা টাকা উদ্ধার, গৃহপালিত পশু সংক্রান্ত ক্ষতি এবং ছোটখাটো মারামারির মামলার চূড়ান্ত মীমাংসা করতে পারে।
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="p-4 bg-white rounded-2xl border border-[#E6E0D4] space-y-1">
                  <strong className="text-[#2D3A3A] block text-sm">সরকারি নামমাত্র ফি:</strong>
                  <p className="text-xs text-[#5A6B6B]">
                    দেওয়ানি মামলায় আবেদন ফি মাত্র <strong>২০ টাকা</strong> এবং ফৌজদারি মামলায় মাত্র <strong>১০ টাকা</strong>।
                  </p>
                </div>

                <div className="p-4 bg-white rounded-2xl border border-[#E6E0D4] space-y-1">
                  <strong className="text-[#2D3A3A] block text-sm">উকিল সম্পূর্ণ নিষিদ্ধ:</strong>
                  <p className="text-xs text-[#5A6B6B]">
                    গ্রাম আদালতে কোনো আইনজীবী বা দালালের প্রবেশাধিকার নেই। বাদী ও বিবাদী নিজে উপস্থিত থেকে আপোষ আলোচনা করেন।
                  </p>
                </div>
              </div>

              <div className="p-4 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] space-y-1">
                <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">আদালত গঠন ও পদ্ধতি:</h5>
                <p className="text-xs text-[#5A6B6B]">
                  ইউপি চেয়ারম্যানের সভাপতিত্বে বাদী তার পছন্দ অনুযায়ী ১ জন মেম্বার ও ১ জন স্থানীয় গণ্যমান্য ব্যক্তি এবং বিবাদী তার পছন্দ অনুযায়ী ১ জন মেম্বার ও ১ জন ব্যক্তি মনোনীত করেন। মোট ৫ সদস্যের গ্রাম আদালত উন্মুক্ত শুনানির মাধ্যমে বিরোধ নিষ্পত্তি করে।
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
