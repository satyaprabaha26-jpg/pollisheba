import React, { useState, useMemo } from 'react';
import { 
  Compass, 
  Search, 
  FileText, 
  PhoneCall, 
  AlertCircle, 
  CheckCircle2, 
  Building2, 
  Sparkles,
  ChevronDown,
  X,
  Scale,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { SERVICE_OFFICE_GUIDES } from '../../data/extendedData';
import { ServiceOfficeGuide } from '../../types';

// Category Priority Order (গুরুত্বপূর্ণ সেবা অনুযায়ী উপর-নিচে সাজানো)
const PRIORITY_CATEGORIES = [
  'সকল সেবা',
  'জরুরি স্বাস্থ্য ও রক্তসেবা',
  'জমিজমা ও পর্চা',
  'আইন, আদালত ও লিগ্যাল এইড',
  'ভোটার আইডি ও জন্ম নিবন্ধন',
  'ভাতা ও আর্থিক সাহায্য',
  'কৃষি ও বীজ-সার',
  'প্রাণিসম্পদ ও পশুপালন',
  'পল্লী উন্নয়ন ও সমবায় (BRDB)',
  'খাবার পানি ও স্যানিটেশন (DPHE)',
  'শিক্ষা ও উপবৃত্তি',
  'চিকিৎসা ও স্বাস্থ্য',
  'বিদ্যুৎ ও সংযোগ',
  'পাসপোর্ট ও লাইসেন্স'
];

interface TopOfficeCard {
  id: string;
  title: string;
  category: string;
  icon: string;
  bg: string;
  text: string;
  borderColor: string;
  summary: string;
  targetGuideId: string;
}

const TOP_8_OFFICES: TopOfficeCard[] = [
  {
    id: 'top-land',
    title: 'ভূমি অফিস ও এসি ল্যান্ড',
    category: 'জমিজমা ও পর্চা',
    icon: '📜',
    bg: 'bg-[#F9E5D4]',
    text: 'text-[#A65E2E]',
    borderColor: 'border-[#E8924A]/40',
    summary: 'ই-নামজারি, জমাভাগ, খারিজ, পর্চা ও খতিয়ান সংশোধন',
    targetGuideId: 'sog-1'
  },
  {
    id: 'top-legal',
    title: 'লিগ্যাল এইড ও আদালত',
    category: 'আইন, আদালত ও লিগ্যাল এইড',
    icon: '⚖️',
    bg: 'bg-emerald-100',
    text: 'text-emerald-800',
    borderColor: 'border-emerald-300',
    summary: 'বিনামূল্যে লিগ্যাল এইড (১৬৪৩০), নির্বাহী ম্যাজিস্ট্রেট ১৪৪ ধারা ও জজ কোর্ট',
    targetGuideId: 'sog-17'
  },
  {
    id: 'top-union',
    title: 'ইউনিয়ন পরিষদ ও গ্রাম আদালত',
    category: 'ভোটার আইডি ও জন্ম নিবন্ধন',
    icon: '🏛️',
    bg: 'bg-[#D4E4BC]/60',
    text: 'text-[#2D5A27]',
    borderColor: 'border-[#2D5A27]/30',
    summary: 'জন্ম/মৃত্যু নিবন্ধন, নাগরিকত্ব সনদ, ওয়ারিশান ও গ্রাম আদালত আপস',
    targetGuideId: 'sog-3'
  },
  {
    id: 'top-social',
    title: 'উপজেলা সমাজসেবা কার্যালয়',
    category: 'ভাতা ও আর্থিক সাহায্য',
    icon: '🤝',
    bg: 'bg-[#F9E5D4]',
    text: 'text-[#A65E2E]',
    borderColor: 'border-[#E8924A]/40',
    summary: 'বয়স্ক, বিধবা ও প্রতিবন্ধী ভাতা কার্ড এবং সুবর্ণ নাগরিক সেবা',
    targetGuideId: 'sog-4'
  },
  {
    id: 'top-agri',
    title: 'উপজেলা কৃষি অফিস',
    category: 'কৃষি ও বীজ-সার',
    icon: '🌾',
    bg: 'bg-[#D4E4BC]/60',
    text: 'text-[#2D5A27]',
    borderColor: 'border-[#2D5A27]/30',
    summary: 'কৃষক কার্ড, প্রণোদনা বীজ-সার ও ফসলের চিকিৎসা পরামর্শ',
    targetGuideId: 'sog-7'
  },
  {
    id: 'top-livestock',
    title: 'উপজেলা প্রাণিসম্পদ অধিদপ্তর',
    category: 'প্রাণিসম্পদ ও পশুপালন',
    icon: '🐄',
    bg: 'bg-amber-100',
    text: 'text-amber-800',
    borderColor: 'border-amber-300',
    summary: 'পশুর চিকিৎসা, টিকা, কৃত্রিম প্রজনন ও খামার নিবন্ধন',
    targetGuideId: 'sog-8'
  },
  {
    id: 'top-brdb',
    title: 'পল্লী উন্নয়ন বোর্ড (বিআরডিবি)',
    category: 'পল্লী উন্নয়ন ও সমবায় (BRDB)',
    icon: '🏢',
    bg: 'bg-emerald-100',
    text: 'text-emerald-800',
    borderColor: 'border-emerald-300',
    summary: 'পল্লী সমবায় সমিতি, স্বল্প সুদে উদ্যোক্তা ঋণ ও প্রশিক্ষণ',
    targetGuideId: 'sog-13'
  },
  {
    id: 'top-dphe',
    title: 'জনস্বাস্থ্য প্রকৌশল অধিদপ্তর',
    category: 'খাবার পানি ও স্যানিটেশন (DPHE)',
    icon: '🚰',
    bg: 'bg-sky-100',
    text: 'text-sky-800',
    borderColor: 'border-sky-300',
    summary: 'নিরাপদ গভীর নলকূপ বরাদ্দ, আর্সেনিক পরীক্ষা ও স্যানিটেশন',
    targetGuideId: 'sog-14'
  }
];

export const ServiceFinder: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('সকল সেবা');
  const [expandedId, setExpandedId] = useState<string | null>('sog-17'); // Default to Legal Aid
  const [modalGuide, setModalGuide] = useState<ServiceOfficeGuide | null>(null);

  // Total services count
  const totalServicesCount = SERVICE_OFFICE_GUIDES.length;

  // Filter guides based on search and category
  const filteredGuides = useMemo(() => {
    return SERVICE_OFFICE_GUIDES.filter((guide) => {
      const matchesCat = selectedCategory === 'সকল সেবা' || guide.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      if (!q) return matchesCat;

      const matchesQuery = 
        guide.serviceName.toLowerCase().includes(q) ||
        guide.category.toLowerCase().includes(q) ||
        guide.officeName.toLowerCase().includes(q) ||
        guide.officerDesignation.toLowerCase().includes(q) ||
        guide.fees.toLowerCase().includes(q) ||
        guide.steps.some(s => s.toLowerCase().includes(q)) ||
        guide.requiredDocuments.some(d => d.toLowerCase().includes(q));

      return matchesCat && matchesQuery;
    });
  }, [searchQuery, selectedCategory]);

  // Group filtered guides by priority categories
  const groupedGuides = useMemo(() => {
    const map = new Map<string, ServiceOfficeGuide[]>();

    // Determine category sequence
    const categoriesToGroup = selectedCategory === 'সকল সেবা' 
      ? PRIORITY_CATEGORIES.filter(c => c !== 'সকল সেবা')
      : [selectedCategory];

    categoriesToGroup.forEach(cat => {
      const items = filteredGuides.filter(g => g.category === cat);
      if (items.length > 0) {
        map.set(cat, items);
      }
    });

    // Also catch any guide whose category might not be explicitly listed
    filteredGuides.forEach(g => {
      if (!map.has(g.category) && !categoriesToGroup.includes(g.category)) {
        map.set(g.category, [g]);
      }
    });

    return map;
  }, [filteredGuides, selectedCategory]);

  const handleTopOfficeClick = (office: TopOfficeCard) => {
    setSelectedCategory(office.category);
    setSearchQuery('');
    setExpandedId(office.targetGuideId);

    // Smooth scroll down to the guides section
    const el = document.getElementById('all-services-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="space-y-6 font-['Noto_Sans_Bengali']">
      {/* 1. Header Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block shadow-2xs">
            🧭 ওয়ান-স্টপ পল্লী সেবা নেভিগেটর
          </span>
          <h2 className="text-xl sm:text-2xl font-bold">
            কী সেবা কোথায় কীভাবে পাবেন?
          </h2>
          <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1 max-w-2xl">
            কোন অফিসের কোন টেবিলে যাবেন, সরকারি ফি কত, কী কী কাগজপত্র লাগবে এবং দালালি ছাড়া কাজ করার পূর্ণ নাগরিক গাইড
          </p>
        </div>

        <div className="flex items-center gap-2 bg-[#23491E] border border-[#3D7A35] px-4 py-2 rounded-2xl text-xs text-[#D4E4BC] shadow-2xs">
          <Sparkles className="w-4 h-4 text-[#E8924A]" />
          <span>দালালমুক্ত সরকারি সেবা নির্দেশিকা</span>
        </div>
      </div>

      {/* 2. Top Section: 8 Main Service Offices (বড় আকারে দেখানো ৮টি মূল সেবা দপ্তর) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#2D5A27]" />
            <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A]">
              উপজেলা ও ইউনিয়ন পর্যায়ের প্রধান সেবা দপ্তরসমূহ
            </h3>
            <span className="text-[11px] bg-[#D4E4BC] text-[#2D5A27] px-2.5 py-0.5 rounded-full font-bold shadow-2xs">
              ৮টি মূল দপ্তর
            </span>
          </div>
          <span className="text-xs text-[#736B5E] hidden sm:inline">
            দপ্তরে ক্লিক করে সরাসরি সংশ্লিষ্ট সেবা ও গাইড দেখুন
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {TOP_8_OFFICES.map((office) => {
            const isSelected = selectedCategory === office.category;
            return (
              <div 
                key={office.id}
                onClick={() => handleTopOfficeClick(office)}
                className={`bg-white border p-3.5 sm:p-4 rounded-3xl shadow-xs cursor-pointer transition transform hover:-translate-y-0.5 flex flex-col justify-between ${
                  isSelected ? 'border-[#2D5A27] ring-2 ring-[#2D5A27]/20 bg-[#FAF8F5]' : 'border-[#E6E0D4] hover:border-[#2D5A27]'
                }`}
              >
                <div>
                  <div className={`w-9 h-9 rounded-2xl ${office.bg} flex items-center justify-center ${office.text} mb-2.5 font-bold text-lg shadow-2xs border ${office.borderColor}`}>
                    {office.icon}
                  </div>
                  <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] leading-snug">
                    {office.title}
                  </h4>
                  <p className="text-[11px] text-[#736B5E] mt-1.5 leading-relaxed line-clamp-2">
                    {office.summary}
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-[#E6E0D4]/60 flex items-center justify-between text-[11px] font-bold text-[#2D5A27]">
                  <span>সেবা দেখুন</span>
                  <span>→</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. All Services Section Header */}
      <div id="all-services-section" className="space-y-3 pt-1">
        <div className="flex items-center justify-between px-1 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#2D5A27]" />
            <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A]">
              সকল নাগরিক সেবা ও দপ্তর নির্দেশিকা
            </h3>
            <span className="text-[11px] bg-[#D4E4BC] text-[#2D5A27] px-2.5 py-0.5 rounded-full font-bold shadow-2xs">
              {totalServicesCount}টি সেবা তালিকাভুক্ত
            </span>
          </div>
          <span className="text-xs text-[#736B5E] hidden sm:inline">
            ক্যাটাগরি নির্বাচন করুন বা সেবার নাম লিখে খুঁজুন
          </span>
        </div>
      </div>

      {/* 4. Filter and Search Bar */}
      <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        {/* Category Chips Bar */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full sm:w-auto pb-1 sm:pb-0">
          {PRIORITY_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-2xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#2D5A27] text-white shadow-xs ring-2 ring-[#2D5A27]/20 font-bold'
                  : 'bg-[#FDFBF7] text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Field */}
        <div className="relative w-full sm:w-80 shrink-0">
          <Search className="w-4 h-4 text-[#736B5E] absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="সেবা, অফিস, আদালত বা কাগজের নাম খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-8 py-2 bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] shadow-2xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 text-[#736B5E] hover:text-[#2D3A3A] p-0.5 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* 5. Services List Grouped By Category Order (উপর-নিচে সাজানো) */}
      <div className="space-y-6">
        {Array.from(groupedGuides.entries()).map(([categoryName, guides]) => (
          <div key={categoryName} className="space-y-3">
            {/* Category Section Header */}
            <div className="flex items-center justify-between px-1 border-b border-[#E6E0D4] pb-2">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-[#2D5A27]" />
                <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A]">
                  {categoryName}
                </h3>
              </div>
              <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full">
                {guides.length}টি সেবা
              </span>
            </div>

            {/* Individual Service Cards in this Category */}
            <div className="space-y-3">
              {guides.map((guide) => {
                const isExpanded = expandedId === guide.id;
                return (
                  <div
                    key={guide.id}
                    id={`guide-${guide.id}`}
                    className={`bg-white border rounded-3xl transition duration-150 overflow-hidden shadow-xs ${
                      isExpanded 
                        ? 'border-[#2D5A27] ring-1 ring-[#2D5A27]/20 shadow-sm' 
                        : 'border-[#E6E0D4] hover:border-[#2D5A27]'
                    }`}
                  >
                    {/* Main Row / Card Click to expand */}
                    <div
                      onClick={() => setExpandedId(isExpanded ? null : guide.id)}
                      className="p-4 sm:p-5 flex items-start justify-between gap-3 cursor-pointer select-none"
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 font-bold ${
                          guide.category.includes('আইন') || guide.category.includes('আদালত')
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-[#D4E4BC]/60 text-[#2D5A27] border border-[#D4E4BC]'
                        }`}>
                          {guide.category.includes('আইন') || guide.category.includes('আদালত') ? (
                            <Scale className="w-5 h-5" />
                          ) : (
                            <Compass className="w-5 h-5" />
                          )}
                        </div>

                        <div>
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/40 px-2.5 py-0.5 rounded-full">
                              {guide.category}
                            </span>
                            <span className="text-[11px] text-[#736B5E] font-medium hidden sm:inline">
                              📍 {guide.officeName}
                            </span>
                          </div>

                          <h4 className="font-bold text-sm sm:text-base text-[#2D3A3A] leading-snug">
                            {guide.serviceName}
                          </h4>

                          <div className="text-xs text-[#736B5E] mt-1.5 flex flex-wrap gap-x-4 gap-y-1">
                            <span><strong>অফিস:</strong> {guide.officeName}</span>
                            <span><strong>কর্মকর্তা:</strong> {guide.officerDesignation}</span>
                            <span><strong>সরকারি ফি:</strong> <span className="text-[#15803D] font-bold">{guide.fees}</span></span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setModalGuide(guide);
                          }}
                          className="hidden sm:inline-flex items-center gap-1 text-[11px] font-bold text-[#2D5A27] hover:text-[#166534] bg-[#FAF8F5] hover:bg-[#E6E0D4]/40 border border-[#D4C3A3] px-2.5 py-1 rounded-xl transition cursor-pointer"
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span>সংক্ষিপ্ত বিবরণ</span>
                        </button>

                        <button
                          type="button"
                          className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition ${
                            isExpanded ? 'bg-[#2D5A27] text-white rotate-180' : 'bg-[#FAF8F5] text-[#736B5E] border border-[#E6E0D4]'
                          }`}
                        >
                          <ChevronDown className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Concise & Comprehensive Breakdown when Expanded */}
                    {isExpanded && (
                      <div className="p-4 sm:p-5 pt-0 border-t border-[#E6E0D4] space-y-4 bg-[#FDFBF7]">
                        {/* Quick Key Metas Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4">
                          <div className="bg-white p-3 rounded-2xl border border-[#E6E0D4]">
                            <span className="text-[11px] text-[#736B5E] block font-semibold">🏢 নির্দিষ্ট রুম বা ডেস্ক:</span>
                            <p className="text-xs font-bold text-[#2D3A3A] mt-0.5">{guide.roomOrDesk}</p>
                          </div>

                          <div className="bg-white p-3 rounded-2xl border border-[#E6E0D4]">
                            <span className="text-[11px] text-[#736B5E] block font-semibold">💰 সরকারি ফি এর পরিমাণ:</span>
                            <p className="text-xs font-bold text-[#15803D] mt-0.5">{guide.fees}</p>
                          </div>

                          <div className="bg-white p-3 rounded-2xl border border-[#E6E0D4] flex items-center justify-between">
                            <div>
                              <span className="text-[11px] text-[#736B5E] block font-semibold">📞 অফিশিয়াল হেল্পলাইন:</span>
                              <p className="text-xs font-bold text-[#2D3A3A] mt-0.5">{guide.contactHelpline || '৩৩৩'}</p>
                            </div>
                            {guide.contactHelpline && (
                              <a
                                href={`tel:${guide.contactHelpline.replace(/[^0-9]/g, '')}`}
                                className="bg-[#2D5A27] hover:bg-[#166534] text-white px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 font-bold shadow-xs transition"
                              >
                                <PhoneCall className="w-3 h-3" />
                                <span>কল</span>
                              </a>
                            )}
                          </div>
                        </div>

                        {/* Required Documents Checklist */}
                        <div className="bg-white p-4 rounded-2xl border border-[#E6E0D4] space-y-2">
                          <h5 className="font-bold text-xs text-[#2D3A3A] flex items-center gap-1.5">
                            <FileText className="w-4 h-4 text-[#E8924A]" />
                            <span>যেসব কাগজপত্র সঙ্গে নিয়ে যেতে হবে (চেকলিস্ট):</span>
                          </h5>
                          <ul className="space-y-1.5">
                            {guide.requiredDocuments.map((doc, idx) => (
                              <li key={idx} className="text-xs text-[#5A6B6B] flex items-start gap-2">
                                <span className="text-[#2D5A27] font-bold">✓</span>
                                <span>{doc}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Step by Step Procedures */}
                        <div className="bg-white p-4 rounded-2xl border border-[#E6E0D4] space-y-2">
                          <h5 className="font-bold text-xs text-[#2D3A3A] flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4 text-[#2D5A27]" />
                            <span>ধাপে ধাপে সেবা পাওয়ার সঠিক নিয়ম:</span>
                          </h5>
                          <div className="space-y-2">
                            {guide.steps.map((step, idx) => (
                              <div key={idx} className="text-xs text-[#5A6B6B] flex items-start gap-2.5">
                                <span className="w-5 h-5 rounded-full bg-[#D4E4BC] text-[#2D5A27] font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5 shadow-2xs">
                                  {idx + 1}
                                </span>
                                <span className="leading-relaxed">{step}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Anti-Corruption Tips */}
                        <div className="bg-[#F9E5D4]/60 border border-[#F9E5D4] p-3.5 rounded-2xl flex items-start gap-2.5">
                          <AlertCircle className="w-4 h-4 text-[#A65E2E] shrink-0 mt-0.5" />
                          <div>
                            <span className="text-xs font-bold text-[#A65E2E] block">দালালমুক্ত সেবা গ্রহণের বিশেষ টিপস:</span>
                            <p className="text-xs text-[#736B5E] mt-0.5 leading-relaxed">{guide.tips}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        {groupedGuides.size === 0 && (
          <div className="bg-white p-8 rounded-3xl border border-[#E6E0D4] text-center space-y-3">
            <AlertCircle className="w-8 h-8 text-[#A65E2E] mx-auto" />
            <h4 className="font-bold text-base text-[#2D3A3A]">কোনো সেবা পাওয়া যায়নি</h4>
            <p className="text-xs text-[#736B5E]">
              আপনার খোঁজা শব্দ দিয়ে কোনো দপ্তর বা সেবা মেলেনি। সঠিক বানান লিখুন অথবা সকল সেবা নির্বাচন করুন।
            </p>
            <button
              onClick={() => {
                setSelectedCategory('সকল সেবা');
                setSearchQuery('');
              }}
              className="bg-[#2D5A27] text-white px-4 py-2 rounded-2xl text-xs font-bold shadow-xs transition"
            >
              সকল সেবা দেখুন
            </button>
          </div>
        )}
      </div>

      {/* 6. Concise Detail Modal (সংক্ষিপ্ত বিস্তারিত পপআপ) */}
      {modalGuide && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150 space-y-4">
            <div className="flex items-start justify-between gap-3 border-b border-[#E6E0D4] pb-3">
              <div>
                <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full">
                  {modalGuide.category}
                </span>
                <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A] mt-1.5 leading-snug">
                  {modalGuide.serviceName}
                </h3>
              </div>
              <button
                onClick={() => setModalGuide(null)}
                className="w-8 h-8 rounded-full bg-[#FAF8F5] border border-[#E6E0D4] flex items-center justify-center text-[#736B5E] hover:text-[#2D3A3A] transition cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E6E0D4]">
                  <span className="text-[#736B5E] block text-[11px]">সংশ্লিষ্ট অফিস:</span>
                  <span className="font-bold text-[#2D3A3A]">{modalGuide.officeName}</span>
                </div>
                <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E6E0D4]">
                  <span className="text-[#736B5E] block text-[11px]">সরকারি ফি:</span>
                  <span className="font-bold text-[#15803D]">{modalGuide.fees}</span>
                </div>
              </div>

              <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-1.5">
                <h5 className="font-bold text-xs text-[#2D3A3A] flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-[#E8924A]" />
                  <span>প্রয়োজনীয় কাগজপত্র:</span>
                </h5>
                <ul className="text-xs text-[#5A6B6B] space-y-1 list-disc list-inside">
                  {modalGuide.requiredDocuments.map((doc, idx) => (
                    <li key={idx}>{doc}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-1.5">
                <h5 className="font-bold text-xs text-[#2D3A3A] flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#2D5A27]" />
                  <span>ধাপে ধাপে সেবা নেওয়ার নিয়ম:</span>
                </h5>
                <div className="space-y-1.5 text-xs text-[#5A6B6B]">
                  {modalGuide.steps.map((step, idx) => (
                    <p key={idx}><strong>{idx + 1}.</strong> {step}</p>
                  ))}
                </div>
              </div>

              <div className="bg-[#F9E5D4]/60 p-3 rounded-2xl border border-[#F9E5D4] text-xs text-[#736B5E]">
                <strong className="text-[#A65E2E] block">পরামর্শ:</strong> {modalGuide.tips}
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2 border-t border-[#E6E0D4]">
              {modalGuide.contactHelpline && (
                <a
                  href={`tel:${modalGuide.contactHelpline.replace(/[^0-9]/g, '')}`}
                  className="bg-[#2D5A27] text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>হেল্পলাইনে কল করুন ({modalGuide.contactHelpline})</span>
                </a>
              )}
              <button
                onClick={() => setModalGuide(null)}
                className="bg-[#FAF8F5] border border-[#D4C3A3] text-[#2D3A3A] px-4 py-2 rounded-xl text-xs font-bold cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
