import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  MapPin, 
  Phone, 
  PhoneCall, 
  MessageSquare, 
  Mic, 
  Star, 
  ChevronRight, 
  ArrowLeft, 
  ShieldCheck, 
  Sparkles, 
  Car, 
  ShoppingBag, 
  Users, 
  HeartHandshake, 
  Zap, 
  GraduationCap, 
  Wrench, 
  Stethoscope, 
  Building2, 
  Calculator,
  SlidersHorizontal,
  PlusCircle,
  HelpCircle,
  BellRing,
  Send,
  CheckCircle2,
  Clock,
  Radio,
  Sliders,
  Share2,
  Compass,
  Lock
} from 'lucide-react';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';
import { BANGLADESH_DISTRICTS, INITIAL_HAAT_LISTINGS } from '../../data/mockData';
import { INITIAL_TRANSPORT_DRIVERS } from '../../data/extendedData';
import { UserProfile } from '../../types/auth';
import { TransportDriver, HaatListing, ServiceReview } from '../../types';
import { VoiceChatModal } from '../voice/VoiceChatModal';
import { ChatModal } from '../chat/ChatModal';
import { TwoWayReviewModal } from '../common/TwoWayReviewModal';
import { SmartFareEstimatorModal } from '../transport/SmartFareEstimatorModal';
import { CallChoiceModal } from '../transport/CallChoiceModal';
import { InAppVoiceCallModal } from '../transport/InAppVoiceCallModal';
import { useLanguage } from '../../context/LanguageContext';
import { broadcastLocalizedDemandNotification, subscribeToDemandNotifications, DemandNotification } from '../../lib/cloudSync';

export interface ServiceCategoryOption {
  id: string;
  titleBn: string;
  titleEn: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  badgeBn?: string;
  badgeEn?: string;
  descBn: string;
  descEn: string;
  navKey: string;
  roleTarget: string;
}

const SERVICE_CATEGORIES: ServiceCategoryOption[] = [
  {
    id: 'transport',
    titleBn: 'গ্রামীণ যানবাহন ও চালক',
    titleEn: 'Rural Transport & Drivers',
    icon: <Car className="w-5 h-5 text-emerald-700" />,
    color: 'border-emerald-500',
    bgColor: 'bg-emerald-50',
    badgeBn: '১০+ বাহন ও অ্যাম্বুলেন্স',
    badgeEn: '10+ Vehicles & Ambulance',
    descBn: 'ভ্যান, রিক্সা, ইজিবাইক, সিএনজি, কার, অ্যাম্বুলেন্স, হেস্কোভেটর, কলেরলাঙ্গল ও নৌকা',
    descEn: 'Van, Rickshaw, Easybike, CNG, Car, Ambulance, Excavator, Power Tiller & Boat',
    navKey: 'transport',
    roleTarget: 'driver'
  },
  {
    id: 'labor',
    titleBn: 'কৃষিন ও দিনমজুর শ্রমিক',
    titleEn: 'Agricultural & Day Laborers',
    icon: <Users className="w-5 h-5 text-blue-700" />,
    color: 'border-blue-500',
    bgColor: 'bg-blue-50',
    badgeBn: 'শ্রমিক ও কাজের ডাক',
    badgeEn: 'Labor & Hiring',
    descBn: 'ধান কাটা ও রোপণ, জমি প্রস্তুত, সেচ নালা খনন, রাজমিস্ত্রি সহযোগী ও দৈনিক মজুর',
    descEn: 'Paddy harvesting, planting, land prep, canal digging & daily laborers',
    navKey: 'labor',
    roleTarget: 'laborer'
  },
  {
    id: 'mechanic',
    titleBn: 'মেকানিক ও ইলেকট্রিশিয়ান',
    titleEn: 'Mechanics & Electricians',
    icon: <Wrench className="w-5 h-5 text-purple-700" />,
    color: 'border-purple-500',
    bgColor: 'bg-purple-50',
    badgeBn: 'দক্ষ কারিগর',
    badgeEn: 'Skilled Technicians',
    descBn: 'ওয়্যারিং, মটর, ফ্রিজ, টিভি, সাবমারসিবল পাম্প ও টিউবওয়েল মেরামত কারিগর',
    descEn: 'Wiring, motor, fridge, TV, submersible pumps & tube-well repairs',
    navKey: 'haat',
    roleTarget: 'mechanic'
  },
  {
    id: 'tutor',
    titleBn: 'গৃহশিক্ষক ও শিক্ষার্থী',
    titleEn: 'Home Tutors & Students',
    icon: <GraduationCap className="w-5 h-5 text-indigo-700" />,
    color: 'border-indigo-500',
    bgColor: 'bg-indigo-50',
    badgeBn: 'পড়ালেখা ও কোরআন',
    badgeEn: 'Education & Quran',
    descBn: 'প্রাথমিক, মাধ্যমিক, সাধারণ গণিত, ইংরেজি ও কোরআন শিক্ষার অভিজ্ঞ শিক্ষক',
    descEn: 'Primary, secondary, math, english and quran teachers',
    navKey: 'haat',
    roleTarget: 'tutor'
  },
  {
    id: 'health',
    titleBn: 'পল্লী ডাক্তার ও স্বাস্থ্যসেবা',
    titleEn: 'Rural Doctors & Health Clinics',
    icon: <Stethoscope className="w-5 h-5 text-rose-700" />,
    color: 'border-rose-500',
    bgColor: 'bg-rose-50',
    badgeBn: 'জরুরি সেবা',
    badgeEn: 'Emergency Care',
    descBn: 'গ্রাম্য চিকিৎসক, স্বাস্থ্য সহকারী, চেম্বার ভিজিট ও প্রাথমিক স্বাস্থ্য পরামর্শ',
    descEn: 'Rural physicians, health assistants, chambers and primary consults',
    navKey: 'health',
    roleTarget: 'doctor'
  },
  {
    id: 'blood',
    titleBn: 'জরুরি রক্তদাতা ও ব্লাড ব্যাংক',
    titleEn: 'Blood Donors & Blood Bank',
    icon: <HeartHandshake className="w-5 h-5 text-red-700" />,
    color: 'border-red-500',
    bgColor: 'bg-red-50',
    badgeBn: '২৪ ঘণ্টা রক্তদান',
    badgeEn: '24h Blood Donation',
    descBn: 'নিকটস্থ যেকোনো রক্তের গ্রুপের স্বেচ্ছাসেবী রক্তদাতা ও হাসপাতাল তথ্য',
    descEn: 'Nearby voluntary blood donors of all groups and hospital info',
    navKey: 'blood',
    roleTarget: 'blood_donor'
  },
  {
    id: 'haat',
    titleBn: 'পল্লী হাট ও কৃষিপণ্য',
    titleEn: 'Rural Marketplace & Crops',
    icon: <ShoppingBag className="w-5 h-5 text-amber-700" />,
    color: 'border-amber-500',
    bgColor: 'bg-amber-50',
    badgeBn: 'সরাসরি কেনাবেচা',
    badgeEn: 'Direct Buy-Sale',
    descBn: 'তাজা ফসল, শাকসবজি, ফলমূল, দুধ, ডিম, গবাদিপশু ও গ্রামীণ খাঁটি খাদ্যপণ্য',
    descEn: 'Fresh harvest, veggies, fruits, milk, eggs, livestock & rural produce',
    navKey: 'haat',
    roleTarget: 'all'
  },
  {
    id: 'electricity',
    titleBn: 'পল্লী বিদ্যুৎ সেবা ও অভিযোগ',
    titleEn: 'Palli Bidyut Complaints & Desk',
    icon: <Zap className="w-5 h-5 text-yellow-700" />,
    color: 'border-yellow-500',
    bgColor: 'bg-yellow-50',
    badgeBn: 'দ্রুত প্রতিকার',
    badgeEn: 'Fast Action',
    descBn: 'বিদ্যুৎ বিভ্রাট, লোডশেডিং, ট্রান্সফরমার বিকল ও জরুরি কমপ্লেইন ট্র্যাকিং',
    descEn: 'Power outage, transformer repairs & emergency complaint tracking',
    navKey: 'electricity',
    roleTarget: 'all'
  },
  {
    id: 'citizen',
    titleBn: 'ডিজিটাল সেন্টার ও সরকারি সেবা',
    titleEn: 'Union Digital Center & Gov Services',
    icon: <Building2 className="w-5 h-5 text-teal-700" />,
    color: 'border-teal-500',
    bgColor: 'bg-teal-50',
    badgeBn: 'নাগরিক সেবা',
    badgeEn: 'Citizen Portal',
    descBn: 'জন্মনিবন্ধন, ওয়ারিশ সনদ, পর্চা, খতিয়ান ও সরকারি বিভিন্ন ভাতা সংক্রান্ত তথ্য',
    descEn: 'Birth certificate, inheritance deed, land record & allowance info',
    navKey: 'citizen_guide',
    roleTarget: 'all'
  }
];

export const VEHICLE_OPTIONS = [
  { id: 'সকল যানবাহন', labelBn: 'সকল যানবাহন', labelEn: 'All Vehicles', icon: '🚗' },
  { id: 'ভ্যান ও রিক্সা', labelBn: 'ভ্যান ও রিক্সা', labelEn: 'Van & Rickshaw', icon: '🛺', badge: 'লোকাল' },
  { id: 'অটোরিকশা / ইজিবাইক', labelBn: 'ইজিবাইক ও ব্যাটারি অটো', labelEn: 'Easybike & Auto', icon: '🛺', badge: 'জনপ্রিয়' },
  { id: 'সিএনজি', labelBn: 'সিএনজি অটোরিকশা', labelEn: 'CNG Auto', icon: '🛺', badge: 'দ্রুত' },
  { id: 'মাইক্রোবাস / কার', labelBn: 'কার ও মাইক্রোবাস', labelEn: 'Car & Microbus', icon: '🚘', badge: 'রিজার্ভ' },
  { id: 'অ্যাম্বুলেন্স (জরুরি রোগী পরিবহন)', labelBn: 'জরুরি অ্যাম্বুলেন্স (অক্সিজেন)', labelEn: 'Emergency Ambulance', icon: '🚑', badge: '২৪ ঘণ্টা' },
  { id: 'হেস্কোভেটর (মাটি কাটা)', labelBn: 'হেস্কোভেটর (মাটি কাটা / এক্সকাভেটর)', labelEn: 'Excavator (Earthmoving)', icon: '🏗️', badge: 'খনন' },
  { id: 'কলেরলাঙ্গল / ট্র্যাক্টর', labelBn: 'কলেরলাঙ্গল / ট্র্যাক্টর / পাওয়ার টিলার', labelEn: 'Power Tiller / Tractor', icon: '🚜', badge: 'জমি চাষ' },
  { id: 'নৌকা ও খেয়া (ইঞ্জিন ট্রলার)', labelBn: 'নৌকা ও খেয়া (ইঞ্জিন ট্রলার)', labelEn: 'Boat & Ferry', icon: '🚤', badge: 'নদী পারাপার' },
  { id: 'বাইক রাইডার', labelBn: 'বাইক রাইডার (মোটরসাইকেল)', labelEn: 'Motorbike Rider', icon: '🏍️', badge: 'একক' },
  { id: 'পিকআপ / নসিমন', labelBn: 'পিকআপ ও নসিমন-করিমন', labelEn: 'Pickup & Nasimon', icon: '🛻', badge: 'মালবাহী' }
];

interface ServiceAreaFlowProps {
  currentUser: UserProfile | null;
  onNavigateTab: (tabKey: string) => void;
  onOpenAuth: (actionName?: string) => void;
  onStartInAppCall?: (targetUser: { id: string; name: string; role: string; phone?: string; avatar?: string }) => void;
}

export const ServiceAreaFlow: React.FC<ServiceAreaFlowProps> = ({
  currentUser,
  onNavigateTab,
  onOpenAuth,
  onStartInAppCall
}) => {
  const { t, language } = useLanguage();

  // Mode: 'directory' = Browse and Call Directly; 'post_demand' = Post Urgent Requirement/Demand
  const [activeMode, setActiveMode] = useState<'directory' | 'post_demand'>('directory');

  // Step: 1 = Service, 2 = Area, 3 = Results
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedService, setSelectedService] = useState<ServiceCategoryOption>(SERVICE_CATEGORIES[0]);
  const [selectedVehicleCategory, setSelectedVehicleCategory] = useState<string>('সকল যানবাহন');
  const [selectedFarePreference, setSelectedFarePreference] = useState<'সকল ভাড়া' | 'আলোচনা সাপেক্ষে' | 'নির্দিষ্ট ভাড়া'>('সকল ভাড়া');

  // Address state
  const [address, setAddress] = useState<AddressState>({
    district: 'ঢাকা',
    upazila: '',
    union: '',
    village: ''
  });

  // Modal interactions
  const [activeVoiceRecipient, setActiveVoiceRecipient] = useState<{
    name: string;
    role: string;
    phone?: string;
    avatar?: string;
    itemTitle?: string;
  } | null>(null);

  const [activeChatRecipient, setActiveChatRecipient] = useState<{
    id: string;
    name: string;
    role?: string;
    phone?: string;
    avatar?: string;
    itemTitle?: string;
  } | null>(null);

  const [activeReviewTarget, setActiveReviewTarget] = useState<{
    id: string;
    name: string;
    role: string;
    serviceType: string;
  } | null>(null);

  const [activeCallChoice, setActiveCallChoice] = useState<{
    name: string;
    role: string;
    phone: string;
    photo?: string;
    subtitle: string;
    allowOfflineCall?: boolean;
  } | null>(null);

  const [isFareModalOpen, setIsFareModalOpen] = useState<boolean>(false);
  const [selectedDriverForFare, setSelectedDriverForFare] = useState<TransportDriver | null>(null);

  const [activeInAppVoiceCall, setActiveInAppVoiceCall] = useState<{
    name: string;
    role: string;
    photo?: string;
    subtitle: string;
    maskedPhone: string;
    rawPhone?: string;
  } | null>(null);

  const handleStartInAppCall = (target: { name: string; role: string; photo?: string; subtitle: string; phone?: string }) => {
    if (onStartInAppCall) {
      onStartInAppCall({
        id: target.phone || target.name,
        name: target.name,
        role: target.role,
        phone: target.phone,
        avatar: target.photo
      });
    } else {
      setActiveInAppVoiceCall({
        name: target.name,
        role: target.role,
        photo: target.photo,
        subtitle: target.subtitle,
        maskedPhone: target.phone || '০১৭••••••',
        rawPhone: target.phone
      });
    }
  };

  // Demand Posting State (Mode 2)
  const [demandCategory, setDemandCategory] = useState<string>('transport');
  const [demandVehicle, setDemandVehicle] = useState<string>('ভ্যান ও রিক্সা');
  const [demandTitle, setDemandTitle] = useState<string>('');
  const [demandDescription, setDemandDescription] = useState<string>('');
  const [demandScope, setDemandScope] = useState<'union' | 'upazila' | 'district'>('union');
  const [demandSenderName, setDemandSenderName] = useState<string>(
    currentUser?.name || (currentUser as any)?.displayName || ''
  );
  const [demandSenderPhone, setDemandSenderPhone] = useState<string>(
    currentUser?.phone || (currentUser as any)?.phoneNumber || ''
  );
  const [allowOfflineCall, setAllowOfflineCall] = useState<boolean>(
    currentUser?.allowOfflineCall ?? (currentUser as any)?.allowOfflineCalls ?? false
  );
  const [isSubmittingDemand, setIsSubmittingDemand] = useState<boolean>(false);
  const [demandSuccessMessage, setDemandSuccessMessage] = useState<string | null>(null);
  const [areaDemands, setAreaDemands] = useState<DemandNotification[]>([]);

  // Auto-fill user name, phone, address & offline call preference from logged-in profile
  useEffect(() => {
    if (currentUser) {
      const uName = currentUser.name || (currentUser as any).displayName || '';
      const uPhone = currentUser.phone || (currentUser as any).phoneNumber || '';
      if (uName) {
        setDemandSenderName(prev => (!prev || prev === 'এলাকাবাসী' ? uName : prev));
      }
      if (uPhone) {
        setDemandSenderPhone(prev => (!prev ? uPhone : prev));
      }
      if (currentUser.allowOfflineCall !== undefined) {
        setAllowOfflineCall(currentUser.allowOfflineCall);
      } else if ((currentUser as any).allowOfflineCalls !== undefined) {
        setAllowOfflineCall((currentUser as any).allowOfflineCalls);
      }
      if (currentUser.district && (!address.district || address.district === 'সকল জেলা')) {
        setAddress(prev => ({
          ...prev,
          district: currentUser.district || prev.district || 'সকল জেলা',
          upazila: currentUser.upazila || prev.upazila || '',
          union: currentUser.union || prev.union || '',
          village: currentUser.village || (currentUser as any).ward || prev.village || ''
        }));
      }
    }
  }, [currentUser]);

  // Subscribe to real-time area demand notifications
  useEffect(() => {
    const unsub = subscribeToDemandNotifications((notifs) => {
      setAreaDemands(notifs);
    });
    return () => unsub();
  }, []);

  // Filter demands for selected area
  const filteredDemands = useMemo(() => {
    return areaDemands.filter(d => {
      if (address.district && address.district !== 'সকল জেলা' && d.targetDistrict !== 'সকল জেলা' && d.targetDistrict !== address.district) {
        return false;
      }
      if (address.upazila && address.upazila !== 'সকল উপজেলা' && d.targetUpazila && d.targetUpazila !== 'সকল উপজেলা' && d.targetUpazila !== address.upazila) {
        return false;
      }
      return true;
    });
  }, [areaDemands, address.district, address.upazila]);

  // Filtered transport drivers
  const matchedDrivers = useMemo(() => {
    if (!selectedService || selectedService.id !== 'transport') return [];
    return INITIAL_TRANSPORT_DRIVERS.filter(d => {
      // Vehicle category check
      if (selectedVehicleCategory !== 'সকল যানবাহন') {
        const target = selectedVehicleCategory.toLowerCase();
        const driverType = d.vehicleType.toLowerCase();
        if (target.includes('ভ্যান') && !driverType.includes('ভ্যান') && !driverType.includes('রিক্সা')) return false;
        if (target.includes('অ্যাম্বুলেন্স') && !driverType.includes('অ্যাম্বুলেন্স')) return false;
        if (target.includes('হেস্কোভেটর') && !driverType.includes('হেস্কোভেটর') && !driverType.includes('এক্সকাভেটর')) return false;
        if (target.includes('কলেরলাঙ্গল') && !driverType.includes('কলেরলাঙ্গল') && !driverType.includes('টিলার') && !driverType.includes('ট্র্যাক্টর')) return false;
        if (target.includes('নৌকা') && !driverType.includes('নৌকা') && !driverType.includes('খেয়া') && !driverType.includes('ট্রলার')) return false;
        if (!target.includes('ভ্যান') && !target.includes('অ্যাম্বুলেন্স') && !target.includes('হেস্কোভেটর') && !target.includes('কলেরলাঙ্গল') && !target.includes('নৌকা')) {
          if (d.vehicleType !== selectedVehicleCategory) return false;
        }
      }

      // Fare preference check
      if (selectedFarePreference === 'আলোচনা সাপেক্ষে' && d.pricingType && !d.pricingType.includes('আলোচনা')) {
        return false;
      }
      if (selectedFarePreference === 'নির্দিষ্ট ভাড়া' && (!d.pricingType || d.pricingType.includes('আলোচনা'))) {
        return false;
      }

      // District check
      if (address.district && address.district !== 'সকল জেলা' && d.district !== address.district) {
        return false;
      }
      // Upazila check if specified
      if (address.upazila && address.upazila !== 'সকল উপজেলা' && d.upazila && d.upazila !== address.upazila) {
        return false;
      }
      // Union check if specified
      if (address.union && address.union !== 'সকল ইউনিয়ন' && d.unionOrWard && d.unionOrWard !== address.union) {
        return false;
      }
      return true;
    });
  }, [selectedService, address, selectedVehicleCategory, selectedFarePreference]);

  // Filtered haat / labor / tutor listings
  const matchedHaatListings = useMemo(() => {
    if (!selectedService || selectedService.id === 'transport') return [];
    return INITIAL_HAAT_LISTINGS.filter(l => {
      // Category match
      if (selectedService.id === 'labor') {
        if (!l.category.includes('শ্রমিক') && l.itemType !== 'কৃষিন / দিনমজুর' && l.itemType !== 'ধান কাটা/রোপণ কৃষিন' && l.itemType !== 'মাটি কাটা ও ভারী কাজ') return false;
      } else if (selectedService.id === 'tutor') {
        if (!l.category.includes('শিক্ষক') && l.itemType !== 'গৃহশিক্ষক' && l.itemType !== 'শিক্ষার্থী') return false;
      } else if (selectedService.id === 'mechanic') {
        if (!l.category.includes('মেকানিক') && l.itemType !== 'ইলেকট্রিশিয়ান' && l.itemType !== 'মেকানিক') return false;
      } else if (selectedService.id === 'haat') {
        if (
          l.category.includes('শ্রমিক') ||
          l.category.includes('শিক্ষক') ||
          l.category.includes('মেকানিক') ||
          l.itemType?.includes('শ্রমিক') ||
          l.itemType?.includes('কৃষিন') ||
          (l as any).laborType
        ) return false;
      }

      // District match
      if (address.district && address.district !== 'সকল জেলা') {
        const itemDist = l.district || 'ঢাকা';
        if (itemDist !== address.district) return false;
      }
      // Upazila match
      if (address.upazila && address.upazila !== 'সকল উপজেলা' && l.upazila) {
        if (l.upazila !== address.upazila) return false;
      }
      // Union match
      if (address.union && address.union !== 'সকল ইউনিয়ন' && l.unionOrWard) {
        if (l.unionOrWard !== address.union) return false;
      }
      return true;
    });
  }, [selectedService, address]);

  // Handle demand alert submission
  const handleSubmitDemand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!demandTitle.trim()) {
      alert(t('অনুগ্রহ করে বিজ্ঞাপনের শিরোনাম বা কাজের বিবরণ লিখুন', 'Please enter a title or description'));
      return;
    }
    if (!demandSenderPhone.trim()) {
      alert(t('অনুগ্রহ করে আপনার যোগাযোগের মোবাইল নম্বর দিন', 'Please enter your contact mobile number'));
      return;
    }

    setIsSubmittingDemand(true);
    try {
      const generatedId = `demand-${Date.now()}`;
      const serviceOpt = SERVICE_CATEGORIES.find(c => c.id === demandCategory);
      const categoryName = demandCategory === 'transport' 
        ? `জরুরি যানবাহন ডাক (${demandVehicle})` 
        : (serviceOpt?.titleBn || 'জরুরি পেশাদার ডাক');

      const targetRole = demandCategory === 'transport'
        ? (demandVehicle.includes('নৌকা') ? 'boatman' : (demandVehicle.includes('হেস্কোভেটর') || demandVehicle.includes('কলেরলাঙ্গল') ? 'agri_machinery_driver' : 'driver'))
        : (serviceOpt?.roleTarget || 'all');

      await broadcastLocalizedDemandNotification({
        id: generatedId,
        title: demandTitle,
        category: categoryName,
        scope: demandScope === 'district' ? 'district' : 'upazila',
        district: address.district || 'ঢাকা',
        upazila: address.upazila || undefined,
        union: demandScope === 'union' ? address.union : undefined,
        sellerName: demandSenderName || 'এলাকাবাসী',
        phone: demandSenderPhone,
        targetRole: targetRole,
        targetCategory: demandCategory === 'transport' ? 'transport' : 'marketplace',
        allowOfflineCall: allowOfflineCall,
        senderUserId: currentUser?.id,
        senderAvatar: currentUser?.avatarUrl || (currentUser as any)?.customAvatarUrl
      });

      setDemandSuccessMessage(
        t(
          `আপনার জরুরি চাহিদা "${demandTitle}" সফলভাবে পোস্ট করা হয়েছে! নির্বাচিত এলাকার (${address.district}${address.upazila ? ` ➔ ${address.upazila}` : ''}${demandScope === 'union' && address.union ? ` ➔ ${address.union}` : ''}) সংশ্লিষ্ট চালক ও পেশাদারদের মোবাইল নোটিফিকেশন পৌঁছে দেওয়া হয়েছে।`,
          `Your urgent demand "${demandTitle}" was posted! Mobile push notification sent to matching drivers and professionals in your selected area.`
        )
      );

      setDemandTitle('');
      setDemandDescription('');
    } catch (err) {
      console.error('Error posting demand notice:', err);
    } finally {
      setIsSubmittingDemand(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl p-4 sm:p-6 border border-[#E6E0D4] shadow-xs font-['Noto_Sans_Bengali'] space-y-6">
      
      {/* Top Header & Dual Mode Switcher */}
      <div className="space-y-4 border-b border-[#E6E0D4] pb-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#2D5A27] text-white flex items-center justify-center shadow-xs">
              <Compass className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg text-[#2D3A3A] flex items-center gap-2">
                <span>{t('স্মার্ট সেবা ও এলাকা অনুসন্ধান হাব', 'Smart Rural Service & Area Explorer')}</span>
                <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] px-2.5 py-0.5 rounded-full font-bold">
                  {t('আধুনিক ও ঝামেলামুক্ত', 'Modern & Hassle-Free')}
                </span>
              </h2>
              <p className="text-xs text-[#736B5E]">
                {t(
                  'পোস্ট না দিয়ে সরাসরি তালিকা দেখুন অথবা এক ক্লিকে এলাকার সংশ্লিষ্ট চালক-শ্রমিকদের নোটিফিকেশন পাঠান',
                  'Browse verified directory directly or broadcast urgent alerts to local providers'
                )}
              </p>
            </div>
          </div>

          {/* Dual Mode Switcher Tabs */}
          <div className="flex items-center p-1 bg-[#FAF8F5] border border-[#E6E0D4] rounded-2xl">
            <button
              type="button"
              onClick={() => setActiveMode('directory')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeMode === 'directory'
                  ? 'bg-[#2D5A27] text-white shadow-xs'
                  : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
              }`}
            >
              <Search className="w-4 h-4" />
              <span>{t('সরাসরি তালিকা দেখুন', 'Direct Directory')}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveMode('post_demand')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeMode === 'post_demand'
                  ? 'bg-[#E8924A] text-white shadow-xs'
                  : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
              }`}
            >
              <BellRing className="w-4 h-4" />
              <span>{t('📢 চাহিদা পোস্ট ও নোটিফিকেশন', 'Post Demand Alert')}</span>
            </button>
          </div>
        </div>

        {/* Informative Subtitle Notice */}
        <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] flex items-center justify-between gap-3 text-xs text-[#5A6B6B]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#2D5A27] shrink-0" />
            <span>
              {activeMode === 'directory' 
                ? t(
                    'বিজ্ঞাপন বা পোস্ট দেওয়া ছাড়া সরাসরি আশেপাশে থাকা ভেরিফাইড চালক ও দক্ষ পেশাদারদের তালিকা খুঁজুন ও যোগাযোগ করুন।',
                    'Directly browse verified local drivers, laborers and mechanics without submitting public posts.'
                  )
                : t(
                    'কাজের বিবরণ লিখে পোস্ট দিলে আপনার নির্বাচিত এলাকার পেশাদারদের ফোনে পুশ নোটিফিকেশন পৌঁছাবে (যা তাঁরা সেটিংস থেকে নিয়ন্ত্রণ করতে পারেন)।',
                    'Posting a requirement immediately notifies matching professionals in your selected area via mobile push.'
                  )}
            </span>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* MODE 1: DIRECT DIRECTORY & EXPLORER (পদবীধারীদের তালিকা) */}
      {/* ======================================================== */}
      {activeMode === 'directory' && (
        <div className="space-y-6">

          {/* Stepper Navigation Bar */}
          <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 text-xs font-bold">
            <button
              onClick={() => setStep(1)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${
                step === 1 ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FAF8F5] text-[#736B5E] hover:bg-gray-200'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-white/20 text-center text-[10px] leading-4">১</span>
              <span>{t('পেশা বা সেবা নির্বাচন', 'Choose Service')}</span>
            </button>

            <ChevronRight className="w-4 h-4 text-gray-400 shrink-0" />

            <button
              onClick={() => setStep(2)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${
                step === 2 ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FAF8F5] text-[#736B5E] hover:bg-gray-200'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-white/20 text-center text-[10px] leading-4">২</span>
              <span>{t('বাহন ও এলাকা নির্বাচন', 'Vehicle & Location')}</span>
            </button>

            <ChevronRight className="w-4 h-4 text-gray-400 shrink-0" />

            <button
              onClick={() => setStep(3)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${
                step === 3 ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FAF8F5] text-[#736B5E] hover:bg-gray-200'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-white/20 text-center text-[10px] leading-4">৩</span>
              <span>{t('সরাসরি তালিকা ও যোগাযোগ', 'Directory & Call')}</span>
            </button>
          </div>

          {/* STEP 1: CHOOSE PROFESSION / SERVICE */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A]">
                    {t('১ম ধাপ: আপনি কোন সেবার পদবীধারী বা চালক খুঁজছেন?', 'Step 1: Which service or professional do you need?')}
                  </h3>
                  <p className="text-xs text-[#736B5E] mt-0.5">
                    {t('যেকোনো একটি সেবা বেছে নিয়ে সহজে এলাকাভিত্তিক তালিকা দেখুন', 'Select a service to browse localized verified professionals')}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {SERVICE_CATEGORIES.map((cat) => {
                  const isSelected = selectedService.id === cat.id;
                  return (
                    <div
                      key={cat.id}
                      onClick={() => {
                        setSelectedService(cat);
                        setStep(2);
                      }}
                      className={`p-4 rounded-2xl border-2 transition-all cursor-pointer space-y-2 relative shadow-2xs group hover:scale-[1.01] ${
                        isSelected
                          ? 'border-[#2D5A27] bg-[#FDFBF7]'
                          : 'border-[#E6E0D4] bg-white hover:border-[#2D5A27]/60 hover:bg-[#FAF8F5]'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${cat.bgColor}`}>
                          {cat.icon}
                        </div>
                        <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] font-bold px-2 py-0.5 rounded-full">
                          {language === 'en' ? cat.badgeEn : cat.badgeBn}
                        </span>
                      </div>

                      <div>
                        <h4 className="font-bold text-sm text-[#2D3A3A] group-hover:text-[#2D5A27] transition">
                          {language === 'en' ? cat.titleEn : cat.titleBn}
                        </h4>
                        <p className="text-xs text-[#736B5E] mt-0.5 line-clamp-2">
                          {language === 'en' ? cat.descEn : cat.descBn}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-1 text-xs font-bold text-[#2D5A27]">
                        <span>{t('পরের ধাপে যান', 'Proceed to next step')}</span>
                        <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 2: CHOOSE SPECIFIC VEHICLE & LOCATION */}
          {step === 2 && (
            <div className="space-y-5 max-w-3xl mx-auto">
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-[#736B5E] hover:text-[#2D3A3A] cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>{t('সেবা পরিবর্তনে ফিরে যান', 'Back to service selection')}</span>
                </button>
                <span className="text-xs bg-[#D4E4BC] text-[#2D5A27] px-3 py-1 rounded-full font-bold">
                  {language === 'en' ? selectedService.titleEn : selectedService.titleBn}
                </span>
              </div>

              {/* If Transport is selected: Clean Dedicated Vehicle Grid */}
              {selectedService.id === 'transport' && (
                <div className="bg-[#FAF8F5] p-4 sm:p-5 rounded-3xl border border-[#E6E0D4] space-y-3 shadow-2xs">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-2">
                      <Car className="w-4 h-4 text-[#2D5A27]" />
                      <span>{t('কিসের চালক দরকার? সুনির্দিষ্ট বাহন বেছে নিন:', 'Which vehicle driver do you need?')}</span>
                    </h4>
                    <span className="text-xs font-bold text-[#2D5A27] bg-white px-2.5 py-0.5 rounded-lg border border-[#E6E0D4]">
                      {selectedVehicleCategory}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 pt-1">
                    {VEHICLE_OPTIONS.map((v) => {
                      const isSelected = selectedVehicleCategory === v.id;
                      return (
                        <button
                          key={v.id}
                          type="button"
                          onClick={() => setSelectedVehicleCategory(v.id)}
                          className={`p-2.5 rounded-xl border text-left transition flex items-center gap-2 cursor-pointer ${
                            isSelected
                              ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-xs'
                              : 'bg-white text-[#2D3A3A] border-[#E6E0D4] hover:border-[#2D5A27]/60'
                          }`}
                        >
                          <span className="text-lg shrink-0">{v.icon}</span>
                          <div className="min-w-0">
                            <p className="text-xs font-bold truncate leading-tight">
                              {language === 'en' ? v.labelEn : v.labelBn}
                            </p>
                            {v.badge && (
                              <span className={`text-[9px] px-1.5 py-0.2 rounded font-medium ${
                                isSelected ? 'bg-white/20 text-white' : 'bg-[#D4E4BC]/60 text-[#2D5A27]'
                              }`}>
                                {v.badge}
                              </span>
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Fare preference filter */}
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#E6E0D4]">
                    <span className="text-xs font-bold text-[#5A6B6B]">{t('ভাড়া পদ্ধতি:', 'Fare type:')}</span>
                    {(['সকল ভাড়া', 'আলোচনা সাপেক্ষে', 'নির্দিষ্ট ভাড়া'] as const).map((fare) => (
                      <button
                        key={fare}
                        type="button"
                        onClick={() => setSelectedFarePreference(fare)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                          selectedFarePreference === fare
                            ? 'bg-[#2D5A27] text-white'
                            : 'bg-white text-[#5A6B6B] border border-[#E6E0D4] hover:text-black'
                        }`}
                      >
                        {fare === 'সকল ভাড়া' ? t('সকল ভাড়া', 'All Fares') : (fare === 'আলোচনা সাপেক্ষে' ? t('আলোচনা সাপেক্ষে', 'Negotiable') : t('নির্দিষ্ট ভাড়া', 'Fixed Rate'))}
                      </button>
                    ))}

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedDriverForFare(null);
                        setIsFareModalOpen(true);
                      }}
                      className="ml-auto bg-[#E8924A] hover:bg-[#D97D35] text-white px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 shadow-2xs cursor-pointer"
                    >
                      <Calculator className="w-3.5 h-3.5" />
                      <span>{t('স্মার্ট ভাড়া হিসাবক', 'Fare Calculator')}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Address Selection Card */}
              <div className="bg-[#FAF8F5] p-5 rounded-3xl border border-[#E6E0D4] space-y-4 shadow-2xs">
                <div>
                  <h4 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#2D5A27]" />
                    <span>{t('এলাকা বা ইউনিয়ন নির্বাচন করুন', 'Select District, Upazila & Union')}</span>
                  </h4>
                  <p className="text-xs text-[#736B5E] mt-0.5">
                    {t(
                      'জেলা ➔ উপজেলা ➔ ইউনিয়ন নির্বাচন করুন। আপনি চাইলে শুধু জেলা নির্বাচন করেও পুরো জেলার তালিকা দেখতে পারবেন।',
                      'Choose District ➔ Upazila ➔ Union. You may also view all listings for the entire district.'
                    )}
                  </p>
                </div>

                <CascadingAddressSelector
                  value={address}
                  onChange={setAddress}
                  layout="grid-2x2"
                  allowAllOption={true}
                  allDistrictLabel={t('সকল জেলা', 'All Districts')}
                  allUpazilaLabel={t('সকল উপজেলা (ঐচ্ছিক)', 'All Upazilas (Optional)')}
                  allUnionLabel={t('সকল ইউনিয়ন (ঐচ্ছিক)', 'All Unions (Optional)')}
                  showAddAreaButton={true}
                />

                <div className="flex items-center justify-between pt-3 border-t border-[#E6E0D4]">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-[#736B5E] hover:bg-gray-100 transition cursor-pointer"
                  >
                    {t('পেছনে', 'Back')}
                  </button>

                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-sm transition cursor-pointer flex items-center gap-1.5"
                  >
                    <span>{t('তালিকা ও ফলাফল দেখুন', 'View Directory & Results')}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

            </div>
          )}

          {/* STEP 3: DIRECTORY RESULTS & COMMUNICATION */}
          {step === 3 && (
            <div className="space-y-4">
              
              {/* Active Filter Summary Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4]">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setStep(2)}
                    className="p-1.5 rounded-xl bg-white border border-[#E6E0D4] text-[#736B5E] hover:text-[#2D3A3A] cursor-pointer"
                    title={t('ফিল্টার পরিবর্তন করুন', 'Change Filters')}
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                  <div>
                    <span className="text-xs font-bold text-[#2D3A3A]">
                      {language === 'en' ? selectedService.titleEn : selectedService.titleBn}: {selectedService.id === 'transport' ? selectedVehicleCategory : ''} ({address.district || t('সকল জেলা', 'All Districts')}{address.upazila ? ` ➔ ${address.upazila}` : ''}{address.union ? ` ➔ ${address.union}` : ''})
                    </span>
                    <p className="text-[11px] text-[#736B5E]">
                      {t(
                        'সরাসরি ফোন কল, অ্যাপ-টু-অ্যাপ ফ্রি কল, অডিও বার্তা ও ভাড়ার হিসাবক উপলব্ধ',
                        'Direct SIM call, free in-app audio call, voice notes & fare estimator available'
                      )}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {selectedService.id === 'transport' && (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedDriverForFare(null);
                        setIsFareModalOpen(true);
                      }}
                      className="bg-white border border-[#D4C3A3] hover:border-[#2D5A27] text-[#2D5A27] px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
                    >
                      <Calculator className="w-3.5 h-3.5" />
                      <span>{t('ভাড়া হিসাবক', 'Fare Calc')}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => setActiveMode('post_demand')}
                    className="bg-[#E8924A] hover:bg-[#D97D35] text-white px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer shadow-2xs flex items-center gap-1"
                  >
                    <BellRing className="w-3.5 h-3.5" />
                    <span>{t('জরুরি ডাক দিন', 'Post Demand')}</span>
                  </button>
                </div>
              </div>

              {/* Quick Vehicle Switcher if Transport */}
              {selectedService.id === 'transport' && (
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                  {VEHICLE_OPTIONS.map((v) => (
                    <button
                      key={v.id}
                      type="button"
                      onClick={() => setSelectedVehicleCategory(v.id)}
                      className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer text-xs flex items-center gap-1 ${
                        selectedVehicleCategory === v.id
                          ? 'bg-[#2D5A27] text-white shadow-2xs'
                          : 'bg-white text-[#5A6B6B] border border-[#E6E0D4] hover:bg-gray-100'
                      }`}
                    >
                      <span>{v.icon}</span>
                      <span>{language === 'en' ? v.labelEn : v.labelBn}</span>
                    </button>
                  ))}
                </div>
              )}

              {/* Results Display */}
              {selectedService.id === 'transport' ? (
                matchedDrivers.length === 0 ? (
                  <div className="p-8 text-center bg-[#FAF8F5] rounded-3xl border border-[#E6E0D4] space-y-4">
                    <Car className="w-12 h-12 text-gray-400 mx-auto" />
                    <div>
                      <h4 className="font-bold text-sm text-[#2D3A3A]">
                        {t(
                          `এই এলাকায় "${selectedVehicleCategory}" ক্যাটাগরির নিবন্ধিত চালক সরাসরি পাওয়া যায়নি`,
                          `No registered driver found for "${selectedVehicleCategory}" in this immediate area`
                        )}
                      </h4>
                      <p className="text-xs text-[#736B5E] max-w-md mx-auto mt-1">
                        {t(
                          'আপনি পুরো জেলার সব চালকদের তালিকা দেখতে পারেন অথবা এক ক্লিকে এই এলাকায় চালকের জন্য বিজ্ঞাপন বা নোটিফিকেশন পাঠাতে পারেন।',
                          'You can view all district drivers or broadcast a demand notice to matching local drivers.'
                        )}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                      {selectedVehicleCategory !== 'সকল যানবাহন' && (
                        <button
                          type="button"
                          onClick={() => setSelectedVehicleCategory('সকল যানবাহন')}
                          className="px-4 py-2 bg-white border border-[#2D5A27] text-[#2D5A27] rounded-xl text-xs font-bold transition cursor-pointer"
                        >
                          {t('সকল যানবাহন দেখুন', 'View All Vehicles')}
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          setAddress(prev => ({ ...prev, upazila: '', union: '' }));
                        }}
                        className="px-4 py-2 bg-white border border-[#D4C3A3] text-[#2D3A3A] rounded-xl text-xs font-bold transition cursor-pointer"
                      >
                        {t('পুরো জেলার তালিকা দেখুন', 'View Entire District')}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setActiveMode('post_demand');
                          setDemandCategory('transport');
                          setDemandVehicle(selectedVehicleCategory === 'সকল যানবাহন' ? 'ভ্যান ও রিক্সা' : selectedVehicleCategory);
                        }}
                        className="px-4 py-2 bg-[#E8924A] hover:bg-[#D97D35] text-white rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-2xs"
                      >
                        <BellRing className="w-3.5 h-3.5" />
                        <span>{t('📢 এই এলাকায় চালকের জরুরি ডাক দিন', 'Broadcast Driver Request')}</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {matchedDrivers.map((driver) => (
                      <div
                        key={driver.id}
                        className="p-4 rounded-2xl bg-white border border-[#E6E0D4] hover:border-[#2D5A27] shadow-2xs space-y-3 transition"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            {driver.facePhotoUrl ? (
                              <img
                                src={driver.facePhotoUrl}
                                alt={driver.driverName}
                                className="w-12 h-12 rounded-2xl object-cover border border-[#2D5A27]"
                              />
                            ) : (
                              <div className="w-12 h-12 rounded-2xl bg-[#2D5A27] text-white font-bold text-base flex items-center justify-center">
                                {driver.driverName.charAt(0)}
                              </div>
                            )}
                            <div>
                              <h4 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-1.5">
                                <span>{driver.driverName}</span>
                                {driver.isVerified && (
                                  <ShieldCheck className="w-4 h-4 text-[#27AE60]" title={t('যাচাইকৃত চালক', 'Verified Driver')} />
                                )}
                              </h4>
                              <p className="text-xs text-[#2D5A27] font-semibold">{driver.vehicleType}</p>
                              <div className="flex items-center gap-2 text-[11px] text-[#736B5E] mt-0.5">
                                <span className="flex items-center gap-0.5 text-[#E8924A] font-bold">
                                  <Star className="w-3 h-3 fill-current" />
                                  <span>{driver.rating || 4.9}</span>
                                </span>
                                <span>•</span>
                                <span>{driver.standLocation || driver.village}</span>
                              </div>
                            </div>
                          </div>

                          <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] font-bold px-2 py-0.5 rounded-full shrink-0">
                            {driver.pricingType || t('আলোচনা সাপেক্ষে', 'Negotiable')}
                          </span>
                        </div>

                        {/* Regular route / area */}
                        {driver.regularRoutes && (
                          <div className="bg-[#FAF8F5] p-2 rounded-xl text-[11px] text-[#5A6B6B] flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-[#2D5A27] shrink-0" />
                            <span className="truncate">{driver.regularRoutes}</span>
                          </div>
                        )}

                        {/* Action Buttons: 2 Clean Rows */}
                        <div className="space-y-1.5 pt-2 border-t border-[#E6E0D4]">
                          {/* Row 1: Direct Communication */}
                          <div className="grid grid-cols-4 gap-1.5">
                            {/* SIM Call */}
                            <button
                              type="button"
                              onClick={() => {
                                setActiveCallChoice({
                                  name: driver.driverName,
                                  role: 'driver',
                                  phone: driver.phone,
                                  photo: driver.facePhotoUrl,
                                  subtitle: `${driver.vehicleType} (${driver.standLocation})`
                                });
                              }}
                              className="bg-[#2D5A27] hover:bg-[#23491E] text-white py-1.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer shadow-2xs"
                              title={t('সরাসরি ফোন কল', 'Direct Phone Call')}
                            >
                              <Phone className="w-3 h-3" />
                              <span>{t('কল', 'Call')}</span>
                            </button>

                            {/* In-App Audio Call */}
                            <button
                              type="button"
                              onClick={() => {
                                handleStartInAppCall({
                                  name: driver.driverName,
                                  role: 'driver',
                                  phone: driver.phone,
                                  photo: driver.facePhotoUrl,
                                  subtitle: `${driver.vehicleType} (${driver.standLocation || driver.village})`
                                });
                              }}
                              className="bg-[#D4E4BC] hover:bg-[#2D5A27] text-[#2D5A27] hover:text-white py-1.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer shadow-2xs"
                              title={t('অ্যাপ-টু-অ্যাপ ফ্রি কল', 'Free In-App Call')}
                            >
                              <PhoneCall className="w-3 h-3" />
                              <span>{t('ফ্রি কল', 'In-App')}</span>
                            </button>

                            {/* Voice Message */}
                            <button
                              type="button"
                              onClick={() => {
                                setActiveVoiceRecipient({
                                  name: driver.driverName,
                                  role: 'driver',
                                  phone: driver.phone,
                                  avatar: driver.facePhotoUrl,
                                  itemTitle: `${driver.vehicleType} - ${driver.standLocation}`
                                });
                              }}
                              className="bg-[#FAF8F5] border border-[#E6E0D4] hover:border-[#2D5A27] text-[#2D3A3A] py-1.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer"
                              title={t('ভয়েস বার্তা পাঠান', 'Send Voice Note')}
                            >
                              <Mic className="w-3 h-3 text-[#2D5A27]" />
                              <span>{t('ভয়েস', 'Voice')}</span>
                            </button>

                            {/* Text Message */}
                            <button
                              type="button"
                              onClick={() => {
                                setActiveChatRecipient({
                                  id: driver.id,
                                  name: driver.driverName,
                                  role: 'driver',
                                  phone: driver.phone,
                                  avatar: driver.facePhotoUrl,
                                  itemTitle: driver.vehicleType
                                });
                              }}
                              className="bg-[#FAF8F5] border border-[#E6E0D4] hover:border-[#2D5A27] text-[#2D3A3A] py-1.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer"
                              title={t('টেক্সট মেসেজ পাঠান', 'Send Text Message')}
                            >
                              <MessageSquare className="w-3 h-3 text-[#2D5A27]" />
                              <span>{t('মেসেজ', 'Chat')}</span>
                            </button>
                          </div>

                          {/* Row 2: Smart Calculator & Review */}
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedDriverForFare(driver);
                                setIsFareModalOpen(true);
                              }}
                              className="flex-1 bg-white border border-[#D4C3A3] text-[#2D5A27] hover:bg-[#FAF8F5] py-1 px-2 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition cursor-pointer"
                            >
                              <Calculator className="w-3 h-3" />
                              <span>{t('স্মার্ট ভাড়া হিসাবক', 'Fare Estimator')}</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                setActiveReviewTarget({
                                  id: driver.id,
                                  name: driver.driverName,
                                  role: 'driver',
                                  serviceType: 'transport'
                                });
                              }}
                              className="bg-[#FFF9E6] border border-[#F39C12]/40 text-[#B7791F] py-1 px-3 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition cursor-pointer"
                            >
                              <Star className="w-3 h-3 fill-current" />
                              <span>{t('রিভিউ দিন', 'Review')}</span>
                            </button>
                          </div>
                        </div>

                      </div>
                    ))}
                  </div>
                )
              ) : (
                /* Non-transport services (Labor, Tutor, Mechanic, Haat) */
                matchedHaatListings.length === 0 ? (
                  <div className="p-8 text-center bg-[#FAF8F5] rounded-3xl border border-[#E6E0D4] space-y-4">
                    <Users className="w-12 h-12 text-gray-400 mx-auto" />
                    <div>
                      <h4 className="font-bold text-sm text-[#2D3A3A]">
                        {t(
                          `এই নির্দিষ্ট এলাকায় কোনো ${selectedService.titleBn} সরাসরি পাওয়া যায়নি`,
                          `No listings found for this category in this location`
                        )}
                      </h4>
                      <p className="text-xs text-[#736B5E] max-w-sm mx-auto mt-1">
                        {t(
                          'আপনি জেলা ভিত্তিক দেখতে পারেন অথবা এক ক্লিকে আপনার কাজের জন্য এলাকার পেশাদারদের নোটিফিকেশন পাঠাতে পারেন।',
                          'Expand to district level or post an urgent requirement to notify local workers.'
                        )}
                      </p>
                    </div>

                    <div className="flex items-center justify-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setAddress(prev => ({ ...prev, upazila: '', union: '' }));
                        }}
                        className="px-4 py-2 bg-white border border-[#D4C3A3] rounded-xl text-xs font-bold cursor-pointer"
                      >
                        {t('পুরো জেলার তালিকা দেখুন', 'View Whole District')}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setActiveMode('post_demand');
                          setDemandCategory(selectedService.id);
                        }}
                        className="px-4 py-2 bg-[#E8924A] hover:bg-[#D97D35] text-white rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-2xs"
                      >
                        <BellRing className="w-3.5 h-3.5" />
                        <span>{t('📢 এই এলাকায় জরুরি কাজের ডাক দিন', 'Post Requirement')}</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                    {matchedHaatListings.map((item) => (
                      <div
                        key={item.id}
                        className="p-4 rounded-2xl bg-white border border-[#E6E0D4] hover:border-[#2D5A27] shadow-2xs space-y-3 transition flex flex-col justify-between"
                      >
                        <div>
                          {item.imageUrl && (
                            <img
                              src={item.imageUrl}
                              alt={item.title}
                              className="w-full h-32 rounded-xl object-cover mb-2 border border-gray-100"
                            />
                          )}
                          <div className="flex items-start justify-between gap-1.5">
                            <h4 className="font-bold text-xs text-[#2D3A3A] line-clamp-1">{item.title}</h4>
                            <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] font-bold px-2 py-0.5 rounded-full shrink-0">
                              {item.price ? `৳ ${item.price}` : t('আলোচনা সাপেক্ষে', 'Negotiable')}
                            </span>
                          </div>
                          <p className="text-[11px] text-[#5A6B6B] mt-1 line-clamp-2">{item.description}</p>
                          
                          <div className="flex items-center gap-1 text-[10px] text-[#736B5E] mt-2">
                            <MapPin className="w-3 h-3 text-[#2D5A27]" />
                            <span>{item.district || 'ঢাকা'}{item.upazila ? `, ${item.upazila}` : ''}</span>
                          </div>
                        </div>

                        {/* Action buttons */}
                        <div className="flex items-center gap-1.5 pt-2 border-t border-[#E6E0D4]">
                          <button
                            type="button"
                            onClick={() => {
                              handleStartInAppCall({
                                name: item.sellerName,
                                role: 'seller',
                                phone: item.phone,
                                subtitle: `${item.title} (${item.district || 'ঢাকা'})`
                              });
                            }}
                            className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white py-1.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer shadow-2xs"
                          >
                            <PhoneCall className="w-3 h-3" />
                            <span>{t('কল', 'Call')}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setActiveVoiceRecipient({
                                name: item.sellerName,
                                role: 'seller',
                                phone: item.phone,
                                itemTitle: item.title
                              });
                            }}
                            className="bg-[#D4E4BC] hover:bg-[#2D5A27] text-[#2D5A27] hover:text-white py-1.5 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer shadow-2xs"
                            title={t('ভয়েস চ্যাট পাঠান', 'Send Voice Note')}
                          >
                            <Mic className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">{t('ভয়েস', 'Voice')}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setActiveChatRecipient({
                                id: item.sellerId || item.id,
                                name: item.sellerName,
                                role: 'seller',
                                phone: item.phone,
                                itemTitle: item.title
                              });
                            }}
                            className="bg-white border border-[#D4C3A3] hover:border-[#2D5A27] text-[#2D3A3A] py-1.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-[#2D5A27]" />
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setActiveReviewTarget({
                                id: item.sellerId || item.id,
                                name: item.sellerName,
                                role: 'seller',
                                serviceType: 'haat'
                              });
                            }}
                            className="bg-[#FFF9E6] border border-[#F39C12]/40 text-[#B7791F] py-1.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer"
                          >
                            <Star className="w-3 h-3 fill-current" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )
              )}

            </div>
          )}

        </div>
      )}

      {/* ======================================================== */}
      {/* MODE 2: POST DEMAND / URGENT NOTICE (চাহিদা বা বিজ্ঞাপনের ডাক) */}
      {/* ======================================================== */}
      {activeMode === 'post_demand' && (
        <div className="space-y-5 max-w-2xl mx-auto">
          
          <div className="bg-[#FFF9F2] p-4 sm:p-5 rounded-3xl border border-[#F5D5B8] space-y-2">
            <div className="flex items-center gap-2 text-[#C05621] font-bold text-sm">
              <BellRing className="w-5 h-5" />
              <span>{t('জরুরি চাহিদা বা কাজের বিজ্ঞাপনের ডাক দিন', 'Post Demand / Local Urgent Call')}</span>
            </div>
            <p className="text-xs text-[#7B341E] leading-relaxed">
              {t(
                'আপনি চালক, কৃষিন দিনমজুর শ্রমিক, মেকানিক বা শিক্ষক খুঁজলে এখানে পোস্ট দিন। আপনার নির্বাচিত এলাকার সংশ্লিষ্ট পেশাদারদের ফোনে তাৎক্ষণিক নোটিফিকেশন পৌঁছে যাবে। পেশাদাররা চাইলে তাদের সেটিংস থেকে নোটিফিকেশন বন্ধ বা চালু রাখতে পারেন।',
                'Post if you need a driver, agricultural laborer, electrician or tutor. Matching local professionals receive instant mobile alerts based on their notification settings.'
              )}
            </p>
          </div>

          {demandSuccessMessage && (
            <div className="bg-[#EBF8EE] p-4 rounded-2xl border border-[#27AE60]/40 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-[#27AE60] shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="text-xs font-bold text-[#1B4D3E]">{demandSuccessMessage}</p>
                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setDemandSuccessMessage(null);
                      setActiveMode('directory');
                      setStep(3);
                    }}
                    className="px-3 py-1.5 bg-[#2D5A27] text-white rounded-xl text-xs font-bold cursor-pointer"
                  >
                    {t('তালিকা পেজে ফিরে যান', 'Back to Directory')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setDemandSuccessMessage(null)}
                    className="px-3 py-1.5 bg-white border border-[#D4C3A3] text-[#2D3A3A] rounded-xl text-xs font-bold cursor-pointer"
                  >
                    {t('আরেকটি নতুন পোস্ট দিন', 'Post Another')}
                  </button>
                </div>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmitDemand} className="bg-[#FAF8F5] p-5 rounded-3xl border border-[#E6E0D4] space-y-4 shadow-2xs">
            
            {/* 1. Category Selection */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                <span>{t('১. আপনার কী সেবা বা পেশাদার দরকার?', '1. What service or professional do you need?')}</span>
              </label>
              <select
                value={demandCategory}
                onChange={(e) => setDemandCategory(e.target.value)}
                className="w-full bg-white border border-[#D4C3A3] rounded-xl p-2.5 text-xs font-bold text-[#2D3A3A] focus:ring-2 focus:ring-[#2D5A27] outline-hidden"
              >
                <option value="transport">{t('যানবাহন ও চালক দরকার (ভ্যান, রিক্সা, কার, অ্যাম্বুলেন্স, নৌকা ইত্যাদি)', 'Driver / Vehicle Needed')}</option>
                <option value="labor">{t('কৃষিন ও দিনমজুর শ্রমিক দরকার (ধান কাটা, রোপণ, মাটি কাটা)', 'Agricultural / Day Laborers Needed')}</option>
                <option value="mechanic">{t('মেকানিক ও ইলেকট্রিশিয়ান দরকার (মটর, ওয়্যারিং, টিউবওয়েল)', 'Mechanic / Electrician Needed')}</option>
                <option value="tutor">{t('গৃহশিক্ষক বা টিউটর দরকার (গণিত, বিজ্ঞান, কোরআন)', 'Home Tutor Needed')}</option>
                <option value="blood">{t('জরুরি রক্তদাতা দরকার (ব্লাড ডোনার)', 'Urgent Blood Donor Needed')}</option>
              </select>
            </div>

            {/* If Transport: Specific Vehicle Choice */}
            {demandCategory === 'transport' && (
              <div className="space-y-1.5 bg-white p-3 rounded-2xl border border-[#E6E0D4]">
                <label className="text-xs font-bold text-[#2D5A27]">
                  {t('কোন নির্দিষ্ট বাহনটি আপনার দরকার?', 'Which specific vehicle do you need?')}
                </label>
                <select
                  value={demandVehicle}
                  onChange={(e) => setDemandVehicle(e.target.value)}
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2 text-xs font-bold text-[#2D3A3A]"
                >
                  {VEHICLE_OPTIONS.filter(v => v.id !== 'সকল যানবাহন').map(v => (
                    <option key={v.id} value={v.id}>
                      {v.icon} {v.labelBn}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* 2. Notification Scope (এলাকার পরিধি) */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                <Radio className="w-4 h-4 text-[#2D5A27]" />
                <span>{t('২. নোটিফিকেশন কত দূর পর্যন্ত যাবে? (পরিধি)', '2. Notification Broadcast Scope')}</span>
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setDemandScope('union')}
                  className={`p-2.5 rounded-xl border text-center transition cursor-pointer text-xs font-bold ${
                    demandScope === 'union'
                      ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-2xs'
                      : 'bg-white text-[#5A6B6B] border-[#E6E0D4] hover:bg-gray-100'
                  }`}
                >
                  📍 {t('শুধু আমার ইউনিয়ন', 'My Union Only')}
                </button>
                <button
                  type="button"
                  onClick={() => setDemandScope('upazila')}
                  className={`p-2.5 rounded-xl border text-center transition cursor-pointer text-xs font-bold ${
                    demandScope === 'upazila'
                      ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-2xs'
                      : 'bg-white text-[#5A6B6B] border-[#E6E0D4] hover:bg-gray-100'
                  }`}
                >
                  📍 {t('পুরো উপজেলা', 'Entire Upazila')}
                </button>
                <button
                  type="button"
                  onClick={() => setDemandScope('district')}
                  className={`p-2.5 rounded-xl border text-center transition cursor-pointer text-xs font-bold ${
                    demandScope === 'district'
                      ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-2xs'
                      : 'bg-white text-[#5A6B6B] border-[#E6E0D4] hover:bg-gray-100'
                  }`}
                >
                  📍 {t('পুরো জেলা', 'Entire District')}
                </button>
              </div>
            </div>

            {/* 3. Location Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#2D3A3A]">
                {t('৩. আপনার এলাকা (জেলা ➔ উপজেলা ➔ ইউনিয়ন)', '3. Your Location')}
              </label>
              <CascadingAddressSelector
                value={address}
                onChange={setAddress}
                layout="grid-2x2"
                allowAllOption={false}
                showAddAreaButton={true}
              />
            </div>

            {/* 4. Title & Description */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#2D3A3A]">
                {t('৪. বিজ্ঞাপনের শিরোনাম (সংক্ষেপে)', '4. Notice Title (Brief)')}
              </label>
              <input
                type="text"
                value={demandTitle}
                onChange={(e) => setDemandTitle(e.target.value)}
                placeholder={
                  demandCategory === 'transport'
                    ? t('যেমন: সাভার বাজার থেকে ঢাকা মেডিকেলে জরুরি রোগী নিতে অ্যাম্বুলেন্স লাগবে', 'e.g. Need urgent ambulance from Savar to DMCH')
                    : (demandCategory === 'labor'
                        ? t('যেমন: কাল সকালে ৫ জন অভিজ্ঞ ধান কাটার কৃষিন শ্রমিক প্রয়োজন', 'e.g. Need 5 experienced laborers for paddy harvest tomorrow')
                        : t('কাজের শিরোনাম ও কী সাহায্য দরকার লিখুন', 'Enter title and required assistance'))
                }
                className="w-full bg-white border border-[#D4C3A3] rounded-xl p-2.5 text-xs text-[#2D3A3A] focus:ring-2 focus:ring-[#2D5A27] outline-hidden font-medium"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#2D3A3A]">
                {demandCategory === 'labor'
                  ? t('৫. কাজের বিস্তারিত বিবরণ ও মজুরি (ঐচ্ছিক)', '5. Work Details & Wage (Optional)')
                  : demandCategory === 'transport'
                  ? t('৫. ভ্রমণের বিস্তারিত বিবরণ ও প্রস্তাবিত ভাড়া (ঐচ্ছিক)', '5. Trip Details & Expected Fare (Optional)')
                  : demandCategory === 'mechanic'
                  ? t('৫. মেরামতের বিবরণ ও প্রস্তাবিত সার্ভিস ফি (ঐচ্ছিক)', '5. Repair Details & Service Fee (Optional)')
                  : demandCategory === 'tutor'
                  ? t('৫. পড়ানোর বিষয়, শ্রেণি ও সম্মানী (ঐচ্ছিক)', '5. Subject, Class & Tuition Fee (Optional)')
                  : demandCategory === 'blood'
                  ? t('৫. রোগীর অবস্থা, রক্তের প্রয়োজনীয়তা ও হাসপাতাল (ঐচ্ছিক)', '5. Patient Status, Hospital & Details (Optional)')
                  : t('৫. বিস্তারিত বিবরণ ও বাজেট (ঐচ্ছিক)', '5. Details & Budget (Optional)')}
              </label>
              <textarea
                value={demandDescription}
                onChange={(e) => setDemandDescription(e.target.value)}
                rows={3}
                placeholder={
                  demandCategory === 'labor'
                    ? t('কাজের ধরন, সময়, দৈনিক মজুরি আলোচনা সাপেক্ষে কিনা বা বিশেষ কোনো শর্ত থাকলে উল্লেখ করুন...', 'Work type, timing, daily wage or conditions...')
                    : demandCategory === 'transport'
                    ? t('যাত্রা শুরুর স্থান, গন্তব্য, যাত্রী সংখ্যা ও প্রস্তাবিত ভাড়া উল্লেখ করুন...', 'Pickup/drop locations, passenger count and expected fare...')
                    : demandCategory === 'mechanic'
                    ? t('কী সমস্যা, যন্ত্রপাতির বিবরণ ও সার্ভিস চার্জ আলোচনা সাপেক্ষে কিনা উল্লেখ করুন...', 'Issue description, appliance details or fee conditions...')
                    : demandCategory === 'tutor'
                    ? t('কোন কোন বিষয়, সপ্তাহে কত দিন ও টিউশন ফি উল্লেখ করুন...', 'Subjects, days per week and tuition fee...')
                    : demandCategory === 'blood'
                    ? t('হাসপাতালের নাম, বেড নম্বর ও রোগীর বর্তমান অবস্থা উল্লেখ করুন...', 'Hospital name, bed number and patient condition...')
                    : t('বিস্তারিত বিবরণ বা কোনো বিশেষ শর্ত থাকলে উল্লেখ করুন...', 'Details or special conditions...')
                }
                className="w-full bg-white border border-[#D4C3A3] rounded-xl p-2.5 text-xs text-[#2D3A3A] focus:ring-2 focus:ring-[#2D5A27] outline-hidden font-medium"
              />
            </div>

            {/* 6. Contact Info & Offline Call Control */}
            <div className="bg-white p-4 rounded-2xl border border-[#E6E0D4] space-y-3.5">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#2D5A27]" />
                  <span>{t('যোগাযোগের তথ্য ও গোপনীয়তা নিয়ন্ত্রণ', 'Contact Info & Privacy Control')}</span>
                </span>
                {currentUser && (
                  <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] px-2 py-0.5 rounded-full font-bold">
                    ✓ {t('প্রোফাইল থেকে স্বয়ংক্রিয় পূরণকৃত', 'Auto-filled from Profile')}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-0.5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A]">{t('আপনার নাম', 'Your Name')}</label>
                  <input
                    type="text"
                    value={demandSenderName}
                    onChange={(e) => setDemandSenderName(e.target.value)}
                    placeholder={t('আপনার নাম লিখুন', 'Enter your name')}
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 text-xs text-[#2D3A3A] font-bold focus:ring-2 focus:ring-[#2D5A27] outline-hidden"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] flex items-center justify-between">
                    <span>{t('মোবাইল নম্বর (যোগাযোগের জন্য)', 'Mobile Phone Number')}</span>
                    <span className="text-[10px] text-[#736B5E] font-normal">
                      {allowOfflineCall ? 'সরাসরি কল উন্মুক্ত' : 'নম্বর গোপন রাখা হবে'}
                    </span>
                  </label>
                  <input
                    type="tel"
                    value={demandSenderPhone}
                    onChange={(e) => setDemandSenderPhone(e.target.value)}
                    placeholder="017xxxxxxxx"
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 text-xs text-[#2D3A3A] font-bold focus:ring-2 focus:ring-[#2D5A27] outline-hidden"
                  />
                </div>
              </div>

              {/* OFFLINE CALL & PRIVACY TOGGLE */}
              <div className="p-3 rounded-xl border border-[#E6E0D4] bg-[#FAF8F5] space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    <div className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center mt-0.5 ${
                      allowOfflineCall ? 'bg-amber-100 text-amber-700' : 'bg-[#EAF2E8] text-[#2D5A27]'
                    }`}>
                      {allowOfflineCall ? <PhoneCall className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                        <span>{allowOfflineCall ? t('অফলাইন সরাসরি সাধারণ কল: চালু', 'Offline Direct SIM Calls: Enabled') : t('অনলাইন কল ও চ্যাট সুরক্ষা: চালু (প্রস্তাবিত)', 'In-App Online First & Number Protected (Recommended)')}</span>
                      </p>
                      <p className="text-[11px] text-[#5A6B6B] mt-0.5 leading-relaxed">
                        {allowOfflineCall
                          ? t('অনুমোদিত: চালক বা শ্রমিকরা বিজ্ঞাপনের পর সরাসরি আপনার সাধারণ নম্বরেও ফোন ডায়াল করতে পারবেন।', 'Others can dial your regular mobile number directly.')
                          : t('সুরক্ষিত: আপনার ফোন নম্বর গোপন থাকবে। অন্যরা সরাসরি ফোনে কল দিতে পারবে না; শুধুমাত্র অ্যাপের ভেতর অনলাইন অডিও কল, অনলাইন চ্যাট ও ভয়েস মেসেজে যোগাযোগ করতে পারবে।', 'Number masked. Others cannot call your regular phone directly; only in-app audio call, chat & voice note are allowed.')}
                      </p>
                    </div>
                  </div>

                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={allowOfflineCall}
                      onChange={(e) => setAllowOfflineCall(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#2D5A27]"></div>
                  </label>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-3">
              <button
                type="submit"
                disabled={isSubmittingDemand}
                className="w-full py-3 rounded-2xl bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSubmittingDemand ? (
                  <span>{t('নোটিফিকেশন পাঠানো হচ্ছে...', 'Broadcasting alert...')}</span>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>{t('📢 এলাকায় নোটিফিকেশন পাঠিয়ে পোস্ট দিন', 'Broadcast Alert & Post Demand')}</span>
                  </>
                )}
              </button>
            </div>

          </form>

          {/* List of Recent Demands Posted in This Area */}
          {filteredDemands.length > 0 && (
            <div className="pt-6 border-t border-[#E6E0D4] space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] flex items-center gap-1.5">
                  <BellRing className="w-4 h-4 text-[#2D5A27]" />
                  <span>{t('এই এলাকায় পোস্টকৃত সাম্প্রতিক চাহিদা ও নোটিফিকেশন', 'Recent Demands in This Area')}</span>
                  <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] px-2 py-0.5 rounded-full font-bold">
                    {filteredDemands.length}টি
                  </span>
                </h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {filteredDemands.map((demand) => (
                  <div
                    key={demand.id}
                    className="p-3.5 bg-white rounded-2xl border border-[#E6E0D4] hover:border-[#2D5A27] transition shadow-2xs space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] bg-[#FAF8F5] border border-[#D4C3A3] text-[#2D3A3A] font-bold px-2 py-0.5 rounded-md">
                            {demand.categoryName || 'চাহিদা'}
                          </span>
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md flex items-center gap-1 ${demand.allowOfflineCall ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                            {demand.allowOfflineCall ? (
                              <>
                                <Phone className="w-2.5 h-2.5" />
                                <span>অফলাইন কল চালু</span>
                              </>
                            ) : (
                              <>
                                <Lock className="w-2.5 h-2.5" />
                                <span>অনলাইন সুরক্ষিত</span>
                              </>
                            )}
                          </span>
                        </div>
                        <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A] mt-1">
                          {demand.title}
                        </h5>
                      </div>
                      <span className="text-[10px] text-[#736B5E] shrink-0">
                        {demand.createdAtFormatted || 'সাম্প্রতিক'}
                      </span>
                    </div>

                    <p className="text-xs text-[#5A6B6B] line-clamp-2">
                      {demand.message}
                    </p>

                    <div className="pt-2 border-t border-[#FAF8F5] flex items-center justify-between text-xs gap-2">
                      <span className="text-[11px] text-[#736B5E]">
                        প্রেরক: <strong>{demand.senderName || 'এলাকাবাসী'}</strong>
                      </span>

                      <div className="flex items-center gap-1">
                        {/* In-App Voice Call */}
                        <button
                          type="button"
                          onClick={() => {
                            handleStartInAppCall({
                              name: demand.senderName || 'বিজ্ঞাপনদাতা',
                              role: demand.targetRole || 'requester',
                              phone: demand.contactNumber,
                              photo: demand.senderAvatar,
                              subtitle: demand.title
                            });
                          }}
                          className="p-1.5 bg-[#D4E4BC] hover:bg-[#2D5A27] text-[#2D5A27] hover:text-white rounded-lg transition cursor-pointer"
                          title="ফ্রি ইন-অ্যাপ কল"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                        </button>

                        {/* Voice Note */}
                        <button
                          type="button"
                          onClick={() => {
                            setActiveVoiceRecipient({
                              name: demand.senderName || 'বিজ্ঞাপনদাতা',
                              role: demand.targetRole || 'requester',
                              phone: demand.contactNumber,
                              avatar: demand.senderAvatar,
                              itemTitle: demand.title
                            });
                          }}
                          className="p-1.5 bg-[#FAF8F5] border border-[#E6E0D4] hover:border-[#2D5A27] text-[#2D3A3A] rounded-lg transition cursor-pointer"
                          title="ভয়েস মেসেজ"
                        >
                          <Mic className="w-3.5 h-3.5 text-[#2D5A27]" />
                        </button>

                        {/* Chat */}
                        <button
                          type="button"
                          onClick={() => {
                            setActiveChatRecipient({
                              id: demand.senderUserId || demand.itemId || demand.id,
                              name: demand.senderName || 'বিজ্ঞাপনদাতা',
                              role: demand.targetRole || 'requester',
                              phone: demand.contactNumber,
                              avatar: demand.senderAvatar,
                              itemTitle: demand.title
                            });
                          }}
                          className="p-1.5 bg-[#FAF8F5] border border-[#E6E0D4] hover:border-[#2D5A27] text-[#2D3A3A] rounded-lg transition cursor-pointer"
                          title="অনলাইন চ্যাট"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-[#2D3A3A]" />
                        </button>

                        {/* Call with Choice Modal (checks allowOfflineCall) */}
                        {demand.contactNumber && (
                          <button
                            type="button"
                            onClick={() => {
                              setActiveCallChoice({
                                name: demand.senderName || 'বিজ্ঞাপনদাতা',
                                role: demand.targetRole || 'requester',
                                phone: demand.contactNumber || '',
                                photo: demand.senderAvatar,
                                subtitle: demand.title,
                                allowOfflineCall: demand.allowOfflineCall ?? false
                              });
                            }}
                            className="px-2.5 py-1 bg-[#2D5A27] hover:bg-[#23491E] text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-2xs transition cursor-pointer"
                            title="কলের মাধ্যম নির্বাচন"
                          >
                            <Phone className="w-3 h-3" />
                            <span>কল</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL DIALOGS */}
      {/* ======================================================== */}

      {/* Voice Chat Modal */}
      {activeVoiceRecipient && (
        <VoiceChatModal
          isOpen={true}
          onClose={() => setActiveVoiceRecipient(null)}
          recipientName={activeVoiceRecipient.name}
          recipientRole={activeVoiceRecipient.role}
          recipientPhone={activeVoiceRecipient.phone}
          recipientAvatar={activeVoiceRecipient.avatar}
          itemTitle={activeVoiceRecipient.itemTitle}
          currentUser={currentUser}
          onSendVoiceMessage={(audioUrl, duration, textSummary) => {
            setActiveChatRecipient({
              id: activeVoiceRecipient.phone || 'target',
              name: activeVoiceRecipient.name,
              role: activeVoiceRecipient.role,
              phone: activeVoiceRecipient.phone,
              avatar: activeVoiceRecipient.avatar,
              itemTitle: activeVoiceRecipient.itemTitle
            });
            setActiveVoiceRecipient(null);
          }}
        />
      )}

      {/* Text Chat Modal */}
      {activeChatRecipient && (
        <ChatModal
          isOpen={true}
          onClose={() => setActiveChatRecipient(null)}
          recipientId={activeChatRecipient.id}
          recipientName={activeChatRecipient.name}
          recipientRole={activeChatRecipient.role}
          recipientPhone={activeChatRecipient.phone}
          recipientAvatar={activeChatRecipient.avatar}
          itemTitle={activeChatRecipient.itemTitle}
          currentUser={currentUser}
          onOpenAuth={onOpenAuth}
          onStartInAppCall={() => {
            if (onStartInAppCall) {
              onStartInAppCall({
                id: activeChatRecipient.id,
                name: activeChatRecipient.name,
                role: activeChatRecipient.role || 'user',
                phone: activeChatRecipient.phone,
                avatar: activeChatRecipient.avatar
              });
            }
          }}
        />
      )}

      {/* Two-Way Rating & Review Modal */}
      {activeReviewTarget && (
        <TwoWayReviewModal
          isOpen={true}
          onClose={() => setActiveReviewTarget(null)}
          targetId={activeReviewTarget.id}
          targetName={activeReviewTarget.name}
          targetRole={activeReviewTarget.role}
          serviceType={activeReviewTarget.serviceType}
          currentUser={currentUser}
        />
      )}

      {/* Smart Fare Estimator Modal */}
      {isFareModalOpen && (
        <SmartFareEstimatorModal
          isOpen={true}
          onClose={() => setIsFareModalOpen(false)}
          selectedDriver={selectedDriverForFare}
          onSelectDriverToCall={(driver) => {
            if (onStartInAppCall) {
              onStartInAppCall({
                id: driver.id,
                name: driver.driverName,
                role: 'driver',
                phone: driver.phone,
                avatar: driver.facePhotoUrl
              });
            }
          }}
        />
      )}

      {/* Call Choice Modal for Offline / Online selection */}
      {activeCallChoice && (
        <CallChoiceModal
          recipientName={activeCallChoice.name}
          recipientRole={activeCallChoice.role}
          recipientPhoto={activeCallChoice.photo}
          recipientSubtitle={activeCallChoice.subtitle}
          rawPhone={activeCallChoice.phone}
          allowOfflineCall={activeCallChoice.allowOfflineCall ?? true}
          onSelectInAppCall={() => {
            handleStartInAppCall({
              name: activeCallChoice.name,
              role: activeCallChoice.role,
              phone: activeCallChoice.phone,
              photo: activeCallChoice.photo,
              subtitle: activeCallChoice.subtitle
            });
            setActiveCallChoice(null);
          }}
          onOpenChat={() => {
            setActiveChatRecipient({
              id: activeCallChoice.name,
              name: activeCallChoice.name,
              role: activeCallChoice.role,
              phone: activeCallChoice.phone,
              avatar: activeCallChoice.photo
            });
            setActiveCallChoice(null);
          }}
          onOpenVoiceNote={() => {
            setActiveVoiceRecipient({
              name: activeCallChoice.name,
              role: activeCallChoice.role,
              phone: activeCallChoice.phone,
              avatar: activeCallChoice.photo,
              itemTitle: activeCallChoice.subtitle
            });
            setActiveCallChoice(null);
          }}
          onClose={() => setActiveCallChoice(null)}
        />
      )}

      {/* Direct In-App Voice Call Session Modal */}
      {activeInAppVoiceCall && (
        <InAppVoiceCallModal
          recipientName={activeInAppVoiceCall.name}
          recipientRole={activeInAppVoiceCall.role}
          recipientPhoto={activeInAppVoiceCall.photo}
          recipientSubtitle={activeInAppVoiceCall.subtitle}
          maskedPhone={activeInAppVoiceCall.maskedPhone}
          rawPhone={activeInAppVoiceCall.rawPhone}
          currentUser={currentUser}
          onClose={() => setActiveInAppVoiceCall(null)}
        />
      )}

    </div>
  );
};
