import React from 'react';
import { 
  Home, 
  Grid,
  Compass,
  Heart,
  Car,
  Moon,
  Sprout, 
  Zap, 
  HeartPulse, 
  Landmark, 
  Beef, 
  ShoppingBag, 
  Calculator, 
  Bot,
  User,
  ShieldCheck,
  Scale
} from 'lucide-react';
import { ServiceCategory } from '../types';
import { UserProfile } from '../types/auth';
import { useLanguage } from '../context/LanguageContext';

interface NavigationProps {
  activeTab: ServiceCategory;
  onSelectTab: (tab: ServiceCategory) => void;
  currentUser?: UserProfile | null;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onSelectTab, currentUser }) => {
  const { t } = useLanguage();

  const accountLabel = currentUser?.name
    ? (currentUser.name.trim().split(' ')[0] || currentUser.name.trim())
    : t('অ্যাকাউন্ট', 'Account');

  const tabs = [
    { id: 'home' as ServiceCategory, label: t('হোম', 'Home'), icon: Home, badge: '' },
    { id: 'services' as ServiceCategory, label: t('২৬টি সেবা তালিকা', '26 Services Directory'), icon: Grid, badge: t('২৬টি', '26') },
    { id: 'marketplace' as ServiceCategory, label: t('পল্লী হাট ও তরিতরকারি', 'Rural Haat & Produce'), icon: ShoppingBag, badge: t('টাটকা', 'Fresh') },
    { id: 'transport' as ServiceCategory, label: t('নিরাপদ পরিবহন ও চালক', 'Safe Transport & Drivers'), icon: Car, badge: t('কল', 'Call') },
    { id: 'agriculture' as ServiceCategory, label: t('কৃষি ও ফসল সেবা', 'Agriculture & Crops'), icon: Sprout, badge: t('বাজারদর', 'Rates') },
    { id: 'health' as ServiceCategory, label: t('স্বাস্থ্য, রক্ত ও হাসপাতাল', 'Health, Blood & Hospital'), icon: Heart, badge: t('জরুরি', 'Emergency') },
    { id: 'electricity' as ServiceCategory, label: t('পল্লী বিদ্যুৎ বিল ও সেবা', 'Electricity Bill & Service'), icon: Zap, badge: t('বিল ও সেবা', 'Bill & Info') },
    { id: 'legal-police' as ServiceCategory, label: t('আইন, আদালত ও সরকারি সাহায্য', 'Legal, Police & Aid'), icon: Scale, badge: '16430' },
    { id: 'government' as ServiceCategory, label: t('ইউনিয়ন ও নাগরিক সেবা', 'Union & Citizen Services'), icon: Landmark, badge: t('ভাতা', 'Allowance') },
    { id: 'livestock' as ServiceCategory, label: t('পশুসম্পদ ও মৎস্য', 'Livestock & Fishery'), icon: Beef, badge: '' },
    { id: 'calculators' as ServiceCategory, label: t('জমি ও ঋণ হিসাব', 'Land & Loan Calc'), icon: Calculator, badge: '' },
    { id: 'service-finder' as ServiceCategory, label: t('কী সেবা কোথায় পাবেন', 'Where to Get Service'), icon: Compass, badge: t('গাইড', 'Guide') },
    { id: 'prayer-islamic' as ServiceCategory, label: t('নামাজ ও ইসলামিক সেবা', 'Prayer & Islamic Services'), icon: Moon, badge: t('ওয়াক্ত', 'Waqt') },
    { id: 'ai-advisor' as ServiceCategory, label: t('এআই পরামর্শক', 'AI Rural Advisor'), icon: Bot, badge: 'AI' },
    { id: 'account' as ServiceCategory, label: accountLabel, icon: User, badge: currentUser ? 'লগইন' : '' },
    { id: 'terms-help' as ServiceCategory, label: t('নীতিমালা ও সাহায্য', 'Terms & Help'), icon: ShieldCheck, badge: '' },
  ];

  return (
    <nav className="bg-white border-b border-[#E6E0D4] sticky top-[84px] sm:top-[80px] z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-2 sm:px-4">
        <div className="flex items-center overflow-x-auto no-scrollbar py-2.5 gap-1.5 sm:gap-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-150 cursor-pointer ${
                  isActive
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'text-[#2D3A3A] hover:bg-[#F9E5D4]/40 hover:text-[#2D5A27]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#D4E4BC]' : 'text-[#736B5E]'}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                      isActive
                        ? 'bg-[#D4E4BC] text-[#2D5A27]'
                        : 'bg-[#F9E5D4] text-[#A65E2E]'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
