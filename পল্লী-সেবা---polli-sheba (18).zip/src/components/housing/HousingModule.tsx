import React, { useState, useEffect } from 'react';
import { 
  Home, 
  Plus, 
  MapPin, 
  ShieldCheck, 
  Phone, 
  MessageSquare, 
  Mic, 
  AlertTriangle, 
  Filter, 
  Search, 
  Trash2, 
  Calendar, 
  Zap, 
  Check, 
  Layers, 
  Eye, 
  Info, 
  Sparkles, 
  Clock, 
  CheckCircle,
  X,
  Share2
} from 'lucide-react';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';
import { UserProfile } from '../../types/auth';
import { 
  HousingListing, 
  HousingCategoryType, 
  checkHousingReviewKeywords, 
  isPostExpired 
} from '../../types/housingMatrimony';
import { 
  subscribeToHousingListings, 
  saveCloudHousingListing, 
  deleteCloudHousingListing,
  saveDemandNotification
} from '../../lib/cloudSync';
import { ReportListingModal } from './ReportListingModal';

interface HousingModuleProps {
  currentDistrict: string;
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
  onStartInAppCall?: (targetUser: Partial<UserProfile>) => void;
  onStartChat?: (targetUser: Partial<UserProfile>) => void;
  onOpenVoiceNote?: (targetUser: Partial<UserProfile>) => void;
}

const CATEGORY_TABS: Array<{ id: 'all' | HousingCategoryType; label: string; icon: string }> = [
  { id: 'all', label: 'সকল আবাসন', icon: '🏠' },
  { id: 'ফ্যামিলি বাসা', label: 'ফ্যামিলি বাসা', icon: '👨‍👩‍👧‍👦' },
  { id: 'ব্যাচেলর বাসা', label: 'ব্যাচেলর বাসা', icon: '🧑‍🤝‍🧑' },
  { id: 'মেস বাসা', label: 'মেস বাসা', icon: '🛏️' },
  { id: 'সাবলেট / রুম', label: 'সাবলেট / রুম', icon: '🚪' },
  { id: 'দোকান / অফিস', label: 'দোকান ও অফিস', icon: '🏢' }
];

const UTILITY_OPTIONS = [
  'বিদ্যুৎ (প্রিপেইড মিটার)',
  'বিদ্যুৎ (পোস্টপেইড)',
  'পানি সার্বক্ষণিক',
  'সিলিন্ডার গ্যাস সুবিধা',
  'লাইনের গ্যাস',
  'হাইস্পিড ওয়াইফাই',
  'বাইক পার্কিং',
  'গাড়ি পার্কিং',
  'লিফট সুবিধা',
  'সিসিটিভি ক্যামেরা নিরাপত্তা',
  'জেনারেটর ব্যাকআপ'
];

export const HousingModule: React.FC<HousingModuleProps> = ({
  currentDistrict,
  currentUser,
  onOpenAuth,
  onStartInAppCall,
  onStartChat,
  onOpenVoiceNote
}) => {
  const [listings, setListings] = useState<HousingListing[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<'all' | HousingCategoryType>('all');
  const [filterAddress, setFilterAddress] = useState<AddressState>({
    district: currentDistrict && currentDistrict !== 'সকল জেলা' ? currentDistrict : 'সকল জেলা',
    upazila: '',
    union: '',
    village: ''
  });
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'browse' | 'my_posts'>('browse');

  // Modal states
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [reportingListing, setReportingListing] = useState<HousingListing | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form states for creating a new housing post
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<HousingCategoryType>('ফ্যামিলি বাসা');
  const [rentType, setRentType] = useState<'fixed' | 'negotiable'>('fixed');
  const [rentAmount, setRentAmount] = useState<number>(5000);
  const [bedrooms, setBedrooms] = useState<number>(2);
  const [bathrooms, setBathrooms] = useState<number>(1);
  const [balconies, setBalconies] = useState<number>(1);
  const [floorLevel, setFloorLevel] = useState('২য় তলা');
  const [selectedUtilities, setSelectedUtilities] = useState<string[]>([
    'বিদ্যুৎ (প্রিপেইড মিটার)',
    'পানি সার্বক্ষণিক',
    'বাইক পার্কিং'
  ]);
  const [postAddress, setPostAddress] = useState<AddressState>({
    district: currentUser?.district || (currentDistrict !== 'সকল জেলা' ? currentDistrict : 'বগুড়া'),
    upazila: currentUser?.upazila || '',
    union: currentUser?.union || '',
    village: currentUser?.village || ''
  });
  const [landmarkAddress, setLandmarkAddress] = useState('');
  const [availableFrom, setAvailableFrom] = useState('পরবর্তী মাস থেকে');
  const [description, setDescription] = useState('');
  const [notificationScope, setNotificationScope] = useState<'upazila' | 'district'>('upazila');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Check if current user is restricted from Housing & Matrimony
  const isRestricted = !!currentUser?.isRestrictedFromHousingAndMatrimony;

  useEffect(() => {
    const unsubscribe = subscribeToHousingListings((data) => {
      setListings(data);
    });
    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, []);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const toggleUtility = (item: string) => {
    if (selectedUtilities.includes(item)) {
      setSelectedUtilities(selectedUtilities.filter(u => u !== item));
    } else {
      setSelectedUtilities([...selectedUtilities, item]);
    }
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (isRestricted) {
      alert('আপনার অ্যাকাউন্টটি আবাসন ও পাত্র-পাত্রী সেবায় আংশিকভাবে সীমাবদ্ধ করা হয়েছে। অন্যান্য সেবা নিয়মিত ব্যবহার করতে পারবেন।');
      return;
    }

    if (!title.trim() || !description.trim() || !postAddress.district || !postAddress.upazila) {
      alert('অনুগ্রহ করে শিরোনাম, বিবরণ, জেলা ও উপজেলা নির্বাচন করুন');
      return;
    }

    setIsSubmitting(true);

    // 1. KEYWORD FILTERING LOGIC
    const keywordCheck = checkHousingReviewKeywords(title, description);
    const initialStatus: HousingListing['status'] = keywordCheck.isSuspicious 
      ? 'pending_review' 
      : 'active';

    const now = Date.now();
    const expiresAt = now + (30 * 24 * 60 * 60 * 1000); // সর্বোচ্চ ৩০ দিন (১ মাস) মেয়াদ
    const dateFormatted = new Date(now).toLocaleDateString('bn-BD', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });

    const fullAreaAddress = [
      landmarkAddress.trim(),
      postAddress.village ? `ওয়ার্ড/গ্রাম: ${postAddress.village}` : '',
      postAddress.union ? `ইউনিয়ন: ${postAddress.union}` : '',
      postAddress.upazila,
      postAddress.district
    ].filter(Boolean).join(', ');

    const newListing: HousingListing = {
      id: `house-${now}-${Math.random().toString(36).substring(2, 7)}`,
      title: title.trim(),
      category,
      rentType,
      rentAmount: rentType === 'fixed' ? Number(rentAmount) : 0,
      bedrooms,
      bathrooms,
      balconies,
      floorLevel,
      utilities: selectedUtilities,
      district: postAddress.district,
      upazila: postAddress.upazila || 'উপজেলা সদর',
      union: postAddress.union || undefined,
      village: postAddress.village || undefined,
      areaAddress: fullAreaAddress,
      description: description.trim(),
      availableFrom: availableFrom.trim(),
      ownerId: currentUser.id,
      ownerName: currentUser.name,
      ownerPhone: currentUser.phone,
      ownerAvatarUrl: currentUser.customAvatarUrl || currentUser.avatarUrl,
      ownerRole: 'বাড়ির মালিক / ম্যানেজার',
      allowOfflineCall: currentUser.allowOfflineCall ?? currentUser.allowOfflineCalls ?? false,
      notificationScope,
      status: initialStatus,
      reviewReason: keywordCheck.isSuspicious 
        ? `স্বয়ংক্রিয় ফিল্টার: "${keywordCheck.matchedKeyword}" শব্দটি পর্যালোচনার জন্য চিহ্নিত` 
        : undefined,
      createdAt: now,
      createdAtFormatted: dateFormatted,
      expiresAt,
      viewsCount: 1
    };

    try {
      await saveCloudHousingListing(newListing);

      // 2. DISPATCH NOTIFICATION IF ACTIVE
      if (initialStatus === 'active') {
        const notifTitle = `🏠 নতুন আবাসন বিজ্ঞপ্তি: ${title.trim()}`;
        const notifMsg = `${postAddress.district}, ${postAddress.upazila} এলাকায় "${category}" ভাড়া দেওয়া হবে। মাসিক ভাড়া: ${rentType === 'fixed' ? `${rentAmount} টাকা` : 'আলোচনা সাপেক্ষে'}।`;
        
        await saveDemandNotification({
          id: `notif-house-${now}`,
          title: notifTitle,
          message: notifMsg,
          urgency: 'সাধারণ',
          targetDistrict: postAddress.district,
          targetUpazila: notificationScope === 'upazila' ? (postAddress.upazila || 'সকল উপজেলা') : 'সকল উপজেলা',
          targetRole: 'all',
          categoryName: 'আবাসন',
          senderName: currentUser.name,
          contactNumber: currentUser.phone,
          targetCategory: 'housing',
          scope: notificationScope,
          createdAt: now,
          expiresAt: now + (7 * 24 * 60 * 60 * 1000),
          createdAtFormatted: dateFormatted,
          allowOfflineCall: currentUser.allowOfflineCall
        });
      }

      setIsCreateModalOpen(false);
      resetForm();

      if (keywordCheck.isSuspicious) {
        triggerToast('⚠️ পোস্টে হোটেল/দৈনিক ভাড়া সংক্রান্ত কীওয়ার্ড থাকায় এটি "Pending for Review" অবস্থায় আছে। এডমিন যাচাই করে দ্রুত উন্মুক্ত করবেন।');
      } else {
        triggerToast('✓ আপনার আবাসন বিজ্ঞাপনটি সফলভাবে প্রকাশিত হয়েছে এবং ৩০ দিন লাইভ থাকবে!');
      }
    } catch (err) {
      alert('পোস্ট সেভ করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setTitle('');
    setLandmarkAddress('');
    setDescription('');
    setRentAmount(5000);
    setBedrooms(2);
    setBathrooms(1);
    setBalconies(1);
    setFloorLevel('২য় তলা');
    setSelectedUtilities(['বিদ্যুৎ (প্রিপেইড মিটার)', 'পানি সার্বক্ষণিক', 'বাইক পার্কিং']);
    setPostAddress({
      district: currentUser?.district || (currentDistrict !== 'সকল জেলা' ? currentDistrict : 'বগুড়া'),
      upazila: currentUser?.upazila || '',
      union: currentUser?.union || '',
      village: currentUser?.village || ''
    });
  };

  const handleDeleteListing = async (id: string, itemTitle: string) => {
    if (confirm(`আপনি কি নিশ্চিত যে "${itemTitle}" বিজ্ঞাপনটি মুছে ফেলতে চান?`)) {
      try {
        await deleteCloudHousingListing(id);
        triggerToast('✓ বিজ্ঞাপনটি সফলভাবে মুছে ফেলা হয়েছে');
      } catch (err) {
        alert('মুছতে সমস্যা হয়েছে');
      }
    }
  };

  // Filter listings
  const publicListings = listings.filter(item => {
    // 1. AUTO-HIDE: Exclude expired items
    if (isPostExpired(item.expiresAt)) return false;
    // 2. Only show active approved posts in public feed
    if (item.status !== 'active') return false;
    // 3. Category filter
    if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;
    // 4. District filter
    if (filterAddress.district && filterAddress.district !== 'সকল জেলা' && item.district !== filterAddress.district) {
      return false;
    }
    // 5. Upazila filter
    if (filterAddress.upazila && filterAddress.upazila !== 'সকল উপজেলা / থানা' && filterAddress.upazila !== 'সকল উপজেলা') {
      const qUpz = filterAddress.upazila.toLowerCase().trim();
      const matchUpz = item.upazila.toLowerCase().includes(qUpz) || qUpz.includes(item.upazila.toLowerCase());
      if (!matchUpz) return false;
    }
    // 6. Union filter
    if (filterAddress.union && filterAddress.union !== 'সকল ইউনিয়ন / ওয়ার্ড' && filterAddress.union !== 'সকল ইউনিয়ন') {
      const qUn = filterAddress.union.toLowerCase().trim();
      const matchUn = (item.union && item.union.toLowerCase().includes(qUn)) ||
        item.areaAddress.toLowerCase().includes(qUn);
      if (!matchUn) return false;
    }
    // 7. Village / Ward filter
    if (filterAddress.village && filterAddress.village.trim()) {
      const qVil = filterAddress.village.toLowerCase().trim();
      const matchVil = (item.village && item.village.toLowerCase().includes(qVil)) ||
        item.areaAddress.toLowerCase().includes(qVil);
      if (!matchVil) return false;
    }
    // 8. Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const match = item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.areaAddress.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const myListings = currentUser 
    ? listings.filter(item => item.ownerId === currentUser.id)
    : [];

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-[#2D5A27] text-white px-4 py-3 rounded-2xl shadow-xl text-xs font-bold flex items-center gap-2 animate-in slide-in-from-top border border-emerald-400">
          <CheckCircle className="w-4 h-4 text-emerald-300" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* HEADER HERO BANNER */}
      <div className="bg-linear-to-r from-[#2D5A27] to-[#1E3A8A] text-white rounded-3xl p-5 sm:p-7 shadow-sm relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-white/5 transform skew-x-12 pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/15 backdrop-blur-xs rounded-full text-xs font-bold text-emerald-100">
              <span>🏠 ২৫তম উন্মুক্ত নাগরিক সেবা</span>
              <span>•</span>
              <span>দালালমুক্ত বাসা ভাড়া</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              আবাসন ও বাসা ভাড়া সার্ভিস
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
              ফ্যামিলি বাসা, ব্যাচেলর মেস, সাবলেট ও বাণিজ্যিক দোকান ভাড়া খুঁজুন কিংবা সরাসরি বাড়ির মালিক হিসেবে বিনামূল্যে বিজ্ঞাপন দিন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={() => {
                if (!currentUser) {
                  onOpenAuth();
                  return;
                }
                if (isRestricted) {
                  alert('আপনার অ্যাকাউন্টটি নিরাপত্তা সংক্রান্ত কারণে এই সেবায় পোস্ট করা থেকে সীমাবদ্ধ করা হয়েছে।');
                  return;
                }
                setIsCreateModalOpen(true);
              }}
              className="bg-white text-[#2D5A27] hover:bg-[#FAF8F5] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold shadow-md transition cursor-pointer flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4 text-[#2D5A27]" />
              <span>বাসা ভাড়ার বিজ্ঞাপন দিন</span>
            </button>

            {currentUser && (
              <button
                onClick={() => setActiveTab(activeTab === 'browse' ? 'my_posts' : 'browse')}
                className={`px-3.5 py-2.5 rounded-2xl text-xs font-bold transition cursor-pointer border ${
                  activeTab === 'my_posts'
                    ? 'bg-emerald-800 text-white border-emerald-400'
                    : 'bg-white/15 text-white hover:bg-white/25 border-white/20'
                }`}
              >
                <span>আমার পোস্ট ({myListings.length})</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ১. পর্দায় স্থায়ী ডিসক্লেইমার (PERMANENT LEGAL DISCLAIMER) */}
      <div className="bg-[#FAF8F5] p-3.5 sm:p-4 rounded-2xl border-2 border-[#D4C3A3] shadow-2xs flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center shrink-0">
          <ShieldCheck className="w-5 h-5" />
        </div>
        <div className="text-xs text-[#2D3A3A] leading-relaxed">
          <strong className="font-extrabold text-[#8B4513] block">
            ⚖️ স্থায়ী অবগতি ও নিরাপত্তা নোটিশ:
          </strong>
          <span>
            পল্লী সেবা কোনো প্রকার আর্থিক লেনদেন করে না। বাসা ভাড়া ও আনুষঙ্গিক চুক্তি নির্ধারণ সম্পূর্ণ বাড়ির মালিক এবং ভাড়াটিয়াদের মধ্যকার সরাসরি আলোচনার বিষয়।
          </span>
        </div>
      </div>

      {/* PARTIAL BAN BANNER FOR RESTRICTED USERS */}
      {isRestricted && (
        <div className="bg-red-50 p-4 rounded-2xl border-2 border-red-300 text-red-900 space-y-1">
          <div className="flex items-center gap-2 font-bold text-xs sm:text-sm text-red-800">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span>আপনার অ্যাকাউন্টের জন্য আবাসন ও পাত্র-পাত্রী সেবায় আংশিক সীমাবদ্ধতা রয়েছে</span>
          </div>
          <p className="text-xs text-red-700 leading-relaxed">
            কোনো ব্যবহারকারীর রিপোর্ট বা নিরাপত্তা নীতি ভঙ্গের কারণে আপনাকে শুধুমাত্র ‘আবাসন’ ও ‘পাত্র-পাত্রীর সন্ধান’ ফিচারে পোস্ট করার অধিকার থেকে আংশিকভাবে সাময়িক/স্থায়ীভাবে বিরত রাখা হয়েছে। তবে আপনি পল্লী সেবার অন্যান্য সকল সেবা (কৃষি, হাট, ডাক্তার, রক্তদান, পরিবহন ইত্যাদি) স্বাভাবিকভাবে ব্যবহার করতে পারবেন।
          </p>
        </div>
      )}

      {/* FILTER & SEARCH BAR */}
      {activeTab === 'browse' && (
        <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs space-y-3">
          {/* Category Tabs */}
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {CATEGORY_TABS.map(tab => (
              <button
                key={tab.id}
                onClick={() => setSelectedCategory(tab.id)}
                className={`px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  selectedCategory === tab.id
                    ? 'bg-[#2D5A27] text-white shadow-2xs'
                    : 'bg-[#FAF8F5] text-[#2D3A3A] border border-[#E6E0D4] hover:bg-[#D4E4BC]/30'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Cascading Area Filter (District ➔ Upazila ➔ Union ➔ Ward/Village) */}
          <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-2">
            <div className="text-[11px] font-bold text-[#2D5A27] flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                <span>এলাকা ভিত্তিক ফিল্টারিং (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ ওয়ার্ড/গ্রাম):</span>
              </div>
              {(filterAddress.district !== 'সকল জেলা' || filterAddress.upazila || filterAddress.union || filterAddress.village) && (
                <button
                  type="button"
                  onClick={() => setFilterAddress({ district: 'সকল জেলা', upazila: '', union: '', village: '' })}
                  className="text-[10px] text-red-600 hover:underline font-bold cursor-pointer"
                >
                  ✕ ফিল্টার রিসেট
                </button>
              )}
            </div>
            <CascadingAddressSelector
              address={filterAddress}
              onChange={setFilterAddress}
              allowAllOption={true}
              layout="grid-4"
              villagePlaceholder="ওয়ার্ড নং / গ্রাম / সড়কের নাম..."
            />
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#736B5E] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="শিরোনাম, বাসার ধরন বা বিবরণ দিয়ে খুঁজুন..."
              className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl pl-9 pr-3 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
            />
          </div>
        </div>
      )}

      {/* TAB: MY LISTINGS (পোস্টদাতার নিজস্ব ড্যাশবোর্ড) */}
      {activeTab === 'my_posts' && currentUser && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-white p-4 rounded-3xl border border-[#E6E0D4]">
            <div>
              <h3 className="font-bold text-sm text-[#2D3A3A]">আমার পোস্টকৃত বাসা ভাড়ার বিজ্ঞাপনসমূহ</h3>
              <p className="text-xs text-[#736B5E]">আপনি চাইলে যেকোনো সময় নিজের পোস্ট ডিলিট করতে পারেন। পোস্ট সর্বোচ্চ ৩০ দিন স্বয়ংক্রিয়ভাবে লাইভ থাকে।</p>
            </div>
            <button
              onClick={() => setActiveTab('browse')}
              className="text-xs text-[#2D5A27] font-bold underline cursor-pointer"
            >
              সব পোস্ট দেখুন
            </button>
          </div>

          {myListings.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 text-center border border-[#E6E0D4] space-y-3">
              <Home className="w-12 h-12 text-gray-300 mx-auto" />
              <p className="text-sm font-bold text-[#2D3A3A]">আপনি এখনও কোনো বাসা ভাড়ার বিজ্ঞাপন দেননি</p>
              <button
                onClick={() => setIsCreateModalOpen(true)}
                className="px-4 py-2 bg-[#2D5A27] text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                নতুন বিজ্ঞাপন দিন
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {myListings.map(item => {
                const expired = isPostExpired(item.expiresAt);
                return (
                  <div key={item.id} className="bg-white rounded-3xl p-5 border border-[#E6E0D4] shadow-xs space-y-3 relative">
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                            {item.category}
                          </span>
                          {item.status === 'pending_review' && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                              ⏳ পর্যালোচনায় (Pending)
                            </span>
                          )}
                          {expired ? (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-200 text-stone-700">
                              ⌛ মেয়াদোত্তীর্ণ (Auto-hidden)
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                              🟢 লাইভ
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-sm text-[#2D3A3A]">{item.title}</h4>
                      </div>

                      <button
                        onClick={() => handleDeleteListing(item.id, item.title)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer"
                        title="পোস্টটি ডিলিট করুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="text-xs text-[#5A6B6B] space-y-1 bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4]">
                      <div className="flex justify-between">
                        <span>মাসিক ভাড়া:</span>
                        <strong className="text-emerald-700">
                          {item.rentType === 'fixed' ? `${item.rentAmount} টাকা` : 'আলোচনা সাপেক্ষে'}
                        </strong>
                      </div>
                      <div className="flex justify-between">
                        <span>এলাকা:</span>
                        <span>{item.upazila}, {item.district}</span>
                      </div>
                      <div className="flex justify-between text-[11px] text-[#736B5E]">
                        <span>পোস্টের তারিখ:</span>
                        <span>{item.createdAtFormatted}</span>
                      </div>
                    </div>

                    {item.status === 'pending_review' && item.reviewReason && (
                      <div className="text-[11px] text-amber-800 bg-amber-50 p-2.5 rounded-xl border border-amber-200">
                        {item.reviewReason}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* LISTINGS GRID */}
      {activeTab === 'browse' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-[#5A6B6B] px-1">
            <span>মোট {publicListings.length}টি লাইভ বিজ্ঞাপন পাওয়া গেছে</span>
            <span>সর্বোচ্চ মেয়াদ: ১ মাস (৩০ দিন পর অটো-হাইড)</span>
          </div>

          {publicListings.length === 0 ? (
            <div className="bg-white rounded-3xl p-10 text-center border border-[#E6E0D4] space-y-3">
              <Home className="w-12 h-12 text-gray-300 mx-auto" />
              <h3 className="font-bold text-sm text-[#2D3A3A]">কোনো আবাসন বিজ্ঞাপন পাওয়া যায়নি</h3>
              <p className="text-xs text-[#736B5E] max-w-sm mx-auto">
                অন্য কোনো জেলা বা ক্যাটাগরি নির্বাচন করুন অথবা আপনার নিজের বাসা বা মেসের বিজ্ঞাপন দিন।
              </p>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setFilterAddress({ district: 'সকল জেলা', upazila: '', union: '', village: '' });
                  setSearchQuery('');
                }}
                className="px-4 py-2 bg-[#2D5A27] text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                সব ফিল্টার রিসেট করুন
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {publicListings.map(post => {
                return (
                  <div
                    key={post.id}
                    className="bg-white rounded-3xl p-5 border border-[#E6E0D4] shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-3">
                      {/* Top Badges */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="bg-[#D4E4BC] text-[#2D5A27] text-[10px] font-extrabold px-2.5 py-0.5 rounded-full">
                            {post.category}
                          </span>
                          <span className="bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                            {post.floorLevel}
                          </span>
                          <span className="bg-stone-100 text-stone-700 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Clock className="w-3 h-3 text-[#2D5A27]" />
                            <span>{post.availableFrom || 'শীঘ্রই খালি'}</span>
                          </span>
                        </div>

                        {/* Rent Pill */}
                        <div className="text-right shrink-0">
                          <div className="text-base font-extrabold text-[#2D5A27]">
                            {post.rentType === 'fixed' ? `${post.rentAmount.toLocaleString('bn-BD')} ৳` : 'আলোচনা সাপেক্ষে'}
                          </div>
                          <span className="text-[10px] text-[#736B5E]">মাসিক ভাড়া</span>
                        </div>
                      </div>

                      {/* Title & Location */}
                      <div>
                        <h3 className="font-bold text-base text-[#2D3A3A] leading-snug line-clamp-2">
                          {post.title}
                        </h3>
                        <div className="flex items-center gap-1 text-xs text-[#5A6B6B] mt-1 font-medium">
                          <MapPin className="w-3.5 h-3.5 text-[#2D5A27] shrink-0" />
                          <span className="line-clamp-1">{post.areaAddress}, {post.upazila}, {post.district}</span>
                        </div>
                      </div>

                      {/* Room Specs & Layout */}
                      <div className="grid grid-cols-3 gap-2 bg-[#FAF8F5] p-2.5 rounded-2xl border border-[#E6E0D4] text-center text-xs text-[#2D3A3A]">
                        <div>
                          <span className="text-[10px] text-[#736B5E] block">বেডরুম</span>
                          <span className="font-bold">{post.bedrooms} টি</span>
                        </div>
                        <div className="border-x border-[#E6E0D4]">
                          <span className="text-[10px] text-[#736B5E] block">বাথরুম</span>
                          <span className="font-bold">{post.bathrooms} টি</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-[#736B5E] block">বারান্দা</span>
                          <span className="font-bold">{post.balconies} টি</span>
                        </div>
                      </div>

                      {/* Utilities Chips */}
                      {post.utilities && post.utilities.length > 0 && (
                        <div className="flex flex-wrap gap-1.5">
                          {post.utilities.map((util, i) => (
                            <span 
                              key={i} 
                              className="text-[10.5px] bg-[#FAF8F5] text-[#2D3A3A] px-2 py-0.5 rounded-lg border border-[#E6E0D4]"
                            >
                              ✓ {util}
                            </span>
                          ))}
                        </div>
                      )}

                      {/* Description */}
                      <p className="text-xs text-[#5A6B6B] leading-relaxed line-clamp-3">
                        {post.description}
                      </p>
                    </div>

                    {/* OWNER CARD & IN-APP CONTACT BUTTONS */}
                    <div className="space-y-3 pt-3 border-t border-[#E6E0D4]">
                      <div className="flex items-center justify-between gap-2">
                        {/* Owner Info */}
                        <div className="flex items-center gap-2.5">
                          {post.ownerAvatarUrl ? (
                            <img
                              src={post.ownerAvatarUrl}
                              alt={post.ownerName}
                              className="w-9 h-9 rounded-full object-cover border border-[#2D5A27]"
                            />
                          ) : (
                            <div className="w-9 h-9 rounded-full bg-[#D4E4BC] text-[#2D5A27] font-bold text-sm flex items-center justify-center">
                              {post.ownerName ? post.ownerName.charAt(0) : 'U'}
                            </div>
                          )}
                          <div>
                            <span className="font-bold text-xs text-[#2D3A3A] block">{post.ownerName}</span>
                            <span className="text-[10px] text-[#736B5E] block">{post.ownerRole || 'বিজ্ঞাপনদাতা'}</span>
                          </div>
                        </div>

                        {/* Report Button */}
                        <button
                          onClick={() => setReportingListing(post)}
                          className="text-[11px] text-red-600 hover:text-red-700 hover:bg-red-50 p-1.5 rounded-xl transition flex items-center gap-1 cursor-pointer"
                          title="অভিযোগ দায়ের করুন"
                        >
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>রিপোর্ট</span>
                        </button>
                      </div>

                      {/* Free In-App & Offline Contact Action Buttons */}
                      <div className="grid grid-cols-3 gap-2">
                        {/* In-App Audio Call */}
                        <button
                          onClick={() => {
                            if (onStartInAppCall) {
                              onStartInAppCall({
                                id: post.ownerId,
                                name: post.ownerName,
                                phone: post.ownerPhone,
                                avatarUrl: post.ownerAvatarUrl,
                                role: 'citizen'
                              });
                            }
                          }}
                          className="bg-[#2D5A27] hover:bg-[#23491E] text-white py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 shadow-xs cursor-pointer"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>ফ্রি কল</span>
                        </button>

                        {/* In-App Chat */}
                        <button
                          onClick={() => {
                            if (onStartChat) {
                              onStartChat({
                                id: post.ownerId,
                                name: post.ownerName,
                                phone: post.ownerPhone,
                                avatarUrl: post.ownerAvatarUrl
                              });
                            }
                          }}
                          className="bg-[#FAF8F5] hover:bg-[#D4E4BC]/30 text-[#2D3A3A] border border-[#E6E0D4] py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-[#2D5A27]" />
                          <span>চ্যাট</span>
                        </button>

                        {/* Voice Note */}
                        <button
                          onClick={() => {
                            if (onOpenVoiceNote) {
                              onOpenVoiceNote({
                                id: post.ownerId,
                                name: post.ownerName,
                                phone: post.ownerPhone,
                                avatarUrl: post.ownerAvatarUrl
                              });
                            }
                          }}
                          className="bg-[#FAF8F5] hover:bg-[#D4E4BC]/30 text-[#2D3A3A] border border-[#E6E0D4] py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Mic className="w-3.5 h-3.5 text-[#2D5A27]" />
                          <span>ভয়েস</span>
                        </button>
                      </div>

                      {/* Direct Phone Call if owner enabled */}
                      {post.allowOfflineCall && (
                        <div className="text-center pt-1">
                          <a
                            href={`tel:${post.ownerPhone}`}
                            className="text-[11px] font-bold text-emerald-800 hover:underline inline-flex items-center gap-1"
                          >
                            <span>📞 সরাসরি মোবাইল কল: {post.ownerPhone}</span>
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Bottom Transparency & Independent Agreement Notice */}
          <div className="bg-[#FAF8F5] p-4 rounded-3xl border border-[#D4C3A3] text-xs text-[#5A6B6B] flex items-start gap-3">
            <Info className="w-4 h-4 text-[#8B4513] shrink-0 mt-0.5" />
            <div className="space-y-1">
              <strong className="text-[#8B4513] font-bold block">
                সরাসরি আলোচনা ও লেনদেন সংক্রান্ত নীতি:
              </strong>
              <p>
                পল্লী সেবা কর্তৃপক্ষ কোনো প্রকার অর্থ লেনদেন বা মধ্যস্থতা করে না। বাসা ভাড়া ও আনুষঙ্গিক চুক্তি নির্ধারণ সম্পূর্ণ বাড়ির মালিক এবং ভাড়াটিয়াদের মধ্যকার সরাসরি যোগাযোগের বিষয়। উভয় পক্ষ নিজ দায়িত্বে সরাসরি আলোচনা করবেন।
              </p>
            </div>
          </div>
        </div>
      )}

      {/* CREATE HOUSING POST MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div 
            className="bg-white w-full max-w-2xl rounded-3xl p-6 shadow-2xl border border-[#E6E0D4] space-y-4 relative max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between border-b border-[#E6E0D4] pb-3">
              <div>
                <h3 className="font-bold text-lg text-[#2D3A3A] flex items-center gap-2">
                  <span>🏠 বাসা ভাড়ার নতুন বিজ্ঞাপন দিন</span>
                </h3>
                <p className="text-xs text-[#736B5E]">
                  আপনার এলাকার সঠিক তথ্য দিয়ে বিজ্ঞাপন প্রকাশ করুন। বিজ্ঞাপনটি ৩০ দিন পর্যন্ত লাইভ থাকবে।
                </p>
              </div>
              <button 
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              {/* Category & Title */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] block">আবাসনের ধরন:</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs font-bold text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  >
                    <option key="opt-fam" value="ফ্যামিলি বাসা">ফ্যামিলি বাসা</option>
                    <option key="opt-bac" value="ব্যাচেলর বাসা">ব্যাচেলর বাসা</option>
                    <option key="opt-mes" value="মেস বাসা">মেস বাসা</option>
                    <option key="opt-sub" value="সাবলেট / রুম">সাবলেট / রুম</option>
                    <option key="opt-com" value="দোকান / অফিস">দোকান ও বাণিজ্যিক অফিস</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] block">উপলব্ধ তারিখ:</label>
                  <input
                    type="text"
                    value={availableFrom}
                    onChange={(e) => setAvailableFrom(e.target.value)}
                    placeholder="যেমন: ১ নভেম্বর থেকে বা তাৎক্ষণিক"
                    className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              {/* Title */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#2D3A3A] block">
                  বিজ্ঞাপনের আকর্ষণীয় শিরোনাম: <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="যেমন: মনোরম পরিবেশে ৩ রুমের সুন্দর ফ্যামিলি বাসা ভাড়া"
                  required
                  className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3.5 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              {/* Cascading Location Selector (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ ওয়ার্ড/গ্রাম) */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] space-y-2">
                <label className="text-xs font-bold text-[#2D3A3A] block flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#2D5A27]" />
                  <span>বাসার সঠিক অবস্থান ও এলাকা নির্বাচন করুন * (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ ওয়ার্ড/গ্রাম):</span>
                </label>
                <CascadingAddressSelector
                  address={postAddress}
                  onChange={setPostAddress}
                  layout="grid-2x2"
                  showVillage={true}
                  villagePlaceholder="যেমন: ৩নং ওয়ার্ড, মধ্যপাড়া / প্রধান সড়ক সংলগ্ন"
                  required={true}
                />
              </div>

              {/* Floor Level & Landmark */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] block">ফ্লোর / তলা:</label>
                  <input
                    type="text"
                    value={floorLevel}
                    onChange={(e) => setFloorLevel(e.target.value)}
                    placeholder="যেমন: নিচতলা, ২য় তলা, ৩য় তলা"
                    className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3.5 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] block">
                    সুনির্দিষ্ট ল্যান্ডমার্ক বা বিবরণ:
                  </label>
                  <input
                    type="text"
                    value={landmarkAddress}
                    onChange={(e) => setLandmarkAddress(e.target.value)}
                    placeholder="যেমন: কলেজ রোডের পূর্ব পাশে, জামে মসজিদের কাছে"
                    className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3.5 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              {/* Room Specs: Bedrooms, Bathrooms, Balconies */}
              <div className="grid grid-cols-3 gap-3 bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4]">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-[#5A6B6B] block">বেডরুম সংখ্যা:</label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={bedrooms}
                    onChange={(e) => setBedrooms(Number(e.target.value))}
                    className="w-full bg-white border border-[#E6E0D4] rounded-xl p-1.5 text-xs text-center font-bold"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-[#5A6B6B] block">বাথরুম সংখ্যা:</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={bathrooms}
                    onChange={(e) => setBathrooms(Number(e.target.value))}
                    className="w-full bg-white border border-[#E6E0D4] rounded-xl p-1.5 text-xs text-center font-bold"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-[#5A6B6B] block">বারান্দা সংখ্যা:</label>
                  <input
                    type="number"
                    min={0}
                    max={10}
                    value={balconies}
                    onChange={(e) => setBalconies(Number(e.target.value))}
                    className="w-full bg-white border border-[#E6E0D4] rounded-xl p-1.5 text-xs text-center font-bold"
                  />
                </div>
              </div>

              {/* Rent Type & Amount */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] block">ভাড়ার পদ্ধতি:</label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setRentType('fixed')}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                        rentType === 'fixed'
                          ? 'bg-[#2D5A27] text-white border-[#2D5A27]'
                          : 'bg-[#FAF8F5] text-[#2D3A3A] border-[#E6E0D4]'
                      }`}
                    >
                      নির্দিষ্ট ভাড়া
                    </button>
                    <button
                      type="button"
                      onClick={() => setRentType('negotiable')}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                        rentType === 'negotiable'
                          ? 'bg-[#2D5A27] text-white border-[#2D5A27]'
                          : 'bg-[#FAF8F5] text-[#2D3A3A] border-[#E6E0D4]'
                      }`}
                    >
                      আলোচনা সাপেক্ষে
                    </button>
                  </div>
                </div>

                {rentType === 'fixed' && (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-[#2D3A3A] block">মাসিক ভাড়া (টাকায়):</label>
                    <input
                      type="number"
                      value={rentAmount}
                      onChange={(e) => setRentAmount(Number(e.target.value))}
                      placeholder="৫০০০"
                      className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs font-bold text-[#2D5A27] focus:outline-none focus:border-[#2D5A27]"
                    />
                  </div>
                )}
              </div>

              {/* Utilities checkboxes */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#2D3A3A] block">
                  বিদ্যুৎ, গ্যাস, পানি ও অন্যান্য সুবিধাসমূহ নির্বাচন করুন:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {UTILITY_OPTIONS.map((util) => {
                    const isChecked = selectedUtilities.includes(util);
                    return (
                      <button
                        type="button"
                        key={util}
                        onClick={() => toggleUtility(util)}
                        className={`p-2 rounded-xl text-[11px] font-medium border text-left transition cursor-pointer flex items-center justify-between ${
                          isChecked
                            ? 'bg-emerald-50 text-emerald-900 border-emerald-300 font-bold'
                            : 'bg-[#FAF8F5] text-[#5A6B6B] border-[#E6E0D4]'
                        }`}
                      >
                        <span className="line-clamp-1">{util}</span>
                        {isChecked && <Check className="w-3.5 h-3.5 text-emerald-700 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#2D3A3A] block">
                  বাসার বিস্তারিত বিবরণ: <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  required
                  placeholder="বাসার আলো-বাতাস, পরিবেশ, কোনো বিশেষ শর্ত বা নিয়ম থাকলে উল্লেখ করুন..."
                  className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl p-3 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] leading-relaxed"
                />
              </div>

              {/* ১. নোটিফিকেশন কতদূর যাবে নির্বাচন (NOTIFICATION SCOPE) */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#D4E4BC] space-y-2">
                <label className="text-xs font-bold text-[#2D5A27] block flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#2D5A27]" />
                  <span>নোটিফিকেশন কতদূর পাঠাতে চান?</span>
                </label>
                <p className="text-[11px] text-[#5A6B6B]">
                  নতুন বিজ্ঞাপনের পুশ অ্যালার্ট পোস্টকারীর অবস্থান অনুযায়ী সংশ্লিষ্ট এলাকার আগ্রহী গ্রাহকদের কাছে স্বয়ংক্রিয়ভাবে পাঠানো হবে।
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNotificationScope('upazila')}
                    className={`p-2.5 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center justify-center gap-1.5 ${
                      notificationScope === 'upazila'
                        ? 'bg-[#2D5A27] text-white border-[#2D5A27]'
                        : 'bg-white text-[#2D3A3A] border-[#E6E0D4]'
                    }`}
                  >
                    <span>📍 উপজেলা পর্যন্ত</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setNotificationScope('district')}
                    className={`p-2.5 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center justify-center gap-1.5 ${
                      notificationScope === 'district'
                        ? 'bg-[#2D5A27] text-white border-[#2D5A27]'
                        : 'bg-white text-[#2D3A3A] border-[#E6E0D4]'
                    }`}
                  >
                    <span>🏛️ জেলা পর্যন্ত (পুরো জেলা)</span>
                  </button>
                </div>
              </div>

              {/* Keyword review notice */}
              <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 text-[11px] text-amber-900 leading-relaxed flex items-start gap-2">
                <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <span>
                  <strong>পল্লী সেবা নিরাপত্তা নিয়ম:</strong> বিজ্ঞাপনে "হোটেল", "দৈনিক ভাড়া", "রুম বুকিং" বা সমজাতীয় শব্দ থাকলে পোস্টটি সরাসরি দৃশ্যমান না হয়ে এডমিন রিভিউতে (Pending) থাকবে। নিয়মিত আবাসিক বাসা সাথে সাথেই প্রকাশিত হবে।
                </span>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E6E0D4]">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100 transition cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl text-xs font-bold bg-[#2D5A27] text-white hover:bg-[#23491E] transition cursor-pointer shadow-md disabled:opacity-50"
                >
                  {isSubmitting ? 'সংরক্ষণ করা হচ্ছে...' : 'বিজ্ঞাপন প্রকাশ করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REPORT LISTING MODAL */}
      {reportingListing && (
        <ReportListingModal
          isOpen={true}
          onClose={() => setReportingListing(null)}
          currentUser={currentUser}
          itemType="housing"
          itemId={reportingListing.id}
          itemTitle={reportingListing.title}
          accusedUserId={reportingListing.ownerId}
          accusedUserName={reportingListing.ownerName}
          accusedUserPhone={reportingListing.ownerPhone}
          onSuccessToast={(msg) => triggerToast(msg)}
        />
      )}
    </div>
  );
};
