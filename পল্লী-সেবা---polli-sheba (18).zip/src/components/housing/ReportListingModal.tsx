import React, { useState } from 'react';
import { AlertTriangle, X, CheckCircle, ShieldAlert, Send } from 'lucide-react';
import { UserProfile } from '../../types/auth';
import { HousingMatrimonyReport } from '../../types/housingMatrimony';
import { saveCloudHousingMatrimonyReport } from '../../lib/cloudSync';

interface ReportListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  itemType: 'housing' | 'matrimony';
  itemId: string;
  itemTitle: string;
  accusedUserId: string;
  accusedUserName: string;
  accusedUserPhone?: string;
  onSuccessToast?: (msg: string) => void;
}

export const ReportListingModal: React.FC<ReportListingModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  itemType,
  itemId,
  itemTitle,
  accusedUserId,
  accusedUserName,
  accusedUserPhone,
  onSuccessToast
}) => {
  const [reason, setReason] = useState<HousingMatrimonyReport['reason']>('প্রতারণা বা অসত্য তথ্য');
  const [details, setDetails] = useState('');
  const [reporterName, setReporterName] = useState(currentUser?.name || '');
  const [reporterPhone, setReporterPhone] = useState(currentUser?.phone || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!details.trim()) {
      alert('অনুগ্রহ করে অভিযোগের সুনির্দিষ্ট বিবরণ বা কারণ লিখুন');
      return;
    }

    setIsSubmitting(true);
    try {
      const now = new Date();
      const report: HousingMatrimonyReport = {
        id: `report-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        reportedItemId: itemId,
        itemType,
        itemTitle,
        accusedUserId,
        accusedUserName,
        accusedUserPhone: accusedUserPhone || 'গোপন/অজানা',
        reporterUserId: currentUser?.id || 'guest',
        reporterName: reporterName.trim() || 'বেনামী অভিযোগকারী',
        reporterPhone: reporterPhone.trim() || 'অনুপলব্ধ',
        reason,
        details: details.trim(),
        createdAt: Date.now(),
        formattedDate: `${now.toLocaleDateString('bn-BD')} ${now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}`,
        status: 'নতুন'
      };

      await saveCloudHousingMatrimonyReport(report);
      setSubmitted(true);
      if (onSuccessToast) {
        onSuccessToast('আপনার অভিযোগটি প্রধান এডমিনের কাছে পাঠানো হয়েছে');
      }
      setTimeout(() => {
        setSubmitted(false);
        setDetails('');
        onClose();
      }, 2500);
    } catch (err) {
      alert('অভিযোগ পাঠাতে সমস্যা হয়েছে। অনুগ্রহ করে পুনরায় চেষ্টা করুন।');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-lg rounded-3xl p-6 shadow-2xl border border-[#E6E0D4] space-y-4 relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-red-100 text-red-700 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#2D3A3A]">
                এডমিনের কাছে অভিযোগ দায়ের
              </h3>
              <p className="text-xs text-[#736B5E]">
                {itemType === 'housing' ? 'বাসাবাড়ির পোস্ট' : 'পাত্র-পাত্রীর পোস্ট'} সম্পর্কে অসত্য তথ্য বা প্রতারণার অভিযোগ
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle className="w-7 h-7" />
            </div>
            <h4 className="font-bold text-lg text-[#2D3A3A]">অভিযোগ সফলভাবে গৃহীত হয়েছে!</h4>
            <p className="text-xs text-[#5A6B6B] max-w-sm mx-auto leading-relaxed">
              এডমিন অভিযোগের সত্যতা যাচাই করবেন। সত্যতা পাওয়া গেলে অভিযুক্ত একাউন্টটিকে শুধুমাত্র এই দুটি ফিচারে স্থায়ীভাবে ব্যান করা হবে।
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Target Listing Summary */}
            <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] text-xs space-y-1">
              <div className="text-[11px] text-[#736B5E]">অভিযুক্ত পোস্ট:</div>
              <div className="font-bold text-[#2D3A3A] line-clamp-1">{itemTitle}</div>
              <div className="text-[11px] text-[#5A6B6B]">পোস্টদাতা: <strong>{accusedUserName}</strong></div>
            </div>

            {/* Reason selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#2D3A3A] block">
                অভিযোগের সুনির্দিষ্ট কারণ:
              </label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value as any)}
                className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-medium focus:outline-none focus:border-red-500"
              >
                <option key="opt-fraud" value="প্রতারণা বা অসত্য তথ্য">১. প্রতারণা বা অসত্য/ভুল তথ্য প্রদান</option>
                <option key="opt-hotel" value="বাণিজ্যিক হোটেল/বুকিং প্রতারণা">২. হোটেল/দৈনিক ভাড়া বা রুম বুকিং প্রতারণা</option>
                <option key="opt-fake" value="ভুয়া পাত্র/পাত্রীর তথ্য">৩. পাত্র বা পাত্রীর ভুয়া যোগ্যতা/অভিভাবকের মিথ্যা পরিচয়</option>
                <option key="opt-misconduct" value="অনুপযুক্ত আচরণ">৪. ফোনে বা চ্যাটে অনুপযুক্ত/অশালীন আচরণ</option>
                <option key="opt-other" value="অন্যান্য">৫. অন্যান্য নীতি লঙ্ঘন</option>
              </select>
            </div>

            {/* Proof Details */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#2D3A3A] block">
                সুনির্দিষ্ট বিবরণ ও প্রমাণ (এডমিন তদন্তের জন্য): <span className="text-red-500">*</span>
              </label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                rows={3}
                required
                placeholder="পোস্টদাতা কীভাবে বিভ্রান্তি সৃষ্টি করেছেন বা কী অসত্য বলেছেন তা বিস্তারিত লিখুন..."
                className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl p-3 text-xs text-[#2D3A3A] focus:outline-none focus:border-red-500 leading-relaxed"
              />
            </div>

            {/* Reporter Contact Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-[#5A6B6B] block">আপনার নাম (ঐচ্ছিক):</label>
                <input
                  type="text"
                  value={reporterName}
                  onChange={(e) => setReporterName(e.target.value)}
                  placeholder="আপনার নাম"
                  className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-1.5 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-[#5A6B6B] block">যোগাযোগের ফোন নম্বর:</label>
                <input
                  type="text"
                  value={reporterPhone}
                  onChange={(e) => setReporterPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-1.5 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>
            </div>

            <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 text-[11px] text-amber-900 leading-relaxed flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <span>
                <strong>সতর্কতা:</strong> মিথ্যা অভিযোগ দায়ের করলে আপনার নিজস্ব একাউন্টের বিরুদ্ধে ব্যবস্থা গ্রহণ করা হতে পারে। সঠিক প্রমাণের ভিত্তিতে এডমিন অভিযুক্তকে আংশিক নিষিদ্ধ করবেন।
              </span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E6E0D4]">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100 transition cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                disabled={isSubmitting || !details.trim()}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-red-600 text-white hover:bg-red-700 transition cursor-pointer flex items-center gap-1.5 shadow-xs disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'পাঠানো হচ্ছে...' : 'অভিযোগ জমা দিন'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
