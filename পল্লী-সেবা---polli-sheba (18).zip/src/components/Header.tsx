import React, { useState } from 'react';
import { 
  PhoneCall, 
  MapPin, 
  Sparkles, 
  Calendar,
  ChevronDown,
  Navigation,
  Settings as SettingsIcon,
  UserCheck,
  LogIn,
  Newspaper,
  ExternalLink,
  Globe,
  MessageSquare
} from 'lucide-react';
import { getBanglaCurrentDate } from '../utils/banglaNumbers';
import { BANGLADESH_DISTRICTS } from '../data/mockData';
import { getUpazilasForDistrict } from '../data/bangladeshLocations';
import { detectCurrentLocationGPS, saveUserLocation } from '../utils/locationService';
import { UserProfile } from '../types/auth';
import { useLanguage } from '../context/LanguageContext';

interface HeaderProps {
  selectedDistrict: string;
  onSelectDistrict: (district: string) => void;
  selectedUpazila?: string;
  onSelectUpazila?: (upazila: string) => void;
  onOpenAIAdvisor: () => void;
  onOpenHotlines: () => void;
  fontSizeClass: 'text-base' | 'text-lg';
  onToggleFontSize: () => void;
  onOpenAdmin?: () => void;
  onOpenSettings?: () => void;
  currentUser?: UserProfile | null;
  onOpenInbox?: () => void;
  unreadInboxCount?: number;
  onOpenAuth?: (action?: string) => void;
  onLogout?: () => void;
  unreadAlertsCount?: number;
  onOpenAlerts?: () => void;
  onOpenAccount?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  selectedDistrict,
  onSelectDistrict,
  selectedUpazila,
  onSelectUpazila,
  onOpenAIAdvisor,
  onOpenHotlines,
  fontSizeClass,
  onToggleFontSize,
  onOpenAdmin,
  onOpenSettings,
  currentUser,
  onOpenInbox,
  unreadInboxCount = 0,
  onOpenAuth,
  onOpenAccount
}) => {
  const dateInfo = getBanglaCurrentDate();
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const { language, toggleLanguage, t } = useLanguage();

  const handleDistrictChange = (d: string) => {
    onSelectDistrict(d);
    if (onSelectUpazila) onSelectUpazila('সকল উপজেলা');
    if (d !== 'সকল জেলা') {
      saveUserLocation({
        district: d,
        detectedAt: Date.now()
      });
    }
  };

  const handleUpazilaChange = (u: string) => {
    if (onSelectUpazila) onSelectUpazila(u);
    saveUserLocation({
      district: selectedDistrict,
      upazila: u !== 'সকল উপজেলা' ? u : undefined,
      detectedAt: Date.now()
    });
  };

  const handleQuickGps = async () => {
    setIsLocating(true);
    try {
      const res = await detectCurrentLocationGPS();
      if (res.success && res.district) {
        onSelectDistrict(res.district);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLocating(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#2D5A27] text-white shadow-md">
      {/* Top micro-bar with Bangla date with bar, hijri date, font controls and emergency hotline */}
      <div className="bg-[#23491E] py-1.5 px-3 sm:px-4 text-xs font-medium text-[#D4E4BC] flex flex-wrap justify-between items-center gap-2 border-b border-[#3D7A35]/50">
        <div className="flex flex-wrap items-center gap-2 text-[11px] sm:text-xs">
          {/* Bangla Date with Day */}
          <span className="flex items-center gap-1.5 bg-[#2D5A27] px-2.5 py-0.5 rounded-full text-[#D4E4BC] border border-[#3D7A35] shadow-2xs font-semibold">
            <Calendar className="w-3.5 h-3.5 text-[#E8924A]" />
            <span>{dateInfo.banglaDateWithDay} ({dateInfo.season})</span>
          </span>

          {/* Arabic / Hijri Date */}
          <span className="hidden md:flex items-center gap-1 bg-[#1B3A17] px-2 py-0.5 rounded-full text-[#F9E5D4] border border-[#3D7A35]/60 text-[11px]">
            <span>🌙</span>
            <span>{dateInfo.hijriDate}</span>
          </span>

          <span className="hidden lg:inline-block text-[#D4E4BC]/50">|</span>
          <span className="hidden lg:inline-block text-white/80">{dateInfo.englishFormatted}</span>
        </div>

        {/* Right side: Emergency Hotlines & Font Size Toggle */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap sm:flex-nowrap">
          {/* Emergency Hotlines Cluster */}
          <div className="flex items-center gap-1 text-[11px]">
            <span className="hidden sm:inline-block text-[#D4E4BC]/70 text-[10px] mr-0.5">{t('জরুরি সেবা:', 'Emergency:')}</span>

            {/* 999 National Emergency */}
            <a
              href="tel:999"
              className="flex items-center gap-1 bg-[#C0392B] hover:bg-[#A93226] text-white px-2 sm:px-2.5 py-0.5 rounded-full font-bold shadow-xs transition"
              title="জাতীয় জরুরি সেবা: ৯৯৯ / National Emergency: 999"
            >
              <PhoneCall className="w-3 h-3" />
              <span>{t('জরুরি ৯৯৯', 'Emergency 999')}</span>
            </a>

            {/* 16123 Agriculture Call Center */}
            <a
              href="tel:16123"
              className="flex items-center gap-1 bg-[#2E7D32] hover:bg-[#1B5E20] text-white px-2 py-0.5 rounded-full font-semibold shadow-xs transition"
              title="কৃষি কল সেন্টার: ১৬১২৩ / Agri Helpline: 16123"
            >
              <span>{t('কৃষি ১৬১২৩', 'Agri 16123')}</span>
            </a>

            {/* 16263 Health Helpline */}
            <a
              href="tel:16263"
              className="flex items-center gap-1 bg-[#0284C7] hover:bg-[#0369A1] text-white px-2 py-0.5 rounded-full font-semibold shadow-xs transition"
              title="স্বাস্থ্য বাতায়ন: ১৬২৬৩ / Health Helpline: 16263"
            >
              <span>{t('স্বাস্থ্য ১৬২৬৩', 'Health 16263')}</span>
            </a>

            {/* 333 Info & Social Services */}
            <a
              href="tel:333"
              className="flex items-center gap-1 bg-[#D97706] hover:bg-[#B45309] text-white px-2 py-0.5 rounded-full font-semibold shadow-xs transition"
              title="জাতীয় তথ্য ও নাগরিক সেবা: ৩৩৩ / Info: 333"
            >
              <span>{t('তথ্য ৩৩৩', 'Info 333')}</span>
            </a>

            {/* 109 Women & Children */}
            <a
              href="tel:109"
              className="hidden lg:flex items-center gap-1 bg-[#8E44AD] hover:bg-[#7D3C98] text-white px-2 py-0.5 rounded-full font-semibold shadow-xs transition"
              title="নারী ও শিশু হেল্পলাইন: ১০৯ / Women & Child: 109"
            >
              <span>{t('নারী/শিশু ১০৯', 'Child/Women 109')}</span>
            </a>

            {/* All Hotlines Directory Modal Launcher */}
            <button
              onClick={onOpenHotlines}
              className="flex items-center gap-0.5 bg-[#2D5A27] hover:bg-[#3D7A35] text-[#D4E4BC] hover:text-white px-1.5 py-0.5 rounded-full text-[10px] border border-[#3D7A35] transition cursor-pointer"
              title="সকল জরুরি হটলাইন ও সরকারি সেবা তালিকা"
            >
              <span>{t('সকল হটলাইন', 'All Hotlines')}</span>
            </button>
          </div>

          <span className="text-[#3D7A35] hidden sm:inline">|</span>

          {/* Bilingual Language Switcher */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1 bg-[#1E3F1A] hover:bg-[#2D5A27] border border-[#4E9344]/60 text-[#D4E4BC] px-2.5 py-0.5 rounded-lg text-xs font-bold transition cursor-pointer shrink-0 shadow-xs"
            title="ভাষা পরিবর্তন / Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-[#E8924A]" />
            <span>{language === 'bn' ? 'English' : 'বাংলা'}</span>
          </button>

          {/* Font size toggle */}
          <button 
            onClick={onToggleFontSize}
            className="flex items-center gap-1 bg-[#3D7A35] hover:bg-[#4E9344] text-[#FDFBF7] px-2 py-0.5 rounded-lg text-xs transition cursor-pointer shrink-0"
            title="বয়স্কদের পড়ার সুবিধার্থে লেখার আকার বড়/ছোট করুন"
          >
            <span>{t('ফন্ট:', 'Font:')}</span>
            <span className="font-bold">{fontSizeClass === 'text-lg' ? (language === 'bn' ? 'বড় (A+)' : 'Large (A+)') : (language === 'bn' ? 'স্বাভাবিক (A)' : 'Normal (A)')}</span>
          </button>
        </div>
      </div>


      {/* Main Header Row */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        {/* Brand with Polli Sheba Custom Logo matching uploaded branding */}
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center p-1 shadow-md border border-[#D4E4BC]/40 flex-shrink-0 overflow-hidden">
            <img 
              src="/logo.png" 
              alt="পল্লী সেবা" 
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer" 
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold tracking-tight text-white font-['Noto_Sans_Bengali'] leading-tight">
                {t('পল্লী সেবা', 'Polli Sheba')}
              </h1>
              <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-[11px] px-2.5 py-0.5 rounded-full shadow-xs">
                {t('ডিজিটাল প্ল্যাটফর্ম', 'Digital Platform')}
              </span>
            </div>
            <p className="text-xs text-[#D4E4BC] font-medium tracking-wide">
              {t('Polli Sheba • গ্রামীণ জনসেবা নেটওয়ার্ক', 'Polli Sheba • Rural Public Service Network')}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* District Picker with GPS */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleQuickGps}
              disabled={isLocating}
              className="p-2 rounded-2xl bg-[#23491E]/90 hover:bg-[#23491E] border border-[#3D7A35] text-[#E8924A] hover:text-white transition cursor-pointer shadow-inner shrink-0"
              title={t('জিপিএস দিয়ে বর্তমান এলাকা খুঁজুন', 'Locate via GPS')}
            >
              <Navigation className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin text-white' : ''}`} />
            </button>

            <div className="relative flex items-center bg-[#23491E]/90 hover:bg-[#23491E] border border-[#3D7A35] rounded-2xl px-3 py-2 text-xs text-[#D4E4BC] shadow-inner">
              <MapPin className="w-3.5 h-3.5 text-[#E8924A] mr-1.5 flex-shrink-0" />
              <select
                value={selectedDistrict}
                onChange={(e) => handleDistrictChange(e.target.value)}
                aria-label={t('আপনার জেলা নির্বাচন করুন', 'Select your district')}
                className="bg-transparent text-white font-medium focus:outline-none cursor-pointer pr-4 appearance-none"
              >
                <option value="সকল জেলা" className="bg-[#23491E] text-white">
                  {t('সকল জেলা (সমগ্র বাংলাদেশ)', 'All Districts (Whole Bangladesh)')}
                </option>
                {BANGLADESH_DISTRICTS.map((d) => (
                  <option key={d} value={d} className="bg-[#23491E] text-white">
                    {d} {t('জেলা', 'District')}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-3 h-3 text-[#D4E4BC] absolute right-2.5 pointer-events-none" />
            </div>

            {/* Upazila Picker when district is active */}
            {selectedDistrict !== 'সকল জেলা' && (
              <div className="relative flex items-center bg-[#23491E]/90 hover:bg-[#23491E] border border-[#3D7A35] rounded-2xl px-2.5 py-2 text-xs text-[#D4E4BC] shadow-inner">
                <select
                  value={selectedUpazila || 'সকল উপজেলা'}
                  onChange={(e) => handleUpazilaChange(e.target.value)}
                  aria-label={t('আপনার উপজেলা নির্বাচন করুন', 'Select your upazila')}
                  className="bg-transparent text-white font-medium focus:outline-none cursor-pointer pr-4 appearance-none text-xs"
                >
                  <option value="সকল উপজেলা" className="bg-[#23491E] text-white">{t('সকল উপজেলা', 'All Upazilas')}</option>
                  {getUpazilasForDistrict(selectedDistrict).map((u) => (
                    <option key={u} value={u} className="bg-[#23491E] text-white">
                      {u} {t('উপজেলা', 'Upazila')}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3 h-3 text-[#D4E4BC] absolute right-2 pointer-events-none" />
              </div>
            )}
          </div>

          {/* Inbox / Messages Button */}
          {onOpenInbox && (
            <button
              onClick={onOpenInbox}
              className="relative p-2 sm:px-3 sm:py-2 rounded-2xl bg-[#23491E]/90 hover:bg-[#23491E] border border-[#3D7A35] text-[#D4E4BC] hover:text-white transition cursor-pointer shadow-inner flex items-center gap-1.5 shrink-0"
              title="ইনবক্স ও চ্যাট বার্তা"
            >
              <MessageSquare className="w-4 h-4 text-[#D4E4BC]" />
              <span className="hidden md:inline font-semibold text-xs">ইনবক্স</span>
              {unreadInboxCount > 0 ? (
                <span className="bg-[#E74C3C] text-white text-[10px] font-extrabold px-1.5 py-0.2 rounded-full min-w-4 text-center animate-pulse shadow-xs">
                  {unreadInboxCount}
                </span>
              ) : null}
            </button>
          )}

          {/* AI Advisor Button */}
          <button
            onClick={onOpenAIAdvisor}
            className="flex items-center gap-1.5 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold px-4 py-2 rounded-2xl text-xs sm:text-sm shadow-md transition-all cursor-pointer transform hover:scale-102"
          >
            <Sparkles className="w-4 h-4 text-white fill-white" />
            <span className="font-semibold">{t('এআই পরামর্শক', 'AI Advisor')}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
