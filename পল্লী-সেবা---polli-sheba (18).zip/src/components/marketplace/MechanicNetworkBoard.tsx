import React, { useState, useMemo } from 'react';
import { 
  Wrench, 
  Search, 
  MapPin, 
  PhoneCall, 
  MessageCircle, 
  PlusCircle, 
  UserCheck, 
  CheckCircle2, 
  Clock, 
  X, 
  ShieldCheck, 
  Zap, 
  AlertTriangle,
  Flame,
  Settings,
  Tv,
  Droplets,
  Cpu,
  Bell,
  Users,
  Trash2
} from 'lucide-react';
import { HaatListing } from '../../types';
import { UserProfile, getUserFormDefaults } from '../../types/auth';
import { formatTaka } from '../../utils/banglaNumbers';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';
import { ChatModal } from '../chat/ChatModal';
import { CallChoiceModal } from '../transport/CallChoiceModal';
import { InAppVoiceCallModal } from '../transport/InAppVoiceCallModal';
import { maskPhoneNumber } from '../transport/RuralTransport';
import { saveCloudHaatItem, deleteCloudHaatItem, broadcastLocalizedDemandNotification } from '../../lib/cloudSync';

interface MechanicNetworkBoardProps {
  currentDistrict: string;
  currentUser?: UserProfile | null;
  onOpenAuth?: (action?: string) => void;
  listings: HaatListing[];
  onAddListing: (listing: HaatListing) => void;
  onDeleteListing?: (id: string) => void;
  onToggleStatus?: (id: string) => void;
}

const MECHANIC_TRADES = [
  'সকল কাজ',
  'ইলেকট্রিশিয়ান ও গৃহ ওয়্যারিং',
  'পানির পাম্প ও মোটর',
  'ফ্রিজ, টিভি ও ফ্যান',
  'শ্যালো মেশিন ও কৃষি ইঞ্জিন',
  'মোটরসাইকেল ও অটোরিকশা',
  'মোবাইল ও কম্পিউটার',
  'অন্যান্য'
];

export const MechanicNetworkBoard: React.FC<MechanicNetworkBoardProps> = ({
  currentDistrict,
  currentUser,
  onOpenAuth,
  listings,
  onAddListing,
  onDeleteListing,
  onToggleStatus
}) => {
  const [subTab, setSubTab] = useState<'all' | 'avail' | 'need'>('all');
  const [statusFilter, setStatusFilter] = useState<'active' | 'completed' | 'all'>('active');
  const [selectedTrade, setSelectedTrade] = useState<string>('সকল কাজ');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterAddress, setFilterAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : '',
    upazila: '',
    union: '',
    village: ''
  });

  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [formType, setFormType] = useState<'mechanic_avail' | 'mechanic_need'>('mechanic_avail');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [trade, setTrade] = useState('ইলেকট্রিশিয়ান ও গৃহ ওয়্যারিং');
  const [experience, setExperience] = useState('৫ বছরের বাস্তব অভিজ্ঞতা');
  const [serviceAvailability, setServiceAvailability] = useState('২৪ ঘণ্টা অন-কল জরুরি সেবা');
  const [price, setPrice] = useState('');
  const [isNegotiable, setIsNegotiable] = useState(true);
  const [hideVillage, setHideVillage] = useState(true);
  const [allowOfflineCall, setAllowOfflineCall] = useState<boolean>(false);
  const [description, setDescription] = useState('');
  const [notificationScope, setNotificationScope] = useState<'upazila' | 'district'>('district');
  const [formAddress, setFormAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : 'বগুড়া',
    upazila: '',
    union: '',
    village: ''
  });

  const populateDefaults = () => {
    const defaults = getUserFormDefaults(currentUser);
    if (defaults.name) setName(defaults.name);
    if (defaults.phone) setPhone(defaults.phone);
    if (defaults.district && defaults.district !== 'সকল জেলা') {
      setFormAddress(prev => ({
        ...prev,
        district: defaults.district,
        upazila: defaults.upazila || prev.upazila,
        union: defaults.union || prev.union,
        village: defaults.village || prev.village
      }));
    } else if (currentDistrict !== 'সকল জেলা') {
      setFormAddress(prev => ({ ...prev, district: currentDistrict }));
    }
    setAllowOfflineCall(defaults.allowOfflineCall);
    setHideVillage(defaults.hideVillage);
  };

  React.useEffect(() => {
    populateDefaults();
  }, [currentUser, currentDistrict]);

  // Call & Chat States
  const [activeChatListing, setActiveChatListing] = useState<HaatListing | null>(null);
  const [activeCallingItem, setActiveCallingItem] = useState<HaatListing | null>(null);
  const [inAppVoiceItem, setInAppVoiceItem] = useState<HaatListing | null>(null);

  // Filter Mechanic Listings
  const mechanicListings = useMemo(() => {
    return listings.filter(item => {
      const isMechanicCategory = 
        item.category === 'ইলেকট্রিশিয়ান ও মেকানিক' || 
        item.itemType === 'ইলেকট্রিশিয়ান' || 
        item.itemType === 'মেকানিক' ||
        !!item.mechanicType;

      if (!isMechanicCategory) return false;

      // Status Filter: active vs completed
      const isCompletedOrSold = !!(item.isSold || item.isCompleted);
      if (statusFilter === 'active' && isCompletedOrSold) {
        return false;
      }
      if (statusFilter === 'completed' && !isCompletedOrSold) {
        return false;
      }

      // Sub-tab filter
      if (subTab === 'avail' && item.mechanicType === 'mechanic_need') {
        return false;
      }
      if (subTab === 'need' && item.mechanicType === 'mechanic_avail') {
        return false;
      }

      // Trade filter
      if (selectedTrade !== 'সকল কাজ') {
        const queryTrade = selectedTrade.split(' ')[0];
        const match = 
          (item.mechanicTrade && item.mechanicTrade.includes(queryTrade)) ||
          (item.title && item.title.includes(queryTrade)) ||
          (item.description && item.description.includes(queryTrade));
        if (!match) return false;
      }

      // Location hierarchy filters
      if (filterAddress.district && filterAddress.district !== 'সকল জেলা' && item.district !== filterAddress.district) {
        return false;
      }
      if (filterAddress.upazila && filterAddress.upazila !== 'সকল উপজেলা') {
        const uq = filterAddress.upazila.toLowerCase().trim();
        const itemU = (item.upazila || '').toLowerCase();
        const itemLoc = (item.location || '').toLowerCase();
        if (!itemU.includes(uq) && !itemLoc.includes(uq)) return false;
      }
      if (filterAddress.union && filterAddress.union !== 'সকল ইউনিয়ন') {
        const uwq = filterAddress.union.toLowerCase().trim();
        const itemUW = (item.unionOrWard || '').toLowerCase();
        const itemLoc = (item.location || '').toLowerCase();
        if (!itemUW.includes(uwq) && !itemLoc.includes(uwq)) return false;
      }
      if (filterAddress.village.trim()) {
        const vq = filterAddress.village.toLowerCase().trim();
        const itemV = (item.village || '').toLowerCase();
        const itemLoc = (item.location || '').toLowerCase();
        if (!itemV.includes(vq) && !itemLoc.includes(vq)) return false;
      }

      // Search Query
      if (searchQuery.trim()) {
        const sq = searchQuery.toLowerCase().trim();
        const matchTitle = item.title.toLowerCase().includes(sq);
        const matchSeller = item.sellerName.toLowerCase().includes(sq);
        const matchTrade = (item.mechanicTrade || '').toLowerCase().includes(sq);
        const matchExp = (item.experience || '').toLowerCase().includes(sq);
        const matchDesc = (item.description || '').toLowerCase().includes(sq);
        const matchLoc = (item.location || '').toLowerCase();
        if (!matchTitle && !matchSeller && !matchTrade && !matchExp && !matchDesc && !matchLoc) {
          return false;
        }
      }

      return true;
    });
  }, [listings, subTab, statusFilter, selectedTrade, filterAddress, searchQuery]);

  const handleSubmitListing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !name.trim() || !phone.trim() || !formAddress.district) {
      alert('দয়া করে শিরোনাম, আপনার নাম, মোবাইল নম্বর এবং জেলা পূরণ করুন।');
      return;
    }

    const compiledLocation = [
      formAddress.village && !hideVillage ? `গ্রাম: ${formAddress.village}` : '',
      formAddress.union ? formAddress.union : '',
      formAddress.upazila ? `উপজেলা: ${formAddress.upazila}` : '',
      formAddress.district ? `${formAddress.district} জেলা` : ''
    ].filter(Boolean).join(', ') || `${formAddress.district} জেলা`;

    const now = Date.now();
    const newListing: HaatListing = {
      id: `haat-mech-${now}`,
      title: title.trim(),
      category: 'ইলেকট্রিশিয়ান ও মেকানিক',
      itemType: formType === 'mechanic_avail' ? 'ইলেকট্রিশিয়ান' : 'মেকানিক',
      price: parseFloat(price) || 0,
      unit: formType === 'mechanic_avail' ? 'ভিজিট ফি' : 'চুক্তির ভিত্তিতে',
      sellerName: name.trim(),
      sellerRole: formType === 'mechanic_avail' ? 'mechanic' : 'citizen',
      sellerId: currentUser?.id,
      phone: phone.trim(),
      location: compiledLocation,
      district: formAddress.district,
      upazila: formAddress.upazila || undefined,
      unionOrWard: formAddress.union || undefined,
      village: formAddress.village || undefined,
      hideVillage,
      allowOfflineCall,
      description: description.trim(),
      createdAt: 'এইমাত্র প্রকাশিত',
      createdAtTimestamp: now,
      isNegotiable,
      isPerishable: false,
      expiryDays: 30,
      expiryDateTimestamp: now + 30 * 24 * 60 * 60 * 1000,
      isSold: false,
      mechanicType: formType,
      mechanicTrade: trade,
      experience: experience.trim(),
      serviceAvailability: serviceAvailability.trim()
    };

    onAddListing(newListing);
    saveCloudHaatItem(newListing);

    try {
      const existing = JSON.parse(localStorage.getItem('polli_user_posted_items') || '[]');
      localStorage.setItem('polli_user_posted_items', JSON.stringify([...existing, newListing.id]));
    } catch {
      // ignore
    }

    // Auto localized notification broadcast to neighbors
    broadcastLocalizedDemandNotification({
      id: newListing.id,
      title: newListing.title,
      category: formType === 'mechanic_avail' ? 'মেকানিক ও কারিগর সেবা' : 'মেকানিক ও মিস্ত্রি আবশ্যক',
      scope: notificationScope,
      district: formAddress.district,
      upazila: formAddress.upazila,
      union: formAddress.unionOrWard,
      sellerName: name.trim(),
      phone: phone.trim(),
      targetRole: formType === 'mechanic_need' ? 'mechanic' : 'all',
      targetCategory: 'marketplace',
      targetSubTab: { market: 'mechanics' }
    });

    setToastMessage(
      formType === 'mechanic_avail' 
        ? `আপনার মেকানিক সেবা সফলভাবে নিবন্ধিত হয়েছে! (${notificationScope === 'upazila' && formAddress.upazila ? `${formAddress.upazila} উপজেলায়` : `${formAddress.district} জেলায়`} নোটিফিকেশন পাঠানো হয়েছে)` 
        : `মেকানিক প্রয়োজন সংক্রান্ত জরুরি বিজ্ঞপ্তি প্রকাশিত হয়েছে! (${notificationScope === 'upazila' && formAddress.upazila ? `${formAddress.upazila} উপজেলার` : `${formAddress.district} জেলার`} সকল মেকানিকদের কাছে নোটিফিকেশন পৌঁছে দেওয়া হয়েছে)`
    );
    setTimeout(() => setToastMessage(null), 4000);

    // Reset Form
    setTitle('');
    setDescription('');
    setPrice('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-[#1E293B] via-[#0F766E] to-[#14532D] text-white p-6 rounded-3xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="bg-[#A7F3D0] text-[#064E3B] font-bold text-xs px-3 py-0.5 rounded-full inline-flex items-center gap-1">
              <Zap className="w-3.5 h-3.5" />
              <span>ইলেকট্রিশিয়ান ও কারিগর মেকানিক বোর্ড</span>
            </span>
            <span className="bg-white/20 text-white text-[11px] font-semibold px-2.5 py-0.5 rounded-full">
              🔧 দালালমুক্ত সরাসরি মিস্ত্রি ও গ্রাহক সংযোগ নেটওয়ার্ক
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold">
            এলাকাভিত্তিক ইলেকট্রিশিয়ান ও জরুরি মেরামত মিস্ত্রি সেবা
          </h2>
          <p className="text-[#A7F3D0] text-xs sm:text-sm max-w-2xl leading-relaxed">
            পল্লী বিদ্যুৎ ওয়্যারিং, পানির মোটর, শ্যালো মেশিন, ফ্রিজ, টিভি বা সিলিং ফ্যানের অভিজ্ঞ কারিগর খুঁজুন। মেরামত বা ওয়্যারিংয়ের কাজের প্রয়োজনে সরাসরি জরুরি মেকানিক চেয়ে বিজ্ঞাপন দিন।
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
          <button
            onClick={() => {
              if (!currentUser) {
                onOpenAuth?.('মেকানিক খুঁজতে বিজ্ঞাপন দিতে অনুগ্রহ করে লগইন বা নিবন্ধন করুন');
                return;
              }
              setFormType('mechanic_need');
              setShowAddModal(true);
            }}
            className="flex items-center justify-center gap-2 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold px-4 py-3 rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer whitespace-nowrap"
          >
            <PlusCircle className="w-4 h-4" />
            <span>জরুরি মেকানিক চাই বিজ্ঞাপন</span>
          </button>
        </div>
      </div>

      {/* Toast Alert */}
      {toastMessage && (
        <div className="p-3.5 bg-[#E8F8F5] border border-[#27AE60]/40 text-[#27AE60] text-xs sm:text-sm font-bold rounded-2xl flex items-center gap-2 shadow-xs animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Sub-Tab Filter */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-[#E6E0D4] space-y-4 shadow-2xs">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
          <div className="flex bg-[#FAF8F5] p-1 rounded-2xl border border-[#E6E0D4] text-xs overflow-x-auto">
            <button
              onClick={() => setSubTab('all')}
              className={`px-3 sm:px-4 py-2 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                subTab === 'all' ? 'bg-[#0F766E] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
              }`}
            >
              সকল মিস্ত্রি ও সেবা ({mechanicListings.length})
            </button>
            <button
              onClick={() => setSubTab('avail')}
              className={`px-3 sm:px-4 py-2 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                subTab === 'avail' ? 'bg-[#0F766E] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
              }`}
            >
              👨‍🔧 প্রস্তুত মেকানিক
            </button>
            <button
              onClick={() => setSubTab('need')}
              className={`px-3 sm:px-4 py-2 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                subTab === 'need' ? 'bg-[#0F766E] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
              }`}
            >
              🚨 মিস্ত্রি প্রয়োজন
            </button>
          </div>

          {/* Status Filter: Active vs Completed vs All */}
          <div className="flex items-center gap-2">
            <div className="flex bg-[#FAF8F5] p-1 rounded-2xl border border-[#E6E0D4] text-xs shrink-0">
              <button
                onClick={() => setStatusFilter('active')}
                className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                  statusFilter === 'active' ? 'bg-[#2D5A27] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                }`}
                title="বর্তমানে সেবা দেওয়া বা নেওয়ার জন্য প্রস্তুত"
              >
                🟢 শুধু সক্রিয়
              </button>
              <button
                onClick={() => setStatusFilter('completed')}
                className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                  statusFilter === 'completed' ? 'bg-[#0F766E] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                }`}
                title="সেবা সম্পন্ন / সমাধান হয়েছে (হাইড)"
              >
                ✅ সম্পন্ন
              </button>
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-2.5 py-1.5 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                  statusFilter === 'all' ? 'bg-[#5A6B6B] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                }`}
              >
                সকল
              </button>
            </div>

            {/* Quick Search */}
            <div className="relative flex-1 sm:w-56">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#736B5E]" />
              <input
                type="text"
                placeholder="মোটর, ওয়্যারিং বা ফ্রিজ..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-2xl pl-9 pr-3 py-2 text-xs focus:outline-none focus:border-[#0F766E]"
              />
            </div>
          </div>
        </div>

        {/* Trade Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
          <span className="text-[11px] font-bold text-[#5A6B6B] whitespace-nowrap">ট্রেড বা কাজ:</span>
          {MECHANIC_TRADES.map(t => (
            <button
              key={t}
              onClick={() => setSelectedTrade(t)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer ${
                selectedTrade === t
                  ? 'bg-[#0F766E] text-white shadow-2xs'
                  : 'bg-[#FAF8F5] text-[#5A6B6B] hover:bg-[#E2F1ED] border border-[#E6E0D4]'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Cascading Address Hierarchy Selector */}
        <div className="pt-2 border-t border-[#E6E0D4]">
          <div className="text-xs font-bold text-[#2D3A3A] mb-2 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#0F766E]" />
            <span>এলাকা নির্বাচন করুন (জেলা ➔ উপজেলা ➔ ইউনিয়ন):</span>
          </div>
          <CascadingAddressSelector
            address={filterAddress}
            onChange={(newAddr) => setFilterAddress(newAddr)}
            showVillage={true}
            allowAllOption={true}
            villagePlaceholder="গ্রাম বা বাজারের নাম (ঐচ্ছিক)"
          />
        </div>
      </div>

      {/* Mechanic Listings Grid */}
      {mechanicListings.length === 0 ? (
        <div className="bg-white p-12 rounded-3xl border border-[#E6E0D4] text-center space-y-3">
          <div className="w-14 h-14 bg-[#FAF8F5] rounded-full flex items-center justify-center mx-auto text-[#736B5E]">
            <Wrench className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-base text-[#2D3A3A]">কোনো মেকানিক বা মিস্ত্রি বিজ্ঞপ্তি পাওয়া যায়নি</h3>
          <p className="text-xs text-[#5A6B6B] max-w-md mx-auto">
            আপনার নির্বাচিত ফিল্টার বা এলাকার জন্য কোনো মেকানিক বিজ্ঞাপন নেই। আপনি নিজেই প্রথম সেবা বা মেরামতের বিজ্ঞপ্তি দিন!
          </p>
          <div className="pt-2 flex justify-center gap-2">
            <button
              onClick={() => {
                if (!currentUser) {
                  onOpenAuth?.('মেকানিক হিসেবে সেবা পোস্ট করতে অনুগ্রহ করে লগইন বা নিবন্ধন করুন');
                  return;
                }
                setFormType('mechanic_avail');
                setShowAddModal(true);
              }}
              className="px-4 py-2 bg-[#0F766E] text-white text-xs font-bold rounded-2xl hover:bg-[#0c5c56] transition cursor-pointer"
            >
              আমি মেকানিক / সেবা বিজ্ঞাপন
            </button>
            <button
              onClick={() => {
                if (!currentUser) {
                  onOpenAuth?.('মেকানিক খুঁজতে বিজ্ঞাপন দিতে অনুগ্রহ করে লগইন বা নিবন্ধন করুন');
                  return;
                }
                setFormType('mechanic_need');
                setShowAddModal(true);
              }}
              className="px-4 py-2 bg-[#E8924A] text-white text-xs font-bold rounded-2xl hover:bg-[#D97D35] transition cursor-pointer"
            >
              জরুরি মিস্ত্রি চাই বিজ্ঞাপন
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mechanicListings.map(item => {
            const isOfferingService = item.mechanicType === 'mechanic_avail' || item.itemType === 'ইলেকট্রিশিয়ান';
            return (
              <div 
                key={item.id}
                className="bg-white rounded-3xl border border-[#E6E0D4] p-5 shadow-2xs hover:shadow-md transition flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Badge & Mode */}
                  <div className="flex items-center justify-between gap-2">
                    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
                      isOfferingService 
                        ? 'bg-teal-50 text-teal-800 border border-teal-200' 
                        : 'bg-amber-50 text-amber-900 border border-amber-200'
                    }`}>
                      {isOfferingService ? (
                        <>
                          <Zap className="w-3.5 h-3.5 text-teal-600" />
                          <span>সেবা দিচ্ছেন (দক্ষ মিস্ত্রি)</span>
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
                          <span>জরুরি মেকানিক আবশ্যক</span>
                        </>
                      )}
                    </span>

                    <span className="text-[10px] text-[#736B5E] flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{item.createdAt}</span>
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-bold text-sm sm:text-base text-[#1E293B] line-clamp-2 leading-snug">
                    {item.title}
                  </h3>

                  {/* Highlights Grid */}
                  <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-2 text-xs">
                    {item.mechanicTrade && (
                      <div className="flex items-start gap-1.5 text-[#2D3A3A]">
                        <span className="font-bold text-[#5A6B6B] min-w-[70px]">ট্রেড/কাজ:</span>
                        <span className="font-semibold text-[#0F766E]">{item.mechanicTrade}</span>
                      </div>
                    )}
                    {item.experience && (
                      <div className="flex items-start gap-1.5 text-[#2D3A3A]">
                        <span className="font-bold text-[#5A6B6B] min-w-[70px]">অভিজ্ঞতা:</span>
                        <span className="text-[#2D3A3A] font-semibold">{item.experience}</span>
                      </div>
                    )}
                    {item.serviceAvailability && (
                      <div className="flex items-start gap-1.5 text-[#2D3A3A]">
                        <span className="font-bold text-[#5A6B6B] min-w-[70px]">উপলব্ধতা:</span>
                        <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded text-[11px] font-bold">
                          {item.serviceAvailability}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Description */}
                  {item.description && (
                    <p className="text-xs text-[#5A6B6B] line-clamp-3 leading-relaxed">
                      {item.description}
                    </p>
                  )}

                  {/* Location & Village privacy */}
                  <div className="flex items-center gap-1.5 text-xs text-[#736B5E] pt-1">
                    <MapPin className="w-3.5 h-3.5 text-[#0F766E] shrink-0" />
                    <span className="truncate">
                      {item.hideVillage 
                        ? `${item.upazila ? item.upazila + ', ' : ''}${item.district}` 
                        : item.location}
                    </span>
                    {item.hideVillage && (
                      <span className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.2 rounded shrink-0">
                        গ্রাম গোপন
                      </span>
                    )}
                  </div>
                </div>

                {/* Bottom Section: Charges & Contact */}
                <div className="pt-4 mt-3 border-t border-[#E6E0D4] space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-[#5A6B6B] block">
                        {isOfferingService ? 'ভিজিট / সার্ভিস চার্জ' : 'প্রস্তাবিত পারিশ্রমিক'}
                      </span>
                      <span className="font-bold text-base text-[#0F766E]">
                        {item.price > 0 ? `${formatTaka(item.price)} টাকা` : 'আলোচনা সাপেক্ষে'}
                      </span>
                      {item.price > 0 && <span className="text-[10px] text-[#736B5E]"> {item.unit || ''}</span>}
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-[#5A6B6B] block">মিস্ত্রি/বিজ্ঞাপনদাতা</span>
                      <span className="text-xs font-bold text-[#2D3A3A]">{item.sellerName}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        if (!currentUser) {
                          onOpenAuth?.('মিস্ত্রি বা কারিগরের সাথে কল বা যোগাযোগ করতে লগইন বা নিবন্ধন করুন');
                          return;
                        }
                        setActiveCallingItem(item);
                      }}
                      className="flex items-center justify-center gap-1.5 bg-[#0F766E] hover:bg-[#0c5c56] text-white py-2.5 px-3 rounded-2xl text-xs font-bold transition cursor-pointer shadow-2xs"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>কল করুন</span>
                    </button>

                    <button
                      onClick={() => {
                        if (!currentUser) {
                          onOpenAuth?.('মিস্ত্রি বা কারিগরের সাথে মেসেজ পাঠাতে লগইন বা নিবন্ধন করুন');
                          return;
                        }
                        setActiveChatListing(item);
                      }}
                      className="flex items-center justify-center gap-1.5 bg-[#E2F1ED] hover:bg-[#cbe7df] text-[#0F766E] py-2.5 px-3 rounded-2xl text-xs font-bold transition cursor-pointer border border-[#A7F3D0]"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>মেসেজ</span>
                    </button>
                  </div>

                  {/* Action Bar: Owner/Admin vs Visitor */}
                  {(() => {
                    const cleanPhone = (p?: string) => p ? p.replace(/[^0-9]/g, '') : '';
                    let localPostedIds: string[] = [];
                    try {
                      localPostedIds = JSON.parse(localStorage.getItem('polli_user_posted_items') || '[]');
                    } catch {
                      localPostedIds = [];
                    }
                    const isAdminSession = typeof window !== 'undefined' && sessionStorage.getItem('polli_logged_admin') === 'true';

                    const isOwnerOrAdmin = Boolean(
                      isAdminSession ||
                      localPostedIds.includes(item.id) ||
                      (currentUser && (
                        currentUser.id === item.sellerId ||
                        (cleanPhone(currentUser.phone) && cleanPhone(item.phone) && cleanPhone(currentUser.phone) === cleanPhone(item.phone)) ||
                        currentUser.role === 'admin' ||
                        cleanPhone(currentUser.phone) === '01700000000'
                      ))
                    );

                    const isCompleted = !!(item.isSold || item.isCompleted);

                    if (isOwnerOrAdmin) {
                      return (
                        <div className="flex items-center justify-between text-[11px] pt-2 border-t border-dashed border-[#E6E0D4] text-[#5A6B6B]">
                          <button
                            onClick={() => onToggleStatus ? onToggleStatus(item.id) : null}
                            className="text-[#0F766E] hover:underline font-bold flex items-center gap-1 cursor-pointer bg-teal-50 px-2.5 py-1 rounded-lg border border-teal-200"
                            title={isCompleted ? 'বিজ্ঞাপনটি পুনরায় সক্রিয় করুন' : 'কাজ সম্পন্ন বা সমস্যা সমাধান হলে হাইড করুন'}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#0F766E]" />
                            <span>{isCompleted ? 'পুনরায় সক্রিয় করুন' : 'সম্পন্ন / হাইড করুন'}</span>
                          </button>

                          <button
                            onClick={() => {
                              if (window.confirm('আপনি কি নিশ্চিত যে এই মেকানিক বিজ্ঞপ্তিটি সম্পূর্ণ মুছে ফেলতে চান?')) {
                                onDeleteListing?.(item.id);
                                deleteCloudHaatItem(item.id);
                              }
                            }}
                            className="text-[#C0392B] hover:underline font-semibold flex items-center gap-1 cursor-pointer px-2 py-1 rounded-lg hover:bg-red-50 border border-red-100"
                            title="বিজ্ঞপ্তিটি স্থায়ীভাবে মুছে ফেলুন"
                          >
                            <Trash2 className="w-3 h-3" />
                            <span>মুছুন</span>
                          </button>
                        </div>
                      );
                    }

                    if (isCompleted) {
                      return (
                        <div className="flex items-center justify-between text-[10px] pt-1.5 bg-gray-50 px-2 py-1 rounded-lg border border-gray-200 text-gray-600">
                          <span className="font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>{isOfferingService ? 'মেকানিকের কাজ সম্পন্ন হয়েছে' : 'মিস্ত্রি পাওয়া গেছে ও কাজ সম্পন্ন'}</span>
                          </span>
                        </div>
                      );
                    }

                    return null;
                  })()}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Mechanic Listing Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[88vh] sm:max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E0D4] overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] p-4 sm:p-5 shrink-0 bg-white">
              <div>
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="bg-[#A7F3D0] text-[#064E3B] text-[10px] font-bold px-2 py-0.5 rounded-full">
                    ইলেকট্রিশিয়ান ও মেকানিক সেবা
                  </span>
                  <span className="text-xs text-[#5A6B6B]">| পল্লী সেবা</span>
                </div>
                <h3 className="font-bold text-base text-[#1E293B]">
                  জরুরি মেকানিক বা ইলেকট্রিশিয়ান চেয়ে বিজ্ঞাপন দিন
                </h3>
                <p className="text-[11px] text-[#5A6B6B] mt-0.5">
                  আপনার এলাকার মেরামত কাজের বিবরণ দিয়ে দক্ষ মেকানিক বা ওয়্যারিং মিস্ত্রি খুঁজতে পোস্ট করুন
                </p>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitListing} className="flex flex-col flex-1 overflow-hidden">
              <div className="p-4 sm:p-5 overflow-y-auto overscroll-contain flex-1 space-y-3.5">
              {/* Title */}
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  বিজ্ঞাপনের মূল শিরোনাম *
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    formType === 'mechanic_avail'
                      ? 'যেমন: দক্ষ পল্লী বিদ্যুৎ ওয়্যারিং ও পানির মোটর মেকানিক'
                      : 'যেমন: সেচের শ্যালো মেশিন বিকল - জরুরি মিস্ত্রি প্রয়োজন'
                  }
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
                />
              </div>

              {/* Trade & Experience */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    কাজের ধরন / ট্রেড *
                  </label>
                  <select
                    value={trade}
                    onChange={(e) => setTrade(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
                  >
                    <option value="ইলেকট্রিশিয়ান ও গৃহ ওয়্যারিং">ইলেকট্রিশিয়ান ও গৃহ ওয়্যারিং</option>
                    <option value="পানির পাম্প ও মোটর">পানির পাম্প ও মোটর</option>
                    <option value="ফ্রিজ, টিভি ও ফ্যান">ফ্রিজ, টিভি ও ফ্যান</option>
                    <option value="শ্যালো মেশিন ও কৃষি ইঞ্জিন">শ্যালো মেশিন ও কৃষি ইঞ্জিন</option>
                    <option value="মোটরসাইকেল ও অটোরিকশা">মোটরসাইকেল ও অটোরিকশা</option>
                    <option value="মোবাইল ও কম্পিউটার">মোবাইল ও কম্পিউটার</option>
                    <option value="অন্যান্য মেকানিক">অন্যান্য মেকানিক</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    কাজের অভিজ্ঞতা / পারদর্শিতা
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: ৫ বছরের বাস্তব অভিজ্ঞতা"
                    value={experience}
                    onChange={(e) => setExperience(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
                  />
                </div>
              </div>

              {/* Availability & Fee */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    সেবা প্রদানের সময় / জরুরি প্রাপ্যতা
                  </label>
                  <select
                    value={serviceAvailability}
                    onChange={(e) => setServiceAvailability(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
                  >
                    <option value="২৪ ঘণ্টা অন-কল জরুরি সেবা">২৪ ঘণ্টা অন-কল জরুরি সেবা</option>
                    <option value="সকাল ৮টা - রাত ১০টা">সকাল ৮টা - রাত ১০টা</option>
                    <option value="হোম সার্ভিস (ফোনে কল দিলেই হাজির)">হোম সার্ভিস (ফোনে কল দিলেই হাজির)</option>
                    <option value="আজই জরুরি ভিত্তিতে আবশ্যক">আজই জরুরি ভিত্তিতে আবশ্যক</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    {formType === 'mechanic_avail' ? 'ভিজিট চার্জ / সার্ভিস ফি (টাকা)' : 'প্রস্তাবিত বাজেট (টাকা)'}
                  </label>
                  <input
                    type="number"
                    placeholder="যেমন: ৩০০"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
                  />
                </div>
              </div>

              {/* Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    আপনার নাম *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="আপনার পুরো নাম"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    মোবাইল নম্বর (যোগাযোগের জন্য) *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৭xxxxxxxx"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
                  />
                </div>
              </div>

              {/* Cascading Location Selector */}
              <div className="pt-2 border-t border-[#E6E0D4]">
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1.5">
                  আপনার এলাকা নির্বাচন করুন (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ গ্রাম) *
                </label>
                <CascadingAddressSelector
                  address={formAddress}
                  onChange={(newAddr) => setFormAddress(newAddr)}
                  showVillage={true}
                  villagePlaceholder="গ্রাম বা মোড়ের নাম"
                />

                <div className="mt-2 flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="mechHideVillage"
                    checked={hideVillage}
                    onChange={(e) => setHideVillage(e.target.checked)}
                    className="rounded text-[#0F766E] focus:ring-[#0F766E]"
                  />
                  <label htmlFor="mechHideVillage" className="text-xs text-[#5A6B6B] cursor-pointer">
                    🔒 গোপনীয়তা রক্ষা: বিজ্ঞাপনে শুধু উপজেলা ও জেলা দেখাবে (গ্রাম হাইড থাকবে)
                  </label>
                </div>
              </div>

              {/* Local Notification Scope Selection */}
              <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#D4C3A3] space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-[#0F766E] flex items-center gap-1.5">
                    <Bell className="w-3.5 h-3.5 text-[#E8924A]" />
                    <span>নোটিফিকেশন এলাকা পরিধি (কারা তাৎক্ষণিক অ্যালার্ট পাবে):</span>
                  </label>
                  <span className="text-[10px] text-[#736B5E]">স্মার্ট অ্যালার্ট</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNotificationScope('upazila')}
                    className={`p-2.5 rounded-xl text-xs font-bold border text-left transition flex items-center gap-2 cursor-pointer ${
                      notificationScope === 'upazila'
                        ? 'bg-[#0F766E] text-white border-[#0F766E] shadow-xs'
                        : 'bg-white text-[#5A6B6B] border-[#D4C3A3] hover:bg-gray-50'
                    }`}
                  >
                    <MapPin className="w-3.5 h-3.5 shrink-0 text-[#E8924A]" />
                    <div>
                      <div className="leading-tight">উপজেলা ভিত্তিক</div>
                      <div className={`text-[10px] font-normal ${notificationScope === 'upazila' ? 'text-teal-100' : 'text-[#736B5E]'}`}>
                        {formAddress.upazila ? `${formAddress.upazila} উপজেলা` : 'আমার উপজেলার সবাই'}
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setNotificationScope('district')}
                    className={`p-2.5 rounded-xl text-xs font-bold border text-left transition flex items-center gap-2 cursor-pointer ${
                      notificationScope === 'district'
                        ? 'bg-[#0F766E] text-white border-[#0F766E] shadow-xs'
                        : 'bg-white text-[#5A6B6B] border-[#D4C3A3] hover:bg-gray-50'
                    }`}
                  >
                    <Users className="w-3.5 h-3.5 shrink-0 text-[#E8924A]" />
                    <div>
                      <div className="leading-tight">জেলা ভিত্তিক (ডিফল্ট)</div>
                      <div className={`text-[10px] font-normal ${notificationScope === 'district' ? 'text-teal-100' : 'text-[#736B5E]'}`}>
                        {formAddress.district ? `${formAddress.district} জেলা` : 'পুরো জেলার সবাই'}
                      </div>
                    </div>
                  </button>
                </div>

                <p className="text-[10px] text-[#736B5E] leading-tight">
                  {notificationScope === 'upazila'
                    ? `📍 শুধুমাত্র ${formAddress.upazila || 'আপনার'} উপজেলার নিবন্ধিত ভাই-বোনেরা পুশ নোটিফিকেশন পাবেন।`
                    : `🌐 পুরো ${formAddress.district || 'আপনার'} জেলার নিবন্ধিত ভাই-বোনেরা নোটিফিকেশন পাবেন।`}
                </p>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  বিস্তারিত বিবরণ
                </label>
                <textarea
                  rows={2}
                  placeholder="কী কী যন্ত্রাংশ মেরামত করেন, কোনো বিশেষ যন্ত্রপাতি আছে কি না লিখুন..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
                />
              </div>

              {/* Global Auto-fill & Offline Call Status Box */}
              <div className="bg-[#FAF6ED] border border-[#E6DEC8] rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                    <span>📞</span>
                    <span>অফলাইন সরাসরি কল পারমিশন (Auto-fill)</span>
                  </span>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                    allowOfflineCall 
                      ? 'bg-[#D4E4BC] text-[#2D5A27] border-[#2D5A27]/30' 
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}>
                    {allowOfflineCall ? 'অনুমোদিত (হ্যাঁ)' : 'সুরক্ষিত/গোপন (না)'}
                  </span>
                </div>

                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={allowOfflineCall}
                    onChange={(e) => setAllowOfflineCall(e.target.checked)}
                    className="w-4 h-4 rounded text-[#0F766E] focus:ring-[#0F766E] cursor-pointer mt-0.5 shrink-0"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-[#2D3A3A] block">
                      {formType === 'mechanic_avail'
                        ? 'আপনি কি গ্রাহকদের সরাসরি অফলাইনে কলের সুযোগ দিতে চান?'
                        : 'আপনি কি মেকানিক বা মিস্ত্রিদের সরাসরি অফলাইনে কলের সুযোগ দিতে চান?'}
                    </span>
                    <span className="text-[11px] text-[#736B5E] block mt-0.5 leading-relaxed">
                      {allowOfflineCall
                        ? '✓ অনুমোদিত: গ্রাহক বা মিস্ত্রি সরাসরি আপনার সিম কার্ডের নম্বরে কল করতে পারবেন (তবে কল করার পূর্বে তাদের স্ক্রিনে সতর্কবার্তা দেখানো হবে)।'
                        : '🔒 বন্ধ (ডিফল্ট): আপনার মোবাইল নম্বর ও সুনির্দিষ্ট গ্রাম/মহল্লা গোপন থাকবে। যোগাযোগকারীরা ইন-অ্যাপ চ্যাট বা ভয়েস কলে যোগাযোগ করবেন।'}
                    </span>
                  </div>
                </label>
              </div>
              </div>

              {/* Pinned Sticky Bottom Action Bar */}
              <div className="border-t border-[#E6E0D4] p-4 bg-[#FAF8F5] shrink-0 flex justify-end gap-2 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-white border border-[#E6E0D4] hover:bg-gray-50 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#0F766E] hover:bg-[#0c5c56] shadow-sm cursor-pointer active:scale-98 transition"
                >
                  বিজ্ঞাপন প্রকাশ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Real-time Cloud Chat Modal */}
      {activeChatListing && (
        <ChatModal
          isOpen={!!activeChatListing}
          onClose={() => setActiveChatListing(null)}
          currentUser={currentUser}
          recipientId={activeChatListing.sellerId || `seller-${activeChatListing.phone}`}
          recipientName={activeChatListing.sellerName}
          recipientRole={activeChatListing.mechanicType === 'mechanic_avail' ? 'মেকানিক' : 'গ্রাহক'}
          recipientPhone={activeChatListing.phone}
          itemTitle={activeChatListing.title}
          itemPrice={activeChatListing.price}
          itemUnit={activeChatListing.unit}
          onOpenAuth={onOpenAuth}
        />
      )}

      {/* Direct Call / In-App Voice Call Choice Modal */}
      {activeCallingItem && (
        <CallChoiceModal
          recipientName={activeCallingItem.sellerName}
          recipientRole={activeCallingItem.mechanicType === 'mechanic_avail' ? 'মেকানিক' : 'গ্রাহক'}
          recipientSubtitle={`বিজ্ঞপ্তি: ${activeCallingItem.title} (${activeCallingItem.district})`}
          rawPhone={activeCallingItem.phone}
          onSelectInAppCall={() => {
            const item = activeCallingItem;
            setActiveCallingItem(null);
            setInAppVoiceItem(item);
          }}
          onOpenChat={() => {
            const item = activeCallingItem;
            setActiveCallingItem(null);
            setActiveChatListing(item);
          }}
          onClose={() => setActiveCallingItem(null)}
        />
      )}

      {/* In-App Encrypted Voice Call Modal */}
      {inAppVoiceItem && (
        <InAppVoiceCallModal
          recipientName={inAppVoiceItem.sellerName}
          recipientRole={inAppVoiceItem.mechanicType === 'mechanic_avail' ? 'মেকানিক' : 'গ্রাহক'}
          recipientSubtitle={`বিজ্ঞপ্তি: ${inAppVoiceItem.title} (${inAppVoiceItem.district})`}
          maskedPhone={maskPhoneNumber(inAppVoiceItem.phone)}
          rawPhone={inAppVoiceItem.phone}
          currentUser={currentUser}
          onClose={() => setInAppVoiceItem(null)}
        />
      )}
    </div>
  );
};
