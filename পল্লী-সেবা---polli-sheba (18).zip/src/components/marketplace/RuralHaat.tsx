import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  PlusCircle, 
  Search, 
  MapPin, 
  PhoneCall, 
  MessageCircle,
  Clock, 
  CheckCircle2, 
  XCircle, 
  Camera, 
  Upload, 
  X, 
  Trash2, 
  Sparkles, 
  AlertCircle, 
  Tag, 
  Filter,
  RefreshCw,
  ShoppingBag,
  Leaf,
  Navigation,
  Info,
  Calendar,
  Layers,
  PhoneForwarded,
  ArrowUpDown,
  Lock,
  Users,
  Briefcase,
  UserCheck,
  Hammer,
  HelpCircle,
  Check,
  GraduationCap,
  Wrench,
  Bell,
  Mic,
  Star,
  User
} from 'lucide-react';
import { INITIAL_HAAT_LISTINGS, BANGLADESH_DISTRICTS } from '../../data/mockData';
import { HaatListing } from '../../types';
import { UserProfile, getUserFormDefaults, isUserAdminOrAssistantAdmin } from '../../types/auth';
import { useLanguage } from '../../context/LanguageContext';
import { formatTaka } from '../../utils/banglaNumbers';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';
import { subscribeToHaatItems, saveCloudHaatItem, deleteCloudHaatItem, broadcastLocalizedDemandNotification, subscribeToAllOnlineUsers, isUserKeyOnline, deleteDemandNotification } from '../../lib/cloudSync';
import { DynamicAdSection } from '../common/DynamicAdSection';
import { compressImage } from '../../utils/imageCompressor';
import { ChatModal } from '../chat/ChatModal';
import { CallChoiceModal } from '../transport/CallChoiceModal';
import { InAppVoiceCallModal } from '../transport/InAppVoiceCallModal';
import { VoiceChatModal } from '../voice/VoiceChatModal';
import { TwoWayReviewModal } from '../common/TwoWayReviewModal';
import { maskPhoneNumber } from '../transport/RuralTransport';
import { TutorNetworkBoard } from './TutorNetworkBoard';
import { MechanicNetworkBoard } from './MechanicNetworkBoard';

interface RuralHaatProps {
  currentDistrict: string;
  currentUser?: UserProfile | null;
  onOpenAuth?: (action?: string) => void;
  initialTab?: 'products' | 'labor' | 'tutors' | 'mechanics';
  onTabChange?: (tab: 'products' | 'labor' | 'tutors' | 'mechanics') => void;
}

// Smart Shelf Life duration recommender based on crop/item characteristics
export const getRecommendedShelfLife = (title: string, category: string, itemType?: string): { days: number; reason: string } => {
  const t = title.toLowerCase();
  
  // 1. Highly perishable leafy greens (পালং শাক, লাল শাক, কলমি শাক, ধনেপাতা, পুঁইশাক, ডাঁটা শাক)
  if (t.includes('শাক') || t.includes('ধনেপাতা') || t.includes('পুদিনা') || t.includes('লেটুস') || itemType === 'পাতাযুক্ত শাক') {
    return { days: 2, reason: 'পাতাযুক্ত তাজা শাক ১-২ দিনের মধ্যে বাসি বা নষ্ট হয়ে যায় (স্বয়ংক্রিয় হাইড সুপারিশকৃত)' };
  }
  // 2. Fresh Fruits & Soft Vegetables (কলা, পাকা পেঁপে, টমেটো, কাঁচামরিচ, শসা, বেগুন, লাউ, পটল, শিম, ঢেঁড়শ, করলা)
  if (t.includes('কলা') || t.includes('টমেটো') || t.includes('মরিচ') || t.includes('শসা') || t.includes('বেগুন') || t.includes('লাউ') || t.includes('পেঁপে') || t.includes('পটল') || t.includes('ঢেঁড়শ') || t.includes('শিম') || t.includes('করলা') || t.includes('আম') || t.includes('লিচু') || t.includes('পেয়ারা') || itemType === 'ফলমূল' || itemType === 'তাজা সবজি') {
    return { days: 5, reason: 'তাজা ফল ও নরম সবজি সাধারণত ৩-৭ দিন তাজা ও খাওয়ার উপযুক্ত থাকে' };
  }
  // 3. Medium shelf life vegetables (আলু, মিষ্টি কুমড়া, আদা, কচু, গাজর, মূলা)
  if (t.includes('আলু') || t.includes('কুমড়া') || t.includes('আদা') || t.includes('কচু') || t.includes('গাজর') || t.includes('শালগম')) {
    return { days: 15, reason: 'আলু ও শক্ত সবজি স্বাভাবিক তাপমাত্রায় ১৫ দিন পর্যন্ত চমৎকার থাকে' };
  }
  // 4. Onions (পেঁয়াজ)
  if (t.includes('পেঁয়াজ') || t.includes('পিয়াজ')) {
    return { days: 30, reason: 'দেশি শুকনো পেঁয়াজ অনায়াসে ৩০ দিন (১ মাস) ভালো থাকে' };
  }
  // 5. Garlic, Rice, Pulses, Grains, Mustard, Honey (রসুন, চাল, ধান, ডাল, সরিষা, মধু, হলুদ)
  if (t.includes('রসুন') || t.includes('চাল') || t.includes('ধান') || t.includes('ডাল') || t.includes('সরিষা') || t.includes('গম') || t.includes('ভুট্টা') || t.includes('মধু') || t.includes('হলুদ') || t.includes('মশলা') || t.includes('গুড়') || itemType === 'খাদ্যশস্য' || itemType === 'আলু/পেঁয়াজ/রসুন') {
    return { days: 90, reason: 'রসুন ও শুকনো শস্য/পণ্য ৬০-৯০ দিন (৩ মাস) অনায়াসে সংরক্ষণযোগ্য' };
  }
  // 6. Livestock
  if (category === 'গবাদিপশু ও হাঁস-মুরগি' || itemType === 'পশু-পাখি') {
    return { days: 45, reason: 'গবাদিপশুর বিজ্ঞাপনের আদর্শ সক্রিয় মেয়াদ ৪৫ দিন' };
  }
  // 7. Machinery, seeds & others
  if (category === 'কৃষি যন্ত্রপাতি' || category === 'বীজ ও চারা') {
    return { days: 60, reason: 'কৃষি যন্ত্রপাতি ও চারাবীজের বিজ্ঞাপনের মেয়াদ ৬০ দিন' };
  }
  return { days: 7, reason: 'সাধারণ কৃষিপণ্যের আদর্শ মেয়াদ ৭ দিন' };
};

// Calculate freshness and live countdown
export const getListingFreshness = (item: HaatListing) => {
  if (item.isHidden || item.is_hidden) {
    return { 
      isExpired: true, 
      label: '🔴 বিজ্ঞাপনটি লুকানো হয়েছে', 
      badgeClass: 'bg-gray-100 text-gray-700 border-gray-300',
      daysRemaining: 0,
      isUrgent: false,
      detail: 'লুকানো'
    };
  }

  const now = Date.now();
  let expiryTime = item.expiryDateTimestamp;
  
  if (!expiryTime && item.createdAtTimestamp) {
    const days = item.expiryDays || 7;
    expiryTime = item.createdAtTimestamp + days * 24 * 60 * 60 * 1000;
  }
  
  if (!expiryTime || expiryTime <= now) {
    return { 
      isExpired: true, 
      label: '🔴 মেয়াদ শেষ (স্বয়ংক্রিয় হাইড)', 
      badgeClass: 'bg-red-50 text-red-700 border-red-200',
      daysRemaining: 0,
      isUrgent: false,
      detail: 'মেয়াদোত্তীর্ণ'
    };
  }

  const diffMs = expiryTime - now;
  const hoursLeft = Math.floor(diffMs / (1000 * 60 * 60));
  const daysLeft = Math.floor(hoursLeft / 24);
  const remainingHours = hoursLeft % 24;
  
  if (daysLeft === 0) {
    return {
      isExpired: false,
      isUrgent: true,
      label: `⏱️ আজই শেষ দিন (${remainingHours} ঘণ্টা বাকি)`,
      badgeClass: 'bg-amber-50 text-amber-900 border-amber-300 font-bold animate-pulse',
      daysRemaining: 0.5,
      detail: `আজই মেয়াদ শেষ হবে`
    };
  }
  
  if (daysLeft <= 2) {
    return {
      isExpired: false,
      isUrgent: false,
      label: `🥬 টাটকা ও সতেজ: আর ${daysLeft} দিন ${remainingHours > 0 ? remainingHours + ' ঘণ্টা' : ''} বাকি`,
      badgeClass: 'bg-lime-50 text-lime-900 border-lime-300 font-semibold',
      daysRemaining: daysLeft,
      detail: `আর ${daysLeft} দিন সতেজ থাকবে`
    };
  }
  
  return {
    isExpired: false,
    isUrgent: false,
    label: `🌿 তাজা ফলন: আর ${daysLeft} দিন বাকি`,
    badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    daysRemaining: daysLeft,
    detail: `মেয়াদ: আর ${daysLeft} দিন`
  };
};

export const RuralHaat: React.FC<RuralHaatProps> = ({ currentDistrict, currentUser, onOpenAuth, initialTab, onTabChange }) => {
  const { language, t } = useLanguage();
  const [activeMainTab, setActiveMainTab] = useState<'products' | 'labor' | 'tutors' | 'mechanics'>(initialTab || 'products');

  useEffect(() => {
    if (initialTab) {
      setActiveMainTab(initialTab);
      if (initialTab === 'products') setSelectedCategory('সকল পণ্য');
      if (initialTab === 'labor') setSelectedCategory('কৃষিন ও দিনমজুর শ্রমিক');
      if (initialTab === 'tutors') setSelectedCategory('গৃহশিক্ষক ও শিক্ষার্থী');
      if (initialTab === 'mechanics') setSelectedCategory('ইলেকট্রিশিয়ান ও মেকানিক');
    }
  }, [initialTab]);

  const handleTabSwitch = (tab: 'products' | 'labor' | 'tutors' | 'mechanics') => {
    setActiveMainTab(tab);
    if (tab === 'products') setSelectedCategory('সকল পণ্য');
    if (tab === 'labor') setSelectedCategory('কৃষিন ও দিনমজুর শ্রমিক');
    if (tab === 'tutors') setSelectedCategory('গৃহশিক্ষক ও শিক্ষার্থী');
    if (tab === 'mechanics') setSelectedCategory('ইলেকট্রিশিয়ান ও মেকানিক');
    onTabChange?.(tab);
  };

  const [laborSubTab, setLaborSubTab] = useState<'all' | 'workers' | 'jobs'>('all');
  const [selectedLaborWorkType, setSelectedLaborWorkType] = useState<string>('সকল কাজ');

  const [listings, setListings] = useState<HaatListing[]>(() => {
    let deletedIds: string[] = [];
    try {
      deletedIds = JSON.parse(localStorage.getItem('polli_deleted_listing_ids') || '[]');
    } catch {
      deletedIds = [];
    }

    const saved = localStorage.getItem('polli_haat_listings_v2') || localStorage.getItem('polli_haat_listings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.filter((item: HaatListing) => !deletedIds.includes(item.id));
        }
      } catch (e) {
        return INITIAL_HAAT_LISTINGS.filter(item => !deletedIds.includes(item.id));
      }
    }
    return INITIAL_HAAT_LISTINGS.filter(item => !deletedIds.includes(item.id));
  });

  // Filters state
  const [selectedCategory, setSelectedCategory] = useState<string>(() => {
    if (initialTab === 'labor') return 'কৃষিন ও দিনমজুর শ্রমিক';
    if (initialTab === 'tutors') return 'গৃহশিক্ষক ও শিক্ষার্থী';
    if (initialTab === 'mechanics') return 'ইলেকট্রিশিয়ান ও মেকানিক';
    return 'সকল পণ্য';
  });
  const [filterAddress, setFilterAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : '',
    upazila: '',
    union: '',
    village: ''
  });
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [quickVegetablesOnly, setQuickVegetablesOnly] = useState<boolean>(false);
  
  // Expiry & Availability Filter: 'active' (fresh only), 'all', 'expired' (auto-hidden items), 'sold'
  const [filterMode, setFilterMode] = useState<'active' | 'all' | 'expired' | 'sold'>('active');

  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [showLaborAddModal, setShowLaborAddModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Chat & Calling States
  const [activeChatListing, setActiveChatListing] = useState<HaatListing | null>(null);
  const [activeCallingItem, setActiveCallingItem] = useState<HaatListing | null>(null);
  const [inAppVoiceItem, setInAppVoiceItem] = useState<HaatListing | null>(null);
  const [activeVoiceTarget, setActiveVoiceTarget] = useState<HaatListing | null>(null);
  const [activeReviewTarget, setActiveReviewTarget] = useState<{
    id: string;
    name: string;
    role: string;
    serviceType: string;
  } | null>(null);

  // Real-time online users presence tracking
  const [onlineUsersMap, setOnlineUsersMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const unsub = subscribeToAllOnlineUsers((map) => {
      setOnlineUsersMap(map);
    });
    return () => {
      if (unsub) unsub();
    };
  }, []);

  const handleOpenSellerProfile = (item: HaatListing) => {
    const userPayload: Partial<UserProfile> = {
      id: item.sellerId || item.phone,
      name: item.sellerName,
      phone: item.phone,
      role: (item.sellerRole || 'farmer') as any,
      district: item.district,
      upazila: item.upazila,
      union: (item as any).union || '',
      village: item.village,
      allowOfflineCall: item.allowOfflineCall ?? true,
      isLiveVerified: true,
      verificationBadgeText: '🛡️ ভেরিফাইড বিক্রেতা'
    };
    window.dispatchEvent(new CustomEvent('polli_open_public_profile', { detail: { user: userPayload } }));
  };

  // Form State for Products
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<string>('তাজা তরিতরকারি ও শাকসবজি');
  const [itemType, setItemType] = useState<HaatListing['itemType']>('পাতাযুক্ত শাক');
  const [price, setPrice] = useState('');
  const [unit, setUnit] = useState('কেজি');
  const [quantity, setQuantity] = useState('');
  const [sellerName, setSellerName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [sellerRole, setSellerRole] = useState<string>(currentUser?.role || 'farmer');
  const [formHideVillage, setFormHideVillage] = useState<boolean>(true);
  const [formAllowOfflineCall, setFormAllowOfflineCall] = useState<boolean>(false);
  const [formAddress, setFormAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : (currentUser?.district || 'ঢাকা'),
    upazila: currentUser?.upazila || 'সাভার',
    union: currentUser?.union || 'সাভার সদর',
    village: currentUser?.village || ''
  });

  // Form State for Laborers / Worker postings
  const [laborFormType, setLaborFormType] = useState<'worker_avail' | 'worker_need'>('worker_avail');
  const [laborTitle, setLaborTitle] = useState('');
  const [laborWorkType, setLaborWorkType] = useState('ধান কাটা ও মাড়াই');
  const [laborTeamSize, setLaborTeamSize] = useState('৮ জন');
  const [laborPrice, setLaborPrice] = useState('৬৫০');
  const [laborUnit, setLaborUnit] = useState('জন/প্রতিদিন (দৈনিক হাজিরা)');
  const [laborWageType, setLaborWageType] = useState<'daily' | 'contract'>('daily');
  const [laborNegotiable, setLaborNegotiable] = useState(true);
  const [laborName, setLaborName] = useState(currentUser?.name || '');
  const [laborPhone, setLaborPhone] = useState(currentUser?.phone || '');
  const [laborHideVillage, setLaborHideVillage] = useState(true);
  const [laborAllowOfflineCall, setLaborAllowOfflineCall] = useState<boolean>(false);
  const [laborAddress, setLaborAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : (currentUser?.district || 'ঢাকা'),
    upazila: currentUser?.upazila || '',
    union: currentUser?.union || '',
    village: currentUser?.village || ''
  });

  // Auto-fill logic from stored profile / currentUser
  const populateProductDefaults = () => {
    const defaults = getUserFormDefaults(currentUser);
    if (defaults.name) setSellerName(defaults.name);
    if (defaults.phone) setPhone(defaults.phone);
    if (defaults.district && defaults.district !== 'সকল জেলা') {
      setFormAddress(prev => ({
        ...prev,
        district: defaults.district,
        upazila: defaults.upazila || prev.upazila,
        union: defaults.union || prev.union,
        village: defaults.village || prev.village
      }));
    } else if (currentDistrict !== 'সকল জেলা') {
      setFormAddress(prev => ({ ...prev, district: currentDistrict }));
    }
    setFormAllowOfflineCall(defaults.allowOfflineCall);
    setFormHideVillage(defaults.hideVillage);
  };

  const populateLaborDefaults = () => {
    const defaults = getUserFormDefaults(currentUser);
    if (defaults.name) setLaborName(defaults.name);
    if (defaults.phone) setLaborPhone(defaults.phone);
    if (defaults.district && defaults.district !== 'সকল জেলা') {
      setLaborAddress(prev => ({
        ...prev,
        district: defaults.district,
        upazila: defaults.upazila || prev.upazila,
        union: defaults.union || prev.union,
        village: defaults.village || prev.village
      }));
    } else if (currentDistrict !== 'সকল জেলা') {
      setLaborAddress(prev => ({ ...prev, district: currentDistrict }));
    }
    setLaborAllowOfflineCall(defaults.allowOfflineCall);
    setLaborHideVillage(defaults.hideVillage);
  };

  useEffect(() => {
    populateProductDefaults();
    populateLaborDefaults();
  }, [currentUser, currentDistrict]);
  const [laborDescription, setLaborDescription] = useState('');
  const [description, setDescription] = useState('');
  const [isNegotiable, setIsNegotiable] = useState(true);
  const [isPerishable, setIsPerishable] = useState(true);
  const [expiryDays, setExpiryDays] = useState<number>(2);
  const [customDaysReason, setCustomDaysReason] = useState<string>('');
  const [productImageBase64, setProductImageBase64] = useState<string | null>(null);
  const [productNotificationScope, setProductNotificationScope] = useState<'upazila' | 'district'>('district');
  const [laborNotificationScope, setLaborNotificationScope] = useState<'upazila' | 'district'>('district');

  // Camera stream state for taking product photo
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Synchronize when currentDistrict prop changes
  useEffect(() => {
    if (currentDistrict !== 'সকল জেলা') {
      setFilterAddress(prev => ({
        ...prev,
        district: currentDistrict,
        upazila: '',
        union: '',
        village: ''
      }));
      setFormAddress(prev => ({
        ...prev,
        district: currentDistrict
      }));
    }
  }, [currentDistrict]);

  useEffect(() => {
    const unsubscribe = subscribeToHaatItems((items) => {
      if (items && items.length > 0) {
        const mappedListings: HaatListing[] = items.map(it => {
          const createdAtTs = it.createdAtTimestamp || Date.now();
          const expDays = it.expiryDays || 7;
          const expiryTs = it.expiryDateTimestamp || (createdAtTs + expDays * 24 * 60 * 60 * 1000);

          return {
            ...it,
            id: it.id,
            title: it.title,
            category: it.category,
            itemType: it.itemType || 'তাজা সবজি',
            price: it.price,
            unit: it.unit,
            quantity: it.quantity,
            sellerName: it.sellerName,
            sellerRole: it.sellerRole,
            sellerId: it.sellerId,
            phone: it.phone,
            location: it.location,
            district: it.district,
            upazila: it.upazila,
            unionOrWard: it.unionOrWard,
            village: it.village,
            hideVillage: it.hideVillage,
            description: it.description || '',
            createdAt: it.createdAt || 'সক্রিয়',
            createdAtTimestamp: createdAtTs,
            isNegotiable: it.isNegotiable ?? true,
            isPerishable: it.isPerishable ?? true,
            expiryDays: expDays,
            expiryDateTimestamp: expiryTs,
            isSold: it.isSold ?? false,
            imageUrl: it.imageUrl,
            teamSize: it.teamSize,
            workType: it.workType,
            wageType: it.wageType,
            laborType: it.laborType,
            tutorType: it.tutorType,
            targetClasses: it.targetClasses,
            subjects: it.subjects,
            qualification: it.qualification,
            teachingDays: it.teachingDays,
            medium: it.medium,
            mechanicType: it.mechanicType,
            mechanicTrade: it.mechanicTrade,
            experience: it.experience,
            serviceAvailability: it.serviceAvailability
          };
        });
        let deletedIds: string[] = [];
        try {
          deletedIds = JSON.parse(localStorage.getItem('polli_deleted_listing_ids') || '[]');
        } catch {}
        const filteredListings = mappedListings.filter(it => !deletedIds.includes(it.id));
        setListings(filteredListings);
      }
    });
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  useEffect(() => {
    // 1. Auto-cleanup: if an item is expired or stale, mark is_hidden = true and remove notification
    if (listings && listings.length > 0) {
      let hasHiddenChanges = false;
      const swept = listings.map(item => {
        const freshness = getListingFreshness(item);
        if (freshness.isExpired && !item.is_hidden && !item.isHidden) {
          hasHiddenChanges = true;
          const hiddenItem = { ...item, is_hidden: true, isHidden: true };
          saveCloudHaatItem(hiddenItem).catch(() => {});
          deleteDemandNotification(`notif-${item.id}`).catch(() => {});
          return hiddenItem;
        }
        if (freshness.isExpired || item.isSold) {
          deleteDemandNotification(`notif-${item.id}`).catch(() => {});
        }
        return item;
      });

      if (hasHiddenChanges) {
        setListings(swept);
        return;
      }
    }

    localStorage.setItem('polli_haat_listings_v2', JSON.stringify(listings));
    localStorage.setItem('polli_haat_listings', JSON.stringify(listings));
  }, [listings]);

  // Auto recommend expiry days when user types title or picks category/type in form
  useEffect(() => {
    if (title || category || itemType) {
      const rec = getRecommendedShelfLife(title, category, itemType);
      setExpiryDays(rec.days);
      setCustomDaysReason(rec.reason);
    }
  }, [title, category, itemType]);

  const categories = [
    'সকল পণ্য',
    'তাজা তরিতরকারি ও শাকসবজি',
    'গৃহ তৈরি খাবার ও নাস্তা',
    'ফসলের ফলন',
    'ফলমূল',
    'গবাদিপশু ও হাঁস-মুরগি',
    'বীজ ও চারা',
    'কৃষি যন্ত্রপাতি',
    'খাঁটি গ্রামীণ পণ্য'
  ];

  // Distinct known upazilas from listings for quick suggestions
  const knownUpazilas = useMemo(() => {
    const set = new Set<string>();
    listings.forEach(l => {
      if (l.upazila) set.add(l.upazila);
    });
    return Array.from(set);
  }, [listings]);

  // Labor specific work types
  const laborWorkTypes = [
    'সকল কাজ',
    'ধান কাটা ও মাড়াই',
    'রোয়া ও চারা রোপণ',
    'খেত নিড়ানি ও আগাছা দমন',
    'জমি প্রস্তুত ও সেচ নালা খনন',
    'মাটি কাটা ও ভারী কাজ',
    'বাগান ও পরিচর্যা'
  ];

  // Filter listings based on location hierarchy (District -> Upazila -> Union/Ward -> Village) & Expiry Cleanliness
  const filteredListings = useMemo(() => {
    return listings.filter((item) => {
      // 0. Primary Mode Separation: Products vs Labor Market
      if (activeMainTab === 'labor') {
        // Must be labor category
        const isLabor = item.category === 'কৃষিন ও দিনমজুর শ্রমিক' || !!item.laborType || item.sellerRole === 'laborer';
        if (!isLabor) return false;

        // Sub-Tab Filter: Workers available vs Jobs/Labor needed
        if (laborSubTab === 'workers' && (item.laborType === 'worker_need' || item.sellerRole === 'farmer')) {
          return false;
        }
        if (laborSubTab === 'jobs' && (item.laborType === 'worker_avail' || item.sellerRole === 'laborer')) {
          return false;
        }

        // Labor Work Type filter
        if (selectedLaborWorkType !== 'সকল কাজ') {
          const matchWork = 
            (item.workType && item.workType.includes(selectedLaborWorkType)) ||
            (item.itemType && item.itemType.includes(selectedLaborWorkType)) ||
            (item.title && item.title.includes(selectedLaborWorkType));
          if (!matchWork) return false;
        }
      } else {
        // Products Mode: strictly exclude all labor/worker listings
        if (
          item.category === 'কৃষিন ও দিনমজুর শ্রমিক' ||
          !!item.laborType ||
          item.sellerRole === 'laborer' ||
          item.itemType?.includes('কৃষিন') ||
          item.itemType?.includes('দিনমজুর') ||
          item.itemType?.includes('শ্রমিক')
        ) {
          return false;
        }
        if (selectedCategory !== 'সকল পণ্য' && item.category !== selectedCategory) {
          return false;
        }

        // Quick Vegetable & Produce Toggle
        if (quickVegetablesOnly) {
          const isVegOrCrop = 
            item.category === 'তাজা তরিতরকারি ও শাকসবজি' || 
            item.category === 'ফসলের ফলন' || 
            item.category === 'ফলমূল' ||
            item.itemType === 'পাতাযুক্ত শাক' ||
            item.itemType === 'তাজা সবজি' ||
            item.itemType === 'আলু/পেঁয়াজ/রসুন' ||
            item.itemType === 'ফলমূল';
          if (!isVegOrCrop) return false;
        }
      }

      // 1. Freshness & Expiry Calculation
      if (item.isHidden || item.is_hidden) return false;
      const freshness = getListingFreshness(item);
      const isItemSold = !!item.isSold;
      const isItemExpired = freshness.isExpired;

      if (filterMode === 'active') {
        // Active view: MUST NOT be sold and MUST NOT be expired/stale!
        if (isItemSold || isItemExpired) return false;
      } else if (filterMode === 'expired') {
        // Only show auto-hidden/expired listings
        if (!isItemExpired) return false;
      } else if (filterMode === 'sold') {
        // Only show completed sales
        if (!isItemSold) return false;
      }

      // 4. District Filter
      if (filterAddress.district && filterAddress.district !== 'সকল জেলা' && item.district !== filterAddress.district) {
        return false;
      }

      // 5. Upazila Filter (Keep district-wide posts visible)
      if (filterAddress.upazila && filterAddress.upazila !== 'সকল উপজেলা') {
        const uq = filterAddress.upazila.toLowerCase().trim();
        const itemU = (item.upazila || '').toLowerCase().trim();
        const itemLoc = (item.location || '').toLowerCase();
        // If post has an upazila, check if it matches; if user posted only district-wide (empty/all), keep it visible!
        if (itemU && itemU !== 'সকল উপজেলা' && !itemU.includes(uq) && !itemLoc.includes(uq)) {
          return false;
        }
      }

      // 6. Union / Ward Filter (Keep district-wide & upazila-wide posts visible)
      if (filterAddress.union && filterAddress.union !== 'সকল ইউনিয়ন') {
        const uwq = filterAddress.union.toLowerCase().trim();
        const itemUW = (item.unionOrWard || '').toLowerCase().trim();
        const itemLoc = (item.location || '').toLowerCase();
        // If post has a union, check if it matches; if user posted district-wide, keep it visible!
        if (itemUW && itemUW !== 'সকল ইউনিয়ন' && !itemUW.includes(uwq) && !itemLoc.includes(uwq)) {
          return false;
        }
      }

      // 7. Village / Haat Filter
      if (filterAddress.village.trim()) {
        const vq = filterAddress.village.toLowerCase().trim();
        const itemV = (item.village || '').toLowerCase();
        const itemLoc = (item.location || '').toLowerCase();
        if (!itemV.includes(vq) && !itemLoc.includes(vq)) {
          return false;
        }
      }

      // 8. General Search text
      if (searchQuery.trim()) {
        const sq = searchQuery.toLowerCase().trim();
        const matchTitle = item.title.toLowerCase().includes(sq);
        const matchSeller = item.sellerName.toLowerCase().includes(sq);
        const matchDesc = (item.description || '').toLowerCase().includes(sq);
        const matchLoc = (item.location || '').toLowerCase();
        const matchPhone = (item.phone || '').includes(sq);
        const matchWork = (item.workType || '').toLowerCase().includes(sq);
        if (!matchTitle && !matchSeller && !matchDesc && !matchLoc.includes(sq) && !matchPhone && !matchWork) {
          return false;
        }
      }

      return true;
    });
  }, [
    listings,
    activeMainTab,
    laborSubTab,
    selectedLaborWorkType,
    filterMode,
    quickVegetablesOnly,
    selectedCategory,
    filterAddress,
    searchQuery
  ]);

  const handleStartCamera = async () => {
    setIsCameraActive(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 } },
        audio: false
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Camera error:', err);
    }
  };

  const handleStopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const handleSnapPhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      setProductImageBase64(canvas.toDataURL('image/jpeg', 0.85));
    }
    handleStopCamera();
  };

  const handleImageFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const compressed = await compressImage(file, 640, 640, 0.75);
        setProductImageBase64(compressed);
      } catch (err) {
        console.error('Image compress error:', err);
        const reader = new FileReader();
        reader.onloadend = () => {
          setProductImageBase64(reader.result as string);
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const handleCreateListing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !price || !sellerName || !phone) return;

    const now = Date.now();
    const durationDays = Number(expiryDays) || 3;
    const expiryTimestamp = now + durationDays * 24 * 60 * 60 * 1000;

    const compiledLocation = [
      formAddress.village ? `গ্রাম: ${formAddress.village}` : '',
      formAddress.union ? `${formAddress.union}` : '',
      formAddress.upazila ? `উপজেলা: ${formAddress.upazila}` : '',
      formAddress.district ? `${formAddress.district} জেলা` : ''
    ].filter(Boolean).join(', ') || `${formAddress.district}`;

    const newListing: HaatListing = {
      id: `haat-${Date.now()}`,
      title,
      category,
      itemType,
      price: parseFloat(price) || 0,
      unit,
      quantity: quantity || undefined,
      sellerName,
      sellerRole: (sellerRole as any) || currentUser?.role || 'farmer',
      sellerId: currentUser?.id,
      phone,
      location: compiledLocation,
      district: formAddress.district,
      upazila: formAddress.upazila || undefined,
      unionOrWard: formAddress.union || undefined,
      village: formAddress.village || undefined,
      hideVillage: formHideVillage,
      allowOfflineCall: formAllowOfflineCall,
      description,
      createdAt: 'এইমাত্র পোস্ট করা হয়েছে',
      createdAtTimestamp: now,
      isNegotiable,
      isPerishable: durationDays <= 15,
      expiryDays: durationDays,
      expiryDateTimestamp: expiryTimestamp,
      isSold: false,
      imageUrl: productImageBase64 || undefined
    };

    setListings([newListing, ...listings]);
    saveCloudHaatItem(newListing);

    // Auto localized notification broadcast to neighbors
    broadcastLocalizedDemandNotification({
      id: newListing.id,
      title: newListing.title,
      category: newListing.category,
      scope: productNotificationScope,
      district: formAddress.district,
      upazila: formAddress.upazila,
      union: formAddress.unionOrWard,
      sellerName: sellerName.trim(),
      phone: phone.trim(),
      targetRole: 'all',
      targetCategory: 'marketplace',
      targetSubTab: { main: 'products' },
      expiresAt: expiryTimestamp
    });

    setShowAddModal(false);
    setToastMessage(`আলহামদুলিল্লাহ! আপনার বিজ্ঞাপন সফলভাবে ক্লাউড হাটে প্রকাশিত হয়েছে এবং ${productNotificationScope === 'upazila' && formAddress.upazila ? `${formAddress.upazila} উপজেলার` : `${formAddress.district} জেলার`} সকল ব্যবহারকারীর কাছে নোটিফিকেশন পৌঁছে দেওয়া হয়েছে।`);
    setTimeout(() => setToastMessage(null), 5000);

    // reset
    setTitle('');
    setPrice('');
    setQuantity('');
    setSellerName('');
    setPhone('');
    setFormAddress({
      district: currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা',
      upazila: 'সাভার',
      union: 'সাভার সদর',
      village: ''
    });
    setDescription('');
    setProductImageBase64(null);
  };

  const handleToggleSold = (id: string) => {
    let targetItem: HaatListing | undefined;
    const updated = listings.map(item => {
      if (item.id === id) {
        const nextSold = !item.isSold;
        const isLabor = item.category === 'কৃষিন ও দিনমজুর শ্রমিক' || !!item.laborType;
        const isTutor = item.category === 'গৃহশিক্ষক ও শিক্ষার্থী' || !!item.tutorType;
        const isMechanic = item.category === 'ইলেকট্রিশিয়ান ও মেকানিক' || !!item.mechanicType;

        const msg = nextSold 
          ? (isLabor ? 'শ্রমিক বা কাজ সম্পন্ন হিসেবে চিহ্নিত হয়েছে এবং স্বাভাবিক তালিকা থেকে হাইড করা হয়েছে।' 
             : isTutor ? 'শিক্ষক/ছাত্র পাওয়া গেছে বলে চিহ্নিত ও তালিকা থেকে হাইড করা হয়েছে।' 
             : isMechanic ? 'মেরামত সম্পন্ন হিসেবে চিহ্নিত ও তালিকা থেকে হাইড করা হয়েছে।' 
             : 'পণ্যটি "বিক্রি সম্পন্ন" হিসেবে চিহ্নিত ও তালিকা থেকে হাইড করা হয়েছে।')
          : 'বিজ্ঞাপনটি পুনরায় সক্রিয় করা হয়েছে।';
        setToastMessage(msg);
        setTimeout(() => setToastMessage(null), 3500);
        targetItem = { ...item, isSold: nextSold, isCompleted: nextSold };
        return targetItem;
      }
      return item;
    });
    setListings(updated);
    if (targetItem) {
      saveCloudHaatItem(targetItem);
    }
  };

  // Farmer renews freshness for expired/near-expiry ad
  const handleRenewListing = (id: string) => {
    const updated = listings.map(item => {
      if (item.id === id) {
        const days = item.expiryDays || 3;
        const now = Date.now();
        setToastMessage(`পণ্যটির মেয়াদ সফলভাবে আরও ${days} দিন বৃদ্ধি করা হয়েছে!`);
        setTimeout(() => setToastMessage(null), 3500);
        return {
          ...item,
          createdAt: 'আজ নতুন করে রিনিউ করা হয়েছে',
          createdAtTimestamp: now,
          expiryDateTimestamp: now + days * 24 * 60 * 60 * 1000,
          isSold: false
        };
      }
      return item;
    });
    setListings(updated);
  };

  const handleDeleteItem = async (id: string) => {
    if (!window.confirm('আপনি কি নিশ্চিত যে এই বিজ্ঞাপনটি সম্পূর্ণ মুছে ফেলতে চান?')) {
      return;
    }
    // Record in deleted listing IDs so it never re-injects
    let deletedIds: string[] = [];
    try {
      deletedIds = JSON.parse(localStorage.getItem('polli_deleted_listing_ids') || '[]');
    } catch {
      deletedIds = [];
    }
    if (!deletedIds.includes(id)) {
      deletedIds.push(id);
      localStorage.setItem('polli_deleted_listing_ids', JSON.stringify(deletedIds));
    }

    const updated = listings.filter(item => item.id !== id);
    setListings(updated);
    localStorage.setItem('polli_haat_listings_v2', JSON.stringify(updated));
    localStorage.setItem('polli_haat_listings', JSON.stringify(updated));
    localStorage.setItem('polli_marketplace_items', JSON.stringify(updated));

    try {
      await deleteCloudHaatItem(id);
      await deleteDemandNotification(`notif-${id}`);
    } catch (err) {
      console.warn('Error deleting cloud haat item:', err);
    }
    setToastMessage('বিজ্ঞাপনটি হাট থেকে সফলভাবে মুছে ফেলা হয়েছে।');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleCreateLaborListing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!laborTitle || !laborPrice || !laborName || !laborPhone) return;

    const now = Date.now();
    const compiledLocation = [
      laborAddress.village ? `গ্রাম: ${laborAddress.village}` : '',
      laborAddress.union ? `${laborAddress.union}` : '',
      laborAddress.upazila ? `উপজেলা: ${laborAddress.upazila}` : '',
      laborAddress.district ? `${laborAddress.district} জেলা` : ''
    ].filter(Boolean).join(', ') || `${laborAddress.district}`;

    const newListing: HaatListing = {
      id: `haat-labor-${Date.now()}`,
      title: laborTitle,
      category: 'কৃষিন ও দিনমজুর শ্রমিক',
      itemType: 'কৃষিন / দিনমজুর',
      price: parseFloat(laborPrice) || 0,
      unit: laborUnit || (laborWageType === 'daily' ? 'জন/প্রতিদিন (দৈনিক হাজিরা)' : 'চুক্তিভিত্তিক'),
      quantity: laborTeamSize ? (laborFormType === 'worker_avail' ? `${laborTeamSize} প্রস্তুত` : `${laborTeamSize} আবশ্যক`) : undefined,
      teamSize: laborTeamSize,
      workType: laborWorkType,
      wageType: laborWageType,
      laborType: laborFormType,
      sellerName: laborName,
      sellerRole: laborFormType === 'worker_avail' ? 'laborer' : 'farmer',
      sellerId: currentUser?.id,
      phone: laborPhone,
      location: compiledLocation,
      district: laborAddress.district || currentDistrict || 'ঢাকা',
      upazila: laborAddress.upazila || '',
      unionOrWard: laborAddress.union || '',
      village: laborAddress.village || '',
      hideVillage: laborHideVillage,
      allowOfflineCall: laborAllowOfflineCall,
      description: laborDescription || (laborFormType === 'worker_avail' ? 'দক্ষ ও পরিশ্রমী কৃষিন দল। সময়মতো উপস্থিত হয়ে সন্তোষজনক কাজ সম্পন্ন করা হয়।' : 'জরুরি ভিত্তিতে বিশ্বস্ত কৃষিন/মজুর আবশ্যক। নগদ পরিশোধ ও খাবার প্রদান করা হবে।'),
      createdAt: 'এইমাত্র পোস্ট করা হয়েছে',
      createdAtTimestamp: now,
      isNegotiable: laborNegotiable,
      isPerishable: false,
      expiryDays: 15,
      expiryDateTimestamp: now + 15 * 24 * 60 * 60 * 1000,
      isSold: false
    };

    setListings(prev => [newListing, ...prev]);
    saveCloudHaatItem(newListing as any).catch(err => console.warn('Cloud labor sync notice:', err));

    // Auto localized notification broadcast to neighbors
    broadcastLocalizedDemandNotification({
      id: newListing.id,
      title: newListing.title,
      category: laborFormType === 'worker_avail' ? 'কৃষিন ও দিনমজুর দল প্রস্তুত' : 'দিনমজুর ও কৃষিশ্রমিক আবশ্যক',
      scope: laborNotificationScope,
      district: laborAddress.district || currentDistrict || 'ঢাকা',
      upazila: laborAddress.upazila || '',
      union: laborAddress.unionOrWard || '',
      sellerName: laborName.trim(),
      phone: laborPhone.trim(),
      targetRole: laborFormType === 'worker_avail' ? 'farmer' : 'laborer',
      targetCategory: 'marketplace',
      targetSubTab: { main: 'labor' }
    });

    setShowLaborAddModal(false);
    setToastMessage(laborFormType === 'worker_avail' 
      ? `আলহামদুলিল্লাহ! আপনার কাজের সন্ধান সফলভাবে ক্লাউডে প্রকাশিত হয়েছে (${laborNotificationScope === 'upazila' && laborAddress.upazila ? `${laborAddress.upazila} উপজেলায়` : `${laborAddress.district} জেলায়`} নোটিফিকেশন পাঠানো হয়েছে)।` 
      : `আলহামদুলিল্লাহ! আপনার শ্রমিক আবশ্যক বিজ্ঞপ্তি সফলভাবে ক্লাউডে প্রকাশিত হয়েছে (${laborNotificationScope === 'upazila' && laborAddress.upazila ? `${laborAddress.upazila} উপজেলায়` : `${laborAddress.district} জেলায়`} নোটিফিকেশন পাঠানো হয়েছে)।`
    );
    setTimeout(() => setToastMessage(null), 4000);

    // Reset labor form
    setLaborTitle('');
    setLaborPrice('৬৫০');
    setLaborTeamSize('৮ জন');
    setLaborDescription('');
  };

  const clearAllFilters = () => {
    setFilterAddress({
      district: '',
      upazila: '',
      union: '',
      village: ''
    });
    setSearchQuery('');
    setSelectedCategory('সকল পণ্য');
    setSelectedLaborWorkType('সকল কাজ');
    setLaborSubTab('all');
    setQuickVegetablesOnly(false);
    setFilterMode('active');
  };

  const activeFiltersCount = [
    Boolean(filterAddress.district),
    Boolean(filterAddress.upazila),
    Boolean(filterAddress.union),
    Boolean(filterAddress.village.trim()),
    searchQuery.trim() !== '',
    selectedCategory !== 'সকল পণ্য',
    quickVegetablesOnly
  ].filter(Boolean).length;

  return (
    <div className="space-y-6 font-['Noto_Sans_Bengali']">
      {/* 4 Marketplace Modes: Products, Agricultural Labor, Tutors/Education, Electrician/Mechanic */}
      <div className="bg-[#FAF8F5] p-1.5 rounded-3xl border border-[#E6E0D4] grid grid-cols-2 lg:grid-cols-4 gap-1.5 shadow-2xs">
        <button
          onClick={() => handleTabSwitch('products')}
          className={`py-2.5 px-3 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition cursor-pointer text-center ${
            activeMainTab === 'products'
              ? 'bg-[#2D5A27] text-white shadow-xs'
              : 'text-[#5A6B6B] hover:text-[#2D3A3A] hover:bg-white/70'
          }`}
        >
          <ShoppingBag className="w-4 h-4 shrink-0" />
          <span className="truncate">{t('🛒 ফসল ও পণ্য হাট', '🛒 Haat & Produce')}</span>
        </button>

        <button
          onClick={() => handleTabSwitch('labor')}
          className={`py-2.5 px-3 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition cursor-pointer text-center ${
            activeMainTab === 'labor'
              ? 'bg-[#2D5A27] text-white shadow-xs'
              : 'text-[#5A6B6B] hover:text-[#2D3A3A] hover:bg-white/70'
          }`}
        >
          <Users className="w-4 h-4 shrink-0 text-[#D4E4BC]" />
          <span className="truncate">{t('🌾 কৃষিন ও দিনমজুর', '🌾 Laborers & Workers')}</span>
        </button>

        <button
          onClick={() => handleTabSwitch('tutors')}
          className={`py-2.5 px-3 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition cursor-pointer text-center ${
            activeMainTab === 'tutors'
              ? 'bg-[#1B365D] text-white shadow-xs'
              : 'text-[#5A6B6B] hover:text-[#2D3A3A] hover:bg-white/70'
          }`}
        >
          <GraduationCap className="w-4 h-4 shrink-0 text-amber-300" />
          <span className="truncate">{t('📚 গৃহশিক্ষক ও শিক্ষার্থী', '📚 Tutors & Students')}</span>
        </button>

        <button
          onClick={() => handleTabSwitch('mechanics')}
          className={`py-2.5 px-3 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition cursor-pointer text-center ${
            activeMainTab === 'mechanics'
              ? 'bg-[#0F766E] text-white shadow-xs'
              : 'text-[#5A6B6B] hover:text-[#2D3A3A] hover:bg-white/70'
          }`}
        >
          <Wrench className="w-4 h-4 shrink-0 text-emerald-300" />
          <span className="truncate">{t('🔧 ইলেকট্রিশিয়ান ও মেকানিক', '🔧 Electricians & Mechanics')}</span>
        </button>
      </div>

      {/* Tutors/Students Board Component */}
      {activeMainTab === 'tutors' && (
        <TutorNetworkBoard
          currentDistrict={currentDistrict}
          currentUser={currentUser}
          onOpenAuth={onOpenAuth}
          listings={listings}
          onAddListing={(item) => {
            setListings(prev => [item, ...prev]);
            saveCloudHaatItem(item);
          }}
          onDeleteListing={handleDeleteItem}
          onToggleStatus={handleToggleSold}
        />
      )}

      {/* Electrician/Mechanic Board Component */}
      {activeMainTab === 'mechanics' && (
        <MechanicNetworkBoard
          currentDistrict={currentDistrict}
          currentUser={currentUser}
          onOpenAuth={onOpenAuth}
          listings={listings}
          onAddListing={(item) => {
            setListings(prev => [item, ...prev]);
            saveCloudHaatItem(item);
          }}
          onDeleteListing={handleDeleteItem}
          onToggleStatus={handleToggleSold}
        />
      )}

      {/* Products & Agricultural Labor Hub */}
      {(activeMainTab === 'products' || activeMainTab === 'labor') && (
        <>
      {/* Hero Banner based on Active Mode */}
      {activeMainTab === 'products' ? (
        <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full inline-flex items-center gap-1">
                <Leaf className="w-3.5 h-3.5" />
                <span>সরাসরি কৃষক থেকে ভোক্তা • মধ্যস্বত্বভোগী ছাড়া</span>
              </span>
              <span className="bg-[#FAF8F5]/20 text-white text-[11px] font-semibold px-2.5 py-0.5 rounded-full">
                ⚡ পচনশীল পণ্যের অটো-মেয়াদোত্তীর্ণ ও জঞ্জালমুক্ত হাট
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold">
              পল্লী হাট ও তাজা তরিতরকারির সরাসরি বাজার
            </h2>
            <p className="text-[#D4E4BC] text-xs sm:text-sm max-w-2xl leading-relaxed">
              জেলা, উপজেলা ও ইউনিয়ন-ওয়ার্ড অনুযায়ী আপনার পাশের গ্রামের তাজা শাকসবজি ও ফসল খুঁজে নিন। সরাসরি বিক্রেতার নম্বরে কল করে সতেজ পণ্য সংগ্রহ করুন।
            </p>
          </div>

          <button
            onClick={() => {
              if (!currentUser) {
                onOpenAuth?.('ফসলের বিজ্ঞাপন দিতে লগইন বা নিবন্ধন করুন');
                return;
              }
              setShowAddModal(true);
            }}
            className="flex items-center gap-2 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold px-5 py-3 rounded-2xl text-xs sm:text-sm shadow-md transition self-start md:self-auto cursor-pointer whitespace-nowrap shrink-0"
          >
            <PlusCircle className="w-4 h-4" />
            <span>তরিতরকারি/ফসলের বিজ্ঞাপন দিন</span>
          </button>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-[#1B4332] to-[#2D5A27] text-white p-6 rounded-3xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full inline-flex items-center gap-1">
                <Users className="w-3.5 h-3.5" />
                <span>কৃষিন • কামলা • জোন • দিনমজুর সেবা</span>
              </span>
              <span className="bg-white/20 text-white text-[11px] font-semibold px-2.5 py-0.5 rounded-full">
                🌾 দালালমুক্ত সরাসরি খামারি ও শ্রমিক যোগাযোগ
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold">
              এলাকাভিত্তিক কৃষিন ও দিনমজুর শ্রমিক সেবা
            </h2>
            <p className="text-[#D4E4BC] text-xs sm:text-sm max-w-2xl leading-relaxed">
              উত্তরবঙ্গে &ldquo;কৃষিন&rdquo;, ঢাকা ও ময়মনসিংহে &ldquo;কামলা&rdquo;, কুমিল্লা-চট্টগ্রাম ও বরিশালে &ldquo;জোন&rdquo; বা মজুর — আপনার এলাকায় ধান কাটা, রোপণ, নিড়ানি বা কৃষিকাজের শ্রমিক দল খুঁজুন কিংবা শ্রম বিক্রির জন্য নিজের নাম/দলের বিজ্ঞপ্তি দিন।
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
            <button
              onClick={() => {
                if (!currentUser) {
                  onOpenAuth?.('শ্রমিক খুঁজতে বিজ্ঞাপন দিতে লগইন বা নিবন্ধন করুন');
                  return;
                }
                setLaborFormType('worker_need');
                setShowLaborAddModal(true);
              }}
              className="flex items-center justify-center gap-2 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold px-4 py-3 rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer whitespace-nowrap"
            >
              <PlusCircle className="w-4 h-4" />
              <span>শ্রমিক আবশ্যক বিজ্ঞাপন</span>
            </button>
          </div>
        </div>
      )}

      {/* Toast Alert */}
      {toastMessage && (
        <div className="p-3.5 bg-[#E8F8F5] border border-[#27AE60]/40 text-[#27AE60] text-xs sm:text-sm font-bold rounded-2xl flex items-center gap-2 shadow-xs animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Smart Location Hierarchy Search & Multi-Level Filter */}
      {activeMainTab === 'products' ? (
        <div className="bg-white p-4 sm:p-5 rounded-3xl border border-[#E6E0D4] space-y-4 shadow-2xs">
          
          {/* Top Quick Row: Quick Vegetables Shortcut + Freshness Mode */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
            <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
              <button
                onClick={() => setQuickVegetablesOnly(!quickVegetablesOnly)}
                className={`px-3.5 py-2 rounded-2xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap shadow-2xs ${
                  quickVegetablesOnly 
                    ? 'bg-[#2D5A27] text-white' 
                    : 'bg-[#F9E5D4] text-[#A65E2E] hover:bg-[#F3D5BC]'
                }`}
              >
                <Leaf className="w-4 h-4" />
                <span>🥬 শুধু তাজা শাকসবজি ও তরিতরকারি</span>
              </button>

              {/* View Filter Mode: Active / Expired / Sold */}
              <div className="flex bg-[#FAF8F5] p-1 rounded-2xl border border-[#E6E0D4] text-xs shrink-0">
                <button
                  onClick={() => setFilterMode('active')}
                  className={`px-3 py-1 rounded-xl font-bold transition cursor-pointer ${
                    filterMode === 'active' ? 'bg-[#2D5A27] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-black'
                  }`}
                  title="শুধুমাত্র বর্তমান টাটকা ও সক্রিয় বিজ্ঞাপন"
                >
                  🟢 টাটকা ও সক্রিয়
                </button>
                <button
                  onClick={() => setFilterMode('expired')}
                  className={`px-3 py-1 rounded-xl font-bold transition cursor-pointer ${
                    filterMode === 'expired' ? 'bg-[#C0392B] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-black'
                  }`}
                  title="মেয়াদ শেষ হওয়া বা অটো-হাইডকৃত পণ্যের তালিকা"
                >
                  🔴 মেয়াদোত্তীর্ণ/হাইড
                </button>
                <button
                  onClick={() => setFilterMode('sold')}
                  className={`px-3 py-1 rounded-xl font-bold transition cursor-pointer ${
                    filterMode === 'sold' ? 'bg-[#736B5E] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-black'
                  }`}
                >
                  বিক্রি শেষ
                </button>
                <button
                  onClick={() => setFilterMode('all')}
                  className={`px-3 py-1 rounded-xl font-bold transition cursor-pointer ${
                    filterMode === 'all' ? 'bg-[#2D3A3A] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-black'
                  }`}
                >
                  সকল
                </button>
              </div>
            </div>

            {/* Product / Seller Keyword Search */}
            <div className="relative min-w-[220px]">
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                placeholder="পণ্য বা বিক্রেতার নাম..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-2xl pl-8 pr-8 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2.5 text-gray-400 hover:text-black"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Cascading Address Filter: District -> Upazila -> Union -> Village Search */}
          <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4]">
            <div className="text-[11px] font-bold text-[#2D5A27] mb-2 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
              <span>স্থান ভিত্তিক ফিল্টারিং (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ গ্রাম/হাট):</span>
            </div>
            <CascadingAddressSelector
              address={filterAddress}
              onChange={setFilterAddress}
              allowAllOption={true}
              layout="grid-4"
              villagePlaceholder="গ্রাম বা হাটের নাম লিখে খুঁজুন..."
            />
          </div>

          {/* Categories Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-full font-bold whitespace-nowrap transition cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#2D5A27] text-white shadow-2xs'
                    : 'bg-[#FAF8F5] text-[#5A6B6B] border border-[#E6E0D4] hover:bg-[#F9E5D4]'
                }`}
              >
                {cat}
              </button>
            ))}

            {activeFiltersCount > 0 && (
              <button
                onClick={clearAllFilters}
                className="px-3 py-1.5 rounded-full font-semibold text-xs text-[#C0392B] bg-[#FADBD8]/50 hover:bg-[#FADBD8] border border-[#F5B7B1] whitespace-nowrap cursor-pointer ml-auto"
              >
                ফিল্টার রিসেট ({activeFiltersCount})
              </button>
            )}
          </div>
        </div>
      ) : (
        /* Labor Market Dedicated Filters */
        <div className="bg-white p-4 sm:p-5 rounded-3xl border border-[#E6E0D4] space-y-4 shadow-2xs">
          {/* Moral & Liability Notice Banner for Labor Market */}
          <div className="bg-[#FAF8F5] border border-[#E6E0D4] rounded-2xl p-3.5 space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-base">🌾</span>
                <p className="text-xs font-bold text-[#2D5A27]">
                  "শ্রমিকদের গায়ের ঘাম শুকানোর আগেই তাদের মজুরি পরিশোধ করতে চেষ্টা করুন।" <span className="text-[11px] font-normal text-[#5A6B6B]">(হাদিস শরিফ)</span>
                </p>
              </div>
              <a
                href="tel:16199"
                className="inline-flex items-center gap-1.5 text-[11px] font-bold text-[#1E3A8A] bg-blue-50 hover:bg-blue-100 border border-blue-200 px-3 py-1 rounded-xl transition cursor-pointer self-start sm:self-auto"
              >
                <PhoneCall className="w-3 h-3" />
                <span>জাতীয় শ্রম কল সেন্টার: ১৬১৯৯</span>
              </a>
            </div>
            <p className="text-[11px] text-[#736B5E] border-t border-[#E6E0D4]/70 pt-1.5">
              ⚖️ <strong>কর্তৃপক্ষের দায়মুক্তি:</strong> শ্রমিকদের মজুরি আদায় করে দিতে বাধ্য নয় অ্যাপ কর্তৃপক্ষ। পল্লী সেবা প্ল্যাটফর্ম কেবল কৃষক, মহাজন ও শ্রমিকের যোগাযোগের নিরপেক্ষ মাধ্যম।
            </p>
          </div>

          {/* Sub Tab: All vs Workers vs Jobs + Search */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
            <div className="flex bg-[#FAF8F5] p-1 rounded-2xl border border-[#E6E0D4] text-xs shrink-0 overflow-x-auto">
              <button
                onClick={() => setLaborSubTab('all')}
                className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                  laborSubTab === 'all' ? 'bg-[#2D5A27] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-black'
                }`}
              >
                📋 সকল তালিকা ({listings.filter(i => i.category === 'কৃষিন ও দিনমজুর শ্রমিক').length})
              </button>
              <button
                onClick={() => setLaborSubTab('workers')}
                className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                  laborSubTab === 'workers' ? 'bg-[#2D5A27] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-black'
                }`}
              >
                👥 উপলব্ধ কৃষিন ও শ্রমিক দল ({listings.filter(i => i.category === 'কৃষিন ও দিনমজুর শ্রমিক' && (i.laborType === 'worker_avail' || i.sellerRole === 'laborer')).length})
              </button>
              <button
                onClick={() => setLaborSubTab('jobs')}
                className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                  laborSubTab === 'jobs' ? 'bg-[#E8924A] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-black'
                }`}
              >
                📢 শ্রমিক আবশ্যক বিজ্ঞপ্তি ({listings.filter(i => i.category === 'কৃষিন ও দিনমজুর শ্রমিক' && (i.laborType === 'worker_need' || i.sellerRole === 'farmer')).length})
              </button>
            </div>

            {/* Keyword Search */}
            <div className="relative min-w-[220px]">
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                placeholder="শ্রমিক বা খামারির নাম, কাজ বা এলাকা..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-2xl pl-8 pr-8 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2.5 text-gray-400 hover:text-black"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Cascading Address Filter */}
          <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4]">
            <div className="text-[11px] font-bold text-[#2D5A27] mb-2 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
              <span>শ্রমিকদের এলাকা বা কাজের স্থান ফিল্টার (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ গ্রাম):</span>
            </div>
            <CascadingAddressSelector
              address={filterAddress}
              onChange={setFilterAddress}
              allowAllOption={true}
              layout="grid-4"
              villagePlaceholder="গ্রাম বা পাড়ার নাম..."
            />
          </div>

          {/* Work Types Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {laborWorkTypes.map((wt) => (
              <button
                key={wt}
                onClick={() => setSelectedLaborWorkType(wt)}
                className={`px-3 py-1.5 rounded-full font-bold whitespace-nowrap transition cursor-pointer ${
                  selectedLaborWorkType === wt
                    ? 'bg-[#2D5A27] text-white shadow-2xs'
                    : 'bg-[#FAF8F5] text-[#5A6B6B] border border-[#E6E0D4] hover:bg-[#F9E5D4]'
                }`}
              >
                {wt}
              </button>
            ))}

            {activeFiltersCount > 0 && (
              <button
                onClick={clearAllFilters}
                className="px-3 py-1.5 rounded-full font-semibold text-xs text-[#C0392B] bg-[#FADBD8]/50 hover:bg-[#FADBD8] border border-[#F5B7B1] whitespace-nowrap cursor-pointer ml-auto"
              >
                রিসেট ({activeFiltersCount})
              </button>
            )}
          </div>
        </div>
      )}

      {/* Mode Information Card */}
      {activeMainTab === 'products' ? (
        <div className="bg-[#FAF8F5] border border-[#D4E4BC] p-4 rounded-3xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start gap-2.5">
            <div className="p-2 bg-[#2D5A27]/10 text-[#2D5A27] rounded-2xl shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-[#2D3A3A]">
                স্বয়ংক্রিয় টাটকা নিয়ন্ত্রণ ও জঞ্জালমুক্ত নীতি:
              </h4>
              <p className="text-[#5A6B6B] mt-0.5 leading-relaxed">
                শাকসবজি ১-৩ দিন, নরম সবজি ৩-৫ দিন এবং অন্যান্য পণ্য স্বয়ংক্রিয়ভাবে তালিকা থেকে হাইড হয়ে যায় যাতে ক্রেতা কখনোই কোনো বাসি পণ্য না দেখেন।
              </p>
              <div className="mt-2 p-2 bg-amber-50/80 border border-amber-200/70 rounded-xl text-[11px] text-amber-900 leading-relaxed flex items-start gap-1.5">
                <Info className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
                <span><strong>সতর্কবার্তা ও দায়মুক্তি:</strong> খাবারের মান ও বিশুদ্ধতা, সঠিক ঔষধ ও মেয়াদসহ প্রয়োজনীয় পণ্যের দরদাম যাচাই করে ক্রয় করুন। পল্লী সেবা অ্যাপস শুধুমাত্র ক্রেতা-বিক্রেতার যোগাযোগকে সহজ করে, পণ্যের বিশুদ্ধতার নিশ্চয়তা এবং কোনো আর্থিক লেনদেনের দায় নেয় না।</span>
              </div>
            </div>
          </div>

          <span className="text-[11px] font-bold px-3 py-1 bg-white border border-[#E6E0D4] rounded-xl text-[#2D5A27] shrink-0 self-end sm:self-auto">
            পাওয়া গেছে: {filteredListings.length} টি পণ্য
          </span>
        </div>
      ) : (
        <div className="bg-[#FAF8F5] border border-[#D4E4BC] p-4 rounded-3xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start gap-2.5">
            <div className="p-2 bg-[#2D5A27]/10 text-[#2D5A27] rounded-2xl shrink-0">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-[#2D3A3A]">
                কৃষিন ও দিনমজুর শ্রমিকদের সহায়তা নির্দেশিকা:
              </h4>
              <p className="text-[#5A6B6B] mt-0.5 leading-relaxed">
                কৃষক ও শ্রমিক দলের মাঝে সরাসরি চুক্তি, কোনো মধ্যস্বত্বভোগী বা দালালি কমিশন ছাড়া। ধান কাটা, রোপণ বা নিড়ানি কাজের জন্য সরাসরি ইন-অ্যাপ চ্যাট বা কল করুন।
              </p>
            </div>
          </div>

          <span className="text-[11px] font-bold px-3 py-1 bg-white border border-[#E6E0D4] rounded-xl text-[#2D5A27] shrink-0 self-end sm:self-auto">
            পাওয়া গেছে: {filteredListings.length} টি তালিকা
          </span>
        </div>
      )}

      {/* Dynamic Sponsored Ads Banner in Marketplace */}
      <DynamicAdSection placement="marketplace_top" district={currentDistrict} className="my-2" />

      {/* Listings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
        {filteredListings.length === 0 ? (
          <div className="col-span-full bg-white p-10 rounded-3xl border border-dashed border-[#D4C3A3] text-center text-[#5A6B6B] space-y-3">
            <div className="p-3 bg-[#FAF8F5] rounded-full w-14 h-14 mx-auto flex items-center justify-center text-[#2D5A27]">
              {activeMainTab === 'labor' ? <Users className="w-7 h-7" /> : <Leaf className="w-7 h-7" />}
            </div>
            <div>
              <p className="text-base font-bold text-[#2D3A3A]">
                {activeMainTab === 'labor' 
                  ? 'আপনার নির্বাচিত এলাকায় বর্তমানে কোনো কৃষিন বা শ্রমিক বিজ্ঞপ্তির সন্ধান মেলেনি' 
                  : 'আপনার নির্বাচিত এলাকায় বর্তমানে কোনো পণ্য বিজ্ঞাপন পাওয়া যায়নি'}
              </p>
              <p className="text-xs text-[#5A6B6B] mt-1 max-w-md mx-auto">
                {activeMainTab === 'labor'
                  ? 'অন্য কোনো উপজেলা বা জেলা নির্বাচন করুন, অথবা আপনি যদি কৃষিন/দিনমজুর হন বা আপনার খামারে শ্রমিক প্রয়োজন হয়, তবে বিনামূল্যে তালিকাভুক্ত করুন।'
                  : 'অন্য কোনো উপজেলা বা জেলা নির্বাচন করুন, অথবা আপনি যদি কৃষক/বিক্রেতা হন তবে আপনার তাজা তরিতরকারির বিজ্ঞাপন বিনামূল্যে পোস্ট করুন।'}
              </p>
            </div>
            <div className="flex justify-center gap-2 pt-2">
              <button
                onClick={clearAllFilters}
                className="px-4 py-2 bg-[#FAF8F5] border border-[#D4C3A3] text-xs font-bold text-[#2D3A3A] rounded-2xl cursor-pointer"
              >
                ফিল্টার রিসেট করুন
              </button>
              {activeMainTab === 'labor' ? (
                <button
                  onClick={() => setShowLaborAddModal(true)}
                  className="px-4 py-2 bg-[#2D5A27] text-white text-xs font-bold rounded-2xl flex items-center gap-1.5 cursor-pointer"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>কাজের বিজ্ঞপ্তি দিন</span>
                </button>
              ) : (
                <button
                  onClick={() => setShowAddModal(true)}
                  className="px-4 py-2 bg-[#2D5A27] text-white text-xs font-bold rounded-2xl flex items-center gap-1.5 cursor-pointer"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>প্রথম বিজ্ঞাপন দিন</span>
                </button>
              )}
            </div>
          </div>
        ) : (
          filteredListings.map((item) => {
            const freshness = getListingFreshness(item);
            const isLaborItem = item.category === 'কৃষিন ও দিনমজুর শ্রমিক';
            
            return (
              <div 
                key={item.id} 
                className={`bg-white rounded-3xl border ${
                  item.isSold 
                    ? 'border-gray-200 opacity-70 bg-gray-50/50' 
                    : freshness.isExpired 
                      ? 'border-red-200 bg-red-50/20' 
                      : isLaborItem
                        ? (item.laborType === 'worker_need' ? 'border-amber-200 hover:border-amber-400' : 'border-emerald-200 hover:border-emerald-400')
                        : 'border-[#E6E0D4] hover:border-[#2D5A27]/60'
                } p-5 flex flex-col justify-between shadow-xs transition-all relative overflow-hidden`}
              >
                {/* Sold / Expired Ribbon */}
                {item.isSold && (
                  <div className="bg-[#736B5E] text-white text-[10px] font-black uppercase tracking-wider py-1 px-8 absolute top-3 -right-8 rotate-45 shadow-sm text-center">
                    সম্পন্ন
                  </div>
                )}
                {!item.isSold && freshness.isExpired && (
                  <div className="bg-[#C0392B] text-white text-[10px] font-black uppercase tracking-wider py-1 px-8 absolute top-3 -right-8 rotate-45 shadow-sm text-center">
                    মেয়াদ শেষ
                  </div>
                )}

                <div>
                  {/* Photo if exists */}
                  {item.imageUrl && (
                    <div className="w-full h-44 rounded-2xl overflow-hidden mb-3.5 bg-gray-100 border border-[#E6E0D4] relative">
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}

                  {/* Badges row: Category & Freshness / Labor indicator */}
                  <div className="flex items-center justify-between gap-1.5 mb-2 flex-wrap">
                    {isLaborItem ? (
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                        item.laborType === 'worker_need' 
                          ? 'bg-amber-100 text-amber-900 border-amber-300' 
                          : 'bg-[#D4E4BC] text-[#1B4332] border-[#a3c482]'
                      }`}>
                        {item.laborType === 'worker_need' ? '📢 শ্রমিক আবশ্যক' : '👥 কৃষিন / দিনমজুর'}
                      </span>
                    ) : (
                      <span className="bg-[#F9E5D4] text-[#A65E2E] text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                        {item.category}
                      </span>
                    )}

                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${freshness.badgeClass}`}>
                      {freshness.label}
                    </span>
                  </div>

                  <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A] leading-snug">
                    {item.title}
                  </h3>

                  {/* Labor specific skill and team tags */}
                  {isLaborItem && (
                    <div className="flex items-center gap-1.5 flex-wrap mt-2">
                      {item.workType && (
                        <span className="bg-blue-50 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-md border border-blue-200">
                          কাজ: {item.workType}
                        </span>
                      )}
                      {item.teamSize && (
                        <span className="bg-emerald-50 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-200">
                          দল/সংখ্যা: {item.teamSize}
                        </span>
                      )}
                      {item.wageType && (
                        <span className="bg-gray-100 text-gray-700 text-[10px] font-medium px-2 py-0.5 rounded-md">
                          {item.wageType === 'daily' ? 'দৈনিক মজুরি' : 'চুক্তিভিত্তিক'}
                        </span>
                      )}
                    </div>
                  )}

                  {/* Price Tag & Stock */}
                  <div className="mt-2.5 flex items-baseline gap-2 flex-wrap">
                    <span className="text-xl font-extrabold text-[#2D5A27]">
                      {formatTaka(item.price)}
                    </span>
                    <span className="text-xs text-[#5A6B6B]">/{item.unit}</span>
                    {item.isNegotiable && (
                      <span className="bg-[#E8F8F5] text-[#27AE60] text-[10px] font-bold px-2 py-0.5 rounded-full ml-auto">
                        দরদাম প্রযোজ্য
                      </span>
                    )}
                  </div>

                  {item.quantity && !isLaborItem && (
                    <p className="text-xs text-[#5A6B6B] mt-1">
                      মজুদ / পরিমাণ: <span className="text-[#2D3A3A] font-bold">{item.quantity}</span>
                    </p>
                  )}

                  {/* Description Box */}
                  <p className="text-xs text-[#5A6B6B] line-clamp-2 mt-2 leading-relaxed bg-[#FDFBF7] p-2.5 rounded-2xl border border-[#E6E0D4]">
                    {item.description}
                  </p>

                  {/* Location Detailed Badge Box */}
                  <div className="mt-3 bg-[#FAF8F5] p-2.5 rounded-2xl border border-[#E6E0D4]/80 space-y-1.5 text-xs text-[#5A6B6B]">
                    <div className="flex items-center gap-1.5 text-[#2D3A3A] font-bold">
                      <MapPin className="w-3.5 h-3.5 text-[#E8924A] shrink-0" />
                      <span>
                        {item.hideVillage 
                          ? (item.upazila ? `উপজেলা: ${item.upazila}, ${item.district}` : `${item.district} জেলা`)
                          : (item.village ? `গ্রাম: ${item.village}, ${item.upazila || ''}` : item.location)}
                      </span>
                    </div>

                    {item.hideVillage && (
                      <div className="text-[10px] text-[#27AE60] flex items-center gap-1 font-semibold pl-5">
                        <Lock className="w-2.5 h-2.5" />
                        <span>গ্রাম গোপন রাখা হয়েছে (নিরাপদ উপজেলা পর্যায়)</span>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-1 border-t border-[#E6E0D4]/60 text-[11px]">
                      <div 
                        onClick={() => handleOpenSellerProfile(item)}
                        className="flex items-center gap-1.5 cursor-pointer group"
                        title="বিক্রেতার ফেসবুক/হোয়াটসঅ্যাপ স্টাইল বড় প্রোফাইল দেখতে স্পর্শ করুন"
                      >
                        <span className="font-bold text-[#2D5A27] group-hover:underline">
                          {item.sellerName}
                        </span>
                        <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] px-2 py-0.2 rounded-full font-bold">
                          {item.sellerRole === 'laborer' || item.laborType === 'worker_avail'
                            ? '🛠️ কৃষিন / দিনমজুর'
                            : (item.sellerRole === 'farmer' && item.laborType === 'worker_need')
                              ? '🌾 খামারি (মালিক)'
                              : item.sellerRole === 'home_entrepreneur' 
                                ? '🏡 গৃহ উদ্যোক্তা' 
                                : item.sellerRole === 'trader' 
                                  ? '🏪 ব্যবসায়ী' 
                                  : item.sellerRole === 'driver' 
                                    ? '🚗 চালক' 
                                    : '🌾 কৃষক/বিক্রেতা'}
                        </span>
                        {isUserKeyOnline(item.phone, onlineUsersMap) || isUserKeyOnline(item.sellerId, onlineUsersMap) ? (
                          <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-bold px-1.5 py-0.2 rounded-full flex items-center gap-0.5 shadow-2xs">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            <span>অনলাইন</span>
                          </span>
                        ) : (
                          <span className="bg-gray-100 text-gray-500 border border-gray-200 text-[10px] font-medium px-1.5 py-0.2 rounded-full">
                            <span>অফলাইন</span>
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleOpenSellerProfile(item)}
                          className="text-[10px] font-bold text-[#2D5A27] hover:underline cursor-pointer flex items-center gap-0.5"
                          title="বিক্রেতার পূর্ণাঙ্গ প্রোফাইল দেখুন"
                        >
                          <User className="w-3 h-3" />
                          <span>প্রোফাইল</span>
                        </button>
                        <span className="text-[10px] text-[#736B5E] flex items-center gap-0.5">
                          <Lock className="w-2.5 h-2.5 text-[#27AE60]" />
                          <span>{currentUser ? maskPhoneNumber(item.phone) : '•••••••• (লগইন করুন)'}</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Controls & Direct Contact Buttons */}
                <div className="mt-4 pt-3 border-t border-[#E6E0D4] space-y-2">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {/* Chat / Message Button */}
                    <button
                      type="button"
                      onClick={() => {
                        if (!currentUser) {
                          onOpenAuth?.('বিজ্ঞাপনদাতার সাথে বার্তা পাঠাতে লগইন বা নিবন্ধন করুন');
                          return;
                        }
                        setActiveChatListing(item);
                      }}
                      className="bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2 px-2 rounded-xl text-xs flex items-center justify-center gap-1 shadow-2xs transition cursor-pointer"
                      title="চ্যাট বা বার্তা পাঠান"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-[#D4E4BC]" />
                      <span>মেসেজ</span>
                    </button>

                    {/* Voice Chat Button */}
                    <button
                      type="button"
                      onClick={() => {
                        if (!currentUser) {
                          onOpenAuth?.('ভয়েস চ্যাট পাঠাতে লগইন বা নিবন্ধন করুন');
                          return;
                        }
                        setActiveVoiceTarget(item);
                      }}
                      className="bg-[#D4E4BC] hover:bg-[#2D5A27] text-[#2D5A27] hover:text-white font-bold py-2 px-2 rounded-xl text-xs flex items-center justify-center gap-1 shadow-2xs transition cursor-pointer"
                      title="ভয়েস মেসেজ / অডিও বার্তা পাঠান"
                    >
                      <Mic className="w-3.5 h-3.5" />
                      <span>ভয়েস চ্যাট</span>
                    </button>

                    {/* Call Button (Opens CallChoiceModal with offline call support) */}
                    <button
                      type="button"
                      onClick={() => {
                        if (!currentUser) {
                          onOpenAuth?.('বিজ্ঞাপনদাতার সাথে যোগাযোগ বা কল করতে লগইন বা নিবন্ধন করুন');
                          return;
                        }
                        setActiveCallingItem(item);
                      }}
                      className="bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold py-2 px-2 rounded-xl text-xs flex items-center justify-center gap-1 shadow-2xs transition cursor-pointer"
                      title="কলের মাধ্যম নির্বাচন করুন (অনলাইন / অফলাইন)"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>কল</span>
                    </button>

                    {/* Review Button */}
                    <button
                      type="button"
                      onClick={() => {
                        setActiveReviewTarget({
                          id: item.sellerId || item.id,
                          name: item.sellerName,
                          role: item.category === 'কৃষিন ও দিনমজুর শ্রমিক' ? 'laborer' : 'seller',
                          serviceType: item.category === 'কৃষিন ও দিনমজুর শ্রমিক' ? 'labor' : 'haat'
                        });
                      }}
                      className="bg-[#FFF9E6] hover:bg-[#F39C12]/20 border border-[#F39C12]/40 text-[#B7791F] font-bold py-2 px-2 rounded-xl text-xs flex items-center justify-center gap-1 transition cursor-pointer"
                      title="রেটিং ও রিভিউ দিন"
                    >
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span>রিভিউ</span>
                    </button>
                  </div>

                  {/* Action Bar: Owner/Admin vs Visitor */}
                  {(() => {
                    const cleanPhone = (p?: string) => p ? p.replace(/[^0-9]/g, '') : '';
                    let localPostedIds: string[] = [];
                    try {
                      localPostedIds = JSON.parse(localStorage.getItem('polli_user_posted_items') || '[]');
                    } catch {
                      localPostedIds = [];
                    }
                    const isElevatedAdmin = isUserAdminOrAssistantAdmin(currentUser);

                    const isOwner = Boolean(
                      localPostedIds.includes(item.id) ||
                      (currentUser && (
                        currentUser.id === item.sellerId ||
                        (cleanPhone(currentUser.phone) && cleanPhone(item.phone) && cleanPhone(currentUser.phone) === cleanPhone(item.phone))
                      ))
                    );

                    const canDeleteOrManage = isElevatedAdmin || isOwner;

                    if (canDeleteOrManage) {
                      return (
                        <div className="flex items-center justify-between text-[11px] pt-2 border-t border-dashed border-[#E6E0D4] text-[#5A6B6B]">
                          {isElevatedAdmin && !isOwner ? (
                            <span className="text-[10px] bg-red-100 text-red-800 font-bold px-2 py-0.5 rounded-full flex items-center gap-1 border border-red-200">
                              🛡️ এডমিন এক্সেস
                            </span>
                          ) : freshness.isExpired ? (
                            <button
                              onClick={() => handleRenewListing(item.id)}
                              className="text-[#2D5A27] hover:underline font-bold flex items-center gap-1 cursor-pointer bg-[#D4E4BC]/50 px-2 py-0.5 rounded-md"
                              title="আরও দিন মেয়াদ বাড়িয়ে সক্রিয় করুন"
                            >
                              <RefreshCw className="w-3 h-3" />
                              <span>পুনরায় সক্রিয় (Renew)</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => handleToggleSold(item.id)}
                              className="text-[#2D5A27] hover:underline font-bold flex items-center gap-1 cursor-pointer bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-200"
                              title={item.isSold ? 'বিজ্ঞাপনটি পুনরায় সক্রিয় করুন' : 'কাজ বা বিক্রি শেষ হলে হাইড করুন'}
                            >
                              <CheckCircle2 className="w-3.5 h-3.5 text-[#2D5A27]" />
                              <span>
                                {item.isSold 
                                  ? 'পুনরায় সক্রিয় করুন' 
                                  : isLaborItem 
                                    ? (item.laborType === 'worker_need' ? 'শ্রমিক পেয়েছি (হাইড)' : 'কাজ পেয়েছি (হাইড)')
                                    : 'বিক্রি শেষ (হাইড)'}
                              </span>
                            </button>
                          )}

                          <button
                            onClick={() => handleDeleteItem(item.id)}
                            className="text-[#C0392B] hover:bg-red-50 font-bold flex items-center gap-1 cursor-pointer px-2.5 py-1 rounded-lg border border-red-200 bg-red-50/50 transition"
                            title="বিজ্ঞাপনটি সম্পূর্ণ মুছে ফেলুন (প্রধান এডমিন / সহকারী এডমিন / মালিকের ক্ষমতা)"
                          >
                            <Trash2 className="w-3.5 h-3.5 text-red-600" />
                            <span className="text-red-600 font-bold">মুছুন</span>
                          </button>
                        </div>
                      );
                    }

                    if (item.isSold || item.isCompleted) {
                      return (
                        <div className="flex items-center justify-between text-[10px] pt-1.5 bg-gray-50 px-2 py-1 rounded-lg border border-gray-200 text-gray-600">
                          <span className="font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>{isLaborItem ? 'সম্পন্ন (নতুন কাজ/শ্রমিক প্রয়োজন নেই)' : 'বিক্রি সম্পন্ন'}</span>
                          </span>
                        </div>
                      );
                    }

                    return (
                      <div className="flex items-center justify-between text-[10px] pt-1.5 text-[#736B5E]">
                        <span className="flex items-center gap-1 text-[#27AE60] font-medium">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>যাচাইকৃত বিজ্ঞাপনদাতা</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setListings(prev => prev.filter(l => l.id !== item.id));
                            setToastMessage('বিজ্ঞাপনটি আপনার তালিকা থেকে সাময়িক সরানো হয়েছে।');
                            setTimeout(() => setToastMessage(null), 2500);
                          }}
                          className="hover:underline text-[#736B5E] hover:text-[#2D3A3A] cursor-pointer"
                        >
                          লুকান
                        </button>
                      </div>
                    );
                  })()}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[88vh] sm:max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E0D4] overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] p-4 sm:p-5 shrink-0 bg-white">
              <div>
                <h3 className="font-bold text-base text-[#2D3A3A]">
                  কৃষিপণ্য ও তাজা তরিতরকারির বিজ্ঞাপন দিন
                </h3>
                <p className="text-[11px] text-[#5A6B6B]">
                  সরাসরি ভোক্তা ক্রেতাদের সাথে যোগাযোগের জন্য আপনার তথ্য দিন
                </p>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateListing} className="flex flex-col flex-1 overflow-hidden">
              <div className="p-4 sm:p-5 overflow-y-auto overscroll-contain flex-1 space-y-4">
              {/* Product Title */}
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  বিজ্ঞাপনের শিরোনাম / পণ্যের নাম *
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: জমি থেকে তোলা টাটকা পালং শাক, দেশি লাল আলু, গাছের পাকা সবরি কলা"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                />
              </div>

              {/* Category & Item Type */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    ক্যাটাগরি
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    <option value="তাজা তরিতরকারি ও শাকসবজি">তাজা তরিতরকারি ও শাকসবজি</option>
                    <option value="গৃহ তৈরি খাবার ও নাস্তা">গৃহ তৈরি খাবার ও নাস্তা</option>
                    <option value="ফসলের ফলন">ফসলের ফলন (ধান/গম/পাট)</option>
                    <option value="ফলমূল">ফলমূল (কলা/আম/পেঁপে)</option>
                    <option value="গবাদিপশু ও হাঁস-মুরগি">গবাদিপশু ও হাঁস-মুরগি</option>
                    <option value="বীজ ও চারা">বীজ ও চারা</option>
                    <option value="কৃষি যন্ত্রপাতি">কৃষি যন্ত্রপাতি</option>
                    <option value="খাঁটি গ্রামীণ পণ্য">খাঁটি গ্রামীণ পণ্য (মধু/গুড়)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    পণ্যের ধরন
                  </label>
                  <select
                    value={itemType}
                    onChange={(e) => setItemType(e.target.value as any)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    <option value="পাতাযুক্ত শাক">পাতাযুক্ত তাজা শাক (পালং/লাল শাক)</option>
                    <option value="তাজা সবজি">নরম তরিতরকারি (বেগুন/টমেটো/কাঁচামরিচ)</option>
                    <option value="আলু/পেঁয়াজ/রসুন">আলু / পেঁয়াজ / রসুন / আদা</option>
                    <option value="ফলমূল">কাঁচা বা পাকা ফলমূল</option>
                    <option value="খাদ্যশস্য">খাদ্যশস্য (ধান/চাল/ডাল)</option>
                    <option value="পশু-পাখি">পশু-পাখি ও হাঁস-মুরগি</option>
                    <option value="অন্যান্য">অন্যান্য পণ্য</option>
                  </select>
                </div>
              </div>

              {/* Price & Unit */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    মূল্য (টাকা) *
                  </label>
                  <input
                    type="number"
                    required
                    placeholder="যেমন: ২৫"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    একক (কেজি/আঁটি/মণ/ডজন)
                  </label>
                  <input
                    type="text"
                    placeholder="কেজি / আঁটি / মণ / ডজন"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>
              </div>

              {/* Stock Quantity & Negotiable */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    মোট মজুদ / পরিমাণ
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: ৪০ আঁটি বা ৫ মণ"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>

                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 text-xs text-[#2D3A3A] font-semibold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isNegotiable}
                      onChange={(e) => setIsNegotiable(e.target.checked)}
                      className="w-4 h-4 text-[#2D5A27] accent-[#2D5A27] rounded"
                    />
                    <span>দামাদামি বা দরদাম চলবে</span>
                  </label>
                </div>
              </div>

              {/* Automatic Shelf Life / Expiry Selector */}
              <div className="p-3 bg-[#FEF9E7] rounded-2xl border border-[#F9E79F] space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-[#7D6608] flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#B7950B]" />
                    <span>বিজ্ঞাপনের সক্রিয় মেয়াদ ও অটো-হাইড সময়কাল:</span>
                  </label>
                  <span className="text-[11px] font-bold text-[#A65E2E] bg-white px-2 py-0.5 rounded-full border border-[#F9E79F]">
                    {expiryDays} দিনের জন্য
                  </span>
                </div>

                <select
                  value={expiryDays}
                  onChange={(e) => setExpiryDays(Number(e.target.value))}
                  className="w-full border border-[#D4C3A3] bg-white rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A] font-bold"
                >
                  <option value={1}>১ দিন (জরুরি তাজা শাক - ২৪ ঘণ্টা পর অটো-হাইড)</option>
                  <option value={2}>২ দিন (পালং শাক / লাল শাক / কলমি শাক)</option>
                  <option value={3}>৩ দিন (কাঁচামরিচ / বেগুন / শসা)</option>
                  <option value={5}>৫ দিন (তাজা কাঁচামাল ও সবজি)</option>
                  <option value={7}>৭ দিন (১ সপ্তাহ - কলা / টমেটো / পেঁপে)</option>
                  <option value={15}>১৫ দিন (আলু / মিষ্টি কুমড়া / আদা)</option>
                  <option value={30}>৩০ দিন (১ মাস - দেশি পেঁয়াজ / শস্য)</option>
                  <option value={90}>৯০ দিন (৩ মাস - রসুন / ডাল / ধান / চাল)</option>
                </select>

                {customDaysReason && (
                  <p className="text-[11px] text-[#7D6608] leading-tight flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-[#B7950B] shrink-0" />
                    <span>স্মার্ট পরামর্শ: {customDaysReason}</span>
                  </p>
                )}
              </div>

              {/* Detailed Location Structure */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] space-y-2.5">
                <span className="text-xs font-bold text-[#2D5A27] flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                  <span>পণ্য যেখানে পাওয়া যাবে (সুনির্দিষ্ট এলাকা নির্বাচন করুন):</span>
                </span>

                <CascadingAddressSelector
                  address={formAddress}
                  onChange={setFormAddress}
                  layout="grid-2x2"
                  required={true}
                  villagePlaceholder="যেমন: রামপুর পশ্চিমপাড়া বা দেউলী বাজার"
                  labelPrefix="পণ্য প্রাপ্তির "
                />

                {/* Village privacy option */}
                <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formHideVillage}
                      onChange={(e) => setFormHideVillage(e.target.checked)}
                      className="rounded text-[#2D5A27] focus:ring-[#2D5A27] w-4 h-4 cursor-pointer"
                    />
                    <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5 text-[#27AE60]" />
                      <span>গ্রামের নাম গোপন রাখুন (প্রাইভেসী প্রটেকশন)</span>
                    </span>
                  </label>
                  <p className="text-[11px] text-[#5A6B6B] pl-6">
                    চালু রাখলে ক্রেতারা শুধুমাত্র আপনার থানা ও উপজেলা দেখতে পাবেন, নির্দিষ্ট গ্রামের নাম গোপন থাকবে।
                  </p>
                </div>

                {/* Local Notification Scope Selection */}
                <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#D4C3A3] space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-[#2D5A27] flex items-center gap-1.5">
                      <Bell className="w-3.5 h-3.5 text-[#E8924A]" />
                      <span>নোটিফিকেশন এলাকা পরিধি (কারা তাৎক্ষণিক অ্যালার্ট পাবে):</span>
                    </label>
                    <span className="text-[10px] text-[#736B5E]">স্মার্ট অ্যালার্ট</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setProductNotificationScope('upazila')}
                      className={`p-2.5 rounded-xl text-xs font-bold border text-left transition flex items-center gap-2 cursor-pointer ${
                        productNotificationScope === 'upazila'
                          ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-xs'
                          : 'bg-white text-[#5A6B6B] border-[#D4C3A3] hover:bg-gray-50'
                      }`}
                    >
                      <MapPin className="w-3.5 h-3.5 shrink-0 text-[#E8924A]" />
                      <div>
                        <div className="leading-tight">উপজেলা ভিত্তিক</div>
                        <div className={`text-[10px] font-normal ${productNotificationScope === 'upazila' ? 'text-green-100' : 'text-[#736B5E]'}`}>
                          {formAddress.upazila ? `${formAddress.upazila} উপজেলা` : 'আমার উপজেলার সবাই'}
                        </div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setProductNotificationScope('district')}
                      className={`p-2.5 rounded-xl text-xs font-bold border text-left transition flex items-center gap-2 cursor-pointer ${
                        productNotificationScope === 'district'
                          ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-xs'
                          : 'bg-white text-[#5A6B6B] border-[#D4C3A3] hover:bg-gray-50'
                      }`}
                    >
                      <Users className="w-3.5 h-3.5 shrink-0 text-[#E8924A]" />
                      <div>
                        <div className="leading-tight">জেলা ভিত্তিক (ডিফল্ট)</div>
                        <div className={`text-[10px] font-normal ${productNotificationScope === 'district' ? 'text-green-100' : 'text-[#736B5E]'}`}>
                          {formAddress.district ? `${formAddress.district} জেলা` : 'পুরো জেলার সবাই'}
                        </div>
                      </div>
                    </button>
                  </div>

                  <p className="text-[10px] text-[#736B5E] leading-tight">
                    {productNotificationScope === 'upazila'
                      ? `📍 শুধুমাত্র ${formAddress.upazila || 'আপনার'} উপজেলার নিবন্ধিত ক্রেতা ও কৃষকদের কাছে নোটিফিকেশন পৌঁছাবে।`
                      : `🌐 পুরো ${formAddress.district || 'আপনার'} জেলার সকল ক্রেতা ও হাট ব্যবহারকারীর কাছে নোটিফিকেশন পৌঁছাবে।`}
                  </p>
                </div>
              </div>

              {/* Seller Role & Contact */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    আপনার পরিচয় / ভূমিকা
                  </label>
                  <select
                    value={sellerRole}
                    onChange={(e) => setSellerRole(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    <option value="farmer">🌾 কৃষক / খামারি</option>
                    <option value="home_entrepreneur">🏡 গৃহ উদ্যোক্তা</option>
                    <option value="trader">🏪 ব্যবসায়ী / আড়তদার</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    আপনার নাম *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="আপনার নাম"
                    value={sellerName}
                    onChange={(e) => setSellerName(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    মোবাইল নম্বর *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৭xxxxxxxx"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              {/* Product Photo with Live Camera or Upload */}
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  পণ্যের ছবি (সরাসরি ক্যামেরা দিয়ে তুলুন বা আপলোড করুন)
                </label>
                {productImageBase64 ? (
                  <div className="flex items-center justify-between gap-2 p-2 bg-[#FAF8F5] border border-[#2D5A27] rounded-2xl">
                    <div className="flex items-center gap-2">
                      <img src={productImageBase64} alt="Product" className="w-10 h-10 object-cover rounded-xl" />
                      <span className="text-xs font-bold text-[#2D5A27]">ছবি সফলভাবে যুক্ত হয়েছে ✓</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setProductImageBase64(null)}
                      className="p-1 text-[#C0392B]"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={handleStartCamera}
                      className="bg-[#2D5A27] text-white py-2 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <Camera className="w-4 h-4" />
                      <span>ক্যামেরা দিয়ে ছবি তুলুন</span>
                    </button>

                    <div className="relative">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageFile}
                        className="hidden"
                        id="haat-photo-upload"
                      />
                      <label
                        htmlFor="haat-photo-upload"
                        className="bg-white border border-[#2D5A27] text-[#2D5A27] py-2 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer text-center"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>গ্যালারি থেকে নিন</span>
                      </label>
                    </div>
                  </div>
                )}
              </div>

              {/* Live Camera View inside modal */}
              {isCameraActive && (
                <div className="p-3 bg-black/90 rounded-2xl space-y-2 text-white text-center">
                  <video ref={videoRef} autoPlay playsInline className="w-full h-44 object-cover rounded-xl" />
                  <div className="flex justify-between gap-2">
                    <button
                      type="button"
                      onClick={handleStopCamera}
                      className="px-3 py-1.5 bg-gray-600 rounded-xl text-xs"
                    >
                      বাতিল
                    </button>
                    <button
                      type="button"
                      onClick={handleSnapPhoto}
                      className="px-4 py-1.5 bg-[#2D5A27] font-bold rounded-xl text-xs"
                    >
                      ছবি তুলুন (Snap)
                    </button>
                  </div>
                </div>
              )}

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  পণ্যের বিস্তারিত বিবরণ *
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="যেমন: কীটনাশক ছাড়া আজ সকালে জমি থেকে সরাসরি তোলা তাজা শাক, তরকারির স্বাদ অত্যন্ত চমৎকার..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              {/* Global Auto-fill & Offline Call Status Box */}
              <div className="bg-[#FAF6ED] border border-[#E6DEC8] rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                    <span>📞</span>
                    <span>অফলাইন সরাসরি কল পারমিশন (Auto-fill)</span>
                  </span>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                    formAllowOfflineCall 
                      ? 'bg-[#D4E4BC] text-[#2D5A27] border-[#2D5A27]/30' 
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}>
                    {formAllowOfflineCall ? 'অনুমোদিত (হ্যাঁ)' : 'সুরক্ষিত/গোপন (না)'}
                  </span>
                </div>

                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formAllowOfflineCall}
                    onChange={(e) => setFormAllowOfflineCall(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2D5A27] focus:ring-[#2D5A27] cursor-pointer mt-0.5 shrink-0"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-[#2D3A3A] block">
                      আপনি কি ক্রেতা বা বেপারিদের সরাসরি অফলাইনে কলের সুযোগ দিতে চান?
                    </span>
                    <span className="text-[11px] text-[#736B5E] block mt-0.5 leading-relaxed">
                      {formAllowOfflineCall
                        ? '✓ অনুমোদিত: ক্রেতারা সরাসরি আপনার সিম কার্ডের নম্বরে কল করতে পারবেন (তবে কল করার পূর্বে তাদের স্ক্রিনে সতর্কবার্তা দেখানো হবে)।'
                        : '🔒 বন্ধ (ডিফল্ট): আপনার মোবাইল নম্বর ও সুনির্দিষ্ট গ্রাম/ওয়ার্ড গোপন থাকবে। ক্রেতারা ইন-অ্যাপ চ্যাট বা সুরক্ষিত ভয়েস কলে যোগাযোগ করবেন।'}
                    </span>
                  </div>
                </label>
              </div>
              </div>

              {/* Pinned Sticky Bottom Action Bar */}
              <div className="border-t border-[#E6E0D4] p-4 bg-[#FAF8F5] shrink-0 flex justify-end gap-2 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-white border border-[#E6E0D4] hover:bg-gray-50 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-sm cursor-pointer active:scale-98 transition"
                >
                  বিজ্ঞাপন প্রকাশ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Labor/Worker Specific Add Listing Modal (কৃষিন / কামলা / জোন সেবা) */}
      {showLaborAddModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[88vh] sm:max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E0D4] overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] p-4 sm:p-5 shrink-0 bg-white">
              <div>
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="bg-[#D4E4BC] text-[#1B4332] text-[10px] font-bold px-2 py-0.5 rounded-full">
                    কৃষিন ও দিনমজুর সেবা
                  </span>
                  <span className="text-xs text-[#5A6B6B]">| পল্লী হাট ও শ্রমিক বাজার</span>
                </div>
                <h3 className="font-bold text-base text-[#2D3A3A]">
                  খামার বা কৃষিকাজের শ্রমিক আবশ্যক বিজ্ঞাপন
                </h3>
                <p className="text-[11px] text-[#5A6B6B] mt-0.5">
                  আপনার জমির ধান কাটা, রোপণ বা খামার কাজের জন্য শ্রমিক চেয়ে বিজ্ঞপ্তি দিন
                </p>
              </div>
              <button
                onClick={() => setShowLaborAddModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateLaborListing} className="flex flex-col flex-1 overflow-hidden">
              <div className="p-4 sm:p-5 overflow-y-auto overscroll-contain flex-1 space-y-4">
              {/* Title */}
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  বিজ্ঞাপনের শিরোনাম *
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    laborFormType === 'worker_avail'
                      ? "যেমন: অভিজ্ঞ ৫ জনের ধান কাটা শ্রমিক দল প্রস্তুত, বা নিড়ানির জন্য দিনমজুর"
                      : "যেমন: ১০ বিঘা জমির ধান কাটার জন্য ৪ জন দক্ষ কৃষিন আবশ্যক"
                  }
                  value={laborTitle}
                  onChange={(e) => setLaborTitle(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                />
              </div>

              {/* Work Type & Team Size */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    কাজের ধরন / ক্ষেত্র *
                  </label>
                  <select
                    value={laborWorkType}
                    onChange={(e) => setLaborWorkType(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    <option value="ধান কাটা ও মাড়াই">ধান কাটা ও মাড়াই</option>
                    <option value="ধান রোপণ (রোয়া)">ধান রোপণ (রোয়া)</option>
                    <option value="জমি চাষ ও নিড়ানি">জমি চাষ ও নিড়ানি</option>
                    <option value="আলু/সবজি তোলা ও প্যাকেজিং">আলু/সবজি তোলা ও প্যাকেজিং</option>
                    <option value="মাটি কাটা ও সেচ কাজ">মাটি কাটা ও সেচ কাজ</option>
                    <option value="সাধারণ দিনমজুরি">সাধারণ দিনমজুরি</option>
                    <option value="যেকোনো কৃষিকাজ">যেকোনো কৃষিকাজ</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    {laborFormType === 'worker_avail' ? 'শ্রমিক দলের সদস্য সংখ্যা' : 'প্রয়োজনীয় শ্রমিকের সংখ্যা'}
                  </label>
                  <select
                    value={laborTeamSize}
                    onChange={(e) => setLaborTeamSize(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    <option value="১ জন (একক)">১ জন (একক)</option>
                    <option value="২-৩ জনের দল">২-৩ জনের দল</option>
                    <option value="৪-৫ জনের দল">৪-৫ জনের দল</option>
                    <option value="৬-১০ জনের দল">৬-১০ জনের দল</option>
                    <option value="১০+ জনের বড় দল">১০+ জনের বড় দল</option>
                  </select>
                </div>
              </div>

              {/* Wage / Price Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    প্রত্যাশিত / প্রস্তাবিত মজুরি (টাকা) *
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    placeholder="যেমন: ৬০০"
                    value={laborPrice}
                    onChange={(e) => setLaborPrice(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    মজুরির হিসাব / ভিত্তি
                  </label>
                  <select
                    value={laborWageType}
                    onChange={(e) => setLaborWageType(e.target.value as 'daily' | 'contract')}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    <option value="daily">দৈনিক হাজিরা (জনপ্রতি)</option>
                    <option value="contract">চুক্তিভিত্তিক (বিঘা/কাজের চুক্তি)</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="laborNegotiable"
                  checked={laborNegotiable}
                  onChange={(e) => setLaborNegotiable(e.target.checked)}
                  className="rounded text-[#2D5A27] focus:ring-[#2D5A27] w-4 h-4 cursor-pointer"
                />
                <label htmlFor="laborNegotiable" className="text-xs text-[#2D3A3A] font-semibold cursor-pointer">
                  মজুরি আলোচনা বা দরদাম সাপেক্ষ
                </label>
              </div>

              {/* Cascading Location */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] space-y-2.5">
                <span className="text-xs font-bold text-[#2D5A27] flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                  <span>{laborFormType === 'worker_avail' ? 'শ্রমিকের এলাকা / ঠিকানা:' : 'কাজের স্থান / খামারের এলাকা:'}</span>
                </span>

                <CascadingAddressSelector
                  address={laborAddress}
                  onChange={setLaborAddress}
                  layout="grid-2x2"
                  required={true}
                  villagePlaceholder="যেমন: রামপুর পশ্চিমপাড়া বা হাটখোলা"
                  labelPrefix="এলাকার "
                />

                {/* Local Notification Scope Selection */}
                <div className="bg-white p-3 rounded-2xl border border-[#D4C3A3] space-y-2 mt-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-[#2D5A27] flex items-center gap-1.5">
                      <Bell className="w-3.5 h-3.5 text-[#E8924A]" />
                      <span>নোটিফিকেশন এলাকা পরিধি (কারা তাৎক্ষণিক অ্যালার্ট পাবে):</span>
                    </label>
                    <span className="text-[10px] text-[#736B5E]">স্মার্ট অ্যালার্ট</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setLaborNotificationScope('upazila')}
                      className={`p-2.5 rounded-xl text-xs font-bold border text-left transition flex items-center gap-2 cursor-pointer ${
                        laborNotificationScope === 'upazila'
                          ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-xs'
                          : 'bg-[#FAF8F5] text-[#5A6B6B] border-[#D4C3A3] hover:bg-gray-100'
                      }`}
                    >
                      <MapPin className="w-3.5 h-3.5 shrink-0 text-[#E8924A]" />
                      <div>
                        <div className="leading-tight">উপজেলা ভিত্তিক</div>
                        <div className={`text-[10px] font-normal ${laborNotificationScope === 'upazila' ? 'text-green-100' : 'text-[#736B5E]'}`}>
                          {laborAddress.upazila ? `${laborAddress.upazila} উপজেলা` : 'আমার উপজেলার সবাই'}
                        </div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setLaborNotificationScope('district')}
                      className={`p-2.5 rounded-xl text-xs font-bold border text-left transition flex items-center gap-2 cursor-pointer ${
                        laborNotificationScope === 'district'
                          ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-xs'
                          : 'bg-[#FAF8F5] text-[#5A6B6B] border-[#D4C3A3] hover:bg-gray-100'
                      }`}
                    >
                      <Users className="w-3.5 h-3.5 shrink-0 text-[#E8924A]" />
                      <div>
                        <div className="leading-tight">জেলা ভিত্তিক (ডিফল্ট)</div>
                        <div className={`text-[10px] font-normal ${laborNotificationScope === 'district' ? 'text-green-100' : 'text-[#736B5E]'}`}>
                          {laborAddress.district ? `${laborAddress.district} জেলা` : 'পুরো জেলার সবাই'}
                        </div>
                      </div>
                    </button>
                  </div>

                  <p className="text-[10px] text-[#736B5E] leading-tight">
                    {laborNotificationScope === 'upazila'
                      ? `📍 শুধুমাত্র ${laborAddress.upazila || 'আপনার'} উপজেলার কৃষিন ও খামারিদের কাছে তাৎক্ষণিক নোটিফিকেশন যাবে।`
                      : `🌐 পুরো ${laborAddress.district || 'আপনার'} জেলার সকল কৃষিন, শ্রমিক ও খামারিদের কাছে নোটিফিকেশন পৌঁছাবে।`}
                  </p>
                </div>
              </div>

              {/* Poster Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    {laborFormType === 'worker_avail' ? 'আপনার বা দলনেতার নাম *' : 'খামারি বা নিয়োগকর্তার নাম *'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="নাম লিখুন"
                    value={laborName}
                    onChange={(e) => setLaborName(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    মোবাইল নম্বর (যোগাযোগের জন্য) *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৭xxxxxxxx"
                    value={laborPhone}
                    onChange={(e) => setLaborPhone(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  বিস্তারিত বিবরণ ও শর্তাবলী *
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder={
                    laborFormType === 'worker_avail'
                      ? "যেমন: আমাদের নিজস্ব কাস্তে আছে, দ্রুত ও পরিচ্ছন্নভাবে ধান কাটি ও আঁটি বাঁধি, দূরবর্তী উপজেলায় থাকার সুব্যবস্থা থাকলে যাওয়া সম্ভব..."
                      : "যেমন: আগামী পরশু থেকে টানা ৩ দিন কাজ করতে হবে, দুপুরে খাবারের ব্যবস্থা রয়েছে..."
                  }
                  value={laborDescription}
                  onChange={(e) => setLaborDescription(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              {/* Islamic & Legal Liability Notice in Modal */}
              <div className="bg-[#FAF8F5] border border-[#E6E0D4] rounded-2xl p-3 text-xs space-y-1.5">
                <p className="font-bold text-[#2D5A27]">
                  🌾 "শ্রমিকদের গায়ের ঘাম শুকানোর আগেই তাদের মজুরি পরিশোধ করতে চেষ্টা করুন।" <span className="font-normal text-[#5A6B6B]">(হাদিস শরিফ)</span>
                </p>
                <p className="text-[11px] text-[#736B5E]">
                  ⚖️ <strong>কর্তৃপক্ষের দায়মুক্তি:</strong> শ্রমিকদের মজুরি আদায় করে দিতে বাধ্য নয় অ্যাপ কর্তৃপক্ষ। পল্লী সেবা প্ল্যাটফর্ম কেবল কৃষক ও শ্রমিকের সরাসরি যোগাযোগের নিরপেক্ষ মাধ্যম।
                </p>
                <div className="pt-1 flex items-center justify-between">
                  <span className="text-[10px] text-[#5A6B6B]">সরকারি শ্রম সহায়তা:</span>
                  <a
                    href="tel:16199"
                    className="text-[10px] font-bold text-[#1E3A8A] hover:underline"
                  >
                    জাতীয় শ্রম কল সেন্টার: ১৬১৯৯ (টোল-ফ্রি)
                  </a>
                </div>
              </div>

              {/* Global Auto-fill & Offline Call Status Box */}
              <div className="bg-[#FAF6ED] border border-[#E6DEC8] rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                    <span>📞</span>
                    <span>অফলাইন সরাসরি কল পারমিশন (Auto-fill)</span>
                  </span>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                    laborAllowOfflineCall 
                      ? 'bg-[#D4E4BC] text-[#2D5A27] border-[#2D5A27]/30' 
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}>
                    {laborAllowOfflineCall ? 'অনুমোদিত (হ্যাঁ)' : 'সুরক্ষিত/গোপন (না)'}
                  </span>
                </div>

                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={laborAllowOfflineCall}
                    onChange={(e) => setLaborAllowOfflineCall(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2D5A27] focus:ring-[#2D5A27] cursor-pointer mt-0.5 shrink-0"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-[#2D3A3A] block">
                      {laborFormType === 'worker_avail'
                        ? 'আপনি কি খামারি বা গৃহস্থদের সরাসরি অফলাইনে কলের সুযোগ দিতে চান?'
                        : 'আপনি কি আগ্রহী কৃষিন/শ্রমিকদের সরাসরি অফলাইনে কলের সুযোগ দিতে চান?'}
                    </span>
                    <span className="text-[11px] text-[#736B5E] block mt-0.5 leading-relaxed">
                      {laborAllowOfflineCall
                        ? '✓ অনুমোদিত: খামারি বা শ্রমিক সরাসরি আপনার সিম কার্ডের নম্বরে কল করতে পারবেন (তবে কল করার পূর্বে তাদের স্ক্রিনে সতর্কবার্তা দেখানো হবে)।'
                        : '🔒 বন্ধ (ডিফল্ট): আপনার মোবাইল নম্বর ও সুনির্দিষ্ট গ্রাম/ওয়ার্ড গোপন থাকবে। যোগাযোগকারীরা ইন-অ্যাপ চ্যাট বা ভয়েস কলে যোগাযোগ করবেন।'}
                    </span>
                  </div>
                </label>
              </div>
              </div>

              {/* Pinned Sticky Bottom Action Bar */}
              <div className="border-t border-[#E6E0D4] p-4 bg-[#FAF8F5] shrink-0 flex justify-end gap-2 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
                <button
                  type="button"
                  onClick={() => setShowLaborAddModal(false)}
                  className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-white border border-[#E6E0D4] hover:bg-gray-50 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-sm cursor-pointer active:scale-98 transition"
                >
                  বিজ্ঞপ্তি প্রকাশ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      </>
      )}

      {/* Real-time Cloud Chat Modal */}
      {activeChatListing && (
        <ChatModal
          isOpen={!!activeChatListing}
          onClose={() => setActiveChatListing(null)}
          currentUser={currentUser}
          recipientId={activeChatListing.sellerId || `seller-${activeChatListing.phone}`}
          recipientName={activeChatListing.sellerName}
          recipientRole={
            activeChatListing.category === 'কৃষিন ও দিনমজুর শ্রমিক'
              ? (activeChatListing.laborType === 'worker_need' ? 'মালিক/খামারি' : 'কৃষিন/শ্রমিক')
              : (activeChatListing.sellerRole || 'seller')
          }
          recipientPhone={activeChatListing.phone}
          recipientPhoto={activeChatListing.imageUrl}
          itemTitle={activeChatListing.title}
          itemPrice={activeChatListing.price}
          itemUnit={activeChatListing.unit}
          itemPhoto={activeChatListing.imageUrl}
          onOpenAuth={onOpenAuth}
        />
      )}

      {/* Direct Call / In-App Voice Call Choice Modal */}
      {activeCallingItem && (
        <CallChoiceModal
          recipientName={activeCallingItem.sellerName}
          recipientRole={
            activeCallingItem.category === 'কৃষিন ও দিনমজুর শ্রমিক'
              ? (activeCallingItem.laborType === 'worker_need' ? 'খামারি (কাজের সুযোগ)' : 'কৃষিন / দিনমজুর')
              : 'seller'
          }
          recipientPhoto={activeCallingItem.imageUrl}
          recipientSubtitle={`বিজ্ঞপ্তি: ${activeCallingItem.title} (${activeCallingItem.district})`}
          rawPhone={activeCallingItem.phone}
          onSelectInAppCall={() => {
            const item = activeCallingItem;
            setActiveCallingItem(null);
            setInAppVoiceItem(item);
          }}
          onOpenChat={() => {
            const item = activeCallingItem;
            setActiveCallingItem(null);
            setActiveChatListing(item);
          }}
          onOpenVoiceNote={() => {
            const item = activeCallingItem;
            setActiveCallingItem(null);
            setActiveVoiceTarget(item);
          }}
          onClose={() => setActiveCallingItem(null)}
        />
      )}

      {/* In-App Encrypted Voice Call Modal */}
      {inAppVoiceItem && (
        <InAppVoiceCallModal
          recipientName={inAppVoiceItem.sellerName}
          recipientRole={
            inAppVoiceItem.category === 'কৃষিন ও দিনমজুর শ্রমিক'
              ? (inAppVoiceItem.laborType === 'worker_need' ? 'খামারি (কাজের সুযোগ)' : 'কৃষিন / দিনমজুর')
              : 'seller'
          }
          recipientPhoto={inAppVoiceItem.imageUrl}
          recipientSubtitle={`বিজ্ঞপ্তি: ${inAppVoiceItem.title} (${inAppVoiceItem.district})`}
          maskedPhone={maskPhoneNumber(inAppVoiceItem.phone)}
          rawPhone={inAppVoiceItem.phone}
          currentUser={currentUser}
          onClose={() => setInAppVoiceItem(null)}
        />
      )}

      {/* Voice Chat Modal */}
      {activeVoiceTarget && (
        <VoiceChatModal
          isOpen={true}
          onClose={() => setActiveVoiceTarget(null)}
          recipientName={activeVoiceTarget.sellerName}
          recipientRole={
            activeVoiceTarget.category === 'কৃষিন ও দিনমজুর শ্রমিক'
              ? (activeVoiceTarget.laborType === 'worker_need' ? 'খামারি' : 'কৃষিন')
              : 'বিক্রেতা'
          }
          recipientPhone={activeVoiceTarget.phone}
          recipientAvatar={activeVoiceTarget.imageUrl}
          itemTitle={activeVoiceTarget.title}
          currentUser={currentUser}
          onSendVoiceMessage={(audioUrl, duration, textSummary) => {
            const item = activeVoiceTarget;
            setActiveVoiceTarget(null);
            setActiveChatListing(item);
          }}
        />
      )}

      {/* Two-Way Rating & Review Modal */}
      {activeReviewTarget && (
        <TwoWayReviewModal
          isOpen={true}
          onClose={() => setActiveReviewTarget(null)}
          targetId={activeReviewTarget.id}
          targetName={activeReviewTarget.name}
          targetRole={activeReviewTarget.role}
          serviceType={activeReviewTarget.serviceType}
          currentUser={currentUser}
        />
      )}
    </div>
  );
};
