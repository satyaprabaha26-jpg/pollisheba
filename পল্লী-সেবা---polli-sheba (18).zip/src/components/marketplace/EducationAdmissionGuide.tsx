import React, { useState } from 'react';
import { 
  GraduationCap, 
  BookOpen, 
  Award, 
  ExternalLink, 
  CheckCircle2, 
  AlertCircle, 
  AlertTriangle,
  FileText, 
  Building2, 
  Compass, 
  Sparkles, 
  Laptop, 
  Target,
  ArrowRight,
  Shield,
  HelpCircle,
  Stethoscope,
  Cpu,
  Sprout
} from 'lucide-react';

interface EducationAdmissionGuideProps {
  onBackToListings?: () => void;
}

export const EducationAdmissionGuide: React.FC<EducationAdmissionGuideProps> = ({
  onBackToListings
}) => {
  const [activeSection, setActiveSection] = useState<'all' | 'higher_edu' | 'bou' | 'cadet'>('all');

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner / Breadcrumb */}
      <div className="bg-gradient-to-r from-[#1B365D] via-[#24487A] to-[#1E5C46] text-white p-5 sm:p-7 rounded-3xl shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-[#D4E4BC] text-[#1B365D] font-bold text-xs px-3 py-0.5 rounded-full inline-flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5" />
                <span>উচ্চশিক্ষা ও বিশেষ ভর্তি প্রস্তুতি গাইড</span>
              </span>
              <span className="bg-white/20 text-white text-[11px] font-medium px-2.5 py-0.5 rounded-full">
                গ্রাম ও মফস্বলের শিক্ষার্থীদের জন্য সহজ তথ্যভাণ্ডার
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
              উচ্চশিক্ষা, উন্মুক্ত বিশ্ববিদ্যালয় ও ক্যাডেট ভর্তি সহায়িকা
            </h2>
            <p className="text-[#D4E4BC] text-xs sm:text-sm max-w-3xl leading-relaxed">
              বিশ্ববিদ্যালয়, মেডিকেল, উন্মুক্ত বিশ্ববিদ্যালয় এবং ক্যাডেট কলেজের প্রয়োজনীয় ভর্তি যোগ্যতা, পরীক্ষার মানবণ্টন ও ঘরে বসে প্রস্তুতির নির্দেশিকা।
            </p>
          </div>

          {onBackToListings && (
            <button
              onClick={onBackToListings}
              className="self-start sm:self-center px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-2xl text-xs font-bold border border-white/30 transition cursor-pointer flex items-center gap-1.5 shrink-0"
            >
              <span>← টিউটর বিজ্ঞাপনে ফিরুন</span>
            </button>
          )}
        </div>

        {/* Quick Filter Buttons */}
        <div className="pt-2 flex flex-wrap items-center gap-2 text-xs">
          <button
            onClick={() => setActiveSection('all')}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition cursor-pointer ${
              activeSection === 'all' 
                ? 'bg-white text-[#1B365D] shadow-xs' 
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            সকল বিভাগ (৩টি)
          </button>
          <button
            onClick={() => setActiveSection('higher_edu')}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1 ${
              activeSection === 'higher_edu' 
                ? 'bg-white text-[#1B365D] shadow-xs' 
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <span>🏛️ উচ্চ শিক্ষা ও মেডিকেল</span>
          </button>
          <button
            onClick={() => setActiveSection('bou')}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1 ${
              activeSection === 'bou' 
                ? 'bg-white text-[#1B365D] shadow-xs' 
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <span>📖 উন্মুক্ত বিশ্ববিদ্যালয় (BOU)</span>
          </button>
          <button
            onClick={() => setActiveSection('cadet')}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1 ${
              activeSection === 'cadet' 
                ? 'bg-white text-[#1B365D] shadow-xs' 
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <span>🎖️ ক্যাডেট কলেজ ভর্তি</span>
          </button>
        </div>
      </div>

      {/* SECTION 1: Higher Education, University & Medical Admission */}
      {(activeSection === 'all' || activeSection === 'higher_edu') && (
        <section className="bg-white rounded-3xl border border-[#E6E0D4] p-5 sm:p-7 shadow-xs space-y-6">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 pb-4">
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-blue-50 border border-blue-200 text-blue-800 flex items-center justify-center font-bold text-lg shrink-0">
                ১
              </div>
              <div>
                <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full">
                  স্নাতক ও প্রফেশনাল লেভেল
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-[#1B365D] mt-1">
                  উচ্চ শিক্ষা, বিশ্ববিদ্যালয় ও মেডিকেল ভর্তি
                </h3>
                <p className="text-xs text-gray-500">
                  পাবলিক বিশ্ববিদ্যালয়, মেডিকেল কলেজ, বুয়েট ও প্রকৌশল গুচ্ছ, এবং কৃষিগুচ্ছ ভর্তি প্রস্তুতি
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-gray-500 bg-gray-50 px-3 py-1.5 rounded-xl border border-gray-200 shrink-0">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>এইচএসসি পরবর্তী ভর্তি পরীক্ষা</span>
            </div>
          </div>

          {/* Core Content Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* 1.1 Primary Qualifications */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <h4>প্রাথমিক শিক্ষাগত যোগ্যতা</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">মেডিকেল ও ডেন্টাল:</strong> এসএসসি ও এইচএসসি উভয় পরীক্ষায় বিজ্ঞান বিভাগ থেকে উত্তীর্ণ। মোট ন্যূনতম জিপিএ ৯.০০ (উপজাতীয়দের জন্য ৮.০০) এবং এইচএসসি জীববিজ্ঞান পরীক্ষায় ন্যূনতম জিপিএ ৪.০০ (বা ৩.৫০) আবশ্যক।
                </li>
                <li>
                  <strong className="text-gray-900">প্রকৌশল বিশ্ববিদ্যালয় (বুয়েট ও গুচ্ছ):</strong> বিজ্ঞান বিভাগ থেকে ন্যূনতম জিপিএ ৫.০০/৪.৫০ সহ এইচএসসিতে গণিত, পদার্থ ও রসায়ন বিষয়ে নির্ধারিত লেটার গ্রেড।
                </li>
                <li>
                  <strong className="text-gray-900">সাধারণ ও বিজ্ঞান-প্রযুক্তি গুচ্ছ (GST):</strong> বিজ্ঞান, মানবিক ও ব্যবসায় শাখাভিত্তিক আলাদা নূন্যতম জিপিএ (সাধারণত উভয় পরীক্ষায় মোট জিপিএ ৬.৫ থেকে ৮.০ পর্যন্ত)।
                </li>
                <li>
                  <strong className="text-gray-900">কৃষি গুচ্ছ (৭/৮টি বিশ্ববিদ্যালয়):</strong> এসএসসি ও এইচএসসিতে বিজ্ঞান বিভাগসহ নির্ধারিত মোট জিপিএ (সাধারণত ৮.০০ বা ৮.৫)।
                </li>
              </ul>
            </div>

            {/* 1.2 Mark Distribution */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <Target className="w-4 h-4 text-rose-600" />
                <h4>পরীক্ষার মানবণ্টন ও নেগেটিভ মার্কিং</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">মেডিকেল ভর্তি:</strong> ১০০ নম্বরের এমসিকিউ (জীববিজ্ঞান ৩০, রসায়ন ২৫, পদার্থ ১৫, ইংরেজি ১৫, সাধারণ জ্ঞান ১০)। সময় ১ ঘণ্টা। এসএসসি ও এইচএসসি জিপিএ-র উপর আরও ১০০ নম্বর থাকে।
                </li>
                <li>
                  <strong className="text-gray-900">নেগেটিভ মার্কিং:</strong> প্রতিটি ভুল উত্তরের জন্য ০.২৫ নম্বর কাটা যাবে। ৪টি ভুল উত্তরের জন্য ১ নম্বর কর্তন।
                </li>
                <li>
                  <strong className="text-gray-900">সাধারণ বিশ্ববিদ্যালয় (MCQ + Written):</strong> ঢাকা বিশ্ববিদ্যালয় ও প্রধান পাবলিক বিশ্ববিদ্যালয়ে এমসিকিউ (৬০ নম্বর) এবং লিখিত পরীক্ষা (৪০ নম্বর) যৌথভাবে গ্রহণ করা হয়।
                </li>
                <li>
                  <strong className="text-gray-900">প্রকৌশল গুচ্ছ:</strong> গণিত, পদার্থ ও রসায়ন থেকে এমসিকিউ ও লিখিত সংক্ষিপ্ত সমাধান থাকে।
                </li>
              </ul>
            </div>

            {/* 1.3 Home Preparation Tips */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <Laptop className="w-4 h-4 text-blue-600" />
                <h4>ঘরে বসে প্রস্তুতি নেওয়ার সেরা টিপস</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">মূল পাঠ্যবই (Textbook):</strong> কোনো নোটবইয়ের বদলে এনসিটিবি অনুমোদিত মূল বোর্ড বই প্রতিটি লাইন ও কনসেপ্ট বুঝে পড়ুন।
                </li>
                <li>
                  <strong className="text-gray-900">বিগত ১০ বছরের প্রশ্ন ব্যাংক:</strong> যে ইউনিটে পরীক্ষা দেবেন তার বিগত ১০-১৫ বছরের প্রশ্নব্যাংক নিখুঁতভাবে সমাধান করুন।
                </li>
                <li>
                  <strong className="text-gray-900">সময় ধরে ওএমআর (OMR) অনুশীলন:</strong> বাসায় ঘড়ি ধরে ১০০ নম্বরের মডেল টেস্ট প্র্যাকটিস করুন যাতে পরীক্ষার হলে সময়ের ঘাটতি না হয়।
                </li>
                <li>
                  <strong className="text-gray-900">অনলাইন ফ্রি ক্লাস ও রুটিন:</strong> ইউটিউব ও শিক্ষামূলক ফ্রি চ্যানেলে কনসেপ্ট রিভিশন দিন এবং নিজের দুর্বল বিষয়ে বাড়তি সময় বরাদ্দ করুন।
                </li>
              </ul>
            </div>

            {/* 1.4 Application Rules */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <FileText className="w-4 h-4 text-amber-600" />
                <h4>আবেদন করার সাধারণ নিয়মাবলী</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">অনলাইন পোর্টাল:</strong> স্বাস্থ্য শিক্ষা অধিদপ্তর (DGME), জিএসটি গুচ্ছ বা নির্দিষ্ট বিশ্ববিদ্যালয়ের অফিশিয়াল ওয়েবসাইট থেকে আবেদন করতে হয়।
                </li>
                <li>
                  <strong className="text-gray-900">তথ্য প্রদান:</strong> এসএসসি ও এইচএসসির বোর্ড, রোল নম্বর ও রেজিস্ট্রেশন নম্বর দিলে স্বয়ংক্রিয়ভাবে জিপিএ যাচাই হয়।
                </li>
                <li>
                  <strong className="text-gray-900">ছবি ও স্বাক্ষর আপলোড:</strong> ৩০০x৩০০ পিক্সেলের রঙিন ছবি এবং ৩০০x৮০ পিক্সেলের স্ক্যান করা স্বাক্ষর আপলোড করতে হবে।
                </li>
                <li>
                  <strong className="text-gray-900">ফি পরিশোধ:</strong> বিকাশ, নগদ, রকেট বা টেলিটক প্রিপেইড সিমের এসএমএসের মাধ্যমে নির্ধারিত আবেদন ফি প্রদান করতে হয়।
                </li>
              </ul>
            </div>
          </div>

          {/* Quick Sub-Badges */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <span className="inline-flex items-center gap-1 bg-blue-50 text-blue-800 text-[11px] font-semibold px-3 py-1 rounded-full border border-blue-200">
              <Stethoscope className="w-3 h-3" /> মেডিকেল ও ডেন্টাল
            </span>
            <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 text-[11px] font-semibold px-3 py-1 rounded-full border border-emerald-200">
              <Building2 className="w-3 h-3" /> জিএসটি সাধারণ গুচ্ছ
            </span>
            <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 text-[11px] font-semibold px-3 py-1 rounded-full border border-amber-200">
              <Cpu className="w-3 h-3" /> বুয়েট ও ইঞ্জিনিয়ারিং
            </span>
            <span className="inline-flex items-center gap-1 bg-green-50 text-green-800 text-[11px] font-semibold px-3 py-1 rounded-full border border-green-200">
              <Sprout className="w-3 h-3" /> সমন্বিত কৃষি গুচ্ছ
            </span>
          </div>

          {/* Official Website Action Bar */}
          <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#1B365D] shrink-0" />
              <span className="text-xs font-semibold text-gray-700">
                ভর্তি বিজ্ঞপ্তি, সার্কুলার ও রেজাল্ট দেখতে সরাসরি মূল পোর্টালে যান:
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <a
                href="http://dgme.teletalk.com.bd/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#1B365D] hover:bg-[#132742] text-white text-xs font-bold rounded-xl shadow-xs transition"
                title="টেলিটক মেডিকেল ও ডেন্টাল অনলাইন আবেদন ও রেজাল্ট পোর্টাল"
              >
                <Stethoscope className="w-3.5 h-3.5 text-rose-300" />
                <span>মেডিকেল ভর্তি আবেদন (টেলিটক)</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href="http://dgme.gov.bd/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-700 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-xs transition"
                title="স্বাস্থ্য শিক্ষা অধিদপ্তর (ডিজিএমই) সার্কুলার পোর্টাল"
              >
                <span>DGME সার্কুলার সাইট</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://gstadmission.ac.bd/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold rounded-xl shadow-xs transition"
                title="জিএসটি সাধারণ ও বিজ্ঞান প্রযুক্তি গুচ্ছ ওয়েবসাইট"
              >
                <span>জিএসটি গুচ্ছ (GST)</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://acas.edu.bd/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition"
                title="সমন্বিত কৃষি বিশ্ববিদ্যালয় গুচ্ছ"
              >
                <span>কৃষি গুচ্ছ (ACAS)</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://admission.eis.du.ac.bd/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 bg-[#E8924A] hover:bg-[#D97D35] text-white text-xs font-bold rounded-xl shadow-xs transition"
                title="ঢাকা বিশ্ববিদ্যালয় অনলাইন ভর্তি পোর্টাল"
              >
                <span>ঢাকা বিশ্ববিদ্যালয়</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Browser SSL certificate guide tip */}
          <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-3.5 flex items-start gap-2.5 text-xs text-amber-900 leading-relaxed">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">সরকারি সাইট খোলার সময় 'সংযোগ ব্যক্তিগত নয়' (Connection Not Private) দেখালে করণীয়:</span>{' '}
              সরকারি অনেক সাইটে নিজস্ব জাতীয় ডাটা সেন্টার সিকিউরিটি সার্টিফিকেট থাকার কারণে গুগল ক্রোম এমন সতর্কতা দেখাতে পারে। এতে ভয়ের কিছু নেই—স্ক্রিনের নিচে থাকা <strong className="underline">"উন্নত" (Advanced)</strong> লেখায় চাপ দিয়ে <strong className="underline">"Proceed / এগিয়ে যান (অনিরাপদ)"</strong> চাপলে সরকারি মূল পোর্টালটি সঙ্গে সঙ্গে খুলে যাবে।
            </div>
          </div>
        </section>
      )}

      {/* SECTION 2: Bangladesh Open University (BOU) */}
      {(activeSection === 'all' || activeSection === 'bou') && (
        <section className="bg-white rounded-3xl border border-[#E6E0D4] p-5 sm:p-7 shadow-xs space-y-6">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 pb-4">
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center justify-center font-bold text-lg shrink-0">
                ২
              </div>
              <div>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full">
                  দূরশিক্ষণ ও উন্মুক্ত শিক্ষা
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-[#1B365D] mt-1">
                  বাংলাদেশ উন্মুক্ত বিশ্ববিদ্যালয় (BOU) শিক্ষা
                </h3>
                <p className="text-xs text-gray-500">
                  ঝরে পড়া শিক্ষার্থী, প্রবাসী, কর্মজীবী ও গৃহিণীদের জন্য ঘরে বসে শিক্ষার অসাধারণ সুযোগ
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 shrink-0 font-medium">
              <Award className="w-3.5 h-3.5" />
              <span>বয়সের কোনো ঊর্ধ্বসীমা নেই</span>
            </div>
          </div>

          {/* Core Content Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* 2.1 Who Can Study */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <BookOpen className="w-4 h-4 text-emerald-600" />
                <h4>কাদের জন্য উন্মুক্ত বিশ্ববিদ্যালয়?</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">ঝরে পড়া শিক্ষার্থী:</strong> যেকোনো কারণে যাদের নিয়মিত বিদ্যালয়ে পড়ালেখা বন্ধ হয়ে গিয়েছিল, তারা নতুন করে জীবন শুরু করতে পারেন।
                </li>
                <li>
                  <strong className="text-gray-900">কর্মজীবী ও ব্যবসায়ী:</strong> চাকরির পাশাপাশি শুক্র ও শনিবার ছুটি নিয়ে পড়াশোনা চালিয়ে সার্টিফিকেট অর্জন করতে পারবেন।
                </li>
                <li>
                  <strong className="text-gray-900">গৃহিণী ও নারী শিক্ষার্থী:</strong> সংসারের যাবতীয় কাজের পাশাপাশি ঘরে বসে নিজস্ব গতিতে ডিগ্রি লাভ সম্ভব।
                </li>
                <li>
                  <strong className="text-gray-900">জাতীয় ও সরকারি স্বীকৃতি:</strong> উন্মুক্ত বিশ্ববিদ্যালয়ের সার্টিফিকেট অন্যান্য যেকোনো সরকারি সাধারণ বোর্ডের সনদের মতোই শতভাগ মান্য ও সরকারি চাকরিতে গ্রহণযোগ্য।
                </li>
              </ul>
            </div>

            {/* 2.2 Courses & Admission Process */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <FileText className="w-4 h-4 text-blue-600" />
                <h4>কোর্স ও ভর্তি প্রক্রিয়া (এসএসসি, এইচএসসি, বিএ/বিএসএস)</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">প্রধান প্রোগ্রামসমূহ:</strong> উন্মুক্ত এসএসসি (ওপেন স্কুল), এইচএসসি প্রোগ্রাম, ৩ বছর মেয়াদী বিএ/বিএসএস (পাস) কোর্স এবং বিএড/এমএড।
                </li>
                <li>
                  <strong className="text-gray-900">অনলাইন আবেদন (OSAPS):</strong> সরাসরি বাউবি-র অনলাইন পোর্টাল <code className="bg-emerald-100 text-emerald-900 px-1.5 py-0.5 rounded text-xs font-mono">osapsnew.bou.ac.bd</code> এর মাধ্যমে আবেদন করতে হয়।
                </li>
                <li>
                  <strong className="text-gray-900">প্রয়োজনীয় কাগজপত্র:</strong> পূর্ববর্তী পাসের মূল সনদ/মার্কশিট, জাতীয় পরিচয়পত্র বা ডিজিটাল জন্মনিবন্ধন এবং ছবি।
                </li>
                <li>
                  <strong className="text-gray-900">সহজ পেমেন্ট:</strong> বিকাশ, নগদ বা রকেট অ্যাকাউন্টের মাধ্যমে ঘরে বসেই টিউশন ফি জমা দেওয়া যায়।
                </li>
              </ul>
            </div>

            {/* 2.3 Finding Study Centers */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <Building2 className="w-4 h-4 text-amber-600" />
                <h4>স্টাডি সেন্টার (Study Center) খোঁজা ও ক্লাস</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">প্রতিটি উপজেলা ও জেলায় কেন্দ্র:</strong> দেশের প্রায় প্রতিটি জেলা ও উপজেলার স্বনামধন্য সরকারি কলেজ বা উচ্চ বিদ্যালয়ে বাউবি অনুমোদিত স্টাডি সেন্টার রয়েছে।
                </li>
                <li>
                  <strong className="text-gray-900">সাপ্তাহিক টিউটোরিয়াল ক্লাস:</strong> সাধারণ সপ্তাহে কোনো ক্লাস থাকে না; শুধুমাত্র শুক্রবার ও শনিবার ছুটির দিনে সম্মানিত টিউটরদের মাধ্যমে গুরুত্বপূর্ণ বিষয়ের ক্লাস নেওয়া হয়।
                </li>
                <li>
                  <strong className="text-gray-900">বই বিতরণ:</strong> সংশ্লিষ্ট স্টাডি সেন্টার থেকেই সরাসরি সম্পূর্ণ বিনামূল্যে মুদ্রিত পাঠ্যপুস্তক সেট শিক্ষার্থীদের হাতে তুলে দেওয়া হয়।
                </li>
                <li>
                  <strong className="text-gray-900">পরীক্ষা ব্যবস্থা:</strong> একই কেন্দ্রে বা কাছের নির্ধারিত সরকারি কেন্দ্রে চূড়ান্ত বোর্ড পরীক্ষা অনুষ্ঠিত হয়।
                </li>
              </ul>
            </div>

            {/* 2.4 E-books & Media Learning */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <Laptop className="w-4 h-4 text-purple-600" />
                <h4>ই-বুক ও পড়াশোনার বহুমুখী মাধ্যম</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">বাউবি ই-বুক পোর্টাল (e-Book):</strong> ইন্টারনেট থেকে যেকোনো সময় মোবাইল বা কম্পিউটারে সম্পূর্ণ বিনামূল্যে সকল ক্লাসের পাঠ্যবই পিডিএফ ফরম্যাটে ডাউনলোড করা যায়।
                </li>
                <li>
                  <strong className="text-gray-900">টেলিভিশন ও ইউটিউব লেকচার:</strong> সংসদ বাংলাদেশ টেলিভিশন এবং বাউবির নিজস্ব অফিসিয়াল ইউটিউব চ্যানেলে নিয়মিত বিষয়ভিত্তিক ভিডিও লেকচার সম্প্রচারিত হয়।
                </li>
                <li>
                  <strong className="text-gray-900">বাংলাদেশ বেতার ক্লাস:</strong> প্রতিদিন নির্দিষ্ট সময়ে রেডিও/বেতারে শিক্ষামূলক অডিও পাঠ সম্প্রচার করা হয়।
                </li>
                <li>
                  <strong className="text-gray-900">মোবাইল অ্যাপস:</strong> বাউবি-র অ্যাপ ডাউনলোড করে খুব সহজেই ক্লাসের রুটিন ও পরীক্ষার ফলাফল জানা যায়।
                </li>
              </ul>
            </div>
          </div>

          {/* Official Website Action Bar */}
          <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#1B365D] shrink-0" />
              <span className="text-xs font-semibold text-gray-700">
                বাংলাদেশ উন্মুক্ত বিশ্ববিদ্যালয়ের অফিশিয়াল তথ্য ও অনলাইন ভর্তি:
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <a
                href="https://bou.ac.bd/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold rounded-xl shadow-xs transition"
                title="বাউবি অফিসিয়াল প্রধান ওয়েবসাইট"
              >
                <span>বাউবি প্রধান ওয়েবসাইট</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://osapsnew.bou.ac.bd/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#1B365D] hover:bg-[#132742] text-white text-xs font-bold rounded-xl shadow-xs transition"
                title="বাউবি অনলাইন স্টুডেন্ট ভর্তি পোর্টাল (OSAPS)"
              >
                <span>অনলাইন ভর্তি পোর্টাল (OSAPS)</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href="http://ebookbou.edu.bd/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition"
                title="বাউবি সকল পাঠ্যবই ই-বুক লাইব্রেরি"
              >
                <span>ফ্রি ই-বুক লাইব্রেরি</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </section>
      )}

      {/* SECTION 3: Cadet Colleges Admission Preparation */}
      {(activeSection === 'all' || activeSection === 'cadet') && (
        <section className="bg-white rounded-3xl border border-[#E6E0D4] p-5 sm:p-7 shadow-xs space-y-6">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 pb-4">
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-amber-50 border border-amber-200 text-amber-800 flex items-center justify-center font-bold text-lg shrink-0">
                ৩
              </div>
              <div>
                <span className="text-xs font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-full">
                  জাতীয় মেধা ও শৃঙ্খলা
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-[#1B365D] mt-1">
                  ক্যাডেট (সরকারি, সেনা নৌ বিমান) স্কুল ও কলেজ ভর্তি প্রস্তুতি
                </h3>
                <p className="text-xs text-gray-500">
                  দেশের ১২টি ঐতিহ্যবাহী ক্যাডেট কলেজে ৬ষ্ঠ শ্রেণিতে ভর্তির পূর্ণাঙ্গ দিকনির্দেশনা ও সিলেবাস
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-amber-800 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200 shrink-0 font-medium">
              <Shield className="w-3.5 h-3.5 text-amber-700" />
              <span>৬ষ্ঠ শ্রেণিতে ভর্তি পরীক্ষা</span>
            </div>
          </div>

          {/* Core Content Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* 3.1 Age & Physical Requirements */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <h4>শারীরিক ও বয়সভিত্তিক প্রাথমিক যোগ্যতা</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">শিক্ষাগত যোগ্যতা:</strong> প্রার্থীকে ভর্তি বছরের শুরুতে ৫ম শ্রেণি বা সমমানের পরীক্ষায় উত্তীর্ণ হতে হবে।
                </li>
                <li>
                  <strong className="text-gray-900">বয়সসীমা:</strong> ভর্তি বছরের ১ জানুয়ারি তারিখে প্রার্থীর বয়স সর্বোচ্চ ১৩ বছর ০ মাস হতে হবে।
                </li>
                <li>
                  <strong className="text-gray-900">উচ্চতা:</strong> বালক ও বালিকা উভয়ের ক্ষেত্রেই ন্যূনতম ৪ ফুট ৮ ইঞ্চি (৪' ৮") উচ্চতা হতে হবে।
                </li>
                <li>
                  <strong className="text-gray-900">দৃষ্টিশক্তি ও ফিটনেস:</strong> স্বাভাবিক দৃষ্টিশক্তি ৬/৬ (অথবা চশমাসহ অনুমোদিত মাপ) এবং বর্ণান্ধতা (Color Blindness) মুক্ত। যেকোনো জন্মগত বা জটিল রোগমুক্ত হতে হবে।
                </li>
              </ul>
            </div>

            {/* 3.2 Written Exam Syllabus & Marks Distribution */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <Target className="w-4 h-4 text-rose-600" />
                <h4>লিখিত পরীক্ষার বিষয় ও ৩০০ নম্বরের মানবণ্টন</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">ইংরেজি (English - ১০০ নম্বর):</strong> Grammar (Tense, Preposition, Parts of Speech), Comprehension, Spelling, Translation, Paragraph Writing।
                </li>
                <li>
                  <strong className="text-gray-900">গণিত (Mathematics - ১০০ নম্বর):</strong> ৫ম শ্রেণির এনসিটিবি পাঠ্যবই অনুযায়ী পাটিগণিত, বীজগণিতীয় যুক্তি, জ্যামিতি ও সৃজনশীল সমস্যা সমাধান।
                </li>
                <li>
                  <strong className="text-gray-900">বাংলা (Bangla - ৬০ নম্বর):</strong> ব্যাকরণ (সন্ধি, সমাস, কারক, বিপরীত শব্দ), রচনা, ভাবসম্প্রসারণ, চিঠিপত্র ও অনুধাবনমূলক প্রশ্ন।
                </li>
                <li>
                  <strong className="text-gray-900">সাধারণ জ্ঞান ও বুদ্ধিমত্তা (GK & IQ - ৪০ নম্বর):</strong> বাংলাদেশ মুক্তিযুদ্ধ, আন্তর্জাতিক ঘটনাপ্রবাহ, সাধারণ বিজ্ঞান ও চিত্রভিত্তিক আইকিউ টেস্ট।
                </li>
              </ul>
            </div>

            {/* 3.3 Home & Class Prep Tips */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <h4>প্রাথমিক গাইডলাইন ও সফল প্রস্তুতির কৌশল</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">বোর্ড বইয়ের খুঁটিনাটি:</strong> ৫ম শ্রেণির গণিত ও বাংলা পাঠ্যবইয়ের প্রতিটি অধ্যায়ের অনুশীলনী হাতে-কলমে নিজে নিজে সমাধান করার অভ্যাস গড়ে তুলুন।
                </li>
                <li>
                  <strong className="text-gray-900">ইংরেজিতে ফ্রি হ্যান্ড রাইটিং:</strong> প্রতিদিন যেকোনো বিষয় নিয়ে ইংরেজিতে ৪-৫টি সঠিক বাক্য লেখার চর্চা ও প্রচুর ভোকাবুলারি আয়ত্ত করা।
                </li>
                <li>
                  <strong className="text-gray-900">দ্রুত ও পরিষ্কার লেখার অভ্যাস:</strong> ৩ ঘণ্টায় ৩০০ নম্বরের উত্তর দিতে হয়, তাই হাতের লেখা পরিষ্কার রেখে দ্রুত লেখার নিয়মিত স্পিড প্র্যাকটিস জরুরি।
                </li>
                <li>
                  <strong className="text-gray-900">স্বাস্থ্য ও খেলাধুলা:</strong> শিশুকে প্রতিদিন বিকেলে দৌড়াদৌড়ি ও সাঁতারসহ শারীরিক কসরত করান যাতে ওজন নিয়ন্ত্রণে থাকে ও আত্মবিশ্বাস বাড়ে।
                </li>
              </ul>
            </div>

            {/* 3.4 Selection Phases */}
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#E8E2D5] space-y-3">
              <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
                <Shield className="w-4 h-4 text-amber-600" />
                <h4>ভর্তি নির্বাচনের ৩টি ধাপ</h4>
              </div>
              <ul className="text-xs sm:text-[13px] text-gray-700 space-y-2 leading-relaxed list-disc list-inside">
                <li>
                  <strong className="text-gray-900">ধাপ ১: লিখিত পরীক্ষা:</strong> সাধারণত ডিসেম্বরের শেষে বা জানুয়ারির শুরুতে দেশব্যাপী একযোগে ৩০০ নম্বরের লিখিত পরীক্ষা অনুষ্ঠিত হয়।
                </li>
                <li>
                  <strong className="text-gray-900">ধাপ ২: মৌখিক ও বুদ্ধিমত্তা পরীক্ষা:</strong> লিখিত পরীক্ষায় উত্তীর্ণদের জন্য ভাইভা ও আইকিউ টেস্ট গ্রহণ করা হয়।
                </li>
                <li>
                  <strong className="text-gray-900">ধাপ ৩: স্বাস্থ্য পরীক্ষা (Medical Checkup):</strong> চূড়ান্তভাবে মেধার ভিত্তিতে নির্বাচিত প্রার্থীদের নিখুঁত মেডিকেল পরীক্ষার মাধ্যমে ক্যাডেট কলেজে ভর্তি নিশ্চিত করা হয়।
                </li>
              </ul>
            </div>
          </div>

          {/* Official Website Action Bar */}
          <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#1B365D] shrink-0" />
              <span className="text-xs font-semibold text-gray-700">
                ক্যাডেট কলেজের অফিসিয়াল সার্কুলার ও অনলাইন আবেদন পোর্টাল:
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <a
                href="https://cadetcollegeadmission.army.mil.bd/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#1B365D] hover:bg-[#132742] text-white text-xs font-bold rounded-xl shadow-xs transition"
                title="ক্যাডেট কলেজ অনলাইন ভর্তি আবেদন পোর্টাল"
              >
                <span>ক্যাডেট কলেজ ভর্তি পোর্টাল</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://cadetcollege.army.mil.bd/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold rounded-xl shadow-xs transition"
                title="বাংলাদেশ সেনাবাহিনী ক্যাডেট কলেজ প্রধান ওয়েবসাইট"
              >
                <span>ক্যাডেট কলেজ প্রধান ওয়েবসাইট</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </section>
      )}

      {/* MANDATORY DISCLAIMER AS REQUESTED BY USER */}
      <div className="bg-amber-50/90 border border-amber-200/90 rounded-2xl p-4 sm:p-5 shadow-2xs text-[#78350F] flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-1 text-xs sm:text-sm leading-relaxed">
          <p className="font-bold text-amber-900">
            বিশেষ দ্রষ্টব্য:
          </p>
          <p>
            এখানে উল্লিখিত তথ্যসমূহ শিক্ষার্থীদের প্রাথমিক ধারণার জন্য সংগৃহীত। জিপিএ, বয়স ও ভর্তির নিয়মাবলী বছর ভেদে পরিবর্তন হতে পারে। সর্বশেষ ও নির্ভুল তথ্যের জন্য সংশ্লিষ্ট প্রতিষ্ঠানের অফিশিয়াল ওয়েবসাইট ভিজিট করুন।
          </p>
        </div>
      </div>
    </div>
  );
};
