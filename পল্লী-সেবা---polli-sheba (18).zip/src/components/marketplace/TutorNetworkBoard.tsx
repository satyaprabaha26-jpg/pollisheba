import React, { useState, useMemo } from 'react';
import { 
  GraduationCap, 
  BookOpen, 
  Search, 
  MapPin, 
  PhoneCall, 
  MessageCircle, 
  PlusCircle, 
  UserCheck, 
  CheckCircle2, 
  Calendar, 
  Users, 
  Award, 
  Sparkles, 
  Clock, 
  X, 
  Briefcase,
  AlertCircle,
  HelpCircle,
  ShieldCheck,
  Check,
  Bell,
  Trash2,
  ArrowRight
} from 'lucide-react';
import { HaatListing } from '../../types';
import { UserProfile, getUserFormDefaults } from '../../types/auth';
import { formatTaka } from '../../utils/banglaNumbers';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';
import { ChatModal } from '../chat/ChatModal';
import { CallChoiceModal } from '../transport/CallChoiceModal';
import { InAppVoiceCallModal } from '../transport/InAppVoiceCallModal';
import { maskPhoneNumber } from '../transport/RuralTransport';
import { saveCloudHaatItem, deleteCloudHaatItem, broadcastLocalizedDemandNotification, subscribeToRegisteredUsers } from '../../lib/cloudSync';
import { EducationAdmissionGuide } from './EducationAdmissionGuide';
import { convertRegisteredUserToTutorListing, cleanDistrictName, cleanUpazilaName, cleanUnionName } from '../../utils/tutorHelpers';

interface TutorNetworkBoardProps {
  currentDistrict: string;
  currentUser?: UserProfile | null;
  onOpenAuth?: (action?: string) => void;
  listings: HaatListing[];
  onAddListing: (listing: HaatListing) => void;
  onDeleteListing?: (id: string) => void;
  onToggleStatus?: (id: string) => void;
}

const CLASS_CATEGORIES = [
  'সকল শ্রেণি',
  '১ম - ৫ম শ্রেণি (প্রাথমিক)',
  '৬ষ্ঠ - ৮ম শ্রেণি (জেএসসি)',
  '৯ম - ১০ম শ্রেণি (এসএসসি)',
  'একাদশ - দ্বাদশ (এইচএসসি)',
  'মাদরাসা ও হিফজ',
  'ইংরেজি / গণিত বিশেষ'
];

export const TutorNetworkBoard: React.FC<TutorNetworkBoardProps> = ({
  currentDistrict,
  currentUser,
  onOpenAuth,
  listings,
  onAddListing,
  onDeleteListing,
  onToggleStatus
}) => {
  const [subTab, setSubTab] = useState<'all' | 'tutors' | 'students' | 'admission_guide'>('all');
  const [statusFilter, setStatusFilter] = useState<'active' | 'completed' | 'all'>('active');
  const [selectedClass, setSelectedClass] = useState<string>('সকল শ্রেণি');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterAddress, setFilterAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : '',
    upazila: '',
    union: '',
    village: ''
  });

  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [formType, setFormType] = useState<'tutor_avail' | 'tutor_need'>('tutor_avail');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [targetClasses, setTargetClasses] = useState('৬ষ্ঠ - ১০ম শ্রেণি (এসএসসি)');
  const [subjects, setSubjects] = useState('');
  const [qualification, setQualification] = useState('');
  const [teachingDays, setTeachingDays] = useState('সপ্তাহে ৩ দিন (১.৫ ঘণ্টা)');
  const [medium, setMedium] = useState('বাংলা মাধ্যম');
  const [price, setPrice] = useState('');
  const [isNegotiable, setIsNegotiable] = useState(true);
  const [hideVillage, setHideVillage] = useState(true);
  const [allowOfflineCall, setAllowOfflineCall] = useState<boolean>(false);
  const [description, setDescription] = useState('');
  const [notificationScope, setNotificationScope] = useState<'upazila' | 'district'>('district');
  const [formAddress, setFormAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : 'বগুড়া',
    upazila: '',
    union: '',
    village: ''
  });

  const populateDefaults = () => {
    const defaults = getUserFormDefaults(currentUser);
    if (defaults.name) setName(defaults.name);
    if (defaults.phone) setPhone(defaults.phone);
    if (defaults.district && defaults.district !== 'সকল জেলা') {
      setFormAddress(prev => ({
        ...prev,
        district: defaults.district,
        upazila: defaults.upazila || prev.upazila,
        union: defaults.union || prev.union,
        village: defaults.village || prev.village
      }));
    } else if (currentDistrict !== 'সকল জেলা') {
      setFormAddress(prev => ({ ...prev, district: currentDistrict }));
    }
    setAllowOfflineCall(defaults.allowOfflineCall);
    setHideVillage(defaults.hideVillage);
  };

  React.useEffect(() => {
    populateDefaults();
  }, [currentUser, currentDistrict]);

  // Call & Chat States
  const [activeChatListing, setActiveChatListing] = useState<HaatListing | null>(null);
  const [activeCallingItem, setActiveCallingItem] = useState<HaatListing | null>(null);
  const [inAppVoiceItem, setInAppVoiceItem] = useState<HaatListing | null>(null);
  const [registeredTutors, setRegisteredTutors] = useState<HaatListing[]>([]);

  // Load and subscribe to registered teachers from Firestore / local storage
  React.useEffect(() => {
    const isTeacherUser = (u: UserProfile) => {
      if (u.role === 'tutor_student') {
        // If explicitly registered as student_parent, they are a student/guardian, not a teacher
        return !u.tutorInfo || u.tutorInfo.tutorType !== 'student_parent';
      }
      return (u as any).role === 'teacher' || u.tutorInfo?.tutorType === 'teacher';
    };

    try {
      const local = localStorage.getItem('polli_all_registered_users');
      if (local) {
        const users: UserProfile[] = JSON.parse(local);
        const tutors = users
          .filter(isTeacherUser)
          .map(convertRegisteredUserToTutorListing);
        setRegisteredTutors(tutors);
      }
    } catch (e) {
      console.warn('Error reading registered users for tutor board:', e);
    }

    const unsubscribe = subscribeToRegisteredUsers((users) => {
      const tutors = users
        .filter(isTeacherUser)
        .map(convertRegisteredUserToTutorListing);
      setRegisteredTutors(tutors);
    });

    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, []);

  // Filter Tutor Listings (including both haat listings and registered tutors)
  const tutorListings = useMemo(() => {
    // Combine regular listings with registered tutors
    const combined: HaatListing[] = [...listings];
    for (const reg of registeredTutors) {
      const cleanPhone = reg.phone ? reg.phone.replace(/\D/g, '') : '';
      const exists = combined.some(it => 
        it.id === reg.id || 
        (it.phone && cleanPhone && it.phone.replace(/\D/g, '') === cleanPhone)
      );
      if (!exists) {
        combined.unshift(reg);
      }
    }

    return combined.filter(item => {
      const isTutorCategory = 
        item.category === 'গৃহশিক্ষক ও শিক্ষার্থী' || 
        item.itemType === 'গৃহশিক্ষক' || 
        item.itemType === 'শিক্ষার্থী' ||
        !!item.tutorType;

      if (!isTutorCategory) return false;

      // Status Filter: active vs completed
      const isCompletedOrSold = !!(item.isSold || item.isCompleted);
      if (statusFilter === 'active' && isCompletedOrSold) {
        return false;
      }
      if (statusFilter === 'completed' && !isCompletedOrSold) {
        return false;
      }

      // Sub-tab filter
      if (subTab === 'tutors' && (item.tutorType === 'tutor_need' || item.itemType === 'শিক্ষার্থী')) {
        return false;
      }
      if (subTab === 'students' && (item.tutorType === 'tutor_avail' || item.itemType === 'গৃহশিক্ষক')) {
        return false;
      }

      // Class category filter
      if (selectedClass !== 'সকল শ্রেণি') {
        const queryClass = selectedClass.split(' ')[0];
        const match = 
          (item.targetClasses && item.targetClasses.includes(queryClass)) ||
          (item.title && item.title.includes(queryClass)) ||
          (item.description && item.description.includes(queryClass));
        if (!match) return false;
      }

      // Location hierarchy filters (Cleaned & Normalized)
      if (filterAddress.district && filterAddress.district !== 'সকল জেলা') {
        const fDist = cleanDistrictName(filterAddress.district).toLowerCase();
        const iDist = cleanDistrictName(item.district).toLowerCase();
        const iLoc = (item.location || '').toLowerCase();
        if (fDist !== iDist && !iDist.includes(fDist) && !iLoc.includes(fDist)) {
          return false;
        }
      }

      if (filterAddress.upazila && filterAddress.upazila !== 'সকল উপজেলা') {
        const fUpz = cleanUpazilaName(filterAddress.upazila).toLowerCase();
        const iUpz = cleanUpazilaName(item.upazila).toLowerCase();
        const iLoc = (item.location || '').toLowerCase();
        if (!iUpz.includes(fUpz) && !fUpz.includes(iUpz) && !iLoc.includes(fUpz)) {
          return false;
        }
      }

      if (filterAddress.union && filterAddress.union !== 'সকল ইউনিয়ন') {
        const fUnion = cleanUnionName(filterAddress.union).toLowerCase();
        const iUnion = cleanUnionName(item.unionOrWard).toLowerCase();
        const iLoc = (item.location || '').toLowerCase();
        if (!iUnion.includes(fUnion) && !fUnion.includes(iUnion) && !iLoc.includes(fUnion)) {
          return false;
        }
      }

      if (filterAddress.village && filterAddress.village.trim()) {
        const vq = filterAddress.village.toLowerCase().trim();
        const itemV = (item.village || '').toLowerCase();
        const itemLoc = (item.location || '').toLowerCase();
        if (!itemV.includes(vq) && !itemLoc.includes(vq)) return false;
      }

      // Search Query
      if (searchQuery.trim()) {
        const sq = searchQuery.toLowerCase().trim();
        const matchTitle = item.title.toLowerCase().includes(sq);
        const matchSeller = item.sellerName.toLowerCase().includes(sq);
        const matchSubjects = (item.subjects || '').toLowerCase().includes(sq);
        const matchQual = (item.qualification || '').toLowerCase().includes(sq);
        const matchDesc = (item.description || '').toLowerCase().includes(sq);
        const matchLoc = (item.location || '').toLowerCase().includes(sq);
        if (!matchTitle && !matchSeller && !matchSubjects && !matchQual && !matchDesc && !matchLoc) {
          return false;
        }
      }

      return true;
    });
  }, [listings, registeredTutors, subTab, statusFilter, selectedClass, filterAddress, searchQuery]);

  const studentPostsCount = useMemo(() => {
    return tutorListings.filter(it => it.tutorType === 'tutor_need' || it.itemType === 'শিক্ষার্থী').length;
  }, [tutorListings]);

  const registeredTeachersCount = useMemo(() => {
    return tutorListings.filter(it => it.tutorType === 'tutor_avail' || it.itemType === 'গৃহশিক্ষক').length;
  }, [tutorListings]);

  const isRegisteredTeacher = useMemo(() => {
    if (!currentUser) return false;
    if (currentUser.role === 'tutor_student') {
      return !currentUser.tutorInfo || currentUser.tutorInfo.tutorType !== 'student_parent';
    }
    return (currentUser as any).role === 'teacher' || currentUser.tutorInfo?.tutorType === 'teacher';
  }, [currentUser]);

  const handleSubmitListing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !name.trim() || !phone.trim() || !formAddress.district) {
      alert('দয়া করে শিরোনাম, আপনার নাম, মোবাইল নম্বর এবং জেলা পূরণ করুন।');
      return;
    }

    const compiledLocation = [
      formAddress.village && !hideVillage ? `গ্রাম: ${formAddress.village}` : '',
      formAddress.union ? formAddress.union : '',
      formAddress.upazila ? `উপজেলা: ${formAddress.upazila}` : '',
      formAddress.district ? `${formAddress.district} জেলা` : ''
    ].filter(Boolean).join(', ') || `${formAddress.district} জেলা`;

    const now = Date.now();
    const isAvail = formType === 'tutor_avail';

    const newListing: HaatListing = {
      id: `haat-tutor-${now}`,
      title: title.trim(),
      category: 'গৃহশিক্ষক ও শিক্ষার্থী',
      itemType: isAvail ? 'গৃহশিক্ষক' : 'শিক্ষার্থী',
      price: parseFloat(price) || 0,
      unit: 'টাকা / মাসিক',
      sellerName: name.trim(),
      sellerRole: isAvail ? 'teacher' : 'citizen',
      sellerId: currentUser?.id,
      phone: phone.trim(),
      location: compiledLocation,
      district: formAddress.district,
      upazila: formAddress.upazila || undefined,
      unionOrWard: formAddress.union || undefined,
      village: formAddress.village || undefined,
      hideVillage,
      allowOfflineCall,
      description: description.trim(),
      createdAt: 'এইমাত্র প্রকাশিত',
      createdAtTimestamp: now,
      isNegotiable,
      isPerishable: false,
      expiryDays: 30,
      expiryDateTimestamp: now + 30 * 24 * 60 * 60 * 1000,
      isSold: false,
      tutorType: formType,
      targetClasses,
      subjects: subjects.trim(),
      qualification: qualification.trim(),
      teachingDays,
      medium
    };

    onAddListing(newListing);
    saveCloudHaatItem(newListing);

    // Auto localized notification broadcast
    if (isAvail) {
      // Teacher posting: Notify students/guardians/citizens in that area
      broadcastLocalizedDemandNotification({
        id: newListing.id,
        title: newListing.title,
        category: 'শিক্ষক পড়াতে চাই',
        scope: notificationScope,
        district: formAddress.district,
        upazila: formAddress.upazila,
        union: formAddress.unionOrWard,
        sellerName: name.trim(),
        phone: phone.trim(),
        targetRole: 'all', // Reaches parents, students and citizens in this locality
        targetCategory: 'marketplace',
        targetSubTab: { market: 'tutors' }
      });

      setToastMessage(
        `পড়াতে চাই শিক্ষক বিজ্ঞাপন সফলভাবে প্রকাশিত হয়েছে! (${notificationScope === 'upazila' && formAddress.upazila ? `${formAddress.upazila} উপজেলার` : `${formAddress.district} জেলার`} সকল শিক্ষার্থী ও অভিভাবকদের কাছে নোটিফিকেশন পৌঁছে দেওয়া হয়েছে)`
      );
      setSubTab('tutors');
    } else {
      // Student/Parent posting: Specifically alerts registered tutors in that area
      broadcastLocalizedDemandNotification({
        id: newListing.id,
        title: newListing.title,
        category: 'গৃহশিক্ষক আবশ্যক',
        scope: notificationScope,
        district: formAddress.district,
        upazila: formAddress.upazila,
        union: formAddress.unionOrWard,
        sellerName: name.trim(),
        phone: phone.trim(),
        targetRole: 'tutor', // Alerts registered teachers in this upazila/district
        targetCategory: 'marketplace',
        targetSubTab: { market: 'tutors' }
      });

      setToastMessage(
        `গৃহশিক্ষক আবশ্যক পোস্ট সফলভাবে প্রকাশিত হয়েছে! (${notificationScope === 'upazila' && formAddress.upazila ? `${formAddress.upazila} উপজেলার` : `${formAddress.district} জেলার`} সকল নিবন্ধিত শিক্ষকের কাছে নোটিফিকেশন পৌঁছে দেওয়া হয়েছে)`
      );
      setSubTab('students');
    }

    setTimeout(() => setToastMessage(null), 6000);

    // Reset Form
    setTitle('');
    setDescription('');
    setSubjects('');
    setQualification('');
    setPrice('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Sub-Tab Navigation Bar - Always available for fast switching between listings and admission guide */}
      <div className="bg-white p-3.5 sm:p-4 rounded-3xl border border-[#E6E0D4] shadow-2xs">
        <div className="flex bg-[#FAF8F5] p-1 rounded-2xl border border-[#E6E0D4] text-xs overflow-x-auto gap-1">
          <button
            onClick={() => {
              setSubTab('all');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-3.5 sm:px-4 py-2 rounded-xl font-bold transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              subTab === 'all' ? 'bg-[#1B365D] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
            }`}
          >
            <span>🌟 সকল বিজ্ঞাপন ও চাহিদা ({tutorListings.length})</span>
          </button>
          <button
            onClick={() => {
              setSubTab('tutors');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-3.5 sm:px-4 py-2 rounded-xl font-bold transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              subTab === 'tutors' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>👨‍🏫 শিক্ষক পড়াতে চাই ({registeredTeachersCount})</span>
          </button>
          <button
            onClick={() => {
              setSubTab('students');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-3.5 sm:px-4 py-2 rounded-xl font-bold transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              subTab === 'students' ? 'bg-[#E8924A] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>📖 শিক্ষক প্রয়োজন পোস্ট ({studentPostsCount})</span>
          </button>
          <button
            onClick={() => {
              setSubTab('admission_guide');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-3.5 sm:px-4 py-2 rounded-xl font-bold transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              subTab === 'admission_guide' ? 'bg-[#1B365D] text-white shadow-xs ring-2 ring-amber-400' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
            }`}
          >
            <span className="text-amber-300">🎓</span>
            <span>ভর্তি গাইড (উচ্চশিক্ষা ও উন্মুক্ত)</span>
          </button>
        </div>
      </div>

      {subTab === 'admission_guide' ? (
        /* ADMISSION GUIDE VIEW */
        <EducationAdmissionGuide 
          onBackToListings={() => {
            setSubTab('all');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }} 
        />
      ) : (
        /* TUTOR & STUDENT MARKETPLACE VIEW */
        <>
          {/* Hero Banner */}
          <div className="bg-gradient-to-r from-[#1B365D] via-[#2A4D69] to-[#1B4332] text-white p-6 rounded-3xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-5">
            <div className="space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="bg-[#D4E4BC] text-[#1B365D] font-bold text-xs px-3 py-0.5 rounded-full inline-flex items-center gap-1">
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>গৃহশিক্ষক ও শিক্ষার্থী সংযোগ নেটওয়ার্ক</span>
                </span>
                <span className="bg-white/20 text-white text-[11px] font-semibold px-2.5 py-0.5 rounded-full">
                  📚 দালালমুক্ত সরাসরি শিক্ষক ও অভিভাবক সংযোগ
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold">
                এলাকাভিত্তিক গৃহশিক্ষক ও শিক্ষার্থী বোর্ড
              </h2>
              <p className="text-[#D4E4BC] text-xs sm:text-sm max-w-2xl leading-relaxed">
                এলাকার শিক্ষিত ভাই-বোনেরা টিউশনি পেতে বিনামূল্যে 'পড়াতে চাই' বিজ্ঞাপন দিন, এবং অভিভাবক ও শিক্ষার্থীরা সরাসরি 'শিক্ষক প্রয়োজন' পোস্ট করুন। পোস্ট হওয়ার সাথে সাথেই স্বয়ংক্রিয় স্থানীয় নোটিফিকেশন পৌঁছে যাবে।
              </p>
              <div className="pt-2">
                <button
                  onClick={() => {
                    setSubTab('admission_guide');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-full text-xs sm:text-sm font-bold border border-white/30 transition cursor-pointer shadow-xs active:scale-95"
                >
                  <GraduationCap className="w-4 h-4 text-amber-300" />
                  <span>উচ্চশিক্ষা, উন্মুক্ত বিশ্ববিদ্যালয় ও ক্যাডেট ভর্তি গাইড দেখুন ➔</span>
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
              <button
                onClick={() => {
                  if (!currentUser) {
                    onOpenAuth?.('শিক্ষক হিসেবে পড়াতে চাই বিজ্ঞাপন প্রকাশ করতে অনুগ্রহ করে লগইন বা নিবন্ধন করুন');
                    return;
                  }
                  setFormType('tutor_avail');
                  setShowAddModal(true);
                }}
                className="flex items-center justify-center gap-2 bg-[#2D5A27] hover:bg-[#24481f] text-white font-bold px-4 py-3 rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer whitespace-nowrap"
              >
                <GraduationCap className="w-4 h-4 text-[#D4E4BC]" />
                <span>👨‍🏫 শিক্ষক পড়াতে চাই (বিজ্ঞাপন)</span>
              </button>

              <button
                onClick={() => {
                  if (!currentUser) {
                    onOpenAuth?.('শিক্ষক প্রয়োজন পোস্ট করতে অনুগ্রহ করে লগইন বা নিবন্ধন করুন');
                    return;
                  }
                  setFormType('tutor_need');
                  setShowAddModal(true);
                }}
                className="flex items-center justify-center gap-2 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold px-5 py-3 rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer whitespace-nowrap"
              >
                <PlusCircle className="w-4 h-4" />
                <span>📖 শিক্ষক প্রয়োজন (পোস্ট)</span>
              </button>
            </div>
          </div>

          {/* Helpful Guidance Banner */}
          <div className="bg-[#FFFBEB] border border-amber-200 p-4 rounded-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-2xs">
            <div className="flex items-start sm:items-center gap-2.5">
              <span className="text-2xl shrink-0">💡</span>
              <div className="text-amber-950 leading-relaxed">
                <strong>উভয় পক্ষের জন্য উন্মুক্ত সুযোগ:</strong> শিক্ষিত তরুণ-তরুণী বা অভিজ্ঞ শিক্ষকেরা টিউশনি পেতে নির্দ্বিধায় <strong>'পড়াতে চাই'</strong> বিজ্ঞাপন প্রকাশ করতে পারবেন (এলাকার অভিভাবকেরা তাৎক্ষণিক নোটিফিকেশন পাবেন)। আবার অভিভাবক বা শিক্ষার্থীরাও সহজেই <strong>'শিক্ষক প্রয়োজন'</strong> পোস্ট দিতে পারবেন (শিক্ষকেরা নোটিফিকেশন পাবেন)।
              </div>
            </div>
            {!currentUser && (
              <button
                onClick={() => onOpenAuth?.('টিউশন পেতে বা শিক্ষক খুঁজতে লগইন বা নিবন্ধন করুন')}
                className="inline-flex items-center justify-center gap-1.5 bg-[#1B365D] hover:bg-[#132742] text-white font-bold px-3.5 py-1.5 rounded-xl text-xs shrink-0 transition cursor-pointer self-start sm:self-auto"
              >
                <span>লগইন / নিবন্ধন</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Toast Alert */}
          {toastMessage && (
            <div className="p-3.5 bg-[#E8F8F5] border border-[#27AE60]/40 text-[#27AE60] text-xs sm:text-sm font-bold rounded-2xl flex items-center gap-2 shadow-xs animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{toastMessage}</span>
            </div>
          )}

          {/* Filters: Status, Quick Search, Class Chips, Cascading Address */}
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-[#E6E0D4] space-y-4 shadow-2xs">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              {/* Status Filter: Active vs Completed vs All */}
              <div className="flex items-center gap-2">
                <div className="flex bg-[#FAF8F5] p-1 rounded-2xl border border-[#E6E0D4] text-xs shrink-0">
                  <button
                    onClick={() => setStatusFilter('active')}
                    className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                      statusFilter === 'active' ? 'bg-[#2D5A27] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                    }`}
                    title="বর্তমানে শিক্ষক বা শিক্ষার্থী খুঁজছেন এমন সক্রিয় তালিকা"
                  >
                    🟢 শুধু সক্রিয়
                  </button>
                  <button
                    onClick={() => setStatusFilter('completed')}
                    className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                      statusFilter === 'completed' ? 'bg-[#1B365D] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                    }`}
                    title="শিক্ষক বা শিক্ষার্থী পাওয়া গেছে (সম্পন্ন/হাইড)"
                  >
                    ✅ সম্পন্ন
                  </button>
                  <button
                    onClick={() => setStatusFilter('all')}
                    className={`px-2.5 py-1.5 rounded-xl font-bold transition cursor-pointer whitespace-nowrap ${
                      statusFilter === 'all' ? 'bg-[#5A6B6B] text-white shadow-2xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                    }`}
                  >
                    সকল
                  </button>
                </div>
              </div>

              {/* Quick Search */}
              <div className="relative flex-1 sm:w-64">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#736B5E]" />
                <input
                  type="text"
                  placeholder="বিষয় বা শ্রেণি খুঁজুন..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-2xl pl-9 pr-8 py-2 text-xs focus:outline-none focus:border-[#1B365D]"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#736B5E] hover:text-[#2D3A3A] p-0.5 cursor-pointer"
                    title="সার্চ মুছুন"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Class Filter Chips */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
              <span className="text-[11px] font-bold text-[#5A6B6B] whitespace-nowrap">শ্রেণি ফিল্টার:</span>
              {CLASS_CATEGORIES.map(cls => (
                <button
                  key={cls}
                  onClick={() => setSelectedClass(cls)}
                  className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer ${
                    selectedClass === cls
                      ? 'bg-[#1B365D] text-white shadow-2xs'
                      : 'bg-[#FAF8F5] text-[#5A6B6B] hover:bg-[#F3EED9] border border-[#E6E0D4]'
                  }`}
                >
                  {cls}
                </button>
              ))}
            </div>

            {/* Cascading Address Hierarchy Selector */}
            <div className="pt-2 border-t border-[#E6E0D4]">
              <div className="text-xs font-bold text-[#2D3A3A] mb-2 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#1B365D]" />
                <span>এলাকা নির্বাচন করুন (জেলা ➔ উপজেলা ➔ ইউনিয়ন):</span>
              </div>
              <CascadingAddressSelector
                address={filterAddress}
                onChange={(newAddr) => setFilterAddress(newAddr)}
                showVillage={true}
                allowAllOption={true}
                villagePlaceholder="গ্রাম বা পাড়ার নাম (ঐচ্ছিক)"
              />
            </div>
          </div>

      {/* Tutor Listings Grid */}
      {tutorListings.length === 0 ? (
        <div className="bg-white p-8 sm:p-12 rounded-3xl border border-[#E6E0D4] text-center space-y-4 shadow-2xs">
          <div className="w-16 h-16 bg-[#FAF8F5] rounded-full flex items-center justify-center mx-auto text-[#736B5E] border border-[#E6E0D4]">
            {searchQuery.trim() ? <Search className="w-7 h-7 text-[#E8924A]" /> : <BookOpen className="w-7 h-7 text-[#1B365D]" />}
          </div>
          
          <div className="space-y-1.5">
            <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A]">
              {searchQuery.trim() 
                ? `"${searchQuery}" সম্পর্কিত কোনো ফলাফল পাওয়া যায়নি` 
                : 'কোনো শিক্ষক বা শিক্ষার্থী বিজ্ঞপ্তি পাওয়া যায়নি'}
            </h3>
            <p className="text-xs sm:text-sm text-[#5A6B6B] max-w-lg mx-auto leading-relaxed">
              {searchQuery.trim() 
                ? `পরামর্শ: "${searchQuery}" বিষয়ে এই এলাকায় এখনও কোনো বিজ্ঞপ্তি পোস্ট করা হয়নি। আপনি কি "${searchQuery}" বিষয়ে পড়াতে চান, কিংবা কোনো অভিজ্ঞ শিক্ষক খুঁজছেন? নিচের বাটনে চাপ দিয়ে সরাসরি আপনার বিজ্ঞাপন প্রকাশ করুন!`
                : 'আপনার নির্বাচিত ফিল্টার বা এলাকার জন্য কোনো সক্রিয় বিজ্ঞপ্তি পাওয়া যায়নি। আপনি নিজেই প্রথম বিজ্ঞাপন পোস্ট করুন!'}
            </p>
          </div>

          <div className="pt-2 flex flex-wrap justify-center items-center gap-2.5">
            <button
              onClick={() => {
                if (!currentUser) {
                  onOpenAuth?.('শিক্ষক হিসেবে বিজ্ঞাপন দিতে অনুগ্রহ করে লগইন বা নিবন্ধন করুন');
                  return;
                }
                if (searchQuery.trim()) {
                  setTitle(`শিক্ষক পড়াতে চাই: ${searchQuery.trim()}`);
                }
                setFormType('tutor_avail');
                setShowAddModal(true);
              }}
              className="px-4 py-2.5 bg-[#1B365D] hover:bg-[#132742] text-white text-xs font-bold rounded-2xl shadow-xs transition cursor-pointer"
            >
              👨‍🏫 শিক্ষক পড়াতে চাই
            </button>
            <button
              onClick={() => {
                if (!currentUser) {
                  onOpenAuth?.('শিক্ষক খুঁজতে বিজ্ঞাপন দিতে অনুগ্রহ করে লগইন বা নিবন্ধন করুন');
                  return;
                }
                if (searchQuery.trim()) {
                  setTitle(`ছাত্র-ছাত্রী পড়তে চাই: ${searchQuery.trim()} শিক্ষক আবশ্যক`);
                }
                setFormType('tutor_need');
                setShowAddModal(true);
              }}
              className="px-4 py-2.5 bg-[#E8924A] hover:bg-[#D97D35] text-white text-xs font-bold rounded-2xl shadow-xs transition cursor-pointer"
            >
              📖 ছাত্র-ছাত্রী / অভিভাবক পড়তে চাই
            </button>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="px-4 py-2.5 bg-[#FAF8F5] border border-[#D4C3A3] text-[#2D3A3A] hover:bg-[#E6E0D4] text-xs font-bold rounded-2xl transition cursor-pointer"
              >
                🔄 সকল বিজ্ঞপ্তি দেখুন
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tutorListings.map(item => {
            const isOfferingTutor = item.tutorType === 'tutor_avail' || item.itemType === 'গৃহশিক্ষক';
            return (
              <div 
                key={item.id}
                className="bg-white rounded-3xl border border-[#E6E0D4] p-5 shadow-2xs hover:shadow-md transition flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Badge & Mode */}
                  <div className="flex items-center justify-between gap-2">
                    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
                      isOfferingTutor 
                        ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' 
                        : 'bg-amber-50 text-amber-900 border border-amber-200'
                    }`}>
                      {isOfferingTutor ? (
                        <>
                          <GraduationCap className="w-3.5 h-3.5 text-emerald-700" />
                          <span>👨‍🏫 পড়াতে চান (শিক্ষক)</span>
                        </>
                      ) : (
                        <>
                          <BookOpen className="w-3.5 h-3.5 text-amber-700" />
                          <span>📖 শিক্ষক আবশ্যক (পড়তে চাই)</span>
                        </>
                      )}
                    </span>

                    <span className="text-[10px] text-[#736B5E] flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{item.createdAt}</span>
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-bold text-sm sm:text-base text-[#1B365D] line-clamp-2 leading-snug">
                    {item.title}
                  </h3>

                  {/* Highlights Grid */}
                  <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-2 text-xs">
                    {item.targetClasses && (
                      <div className="flex items-start gap-1.5 text-[#2D3A3A]">
                        <span className="font-bold text-[#5A6B6B] min-w-[70px]">শ্রেণি:</span>
                        <span className="font-semibold text-[#1B365D]">{item.targetClasses}</span>
                      </div>
                    )}
                    {item.subjects && (
                      <div className="flex items-start gap-1.5 text-[#2D3A3A]">
                        <span className="font-bold text-[#5A6B6B] min-w-[70px]">বিষয়:</span>
                        <span className="text-[#2D3A3A]">{item.subjects}</span>
                      </div>
                    )}
                    {item.qualification && (
                      <div className="flex items-start gap-1.5 text-[#2D3A3A]">
                        <span className="font-bold text-[#5A6B6B] min-w-[70px]">যোগ্যতা:</span>
                        <span className="text-[#2D5A27] font-semibold">{item.qualification}</span>
                      </div>
                    )}
                    {item.teachingDays && (
                      <div className="flex items-start gap-1.5 text-[#2D3A3A]">
                        <span className="font-bold text-[#5A6B6B] min-w-[70px]">দিন/সময়:</span>
                        <span>{item.teachingDays}</span>
                      </div>
                    )}
                    {item.medium && (
                      <div className="flex items-start gap-1.5 text-[#2D3A3A]">
                        <span className="font-bold text-[#5A6B6B] min-w-[70px]">মাধ্যম:</span>
                        <span className="bg-white px-2 py-0.5 rounded border border-[#E6E0D4] text-[11px]">{item.medium}</span>
                      </div>
                    )}
                  </div>

                  {/* Description */}
                  {item.description && (
                    <p className="text-xs text-[#5A6B6B] line-clamp-3 leading-relaxed">
                      {item.description}
                    </p>
                  )}

                  {/* Location & Village privacy */}
                  <div className="flex items-center gap-1.5 text-xs text-[#736B5E] pt-1">
                    <MapPin className="w-3.5 h-3.5 text-[#1B365D] shrink-0" />
                    <span className="truncate">
                      {item.hideVillage 
                        ? `${item.upazila ? item.upazila + ', ' : ''}${item.district}` 
                        : item.location}
                    </span>
                    {item.hideVillage && (
                      <span className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.2 rounded shrink-0">
                        গ্রাম গোপন
                      </span>
                    )}
                  </div>
                </div>

                {/* Bottom Section: Remuneration & Contact */}
                <div className="pt-4 mt-3 border-t border-[#E6E0D4] space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-[#5A6B6B] block">
                        {isOfferingTutor ? 'প্রত্যাশিত বেতন' : 'প্রস্তাবিত সম্মানী'}
                      </span>
                      <span className="font-bold text-base text-[#1B365D]">
                        {item.price > 0 ? `${formatTaka(item.price)} টাকা` : 'আলোচনা সাপেক্ষে'}
                      </span>
                      {item.price > 0 && <span className="text-[10px] text-[#736B5E]"> /মাস</span>}
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-[#5A6B6B] block">বিজ্ঞাপনদাতা</span>
                      <span className="text-xs font-bold text-[#2D3A3A]">{item.sellerName}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        if (!currentUser) {
                          onOpenAuth?.('বিজ্ঞাপনদাতার সাথে কল বা যোগাযোগ করতে লগইন বা নিবন্ধন করুন');
                          return;
                        }
                        setActiveCallingItem(item);
                      }}
                      className="flex items-center justify-center gap-1.5 bg-[#1B365D] hover:bg-[#132742] text-white py-2.5 px-3 rounded-2xl text-xs font-bold transition cursor-pointer shadow-2xs"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>কল করুন</span>
                    </button>

                    <button
                      onClick={() => {
                        if (!currentUser) {
                          onOpenAuth?.('বিজ্ঞাপনদাতার সাথে মেসেজ পাঠাতে লগইন বা নিবন্ধন করুন');
                          return;
                        }
                        setActiveChatListing(item);
                      }}
                      className="flex items-center justify-center gap-1.5 bg-[#F4E8D1] hover:bg-[#ECD9B8] text-[#1B365D] py-2.5 px-3 rounded-2xl text-xs font-bold transition cursor-pointer border border-[#D4C3A3]"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>মেসেজ</span>
                    </button>
                  </div>

                  {/* Action Bar: Owner/Admin vs Visitor */}
                  {(() => {
                    const cleanPhone = (p?: string) => p ? p.replace(/[^0-9]/g, '') : '';
                    let localPostedIds: string[] = [];
                    try {
                      localPostedIds = JSON.parse(localStorage.getItem('polli_user_posted_items') || '[]');
                    } catch {
                      localPostedIds = [];
                    }
                    const isAdminSession = typeof window !== 'undefined' && sessionStorage.getItem('polli_logged_admin') === 'true';

                    const isOwnerOrAdmin = Boolean(
                      isAdminSession ||
                      localPostedIds.includes(item.id) ||
                      (currentUser && (
                        currentUser.id === item.sellerId ||
                        (cleanPhone(currentUser.phone) && cleanPhone(item.phone) && cleanPhone(currentUser.phone) === cleanPhone(item.phone)) ||
                        currentUser.role === 'admin' ||
                        cleanPhone(currentUser.phone) === '01700000000'
                      ))
                    );

                    const isCompleted = !!(item.isSold || item.isCompleted);

                    if (isOwnerOrAdmin) {
                      return (
                        <div className="flex items-center justify-between text-[11px] pt-2 border-t border-dashed border-[#E6E0D4] text-[#5A6B6B]">
                          <button
                            onClick={() => onToggleStatus ? onToggleStatus(item.id) : null}
                            className="text-[#1B365D] hover:underline font-bold flex items-center gap-1 cursor-pointer bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200"
                            title={isCompleted ? 'বিজ্ঞাপনটি পুনরায় সক্রিয় করুন' : 'শিক্ষক বা শিক্ষার্থী পাওয়া গেলে হাইড করুন'}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#1B365D]" />
                            <span>{isCompleted ? 'পুনরায় সক্রিয় করুন' : 'সম্পন্ন / হাইড করুন'}</span>
                          </button>

                          <button
                            onClick={() => {
                              if (window.confirm('আপনি কি নিশ্চিত যে এই বিজ্ঞপ্তিটি সম্পূর্ণ মুছে ফেলতে চান?')) {
                                onDeleteListing?.(item.id);
                                deleteCloudHaatItem(item.id);
                              }
                            }}
                            className="text-[#C0392B] hover:underline font-semibold flex items-center gap-1 cursor-pointer px-2 py-1 rounded-lg hover:bg-red-50 border border-red-100"
                            title="বিজ্ঞপ্তিটি স্থায়ীভাবে মুছে ফেলুন"
                          >
                            <Trash2 className="w-3 h-3" />
                            <span>মুছুন</span>
                          </button>
                        </div>
                      );
                    }

                    if (isCompleted) {
                      return (
                        <div className="flex items-center justify-between text-[10px] pt-1.5 bg-gray-50 px-2 py-1 rounded-lg border border-gray-200 text-gray-600">
                          <span className="font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>{isOfferingTutor ? 'শিক্ষক ছাত্র পেয়েছেন (সম্পন্ন)' : 'গৃহশিক্ষক পাওয়া গেছে (সম্পন্ন)'}</span>
                          </span>
                        </div>
                      );
                    }

                    return null;
                  })()}
                </div>
              </div>
            );
          })}
        </div>
      )}
      </>
      )}

      {/* Add Tutor Listing Modal (Supports both Tutor Offering and Student Demanding) */}
      {showAddModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[88vh] sm:max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E0D4] overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] p-4 sm:p-5 shrink-0 bg-white">
              <div>
                <div className="flex items-center gap-1.5 mb-1">
                  {formType === 'tutor_avail' ? (
                    <>
                      <span className="bg-[#E8F8F5] text-[#2D5A27] text-[10px] font-bold px-2 py-0.5 rounded-full border border-[#2D5A27]/30">
                        শিক্ষক ও টিউটর কর্নার
                      </span>
                      <span className="text-xs text-[#5A6B6B]">| পড়াতে চাই বিজ্ঞাপন</span>
                    </>
                  ) : (
                    <>
                      <span className="bg-[#FFF4EC] text-[#E8924A] text-[10px] font-bold px-2 py-0.5 rounded-full border border-[#E8924A]/30">
                        অভিভাবক ও শিক্ষার্থী কর্নার
                      </span>
                      <span className="text-xs text-[#5A6B6B]">| গৃহশিক্ষক আবশ্যক</span>
                    </>
                  )}
                </div>
                <h3 className="font-bold text-base text-[#1B365D]">
                  {formType === 'tutor_avail' ? '👨‍🏫 শিক্ষক পড়াতে চাই বিজ্ঞাপন প্রকাশ' : '📖 গৃহশিক্ষক আবশ্যক পোস্ট তৈরি'}
                </h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitListing} className="flex flex-col flex-1 overflow-hidden">
              <div className="p-4 sm:p-5 overflow-y-auto overscroll-contain flex-1 space-y-4">
                {/* Type Switcher inside Modal */}
              <div className="flex bg-[#FAF8F5] p-1 rounded-2xl border border-[#E6E0D4] text-xs">
              <button
                type="button"
                onClick={() => setFormType('tutor_avail')}
                className={`flex-1 py-2.5 rounded-xl font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  formType === 'tutor_avail' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                }`}
              >
                <GraduationCap className="w-3.5 h-3.5" />
                <span>👨‍🏫 শিক্ষক পড়াতে চাই (অফার)</span>
              </button>
              <button
                type="button"
                onClick={() => setFormType('tutor_need')}
                className={`flex-1 py-2.5 rounded-xl font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  formType === 'tutor_need' ? 'bg-[#E8924A] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>📖 শিক্ষক আবশ্যক (পড়তে চাই)</span>
              </button>
            </div>

            {/* Local Notification Alert Banner */}
            {formType === 'tutor_avail' ? (
              <div className="bg-[#E8F8F5] border border-[#2D5A27]/30 p-3 rounded-2xl mb-4 text-xs text-[#1B4332] flex items-start gap-2.5">
                <Bell className="w-4 h-4 text-[#2D5A27] shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <strong>স্বয়ংক্রিয় অভিভাবক অ্যালার্ট:</strong> বিজ্ঞাপনটি প্রকাশিত হলে আপনার এলাকার অভিভাবক ও শিক্ষার্থীরা তাদের ফোনে তাৎক্ষণিক নোটিফিকেশন পাবেন এবং আপনার সাথে সরাসরি যোগাযোগ করবেন।
                </div>
              </div>
            ) : (
              <div className="bg-[#FFF8F0] border border-[#E8924A]/40 p-3 rounded-2xl mb-4 text-xs text-[#8A4816] flex items-start gap-2.5">
                <Bell className="w-4 h-4 text-[#E8924A] shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <strong>স্বয়ংক্রিয় শিক্ষক অ্যালার্ট:</strong> আপনার এই পোস্টটি সম্পন্ন হওয়ার সাথে সাথে এলাকার নিবন্ধিত শিক্ষকেরা তাদের ফোনে তাৎক্ষণিক নোটিফিকেশন পাবেন এবং আপনার সাথে সরাসরি যোগাযোগ করবেন।
                </div>
              </div>
            )}

            <div className="space-y-3.5">
              {/* Title */}
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  {formType === 'tutor_avail' ? 'বিজ্ঞাপনের মূল শিরোনাম *' : 'পোস্টের মূল শিরোনাম *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    formType === 'tutor_avail'
                      ? 'যেমন: ৮ম-১০ম শ্রেণির গণিত ও বিজ্ঞানের অভিজ্ঞ শিক্ষক পড়াতে চাই'
                      : 'যেমন: ৭ম শ্রেণির গণিত ও ইংরেজির জন্য অভিজ্ঞ গৃহশিক্ষক প্রয়োজন'
                  }
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#1B365D]"
                />
              </div>

              {/* Class & Medium */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    শ্রেণি / শ্রেণি স্তর *
                  </label>
                  <select
                    value={targetClasses}
                    onChange={(e) => setTargetClasses(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#1B365D]"
                  >
                    <option value="১ম - ৫ম শ্রেণি (প্রাথমিক)">১ম - ৫ম শ্রেণি (প্রাথমিক)</option>
                    <option value="৬ষ্ঠ - ৮ম শ্রেণি (জেএসসি)">৬ষ্ঠ - ৮ম শ্রেণি (জেএসসি)</option>
                    <option value="৮ম - ১০ম শ্রেণি (এসএসসি)">৮ম - ১০ম শ্রেণি (এসএসসি)</option>
                    <option value="একাদশ - দ্বাদশ (এইচএসসি বিজ্ঞান)">একাদশ - দ্বাদশ (এইচএসসি বিজ্ঞান)</option>
                    <option value="একাদশ - দ্বাদশ (মানবিক / বাণিজ্য)">একাদশ - দ্বাদশ (মানবিক / বাণিজ্য)</option>
                    <option value="মাদরাসা ও হিফজ বিভাগ">মাদরাসা ও হিফজ বিভাগ</option>
                    <option value="ইংরেজি ভার্সন / স্পোকেন">ইংরেজি ভার্সন / স্পোকেন</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    পাঠদান মাধ্যম
                  </label>
                  <select
                    value={medium}
                    onChange={(e) => setMedium(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#1B365D]"
                  >
                    <option value="বাংলা মাধ্যম">বাংলা মাধ্যম</option>
                    <option value="ইংরেজি ভার্সন">ইংরেজি ভার্সন</option>
                    <option value="মাদরাসা মাধ্যম">মাদরাসা মাধ্যম</option>
                  </select>
                </div>
              </div>

              {/* Subjects & Qualification */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    বিষয়সমূহ *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: সাধারণ গণিত, উচ্চতর গণিত, ইংরেজি"
                    value={subjects}
                    onChange={(e) => setSubjects(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#1B365D]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    {formType === 'tutor_avail' ? 'আপনার শিক্ষাগত যোগ্যতা ও প্রতিষ্ঠান' : 'শিক্ষকের প্রত্যাশিত যোগ্যতা (ঐচ্ছিক)'}
                  </label>
                  <input
                    type="text"
                    placeholder={
                      formType === 'tutor_avail'
                        ? 'যেমন: বিএসসি অনার্স (গণিত), সরকারি আজিজুল হক কলেজ'
                        : 'যেমন: স্নাতক অধ্যয়নরত অথবা অভিজ্ঞ শিক্ষিকা'
                    }
                    value={qualification}
                    onChange={(e) => setQualification(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#1B365D]"
                  />
                </div>
              </div>

              {/* Teaching Days & Salary */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    সপ্তাহে দিন ও সুবিধাজনক সময়
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: সপ্তাহে ৩ দিন (বিকেল বা সন্ধ্যায়)"
                    value={teachingDays}
                    onChange={(e) => setTeachingDays(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#1B365D]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    {formType === 'tutor_avail' ? 'প্রত্যাশিত মাসিক সম্মানী (টাকা)' : 'প্রস্তাবিত মাসিক বাজেট / সম্মানী (টাকা)'}
                  </label>
                  <input
                    type="number"
                    placeholder={formType === 'tutor_avail' ? 'যেমন: ৩০০০' : 'যেমন: ২৫০০ বা ৩০০০'}
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#1B365D]"
                  />
                </div>
              </div>

              {/* Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    আপনার নাম *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="আপনার পুরো নাম"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#1B365D]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    মোবাইল নম্বর (যোগাযোগের জন্য) *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৭xxxxxxxx"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#1B365D]"
                  />
                </div>
              </div>

              {/* Cascading Location Selector */}
              <div className="pt-2 border-t border-[#E6E0D4]">
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1.5">
                  আপনার এলাকা নির্বাচন করুন (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ গ্রাম) *
                </label>
                <CascadingAddressSelector
                  address={formAddress}
                  onChange={(newAddr) => setFormAddress(newAddr)}
                  showVillage={true}
                  villagePlaceholder="গ্রাম বা মহল্লার নাম"
                />

                <div className="mt-2 flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="tutorHideVillage"
                    checked={hideVillage}
                    onChange={(e) => setHideVillage(e.target.checked)}
                    className="rounded text-[#1B365D] focus:ring-[#1B365D]"
                  />
                  <label htmlFor="tutorHideVillage" className="text-xs text-[#5A6B6B] cursor-pointer">
                    🔒 গোপনীয়তা রক্ষা: বিজ্ঞাপনে শুধু উপজেলা ও জেলা দেখাবে (গ্রাম হাইড থাকবে)
                  </label>
                </div>
              </div>

              {/* Local Notification Scope Selection */}
              <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#D4C3A3] space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-[#1B365D] flex items-center gap-1.5">
                    <Bell className="w-3.5 h-3.5 text-[#E8924A]" />
                    <span>নোটিফিকেশন এলাকা পরিধি (কারা তাৎক্ষণিক অ্যালার্ট পাবে):</span>
                  </label>
                  <span className="text-[10px] text-[#736B5E]">স্মার্ট অ্যালার্ট</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNotificationScope('upazila')}
                    className={`p-2.5 rounded-xl text-xs font-bold border text-left transition flex items-center gap-2 cursor-pointer ${
                      notificationScope === 'upazila'
                        ? 'bg-[#1B365D] text-white border-[#1B365D] shadow-xs'
                        : 'bg-white text-[#5A6B6B] border-[#D4C3A3] hover:bg-gray-50'
                    }`}
                  >
                    <MapPin className="w-3.5 h-3.5 shrink-0 text-[#E8924A]" />
                    <div>
                      <div className="leading-tight">উপজেলা ভিত্তিক</div>
                      <div className={`text-[10px] font-normal ${notificationScope === 'upazila' ? 'text-blue-100' : 'text-[#736B5E]'}`}>
                        {formAddress.upazila ? `${formAddress.upazila} উপজেলা` : 'আমার উপজেলার সবাই'}
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setNotificationScope('district')}
                    className={`p-2.5 rounded-xl text-xs font-bold border text-left transition flex items-center gap-2 cursor-pointer ${
                      notificationScope === 'district'
                        ? 'bg-[#1B365D] text-white border-[#1B365D] shadow-xs'
                        : 'bg-white text-[#5A6B6B] border-[#D4C3A3] hover:bg-gray-50'
                    }`}
                  >
                    <Users className="w-3.5 h-3.5 shrink-0 text-[#E8924A]" />
                    <div>
                      <div className="leading-tight">জেলা ভিত্তিক (ডিফল্ট)</div>
                      <div className={`text-[10px] font-normal ${notificationScope === 'district' ? 'text-blue-100' : 'text-[#736B5E]'}`}>
                        {formAddress.district ? `${formAddress.district} জেলা` : 'পুরো জেলার সবাই'}
                      </div>
                    </div>
                  </button>
                </div>

                <p className="text-[10px] text-[#736B5E] leading-tight">
                  {notificationScope === 'upazila'
                    ? `📍 শুধুমাত্র ${formAddress.upazila || 'আপনার'} উপজেলার নিবন্ধিত ভাই-বোনেরা পুশ নোটিফিকেশন পাবেন।`
                    : `🌐 পুরো ${formAddress.district || 'আপনার'} জেলার নিবন্ধিত ভাই-বোনেরা নোটিফিকেশন পাবেন।`}
                </p>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  বিস্তারিত বিবরণ
                </label>
                <textarea
                  rows={2}
                  placeholder="পড়ানোর অভিজ্ঞতা, পূর্বের ফলাফল বা অন্যান্য বিশেষ নির্দেশনা লিখুন..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#1B365D]"
                />
              </div>

              {/* Global Auto-fill & Offline Call Status Box */}
              <div className="bg-[#FAF6ED] border border-[#E6DEC8] rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                    <span>📞</span>
                    <span>অফলাইন সরাসরি কল পারমিশন (Auto-fill)</span>
                  </span>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                    allowOfflineCall 
                      ? 'bg-[#D4E4BC] text-[#2D5A27] border-[#2D5A27]/30' 
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}>
                    {allowOfflineCall ? 'অনুমোদিত (হ্যাঁ)' : 'সুরক্ষিত/গোপন (না)'}
                  </span>
                </div>

                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={allowOfflineCall}
                    onChange={(e) => setAllowOfflineCall(e.target.checked)}
                    className="w-4 h-4 rounded text-[#1B365D] focus:ring-[#1B365D] cursor-pointer mt-0.5 shrink-0"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-[#2D3A3A] block">
                      {formType === 'tutor_avail'
                        ? 'আপনি কি শিক্ষার্থী বা অভিভাবকদের সরাসরি অফলাইনে কলের সুযোগ দিতে চান?'
                        : 'আপনি কি শিক্ষকদের সরাসরি অফলাইনে কলের সুযোগ দিতে চান?'}
                    </span>
                    <span className="text-[11px] text-[#736B5E] block mt-0.5 leading-relaxed">
                      {allowOfflineCall
                        ? '✓ অনুমোদিত: অভিভাবক/শিক্ষার্থী সরাসরি আপনার সিম কার্ডের নম্বরে কল করতে পারবেন (তবে কল করার পূর্বে তাদের স্ক্রিনে সতর্কবার্তা দেখানো হবে)।'
                        : '🔒 বন্ধ (ডিফল্ট): আপনার মোবাইল নম্বর ও সুনির্দিষ্ট গ্রাম/মহল্লা গোপন থাকবে। যোগাযোগকারীরা ইন-অ্যাপ চ্যাট বা ভয়েস কলে যোগাযোগ করবেন।'}
                    </span>
                  </div>
                </label>
              </div>
              </div>
              </div>

              {/* Pinned Sticky Bottom Action Bar */}
              <div className="border-t border-[#E6E0D4] p-4 bg-[#FAF8F5] shrink-0 flex justify-end gap-2 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-white border border-[#E6E0D4] hover:bg-gray-50 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className={`px-6 py-2.5 rounded-2xl text-xs font-bold text-white shadow-sm cursor-pointer active:scale-98 transition flex items-center gap-1.5 ${
                    formType === 'tutor_avail'
                      ? 'bg-[#2D5A27] hover:bg-[#24481f]'
                      : 'bg-[#E8924A] hover:bg-[#D97D35]'
                  }`}
                >
                  {formType === 'tutor_avail' ? (
                    <>
                      <GraduationCap className="w-3.5 h-3.5" />
                      <span>👨‍🏫 শিক্ষক পড়াতে চাই বিজ্ঞাপন প্রকাশ করুন</span>
                    </>
                  ) : (
                    <>
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>📖 গৃহশিক্ষক আবশ্যক পোস্ট প্রকাশ করুন</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Real-time Cloud Chat Modal */}
      {activeChatListing && (
        <ChatModal
          isOpen={!!activeChatListing}
          onClose={() => setActiveChatListing(null)}
          currentUser={currentUser}
          recipientId={activeChatListing.sellerId || `seller-${activeChatListing.phone}`}
          recipientName={activeChatListing.sellerName}
          recipientRole={activeChatListing.tutorType === 'tutor_avail' ? 'শিক্ষক' : 'অভিভাবক'}
          recipientPhone={activeChatListing.phone}
          itemTitle={activeChatListing.title}
          itemPrice={activeChatListing.price}
          itemUnit={activeChatListing.unit}
          onOpenAuth={onOpenAuth}
        />
      )}

      {/* Direct Call / In-App Voice Call Choice Modal */}
      {activeCallingItem && (
        <CallChoiceModal
          recipientName={activeCallingItem.sellerName}
          recipientRole={activeCallingItem.tutorType === 'tutor_avail' ? 'শিক্ষক' : 'অভিভাবক'}
          recipientSubtitle={`বিজ্ঞপ্তি: ${activeCallingItem.title} (${activeCallingItem.district})`}
          rawPhone={activeCallingItem.phone}
          onSelectInAppCall={() => {
            const item = activeCallingItem;
            setActiveCallingItem(null);
            setInAppVoiceItem(item);
          }}
          onOpenChat={() => {
            const item = activeCallingItem;
            setActiveCallingItem(null);
            setActiveChatListing(item);
          }}
          onClose={() => setActiveCallingItem(null)}
        />
      )}

      {/* In-App Encrypted Voice Call Modal */}
      {inAppVoiceItem && (
        <InAppVoiceCallModal
          recipientName={inAppVoiceItem.sellerName}
          recipientRole={inAppVoiceItem.tutorType === 'tutor_avail' ? 'শিক্ষক' : 'অভিভাবক'}
          recipientSubtitle={`বিজ্ঞপ্তি: ${inAppVoiceItem.title} (${inAppVoiceItem.district})`}
          maskedPhone={maskPhoneNumber(inAppVoiceItem.phone)}
          rawPhone={inAppVoiceItem.phone}
          currentUser={currentUser}
          onClose={() => setInAppVoiceItem(null)}
        />
      )}
    </div>
  );
};
