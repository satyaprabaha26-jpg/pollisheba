import React, { useState, useEffect } from 'react';
import { 
  X, 
  ShieldCheck, 
  Phone, 
  PhoneCall, 
  MessageSquare, 
  Mic, 
  MapPin, 
  Lock, 
  ExternalLink,
  Smartphone,
  Eye,
  Ban,
  ShieldAlert,
  AlertCircle,
  Flag
} from 'lucide-react';
import { UserProfile, getUserDisplayAvatar } from '../../types/auth';
import { subscribeToUserPresence, toggleBlockUser, isUserBlocked } from '../../lib/cloudSync';
import { ReportItemModal } from '../common/ReportItemModal';

interface CitizenPublicProfileModalProps {
  user: Partial<UserProfile>;
  isOpen: boolean;
  currentUser?: UserProfile | null;
  onClose: () => void;
  onStartInAppCall?: (user: Partial<UserProfile>) => void;
  onStartChat?: (user: Partial<UserProfile>) => void;
  onOpenVoiceNote?: (user: Partial<UserProfile>) => void;
}

export const CitizenPublicProfileModal: React.FC<CitizenPublicProfileModalProps> = ({
  user,
  isOpen,
  currentUser,
  onClose,
  onStartInAppCall,
  onStartChat,
  onOpenVoiceNote
}) => {
  const [showEnlargedPhoto, setShowEnlargedPhoto] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [offlineCallError, setOfflineCallError] = useState<string | null>(null);
  const [isUserOnline, setIsUserOnline] = useState<boolean>(false);
  const [photoNotice, setPhotoNotice] = useState<string | null>(null);

  // Determine avatar: only custom optional photo is public; live verification photo is private to owner/admin
  const viewerId = currentUser?.phone || currentUser?.id;
  const isSuperAdmin = currentUser?.email?.toLowerCase().trim() === 'polliseba26@gmail.com' || currentUser?.email?.toLowerCase().trim() === 'shahinurrahman847@gmail.com';
  const displayAvatar = getUserDisplayAvatar(user, viewerId, isSuperAdmin);

  // Subscribe to real-time online status
  useEffect(() => {
    if (!isOpen || (!user.id && !user.phone)) return;
    const targetKey = user.phone ? user.phone.replace(/[^0-9]/g, '') : (user.id || '');
    const unsub = subscribeToUserPresence(targetKey, (presence) => {
      setIsUserOnline(!!presence?.isOnline);
    });
    return () => {
      if (unsub) unsub();
    };
  }, [isOpen, user.id, user.phone]);

  const targetId = user.phone ? user.phone.replace(/[^0-9]/g, '') : (user.id || '');
  const [isBlocked, setIsBlocked] = useState<boolean>(() => {
    return isUserBlocked(viewerId, targetId, currentUser);
  });
  const [blockNotice, setBlockNotice] = useState<string | null>(null);

  useEffect(() => {
    setIsBlocked(isUserBlocked(viewerId, targetId, currentUser));
  }, [viewerId, targetId, currentUser]);

  const handleToggleBlock = async () => {
    if (!viewerId) {
      alert('ব্যবহারকারীকে ব্লক করতে আগে লগইন করুন।');
      return;
    }
    const nextBlocked = !isBlocked;
    const confirmMsg = nextBlocked
      ? `আপনি কি "${user.name || 'এই ব্যবহারকারী'}" কে ব্লক করতে চান? ব্লক করলে তার কোনো কল বা মেসেজ আর আপনার কাছে আসবে না।`
      : `আপনি কি "${user.name || 'এই ব্যবহারকারী'}" এর ব্লক প্রত্যাহার (Unblock) করতে চান?`;

    if (window.confirm(confirmMsg)) {
      const res = await toggleBlockUser(viewerId, targetId, nextBlocked);
      setIsBlocked(res.isBlocked);
      setBlockNotice(res.isBlocked ? '🚫 ব্যবহারকারীকে সফলভাবে ব্লক করা হয়েছে।' : '✓ ব্লক প্রত্যাহার করা হয়েছে।');
      setTimeout(() => setBlockNotice(null), 4000);
    }
  };

  if (!isOpen) return null;

  const isOwner = currentUser && (
    currentUser.id === user.id || 
    (currentUser.phone && user.phone && currentUser.phone.replace(/[^0-9]/g, '') === user.phone.replace(/[^0-9]/g, ''))
  );

  // Strict offline call permission: must be explicitly true
  const allowOffline = user.allowOfflineCall === true || user.allowOfflineCalls === true;

  const handleOfflineCallClick = () => {
    if (!allowOffline) {
      setOfflineCallError('দুঃখিত! অফলাইনে এই ব্যবহারকারীকে কল করার অনুমতি নেই।');
      setTimeout(() => setOfflineCallError(null), 5000);
      return;
    }
    const cleanPhone = (user.phone || '').replace(/[^0-9+]/g, '');
    if (cleanPhone) {
      window.location.href = `tel:${cleanPhone}`;
    }
  };

  const handleAvatarClick = () => {
    if (displayAvatar) {
      setShowEnlargedPhoto(true);
    } else {
      setPhotoNotice('ব্যবহারকারীর লাইভ ভেরিফিকেশন ছবি গোপন রাখা হয়েছে (নিরাপত্তার স্বার্থে শুধুমাত্র নাম ও ব্যাজ দৃশ্যমান)।');
      setTimeout(() => setPhotoNotice(null), 4000);
    }
  };

  const getRoleLabel = (role?: string) => {
    switch (role) {
      case 'farmer': return '🌾 সম্মানিত কৃষক ও খামারি';
      case 'laborer': return '🛠️ সম্মানিত কৃষাণ ও দিনমজুর';
      case 'home_entrepreneur': return '🏡 সম্মানিত গৃহ উদ্যোক্তা';
      case 'trader': return '🛍️ সম্মানিত ব্যবসায়ী ও পাইকার';
      case 'driver': return '🚗 সম্মানিত চালক';
      case 'mechanic': return '🔧 সম্মানিত ইলেকট্রিশিয়ান ও মেকার';
      case 'tutor_student': return '📚 সম্মানিত শিক্ষক / শিক্ষার্থী';
      case 'doctor': return '👨‍⚕️ সম্মানিত পল্লী চিকিৎসক';
      case 'agri_machinery_driver': return '🚜 ট্র্যাক্টর / হেস্কোভেটর চালক';
      case 'boatman': return '⛵ নৌকার মাঝি / খেয়া চালক';
      default: return '👤 সম্মানিত পল্লী নাগরিক';
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-150">
        <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl border border-[#E6E0D4] relative overflow-hidden">
          
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Offline Call Disallowed Error Alert */}
          {offlineCallError && (
            <div className="bg-amber-50 text-amber-950 border-2 border-amber-400 rounded-2xl p-3 text-xs font-bold animate-in fade-in space-y-1 text-left shadow-md">
              <div className="flex items-center justify-between gap-1">
                <span className="text-amber-900 font-extrabold flex items-center gap-1">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>{offlineCallError}</span>
                </span>
                <button onClick={() => setOfflineCallError(null)} className="text-amber-700 hover:text-amber-950">✕</button>
              </div>
              <p className="text-[11px] font-normal text-amber-900 leading-tight">
                এই ব্যবহারকারী নিজের ফোন নম্বর নিরাপদ ও গোপন রাখতে অফলাইন কল বন্ধ রেখেছেন। আপনি চাইলে ওনাকে <strong>অনলাইন অডিও কল</strong> করতে পারেন অথবা <strong>লিখিত/ভয়েস মেসেজ</strong> পাঠাতে পারেন।
              </p>
            </div>
          )}

          {/* Photo privacy notice */}
          {photoNotice && (
            <div className="bg-blue-50 text-blue-900 border border-blue-300 rounded-2xl p-2.5 text-[11px] font-medium animate-in fade-in flex items-center justify-between gap-1 text-left shadow-xs">
              <span>🛡️ {photoNotice}</span>
              <button onClick={() => setPhotoNotice(null)} className="text-blue-700 hover:text-blue-950">✕</button>
            </div>
          )}

          {/* Centered Circular Avatar directly above the name (Facebook / WhatsApp style) */}
          <div className="flex flex-col items-center pt-1">
            <div 
              onClick={handleAvatarClick}
              className="relative inline-block cursor-pointer group"
              title={displayAvatar ? 'ছবিতে স্পর্শ করে বড় আকারে দেখুন' : 'প্রোফাইল ছবি'}
            >
              <div className="w-28 h-28 rounded-full border-4 border-[#2D5A27] flex items-center justify-center shadow-lg overflow-hidden bg-[#FAF8F5] transition transform group-hover:scale-105">
                {displayAvatar ? (
                  <img 
                    src={displayAvatar} 
                    alt={user.name} 
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center font-bold text-4xl text-[#2D5A27] bg-[#D4E4BC]/50">
                    {user.name ? user.name.charAt(0) : 'প'}
                  </div>
                )}
              </div>

              {/* Verified badge */}
              <div className="absolute bottom-1 right-1 bg-[#27AE60] p-1.5 rounded-full border-2 border-white text-white shadow-xs">
                <ShieldCheck className="w-4 h-4" />
              </div>
            </div>

            <p className="text-[10px] text-gray-400 mt-1 flex items-center gap-1 justify-center">
              <Eye className="w-3 h-3 text-[#2D5A27]" />
              <span>ছবিতে হাত দিলে বড় হবে</span>
            </p>
          </div>

          {/* User Name & Details Centered Directly Below */}
          <div className="space-y-1">
            <div className="flex items-center justify-center gap-1.5">
              <h3 className="text-xl font-bold text-[#2D3A3A] tracking-wide">
                {user.name || 'সম্মানিত সদস্য'}
              </h3>
              <ShieldCheck className="w-4 h-4 text-[#27AE60]" />
            </div>

            <p className="text-xs font-bold text-[#2D5A27] bg-[#D4E4BC]/40 px-3 py-1 rounded-full inline-block">
              {getRoleLabel(user.role)}
            </p>

            {/* Address */}
            <p className="text-xs text-[#736B5E] flex items-center justify-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-[#2D5A27]" />
              <span>
                {[user.village, user.union, user.upazila, user.district].filter(Boolean).join(', ') || 'বাংলাদেশ'}
              </span>
            </p>

            {/* Real-time Online Presence Indicator */}
            <div className="flex items-center justify-center gap-1.5 pt-1">
              {isUserOnline ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>🟢 অনলাইনে আছেন</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-semibold bg-gray-100 text-gray-600 border border-gray-300">
                  <span className="w-2 h-2 rounded-full bg-gray-400" />
                  <span>⚪ অফলাইন</span>
                </span>
              )}
            </div>
          </div>

          {/* 3 Prominent Action Cards: Call (Online/Offline), Message, Voice Note */}
          <div className="pt-2 space-y-2.5">
            
            {/* Call Section: Online & Offline Buttons */}
            <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-2">
              <span className="text-[11px] font-bold text-[#2D3A3A] block text-left flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-[#2D5A27]" />
                <span>কল করার মাধ্যম:</span>
              </span>

              <div className="grid grid-cols-2 gap-2">
                {/* 1. Online Voice Call */}
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onStartInAppCall?.(user);
                  }}
                  className="py-2.5 px-3 bg-[#2D5A27] hover:bg-[#23491E] text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>অনলাইন কল</span>
                </button>

                {/* 2. Offline SIM Call (with permission check) */}
                <button
                  type="button"
                  onClick={handleOfflineCallClick}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer ${
                    allowOffline 
                      ? 'bg-[#E8924A] hover:bg-[#D97D35] text-white' 
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-600 border border-gray-300'
                  }`}
                  title={allowOffline ? 'সাধারণ সিম কল' : 'অফলাইন কল বন্ধ'}
                >
                  {allowOffline ? <Smartphone className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                  <span>অফলাইন কল</span>
                </button>
              </div>

              {!allowOffline && (
                <p className="text-[10px] text-gray-500 text-left leading-tight">
                  🔒 ব্যবহারকারী অফলাইন কল বন্ধ রেখেছেন। শুধুমাত্র অনলাইন কল বা মেসেজ প্রযোজ্য।
                </p>
              )}
            </div>

            {/* Direct Written Message & Voice Note Buttons */}
            <div className="grid grid-cols-2 gap-2">
              {/* Written Text Chat */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onStartChat?.(user);
                }}
                className="py-2.5 px-3 bg-white hover:bg-emerald-50 text-[#2D5A27] border border-[#2D5A27] rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5 text-[#2D5A27]" />
                <span>লিখিত মেসেজ</span>
              </button>

              {/* Voice Message */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenVoiceNote?.(user);
                }}
                className="py-2.5 px-3 bg-white hover:bg-gray-50 text-[#2D3A3A] border border-[#D4C3A3] rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <Mic className="w-3.5 h-3.5 text-[#2D5A27]" />
                <span>ভয়েস মেসেজ</span>
              </button>
            </div>

          </div>

          {/* Block Notice Alert */}
          {blockNotice && (
            <div className="bg-red-50 text-red-900 border border-red-300 rounded-2xl p-2.5 text-xs font-bold animate-in fade-in flex items-center justify-between text-left shadow-xs">
              <span className="flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-red-600 shrink-0" />
                <span>{blockNotice}</span>
              </span>
              <button onClick={() => setBlockNotice(null)} className="text-red-700">✕</button>
            </div>
          )}

          {/* User-Level Block / Unblock & Report Fake Account Actions (Requirement 6 & 8) */}
          {!isOwner && (
            <div className="pt-1 space-y-2">
              <button
                type="button"
                onClick={handleToggleBlock}
                className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer border shadow-2xs ${
                  isBlocked
                    ? 'bg-red-600 hover:bg-red-700 text-white border-red-600'
                    : 'bg-white hover:bg-red-50 text-red-600 border-red-200'
                }`}
              >
                <Ban className="w-3.5 h-3.5" />
                <span>{isBlocked ? 'এই ব্যবহারকারী ব্লক করা আছেন (আনব্লক করুন)' : 'ব্যবহারকারীকে ব্লক করুন (কল/মেসেজ বন্ধ)'}</span>
              </button>

              <button
                type="button"
                onClick={() => setShowReportModal(true)}
                className="w-full py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 shadow-2xs"
              >
                <Flag className="w-3.5 h-3.5 text-amber-700" />
                <span>ভুয়া অ্যাকাউন্ট বা বিভ্রান্তিকর তথ্যের বিরুদ্ধে অভিযোগ করুন</span>
              </button>
            </div>
          )}

          {/* Privacy Note */}
          <div className="pt-1 text-[10px] text-gray-400 flex items-center justify-center gap-1">
            <Lock className="w-3 h-3 text-[#27AE60]" />
            <span>১০০% সুরক্ষিত পল্লী সেবা সংযোগ • নম্বর অপ্রকাশ্য</span>
          </div>

        </div>
      </div>

      {/* Enlarged Photo Lightbox Modal (WhatsApp/Facebook style) */}
      {showEnlargedPhoto && displayAvatar && (
        <div 
          onClick={() => setShowEnlargedPhoto(false)}
          className="fixed inset-0 z-80 bg-black/95 backdrop-blur-lg flex flex-col items-center justify-center p-4 animate-in fade-in"
        >
          <div className="relative max-w-sm w-full flex flex-col items-center space-y-4">
            <button
              onClick={() => setShowEnlargedPhoto(false)}
              className="absolute -top-12 right-0 p-2 text-white/80 hover:text-white bg-white/10 rounded-full cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
            <img 
              src={displayAvatar} 
              alt={user.name} 
              className="w-72 h-72 rounded-full object-cover border-4 border-emerald-500 shadow-2xl" 
            />
            <h4 className="text-xl font-bold text-white text-center">{user.name}</h4>
            <p className="text-xs text-gray-300">প্রোফাইল ছবি (পূর্ণরূপ)</p>
          </div>
        </div>
      )}

      {/* Report Fake Account or Misleading Info Modal */}
      {showReportModal && (
        <ReportItemModal
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          targetId={user.id || user.phone || 'profile-target'}
          targetTitle={user.name ? `${user.name} (${user.role || 'প্রোফাইল'})` : 'নাগরিক প্রোফাইল'}
          targetType="driver"
          currentUser={currentUser}
        />
      )}
    </>
  );
};

