import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Clock, 
  Car, 
  Phone, 
  Camera, 
  FileText, 
  Download, 
  Printer, 
  Lock, 
  Search, 
  Filter, 
  MapPin, 
  CheckCircle2, 
  AlertTriangle,
  Eye,
  Shield,
  Calendar,
  X,
  UserCheck,
  Building
} from 'lucide-react';
import { UserProfile, UserSecurityLogRecord, LOGBOOK_RETENTION_PERIOD_MS } from '../../types/auth';

interface UserSecurityLogbookProps {
  user?: UserProfile | null;
  isAdminView?: boolean;
  onClose?: () => void;
}

export const UserSecurityLogbook: React.FC<UserSecurityLogbookProps> = ({
  user,
  isAdminView = false,
  onClose
}) => {
  if (!user) {
    return null;
  }

  const [selectedFilter, setSelectedFilter] = useState<'all' | 'travel_trip' | 'phone_change' | 'photo_change' | 'security_verify'>('all');
  const [selectedMonth, setSelectedMonth] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showOfficialDossier, setShowOfficialDossier] = useState(false);

  // Compile logs from user profile
  const logs: UserSecurityLogRecord[] = React.useMemo(() => {
    const rawLogs = user.securityAuditLogs || [];
    
    // Fallback: If no logs yet, synthesize baseline logs from account creation & phone regulation
    const compiled: UserSecurityLogRecord[] = [...rawLogs];

    // Check if account creation log exists
    if (!compiled.some(l => l.category === 'security_verify')) {
      const createdAt = user.createdAtTimestamp || (Date.now() - 15 * 24 * 60 * 60 * 1000);
      compiled.push({
        id: `LOG-INIT-${user.id}`,
        auditHash: `SEC-POL-${user.id.slice(0, 4).toUpperCase()}-INIT`,
        timestamp: createdAt,
        formattedDate: new Date(createdAt).toLocaleString('bn-BD', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          hour12: true
        }),
        category: 'security_verify',
        categoryTitle: 'প্রাথমিক অ্যাকাউন্ট ভেরিফিকেশন',
        summary: 'মোবাইল ওটিপি ও লাইভ সেলফি যাচাইয়ের মাধ্যমে অ্যাকাউন্ট নিবন্ধন সম্পন্ন',
        details: {
          notes: 'ডিজিটাল পল্লি সেবা প্ল্যাটফর্মে নিয়মাবলি সম্মতিসহ নাগরিক প্রোফাইল প্রস্তুত।'
        },
        retentionDaysLeft: 350,
        expiresAtTimestamp: createdAt + LOGBOOK_RETENTION_PERIOD_MS,
        isImmutable: true
      });
    }

    // Check if user has phone change history
    if (user.phoneChangeHistory && user.phoneChangeHistory.length > 0) {
      user.phoneChangeHistory.forEach((rec, idx) => {
        if (!compiled.some(l => l.details.newPhone === rec.newPhone)) {
          compiled.push({
            id: `LOG-PHONE-${idx}-${user.id}`,
            auditHash: `SEC-POL-PH-${idx}-REG`,
            timestamp: rec.changedAtTimestamp,
            formattedDate: rec.changedAt,
            category: 'phone_change',
            categoryTitle: 'ফোন নম্বর পরিবর্তন লগ',
            summary: `মোবাইল নম্বর পরিবর্তন: ${rec.oldPhone} থেকে ${rec.newPhone}`,
            details: {
              oldPhone: rec.oldPhone,
              newPhone: rec.newPhone,
              otpStatus: 'ওটিপি ভেরিফাইড সম্পন্ন',
              notes: rec.reason || '২৬ দিন অতিক্রান্ত হওয়ার পর ওটিপি যাচাই সাপেক্ষে নম্বর পরিবর্তন।'
            },
            retentionDaysLeft: 360,
            expiresAtTimestamp: rec.changedAtTimestamp + LOGBOOK_RETENTION_PERIOD_MS,
            isImmutable: true
          });
        }
      });
    }

    // Sort by most recent first
    return compiled.sort((a, b) => b.timestamp - a.timestamp);
  }, [user]);

  // Extract distinct months for month-wise grouping and filtering
  const availableMonths = React.useMemo(() => {
    const set = new Set<string>();
    logs.forEach(l => {
      const d = new Date(l.timestamp);
      const mStr = d.toLocaleDateString('bn-BD', { year: 'numeric', month: 'long' });
      set.add(mStr);
    });
    return Array.from(set);
  }, [logs]);

  // Filtered Logs
  const filteredLogs = logs.filter(log => {
    if (selectedFilter !== 'all' && log.category !== selectedFilter) return false;
    if (selectedMonth !== 'all') {
      const d = new Date(log.timestamp);
      const mStr = d.toLocaleDateString('bn-BD', { year: 'numeric', month: 'long' });
      if (mStr !== selectedMonth) return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchSummary = log.summary.toLowerCase().includes(q);
      const matchTitle = log.categoryTitle.toLowerCase().includes(q);
      const matchHash = log.auditHash.toLowerCase().includes(q);
      const matchDetails = JSON.stringify(log.details).toLowerCase().includes(q);
      return matchSummary || matchTitle || matchHash || matchDetails;
    }
    return true;
  });

  // Group filtered logs month-wise
  const groupedLogsByMonth = React.useMemo(() => {
    const groups: { monthLabel: string; items: UserSecurityLogRecord[] }[] = [];
    filteredLogs.forEach(log => {
      const d = new Date(log.timestamp);
      const monthLabel = d.toLocaleDateString('bn-BD', { year: 'numeric', month: 'long' });
      let group = groups.find(g => g.monthLabel === monthLabel);
      if (!group) {
        group = { monthLabel, items: [] };
        groups.push(group);
      }
      group.items.push(log);
    });
    return groups;
  }, [filteredLogs]);

  const travelLogsCount = logs.filter(l => l.category === 'travel_trip').length;
  const phoneLogsCount = logs.filter(l => l.category === 'phone_change').length;
  const photoLogsCount = logs.filter(l => l.category === 'photo_change').length;

  const handlePrintDossier = () => {
    window.print();
  };

  return (
    <div className="bg-white rounded-3xl border border-[#E6E0D4] shadow-sm overflow-hidden space-y-4">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#1B365D] via-[#2D5A27] to-[#1E3F1A] text-white p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <div className="p-2 bg-white/10 backdrop-blur-xs rounded-xl text-[#D4E4BC]">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-base sm:text-lg">
                ডিজিটাল নিরাপত্তা লগবই (১ বছর মেয়াদী অপরিবর্তনীয় রেকর্ড)
              </h3>
              <span className="bg-amber-400 text-slate-900 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                ৩৬৫ দিন লিগ্যাল অডিট
              </span>
            </div>
            <p className="text-xs text-white/80 max-w-2xl leading-relaxed">
              ফোন নম্বর পরিবর্তন, প্রোফাইল ছবি ভেরিফিকেশন এবং যাতায়াতকালে চালক-যাত্রী সেবা গ্রহণের তারিখ, সময় ও গাড়ির বিবরণ যা কোনো ব্যবহারকারী ইচ্ছেমতো মুছে ফেলতে পারবেন না। এটি যেকোনো অনাকাঙ্ক্ষিত ঘটনা তদন্তে আইনগত সহায়ক হিসেবে কাজ করে।
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowOfficialDossier(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white text-[#1B365D] hover:bg-slate-50 font-bold text-xs shadow-xs transition cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-[#1B365D]" />
              <span>তদন্ত প্রতিবেদন ডসিয়ার</span>
            </button>
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-5 text-xs">
          <div className="bg-white/10 p-2.5 rounded-2xl backdrop-blur-xs">
            <span className="text-white/70 block text-[10px]">মোট সংরক্ষিত অডিট</span>
            <span className="font-bold text-sm text-white">{logs.length} টি রেকর্ড</span>
          </div>
          <div className="bg-white/10 p-2.5 rounded-2xl backdrop-blur-xs">
            <span className="text-[#D4E4BC] block text-[10px]">ভ্রমণ ও যাতায়াত হিস্ট্রি</span>
            <span className="font-bold text-sm text-[#D4E4BC]">{travelLogsCount} টি ট্রিপ</span>
          </div>
          <div className="bg-white/10 p-2.5 rounded-2xl backdrop-blur-xs">
            <span className="text-amber-300 block text-[10px]">মোবাইল পরিবর্তন ট্র্যাকিং</span>
            <span className="font-bold text-sm text-amber-300">{phoneLogsCount} বার (২৬ দিন লক)</span>
          </div>
          <div className="bg-white/10 p-2.5 rounded-2xl backdrop-blur-xs">
            <span className="text-emerald-300 block text-[10px]">সংরক্ষণ সময়সীমা</span>
            <span className="font-bold text-sm text-emerald-300">৩৬৫ দিন (অপরিবর্তনীয়)</span>
          </div>
        </div>
      </div>

      {/* Safety Notice & Privacy Reassurance Bar */}
      <div className="mx-4 sm:mx-6 p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-start gap-2.5 text-xs text-emerald-950">
        <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-bold text-emerald-900">
            🛡️ আপনার নিরাপত্তার স্বার্থে এই তথ্যটি সংরক্ষিত থাকছে এবং এটি সম্পূর্ণ সুরক্ষিত।
          </p>
          <p className="text-[11px] text-emerald-800 leading-relaxed">
            আপনার এই তথ্য সম্পূর্ণ ব্যক্তিগত ও এনক্রিপ্ট করা। কোনো সাধারণ ব্যবহারকারী বা তৃতীয় পক্ষ এটি দেখতে পারে না। প্ল্যাটফর্মের সততা রক্ষা, অপরাধ দমন ও প্রয়োজনে আইনি অনুসন্ধানের জন্য ৩৬৫ দিন অপরিবর্তনীয় অডিট ট্রেইল হিসেবে সংরক্ষিত থাকে।
          </p>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="px-4 sm:px-6 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          {/* Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 bg-[#FAF8F5] p-1 rounded-2xl border border-[#E6E0D4] text-xs">
            <button
              type="button"
              onClick={() => setSelectedFilter('all')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
                selectedFilter === 'all' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
              }`}
            >
              সকল রেকর্ড ({logs.length})
            </button>
            <button
              type="button"
              onClick={() => setSelectedFilter('travel_trip')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1 ${
                selectedFilter === 'travel_trip' ? 'bg-[#1B365D] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
              }`}
            >
              <Car className="w-3.5 h-3.5" />
              <span>যাতায়াত ও ভ্রমণ ({travelLogsCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedFilter('phone_change')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1 ${
                selectedFilter === 'phone_change' ? 'bg-[#C0392B] text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
              }`}
            >
              <Phone className="w-3.5 h-3.5" />
              <span>ফোন পরিবর্তন ({phoneLogsCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedFilter('photo_change')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1 ${
                selectedFilter === 'photo_change' ? 'bg-purple-700 text-white shadow-xs' : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>ছবি ও ফেস স্ক্যান ({photoLogsCount})</span>
            </button>
          </div>

          {/* Month Filter Dropdown */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex items-center bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-1.5 text-xs text-[#2D3A3A]">
              <Calendar className="w-3.5 h-3.5 text-[#2D5A27] mr-1.5" />
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-transparent font-bold focus:outline-none cursor-pointer pr-3"
              >
                <option value="all">📅 সকল মাস (১ বছরের রেকর্ড)</option>
                {availableMonths.map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>

            {/* Search Box */}
            <div className="relative flex-1 sm:w-60">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="ট্রিপ, রুট বা কোড খুঁজুন..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl pl-8 pr-3 py-1.5 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
              />
            </div>
          </div>
        </div>

        {/* Timeline Log Entries List - Grouped by Month */}
        <div className="space-y-4 pb-6">
          {filteredLogs.length === 0 ? (
            <div className="text-center py-10 bg-[#FAF8F5] rounded-3xl border border-dashed border-[#E6E0D4] p-6 space-y-2">
              <ShieldCheck className="w-10 h-10 text-gray-300 mx-auto" />
              <p className="text-xs font-bold text-[#2D3A3A]">কোনো লগ রেকর্ড পাওয়া যায়নি</p>
              <p className="text-[11px] text-[#736B5E]">
                {selectedFilter === 'travel_trip' 
                  ? 'ব্যবহারকারী পরিবহন বিভাগ ব্যবহার করে চালকের সাথে ভ্রমণ সংযোগ স্থাপন করলে এখানে স্বয়ংক্রিয়ভাবে লিপিবদ্ধ হবে।'
                  : 'অন্যান্য ফিল্টার পরিবর্তন করে দেখতে পারেন।'}
              </p>
            </div>
          ) : (
            groupedLogsByMonth.map((group) => (
              <div key={group.monthLabel} className="space-y-2.5">
                {/* Month Separator Header */}
                <div className="flex items-center gap-2 pt-2">
                  <div className="flex items-center gap-1.5 bg-[#2D5A27] text-white px-3 py-1 rounded-full text-xs font-bold shadow-xs">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{group.monthLabel}</span>
                  </div>
                  <div className="flex-1 h-px bg-[#E6E0D4]" />
                  <span className="text-[11px] text-[#736B5E] font-medium">({group.items.length} টি কার্যক্রম)</span>
                </div>

                {group.items.map((log) => {
                  const isTravel = log.category === 'travel_trip';
                  const isPhone = log.category === 'phone_change';
                  const isPhoto = log.category === 'photo_change';

                  return (
                    <div
                      key={log.id}
                      className="bg-[#FAF8F5] hover:bg-[#FDFBF7] p-4 rounded-2xl border border-[#E6E0D4] transition shadow-2xs space-y-2.5"
                    >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E6E0D4]/70 pb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                        isTravel 
                          ? 'bg-[#1B365D] text-white' 
                          : isPhone 
                            ? 'bg-[#C0392B] text-white' 
                            : isPhoto 
                              ? 'bg-purple-700 text-white' 
                              : 'bg-[#2D5A27] text-white'
                      }`}>
                        {isTravel && <Car className="w-4 h-4" />}
                        {isPhone && <Phone className="w-4 h-4" />}
                        {isPhoto && <Camera className="w-4 h-4" />}
                        {!isTravel && !isPhone && !isPhoto && <ShieldCheck className="w-4 h-4" />}
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">{log.categoryTitle}</h4>
                          <span className="text-[10px] bg-white border border-[#D4C3A3] text-[#5A6B6B] px-2 py-0.5 rounded-full font-mono font-semibold">
                            {log.auditHash}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#736B5E] flex items-center gap-1">
                          <Clock className="w-3 h-3 text-[#E8924A]" />
                          <span>{log.formattedDate}</span>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-start sm:self-auto">
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-300 px-2 py-0.5 rounded-full">
                        সংরক্ষণ বাকি: {log.retentionDaysLeft} দিন
                      </span>
                    </div>
                  </div>

                  {/* Summary & Detailed Metadata */}
                  <div className="text-xs text-[#2D3A3A] space-y-2">
                    <p className="font-semibold text-slate-800 leading-relaxed">
                      {log.summary}
                    </p>

                    {/* Travel Details Box (When & Where travel took place) */}
                    {isTravel && (
                      <div className="p-3 bg-white rounded-xl border border-[#C7D2FE]/60 space-y-1.5 text-xs">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                          {log.details.driverName && (
                            <div>
                              <span className="text-[#5A6B6B]">🚗 চালকের নাম: </span>
                              <strong className="text-[#1B365D]">{log.details.driverName}</strong>
                            </div>
                          )}
                          {log.details.vehicleNumber && (
                            <div>
                              <span className="text-[#5A6B6B]">গাড়ির প্লেট/নম্বর: </span>
                              <strong className="text-[#2D3A3A] bg-slate-100 px-1.5 py-0.2 rounded font-mono">{log.details.vehicleNumber}</strong>
                            </div>
                          )}
                          {log.details.passengerName && (
                            <div>
                              <span className="text-[#5A6B6B]">👤 যাত্রী: </span>
                              <strong className="text-[#2D5A27]">{log.details.passengerName}</strong>
                            </div>
                          )}
                          {log.details.driverPhoneMasked && (
                            <div>
                              <span className="text-[#5A6B6B]">📞 যোগাযোগ: </span>
                              <strong className="text-[#2D3A3A]">{log.details.driverPhoneMasked}</strong>
                            </div>
                          )}
                          {log.details.tripFrom && (
                            <div>
                              <span className="text-[#5A6B6B]">📍 প্রারম্ভিক স্থান: </span>
                              <strong>{log.details.tripFrom}</strong>
                            </div>
                          )}
                          {log.details.tripTo && (
                            <div>
                              <span className="text-[#5A6B6B]">🏁 গন্তব্য রুট: </span>
                              <strong>{log.details.tripTo}</strong>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Phone Change Details Box */}
                    {isPhone && (
                      <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs space-y-1">
                        <div className="flex items-center gap-3 flex-wrap">
                          <span>পুরনো নম্বর: <strong className="line-through text-red-700">{log.details.oldPhone}</strong></span>
                          <span>➔</span>
                          <span>নতুন নম্বর: <strong className="text-emerald-800">{log.details.newPhone}</strong></span>
                          {log.details.otpStatus && (
                            <span className="text-[10px] bg-emerald-100 text-emerald-900 px-1.5 py-0.2 rounded font-bold">
                              ✓ {log.details.otpStatus}
                            </span>
                          )}
                        </div>
                        {log.details.notes && (
                          <p className="text-[11px] text-amber-900 pt-0.5">{log.details.notes}</p>
                        )}
                      </div>
                    )}

                    {/* General Notes */}
                    {!isTravel && !isPhone && log.details.notes && (
                      <p className="text-[11px] text-[#5A6B6B] bg-white p-2.5 rounded-xl border border-[#E6E0D4]">
                        {log.details.notes}
                      </p>
                    )}
                  </div>
                    </div>
                  );
                })}
              </div>
            ))
          )}
        </div>
      </div>

      {/* OFFICIAL DOSSIER MODAL (Printable / Investigation Dossier - 1-2 Pages Standard A4) */}
      {showOfficialDossier && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          {/* Dedicated A4 Print Style Injection */}
          <style>{`
            @media print {
              @page {
                size: A4 portrait;
                margin: 6mm 8mm;
              }
              html, body {
                height: auto !important;
                min-height: 0 !important;
                max-height: none !important;
                margin: 0 !important;
                padding: 0 !important;
                background: white !important;
                color: #0f172a !important;
                overflow: visible !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
              /* Collapse background application to prevent page sprawl and empty pages */
              #root {
                height: 0 !important;
                max-height: 0 !important;
                overflow: visible !important;
              }
              body * {
                visibility: hidden !important;
              }
              #printable-security-dossier, #printable-security-dossier * {
                visibility: visible !important;
              }
              #printable-security-dossier {
                position: absolute !important;
                left: 0 !important;
                top: 0 !important;
                width: 100% !important;
                max-width: 100% !important;
                height: auto !important;
                margin: 0 !important;
                padding: 4mm 6mm !important;
                border: 1px solid #cbd5e1 !important;
                box-shadow: none !important;
                background: white !important;
                overflow: visible !important;
                z-index: 999999 !important;
                box-sizing: border-box !important;
                page-break-after: auto !important;
                break-after: auto !important;
              }
              .no-print, .no-print * {
                display: none !important;
                visibility: hidden !important;
              }
              table {
                page-break-inside: auto !important;
                break-inside: auto !important;
                width: 100% !important;
                table-layout: fixed !important;
                border-collapse: collapse !important;
              }
              tr {
                page-break-inside: avoid !important;
                break-inside: avoid !important;
              }
              thead {
                display: table-header-group !important;
              }
            }
          `}</style>

          <div 
            id="printable-security-dossier"
            className="bg-white rounded-3xl max-w-3xl w-full p-5 sm:p-7 shadow-2xl border border-slate-300 space-y-4 animate-in fade-in duration-200 my-auto text-[#2D3A3A]"
          >
            {/* Dossier Header */}
            <div className="flex items-start justify-between border-b-2 border-slate-800 pb-3">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-slate-900 text-white rounded-xl no-print">
                    <Building className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="font-bold text-base sm:text-lg text-slate-900 leading-tight">
                      ডিজিটাল পল্লী সেবা নিরাপত্তা অডিট ডসিয়ার
                    </h2>
                    <p className="text-[11px] text-slate-600">
                      আইনশৃঙ্খলা ও তদন্ত সহায়ক অফিশিয়াল ডিজিটাল প্রতিবেদন (১ বছর অপরিবর্তনীয় রেকর্ড)
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 no-print">
                <button
                  type="button"
                  onClick={handlePrintDossier}
                  className="flex items-center gap-1.5 bg-[#1B365D] hover:bg-[#132742] text-white px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>প্রিন্ট / PDF ডাউনলোড</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowOfficialDossier(false)}
                  className="p-1.5 text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Verification Stamp & Subject Details (Compact Grid) */}
            <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200 text-[11px] leading-relaxed">
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">নাগরিক পরিচয় বিবরণ</span>
                <p>নাম: <strong className="text-slate-900 font-bold">{user.name}</strong></p>
                <p>মোবাইল: <strong className="font-mono">{user.phone}</strong> (OTP ভেরিফাইড)</p>
                <p>ভূমিকা: <strong>{user.role}</strong></p>
                <p>ঠিকানা: <span>{user.village ? `${user.village}, ` : ''}{user.union}, {user.upazila}, {user.district}</span></p>
              </div>

              <div className="space-y-0.5 border-l border-slate-200 pl-3">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">তদন্ত ও ডাটা অডিট নিরাপত্তা সীল</span>
                <p>অডিট আইডি: <strong className="font-mono text-[#1B365D]">{user.id}</strong></p>
                <p>সংরক্ষণ সময়সীমা: <strong>৩৬৫ দিন (১ বছর অপরিবর্তনীয়)</strong></p>
                <p>প্রতিবেদন প্রকাশের তারিখ: <strong>{new Date().toLocaleString('bn-BD')}</strong></p>
                <div className="pt-0.5 flex items-center gap-1 text-emerald-800 font-bold text-[10px]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>ডিজিটাল ক্রিপ্টোগ্রাফিক সীল দ্বারা সুরক্ষিত</span>
                </div>
              </div>
            </div>

            {/* TABLE 1: যাতায়াত ও ভ্রমণ ইতিহাস (Travel & Trip History) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <Car className="w-3.5 h-3.5 text-[#1B365D]" />
                  <span>১. যাতায়াত ও ভ্রমণ ইতিহাস (Travel & Trip Log)</span>
                </h4>
                <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded font-bold text-slate-700">
                  মোট ট্রিপ: {logs.filter(l => l.category === 'travel_trip').length} টি
                </span>
              </div>

              <div className="border border-slate-300 rounded-xl overflow-hidden">
                <table className="table-fixed w-full text-left text-[11px] border-collapse">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                    <tr>
                      <th className="p-2 w-[22%]">তারিখ ও সময়</th>
                      <th className="p-2 w-[28%]">চালক ও গাড়ির নম্বর</th>
                      <th className="p-2 w-[35%]">রুট ও সেবা বিবরণ</th>
                      <th className="p-2 w-[15%]">অডিট হ্যাশ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {logs.filter(l => l.category === 'travel_trip').length === 0 ? (
                      <tr>
                        <td colSpan={4} className="p-3 text-center text-slate-500 italic text-[11px]">
                          কোনো যাতায়াত বা ভ্রমণ রেকর্ড এখনও নিবন্ধিত হয়নি।
                        </td>
                      </tr>
                    ) : (
                      logs.filter(l => l.category === 'travel_trip').map((log, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="p-2 font-medium break-words align-top">{log.formattedDate}</td>
                          <td className="p-2 align-top break-words">
                            <div>
                              <strong>{log.details.driverName || 'চালকের নাম'}</strong>
                              {log.details.vehicleNumber && (
                                <span className="block text-slate-600 font-mono text-[10px]">
                                  প্লেট: {log.details.vehicleNumber}
                                </span>
                              )}
                              {log.details.driverPhoneMasked && (
                                <span className="block text-slate-500 text-[10px]">
                                  যোগাযোগ: {log.details.driverPhoneMasked}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-2 text-slate-700 break-words align-top">
                            {log.details.tripFrom && log.details.tripTo ? (
                              <div>
                                <span className="font-semibold text-slate-900">{log.details.tripFrom} ➔ {log.details.tripTo}</span>
                                <span className="block text-slate-500 text-[10px]">{log.summary}</span>
                              </div>
                            ) : (
                              log.summary
                            )}
                          </td>
                          <td className="p-2 font-mono text-[10px] text-slate-600 break-all align-top">{log.auditHash}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* TABLE 2: অ্যাকাউন্ট ও নিরাপত্তা পরিবর্তন ইতিহাস (Account & Security Change History) */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#2D5A27]" />
                  <span>২. অ্যাকাউন্ট ও নিরাপত্তা পরিবর্তন ইতিহাস (Account & Security Audit Log)</span>
                </h4>
                <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded font-bold text-slate-700">
                  মোট ইভেন্ট: {logs.filter(l => l.category !== 'travel_trip').length} টি
                </span>
              </div>

              <div className="border border-slate-300 rounded-xl overflow-hidden">
                <table className="table-fixed w-full text-left text-[11px] border-collapse">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                    <tr>
                      <th className="p-2 w-[22%]">তারিখ ও সময়</th>
                      <th className="p-2 w-[22%]">ইভেন্ট ক্যাটাগরি</th>
                      <th className="p-2 w-[41%]">নিরাপত্তা বিবরণ ও অডিট মান</th>
                      <th className="p-2 w-[15%]">অডিট হ্যাশ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {logs.filter(l => l.category !== 'travel_trip').length === 0 ? (
                      <tr>
                        <td colSpan={4} className="p-3 text-center text-slate-500 italic text-[11px]">
                          কোনো নিরাপত্তা পরিবর্তন রেকর্ড পাওয়া যায়নি।
                        </td>
                      </tr>
                    ) : (
                      logs.filter(l => l.category !== 'travel_trip').map((log, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="p-2 font-medium break-words align-top">{log.formattedDate}</td>
                          <td className="p-2 align-top break-words">
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-800 inline-block">
                              {log.categoryTitle}
                            </span>
                          </td>
                          <td className="p-2 text-slate-700 break-words align-top">
                            <div className="space-y-0.5">
                              <span className="font-semibold text-slate-900 block">{log.summary}</span>
                              {log.details.oldPhone && log.details.newPhone && (
                                <span className="block text-[10px] text-amber-800">
                                  পুরাতন: <span className="line-through">{log.details.oldPhone}</span> ➔ নতুন: <strong>{log.details.newPhone}</strong> ({log.details.otpStatus || 'OTP যাচাইকৃত'})
                                </span>
                              )}
                              {log.details.notes && (
                                <span className="block text-[10px] text-slate-500">{log.details.notes}</span>
                              )}
                            </div>
                          </td>
                          <td className="p-2 font-mono text-[10px] text-slate-600 break-all align-top">{log.auditHash}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Statutory Declaration */}
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-[10px] text-slate-600 leading-relaxed flex items-center justify-between">
              <span><strong>আইনগত ঘোষণা:</strong> এই অডিট ডসিয়ারে প্রদর্শিত তথ্য ডিজিটাল পল্লি সেবা ক্লাউড ডাটাবেজ থেকে সরাসরি সংগৃহীত। এটি ৩৬৫ দিন অপরিবর্তনীয় ও ক্রিপ্টোগ্রাফিকভাবে সুরক্ষিত।</span>
              <span className="font-mono text-[9px] text-slate-400 shrink-0 ml-2">পৃষ্ঠা ১-২ (স্ট্যান্ডার্ড A4)</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
