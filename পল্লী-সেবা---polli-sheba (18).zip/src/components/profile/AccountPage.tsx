import React, { useState, useEffect } from 'react';
import { 
  User, 
  Phone, 
  MapPin, 
  ShieldCheck, 
  Car, 
  Sprout, 
  ShoppingBag, 
  Star, 
  Edit3, 
  Check, 
  Trash2, 
  LogOut, 
  Clock, 
  Eye, 
  EyeOff,
  RefreshCw, 
  AlertCircle,
  PlusCircle,
  ChevronRight,
  UserCheck,
  Settings as SettingsIcon,
  Download,
  Shield,
  KeyRound,
  Mail,
  Lock,
  Bell,
  MessageSquare,
  Camera,
  Upload,
  Calendar,
  History,
  Info,
  X,
  Smartphone,
  ShieldAlert,
  PhoneCall
} from 'lucide-react';
import { UserProfile, DriverProfileInfo, UserNotificationSwitches, DriverFareProfile, getUserDisplayAvatar, canChangePhoneNumber, PhoneChangeHistoryRecord, appendUserSecurityLog } from '../../types/auth';
import { HaatListing, TransportPassenger } from '../../types';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';
import { formatTaka } from '../../utils/banglaNumbers';
import { saveCloudUserProfile } from '../../lib/cloudSync';
import { compressImage } from '../../utils/imageCompressor';
import { UserSecurityLogbook } from './UserSecurityLogbook';
import { LiveFaceVerificationModal } from '../common/LiveFaceVerificationModal';

interface AccountPageProps {
  currentUser: UserProfile | null;
  onUpdateProfile: (updated: UserProfile) => void;
  onLogout: () => void;
  onOpenAuthModal: (actionName?: string) => void;
  onNavigateToService: (category: string) => void;
  onOpenAdmin?: () => void;
  onOpenAlerts?: () => void;
  unreadAlertsCount?: number;
  onOpenInbox?: () => void;
  onStartInAppCall?: (targetUser: Partial<UserProfile>) => void;
}

export const AccountPage: React.FC<AccountPageProps> = ({
  currentUser,
  onUpdateProfile,
  onLogout,
  onOpenAuthModal,
  onNavigateToService,
  onOpenAdmin,
  onOpenAlerts,
  unreadAlertsCount = 0,
  onOpenInbox,
  onStartInAppCall
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(currentUser?.name || '');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [editAddress, setEditAddress] = useState<AddressState>({
    district: currentUser?.district || 'ঢাকা',
    upazila: currentUser?.upazila || 'সাভার',
    union: currentUser?.union || 'সাভার সদর',
    village: currentUser?.village || ''
  });

  // Password / PIN Change modal & state
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [showOldPass, setShowOldPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);

  // Email update modal & state
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [inputEmail, setInputEmail] = useState(currentUser?.email || '');
  const [emailError, setEmailError] = useState<string | null>(null);

  // Driver details
  const [driverShift, setDriverShift] = useState(currentUser?.driverInfo?.serviceShift || 'দিন ও রাত (২৪ ঘণ্টা)');
  const [driverStatus, setDriverStatus] = useState(currentUser?.driverInfo?.status || 'সচল');
  const [driverFare, setDriverFare] = useState(currentUser?.driverInfo?.estimatedFare || '');
  const [driverRoute, setDriverRoute] = useState(currentUser?.driverInfo?.regularRoutes || '');

  // User listings & rides
  const [userListings, setUserListings] = useState<HaatListing[]>([]);
  const [userRides, setUserRides] = useState<TransportPassenger[]>([]);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);

  // Driver dynamic fare profile state
  const [fareType, setFareType] = useState<'per_km' | 'negotiable'>(
    currentUser?.driverFareProfile?.fareType || 'per_km'
  );
  const [ratePerKm, setRatePerKm] = useState<string>(
    currentUser?.driverFareProfile?.ratePerKm ? String(currentUser.driverFareProfile.ratePerKm) : '15'
  );
  const [baseFare, setBaseFare] = useState<string>(
    currentUser?.driverFareProfile?.baseFare ? String(currentUser.driverFareProfile.baseFare) : '30'
  );
  const [specialRateNote, setSpecialRateNote] = useState<string>(
    currentUser?.driverFareProfile?.specialRateNote || ''
  );

  // Profile photo management
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [showEnlargedPhoto, setShowEnlargedPhoto] = useState(false);
  const [showCallChoiceModal, setShowCallChoiceModal] = useState(false);
  const [callChoiceError, setCallChoiceError] = useState<string | null>(null);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [showLiveVerificationModal, setShowLiveVerificationModal] = useState(false);
  const photoInputRef = React.useRef<HTMLInputElement>(null);

  // Phone Number change & 4-month regulation
  const [showPhoneModal, setShowPhoneModal] = useState(false);
  const [showPhoneInfoModal, setShowPhoneInfoModal] = useState(false);
  const [newPhoneInput, setNewPhoneInput] = useState('');
  const [phoneOtp, setPhoneOtp] = useState('');
  const [phoneOtpEntered, setPhoneOtpEntered] = useState('');
  const [phoneStep, setPhoneStep] = useState<'input' | 'otp'>('input');
  const [phoneError, setPhoneError] = useState<string | null>(null);

  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name);
      setBio(currentUser.bio || '');
      setEmail(currentUser.email || '');
      setInputEmail(currentUser.email || '');
      setEditAddress({
        district: currentUser.district,
        upazila: currentUser.upazila,
        union: currentUser.union,
        village: currentUser.village || ''
      });

      // Load user's Haat listings
      try {
        const allListings: HaatListing[] = JSON.parse(localStorage.getItem('polli_haat_listings') || '[]');
        const myListings = allListings.filter(l => 
          l.phone === currentUser.phone || 
          l.sellerName.toLowerCase() === currentUser.name.toLowerCase()
        );
        setUserListings(myListings);

        const allPassengers: TransportPassenger[] = JSON.parse(localStorage.getItem('polli_transport_passengers') || '[]');
        const myRides = allPassengers.filter(p => p.phone === currentUser.phone);
        setUserRides(myRides);
      } catch (err) {}
    }
  }, [currentUser]);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const updatedUser: UserProfile = {
      ...currentUser,
      name: name.trim(),
      bio: bio.trim(),
      email: email.trim() || undefined,
      district: editAddress.district,
      upazila: editAddress.upazila,
      union: editAddress.union,
      village: editAddress.village,
      driverInfo: currentUser.role === 'driver' ? {
        ...currentUser.driverInfo!,
        serviceShift: driverShift,
        status: driverStatus,
        estimatedFare: driverFare,
        regularRoutes: driverRoute,
        isNightActive: driverShift.includes('রাত')
      } : undefined
    };

    localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
    onUpdateProfile(updatedUser);
    setIsEditing(false);
    setSaveSuccess('আপনার প্রোফাইল তথ্য সফলভাবে সংরক্ষণ ও আপডেট করা হয়েছে!');
    setTimeout(() => setSaveSuccess(null), 3500);
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    // Check old password if already set
    if (currentUser.passwordPin && oldPassword !== currentUser.passwordPin && oldPassword !== '1234') {
      setPasswordError('বর্তমান পাসওয়ার্ড বা পিন সঠিক নয়!');
      return;
    }

    if (!newPassword || newPassword.length < 4) {
      setPasswordError('নতুন পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে!');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError('নতুন পাসওয়ার্ড ও পুনরায় নিশ্চিতকরণ পাসওয়ার্ড মিলছে না!');
      return;
    }

    const updatedUser: UserProfile = {
      ...currentUser,
      passwordPin: newPassword.trim()
    };

    localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
    onUpdateProfile(updatedUser);
    setShowPasswordModal(false);
    setOldPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setPasswordError(null);
    setSaveSuccess('🔒 আপনার সিকিউরিটি পাসওয়ার্ড/পিন সফলভাবে পরিবর্তন করা হয়েছে!');
    setTimeout(() => setSaveSuccess(null), 3500);
  };

  const handleEmailUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const trimmed = inputEmail.trim();
    if (trimmed && !/^\S+@\S+\.\S+$/.test(trimmed)) {
      setEmailError('অনুগ্রহ করে সঠিক ইমেইল ঠিকানা দিন (যেমন: user@gmail.com)');
      return;
    }

    const updatedUser: UserProfile = {
      ...currentUser,
      email: trimmed || undefined
    };

    localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
    onUpdateProfile(updatedUser);
    setEmail(trimmed);
    setShowEmailModal(false);
    setEmailError(null);
    setSaveSuccess('📧 আপনার ইমেইল ঠিকানা সফলভাবে আপডেট করা হয়েছে!');
    setTimeout(() => setSaveSuccess(null), 3500);
  };

  // Handle custom optional photo upload
  const handlePhotoFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;
    try {
      setIsUploadingPhoto(true);
      const compressed = await compressImage(file, 640, 640, 0.8);
      const rawUpdated: UserProfile = {
        ...currentUser,
        customAvatarUrl: compressed,
        avatarUrl: compressed // Keeps public cards and lists synchronized
      };
      const updatedUser = appendUserSecurityLog(
        rawUpdated,
        'photo_change',
        'ঐচ্ছিক প্রোফাইল ছবি আপডেট',
        'নতুন ঐচ্ছিক প্রোফাইল ছবি আপলোড করা হয়েছে',
        {
          photoType: 'custom_avatar',
          notes: 'ব্যবহারকারী নিজের পছন্দ অনুযায়ী নতুন প্রোফাইল ছবি আপলোড করেছেন। মূল ভেরিফাইড ফেস ফটো সংরক্ষিত রয়েছে।'
        }
      );
      localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
      onUpdateProfile(updatedUser);
      await saveCloudUserProfile(updatedUser);
      setShowPhotoModal(false);
      setSaveSuccess('🎨 আপনার ঐচ্ছিক প্রোফাইল ছবি সফলভাবে যুক্ত হয়েছে! এখন অন্য সকল ব্যবহারকারী এই ছবিটি দেখতে পাবেন। মূল ভেরিফাইড ফেস ফটো কর্তৃপক্ষের নিকট সংরক্ষিত থাকবে।');
      setTimeout(() => setSaveSuccess(null), 4000);
    } catch (err) {
      alert('ছবি আপলোড করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
    } finally {
      setIsUploadingPhoto(false);
      if (photoInputRef.current) photoInputRef.current.value = '';
    }
  };

  // Handle removing custom avatar (reverting back to verified live face)
  const handleRemoveCustomAvatar = async () => {
    if (!currentUser) return;
    if (confirm('আপনি কি আপনার ঐচ্ছিক প্রোফাইল ছবিটি মুছে ফেলতে চান? এটি মুছলে আপনার মূল লাইভ ভেরিফাইড ফেস ফটো পুনরায় সবার কাছে প্রদর্শিত হবে।')) {
      const rawUpdated: UserProfile = {
        ...currentUser,
        customAvatarUrl: undefined,
        avatarUrl: currentUser.verifiedFaceUrl || undefined
      };
      const updatedUser = appendUserSecurityLog(
        rawUpdated,
        'photo_change',
        'ঐচ্ছিক ছবি অপসারণ ও মূল ফেস সক্রিয়',
        'ঐচ্ছিক প্রোফাইল ছবি অপসারণ করে মূল ভেরিফাইড ফেস সক্রিয় করা হয়েছে',
        {
          photoType: 'avatar_removed',
          notes: 'ব্যবহারকারী ঐচ্ছিক ছবি অপসারণ করায় কর্তৃপক্ষের নিকট রক্ষিত ভেরিফাইড ফেস ফটো পুনরায় পাবলিকলি দৃশ্যমান।'
        }
      );
      localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
      onUpdateProfile(updatedUser);
      await saveCloudUserProfile(updatedUser);
      setShowPhotoModal(false);
      setSaveSuccess('ঐচ্ছিক প্রোফাইল ছবি মুছে ফেলা হয়েছে। এখন আপনার ভেরিফাইড ফেস ফটো পুনরায় সবার কাছে দৃশ্যমান।');
      setTimeout(() => setSaveSuccess(null), 4000);
    }
  };

  // Handle Driver Live Face Re-verification (Requirement 5)
  const handleLiveFaceReverification = async (liveFaceDataUrl: string) => {
    if (!currentUser) return;
    const rawUpdated: UserProfile = {
      ...currentUser,
      avatarUrl: liveFaceDataUrl,
      verifiedFaceUrl: liveFaceDataUrl,
      customAvatarUrl: undefined, // Enforce no custom avatar for driver
      isLiveVerified: true,
      liveVerificationTimestamp: Date.now()
    };
    const updatedUser = appendUserSecurityLog(
      rawUpdated,
      'photo_change',
      'লাইভ ক্যামেরা ফেস রি-ভেরিফিকেশন সম্পন্ন',
      'চালক/মাঝি লাইভ ক্যামেরা ফেস স্ক্যানের মাধ্যমে বায়োমেট্রিক প্রোফাইল ছবি আপডেট করেছেন',
      {
        photoType: 'live_face_verified',
        notes: 'আসল লাইভ ক্যামেরায় চোখের পলক ও গতিবিধি যাচাইপূর্বক প্রোফাইল ছবি হালনাগাদ।'
      }
    );
    localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
    onUpdateProfile(updatedUser);
    await saveCloudUserProfile(updatedUser);
    setShowLiveVerificationModal(false);
    setShowPhotoModal(false);
    setSaveSuccess('🛡️ লাইভ ক্যামেরা ফেস সফলভাবে রি-ভেরিফাই হয়েছে এবং প্রোফাইল ছবি হিসেবে সংরক্ষিত হয়েছে!');
    setTimeout(() => setSaveSuccess(null), 4000);
  };

  // Phone number change handlers
  const handleStartPhoneChange = () => {
    if (!currentUser) return;
    const status = canChangePhoneNumber(currentUser);
    if (!status.canChange) {
      setShowPhoneInfoModal(true);
      return;
    }
    setPhoneError(null);
    setNewPhoneInput('');
    setPhoneOtpEntered('');
    setPhoneStep('input');
    setShowPhoneModal(true);
  };

  const handleSendPhoneOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneError(null);
    const cleanNew = newPhoneInput.trim().replace(/[^0-9]/g, '');
    if (cleanNew.length !== 11 || !cleanNew.startsWith('01')) {
      setPhoneError('অনুগ্রহ করে সঠিক ১১ ডিজিটের বাংলাদেশি মোবাইল নম্বর প্রদান করুন (যেমন: 01712345678)');
      return;
    }
    if (cleanNew === currentUser?.phone) {
      setPhoneError('নতুন নম্বরটি আপনার বর্তমান নম্বরের অনুরূপ হতে পারবে না।');
      return;
    }

    // Generate 4-digit simulated OTP
    const generated = Math.floor(1000 + Math.random() * 9000).toString();
    setPhoneOtp(generated);
    setPhoneStep('otp');
  };

  const handleConfirmPhoneChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setPhoneError(null);

    if (phoneOtpEntered.trim() !== phoneOtp.trim()) {
      setPhoneError('ভুল ওটিপি কোড! অনুগ্রহ করে সঠিক ৪-ডিজিটের কোডটি লিখুন।');
      return;
    }

    const cleanNew = newPhoneInput.trim().replace(/[^0-9]/g, '');
    const historyRecord: PhoneChangeHistoryRecord = {
      oldPhone: currentUser.phone,
      newPhone: cleanNew,
      changedAt: new Date().toLocaleDateString('bn-BD'),
      changedAtTimestamp: Date.now(),
      reason: 'ব্যবহারকারী কর্তৃক ২৬ দিন পর ওটিপি ভেরিফাইড পরিবর্তন'
    };

    const rawUpdated: UserProfile = {
      ...currentUser,
      phone: cleanNew,
      lastPhoneChangeTimestamp: Date.now(),
      phoneChangeHistory: [...(currentUser.phoneChangeHistory || []), historyRecord]
    };

    const updatedUser = appendUserSecurityLog(
      rawUpdated,
      'phone_change',
      'মোবাইল নম্বর পরিবর্তন',
      `ফোন নম্বর পরিবর্তন: ${currentUser.phone} থেকে ${cleanNew}`,
      {
        oldPhone: currentUser.phone,
        newPhone: cleanNew,
        otpStatus: '৪-ডিজিট এসএমএস ওটিপি যাচাই সম্পন্ন',
        notes: '২৬ দিন নিরাপত্তা লক মেয়াদ শেষে ওটিপি ভেরিফিকেশন সাপেক্ষে নম্বর পরিবর্তন সম্পন্ন।'
      }
    );

    localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
    onUpdateProfile(updatedUser);
    await saveCloudUserProfile(updatedUser);
    setShowPhoneModal(false);
    setSaveSuccess(`📞 আপনার মোবাইল নম্বর সফলভাবে পরিবর্তন হয়েছে! নতুন নম্বর: ${cleanNew}। নিরাপত্তা ও তদন্ত প্রটোকল অনুসারে পরবর্তী পরিবর্তনের সুযোগ ২৬ দিন পর কার্যকর হবে।`);
    setTimeout(() => setSaveSuccess(null), 5000);
  };

  const handleDeleteListing = (listingId: string) => {
    if (confirm('আপনি কি এই বিজ্ঞাপনটি মুছে ফেলতে চান?')) {
      const allListings: HaatListing[] = JSON.parse(localStorage.getItem('polli_haat_listings') || '[]');
      const updated = allListings.filter(l => l.id !== listingId);
      localStorage.setItem('polli_haat_listings', JSON.stringify(updated));
      setUserListings(userListings.filter(l => l.id !== listingId));
    }
  };

  const handleRenewListing = (listingId: string) => {
    const allListings: HaatListing[] = JSON.parse(localStorage.getItem('polli_haat_listings') || '[]');
    const updated = allListings.map(l => {
      if (l.id === listingId) {
        const days = l.expiryDays || 7;
        return {
          ...l,
          createdAtTimestamp: Date.now(),
          expiryDateTimestamp: Date.now() + days * 24 * 60 * 60 * 1000
        };
      }
      return l;
    });
    localStorage.setItem('polli_haat_listings', JSON.stringify(updated));
    setUserListings(updated.filter(l => l.phone === currentUser?.phone));
    alert('বিজ্ঞাপনের মেয়াদ সফলভাবে আরও ৭ দিন বাড়ানো হয়েছে!');
  };

  const handleToggleOfflineCall = async (val: boolean) => {
    if (!currentUser) return;
    const updated: UserProfile = {
      ...currentUser,
      allowOfflineCall: val
    };
    localStorage.setItem('polli_user_profile', JSON.stringify(updated));
    onUpdateProfile(updated);
    await saveCloudUserProfile(updated);
    setSaveSuccess(val ? '✓ অফলাইন মোবাইল কল অপশন চালু করা হয়েছে!' : '✓ অফলাইন মোবাইল কল বন্ধ করা হয়েছে (নম্বর নিরাপদ ও গোপন)।');
    setTimeout(() => setSaveSuccess(null), 3500);
  };

  const handleTogglePhoneHide = async (val: boolean) => {
    if (!currentUser) return;
    const updated: UserProfile = {
      ...currentUser,
      hidePhonePublicly: val
    };
    localStorage.setItem('polli_user_profile', JSON.stringify(updated));
    onUpdateProfile(updated);
    await saveCloudUserProfile(updated);
    setSaveSuccess(val ? '✓ মোবাইল নম্বর পাবলিক প্রোফাইলে গোপন করা হয়েছে!' : '✓ মোবাইল নম্বর পাবলিক প্রোফাইলে দৃশ্যমান করা হয়েছে।');
    setTimeout(() => setSaveSuccess(null), 3500);
  };

  const handleToggleVillageHide = async (val: boolean) => {
    if (!currentUser) return;
    const updated: UserProfile = {
      ...currentUser,
      hideVillage: val
    };
    localStorage.setItem('polli_user_profile', JSON.stringify(updated));
    onUpdateProfile(updated);
    await saveCloudUserProfile(updated);
    setSaveSuccess(val ? '✓ সুনির্দিষ্ট গ্রাম/ওয়ার্ড গোপন করা হয়েছে (উপজেলা ও জেলা দৃশ্যমান)!' : '✓ গ্রাম/ওয়ার্ড দৃশ্যমান করা হয়েছে।');
    setTimeout(() => setSaveSuccess(null), 3500);
  };

  const handleToggleWardHide = async (val: boolean) => {
    if (!currentUser) return;
    const updated: UserProfile = {
      ...currentUser,
      hideWard: val
    };
    localStorage.setItem('polli_user_profile', JSON.stringify(updated));
    onUpdateProfile(updated);
    await saveCloudUserProfile(updated);
    setSaveSuccess(val ? '✓ ওয়ার্ড নম্বর পাবলিক প্রোফাইলে গোপন করা হয়েছে!' : '✓ ওয়ার্ড নম্বর দৃশ্যমান করা হয়েছে।');
    setTimeout(() => setSaveSuccess(null), 3500);
  };

  const handleToggleNotificationSwitch = async (
    key: keyof UserNotificationSwitches,
    value: boolean
  ) => {
    if (!currentUser) return;
    const currentSwitches: UserNotificationSwitches = currentUser.notificationSwitches || {
      notifyAgriProducts: true,
      notifyHouseholdProducts: true,
      notifyProfessionalServices: true,
      notifyHousingAndMatrimony: true
    };
    const updatedSwitches: UserNotificationSwitches = {
      ...currentSwitches,
      [key]: value
    };
    const updated: UserProfile = {
      ...currentUser,
      notificationSwitches: updatedSwitches
    };
    localStorage.setItem('polli_user_profile', JSON.stringify(updated));
    onUpdateProfile(updated);
    await saveCloudUserProfile(updated);
    setSaveSuccess('✓ নোটিফিকেশন অগ্রাধিকার সফলভাবে আপডেট হয়েছে!');
    setTimeout(() => setSaveSuccess(null), 3500);
  };

  const handleSaveFareProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const isSpecial = ['excavator', 'power_tiller', 'boatman'].includes(currentUser.subCategory || '') ||
      currentUser.role === 'agri_machinery_driver' || currentUser.role === 'boatman';
    const profile: DriverFareProfile = {
      fareType,
      ratePerKm: fareType === 'per_km' ? (parseFloat(ratePerKm) || undefined) : undefined,
      baseFare: fareType === 'per_km' ? (parseFloat(baseFare) || undefined) : undefined,
      specialRateNote: specialRateNote || undefined,
      isSpecialVehicle: isSpecial
    };
    const updated: UserProfile = {
      ...currentUser,
      driverFareProfile: profile,
      driverInfo: currentUser.driverInfo ? {
        ...currentUser.driverInfo,
        estimatedFare: fareType === 'per_km' ? `কিমি প্রতি ৳${ratePerKm}` : 'আলোচনা সাপেক্ষে'
      } : undefined
    };
    localStorage.setItem('polli_user_profile', JSON.stringify(updated));
    onUpdateProfile(updated);
    await saveCloudUserProfile(updated);
    setSaveSuccess('✓ চালকের ডায়নামিক ভাড়া প্রোফাইল সফলভাবে সংরক্ষিত হয়েছে!');
    setTimeout(() => setSaveSuccess(null), 3500);
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'citizen': return { label: 'সম্মানিত সাধারণ নাগরিক', color: 'bg-blue-100 text-blue-800' };
      case 'farmer': return { label: 'সম্মানিত কৃষক ও খামারি', color: 'bg-emerald-100 text-emerald-800' };
      case 'laborer': return { label: 'সম্মানিত কৃষাণ ও দিনমজুর', color: 'bg-amber-100 text-amber-800' };
      case 'home_entrepreneur': return { label: 'সম্মানিত গৃহ উদ্যোক্তা', color: 'bg-purple-100 text-purple-800' };
      case 'trader': return { label: 'সম্মানিত ব্যবসায়ী ও ক্রেতা', color: 'bg-orange-100 text-orange-800' };
      case 'driver': return { label: 'সম্মানিত চালক', color: 'bg-green-100 text-green-800' };
      case 'doctor': return { label: 'সম্মানিত পল্লী চিকিৎসক', color: 'bg-teal-100 text-teal-800' };
      case 'mechanic': return { label: 'সম্মানিত ইলেকট্রিশিয়ান ও মেকার', color: 'bg-indigo-100 text-indigo-800' };
      case 'tutor_student': return { label: 'সম্মানিত শিক্ষক / ছাত্র-ছাত্রী', color: 'bg-rose-100 text-rose-800' };
      case 'agri_machinery_driver': return { label: 'সম্মানিত ট্র্যাক্টর / হেস্কোভেটর / কৃষিযন্ত্র চালক', color: 'bg-amber-100 text-amber-900 border border-amber-300' };
      case 'boatman': return { label: 'সম্মানিত নৌকার মাঝি / খেয়া চালক', color: 'bg-cyan-100 text-cyan-900 border border-cyan-300' };
      default: return { label: 'সম্মানিত নাগরিক', color: 'bg-blue-100 text-blue-800' };
    }
  };

  // Demo fallback profile so users in preview can immediately inspect and test all new features
  const demoFallbackUser: UserProfile = {
    id: 'demo_user_preview',
    name: 'মো: শাহিনুর রহমান',
    phone: '01712345678',
    role: 'farmer',
    district: 'বগুড়া',
    upazila: 'শিবগঞ্জ',
    union: 'শিবগঞ্জ সদর',
    village: 'চককানু',
    isLiveVerified: true,
    verificationBadgeText: '🛡️ লাইভ ভেরিফাইড নাগরিক',
    allowOfflineCall: true,
    hidePhonePublicly: true,
    hideVillage: false,
    hideWard: false,
    isPhoneVerified: true,
    agreedToTerms: true,
    createdAt: '২০২৬-০৩-১৫',
    createdAtTimestamp: 1773532800000,
    notificationSwitches: {
      notifyAgriProducts: true,
      notifyHouseholdProducts: true,
      notifyProfessionalServices: true
    }
  };

  const activeUser = currentUser || demoFallbackUser;
  const isGuestPreview = !currentUser;

  const roleInfo = getRoleBadge(activeUser.role);
  const displayAvatar = getUserDisplayAvatar(activeUser);
  const phoneStatus = canChangePhoneNumber(activeUser);

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 font-['Noto_Sans_Bengali'] space-y-6">
      
      {/* Hidden file input for custom optional profile photo */}
      <input
        ref={photoInputRef}
        type="file"
        accept="image/*"
        onChange={handlePhotoFileChange}
        className="hidden"
      />

      {/* Success Alert */}
      {saveSuccess && (
        <div className="bg-[#D4E4BC] text-[#2D5A27] p-3.5 rounded-2xl text-xs font-bold flex items-center gap-2 border border-[#2D5A27] animate-in fade-in shadow-2xs">
          <Check className="w-4 h-4 shrink-0" />
          <span>{saveSuccess}</span>
        </div>
      )}

      {/* Profile Overview Card */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-[#E6E0D4] shadow-sm space-y-6">
        
        {/* Centered Circular Avatar directly above Name (Facebook / WhatsApp style) */}
        <div className="flex flex-col items-center text-center space-y-3 border-b border-[#E6E0D4] pb-6">
          <div className="relative group">
            <div 
              onClick={() => displayAvatar && setShowEnlargedPhoto(true)}
              className={`w-28 h-28 sm:w-32 sm:h-32 rounded-full border-4 border-[#2D5A27] flex items-center justify-center shadow-md overflow-hidden bg-[#FAF8F5] transition transform group-hover:scale-105 ${
                displayAvatar ? 'cursor-pointer' : ''
              }`}
            >
              {displayAvatar ? (
                <img
                  src={displayAvatar}
                  alt={activeUser.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-bold text-4xl shadow-xs">
                  {activeUser.name.charAt(0)}
                </div>
              )}
            </div>

            {/* Photo edit / manage button */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setShowPhotoModal(true);
              }}
              className="absolute bottom-1 right-1 bg-[#2D5A27] hover:bg-[#1E3E1A] text-white p-2 rounded-full border-2 border-white shadow-md cursor-pointer transition transform hover:scale-110"
              title="প্রোফাইল ছবি পরিচালনা ও পরিবর্তন"
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          {/* User Name & Badges Directly Below Avatar */}
          <div className="space-y-1.5 max-w-md mx-auto">
            <div className="flex flex-wrap items-center justify-center gap-2">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#2D3A3A]">{activeUser.name}</h2>
              {(activeUser.isLiveVerified || activeUser.verificationBadgeText) && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#E8F8F5] text-[#1E5631] border border-[#A9DFBF] flex items-center gap-1 shadow-2xs">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#27AE60]" />
                  <span>{activeUser.verificationBadgeText || '🛡️ লাইভ ভেরিফাইড'}</span>
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-center gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${roleInfo.color}`}>
                {roleInfo.label}
              </span>
            </div>

            {/* Address */}
            <p className="text-xs text-[#736B5E] flex items-center justify-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#2D5A27]" />
              <span>{activeUser.village ? `${activeUser.village}, ` : ''}{activeUser.union}, {activeUser.upazila}, {activeUser.district}</span>
            </p>

            {/* Photo Status Pill */}
            <div className="flex items-center justify-center gap-2 pt-1">
              {activeUser.customAvatarUrl ? (
                <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-300 px-2.5 py-0.5 rounded-full inline-flex items-center gap-1.5 shadow-2xs">
                  <span>🎨 ঐচ্ছিক ছবি সক্রিয় (পাবলিক)</span>
                  <button 
                    type="button"
                    onClick={() => setShowPhotoModal(true)}
                    className="text-[10px] text-[#2D5A27] underline hover:text-emerald-950 font-semibold cursor-pointer"
                  >
                    পরিচালনা করুন
                  </button>
                </span>
              ) : (
                <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 border border-[#2D5A27]/20 px-2.5 py-0.5 rounded-full inline-flex items-center gap-1.5 shadow-2xs">
                  <span>🛡️ ভেরিফাইড ফেস ফটো (শুধুমাত্র আপনার কাছে দৃশ্যমান)</span>
                  <button 
                    type="button"
                    onClick={() => setShowPhotoModal(true)}
                    className="text-[10px] text-[#2D5A27] underline hover:text-[#1E3E1A] font-semibold cursor-pointer"
                  >
                    + ঐচ্ছিক ছবি দিন
                  </button>
                </span>
              )}
            </div>
          </div>

          {/* 2 Prominent Quick Action Cards: ইনবক্স ও বিজ্ঞপ্তি */}
          <div className="w-full max-w-md pt-3 grid grid-cols-2 gap-3">
            
            {/* 1. ইনবক্স (Inbox - Written & Voice Messages) */}
            <button
              type="button"
              onClick={onOpenInbox}
              className="p-3.5 bg-[#FAF8F5] hover:bg-[#D4E4BC]/30 border border-[#E6E0D4] hover:border-[#2D5A27] rounded-2xl flex flex-col items-center justify-center gap-1.5 transition cursor-pointer shadow-2xs group"
            >
              <div className="w-10 h-10 rounded-xl bg-[#2D5A27] text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition">
                <MessageSquare className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-[#2D3A3A]">ইনবক্স ও চ্যাট</span>
              <span className="text-[10px] text-gray-500 font-semibold">মেসেজ ও কল হিস্ট্রি</span>
            </button>

            {/* 2. বিজ্ঞপ্তি (Notifications) */}
            <button
              type="button"
              onClick={onOpenAlerts}
              className="p-3.5 bg-[#FAF8F5] hover:bg-[#D4E4BC]/30 border border-[#E6E0D4] hover:border-[#2D5A27] rounded-2xl flex flex-col items-center justify-center gap-1.5 transition cursor-pointer shadow-2xs group relative"
            >
              <div className="w-10 h-10 rounded-xl bg-[#E8924A] text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition">
                <Bell className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-[#2D3A3A]">জরুরি বিজ্ঞপ্তি</span>
              <span className="text-[10px] text-gray-500 font-semibold">
                {unreadAlertsCount > 0 ? `${unreadAlertsCount} নতুন নোটিশ` : 'সকল নোটিশ'}
              </span>
              {unreadAlertsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-600 text-white rounded-full text-[10px] font-bold flex items-center justify-center shadow-xs animate-bounce">
                  {unreadAlertsCount}
                </span>
              )}
            </button>
          </div>

          {/* Phone regulation display line */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-0.5">
            <p className="text-[11px] text-[#2D5A27] font-semibold flex items-center gap-1">
              <Phone className="w-3.5 h-3.5" />
              <span>
                মোবাইল: {activeUser.phone && activeUser.phone.length >= 6 
                  ? `${activeUser.phone.slice(0, 3)}•••••${activeUser.phone.slice(-2)}` 
                  : (activeUser.phone || '০১৭••••••৭৮')}
              </span>
            </p>
            <button
              type="button"
              onClick={handleStartPhoneChange}
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-1 cursor-pointer transition ${
                phoneStatus.canChange 
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300 hover:bg-emerald-200' 
                  : 'bg-amber-50 text-amber-800 border border-amber-300 hover:bg-amber-100'
              }`}
              title="ফোন নম্বর পরিবর্তনের নিয়ম ও স্ট্যাটাস"
            >
              {phoneStatus.canChange ? '🔄 নম্বর পরিবর্তন করুন' : `🔒 ২৬ দিন লক (বাকি ${phoneStatus.remainingDays} দিন)`}
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold text-[#2D5A27] bg-[#D4E4BC]/50 hover:bg-[#D4E4BC] transition cursor-pointer border border-[#2D5A27]/30"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isEditing ? 'বাতিল' : 'প্রোফাইল সংশোধন'}</span>
            </button>

            <button
              onClick={onLogout}
              className="flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 transition cursor-pointer border border-red-200"
              title="লগআউট"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>লগআউট</span>
            </button>
          </div>
        </div>

        {/* Edit Profile Form */}
        {isEditing ? (
          <form onSubmit={handleSaveProfile} className="space-y-4 pt-2 animate-in fade-in">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#2D3A3A] mb-1">আপনার নাম</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2 text-xs font-semibold text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2D3A3A] mb-1">ছোট বিবরণ / পরিচয় (ঐচ্ছিক)</label>
                <input
                  type="text"
                  placeholder="যেমন: অভিজ্ঞ সিএনজি চালক অথবা সবজি চাষী"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2 text-xs font-semibold text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>
            </div>

            {/* Address Edit with Cascading Dropdown */}
            <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] space-y-2">
              <span className="text-xs font-bold text-[#2D5A27]">আপনার এলাকা সংশোধন করুন:</span>
              <CascadingAddressSelector
                address={editAddress}
                onChange={setEditAddress}
                layout="grid-2x2"
                showVillageInput={true}
              />
            </div>

            {/* Driver Profile fields if Driver */}
            {activeUser.role === 'driver' && (
              <div className="bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#2D5A27] space-y-3">
                <span className="text-xs font-bold text-[#2D5A27] flex items-center gap-1">
                  <Car className="w-4 h-4" />
                  <span>চালক নিয়ন্ত্রণ ও ভাড়া আপডেট:</span>
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">সেবার অবস্থা</label>
                    <select
                      value={driverStatus}
                      onChange={(e) => setDriverStatus(e.target.value as any)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs font-semibold"
                    >
                      <option value="সচল">🟢 সচল (যাত্রী নিচ্ছি)</option>
                      <option value="ব্যস্ত">🔴 সাময়িক ব্যস্ত / বিরতি</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">শিফট</label>
                    <select
                      value={driverShift}
                      onChange={(e) => setDriverShift(e.target.value as any)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs font-semibold"
                    >
                      <option value="দিন ও রাত (২৪ ঘণ্টা)">দিন ও রাত (২৪ ঘণ্টা)</option>
                      <option value="শুধুমাত্র দিনে">শুধুমাত্র দিনে</option>
                      <option value="শুধুমাত্র রাতে">শুধুমাত্র রাতে</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">ভাড়া / রেট</label>
                    <input
                      type="text"
                      value={driverFare}
                      onChange={(e) => setDriverFare(e.target.value)}
                      placeholder="যেমন: প্রতি কিমি ২০ টাকা"
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs font-semibold"
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-[#5A6B6B] bg-[#FAF8F5] border"
              >
                বাতিল
              </button>
              <button
                type="submit"
                className="px-6 py-2 rounded-xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-xs"
              >
                পরিবর্তন সংরক্ষণ করুন
              </button>
            </div>
          </form>
        ) : (
          /* Read Only Details */
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4]">
              <span className="text-[11px] text-[#736B5E] block">নিবন্ধন তারিখ</span>
              <span className="text-xs font-bold text-[#2D3A3A]">{activeUser.createdAt || '২০২৬-০৩-১৫'}</span>
            </div>

            <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4]">
              <span className="text-[11px] text-[#736B5E] block">স্ট্যাটাস</span>
              <span className="text-xs font-bold text-[#2D5A27]">সক্রিয় ও ভেরিফাইড ✓</span>
            </div>

            <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4]">
              <span className="text-[11px] text-[#736B5E] block">আমার বিজ্ঞাপন</span>
              <span className="text-xs font-bold text-[#2D3A3A]">{userListings.length} টি পণ্য</span>
            </div>

            <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4]">
              <span className="text-[11px] text-[#736B5E] block">আমার ট্রিপ রিকোয়েস্ট</span>
              <span className="text-xs font-bold text-[#2D3A3A]">{userRides.length} টি</span>
            </div>
          </div>
        )}

        {/* Tutor / Student Details Card */}
        {activeUser.tutorInfo && (
          <div className="mt-4 bg-[#F6F8FD] p-4 rounded-2xl border border-[#C7D2FE] space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">{activeUser.tutorInfo.tutorType === 'teacher' ? '👨‍🏫' : '🧑‍🎓'}</span>
                <span className="font-bold text-xs text-[#3730A3]">
                  {activeUser.tutorInfo.tutorType === 'teacher' ? 'গৃহশিক্ষক প্রোফাইল' : 'শিক্ষার্থী / অভিভাবক চাহিদা'}
                </span>
              </div>
              <span className="text-[11px] bg-indigo-100 text-indigo-800 font-bold px-2.5 py-0.5 rounded-lg border border-indigo-200">
                {activeUser.tutorInfo.teachingDaysPerWeek} • {activeUser.tutorInfo.hoursPerDay || '১.৫ ঘণ্টা'}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-[#2D3A3A] bg-white p-3 rounded-xl border border-[#E0E7FF]">
              <div>
                <span className="text-[10px] text-[#736B5E] block">যোগ্যতা / শ্রেণি:</span>
                <span className="font-semibold">{activeUser.tutorInfo.qualification || 'উল্লেখ নেই'}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#736B5E] block">কাঙ্ক্ষিত বিষয়সমূহ:</span>
                <span className="font-semibold">{activeUser.tutorInfo.preferredSubjects || 'সকল বিষয়'}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#736B5E] block">সম্মানী / বাজেট:</span>
                <span className="font-semibold text-emerald-700">{activeUser.tutorInfo.remuneration || 'আলোচনা সাপেক্ষে'}</span>
              </div>
            </div>
          </div>
        )}

        {/* Agri Machinery Driver Card */}
        {(activeUser.role === 'agri_machinery_driver' || activeUser.agriMachineryInfo) && (
          <div className="mt-4 bg-[#FFFBEB] p-4 rounded-2xl border border-[#FDE68A] space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">🚜</span>
                <span className="font-bold text-xs text-amber-900">
                  সম্মানিত ট্র্যাক্টর / হেস্কোভেটর / কৃষিযন্ত্র চালক
                </span>
              </div>
              <span className="text-[11px] bg-amber-100 text-amber-900 font-bold px-2.5 py-0.5 rounded-lg border border-amber-300">
                {activeUser.agriMachineryInfo?.machineryType || 'কৃষি যন্ত্রপাতি ও মাটি কাটা'}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-[#2D3A3A] bg-white p-3 rounded-xl border border-amber-200">
              <div>
                <span className="text-[10px] text-[#736B5E] block">যন্ত্রের ধরন / মডেল:</span>
                <span className="font-semibold">{activeUser.agriMachineryInfo?.machineModelOrNumber || activeUser.agriMachineryInfo?.machineryType || 'ট্র্যাক্টর / হেস্কোভেটর'}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#736B5E] block">কাজের এলাকা:</span>
                <span className="font-semibold">{activeUser.upazila}, {activeUser.district}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#736B5E] block">ভাড়া / চুক্তি:</span>
                <span className="font-semibold text-emerald-700">{activeUser.agriMachineryInfo?.hourlyOrDailyRate || 'আলোচনা সাপেক্ষে'}</span>
              </div>
            </div>
          </div>
        )}

        {/* Boatman / Ferry Driver Card */}
        {(activeUser.role === 'boatman' || activeUser.boatmanInfo) && (
          <div className="mt-4 bg-[#ECFEFF] p-4 rounded-2xl border border-[#A5F3FC] space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">⛵</span>
                <span className="font-bold text-xs text-cyan-900">
                  সম্মানিত নৌকার মাঝি / খেয়া চালক
                </span>
              </div>
              <span className="text-[11px] bg-cyan-100 text-cyan-900 font-bold px-2.5 py-0.5 rounded-lg border border-cyan-300">
                {activeUser.boatmanInfo?.serviceShift || 'দিন ও রাত (জরুরি পারাপার)'}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-[#2D3A3A] bg-white p-3 rounded-xl border border-cyan-200">
              <div>
                <span className="text-[10px] text-[#736B5E] block">নৌকার ধরন:</span>
                <span className="font-semibold">{activeUser.boatmanInfo?.boatType || 'যাত্রীবাহী ট্রলার / খেয়া নৌকা'}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#736B5E] block">ঘাট ও রুট:</span>
                <span className="font-semibold">{activeUser.boatmanInfo?.ghatNameOrRoute || `${activeUser.upazila} নদী পারাপার ঘাট`}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#736B5E] block">ভাড়া / পারাপার ফি:</span>
                <span className="font-semibold text-emerald-700">{activeUser.boatmanInfo?.fareRate || 'নির্ধারিত ঘাট রেট'}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* স্বতন্ত্র প্রোফাইল নোটিফিকেশন সেটিংস (কৃষি পণ্য, গৃহস্থালি পণ্য, পেশাগত সেবা, বাসা ও পাত্র-পাত্রী) */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-[#2D5A27]" />
            <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">
              নোটিফিকেশন পছন্দসমূহ (৪টি স্বতন্ত্র অন/অফ সুইচ)
            </h4>
          </div>
          <span className="text-[10px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2 py-0.5 rounded-full">
            তাৎক্ষণিক পুশ অ্যালার্ট
          </span>
        </div>
        <p className="text-[11px] text-[#736B5E]">
          আপনার আগ্রহ অনুযায়ী পণ্যের কেনাবেচা, পেশাগত সেবা কিংবা বাসা ভাড়া ও পাত্র-পাত্রী পোস্টের নোটিফিকেশন আলাদাভাবে নিয়ন্ত্রণ করুন:
        </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
            {/* ১. কৃষি পণ্যের নোটিফিকেশন */}
            <div className="p-3.5 rounded-2xl border border-[#D4E4BC] bg-[#F4F9F2] flex flex-col justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-base">🌾</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    (activeUser.notificationSwitches?.notifyAgriProducts ?? true)
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-stone-200 text-stone-600'
                  }`}>
                    {(activeUser.notificationSwitches?.notifyAgriProducts ?? true) ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                  </span>
                </div>
                <h5 className="font-bold text-xs text-[#2D3A3A]">কৃষি পণ্যের নোটিফিকেশন</h5>
                <p className="text-[10.5px] text-[#5A6B6B] leading-relaxed">
                  ধান, চাল, ভুট্টা, শাকসবজি, ফলমূল ও গবাদিপশুর নতুন বিজ্ঞাপন ও কেনাবেচা বার্তা।
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleToggleNotificationSwitch('notifyAgriProducts', !(activeUser.notificationSwitches?.notifyAgriProducts ?? true))}
                className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  (activeUser.notificationSwitches?.notifyAgriProducts ?? true)
                    ? 'bg-[#2D5A27] text-white hover:bg-[#23491E]'
                    : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
                }`}
              >
                {(activeUser.notificationSwitches?.notifyAgriProducts ?? true) ? '✓ অন আছে (ক্লিক করে বন্ধ করুন)' : '✕ বন্ধ আছে (ক্লিক করে চালু করুন)'}
              </button>
            </div>

            {/* ২. গৃহস্থালি পণ্যের নোটিফিকেশন */}
            <div className="p-3.5 rounded-2xl border border-[#D4E4BC] bg-[#F4F9F2] flex flex-col justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-base">🍲</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    (activeUser.notificationSwitches?.notifyHouseholdProducts ?? true)
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-stone-200 text-stone-600'
                  }`}>
                    {(activeUser.notificationSwitches?.notifyHouseholdProducts ?? true) ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                  </span>
                </div>
                <h5 className="font-bold text-xs text-[#2D3A3A]">গৃহস্থালি পণ্যের নোটিফিকেশন</h5>
                <p className="text-[10.5px] text-[#5A6B6B] leading-relaxed">
                  ঘরে তৈরি খাবার, পিঠাপুলি, মিষ্টি, আচার, হস্তশিল্প ও দেশীয় কুটির পণ্যের নোটিফিকেশন।
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleToggleNotificationSwitch('notifyHouseholdProducts', !(activeUser.notificationSwitches?.notifyHouseholdProducts ?? true))}
                className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  (activeUser.notificationSwitches?.notifyHouseholdProducts ?? true)
                    ? 'bg-[#2D5A27] text-white hover:bg-[#23491E]'
                    : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
                }`}
              >
                {(activeUser.notificationSwitches?.notifyHouseholdProducts ?? true) ? '✓ অন আছে (ক্লিক করে বন্ধ করুন)' : '✕ বন্ধ আছে (ক্লিক করে চালু করুন)'}
              </button>
            </div>

            {/* ৩. পেশাগত সেবার নোটিফিকেশন */}
            <div className="p-3.5 rounded-2xl border border-[#D4E4BC] bg-[#F4F9F2] flex flex-col justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-base">🛠️</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    (activeUser.notificationSwitches?.notifyProfessionalServices ?? true)
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-stone-200 text-stone-600'
                  }`}>
                    {(activeUser.notificationSwitches?.notifyProfessionalServices ?? true) ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                  </span>
                </div>
                <h5 className="font-bold text-xs text-[#2D3A3A]">পেশাগত সেবার নোটিফিকেশন</h5>
                <p className="text-[10.5px] text-[#5A6B6B] leading-relaxed">
                  আপনার এলাকার চালক, মেকার, কৃষি শ্রমিক, দিনমজুর ও শিক্ষক সংক্রান্ত কাজের সরাসরি পুশ রিকোয়েস্ট।
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleToggleNotificationSwitch('notifyProfessionalServices', !(activeUser.notificationSwitches?.notifyProfessionalServices ?? true))}
                className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  (activeUser.notificationSwitches?.notifyProfessionalServices ?? true)
                    ? 'bg-[#2D5A27] text-white hover:bg-[#23491E]'
                    : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
                }`}
              >
                {(activeUser.notificationSwitches?.notifyProfessionalServices ?? true) ? '✓ অন আছে (ক্লিক করে বন্ধ করুন)' : '✕ বন্ধ আছে (ক্লিক করে চালু করুন)'}
              </button>
            </div>

            {/* ৪. বাসা ভাড়া ও পাত্র-পাত্রীর নোটিফিকেশন */}
            <div className="p-3.5 rounded-2xl border border-[#D4E4BC] bg-[#F4F9F2] flex flex-col justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-base">🏠</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    (activeUser.notificationSwitches?.notifyHousingAndMatrimony ?? true)
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-stone-200 text-stone-600'
                  }`}>
                    {(activeUser.notificationSwitches?.notifyHousingAndMatrimony ?? true) ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                  </span>
                </div>
                <h5 className="font-bold text-xs text-[#2D3A3A]">বাসা ভাড়া ও পাত্র-পাত্রী</h5>
                <p className="text-[10.5px] text-[#5A6B6B] leading-relaxed">
                  বাসা ভাড়া ও পাত্র-পাত্রীর সন্ধান চেয়ে পোস্টের বা বিজ্ঞাপনের নোটিফিকেশন পেতে চান?
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleToggleNotificationSwitch('notifyHousingAndMatrimony', !(activeUser.notificationSwitches?.notifyHousingAndMatrimony ?? true))}
                className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  (activeUser.notificationSwitches?.notifyHousingAndMatrimony ?? true)
                    ? 'bg-[#2D5A27] text-white hover:bg-[#23491E]'
                    : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
                }`}
              >
                {(activeUser.notificationSwitches?.notifyHousingAndMatrimony ?? true) ? '✓ অন আছে (ক্লিক করে বন্ধ করুন)' : '✕ বন্ধ আছে (ক্লিক করে চালু করুন)'}
              </button>
            </div>
          </div>
        </div>

      {/* ACCOUNT SECURITY & CREDENTIALS (PHONE, PASSWORD & EMAIL) */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#2D3A3A]">অ্যাকাউন্ট সিকিউরিটি, মোবাইল নম্বর ও পাসওয়ার্ড নিয়ন্ত্রণ</h3>
              <p className="text-[11px] text-[#736B5E]">আপনার ভেরিফাইড মোবাইল নম্বর, লগইন পাসওয়ার্ড এবং ইমেইল নিরাপদভাবে পরিচালনা করুন</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
          {/* Phone Regulation Card */}
          <div className="p-4 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] flex flex-col justify-between gap-3">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-[#2D5A27]" />
                  <h4 className="font-bold text-sm text-[#2D3A3A]">ভেরিফাইড মোবাইল নম্বর</h4>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  phoneStatus.canChange 
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-amber-100 text-amber-800 border border-amber-300'
                }`}>
                  {phoneStatus.canChange ? '🟢 পরিবর্তনযোগ্য' : '🔒 ২৬ দিন লক'}
                </span>
              </div>
              <p className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1">
                <span>{activeUser.phone}</span>
                <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">ওটিপি ভেরিফাইড</span>
              </p>
              <p className="text-[11px] text-[#736B5E] leading-relaxed">
                {phoneStatus.canChange ? (
                  '২৬ দিন অতিক্রান্ত হয়েছে। আপনি চাইলে ওটিপি যাচাইয়ের মাধ্যমে নতুন নম্বর যোগ করতে পারেন।'
                ) : (
                  <span>
                    তদন্ত ও নিরাপত্তার স্বার্থে নম্বরটি লক করা আছে। পরবর্তী পরিবর্তনের সুযোগ: <strong>{phoneStatus.nextEligibleDate}</strong> (বাকি {phoneStatus.remainingDays} দিন)।
                  </span>
                )}
              </p>
            </div>
            <div className="pt-1">
              {phoneStatus.canChange ? (
                <button
                  onClick={handleStartPhoneChange}
                  className="w-full flex items-center justify-center gap-1.5 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-xs transition cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>নতুন নম্বর পরিবর্তন করুন</span>
                </button>
              ) : (
                <button
                  onClick={() => setShowPhoneInfoModal(true)}
                  className="w-full flex items-center justify-center gap-1.5 bg-white hover:bg-[#D4E4BC]/30 text-[#2D5A27] font-bold text-xs py-2.5 px-4 rounded-xl border border-[#2D5A27]/40 shadow-2xs transition cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5 text-amber-600" />
                  <span>পরিবর্তন লক থাকার নিয়ম ও কারণ</span>
                </button>
              )}
            </div>
          </div>

          {/* Password Card */}
          <div className="p-4 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] flex flex-col justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#2D5A27]" />
                <h4 className="font-bold text-sm text-[#2D3A3A]">লগইন পাসওয়ার্ড / সিকিউরিটি পিন</h4>
              </div>
              <p className="text-xs text-[#736B5E]">
                {activeUser.passwordPin 
                  ? 'আপনার অ্যাকাউন্টে কাস্টম পাসওয়ার্ড সেট করা আছে।' 
                  : 'আপনি বর্তমান ডিফল্ট পিন (1234) পরিবর্তন করে নিজস্ব গোপনীয় পাসওয়ার্ড সেট করতে পারেন।'}
              </p>
            </div>
            <button
              onClick={() => {
                setPasswordError(null);
                setOldPassword('');
                setNewPassword('');
                setConfirmPassword('');
                setShowPasswordModal(true);
              }}
              className="w-full flex items-center justify-center gap-1.5 bg-white hover:bg-[#D4E4BC]/30 text-[#2D5A27] font-bold text-xs py-2.5 px-4 rounded-xl border border-[#2D5A27]/40 shadow-2xs transition cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>পাসওয়ার্ড পরিবর্তন করুন</span>
            </button>
          </div>

          {/* Email Card */}
          <div className="p-4 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] flex flex-col justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#2D5A27]" />
                <h4 className="font-bold text-sm text-[#2D3A3A]">ইমেইল ঠিকানা (Email Address)</h4>
              </div>
              <p className="text-xs text-[#736B5E]">
                {activeUser.email ? (
                  <span className="font-semibold text-[#2D3A3A]">সংযুক্ত ইমেইল: {activeUser.email}</span>
                ) : (
                  'কোনো ইমেইল যুক্ত করা নেই। জরুরি নোটিফিকেশনের জন্য ইমেইল যুক্ত করুন।'
                )}
              </p>
            </div>
            <button
              onClick={() => {
                setEmailError(null);
                setInputEmail(activeUser.email || '');
                setShowEmailModal(true);
              }}
              className="w-full flex items-center justify-center gap-1.5 bg-white hover:bg-[#D4E4BC]/30 text-[#2D5A27] font-bold text-xs py-2.5 px-4 rounded-xl border border-[#2D5A27]/40 shadow-2xs transition cursor-pointer"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>{activeUser.email ? 'ইমেইল পরিবর্তন করুন' : 'ইমেইল যুক্ত করুন'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* PRIVACY RULES & SAFE COMMUNICATION CONTROLS */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#2D3A3A]">প্রাইভেসি রুলস ও অফলাইন কল নিয়ন্ত্রণ (Privacy Settings)</h3>
              <p className="text-[11px] text-[#736B5E]">আপনার ব্যক্তিগত ফোন নম্বর ও সুনির্দিষ্ট ঠিকানা প্রকাশের মাত্রা নির্ধারণ করুন</p>
            </div>
          </div>
          <span className="text-[10px] font-bold text-[#1E5631] bg-[#E8F8F5] px-2.5 py-1 rounded-full border border-[#A9DFBF]">
            🛡️ ডিফল্ট অটো-হাইড সক্রিয়
          </span>
        </div>

        <div className="space-y-3">
          {/* Key Rule: [✓] অফলাইন মোবাইল কলে যোগাযোগের সুযোগ দিন */}
          <div className="p-4 bg-[#FAF8F5] rounded-2xl border border-[#D4C3A3] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="space-y-1 max-w-xl">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#2D5A27]" />
                <h4 className="font-bold text-sm text-[#2D3A3A]">
                  অফলাইন সরাসরি মোবাইল কল অনুমোদন (Offline Direct Call)
                </h4>
              </div>
              <p className="text-xs text-[#5A6B6B] leading-relaxed">
                ডিফল্টভাবে আপনার মোবাইল নম্বর গোপন থাকে এবং ব্যবহারকারীরা কেবল ইন-অ্যাপ অনলাইন চ্যাট ও অডিও কলে যোগাযোগ করতে পারে। আপনি নিজে চালু না করা পর্যন্ত কেউ আপনাকে সরাসরি অফলাইন মোবাইল কল দিতে পারবে না।
              </p>
            </div>

            <label className="flex items-center gap-2.5 cursor-pointer bg-white px-3.5 py-2.5 rounded-xl border border-[#D4C3A3] hover:bg-[#FAF8F5] shrink-0">
              <input
                type="checkbox"
                checked={!!activeUser.allowOfflineCall}
                onChange={(e) => handleToggleOfflineCall(e.target.checked)}
                className="w-4 h-4 text-[#2D5A27] rounded focus:ring-[#2D5A27] cursor-pointer"
              />
              <span className="text-xs font-bold text-[#2D3A3A]">
                [✓] অফলাইন মোবাইল কলে যোগাযোগের সুযোগ দিন
              </span>
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Phone Number Visibility Toggle */}
            <div className="p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] flex items-center justify-between gap-2">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                  <EyeOff className="w-3.5 h-3.5 text-[#736B5E]" />
                  <span>পাবলিক প্রোফাইলে ফোন নম্বর হাইড রাখুন</span>
                </span>
                <p className="text-[11px] text-[#736B5E]">হাটের বিজ্ঞাপনে মোবাইল নম্বর লুকানো থাকবে</p>
              </div>
              <input
                type="checkbox"
                checked={activeUser.hidePhonePublicly ?? true}
                onChange={(e) => handleTogglePhoneHide(e.target.checked)}
                className="w-4 h-4 text-[#2D5A27] rounded cursor-pointer"
              />
            </div>

            {/* Village Hide Toggle */}
            <div className="p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] flex items-center justify-between gap-2">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-[#736B5E]" />
                  <span>গ্রাম হাইড রাখুন (শুধু উপজেলা দৃশ্যমান)</span>
                </span>
                <p className="text-[11px] text-[#736B5E]">সুনির্দিষ্ট বাড়ি বা পাড়া কেউ দেখতে পাবে না</p>
              </div>
              <input
                type="checkbox"
                checked={activeUser.hideVillage ?? true}
                onChange={(e) => handleToggleVillageHide(e.target.checked)}
                className="w-4 h-4 text-[#2D5A27] rounded cursor-pointer"
              />
            </div>

            {/* Ward Hide Toggle */}
            <div className="p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] flex items-center justify-between gap-2">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-[#736B5E]" />
                  <span>ওয়ার্ড নম্বর গোপন রাখুন (হাইড)</span>
                </span>
                <p className="text-[11px] text-[#736B5E]">পাবলিক প্রোফাইলে সুনির্দিষ্ট ওয়ার্ড নম্বর লুকানো থাকবে</p>
              </div>
              <input
                type="checkbox"
                checked={activeUser.hideWard ?? true}
                onChange={(e) => handleToggleWardHide(e.target.checked)}
                className="w-4 h-4 text-[#2D5A27] rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Primary Safe Communication Channels Info */}
          <div className="p-3 bg-emerald-50/80 rounded-2xl border border-emerald-200 text-xs text-emerald-950 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <p className="text-[11px] text-[#2D5A27] leading-relaxed">
              <strong>ডিফল্ট নিরাপদ যোগাযোগ মাধ্যম:</strong> অন-অ্যাপ ভয়েস কল, ইন-অ্যাপ চ্যাট এবং ভয়েস মেসেজ হলো প্ল্যাটফর্মের প্রধান ও নিরাপদ যোগাযোগের মাধ্যম। আপনি নিজে প্রোফাইল থেকে "অফলাইন কল" চালু না করলে অন্য কোনো নাগরিক বা ক্রেতা আপনার ব্যক্তিগত সিম নম্বর দেখতে পাবে না।
            </p>
          </div>
        </div>
      </div>

      {/* 🛡️ DIGITAL SECURITY AUDIT LOGBOOK (1-YEAR RETENTION) */}
      <UserSecurityLogbook user={activeUser} />

      {/* Driver Stats & Rating Card if User is a Driver */}
      {activeUser.role === 'driver' && activeUser.driverInfo && (
        <div className="bg-gradient-to-br from-[#2D5A27] to-[#1E3F1A] text-white rounded-3xl p-5 sm:p-6 shadow-md space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Car className="w-6 h-6 text-[#D4E4BC]" />
              <h3 className="font-bold text-base sm:text-lg">আমার চালক প্রোফাইল ড্যাশবোর্ড</h3>
            </div>
            <span className="px-3 py-1 bg-white/20 rounded-full text-xs font-bold">
              {activeUser.driverInfo.status === 'সচল' ? '🟢 অন-ডিউটি' : '🔴 অফ-ডিউটি'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-xs">
              <span className="text-[#D4E4BC] block text-[11px]">যানবাহন</span>
              <span className="font-bold text-sm">{activeUser.driverInfo.vehicleType}</span>
            </div>
            <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-xs">
              <span className="text-[#D4E4BC] block text-[11px]">গাড়ির প্লেট</span>
              <span className="font-bold text-sm">{activeUser.driverInfo.vehicleNumber}</span>
            </div>
            <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-xs">
              <span className="text-[#D4E4BC] block text-[11px]">গড় নাগরিক রেটিং</span>
              <span className="font-bold text-sm text-[#F6E05E] flex items-center gap-1">
                <Star className="w-4 h-4 fill-[#F6E05E]" />
                <span>{activeUser.driverInfo.rating || '5.0'} / ৫.০</span>
              </span>
            </div>
            <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-xs">
              <span className="text-[#D4E4BC] block text-[11px]">শিফট</span>
              <span className="font-bold text-sm">{activeUser.driverInfo.serviceShift}</span>
            </div>
          </div>

          {/* Dynamic Fare Profile Configuration */}
          <form onSubmit={handleSaveFareProfile} className="bg-white/10 p-4 rounded-2xl backdrop-blur-xs border border-white/20 space-y-3 text-xs">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <span className="font-bold text-xs text-[#D4E4BC] flex items-center gap-1.5">
                <span>💰 ডায়নামিক ভাড়া নির্ধারণ ও প্রোফাইল রেট</span>
              </span>
              <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-bold">
                {fareType === 'per_km' ? 'কিলোমিটার ভিত্তিক রেট' : 'আলোচনা সাপেক্ষে'}
              </span>
            </div>

            {/* Check if special vehicle (excavator, power tiller, boat) */}
            {(['excavator', 'power_tiller', 'boatman'].includes(activeUser.subCategory || '') || 
              activeUser.role === 'agri_machinery_driver' || 
              activeUser.role === 'boatman') ? (
              <div className="p-3 bg-amber-500/20 rounded-xl border border-amber-300/40 text-amber-100 text-[11px] leading-relaxed">
                🚜 <strong>বিশেষ যানবাহন বিজ্ঞপ্তি:</strong> আপনার যানবাহনটি বিশেষ ক্যাটাগরির (এক্সকাভেটর/পাওয়ার ট্রিলার/নৌকা)। এতে দূরত্ব বা কিমি প্রতি ভাড়া প্রযোজ্য নয়। আপনার কাজের এলাকা অনুযায়ী সময় (ঘণ্টা), জমি (বিঘা/শতাংশ) বা চুক্তিভিত্তিক "আলোচনা সাপেক্ষে" ভাড়া নির্ধারণ করা হয়।
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="fareType"
                      value="per_km"
                      checked={fareType === 'per_km'}
                      onChange={() => setFareType('per_km')}
                      className="cursor-pointer text-[#2D5A27]"
                    />
                    <span className="font-bold">কিমি প্রতি নির্দিষ্ট ভাড়া</span>
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="fareType"
                      value="negotiable"
                      checked={fareType === 'negotiable'}
                      onChange={() => setFareType('negotiable')}
                      className="cursor-pointer text-[#2D5A27]"
                    />
                    <span className="font-bold">আলোচনা সাপেক্ষে</span>
                  </label>
                </div>

                {fareType === 'per_km' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10.5px] text-[#D4E4BC] mb-1">
                        প্রতি কিলোমিটার ভাড়া (টাকা)
                      </label>
                      <input
                        type="number"
                        min="5"
                        max="200"
                        value={ratePerKm}
                        onChange={(e) => setRatePerKm(e.target.value)}
                        className="w-full bg-white/20 border border-white/30 rounded-xl px-3 py-1.5 text-white font-bold placeholder-white/50 focus:outline-none"
                        placeholder="যেমন: ১৫"
                      />
                    </div>
                    <div>
                      <label className="block text-[10.5px] text-[#D4E4BC] mb-1">
                        প্রারম্ভিক / ন্যূনতম ভাড়া (টাকা)
                      </label>
                      <input
                        type="number"
                        min="10"
                        max="500"
                        value={baseFare}
                        onChange={(e) => setBaseFare(e.target.value)}
                        className="w-full bg-white/20 border border-white/30 rounded-xl px-3 py-1.5 text-white font-bold placeholder-white/50 focus:outline-none"
                        placeholder="যেমন: ৩০"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex items-center justify-between pt-1">
              <p className="text-[10.5px] text-white/80">
                যাত্রী গন্তব্য নির্বাচন করলে স্বয়ংক্রিয়ভাবে সম্ভাব্য ভাড়ার রেঞ্জ দেখতে পাবে।
              </p>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#D4E4BC] text-[#2D5A27] font-bold rounded-xl hover:bg-white transition cursor-pointer text-xs shadow-xs"
              >
                ভাড়া আপডেট করুন
              </button>
            </div>
          </form>
        </div>
      )}

      {/* User's Haat Ads / Listings Section */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#2D5A27]" />
            <h3 className="font-bold text-base text-[#2D3A3A]">আমার হাট বিজ্ঞাপন সমূহ ({userListings.length})</h3>
          </div>
          <button
            onClick={() => onNavigateToService('marketplace')}
            className="flex items-center gap-1 text-xs font-bold text-[#2D5A27] hover:underline cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>নতুন বিজ্ঞাপন দিন</span>
          </button>
        </div>

        {userListings.length === 0 ? (
          <div className="text-center py-6 text-xs text-[#736B5E] space-y-2">
            <p>আপনার কোনো সক্রিয় হাট বিজ্ঞাপন নেই।</p>
            <button
              onClick={() => onNavigateToService('marketplace')}
              className="px-4 py-2 bg-[#D4E4BC] text-[#2D5A27] font-bold rounded-xl text-xs cursor-pointer hover:bg-[#c2d7a5]"
            >
              + এখনই বিনামূল্যে কৃষিপণ্যের বিজ্ঞাপন পোস্ট করুন
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {userListings.map((item) => (
              <div
                key={item.id}
                className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-[#2D3A3A]">{item.title}</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#D4E4BC] text-[#2D5A27]">
                      {item.category}
                    </span>
                  </div>
                  <p className="text-xs text-[#2D5A27] font-bold">
                    দাম: {formatTaka(item.price)} টাকা / {item.unit} • পরিমাণ: {item.quantity}
                  </p>
                  <p className="text-[11px] text-[#736B5E]">
                    পোস্ট: {item.createdAt} • এলাকা: {item.upazila || ''}, {item.district}
                  </p>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => handleRenewListing(item.id)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold text-[#2D5A27] bg-[#D4E4BC]/50 hover:bg-[#D4E4BC] cursor-pointer"
                    title="মেয়াদ আরও বাড়ান"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>মেয়াদ বাড়ান</span>
                  </button>

                  <button
                    onClick={() => handleDeleteListing(item.id)}
                    className="p-1.5 rounded-xl text-red-600 bg-red-50 hover:bg-red-100 cursor-pointer"
                    title="মুছে ফেলুন"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Settings & App Optimization Quick Shortcuts */}
      <div className="bg-white rounded-3xl p-5 border border-[#E6E0D4] shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <SettingsIcon className="w-5 h-5 text-[#2D5A27]" />
            <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A]">
              অ্যাপ সেটিংস ও নিরাপত্তা নিয়ন্ত্রণ
            </h3>
          </div>
          <button
            onClick={() => onNavigateToService('settings')}
            className="flex items-center gap-1 text-xs font-bold text-[#2D5A27] hover:underline cursor-pointer"
          >
            <span>সেটিংস খুলুন</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
          <button
            onClick={() => onNavigateToService('settings')}
            className="p-3 bg-[#FAF8F5] hover:bg-[#D4E4BC]/20 rounded-2xl border border-[#E6E0D4] text-left transition flex items-center justify-between cursor-pointer"
          >
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-[#2D3A3A] block">নোটিফিকেশন ও থিম</span>
              <span className="text-[11px] text-[#736B5E]">ক্যাশ ও ডেটা নিয়ন্ত্রণ</span>
            </div>
            <ChevronRight className="w-4 h-4 text-[#736B5E]" />
          </button>

          <button
            onClick={() => window.dispatchEvent(new CustomEvent('polli_trigger_pwa_install'))}
            className="p-3 bg-[#FAF8F5] hover:bg-[#F9E5D4] rounded-2xl border border-[#E6E0D4] text-left transition flex items-center justify-between cursor-pointer"
          >
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-[#A65E2E] block">📲 অ্যাপ ইনস্টল (PWA)</span>
              <span className="text-[11px] text-[#736B5E]">হোম স্ক্রিন শর্টকাট</span>
            </div>
            <Download className="w-4 h-4 text-[#A65E2E]" />
          </button>

          {onOpenAdmin && (
            <button
              onClick={onOpenAdmin}
              className="p-3 bg-[#FAF8F5] hover:bg-[#23491E]/10 rounded-2xl border border-[#E6E0D4] text-left transition flex items-center justify-between cursor-pointer"
            >
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-[#23491E] block">🔐 অ্যাডমিন প্যানেল</span>
                <span className="text-[11px] text-[#736B5E]">বিজ্ঞাপন ও সাব-এডমিন</span>
              </div>
              <Shield className="w-4 h-4 text-[#2D5A27]" />
            </button>
          )}
        </div>
      </div>

      {/* PASSWORD CHANGE MODAL */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4 max-h-[88vh] overflow-y-auto animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-[#2D3A3A]">পাসওয়ার্ড / পিন পরিবর্তন</h4>
                  <p className="text-[11px] text-[#736B5E]">আপনার অ্যাকাউন্টের নিরাপত্তা নিশ্চিত করুন</p>
                </div>
              </div>
              <button
                onClick={() => setShowPasswordModal(false)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-[#736B5E] cursor-pointer"
              >
                ✕
              </button>
            </div>

            {passwordError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{passwordError}</span>
              </div>
            )}

            <form onSubmit={handlePasswordChange} className="space-y-3.5">
              {currentUser.passwordPin && (
                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1">বর্তমান পাসওয়ার্ড / পিন</label>
                  <div className="relative">
                    <input
                      type={showOldPass ? "text" : "password"}
                      required
                      value={oldPassword}
                      onChange={(e) => setOldPassword(e.target.value)}
                      placeholder="বর্তমান পাসওয়ার্ড দিন"
                      className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2.5 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowOldPass(!showOldPass)}
                      className="absolute right-3 top-2.5 text-[#736B5E] hover:text-[#2D3A3A] cursor-pointer"
                    >
                      {showOldPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-[#2D3A3A] mb-1">নতুন পাসওয়ার্ড / ৪-ডিজিট পিন</label>
                <div className="relative">
                  <input
                    type={showNewPass ? "text" : "password"}
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="কমপক্ষে ৪ অক্ষরের নতুন পাসওয়ার্ড"
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2.5 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPass(!showNewPass)}
                    className="absolute right-3 top-2.5 text-[#736B5E] hover:text-[#2D3A3A] cursor-pointer"
                  >
                    {showNewPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2D3A3A] mb-1">পুনরায় নতুন পাসওয়ার্ড নিশ্চিত করুন</label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="নতুন পাসওয়ার্ডটি আবার লিখুন"
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2.5 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-xl text-xs shadow-xs cursor-pointer"
                >
                  পাসওয়ার্ড সংরক্ষণ করুন
                </button>
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="bg-[#FAF8F5] text-[#5A6B6B] font-semibold py-2.5 px-4 rounded-xl text-xs border border-[#E6E0D4] cursor-pointer"
                >
                  বাতিল
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EMAIL UPDATE MODAL */}
      {showEmailModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4 max-h-[88vh] overflow-y-auto animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-[#2D3A3A]">ইমেইল ঠিকানা আপডেট</h4>
                  <p className="text-[11px] text-[#736B5E]">গুরুত্বপূর্ণ বার্তা ও নোটিফিকেশন পেতে ইমেইল যোগ করুন</p>
                </div>
              </div>
              <button
                onClick={() => setShowEmailModal(false)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-[#736B5E] cursor-pointer"
              >
                ✕
              </button>
            </div>

            {emailError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{emailError}</span>
              </div>
            )}

            <form onSubmit={handleEmailUpdate} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-[#2D3A3A] mb-1">আপনার ইমেইল অ্যাড্রেস</label>
                <input
                  type="email"
                  value={inputEmail}
                  onChange={(e) => setInputEmail(e.target.value)}
                  placeholder="যেমন: shahinur@example.com"
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2.5 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
                <p className="text-[11px] text-[#736B5E] mt-1">
                  * ইমেইল যুক্ত করলে জরুরি নিরাপত্তা অ্যালার্ট ও হাট বিজ্ঞাপনের নোটিফিকেশন পাবেন।
                </p>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-xl text-xs shadow-xs cursor-pointer"
                >
                  ইমেইল সেভ করুন
                </button>
                <button
                  type="button"
                  onClick={() => setShowEmailModal(false)}
                  className="bg-[#FAF8F5] text-[#5A6B6B] font-semibold py-2.5 px-4 rounded-xl text-xs border border-[#E6E0D4] cursor-pointer"
                >
                  বাতিল
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PROFILE PHOTO MANAGEMENT MODAL */}
      {showPhotoModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-4 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4 max-h-[88vh] overflow-y-auto animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-[#2D3A3A]">প্রোফাইল ছবি ও ভেরিফাইড ফেস ব্যবস্থাপনা</h4>
                  <p className="text-[11px] text-[#736B5E]">ঐচ্ছিক ছবি পরিচালনা এবং স্থায়ী পরিচয় সংরক্ষণ প্রটোকল</p>
                </div>
              </div>
              <button
                onClick={() => setShowPhotoModal(false)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-[#736B5E] cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Current Public Profile Photo Display */}
            <div className="p-4 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#2D3A3A]">বর্তমান পাবলিক প্রোফাইল ছবি</span>
                {activeUser.customAvatarUrl ? (
                  <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2.5 py-0.5 rounded-full">
                    🎨 ঐচ্ছিক ছবি সক্রিয় (অন্যরা দেখছেন)
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-[#2D5A27] bg-[#D4E4BC] border border-[#2D5A27]/30 px-2.5 py-0.5 rounded-full">
                    🛡️ ভেরিফাইড ফেস ফটো সক্রিয়
                  </span>
                )}
              </div>

              <div className="flex items-center gap-4">
                {displayAvatar ? (
                  <img
                    src={displayAvatar}
                    alt={activeUser.name}
                    className="w-20 h-20 rounded-2xl object-cover border-2 border-[#2D5A27] shadow-sm shrink-0"
                  />
                ) : (
                  <div className="w-20 h-20 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-bold text-3xl shadow-sm shrink-0">
                    {activeUser.name.charAt(0)}
                  </div>
                )}

                <div className="space-y-1 text-xs">
                  <p className="font-bold text-[#2D3A3A]">{activeUser.name}</p>
                  <p className="text-[11px] text-[#5A6B6B] leading-relaxed">
                    {activeUser.customAvatarUrl 
                      ? 'আপনি একটি ঐচ্ছিক প্রোফাইল ছবি যুক্ত করেছেন যা সাধারণ ব্যবহারকারীদের কাছে প্রদর্শিত হচ্ছে।'
                      : 'বর্তমানে আপনার লাইভ ফেস ভেরিফিকেশন ছবিটিই পাবলিকলি প্রোফাইল ছবি হিসেবে প্রদর্শিত হচ্ছে।'}
                  </p>
                </div>
              </div>

              {/* Action Buttons for Custom Photo vs Driver Policy (Requirement 5) */}
              {(activeUser.role === 'driver' || activeUser.role === 'boatman' || activeUser.role === 'agri_machinery_driver') ? (
                <div className="p-3 bg-amber-50 rounded-2xl border border-amber-300 space-y-2.5">
                  <div className="flex items-center gap-2 text-amber-900 font-bold text-xs">
                    <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>চালক ও মাঝি সুরক্ষা নীতি (গ্যালারি ছবি নিষিদ্ধ)</span>
                  </div>
                  <p className="text-[11px] text-amber-900 leading-relaxed">
                    যাত্রী নিরাপত্তা ও পরিচয় নির্ভরযোগ্যতার স্বার্থে চালক ও মাঝিরা গ্যালারি থেকে ইচ্ছেমতো ছবি আপলোড করতে পারবেন না। রেজিস্ট্রেশনের সময় সম্পন্ন আসল লাইভ ভেরিফিকেশন ছবিই সবার কাছে পাবলিকলি দৃশ্যমান। প্রয়োজনে আসল মুখমণ্ডল দিয়ে লাইভ ক্যামেরা রি-ভেরিফিকেশন করতে পারেন।
                  </p>
                  <button
                    type="button"
                    onClick={() => setShowLiveVerificationModal(true)}
                    className="w-full py-2.5 px-3 bg-gradient-to-r from-[#2D5A27] to-[#1E5C46] hover:from-[#23491E] hover:to-[#174635] text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                  >
                    <Camera className="w-4 h-4 text-emerald-300" />
                    <span>লাইভ ক্যামেরা ফেস রি-ভেরিফিকেশন করুন</span>
                  </button>
                </div>
              ) : (
                <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-[#E6E0D4]">
                  <button
                    type="button"
                    disabled={isUploadingPhoto}
                    onClick={() => photoInputRef.current?.click()}
                    className="flex-1 min-w-[140px] flex items-center justify-center gap-1.5 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold text-xs py-2.5 px-3.5 rounded-xl shadow-xs transition cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>{isUploadingPhoto ? 'প্রসেসিং...' : activeUser.customAvatarUrl ? 'নতুন ঐচ্ছিক ছবি আপলোড' : 'ঐচ্ছিক ছবি যোগ করুন'}</span>
                  </button>

                  {activeUser.customAvatarUrl && (
                    <button
                      type="button"
                      onClick={handleRemoveCustomAvatar}
                      className="flex items-center justify-center gap-1.5 bg-red-50 hover:bg-red-100 text-red-600 font-bold text-xs py-2.5 px-3.5 rounded-xl border border-red-200 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>ঐচ্ছিক ছবি মুছুন</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Permanent Verified Face Record Display */}
            <div className="p-3.5 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-2">
              <div className="flex items-center gap-2 text-[#1E5631]">
                <ShieldCheck className="w-4 h-4 text-[#27AE60] shrink-0" />
                <h5 className="font-bold text-xs">কর্তৃপক্ষের স্থায়ী নিরাপত্তা রেকর্ড (ভেরিফাইড ফেস)</h5>
              </div>

              <div className="flex items-center gap-3">
                {(activeUser.verifiedFaceUrl || (!activeUser.customAvatarUrl ? activeUser.avatarUrl : null)) ? (
                  <img
                    src={activeUser.verifiedFaceUrl || activeUser.avatarUrl}
                    alt="Verified Face Record"
                    className="w-12 h-12 rounded-xl object-cover border-2 border-emerald-600 shadow-xs shrink-0"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-lg border border-emerald-300 shrink-0">
                    🛡️
                  </div>
                )}
                <p className="text-[11px] text-emerald-950 leading-relaxed">
                  নিবন্ধনের সময় গৃহীত আপনার আসল লাইভ ক্যামেরা ফেস ফটো কর্তৃপক্ষের সেন্ট্রাল অডিট ডাটাবেজে স্থায়ী ও সুরক্ষিত রয়েছে। কোনো অনাকাঙ্ক্ষিত ঘটনা বা অভিযোগ তদন্তের প্রয়োজনে কর্তৃপক্ষ এটি সংরক্ষণ করে।
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => setShowPhotoModal(false)}
                className="px-5 py-2 rounded-xl bg-[#FAF8F5] hover:bg-[#F2ECE1] text-[#2D3A3A] font-bold text-xs border border-[#D4C3A3] cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Driver Live Camera Re-verification Modal */}
      {showLiveVerificationModal && (
        <LiveFaceVerificationModal
          isOpen={showLiveVerificationModal}
          userName={activeUser.name}
          onSuccess={(liveFaceDataUrl) => {
            handleLiveFaceReverification(liveFaceDataUrl);
          }}
          onCancel={() => setShowLiveVerificationModal(false)}
        />
      )}

      {/* PHONE INFORMATION MODAL (4-MONTH RULE & INVESTIGATION PROTOCOL) */}
      {showPhoneInfoModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4 max-h-[88vh] overflow-y-auto animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5 text-amber-700" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-[#2D3A3A]">মোবাইল নম্বর পরিবর্তন নিয়ন্ত্রণ নীতি</h4>
                  <p className="text-[11px] text-[#736B5E]">নিরাপত্তা ও অপরাধ দমনের স্বার্থে ২৬ দিন পর পর পরিবর্তনের নিয়ম</p>
                </div>
              </div>
              <button
                onClick={() => setShowPhoneInfoModal(false)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-[#736B5E] cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-[#2D3A3A] leading-relaxed">
              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900 text-[11px] font-medium flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>আপনার নিরাপত্তার স্বার্থে এই তথ্যটি সংরক্ষিত থাকছে এবং এটি সম্পূর্ণ সুরক্ষিত ও এনক্রিপ্ট করা।</span>
              </div>

              <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 space-y-1.5">
                <p className="font-bold text-amber-900 flex items-center gap-1.5 text-sm">
                  <Lock className="w-4 h-4 text-amber-700" />
                  <span>বর্তমানে নম্বর পরিবর্তন সাময়িকভাবে সীমাবদ্ধ</span>
                </p>
                <p className="text-amber-800 text-[11px]">
                  আপনার বর্তমান নম্বরটি নিবন্ধনের পর এখনো ২৬ দিন অতিক্রান্ত হয়নি। নিরাপত্তা প্রটোকল অনুসারে পরবর্তী পরিবর্তনের সুযোগ আসবে: <strong>{phoneStatus.nextEligibleDate}</strong> তারিখে (আর <strong>{phoneStatus.remainingDays}</strong> দিন বাকি)।
                </p>
              </div>

              <div className="space-y-2 pt-1">
                <h5 className="font-bold text-[#2D5A27] text-xs">🛡️ কেন নম্বর ইচ্ছেমতো পরিবর্তন করা যায় না?</h5>
                <ul className="space-y-2 text-[#3E4D4D] text-[11px] list-disc list-inside">
                  <li>
                    <strong>আইনি তদন্ত ও অপরাধ দমন:</strong> প্ল্যাটফর্মের মাধ্যমে কোনো লেনদেন বা সেবায় অনাকাঙ্ক্ষিত ঘটনা ঘটলে আইনশৃঙ্খলা রক্ষাকারী বাহিনীর নির্ভুল অনুসন্ধানের জন্য ভেরিফাইড নম্বরের ধারাবাহিকতা থাকা আবশ্যক।
                  </li>
                  <li>
                    <strong>প্রতারণা ও ভুয়া অ্যাকাউন্ট রোধ:</strong> একই ব্যক্তি ঘনঘন নম্বর পরিবর্তন করে দায়মুক্তি নেওয়ার চেষ্টা প্রতিহত করতে এই নীতি প্রণয়ন করা হয়েছে।
                  </li>
                  <li>
                    <strong>গ্রামীণ বিশ্বাসযোগ্যতা ও নিরাপত্তা:</strong> কৃষক, চালক ও সাধারণ নাগরিকদের লেনদেনের পারস্পরিক আস্থা ও ভরসা বজায় রাখা।
                  </li>
                  <li>
                    <strong>স্থায়ী রেকর্ড সংরক্ষণ:</strong> প্ল্যাটফর্ম কর্তৃপক্ষের সেন্ট্রাল সার্ভারে প্রতিটি অ্যাকাউন্টের ওটিপি ভেরিফাইড নম্বর, গ্রাম/ওয়ার্ড ও ভেরিফাইড ফেস ফটো অপরিবর্তনীয়ভাবে সংরক্ষিত থাকে।
                  </li>
                </ul>
              </div>

              <div className="p-3 bg-[#FAF8F5] rounded-xl border border-[#E6E0D4] text-[11px] text-[#5A6B6B]">
                <div className="flex justify-between py-0.5">
                  <span>বর্তমান নিবন্ধিত নম্বর:</span>
                  <strong className="text-[#2D3A3A]">{activeUser.phone}</strong>
                </div>
                <div className="flex justify-between py-0.5">
                  <span>সর্বশেষ নিবন্ধন/পরিবর্তনের তারিখ:</span>
                  <strong className="text-[#2D3A3A]">{phoneStatus.lastChangedDate}</strong>
                </div>
                <div className="flex justify-between py-0.5">
                  <span>পরবর্তী পরিবর্তনের সুযোগ:</span>
                  <strong className="text-[#2D5A27]">{phoneStatus.nextEligibleDate}</strong>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => setShowPhoneInfoModal(false)}
                className="px-5 py-2.5 rounded-xl bg-[#2D5A27] text-white font-bold text-xs shadow-xs hover:bg-[#23491E] cursor-pointer"
              >
                বুঝেছি
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PHONE NUMBER CHANGE & OTP VERIFICATION MODAL */}
      {showPhoneModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4 max-h-[88vh] overflow-y-auto animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-[#2D3A3A]">নতুন মোবাইল নম্বর পরিবর্তন</h4>
                  <p className="text-[11px] text-[#736B5E]">ওটিপি যাচাইকরণের মাধ্যমে নতুন নম্বর যোগ করুন</p>
                </div>
              </div>
              <button
                onClick={() => setShowPhoneModal(false)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-[#736B5E] cursor-pointer"
              >
                ✕
              </button>
            </div>

            {phoneError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{phoneError}</span>
              </div>
            )}

            {phoneStep === 'input' ? (
              <form onSubmit={handleSendPhoneOtp} className="space-y-4">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-[11px] text-blue-900 leading-relaxed">
                  ℹ️ আপনার ২৬ দিনের লক সময় শেষ হয়েছে। নতুন নম্বর যুক্ত করতে ওটিপি যাচাই বাধ্যতামূলক। নতুন নম্বর যুক্ত করলে তা পরবর্তী ২৬ দিনের জন্য পুনরায় লক হবে এবং পূর্বের নম্বরটি অডিট আর্কাইভে সংরক্ষিত থাকবে।
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1">বর্তমান মোবাইল নম্বর</label>
                  <input
                    type="text"
                    disabled
                    value={activeUser.phone}
                    className="w-full bg-gray-100 border border-gray-300 rounded-xl px-3.5 py-2.5 text-xs text-gray-600 font-semibold cursor-not-allowed"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1">নতুন ১১ ডিজিটের মোবাইল নম্বর</label>
                  <input
                    type="tel"
                    required
                    maxLength={11}
                    value={newPhoneInput}
                    onChange={(e) => setNewPhoneInput(e.target.value)}
                    placeholder="যেমন: 01712345678"
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2.5 text-xs text-[#2D3A3A] font-bold focus:outline-none focus:border-[#2D5A27]"
                  />
                  <p className="text-[11px] text-[#736B5E] mt-1">
                    * এই নম্বরে ৪-সংখ্যার একটি তাৎক্ষণিক ওটিপি ভেরিফিকেশন কোড পাঠানো হবে।
                  </p>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="submit"
                    className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-xl text-xs shadow-xs cursor-pointer"
                  >
                    ওটিপি কোড পাঠান
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowPhoneModal(false)}
                    className="bg-[#FAF8F5] text-[#5A6B6B] font-semibold py-2.5 px-4 rounded-xl text-xs border border-[#E6E0D4] cursor-pointer"
                  >
                    বাতিল
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleConfirmPhoneChange} className="space-y-4">
                {/* OTP Simulation notice */}
                <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-950 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold flex items-center gap-1">
                      <span>📱 এসএমএস ওটিপি কোড:</span>
                      <strong className="text-base text-emerald-700 font-mono tracking-widest bg-white px-2 py-0.5 rounded border border-emerald-300">{phoneOtp}</strong>
                    </span>
                    <span className="text-[10px] bg-emerald-200 text-emerald-900 px-1.5 py-0.2 rounded font-bold">ডেমো এসএমএস</span>
                  </div>
                  <p className="text-[10px] text-[#3A5A40]">
                    বাস্তব টেলিকম গেটওয়ে ছাড়া অ্যাপে সরাসরি পরীক্ষার জন্য স্ক্রিনে ওটিপি দেখানো হয়েছে।
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                    {newPhoneInput} নম্বরে প্রেরিত ৪ সংখ্যার ওটিপি কোড লিখুন
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={4}
                    value={phoneOtpEntered}
                    onChange={(e) => setPhoneOtpEntered(e.target.value)}
                    placeholder="৪ সংখ্যার কোড"
                    className="w-full bg-[#FAF8F5] border-2 border-[#2D5A27] rounded-xl px-3.5 py-3 text-center text-lg font-bold tracking-widest text-[#2D3A3A] focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="submit"
                    className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-xl text-xs shadow-xs cursor-pointer"
                  >
                    যাচাই ও নম্বর পরিবর্তন সম্পন্ন করুন
                  </button>
                  <button
                    type="button"
                    onClick={() => setPhoneStep('input')}
                    className="bg-[#FAF8F5] text-[#5A6B6B] font-semibold py-2.5 px-4 rounded-xl text-xs border border-[#E6E0D4] cursor-pointer"
                  >
                    নম্বর পরিবর্তন
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Enlarged Photo Lightbox Modal (WhatsApp / Facebook style) */}
      {showEnlargedPhoto && displayAvatar && (
        <div 
          onClick={() => setShowEnlargedPhoto(false)}
          className="fixed inset-0 z-80 bg-black/95 backdrop-blur-lg flex flex-col items-center justify-center p-4 animate-in fade-in"
        >
          <div className="relative max-w-sm w-full flex flex-col items-center space-y-4">
            <button
              onClick={() => setShowEnlargedPhoto(false)}
              className="absolute -top-12 right-0 p-2 text-white/80 hover:text-white bg-white/10 rounded-full cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
            <img 
              src={displayAvatar} 
              alt={activeUser.name} 
              className="w-72 h-72 rounded-full object-cover border-4 border-emerald-500 shadow-2xl" 
            />
            <h4 className="text-xl font-bold text-white text-center">{activeUser.name}</h4>
          </div>
        </div>
      )}

      {/* Call Choice Modal for Profile */}
      {showCallChoiceModal && (
        <div className="fixed inset-0 z-70 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Noto_Sans_Bengali'] animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl border border-[#E6E0D4] relative">
            <button
              onClick={() => {
                setShowCallChoiceModal(false);
                setCallChoiceError(null);
              }}
              className="absolute top-4 right-4 p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-500 cursor-pointer"
            >
              ✕
            </button>

            <div className="w-12 h-12 rounded-2xl bg-[#E8F8F5] text-[#27AE60] flex items-center justify-center mx-auto shadow-xs">
              <Phone className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h3 className="text-lg font-bold text-[#2D3A3A]">কল অপশন ও মাধ্যম</h3>
              <p className="text-xs text-[#736B5E]">আপনার অ্যাকাউন্টের কল সেটিংস ও সংযোগ</p>
            </div>

            {callChoiceError && (
              <div className="bg-amber-50 text-amber-950 border border-amber-300 rounded-xl p-2.5 text-xs font-bold animate-in fade-in">
                ⚠️ {callChoiceError}
              </div>
            )}

            <div className="space-y-2.5 pt-2">
              {/* Option 1: Online Call with Active Call Button */}
              <div className="p-3.5 rounded-2xl border-2 border-[#2D5A27] bg-[#FDFBF7] text-left space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-[#2D5A27] flex items-center gap-1.5">
                    <span>🟢 অনলাইন ইন্টারনেট কল</span>
                    <span className="bg-[#27AE60] text-white text-[9px] px-2 py-0.2 rounded-full font-bold">সক্রিয়</span>
                  </span>
                </div>
                <p className="text-[11px] text-[#5A6B6B]">
                  ১০০% বিনামূল্যে ইন-অ্যাপ ইন্টারনেট অডিও কল। ফোন নম্বর সম্পূর্ণ গোপন থাকে।
                </p>
                
                {/* Active Button to place/test Online Call */}
                <button
                  type="button"
                  onClick={() => {
                    setShowCallChoiceModal(false);
                    onStartInAppCall?.(activeUser);
                  }}
                  className="w-full py-2.5 px-3 bg-[#2D5A27] hover:bg-[#23491E] text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-xs cursor-pointer mt-1"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>📞 অনলাইন কল দিন (টেস্ট / অডিও সংযোগ)</span>
                </button>
              </div>

              {/* Option 2: Offline Call Settings & Control with Direct Dial Button */}
              <div className="p-3.5 rounded-2xl border border-[#E6E0D4] bg-[#FAF8F5] text-left space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-[#2D3A3A] flex items-center gap-1.5">
                    <span>📱 অফলাইন সাধারণ সিম কল</span>
                    <span className={`text-[9px] px-2 py-0.2 rounded-full font-bold ${
                      activeUser.allowOfflineCall ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-200 text-gray-700'
                    }`}>
                      {activeUser.allowOfflineCall ? 'অনুমোদিত' : 'বন্ধ'}
                    </span>
                  </span>
                </div>

                <p className="text-[11px] text-[#5A6B6B]">
                  {activeUser.allowOfflineCall 
                    ? 'অন্য ব্যবহারকারীরা অনুমতি সাপেক্ষে আপনার সিমে সাধারণ ডায়ালারে সরাসরি কল করতে পারবেন।' 
                    : 'বর্তমানে অফলাইন কল বন্ধ রয়েছে। নম্বর সুরক্ষার জন্য শুধুমাত্র অনলাইন কল গ্রহণ করা হবে।'}
                </p>

                <div className="flex flex-col sm:flex-row gap-2 pt-1">
                  {/* DIRECT DIAL BUTTON - Only if permission is granted AND logged in */}
                  {activeUser.allowOfflineCall && activeUser.phone && currentUser ? (
                    <button
                      type="button"
                      onClick={() => {
                        setShowCallChoiceModal(false);
                        const clean = activeUser.phone ? activeUser.phone.replace(/[^0-9+]/g, '') : '';
                        if (clean) {
                          window.location.href = `tel:${clean}`;
                        }
                      }}
                      className="flex-1 py-2 px-3 bg-[#E8924A] hover:bg-[#D97D35] text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-xs text-center cursor-pointer"
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>📱 ডায়ালারে কল করুন</span>
                    </button>
                  ) : (
                    <div 
                      onClick={() => {
                        if (!currentUser) {
                          setCallChoiceError('আপনি বর্তমানে লগইন ছাড়া প্রিভিউ দেখছেন। অফলাইন ডায়াল করতে প্রথমে লগইন করুন।');
                        } else {
                          setCallChoiceError('অফলাইন কল বন্ধ রয়েছে। অনুমতি "অন" না করলে ডায়ালারে কল যাবে না এবং নম্বর সম্পূর্ণ গোপন থাকবে।');
                        }
                        setTimeout(() => setCallChoiceError(null), 5000);
                      }}
                      className="flex-1 py-2 px-3 bg-gray-100 text-gray-500 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border border-gray-200 cursor-not-allowed select-none"
                      title="অফলাইন কল বন্ধ"
                    >
                      <Lock className="w-3.5 h-3.5 text-gray-400" />
                      <span>🔒 অফলাইন কল বন্ধ (নম্বর অপ্রকাশ্য)</span>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      if (!currentUser) {
                        setCallChoiceError('অনুমতি পরিবর্তন করতে প্রথমে আপনার অ্যাকাউন্টে লগইন করুন।');
                        setTimeout(() => setCallChoiceError(null), 4000);
                        return;
                      }
                      handleToggleOfflineCall(!activeUser.allowOfflineCall);
                    }}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                      activeUser.allowOfflineCall 
                        ? 'bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300' 
                        : 'bg-[#2D5A27] hover:bg-[#23491E] text-white shadow-xs'
                    }`}
                  >
                    {activeUser.allowOfflineCall ? '🔒 অফলাইন কল বন্ধ করুন' : '✓ অফলাইন কল অনুমতি অন করুন'}
                  </button>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowCallChoiceModal(false);
                  setCallChoiceError(null);
                }}
                className="w-full py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

