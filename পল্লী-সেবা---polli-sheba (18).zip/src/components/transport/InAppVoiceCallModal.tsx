import React, { useState, useEffect, useRef } from 'react';
import { 
  PhoneOff, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Volume1,
  Plus,
  Minus,
  ShieldCheck, 
  Lock, 
  User, 
  Radio, 
  Sparkles,
  PhoneMissed,
  CheckCircle,
  WifiOff,
  Smartphone,
  X
} from 'lucide-react';
import { UserProfile } from '../../types/auth';
import { 
  DemandNotification, 
  saveDemandNotification, 
  MissedCallRecord,
  saveCloudCallRecord,
  createCallSession,
  updateCallSessionStatus,
  subscribeToCallSession
} from '../../lib/cloudSync';
import { agoraVoiceManager, AGORA_APP_ID } from '../../lib/agoraRtc';
import { audioTones, getMicrophonePermissionState, requestMicrophoneAccess } from '../../utils/audioTones';
import { dismissIncomingCallAlert } from '../../utils/notificationService';

interface InAppVoiceCallModalProps {
  recipientName: string;
  recipientRole: 'driver' | 'passenger' | 'seller' | 'buyer' | 'trader' | 'doctor' | 'donor' | 'mechanic' | 'tutor' | string;
  recipientPhoto?: string;
  recipientSubtitle: string; // e.g. "গাড়ি: ঢাকা-থ ১২-৩৪৫৬" or "ঘাটাইল, টাঙ্গাইল"
  maskedPhone: string;
  rawPhone?: string;
  currentUser?: UserProfile | null;
  allowOfflineCall?: boolean;
  initialCallState?: 'connecting' | 'connected';
  channelOverride?: string;
  onClose: () => void;
}

export const InAppVoiceCallModal: React.FC<InAppVoiceCallModalProps> = ({
  recipientName,
  recipientRole,
  recipientPhoto,
  recipientSubtitle,
  maskedPhone,
  rawPhone,
  currentUser,
  allowOfflineCall = false,
  initialCallState = 'connecting',
  channelOverride,
  onClose
}) => {
  // Call States: 'connecting' | 'ringing' | 'connected' | 'ended' | 'missed_call_left' | 'offline_prompt' | 'rejected'
  const [callState, setCallState] = useState<'connecting' | 'ringing' | 'connected' | 'ended' | 'missed_call_left' | 'offline_prompt' | 'rejected'>(initialCallState);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [volume, setVolume] = useState<number>(100);
  const [callDuration, setCallDuration] = useState(0);
  const [audioLevel, setAudioLevel] = useState<number[]>(new Array(16).fill(15));
  const [networkQuality, setNetworkQuality] = useState<'good' | 'poor' | 'offline'>('good');
  const [showEnlargedPhoto, setShowEnlargedPhoto] = useState(false);

  const ringTimeoutRef = useRef<any>(null);
  const sessionUnsubRef = useRef<(() => void) | null>(null);

  const myId = currentUser?.phone ? currentUser.phone.replace(/[^0-9]/g, '') : (currentUser?.id || 'guest_user');
  const targetId = rawPhone ? rawPhone.replace(/[^0-9]/g, '') : maskedPhone.replace(/[^0-9]/g, '');

  const activeChannelName = channelOverride || agoraVoiceManager.generateChannelName(myId, targetId);

  // Extract clean number for native SIM call (ACTION_DIAL)
  const cleanSimPhone = rawPhone ? rawPhone.replace(/[^0-9+]/g, '') : '';

  const handleLaunchNativeDialer = () => {
    if (cleanSimPhone) {
      window.location.href = `tel:${cleanSimPhone}`;
    }
  };

  // Microphone permission pre-call check state
  const [showMicPrompt, setShowMicPrompt] = useState<boolean>(false);
  const [micPromptError, setMicPromptError] = useState<string | null>(null);

  const playRingTone = () => {
    audioTones.playDialingTone();
  };

  const stopRingTone = () => {
    audioTones.stopDialingTone();
  };

  // Helper to record missed call for recipient if not answered within 45s
  const handleLeaveMissedCall = () => {
    stopRingTone();
    if (ringTimeoutRef.current) clearTimeout(ringTimeoutRef.current);
    agoraVoiceManager.leaveCall();
    updateCallSessionStatus(activeChannelName, 'missed').catch(() => {});

    const callerName = currentUser?.name || 'পল্লী সেবা নাগরিক';
    const callerPhone = currentUser?.phone || '০১৭xxxxxxxx';
    const recordId = `MC-${Date.now()}`;
    const now = new Date();

    const record: MissedCallRecord = {
      id: recordId,
      callerName,
      callerPhone,
      callerRole: currentUser?.role || 'নাগরিক',
      callerSubtitle: currentUser?.district ? `${currentUser.district}, ${currentUser.upazila || ''}` : undefined,
      recipientName,
      recipientPhone: rawPhone || maskedPhone,
      recipientRole,
      recipientSubtitle,
      timestamp: Date.now(),
      formattedDate: now.toLocaleDateString('bn-BD'),
      formattedTime: now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
      isCallbackDone: false,
      type: 'missed'
    };

    try {
      const existingRaw = localStorage.getItem('polli_missed_calls');
      const existing = existingRaw ? JSON.parse(existingRaw) : [];
      localStorage.setItem('polli_missed_calls', JSON.stringify([record, ...existing]));
      window.dispatchEvent(new Event('polli_missed_calls_updated'));
      saveCloudCallRecord(record).catch(() => {});

      // Save notification so recipient gets it when they open notifications
      const autoNotif: DemandNotification = {
        id: `notif-${recordId}`,
        title: `📞 মিসড কল: ${callerName} আপনাকে ইন-অ্যাপ কল করেছিলেন`,
        message: `${recipientSubtitle ? recipientSubtitle + ' • ' : ''}কলের সময়: ${record.formattedTime}। আপনি এই মুহূর্তে উত্তর দিতে পারেননি। ওনাকে কল ব্যাক করতে নিচে চাপুন।`,
        urgency: 'জরুরি',
        targetDistrict: 'সকল জেলা',
        targetUpazila: 'সকল উপজেলা',
        targetRole: 'missed_call',
        categoryName: 'মিসড কল',
        senderName: callerName,
        contactNumber: rawPhone || maskedPhone,
        actionUrl: `callback:${recordId}`,
        itemId: recordId,
        targetCategory: 'transport',
        createdAt: Date.now(),
        expiresAt: Date.now() + 24 * 60 * 60 * 1000,
        createdAtFormatted: 'এইমাত্র'
      };
      saveDemandNotification(autoNotif);
      // Also save dialed call record on caller's phone so dialed call history is 100% complete
      const dialedRecord: MissedCallRecord = {
        id: `DIAL-${recordId}`,
        callerName,
        callerPhone,
        callerRole: currentUser?.role || 'নাগরিক',
        callerSubtitle: currentUser?.district ? `${currentUser.district}, ${currentUser.upazila || ''}` : undefined,
        callerAvatar: currentUser?.customAvatarUrl,
        recipientName,
        recipientPhone: rawPhone || maskedPhone,
        recipientRole,
        recipientSubtitle,
        recipientAvatar: recipientPhoto,
        timestamp: Date.now(),
        formattedDate: now.toLocaleDateString('bn-BD'),
        formattedTime: now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
        isCallbackDone: true,
        type: 'dialed',
        duration: 'উত্তর মেলেনি'
      };
      saveCloudCallRecord(dialedRecord).catch(() => {});
    } catch (err) {
      console.warn('Could not record missed call:', err);
    }

    setCallState('missed_call_left');
  };

  // Start Agora / WebRTC Audio Call
  const startAudioCall = async () => {
    if (!navigator.onLine) {
      setNetworkQuality('offline');
      setCallState('offline_prompt');
      return;
    }

    // Pre-call Microphone Permission check
    try {
      const micAccess = await requestMicrophoneAccess();
      if (!micAccess.granted) {
        setShowMicPrompt(true);
        setMicPromptError(micAccess.error || 'মাইক্রোফোন ব্যবহারের অনুমতি প্রয়োজন।');
        return;
      }
    } catch {
      // Continue if browser doesn't block
    }

    try {
      await agoraVoiceManager.joinCall(activeChannelName, myId, {
        onCallConnected: () => {
          // Channel connected
          if (initialCallState === 'connected') {
            stopRingTone();
            if (ringTimeoutRef.current) clearTimeout(ringTimeoutRef.current);
            setCallState('connected');
          }
        },
        onRemoteUserJoined: () => {
          // Remote peer answered and joined room
          stopRingTone();
          if (ringTimeoutRef.current) clearTimeout(ringTimeoutRef.current);
          setCallState('connected');
        },
        onRemoteUserLeft: () => {
          handleEndCall(false);
        },
        onVolumeIndicator: (volumes) => {
          if (volumes && volumes.length > 0) {
            const level = volumes[0].level || 12;
            setAudioLevel(prev => {
              return prev.map(() => Math.max(8, Math.min(50, Math.floor(level * (0.8 + Math.random() * 0.4)))));
            });
          }
        },
        onError: (err) => {
          console.info('Voice call note:', err?.message || err);
          stopRingTone();
        },
        onConnectionStateChanged: (state) => {
          if (state === 'CONNECTED') {
            setNetworkQuality('good');
          } else if (state === 'RECONNECTING') {
            setNetworkQuality('poor');
          } else if (state === 'DISCONNECTED') {
            stopRingTone();
          }
        }
      });
    } catch (err: any) {
      console.info('Voice call initiation note:', err?.message || err);
    }
  };

  // Lifecycle transitions & Real-Time Bidirectional Session Sync
  useEffect(() => {
    if (!navigator.onLine) {
      setCallState('offline_prompt');
      return;
    }

    // 1. If receiving an answered call directly (Receiver side)
    if (initialCallState === 'connected') {
      setCallState('connected');
      dismissIncomingCallAlert(activeChannelName);
      startAudioCall();

      // RECEIVER REAL-TIME LISTENER: Immediately disconnects when caller hangs up!
      sessionUnsubRef.current = subscribeToCallSession(activeChannelName, (session) => {
        if (!session) return;
        if (session.status === 'ended') {
          handleEndCall(false);
        } else if (session.status === 'rejected') {
          handleEndCall(false);
        }
      });
      return;
    }

    // 2. Initiating an outgoing call (Caller side)
    const connectTimer = setTimeout(() => {
      setCallState('ringing');
      playRingTone();
      startAudioCall();

      // Create live session in Firestore so recipient's device gets incoming call alert!
      createCallSession({
        channelId: activeChannelName,
        callerId: myId,
        callerName: currentUser?.name || 'পল্লী সেবা নাগরিক',
        callerAvatar: currentUser?.customAvatarUrl || '',
        callerRole: currentUser?.role || 'নাগরিক',
        callerPhone: currentUser?.phone || '',
        recipientId: targetId,
        recipientName,
        recipientPhone: rawPhone || maskedPhone,
        recipientAvatar: recipientPhoto,
        recipientRole,
        recipientSubtitle,
        status: 'ringing',
        createdAt: Date.now()
      }).catch(() => {});

      // CALLER REAL-TIME LISTENER: Listens for recipient response or remote hangup
      sessionUnsubRef.current = subscribeToCallSession(activeChannelName, (session) => {
        if (!session) return;
        if (session.status === 'accepted') {
          stopRingTone();
          if (ringTimeoutRef.current) clearTimeout(ringTimeoutRef.current);
          setCallState('connected');
        } else if (session.status === 'rejected') {
          stopRingTone();
          if (ringTimeoutRef.current) clearTimeout(ringTimeoutRef.current);
          setCallState('rejected');
          setTimeout(() => {
            onClose();
          }, 2500);
        } else if (session.status === 'ended') {
          handleEndCall(false);
        }
      });

      // Standard phone ringing duration: 45 seconds
      ringTimeoutRef.current = setTimeout(() => {
        handleLeaveMissedCall();
      }, 45000);
    }, 1000);

    const handleOffline = () => {
      setNetworkQuality('offline');
      setCallState('offline_prompt');
    };
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('offline', handleOffline);
      clearTimeout(connectTimer);
      if (ringTimeoutRef.current) clearTimeout(ringTimeoutRef.current);
      if (sessionUnsubRef.current) sessionUnsubRef.current();
      stopRingTone();
      agoraVoiceManager.leaveCall();
      dismissIncomingCallAlert(activeChannelName);
    };
  }, []);

  // Duration Timer
  useEffect(() => {
    let interval: any = null;
    if (callState === 'connected') {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [callState]);

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const remainingSecs = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  const handleToggleMute = async () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    agoraVoiceManager.setMuted(nextMute);
  };

  const handleVolumeChange = (newVol: number) => {
    const clamped = Math.max(0, Math.min(100, Math.round(newVol)));
    setVolume(clamped);
    agoraVoiceManager.setPlaybackVolume(clamped);
    if (clamped === 0) {
      setIsSpeakerOn(false);
    } else if (!isSpeakerOn) {
      setIsSpeakerOn(true);
    }
  };

  const handleToggleSpeaker = () => {
    const nextSpeaker = !isSpeakerOn;
    setIsSpeakerOn(nextSpeaker);
    if (!nextSpeaker) {
      // Earpiece mode / lower volume
      handleVolumeChange(35);
    } else {
      // Loudspeaker full volume
      handleVolumeChange(100);
    }
  };

  const handleEndCall = (isLocalInitiator: boolean = true) => {
    stopRingTone();
    audioTones.stopAll();
    audioTones.playCallEndTone();
    if (ringTimeoutRef.current) clearTimeout(ringTimeoutRef.current);
    if (sessionUnsubRef.current) sessionUnsubRef.current();
    agoraVoiceManager.leaveCall();
    dismissIncomingCallAlert(activeChannelName);

    if (isLocalInitiator) {
      updateCallSessionStatus(activeChannelName, 'ended').catch(() => {});
    }
    
    // If call was connected or had duration, record completed call entry
    const isCaller = initialCallState !== 'connected';
    if (callDuration > 0 || callState === 'connected') {
      const now = new Date();
      const completedRecord: MissedCallRecord = {
        id: `CALL-${Date.now()}`,
        callerName: currentUser?.name || 'পল্লী সেবা নাগরিক',
        callerPhone: currentUser?.phone || '০১৭xxxxxxxx',
        callerRole: currentUser?.role || 'নাগরিক',
        callerSubtitle: currentUser?.district ? `${currentUser.district}, ${currentUser.upazila || ''}` : undefined,
        callerAvatar: currentUser?.customAvatarUrl,
        recipientName,
        recipientPhone: rawPhone || maskedPhone,
        recipientRole,
        recipientSubtitle,
        recipientAvatar: recipientPhoto,
        timestamp: Date.now(),
        formattedDate: now.toLocaleDateString('bn-BD'),
        formattedTime: now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
        isCallbackDone: true,
        type: isCaller ? 'dialed' : 'received',
        duration: formatDuration(callDuration)
      };
      saveCloudCallRecord(completedRecord).catch(() => {});
    } else if (isCaller && (callState === 'ringing' || callState === 'connecting')) {
      // Caller hung up before callee picked up -> record as dialed call
      const now = new Date();
      const dialedRecord: MissedCallRecord = {
        id: `DIAL-${Date.now()}`,
        callerName: currentUser?.name || 'পল্লী সেবা নাগরিক',
        callerPhone: currentUser?.phone || '০১৭xxxxxxxx',
        callerRole: currentUser?.role || 'নাগরিক',
        callerSubtitle: currentUser?.district ? `${currentUser.district}, ${currentUser.upazila || ''}` : undefined,
        callerAvatar: currentUser?.customAvatarUrl,
        recipientName,
        recipientPhone: rawPhone || maskedPhone,
        recipientRole,
        recipientSubtitle,
        recipientAvatar: recipientPhoto,
        timestamp: Date.now(),
        formattedDate: now.toLocaleDateString('bn-BD'),
        formattedTime: now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
        isCallbackDone: true,
        type: 'dialed',
        duration: 'উত্তর মেলেনি'
      };
      saveCloudCallRecord(dialedRecord).catch(() => {});
    }

    setCallState('ended');
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <>
      <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-200">
        <div className="bg-[#121B22] text-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-[#27AE60]/40 flex flex-col items-center justify-between min-h-[520px] relative overflow-hidden">
          
          {/* Subtle audio waves background */}
          <div className="absolute inset-0 bg-radial from-[#2D5A27]/20 to-transparent pointer-events-none" />

          {/* Top Encrypted Call Status Header */}
          <div className="w-full flex items-center justify-between relative z-10">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1E2A32] border border-white/10 text-[11px] font-bold text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>১০০% সুরক্ষিত ইন-অ্যাপ অডিও কল</span>
            </div>
            
            <button
              onClick={handleEndCall}
              className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Recipient Profile Section (WhatsApp style: Centered Circular Avatar directly above Name) */}
          <div className="flex flex-col items-center text-center space-y-3 my-auto relative z-10 w-full">
            
            {/* Circular Profile Avatar (Tappable to enlarge full size) */}
            <div className="relative group cursor-pointer" onClick={() => recipientPhoto && setShowEnlargedPhoto(true)}>
              <div className="w-28 h-28 rounded-full border-4 border-[#27AE60] flex items-center justify-center shadow-xl overflow-hidden bg-[#1E2A32] transition transform group-hover:scale-105">
                {recipientPhoto ? (
                  <img 
                    src={recipientPhoto} 
                    alt={recipientName} 
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-4xl font-extrabold text-[#2ECC71] bg-[#1E3E1A]">
                    {recipientName ? recipientName.charAt(0) : 'প'}
                  </div>
                )}
              </div>

              {/* Verified badge pin */}
              <div className="absolute bottom-0 right-1 bg-[#27AE60] p-1.5 rounded-full border-2 border-[#121B22] text-white shadow-xs">
                <User className="w-3.5 h-3.5" />
              </div>
            </div>
            <p className="text-[10px] text-gray-400">ছবিতে ট্যাপ করলে বড় হবে</p>

            {/* Recipient Details */}
            <div className="space-y-1">
              <h3 className="text-xl font-bold text-white tracking-wide flex items-center justify-center gap-1.5">
                <span>{recipientName}</span>
                <ShieldCheck className="w-4 h-4 text-[#2ECC71]" />
              </h3>

              <p className="text-xs text-gray-400 max-w-[240px] truncate mx-auto">
                {recipientSubtitle || 'পল্লী সেবা সদস্য'}
              </p>

              {/* Number Masking Notice */}
              <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-[10px] text-gray-300">
                <Lock className="w-2.5 h-2.5 text-emerald-400" />
                <span>নম্বর সম্পূর্ণ গোপন (ডায়ালারে অপ্রকাশ্য)</span>
              </div>
            </div>

            {/* Current Dynamic Status */}
            <div className="pt-2">
              {callState === 'connecting' && (
                <div className="flex items-center justify-center gap-2 text-xs font-semibold text-emerald-400 animate-pulse">
                  <Radio className="w-3.5 h-3.5 animate-spin" />
                  <span>সংযোগ স্থাপন হচ্ছে...</span>
                </div>
              )}

              {callState === 'ringing' && (
                <div className="space-y-1">
                  <div className="flex items-center justify-center gap-2 text-xs font-bold text-[#F1C40F] animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-[#F1C40F] animate-ping" />
                    <span>রিং হচ্ছে... (উত্তরের অপেক্ষায়)</span>
                  </div>
                  <p className="text-[10px] text-gray-400">অনলাইনে রিং বাজছে (সর্বোচ্চ ৪৫ সেকেন্ড)</p>
                </div>
              )}

              {callState === 'connected' && (
                <div className="space-y-1.5">
                  <div className="text-sm font-mono font-bold text-[#2ECC71] flex items-center justify-center gap-1.5 bg-[#1E2A32] px-4 py-1.5 rounded-full border border-emerald-500/30">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#2ECC71] animate-pulse" />
                    <span>কথা চলছে • {formatDuration(callDuration)}</span>
                  </div>

                  {/* Equalizer bars */}
                  <div className="flex items-center justify-center gap-1 h-8 pt-1">
                    {audioLevel.map((height, i) => (
                      <div 
                        key={i} 
                        className="w-1 bg-[#2ECC71] rounded-full transition-all duration-100"
                        style={{ 
                          height: `${isMuted ? 4 : height}px`,
                          opacity: isMuted ? 0.3 : 0.85
                        }}
                      />
                    ))}
                  </div>
                </div>
              )}

              {callState === 'rejected' && (
                <div className="text-xs text-red-400 font-bold bg-red-950/60 border border-red-500/40 px-3 py-1.5 rounded-xl">
                  কলটি অপর প্রান্ত থেকে বাতিল করা হয়েছে।
                </div>
              )}

              {callState === 'ended' && (
                <div className="text-xs text-red-400 font-bold">
                  কল সমাপ্ত হয়েছে
                </div>
              )}

              {/* Missed Call Left State (when 45s expires) */}
              {callState === 'missed_call_left' && (
                <div className="bg-[#1E2A32] border border-amber-500/40 rounded-2xl p-4 text-center space-y-2 animate-in fade-in">
                  <div className="w-10 h-10 bg-amber-500/20 text-[#F39C12] rounded-full flex items-center justify-center mx-auto">
                    <PhoneMissed className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">
                    অপর প্রান্ত এই মুহূর্তে উত্তর দেননি
                  </h4>
                  <p className="text-xs text-white/80 leading-relaxed">
                    আপনার কলটি একটি <strong>'মিসড কল'</strong> হিসেবে ওনার অ্যাকাউন্টে জমা হয়েছে। তিনি অনলাইনে আসলেই দেখতে পাবেন এবং আপনাকে কল ব্যাক করতে পারবেন।
                  </p>
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={handleEndCall}
                      className="w-full py-2 bg-[#27AE60] hover:bg-[#219150] text-white rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>বুঝেছি (প্রস্থান করুন)</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Offline Call Prompt State (When network is offline) */}
              {callState === 'offline_prompt' && (
                <div className="bg-[#2D1A1A]/80 border border-amber-500/40 rounded-2xl p-4 text-center space-y-2.5 animate-in fade-in">
                  <div className="w-10 h-10 bg-amber-500/20 text-amber-400 rounded-full flex items-center justify-center mx-auto">
                    <WifiOff className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">
                    ইন্টারনেট সংযোগ বিচ্ছিন্ন (অফলাইন)
                  </h4>
                  <p className="text-xs text-white/80 leading-relaxed">
                    ইন্টারনেট না থাকায় অনলাইন কল করা যাচ্ছে না।
                  </p>
                  <div className="pt-1 space-y-2">
                    {allowOfflineCall && cleanSimPhone ? (
                      <button
                        type="button"
                        onClick={handleLaunchNativeDialer}
                        className="w-full py-2.5 bg-[#E8924A] hover:bg-[#D97D35] text-white rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-2 shadow-md"
                      >
                        <Smartphone className="w-4 h-4" />
                        <span>সিমে কল করুন (ডায়ালারে যান)</span>
                      </button>
                    ) : (
                      <div className="bg-white/10 p-2.5 rounded-xl text-xs text-amber-300 font-medium">
                        🔒 অপর প্রান্তের ব্যবহারকারী অফলাইন কল বন্ধ রেখেছেন। ফোন নম্বর গোপন রাখা হয়েছে।
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={handleEndCall}
                      className="w-full py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-medium transition cursor-pointer"
                    >
                      বাতিল করুন
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>

          {/* Privacy badge */}
          <div className="w-full bg-white/5 rounded-2xl p-2.5 text-center text-[10px] text-white/70 border border-white/5 space-y-0.5 my-2 relative z-10">
            <div className="flex items-center justify-center gap-1 text-[#2ECC71] font-semibold">
              <Sparkles className="w-3 h-3" />
              <span>প্রাইভেসী প্রটেকশন মোড সক্রিয় (Agora RTC Engine)</span>
            </div>
            <p>আপনার ব্যক্তিগত নম্বর অপর পক্ষের কাছে সম্পূর্ণ গোপন রাখা হচ্ছে।</p>
          </div>

          {/* Physical Hardware Volume Info (ফোনের হার্ডওয়্যার বাটন দিয়ে সরাসরি ভলিউম নিয়ন্ত্রণ) */}
          {callState !== 'missed_call_left' && callState !== 'offline_prompt' && (
            <div className="w-full bg-white/5 backdrop-blur-xs rounded-2xl px-3 py-2 my-2 border border-white/10 flex items-center justify-between text-xs text-white/90 relative z-10">
              <span className="flex items-center gap-1.5 text-[11px] font-medium text-emerald-300">
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span>ফোনের সাইড ভলিউম (+ / -) বাটন চেপে আওয়াজ নিয়ন্ত্রণ করুন</span>
              </span>
              <span className="font-mono text-emerald-400 text-[10px] font-bold bg-black/30 px-2 py-0.5 rounded-md border border-white/10">
                হার্ডওয়্যার অডিও
              </span>
            </div>
          )}

          {/* Action Controls: Loudspeaker, Mute, Red Hangup Button (WhatsApp style) */}
          {callState !== 'missed_call_left' && callState !== 'offline_prompt' && (
            <div className="w-full pt-3 border-t border-white/10 flex items-center justify-around relative z-10">
              
              {/* Loudspeaker Button */}
              <div className="flex flex-col items-center gap-1">
                <button
                  type="button"
                  onClick={handleToggleSpeaker}
                  className={`w-12 h-12 rounded-full border transition cursor-pointer flex items-center justify-center ${
                    isSpeakerOn 
                      ? 'bg-emerald-600 text-white border-transparent shadow-md' 
                      : 'bg-white/10 hover:bg-white/20 text-white border-white/10'
                  }`}
                  title={isSpeakerOn ? 'লাউডস্পিকার অন' : 'ইয়ারপিস মোড'}
                >
                  {isSpeakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                </button>
                <span className="text-[10px] text-gray-300 font-medium">
                  {isSpeakerOn ? 'স্পিকার অন' : 'স্পিকার অফ'}
                </span>
              </div>

              {/* Large Red Hangup Button */}
              <div className="flex flex-col items-center gap-1">
                <button
                  type="button"
                  onClick={handleEndCall}
                  className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 active:scale-95 text-white shadow-xl transition cursor-pointer border-2 border-white/20 flex items-center justify-center animate-in"
                  title="কল শেষ করুন"
                >
                  <PhoneOff className="w-7 h-7" />
                </button>
                <span className="text-[11px] text-red-400 font-bold">কল কাটুন</span>
              </div>

              {/* Mute Microphone Button */}
              <div className="flex flex-col items-center gap-1">
                <button
                  type="button"
                  onClick={handleToggleMute}
                  disabled={callState !== 'connected'}
                  className={`w-12 h-12 rounded-full border transition cursor-pointer flex items-center justify-center ${
                    isMuted 
                      ? 'bg-red-500 text-white border-transparent' 
                      : 'bg-white/10 hover:bg-white/20 text-white border-white/10'
                  } ${callState !== 'connected' ? 'opacity-40 cursor-not-allowed' : ''}`}
                  title={isMuted ? 'আনমিউট করুন' : 'মিউট করুন'}
                >
                  {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>
                <span className="text-[10px] text-gray-300 font-medium">
                  {isMuted ? 'মিউট' : 'আনমিউট'}
                </span>
              </div>

            </div>
          )}

        </div>
      </div>

      {/* Pre-Call Microphone Runtime Permission Prompt Modal */}
      {showMicPrompt && (
        <div className="fixed inset-0 z-90 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-[#1A252C] border border-emerald-500/40 rounded-3xl p-6 max-w-sm w-full text-center space-y-4 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
              <Mic className="w-8 h-8 animate-pulse text-emerald-400" />
            </div>

            <div className="space-y-1.5">
              <h3 className="text-lg font-bold text-white">
                মাইক্রোফোনের অনুমতি প্রয়োজন
              </h3>
              <p className="text-xs text-gray-300 leading-relaxed">
                পল্লী সেবা সুরক্ষিত অডিও কলে পরিষ্কার কথা বলতে আপনার ডিভাইসের মাইক্রোফোন ব্যবহারের অনুমতি দিন।
              </p>
            </div>

            {micPromptError && (
              <div className="bg-red-950/60 border border-red-500/40 rounded-2xl p-3 text-xs text-red-300 text-left space-y-1">
                <p className="font-bold text-red-200">⚠️ পারমিশন সহায়িকা:</p>
                <p>{micPromptError}</p>
                <p className="text-[11px] text-gray-400">
                  পরামর্শ: ব্রাউজারের উপরে অ্যাড্রেস বারের তালা (Lock) আইকনে চাপ দিয়ে Microphone "Allow" করে পেজটি রিফ্রেশ করুন।
                </p>
              </div>
            )}

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={async () => {
                  const res = await requestMicrophoneAccess();
                  if (res.granted) {
                    setShowMicPrompt(false);
                    setMicPromptError(null);
                    startAudioCall();
                  } else {
                    setMicPromptError(res.error || 'মাইক্রোফোনের অনুমতি পাওয়া যায়নি।');
                  }
                }}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white rounded-2xl text-xs font-bold transition shadow-lg flex items-center justify-center gap-2 cursor-pointer"
              >
                <Mic className="w-4 h-4" />
                <span>অনুমতি দিন (Allow Microphone)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowMicPrompt(false);
                  handleEndCall(false);
                }}
                className="w-full py-2.5 bg-white/10 hover:bg-white/20 text-gray-300 rounded-2xl text-xs font-semibold transition cursor-pointer"
              >
                বাতিল করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Enlarged Photo Lightbox Modal (WhatsApp/Facebook style) */}
      {showEnlargedPhoto && recipientPhoto && (
        <div 
          onClick={() => setShowEnlargedPhoto(false)}
          className="fixed inset-0 z-80 bg-black/95 backdrop-blur-lg flex flex-col items-center justify-center p-4 animate-in fade-in"
        >
          <div className="relative max-w-sm w-full flex flex-col items-center space-y-4">
            <button
              onClick={() => setShowEnlargedPhoto(false)}
              className="absolute -top-12 right-0 p-2 text-white/80 hover:text-white bg-white/10 rounded-full cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
            <img 
              src={recipientPhoto} 
              alt={recipientName} 
              className="w-72 h-72 rounded-full object-cover border-4 border-emerald-500 shadow-2xl" 
            />
            <h4 className="text-xl font-bold text-white text-center">{recipientName}</h4>
          </div>
        </div>
      )}
    </>
  );
};
