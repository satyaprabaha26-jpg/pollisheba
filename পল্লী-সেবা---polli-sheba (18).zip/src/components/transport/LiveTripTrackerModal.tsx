import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Navigation, 
  Share2, 
  ShieldCheck, 
  Clock, 
  Copy, 
  Check, 
  AlertTriangle, 
  PhoneCall, 
  X, 
  Compass, 
  Car, 
  CheckCircle2,
  Lock,
  BatteryCharging,
  Radio,
  FileText
} from 'lucide-react';
import { TransportDriver, TripLog } from '../../types';

interface LiveTripTrackerModalProps {
  driver: TransportDriver;
  passengerName?: string;
  passengerPhone?: string;
  passengerPhotoUrl?: string;
  startLocation: string;
  destination: string;
  onClose: () => void;
  onTripCompleted?: (log: TripLog) => void;
}

export const LiveTripTrackerModal: React.FC<LiveTripTrackerModalProps> = ({
  driver,
  passengerName = 'নিবন্ধিত সম্মানিত যাত্রী',
  passengerPhone = '০১৭০০০০০০০০',
  passengerPhotoUrl,
  startLocation,
  destination,
  onClose,
  onTripCompleted
}) => {
  const [tripId] = useState<string>(() => `TRIP-${Math.floor(100000 + Math.random() * 900000)}`);
  const [trackingToken] = useState<string>(() => `TK-${Math.floor(10000 + Math.random() * 90000)}`);
  const [progressPercent, setProgressPercent] = useState<number>(15);
  const [speedKmh, setSpeedKmh] = useState<number>(28);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [tripStatus, setTripStatus] = useState<'active' | 'completed' | 'cancelled'>('active');
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [tripDistance] = useState<number>(() => Number((3.5 + Math.random() * 6.5).toFixed(1)));
  const [startTime] = useState<string>(() => new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true }));

  const trackingUrl = `https://polli-sheba.app/track/${tripId}?tk=${trackingToken}`;

  // Live GPS progression simulation
  useEffect(() => {
    if (tripStatus !== 'active') return;

    const timer = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
      setProgressPercent(prev => {
        if (prev >= 98) {
          return 98;
        }
        return prev + 1.2;
      });
      // Slight speed variations
      setSpeedKmh(Math.floor(24 + Math.random() * 12));
    }, 1500);

    return () => clearInterval(timer);
  }, [tripStatus]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(trackingUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const handleShareWhatsApp = () => {
    const msg = `🛡️ নিরাপদ যাত্রা লাইভ ট্র্যাকিং (পল্লী সেবা):\n\nআমি বর্তমানে গাড়িতে ভ্রমণ করছি।\n• চালকের নাম: ${driver.driverName}\n• গাড়ির নম্বর: ${driver.vehicleNumber} (${driver.vehicleType})\n• শুরুর স্থান: ${startLocation}\n• গন্তব্য: ${destination}\n\n🔗 পরিবারের জন্য লাইভ জিপিএস ট্র্যাকিং লিংক:\n${trackingUrl}\n\n⚠️ দ্রষ্টব্য: যাত্রা শেষ বা বাতিল হওয়ামাত্রই লিংকটির কার্যকারিতা স্বয়ংক্রিয়ভাবে অকার্যকর (Expired) হয়ে যাবে।\nজরুরিতে জাতীয় জরুরি হেল্পলাইন ৯৯৯ এ কল করুন।`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handleEndTrip = (finalStatus: 'completed' | 'cancelled') => {
    setTripStatus(finalStatus);
    const endTimeStr = new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true });
    
    // Save to completed route history for Admin and Law Enforcement auditing
    const completedLog: TripLog = {
      id: `log-${Date.now()}`,
      tripId,
      passengerName,
      passengerPhone, // Saved securely in database for admin/police audit only
      driverId: driver.id,
      driverName: driver.driverName,
      driverPhone: driver.phone, // Saved securely in database for admin/police audit only
      vehicleType: driver.vehicleType,
      vehicleNumber: driver.vehicleNumber,
      district: driver.district,
      startLocation,
      destination,
      startTime: `${new Date().toLocaleDateString('bn-BD')} ${startTime}`,
      endTime: `${new Date().toLocaleDateString('bn-BD')} ${endTimeStr}`,
      startTimestamp: Date.now() - elapsedSeconds * 1000,
      endTimestamp: Date.now(),
      distanceKm: tripDistance,
      durationMinutes: Math.max(1, Math.round(elapsedSeconds / 60)),
      status: finalStatus === 'completed' ? 'সম্পন্ন (Completed)' : 'বাতিল (Cancelled)',
      trackingToken,
      trackingLinkUrl: trackingUrl,
      isTrackingExpired: true,
      notes: finalStatus === 'completed' 
        ? 'যাত্রা সফলভাবে সম্পন্ন হয়েছে। ট্র্যাকিং লিংক স্বয়ংক্রিয়ভাবে অকার্যকর হয়েছে।'
        : 'যাত্রা বাতিল করা হয়েছে। ট্র্যাকিং লিংক অবিলম্বে বাতিল।'
    };

    try {
      const existingLogs: TripLog[] = JSON.parse(localStorage.getItem('polli_route_history') || '[]');
      localStorage.setItem('polli_route_history', JSON.stringify([completedLog, ...existingLogs]));
    } catch (e) {
      console.error('Error saving trip log:', e);
    }

    if (onTripCompleted) {
      onTripCompleted(completedLog);
    }
  };

  const formatElapsed = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins} মিনিট ${s < 10 ? '0' : ''}${s} সেকেন্ড`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto font-['Noto_Sans_Bengali']">
      <div className="bg-white rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] max-h-[94vh] overflow-y-auto space-y-4">
        
        {/* Modal Top Header */}
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#2D5A27] text-white flex items-center justify-center">
              <Navigation className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-[#2D3A3A]">
                  লাইভ রাইড ট্র্যাকিং ও রুট মনিটরিং
                </h3>
                {tripStatus === 'active' ? (
                  <span className="bg-[#E8F8F5] text-[#27AE60] border border-[#27AE60]/40 text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse">
                    <Radio className="w-3 h-3 text-[#27AE60]" />
                    লাইভ সচল
                  </span>
                ) : (
                  <span className="bg-[#FADBD8] text-[#C0392B] text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                    🚫 লিংক মেয়াদোত্তীর্ণ (Expired)
                  </span>
                )}
              </div>
              <p className="text-[11px] text-[#736B5E]">
                ট্রিপ আইডি: <strong className="text-[#2D3A3A] font-mono">{tripId}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-[#736B5E] hover:text-[#2D3A3A] text-lg font-bold p-1 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live GPS Map Visual Canvas Simulator */}
        <div className="relative bg-[#1E3F1A] rounded-2xl p-4 text-white overflow-hidden shadow-inner border border-[#2D5A27]">
          {/* Background Map Grid & Roads */}
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#FAF8F5_1px,transparent_1px)] [background-size:16px_16px]" />
          
          <div className="relative z-10 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5 text-[#D4E4BC] font-semibold">
                <Compass className="w-3.5 h-3.5 text-[#E8924A] animate-spin" style={{ animationDuration: '6s' }} />
                <span>জিপিএস স্যাটেলাইট কানেকশন সক্রিয়</span>
              </span>
              <span className="flex items-center gap-1 text-[11px] text-[#D4E4BC] bg-white/10 px-2 py-0.5 rounded-full">
                <BatteryCharging className="w-3 h-3 text-[#27AE60]" />
                <span>গতি: {speedKmh} কিমি/ঘণ্টা</span>
              </span>
            </div>

            {/* Visual Route Track Path */}
            <div className="py-2">
              <div className="flex items-center justify-between text-[11px] text-[#D4E4BC] mb-1.5 font-medium">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-[#E8924A]" />
                  <span>{startLocation}</span>
                </span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-[#27AE60]" />
                  <span>{destination}</span>
                </span>
              </div>

              {/* Progress Bar with Moving Vehicle Beacon */}
              <div className="relative w-full bg-white/20 h-3 rounded-full overflow-visible">
                <div 
                  className="bg-linear-to-r from-[#E8924A] to-[#27AE60] h-full rounded-full transition-all duration-1000 ease-out"
                  style={{ width: `${progressPercent}%` }}
                />
                <div 
                  className="absolute -top-2.5 transition-all duration-1000 ease-out flex flex-col items-center"
                  style={{ left: `calc(${progressPercent}% - 12px)` }}
                >
                  <div className="w-7 h-7 bg-white text-[#2D5A27] rounded-full shadow-lg flex items-center justify-center border-2 border-[#E8924A] animate-bounce">
                    <Car className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-white/15 text-xs">
              <div className="bg-white/10 p-2 rounded-xl">
                <div className="text-[10px] text-[#D4E4BC]">অতিক্রান্ত সময়</div>
                <div className="font-bold text-white mt-0.5">{formatElapsed(elapsedSeconds)}</div>
              </div>
              <div className="bg-white/10 p-2 rounded-xl">
                <div className="text-[10px] text-[#D4E4BC]">মোট দূরত্ব</div>
                <div className="font-bold text-white mt-0.5">{tripDistance} কিমি</div>
              </div>
              <div className="bg-white/10 p-2 rounded-xl">
                <div className="text-[10px] text-[#D4E4BC]">আনুমানিক স্থিতি</div>
                <div className="font-bold text-[#E8924A] mt-0.5">
                  {progressPercent > 90 ? 'গন্তব্যের নিকটে' : 'চলমান'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Privacy Guard & Profile Cards (Zero Phone Number Exposure) */}
        <div className="bg-[#FAF8F5] border border-[#E6E0D4] p-3.5 rounded-2xl space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#2D5A27] flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" />
              <span>প্রাইভেসি আর্কিটেকচার (উভয়ের ফোন নম্বর সম্পূর্ণ গোপন)</span>
            </span>
            <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] font-extrabold px-2 py-0.5 rounded-full">
              সুরক্ষিত
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {/* Driver Profile */}
            <div className="bg-white p-3 rounded-xl border border-[#E6E0D4] flex items-center gap-2.5">
              {driver.facePhotoUrl ? (
                <img src={driver.facePhotoUrl} alt="Driver" className="w-10 h-10 rounded-xl object-cover border border-[#2D5A27]" />
              ) : (
                <div className="w-10 h-10 rounded-xl bg-[#2D5A27] text-white flex items-center justify-center font-bold text-sm">
                  {driver.driverName.charAt(0)}
                </div>
              )}
              <div className="space-y-0.5">
                <div className="font-bold text-[#2D3A3A] flex items-center gap-1">
                  <span>{driver.driverName}</span>
                  <ShieldCheck className="w-3.5 h-3.5 text-[#27AE60]" />
                </div>
                <p className="text-[#5A6B6B] text-[11px]">
                  গাড়ির নং: <strong className="text-[#2D3A3A]">{driver.vehicleNumber}</strong>
                </p>
                <p className="text-[10px] text-[#27AE60] font-semibold">ফোন নম্বর: গোপন ও সুরক্ষিত 🔒</p>
              </div>
            </div>

            {/* Passenger Profile */}
            <div className="bg-white p-3 rounded-xl border border-[#E6E0D4] flex items-center gap-2.5">
              {passengerPhotoUrl ? (
                <img src={passengerPhotoUrl} alt="Passenger" className="w-10 h-10 rounded-xl object-cover border border-[#E8924A]" />
              ) : (
                <div className="w-10 h-10 rounded-xl bg-[#E8924A] text-white flex items-center justify-center font-bold text-sm">
                  {passengerName.charAt(0)}
                </div>
              )}
              <div className="space-y-0.5">
                <div className="font-bold text-[#2D3A3A] flex items-center gap-1">
                  <span>{passengerName}</span>
                  <span className="bg-[#E8F8F5] text-[#27AE60] text-[9px] px-1.5 py-0.2 rounded-full font-bold">যাত্রী</span>
                </div>
                <p className="text-[#5A6B6B] text-[11px]">রুট: {startLocation} ➔ {destination}</p>
                <p className="text-[10px] text-[#27AE60] font-semibold">ফোন নম্বর: গোপন ও সুরক্ষিত 🔒</p>
              </div>
            </div>
          </div>
        </div>

        {/* Ephemeral Live Location Sharing Box */}
        {tripStatus === 'active' ? (
          <div className="bg-[#FFF9E6] border border-[#F6E05E] p-3.5 rounded-2xl space-y-2.5">
            <div className="flex items-start gap-2 text-xs text-[#7B4F12]">
              <Clock className="w-4 h-4 text-[#E8924A] shrink-0 mt-0.5" />
              <div>
                <strong className="block font-bold">পরিবারের জন্য অস্থায়ী ট্র্যাকিং লিংক (Auto-Expiring):</strong>
                <p className="text-[11px] text-[#8C5D17] leading-relaxed mt-0.5">
                  নিচে প্রদর্শিত অস্থায়ী লিংকটি পরিবার বা পরিজনদের সাথে শেয়ার করুন। যাত্রা শেষ হওয়া মাত্রই উক্ত লিংকের কার্যকারিতা স্বয়ংক্রিয়ভাবে চিরতরে বিলুপ্ত হবে।
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex-1 bg-white border border-[#D4C3A3] rounded-xl px-3 py-1.5 text-xs text-[#5A6B6B] font-mono truncate select-all">
                {trackingUrl}
              </div>

              <button
                onClick={handleCopyLink}
                className="bg-white hover:bg-[#FAF8F5] border border-[#D4C3A3] text-[#2D3A3A] px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#27AE60]" />
                    <span className="text-[#27AE60]">কপি হয়েছে</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>কপি</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <button
                onClick={handleShareWhatsApp}
                className="flex-1 bg-[#25D366] hover:bg-[#20BE5A] text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer transition"
              >
                <Share2 className="w-4 h-4" />
                <span>হোয়াটসঅ্যাপে পরিবারের কাছে পাঠান</span>
              </button>

              <a
                href="tel:999"
                className="bg-[#C0392B] hover:bg-[#A93226] text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition shrink-0"
                title="জরুরি পুলিশ সহায়তা"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>জরুরি ৯৯৯</span>
              </a>
            </div>
          </div>
        ) : (
          <div className="p-4 bg-[#FADBD8]/40 border border-[#C0392B]/30 rounded-2xl text-center space-y-1.5">
            <div className="flex items-center justify-center gap-1.5 text-[#C0392B] font-bold text-xs">
              <AlertTriangle className="w-4 h-4" />
              <span>ট্র্যাকিং লিংকের মেয়াদ সমাপ্ত (Expired)</span>
            </div>
            <p className="text-[11px] text-[#5A6B6B] max-w-md mx-auto">
              যাত্রা {tripStatus === 'completed' ? 'সম্পন্ন' : 'বাতিল'} হওয়ায় পরিবারের জন্য শেয়ারকৃত ট্র্যাকিং লিংকটি স্বয়ংক্রিয়ভাবে অকার্যকর করা হয়েছে। আইন প্রয়োগকারী সংস্থার নিরীক্ষার জন্য রুট লগ কেন্দ্রীয় ডাটাবেজে সংরক্ষিত হয়েছে।
            </p>
          </div>
        )}

        {/* Action Controls */}
        <div className="pt-2 border-t border-[#E6E0D4] flex items-center justify-between gap-2">
          {tripStatus === 'active' ? (
            <>
              <button
                onClick={() => handleEndTrip('cancelled')}
                className="px-4 py-2.5 rounded-2xl text-xs font-bold text-[#C0392B] bg-[#FADBD8]/60 hover:bg-[#FADBD8] transition cursor-pointer"
              >
                রাইড বাতিল করুন
              </button>

              <button
                onClick={() => handleEndTrip('completed')}
                className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white py-2.5 px-5 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs cursor-pointer transition"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>যাত্রা সম্পন্ন করুন (End Ride)</span>
              </button>
            </>
          ) : (
            <button
              onClick={onClose}
              className="w-full bg-[#2D5A27] text-white py-2.5 rounded-2xl text-xs font-bold shadow-xs cursor-pointer"
            >
              উইন্ডো বন্ধ করুন
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
