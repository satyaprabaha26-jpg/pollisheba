import React, { useState } from 'react';
import { 
  PhoneCall, 
  Lock, 
  ShieldCheck, 
  Smartphone, 
  AlertTriangle, 
  Mic, 
  Sparkles,
  ArrowRight,
  WifiOff,
  MessageSquare,
  AlertCircle
} from 'lucide-react';
import { maskPhoneNumber } from './RuralTransport';
import { OfflineCallWarningModal } from '../common/OfflineCallWarningModal';
import { ChatModal } from '../chat/ChatModal';
import { UserProfile } from '../../types/auth';

interface CallChoiceModalProps {
  recipientName: string;
  recipientRole: string;
  recipientPhoto?: string;
  recipientSubtitle: string;
  rawPhone: string;
  recipientId?: string;
  currentUser?: UserProfile | null;
  allowOfflineCall?: boolean;
  onSelectInAppCall: () => void;
  onOpenChat?: () => void;
  onOpenVoiceNote?: () => void;
  onClose: () => void;
}

export const CallChoiceModal: React.FC<CallChoiceModalProps> = ({
  recipientName,
  recipientRole,
  recipientPhoto,
  recipientSubtitle,
  rawPhone,
  recipientId,
  currentUser,
  allowOfflineCall = true,
  onSelectInAppCall,
  onOpenChat,
  onOpenVoiceNote,
  onClose
}) => {
  const [showWarningModal, setShowWarningModal] = useState<boolean>(false);
  const [showInternalChat, setShowInternalChat] = useState<boolean>(false);
  const [offlineDisallowedAlert, setOfflineDisallowedAlert] = useState<string | null>(null);
  const maskedPhone = maskPhoneNumber(rawPhone);
  const isOffline = !navigator.onLine;

  const handleSimCallTrigger = () => {
    // Show warning popup: if disallowed, alerts that offline call is prohibited; if allowed, confirms number visibility before dialer
    setShowWarningModal(true);
  };

  const handleProceedSimCall = () => {
    setShowWarningModal(false);
    const clean = rawPhone.replace(/[^0-9+]/g, '');
    if (clean) {
      window.location.href = `tel:${clean}`;
    }
    onClose();
  };

  const handleChatTrigger = () => {
    if (onOpenChat) {
      onClose();
      onOpenChat();
    } else {
      setShowInternalChat(true);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-150">
        <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4">
          
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#E8F8F5] text-[#27AE60] flex items-center justify-center">
                <PhoneCall className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-base text-[#2D3A3A]">যোগাযোগ ও কলের মাধ্যম</h3>
                <p className="text-[11px] text-[#736B5E]">প্রাইভেসী ও নম্বর সুরক্ষা অপশন</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-[#736B5E] hover:text-[#2D3A3A] text-lg font-bold cursor-pointer"
            >
              ✕
            </button>
          </div>

          {/* Offline Call Disallowed Error Alert */}
          {offlineDisallowedAlert && (
            <div className="bg-amber-50 text-amber-950 border-2 border-amber-400 rounded-2xl p-3 text-xs font-bold animate-in fade-in flex items-center justify-between gap-2 shadow-xs">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>{offlineDisallowedAlert}</span>
              </div>
              <button onClick={() => setOfflineDisallowedAlert(null)} className="text-amber-700 hover:text-amber-950">✕</button>
            </div>
          )}

          {/* Recipient Snippet */}
          <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] flex items-center gap-3">
            {recipientPhoto ? (
              <img src={recipientPhoto} alt={recipientName} className="w-12 h-12 rounded-xl object-cover border border-[#2D5A27]" />
            ) : (
              <div className="w-12 h-12 rounded-xl bg-[#2D5A27] text-white font-bold text-lg flex items-center justify-center">
                {recipientName.charAt(0)}
              </div>
            )}
            <div className="space-y-0.5 flex-1">
              <div className="flex items-center justify-between gap-1">
                <h4 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-1.5">
                  <span>{recipientName}</span>
                  <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] px-1.5 py-0.2 rounded-full font-bold">
                    {recipientRole === 'driver' ? 'চালক' : recipientRole === 'passenger' ? 'যাত্রী' : recipientRole === 'seller' ? 'বিক্রেতা' : recipientRole === 'laborer' ? 'শ্রমিক' : 'ব্যবহারকারী'}
                  </span>
                </h4>
                <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-md ${allowOfflineCall ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                  {allowOfflineCall ? '🟢 অফলাইন অনুমোদিত' : '🔒 ইন-অ্যাপ সুরক্ষিত'}
                </span>
              </div>
              <p className="text-xs text-[#5A6B6B]">{recipientSubtitle}</p>
              <p className="text-[11px] text-[#736B5E] flex items-center gap-1 font-semibold">
                <Lock className="w-3 h-3 text-[#27AE60]" />
                <span>নম্বর: {allowOfflineCall ? rawPhone : maskedPhone}</span>
              </p>
            </div>
          </div>

          {/* Option 1: In-App Voice Call (100% Privacy Preserved) */}
          <div 
            onClick={() => {
              if (isOffline) {
                setShowWarningModal(true);
                return;
              }
              onSelectInAppCall();
              onClose();
            }}
            className={`group p-3.5 rounded-2xl border-2 transition cursor-pointer space-y-1.5 relative shadow-xs ${
              isOffline 
                ? 'border-gray-300 bg-gray-50 opacity-70'
                : 'border-[#2D5A27] bg-[#FDFBF7] hover:bg-[#D4E4BC]/20'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-xs ${
                  isOffline ? 'bg-gray-400 text-white' : 'bg-[#2D5A27] text-white'
                }`}>
                  {isOffline ? <WifiOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </div>
                <div>
                  <span className="font-bold text-sm text-[#2D5A27] flex items-center gap-1.5">
                    <span>অনলাইন অডিও কল (ফ্রি ইন্টারনেট কল)</span>
                    {!isOffline && (
                      <span className="bg-[#27AE60] text-white text-[9px] font-extrabold px-2 py-0.5 rounded-full">
                        প্রস্তাবিত
                      </span>
                    )}
                  </span>
                  <p className="text-xs text-[#2D3A3A] font-semibold">
                    {isOffline ? 'ইন্টারনেট সংযোগ নেই (অফলাইন)' : '১০০% গোপন ও সুরক্ষিত ইন্টারনেট কলিং'}
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-[#2D5A27] group-hover:translate-x-1 transition" />
            </div>

            <p className="text-[11px] text-[#5A6B6B]">
              <ShieldCheck className="w-3.5 h-3.5 inline text-[#27AE60] mr-1" />
              ফোন নম্বর গোপন থাকবে এবং কোনো ডায়ালারে ডায়াল হবে না।
            </p>

            {/* Direct Prominent Call Button */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                if (isOffline) {
                  setShowWarningModal(true);
                  return;
                }
                onSelectInAppCall();
                onClose();
              }}
              className="w-full mt-1.5 py-2.5 px-3 bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <PhoneCall className="w-4 h-4" />
              <span>📞 সরাসরি কল দিন (অনলাইন অডিও কল)</span>
            </button>
          </div>

          {/* Option 2: In-App Online Text Chat (ALWAYS VISIBLE & PROMINENT) */}
          <div
            onClick={handleChatTrigger}
            className="p-3.5 rounded-2xl border-2 border-[#2D5A27] bg-[#F4F9F2] hover:bg-[#EAF5E7] transition cursor-pointer flex items-center justify-between shadow-xs group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#2D5A27] text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs sm:text-sm font-bold text-[#2D3A3A]">লিখিত মেসেজ (ইন-অ্যাপ টেক্সট চ্যাট)</p>
                <p className="text-[10px] text-[#5A6B6B]">নম্বর গোপন রেখে সরাসরি টেক্সট মেসেজ লিখুন ও চ্যাট করুন</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-[#2D5A27] group-hover:translate-x-1 transition" />
          </div>

          {/* Option 3: In-App Voice Note */}
          {onOpenVoiceNote && (
            <div
              onClick={() => {
                onClose();
                onOpenVoiceNote();
              }}
              className="p-3 rounded-2xl border border-[#2D5A27]/40 bg-[#EAF2E8]/40 hover:bg-[#EAF2E8] transition cursor-pointer flex items-center justify-between"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#2D5A27] text-white flex items-center justify-center shadow-xs">
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-[#2D5A27]">ভয়েস বার্তা পাঠান (Voice Message)</p>
                  <p className="text-[10px] text-[#5A6B6B]">কণ্ঠস্বর রেকর্ড করে তাৎক্ষণিক ইন-অ্যাপ বার্তা পাঠান</p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-[#2D5A27]" />
            </div>
          )}

          {/* Option 4: Direct SIM Network Call (Only if allowOfflineCall is enabled) */}
          {allowOfflineCall ? (
            <div className="p-3.5 rounded-2xl border border-[#E6E0D4] bg-[#FAF8F5] space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[#E8924A] text-white flex items-center justify-center shadow-xs">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-xs text-[#2D3A3A] flex items-center gap-1.5">
                      <span>অফলাইন সাধারণ সিম কল</span>
                      <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded-full">
                        অনুমোদিত
                      </span>
                    </span>
                    <p className="text-[11px] text-[#736B5E]">
                      বিজ্ঞাপনদাতা অফলাইন সাধারণ কল চালু রেখেছেন
                    </p>
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-[#5A6B6B] bg-white p-2.5 rounded-xl border border-[#E6E0D4] space-y-1.5">
                <p className="text-[11px]">
                  সরাসরি সাধারণ মোবাইল ফোন ডায়ালারে কল করতে চাইলে নিচের বাটনে ট্যাপ করুন।
                </p>
                <button
                  type="button"
                  onClick={handleSimCallTrigger}
                  className="w-full mt-1 py-2 px-3 rounded-xl bg-[#E8924A] hover:bg-[#D97D35] text-white text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-white" />
                  <span>সরাসরি ডায়ালারে কল করুন</span>
                </button>
              </div>
            </div>
          ) : (
            <div 
              onClick={() => {
                setOfflineDisallowedAlert('দুঃখিত! অফলাইনে এই ব্যবহারকারীকে কল করার অনুমতি নেই।');
                setTimeout(() => setOfflineDisallowedAlert(null), 5000);
              }}
              className="p-3.5 rounded-2xl border border-gray-200 bg-gray-50/80 space-y-1.5 cursor-pointer hover:bg-gray-100 transition"
              title="অফলাইন কল করার চেষ্টা করুন"
            >
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-gray-200 text-gray-500 flex items-center justify-center">
                  <Lock className="w-3.5 h-3.5" />
                </div>
                <div>
                  <span className="font-bold text-xs text-gray-600 flex items-center gap-1.5">
                    <span>অফলাইন কল: বন্ধ</span>
                    <span className="text-[9px] bg-gray-200 text-gray-600 font-bold px-1.5 py-0.2 rounded-full">
                      প্রাইভেসি সুরক্ষিত
                    </span>
                  </span>
                </div>
              </div>
              <p className="text-[11px] text-gray-600 leading-relaxed bg-white p-2 rounded-xl border border-gray-200">
                🔒 <strong>বিজ্ঞাপনদাতা অফলাইন কল অপশন বন্ধ রেখেছেন।</strong> আপনার এবং বিজ্ঞাপনদাতার ফোন নম্বর সুরক্ষার্থে সরাসরি ফোনে কল করা যাবে না; শুধুমাত্র উপরের <strong>অনলাইন অডিও কল</strong>, <strong>লিখিত মেসেজ</strong> বা <strong>ভয়েস মেসেজ</strong> ব্যবহার করে যোগাযোগ করতে পারেন।
              </p>
            </div>
          )}

          {/* Cancel Button */}
          <div className="flex justify-end pt-1">
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl text-xs font-semibold text-[#5A6B6B] hover:text-[#2D3A3A] bg-[#FAF8F5] border border-[#E6E0D4] cursor-pointer"
            >
              বন্ধ করুন
            </button>
          </div>

        </div>
      </div>

      {/* Offline Call Warning Popup */}
      <OfflineCallWarningModal
        isOpen={showWarningModal}
        phoneNumber={rawPhone}
        recipientName={recipientName}
        recipientRole={recipientRole}
        allowOfflineCall={allowOfflineCall}
        onProceedOfflineCall={handleProceedSimCall}
        onOpenOnlineChat={() => {
          setShowWarningModal(false);
          onClose();
          handleChatTrigger();
        }}
        onOnlineVoiceCall={() => {
          setShowWarningModal(false);
          onClose();
          onSelectInAppCall();
        }}
        onCancel={() => setShowWarningModal(false)}
      />

      {/* Internal Chat Modal Fallback if onOpenChat not passed */}
      {showInternalChat && (
        <ChatModal
          isOpen={true}
          onClose={() => {
            setShowInternalChat(false);
            onClose();
          }}
          currentUser={currentUser || null}
          recipientId={recipientId || rawPhone.replace(/[^0-9]/g, '')}
          recipientName={recipientName}
          recipientRole={recipientRole}
          recipientPhone={rawPhone}
          itemTitle={recipientSubtitle}
          recipientAvatar={recipientPhoto}
        />
      )}
    </>
  );
};

