import React, { useState, useEffect, useRef } from 'react';
import { 
  Car, 
  Search, 
  MapPin, 
  PhoneCall, 
  ShieldCheck, 
  Moon, 
  Share2, 
  PlusCircle, 
  Check, 
  Camera, 
  PhoneForwarded, 
  CheckCircle2, 
  UserCheck,
  Navigation,
  KeyRound,
  FileText,
  AlertTriangle,
  Lock,
  EyeOff,
  Radio,
  Clock,
  Sparkles,
  Mic,
  Smartphone,
  MessageCircle,
  ArrowRight,
  Star,
  Calculator,
  User,
  Repeat,
  Calendar,
  DollarSign,
  Filter,
  Armchair,
  RefreshCw,
  SlidersHorizontal,
  Send
} from 'lucide-react';
import { INITIAL_TRANSPORT_DRIVERS, INITIAL_RETURN_TRANSPORT_RIDES } from '../../data/extendedData';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { TransportDriver, TransportPassenger, ReturnTransportRide } from '../../types';
import { UserProfile, getUserFormDefaults, appendUserSecurityLog } from '../../types/auth';
import { LiveTripTrackerModal } from './LiveTripTrackerModal';
import { TermsAndDisclaimerModal } from '../common/TermsAndDisclaimerModal';
import { InAppVoiceCallModal } from './InAppVoiceCallModal';
import { CallChoiceModal } from './CallChoiceModal';
import { ChatModal } from '../chat/ChatModal';
import { VoiceChatModal } from '../voice/VoiceChatModal';
import { TwoWayReviewModal } from '../common/TwoWayReviewModal';
import { SmartFareEstimatorModal } from './SmartFareEstimatorModal';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';
import { 
  subscribeToDrivers, 
  saveCloudDriver, 
  saveCloudHaatItem, 
  broadcastLocalizedDemandNotification, 
  saveCloudUserProfile, 
  subscribeToAllOnlineUsers, 
  isUserKeyOnline,
  subscribeToReturnRides,
  saveCloudReturnRide,
  deleteCloudReturnRide,
  broadcastReturnTransportNotification
} from '../../lib/cloudSync';
import { DynamicAdSection } from '../common/DynamicAdSection';
import { LiveFaceVerificationModal } from '../common/LiveFaceVerificationModal';
import { ReturnTransportSection } from './ReturnTransportSection';
import { calculateDistanceKm, getDistrictGeo, findNearestDistrict } from '../../data/districtCoordinates';
import { detectCurrentLocationGPS, getSavedLocation, saveUserLocation, UserSavedLocation } from '../../utils/locationService';

interface RuralTransportProps {
  currentDistrict: string;
  currentUser?: UserProfile | null;
  onOpenAuth?: (action?: string) => void;
}

// Bengali digits converter helper
export const toBengaliDigits = (num: string | number): string => {
  const enToBn: Record<string, string> = {
    '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
    '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯', '.': '.'
  };
  return String(num).replace(/[0-9.]/g, (d) => enToBn[d] || d);
};

// Utility to resolve driver coordinates (either live GPS or district/stand coordinates)
export const getDriverCoordinates = (driver: TransportDriver): { lat: number; lng: number } => {
  if (driver.latitude && driver.longitude) {
    return { lat: driver.latitude, lng: driver.longitude };
  }
  const geo = getDistrictGeo(driver.district);
  let offsetLat = 0;
  let offsetLng = 0;
  if (driver.id) {
    let hash = 0;
    for (let i = 0; i < driver.id.length; i++) {
      hash = (hash << 5) - hash + driver.id.charCodeAt(i);
    }
    offsetLat = ((hash % 100) / 1000) * 0.04;
    offsetLng = (((hash >> 3) % 100) / 1000) * 0.04;
  }
  return {
    lat: geo.lat + offsetLat,
    lng: geo.lng + offsetLng
  };
};

// Utility to mask phone numbers for passenger & driver privacy
export const maskPhoneNumber = (phone: string): string => {
  if (!phone) return '০১৭••••••';
  const clean = phone.trim();
  if (clean.length < 7) return clean.slice(0, 3) + '••••';
  const prefix = clean.slice(0, 3);
  const suffix = clean.slice(-2);
  return `${prefix}•••••${suffix}`;
};

export const RuralTransport: React.FC<RuralTransportProps> = ({ currentDistrict, currentUser, onOpenAuth }) => {
  // Drivers State
  const [drivers, setDrivers] = useState<TransportDriver[]>(() => {
    const saved = localStorage.getItem('polli_transport_drivers');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_TRANSPORT_DRIVERS;
      }
    }
    return INITIAL_TRANSPORT_DRIVERS;
  });

  // Passengers State
  const [passengers, setPassengers] = useState<TransportPassenger[]>(() => {
    const saved = localStorage.getItem('polli_transport_passengers');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  // Master Service Switcher: 'regular' (পল্লী পরিবহন) vs 'return' (ফিরতি পরিবহন)
  const [activeTransportService, setActiveTransportService] = useState<'regular' | 'return'>('regular');

  // Filters State
  const [activeMainTab, setActiveMainTab] = useState<'drivers' | 'passengers'>('drivers');
  const [selectedVehicleType, setSelectedVehicleType] = useState<string>('সকল যানবাহন');
  const [selectedFareFilter, setSelectedFareFilter] = useState<'সকল ভাড়া' | 'আলোচনা সাপেক্ষে' | 'নির্দিষ্ট ভাড়া'>('সকল ভাড়া');
  const [selectedShiftFilter, setSelectedShiftFilter] = useState<'সকল সময়' | 'শুধুমাত্র দিনে' | 'শুধুমাত্র রাতে' | 'দিন ও রাত (২৪ ঘণ্টা)'>('সকল সময়');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterAddress, setFilterAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : '',
    upazila: '',
    union: '',
    village: ''
  });

  // Active Chat Target State
  const [activeChatTarget, setActiveChatTarget] = useState<{
    id: string;
    name: string;
    role: string;
    phone: string;
    photo?: string;
    subtitle?: string;
  } | null>(null);
  
  // Modals State
  const [showDriverModal, setShowDriverModal] = useState<boolean>(false);
  const [showPassengerModal, setShowPassengerModal] = useState<boolean>(false);
  const [showSafetyModal, setShowSafetyModal] = useState<boolean>(false);
  const [showLiveTrackerModal, setShowLiveTrackerModal] = useState<boolean>(false);
  const [showTermsModal, setShowTermsModal] = useState<boolean>(false);
  const [selectedDriverForSafety, setSelectedDriverForSafety] = useState<TransportDriver | null>(null);
  const [selectedDriverForTracking, setSelectedDriverForTracking] = useState<TransportDriver | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Real-time online users presence tracking
  const [onlineUsersMap, setOnlineUsersMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const unsub = subscribeToAllOnlineUsers((map) => {
      setOnlineUsersMap(map);
    });
    return () => {
      if (unsub) unsub();
    };
  }, []);

  // Proximity & Near-Me Driver Sorting State
  const [passengerLocation, setPassengerLocation] = useState<{
    lat: number;
    lng: number;
    isGps: boolean;
    districtName?: string;
  } | null>(() => {
    const saved = getSavedLocation();
    if (saved?.latitude && saved?.longitude) {
      return {
        lat: saved.latitude,
        lng: saved.longitude,
        isGps: !!saved.isGpsDetected,
        districtName: saved.district
      };
    }
    if (currentUser?.district && currentUser.district !== 'সকল জেলা') {
      const geo = getDistrictGeo(currentUser.district);
      return {
        lat: geo.lat,
        lng: geo.lng,
        isGps: false,
        districtName: currentUser.district
      };
    }
    if (currentDistrict && currentDistrict !== 'সকল জেলা') {
      const geo = getDistrictGeo(currentDistrict);
      return {
        lat: geo.lat,
        lng: geo.lng,
        isGps: false,
        districtName: currentDistrict
      };
    }
    return null;
  });

  const [sortByNearest, setSortByNearest] = useState<boolean>(true);
  const [isDetectingGps, setIsDetectingGps] = useState<boolean>(false);
  const [driverUpdatingLocation, setDriverUpdatingLocation] = useState<boolean>(false);

  // Auto-detect / refresh Passenger Live GPS Location
  const handleDetectPassengerLocation = async () => {
    setIsDetectingGps(true);
    try {
      const res = await detectCurrentLocationGPS();
      if (res.success && res.latitude && res.longitude) {
        setPassengerLocation({
          lat: res.latitude,
          lng: res.longitude,
          isGps: true,
          districtName: res.district
        });
        setToastMessage(`✓ আপনার লাইভ অবস্থান নির্ণয় হয়েছে (${res.district || ''})! নিকটতম চালকরা সবার উপরে সাজানো হলো।`);
        setTimeout(() => setToastMessage(null), 5000);
      } else {
        setToastMessage(res.errorMessage || 'জিপিএস লোকেশন পাওয়া যায়নি।');
        setTimeout(() => setToastMessage(null), 5000);
      }
    } catch (e) {
      setToastMessage('লোকেশন শনাক্তকরণে সমস্যা হয়েছে। অনুগ্রহ করে ব্রাউজার পারমিশন চেক করুন।');
      setTimeout(() => setToastMessage(null), 5000);
    } finally {
      setIsDetectingGps(false);
    }
  };

  // Driver Live GPS Broadcast Handler
  const handleUpdateDriverLiveLocation = async () => {
    if (!navigator.geolocation) {
      alert('আপনার ডিভাইসে জিপিএস সমর্থন করে না।');
      return;
    }
    setDriverUpdatingLocation(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        const now = Date.now();
        
        // 1. Update user profile if logged in
        if (currentUser) {
          const updatedUser: UserProfile = {
            ...currentUser,
            latitude,
            longitude,
            lastLocationUpdate: now
          };
          localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
          saveCloudUserProfile(updatedUser).catch(() => {});
        }

        // 2. Update matching driver in transport_drivers
        const cleanMyPhone = currentUser?.phone?.replace(/[^0-9]/g, '');
        const matchingDriver = drivers.find(d => 
          (currentUser && d.id === `drv-${currentUser.id}`) ||
          (cleanMyPhone && d.phone?.replace(/[^0-9]/g, '') === cleanMyPhone) ||
          (currentUser && d.driverName === currentUser.name)
        );

        if (matchingDriver) {
          const updatedDriver: TransportDriver = {
            ...matchingDriver,
            latitude,
            longitude,
            lastLocationUpdate: now
          };
          const newDriversList = drivers.map(d => d.id === matchingDriver.id ? updatedDriver : d);
          setDrivers(newDriversList);
          await saveCloudDriver(updatedDriver);
        }

        setDriverUpdatingLocation(false);
        setToastMessage('✓ আপনার গাড়ির লাইভ লোকেশন সফলভাবে আপডেট হয়েছে! যাত্রীরা আপনাকে নিকটতম চালক হিসেবে সবার উপরে দেখতে পাবেন।');
        setTimeout(() => setToastMessage(null), 6000);
      },
      (err) => {
        setDriverUpdatingLocation(false);
        alert('জিপিএস লোকেশন পাওয়া যায়নি। আপনার ফোনের লোকেশন/GPS অন আছে কিনা যাচাই করুন।');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Distance metadata helper for driver card
  const getDriverDistanceMeta = (driver: TransportDriver) => {
    if (!passengerLocation) {
      return {
        distanceKm: null,
        distanceText: '',
        isVeryClose: false,
        isGpsAccurate: false
      };
    }

    const coords = getDriverCoordinates(driver);
    const dist = calculateDistanceKm(passengerLocation.lat, passengerLocation.lng, coords.lat, coords.lng);
    const rounded = Math.round(dist * 10) / 10;
    const isVeryClose = rounded < 1.0;
    const isGpsAccurate = (!!driver.latitude && !!driver.longitude) || passengerLocation.isGps;

    let distanceText = '';
    if (rounded < 1.0) {
      const meters = Math.max(100, Math.round(rounded * 1000));
      distanceText = `⚡ অতি নিকটে • মাত্র ${toBengaliDigits(meters)} মিটার`;
    } else if (rounded <= 20) {
      distanceText = `📍 ${toBengaliDigits(rounded.toFixed(1))} কিমি দূরে`;
    } else {
      distanceText = `📍 ${toBengaliDigits(Math.round(rounded))} কিমি (${driver.district})`;
    }

    return {
      distanceKm: rounded,
      distanceText,
      isVeryClose,
      isGpsAccurate
    };
  };

  const handleOpenDriverProfile = (driver: TransportDriver) => {
    const userPayload: Partial<UserProfile> = {
      id: driver.id || driver.phone,
      name: driver.driverName,
      phone: driver.phone,
      role: 'driver',
      district: driver.district,
      upazila: driver.upazila,
      union: (driver as any).union || '',
      village: (driver as any).village || '',
      customAvatarUrl: driver.facePhotoUrl,
      allowOfflineCall: (driver as any).allowOfflineCall ?? true,
      isLiveVerified: true,
      verificationBadgeText: '🛡️ ভেরিফাইড চালক'
    };
    window.dispatchEvent(new CustomEvent('polli_open_public_profile', { detail: { user: userPayload } }));
  };

  // In-App Voice Call States (100% Privacy Preserved)
  const [showInAppVoiceCall, setShowInAppVoiceCall] = useState<boolean>(false);
  const [showCallChoiceModal, setShowCallChoiceModal] = useState<boolean>(false);
  const [activeCallTarget, setActiveCallTarget] = useState<{
    name: string;
    role: 'driver' | 'passenger';
    photo?: string;
    subtitle: string;
    rawPhone: string;
  } | null>(null);

  const handleInitiateCall = (target: {
    name: string;
    role: 'driver' | 'passenger';
    photo?: string;
    subtitle: string;
    rawPhone: string;
  }) => {
    logTravelInteraction(target);
    setActiveCallTarget(target);
    setShowCallChoiceModal(true);
  };

  const logTravelInteraction = (target: {
    name: string;
    role: 'driver' | 'passenger';
    photo?: string;
    subtitle: string;
    rawPhone: string;
  }) => {
    if (!currentUser) return;
    try {
      const isTargetDriver = target.role === 'driver';
      const updatedUser = appendUserSecurityLog(
        currentUser,
        'travel_trip',
        'গ্রামীণ যাতায়াত ও ভ্রমণ রেকর্ড',
        isTargetDriver
          ? `চালক ${target.name} (${target.subtitle}) এর সাথে যাতায়াত ট্রিপ যোগাযোগ`
          : `যাত্রী ${target.name} (${target.subtitle}) এর সাথে যাতায়াত সংযোগ`,
        {
          driverName: isTargetDriver ? target.name : currentUser.name,
          driverPhoneMasked: maskPhoneNumber(target.rawPhone),
          passengerName: isTargetDriver ? currentUser.name : target.name,
          vehicleNumber: isTargetDriver ? target.subtitle : undefined,
          serviceType: 'পল্লী যাতায়াত রাইড ট্রিপ',
          notes: `অ্যাপসের মাধ্যমে চালক-যাত্রী সংযোগ ও ভ্রমণ হিস্ট্রি রেকর্ড। তদন্ত ও নিরাপত্তার স্বার্থে ৩৬৫ দিন সংরক্ষিত থাকবে।`
        }
      );
      localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
      saveCloudUserProfile(updatedUser).catch(() => {});
    } catch (err) {
      console.error('Failed to log travel interaction', err);
    }
  };

  const handleDirectInAppCall = (target: {
    name: string;
    role: 'driver' | 'passenger';
    photo?: string;
    subtitle: string;
    rawPhone: string;
  }) => {
    logTravelInteraction(target);
    setActiveCallTarget(target);
    setShowInAppVoiceCall(true);
  };

  // Form State for Driver (Only OTP Verified Phone & Face Photo - NO NID/License!)
  const [driverName, setDriverName] = useState('');
  const [vehicleType, setVehicleType] = useState<TransportDriver['vehicleType']>('অটোরিকশা / ইজিবাইক');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [driverAddress, setDriverAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা',
    upazila: 'সাভার',
    union: 'সাভার সদর',
    village: ''
  });
  const [standLocation, setStandLocation] = useState('');
  const [regularRoutes, setRegularRoutes] = useState('');
  const [serviceShift, setServiceShift] = useState<'শুধুমাত্র দিনে' | 'শুধুমাত্র রাতে' | 'দিন ও রাত (২৪ ঘণ্টা)'>('দিন ও রাত (২৪ ঘণ্টা)');
  const [driverFacePhoto, setDriverFacePhoto] = useState<string | null>(null);
  const [driverOtpSent, setDriverOtpSent] = useState<boolean>(false);
  const [driverOtpInput, setDriverOtpInput] = useState<string>('');
  const [driverOtpVerified, setDriverOtpVerified] = useState<boolean>(false);
  const [driverTermsAccepted, setDriverTermsAccepted] = useState<boolean>(false);

  // Form State for Passenger (Only OTP Verified Phone & Face Photo - NO NID/License!)
  const [passName, setPassName] = useState('');
  const [passPhone, setPassPhone] = useState('');
  const [passEmergencyPhone, setPassEmergencyPhone] = useState('');
  const [passEmergencyRel, setPassEmergencyRel] = useState('পিতা/অভিভাবক');
  const [passAddress, setPassAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা',
    upazila: 'সাভার',
    union: 'সাভার সদর',
    village: ''
  });
  const [passArea, setPassArea] = useState('');
  const [passFrequentRoute, setPassFrequentRoute] = useState('');
  const [passFacePhoto, setPassFacePhoto] = useState<string | null>(null);
  const [passOtpSent, setPassOtpSent] = useState<boolean>(false);
  const [passOtpInput, setPassOtpInput] = useState<string>('');
  const [passOtpVerified, setPassOtpVerified] = useState<boolean>(false);
  const [passTermsAccepted, setPassTermsAccepted] = useState<boolean>(false);

  // Need Vehicle / Passenger Direct Request State (No registration required)
  const [showNeedVehicleModal, setShowNeedVehicleModal] = useState<boolean>(false);
  const [needVehicleType, setNeedVehicleType] = useState('পিকআপ / নসিমন');
  const [needName, setNeedName] = useState(currentUser?.name || '');
  const [needPhone, setNeedPhone] = useState(currentUser?.phone || '');
  const [needAddress, setNeedAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা',
    upazila: 'সাভার',
    union: 'সাভার সদর',
    village: ''
  });
  const [needDestination, setNeedDestination] = useState('');
  const [needTripTime, setNeedTripTime] = useState('আজই জরুরি ভিত্তিতে');
  const [needDescription, setNeedDescription] = useState('');

  // Offline Direct Call Permission States (Auto-filled from profile)
  const [driverAllowOfflineCall, setDriverAllowOfflineCall] = useState<boolean>(false);
  const [passAllowOfflineCall, setPassAllowOfflineCall] = useState<boolean>(false);
  const [needAllowOfflineCall, setNeedAllowOfflineCall] = useState<boolean>(false);

  // Biometric Live Face Verification Modal State
  const [showLiveFaceModal, setShowLiveFaceModal] = useState<boolean>(false);
  const [liveFaceTarget, setLiveFaceTarget] = useState<'driver' | 'passenger'>('driver');

  // Voice Chat, Reviews & Smart Fare States
  const [activeVoiceTarget, setActiveVoiceTarget] = useState<{
    name: string;
    role: string;
    phone?: string;
    avatar?: string;
    itemTitle?: string;
  } | null>(null);

  const [activeReviewTarget, setActiveReviewTarget] = useState<{
    id: string;
    name: string;
    role: string;
    serviceType: string;
  } | null>(null);

  const [showFareEstimatorModal, setShowFareEstimatorModal] = useState<boolean>(false);
  const [fareEstimatorDriver, setFareEstimatorDriver] = useState<TransportDriver | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToDrivers((updatedDrivers) => {
      setDrivers(updatedDrivers);
    });
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  useEffect(() => {
    const defaults = getUserFormDefaults(currentUser);
    if (defaults.name) {
      if (!driverName) setDriverName(defaults.name);
      if (!passName) setPassName(defaults.name);
      if (!needName) setNeedName(defaults.name);
    }
    if (defaults.phone) {
      if (!driverPhone) setDriverPhone(defaults.phone);
      if (!passPhone) setPassPhone(defaults.phone);
      if (!needPhone) setNeedPhone(defaults.phone);
    }
    if (defaults.district && defaults.district !== 'সকল জেলা') {
      const addr: AddressState = {
        district: defaults.district,
        upazila: defaults.upazila || '',
        union: defaults.union || '',
        village: defaults.village || ''
      };
      setDriverAddress(prev => ({ ...prev, ...addr }));
      setPassAddress(prev => ({ ...prev, ...addr }));
      setNeedAddress(prev => ({ ...prev, ...addr }));
    } else if (currentDistrict !== 'সকল জেলা') {
      setFilterAddress(prev => ({
        ...prev,
        district: currentDistrict,
        upazila: '',
        union: '',
        village: ''
      }));
      setDriverAddress(prev => ({ ...prev, district: currentDistrict }));
      setPassAddress(prev => ({ ...prev, district: currentDistrict }));
      setNeedAddress(prev => ({ ...prev, district: currentDistrict }));
    }
    setDriverAllowOfflineCall(defaults.allowOfflineCall);
    setPassAllowOfflineCall(defaults.allowOfflineCall);
    setNeedAllowOfflineCall(defaults.allowOfflineCall);
  }, [currentUser, currentDistrict]);

  useEffect(() => {
    localStorage.setItem('polli_transport_drivers', JSON.stringify(drivers));
  }, [drivers]);

  useEffect(() => {
    localStorage.setItem('polli_transport_passengers', JSON.stringify(passengers));
  }, [passengers]);

  const vehicleCategories = [
    'সকল যানবাহন',
    'অটোরিকশা / ইজিবাইক',
    'সিএনজি',
    'বাইক রাইডার',
    'পিকআপ / নসিমন',
    'মাইক্রোবাস / কার',
    'ট্র্যাক্টর / পাওয়ার টিলার',
    'হেস্কোভেটর (মাটি কাটা)',
    'নৌকা / ইঞ্জিন ট্রলার'
  ];

  const filteredDrivers = drivers.filter((driver) => {
    // Exclude drivers who are inactive or pending admin verification
    if (driver.status && (driver.status === 'নিষ্ক্রিয়' || driver.status === 'পেন্ডিং' || driver.status === 'pending' || driver.status === 'inactive')) {
      return false;
    }

    const matchesType = selectedVehicleType === 'সকল যানবাহন' || driver.vehicleType === selectedVehicleType;
    
    // District match
    if (filterAddress.district && filterAddress.district !== 'সকল জেলা' && driver.district !== filterAddress.district) {
      return false;
    }

    // Upazila match
    if (filterAddress.upazila && filterAddress.upazila !== 'সকল উপজেলা') {
      const uq = filterAddress.upazila.toLowerCase();
      const drvU = (driver.upazila || '').toLowerCase();
      const drvStand = (driver.standLocation || '').toLowerCase();
      const drvRoutes = (driver.regularRoutes || '').toLowerCase();
      if (!drvU.includes(uq) && !drvStand.includes(uq) && !drvRoutes.includes(uq)) {
        return false;
      }
    }

    // Union match
    if (filterAddress.union && filterAddress.union !== 'সকল ইউনিয়ন') {
      const unq = filterAddress.union.toLowerCase();
      const drvUn = (driver.unionOrWard || '').toLowerCase();
      const drvStand = (driver.standLocation || '').toLowerCase();
      const drvRoutes = (driver.regularRoutes || '').toLowerCase();
      if (!drvUn.includes(unq) && !drvStand.includes(unq) && !drvRoutes.includes(unq)) {
        return false;
      }
    }

    // Village / Stand query match
    if (filterAddress.village.trim()) {
      const vq = filterAddress.village.toLowerCase();
      const drvV = (driver.village || '').toLowerCase();
      const drvStand = (driver.standLocation || '').toLowerCase();
      const drvRoutes = (driver.regularRoutes || '').toLowerCase();
      if (!drvV.includes(vq) && !drvStand.includes(vq) && !drvRoutes.includes(vq)) {
        return false;
      }
    }
    
    // Shift filter logic
    let matchesShift = true;
    if (selectedShiftFilter === 'শুধুমাত্র দিনে') {
      matchesShift = driver.serviceShift === 'শুধুমাত্র দিনে' || (!driver.serviceShift && !driver.isNightActive);
    } else if (selectedShiftFilter === 'শুধুমাত্র রাতে') {
      matchesShift = driver.serviceShift === 'শুধুমাত্র রাতে' || (driver.isNightActive && driver.serviceShift !== 'দিন ও রাত (২৪ ঘণ্টা)');
    } else if (selectedShiftFilter === 'দিন ও রাত (২৪ ঘণ্টা)') {
      matchesShift = driver.serviceShift === 'দিন ও রাত (২৪ ঘণ্টা)' || driver.isNightActive;
    }

    // Fare filter logic
    let matchesFare = true;
    if (selectedFareFilter === 'আলোচনা সাপেক্ষে') {
      matchesFare = !driver.pricingType || driver.pricingType.includes('আলোচনা');
    } else if (selectedFareFilter === 'নির্দিষ্ট ভাড়া') {
      matchesFare = !!(driver.pricingType && !driver.pricingType.includes('আলোচনা'));
    }

    const matchesSearch = 
      !searchQuery.trim() ||
      driver.driverName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      driver.standLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      driver.regularRoutes.toLowerCase().includes(searchQuery.toLowerCase()) ||
      driver.vehicleNumber.toLowerCase().includes(searchQuery.toLowerCase());
      
    return matchesType && matchesShift && matchesFare && matchesSearch;
  }).sort((a, b) => {
    if (!sortByNearest) return 0;

    // 1. If passenger location is available, sort strictly by distance in km (closest first)
    if (passengerLocation) {
      const distA = getDriverDistanceMeta(a).distanceKm ?? 99999;
      const distB = getDriverDistanceMeta(b).distanceKm ?? 99999;
      if (Math.abs(distA - distB) > 0.05) {
        return distA - distB;
      }
    }

    // 2. Hierarchy fallback: Same Union -> Same Upazila -> Online Status
    const userUnion = (filterAddress.union || currentUser?.union || '').toLowerCase();
    if (userUnion && userUnion !== 'সকল ইউনিয়ন') {
      const aUnionMatch = (a.unionOrWard || '').toLowerCase().includes(userUnion) || (a.standLocation || '').toLowerCase().includes(userUnion);
      const bUnionMatch = (b.unionOrWard || '').toLowerCase().includes(userUnion) || (b.standLocation || '').toLowerCase().includes(userUnion);
      if (aUnionMatch && !bUnionMatch) return -1;
      if (!aUnionMatch && bUnionMatch) return 1;
    }

    const userUpazila = (filterAddress.upazila || currentUser?.upazila || '').toLowerCase();
    if (userUpazila && userUpazila !== 'সকল উপজেলা') {
      const aUpazilaMatch = (a.upazila || '').toLowerCase().includes(userUpazila) || (a.standLocation || '').toLowerCase().includes(userUpazila);
      const bUpazilaMatch = (b.upazila || '').toLowerCase().includes(userUpazila) || (b.standLocation || '').toLowerCase().includes(userUpazila);
      if (aUpazilaMatch && !bUpazilaMatch) return -1;
      if (!aUpazilaMatch && bUpazilaMatch) return 1;
    }

    const aOnline = isUserKeyOnline(a.phone, onlineUsersMap);
    const bOnline = isUserKeyOnline(b.phone, onlineUsersMap);
    if (aOnline && !bOnline) return -1;
    if (!aOnline && bOnline) return 1;

    return 0;
  });

  const filteredPassengers = passengers.filter((pass) => {
    // District match
    if (filterAddress.district && filterAddress.district !== 'সকল জেলা' && pass.district !== filterAddress.district) {
      return false;
    }

    // Upazila match
    if (filterAddress.upazila && filterAddress.upazila !== 'সকল উপজেলা') {
      const uq = filterAddress.upazila.toLowerCase();
      const passU = (pass.upazila || '').toLowerCase();
      const passArea = (pass.upazilaOrArea || '').toLowerCase();
      const passRoute = (pass.frequentRoute || '').toLowerCase();
      if (!passU.includes(uq) && !passArea.includes(uq) && !passRoute.includes(uq)) {
        return false;
      }
    }

    // Union match
    if (filterAddress.union && filterAddress.union !== 'সকল ইউনিয়ন') {
      const unq = filterAddress.union.toLowerCase();
      const passUn = (pass.unionOrWard || '').toLowerCase();
      const passArea = (pass.upazilaOrArea || '').toLowerCase();
      const passRoute = (pass.frequentRoute || '').toLowerCase();
      if (!passUn.includes(unq) && !passArea.includes(unq) && !passRoute.includes(unq)) {
        return false;
      }
    }

    // Village match
    if (filterAddress.village.trim()) {
      const vq = filterAddress.village.toLowerCase();
      const passV = (pass.village || '').toLowerCase();
      const passArea = (pass.upazilaOrArea || '').toLowerCase();
      const passRoute = (pass.frequentRoute || '').toLowerCase();
      if (!passV.includes(vq) && !passArea.includes(vq) && !passRoute.includes(vq)) {
        return false;
      }
    }

    const matchesSearch = 
      !searchQuery.trim() ||
      pass.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pass.upazilaOrArea.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pass.frequentRoute.toLowerCase().includes(searchQuery.toLowerCase());
      
    return matchesSearch;
  });

  // Open Biometric Live Face Verification Modal
  const handleOpenLiveFaceModal = (target: 'driver' | 'passenger') => {
    setLiveFaceTarget(target);
    setShowLiveFaceModal(true);
  };

  // OTP Handlers
  const handleSendDriverOtp = () => {
    if (!driverPhone || driverPhone.length < 11) {
      alert('সঠিক ১১ ডিজিটের মোবাইল নম্বর লিখুন');
      return;
    }
    setDriverOtpSent(true);
    setDriverOtpInput('4892'); // Pre-fill simulation OTP
  };

  const handleVerifyDriverOtp = () => {
    if (driverOtpInput.trim().length >= 4) {
      setDriverOtpVerified(true);
    }
  };

  const handleSendPassOtp = () => {
    if (!passPhone || passPhone.length < 11) {
      alert('সঠিক ১১ ডিজিটের মোবাইল নম্বর লিখুন');
      return;
    }
    setPassOtpSent(true);
    setPassOtpInput('7254'); // Pre-fill simulation OTP
  };

  const handleVerifyPassOtp = () => {
    if (passOtpInput.trim().length >= 4) {
      setPassOtpVerified(true);
    }
  };

  // Driver Submit (Strictly NO NID collected, no mandatory photo)
  const handleRegisterDriver = (e: React.FormEvent) => {
    e.preventDefault();
    if (!driverName || !driverPhone || !vehicleNumber) {
      alert('অনুগ্রহ করে চালকের নাম, মোবাইল নম্বর এবং গাড়ির নম্বর পূরণ করুন');
      return;
    }

    const compiledStand = [
      driverAddress.village ? `স্ট্যান্ড/গ্রাম: ${driverAddress.village}` : '',
      driverAddress.union ? `${driverAddress.union}` : '',
      driverAddress.upazila ? `উপজেলা: ${driverAddress.upazila}` : '',
      standLocation ? `${standLocation}` : ''
    ].filter(Boolean).join(', ') || standLocation || `${driverAddress.district}`;

    const newDriver: TransportDriver = {
      id: `driver-${Date.now()}`,
      driverName,
      vehicleType,
      vehicleNumber,
      phone: driverPhone,
      district: driverAddress.district,
      upazila: driverAddress.upazila || undefined,
      unionOrWard: driverAddress.union || undefined,
      village: driverAddress.village || undefined,
      standLocation: compiledStand,
      regularRoutes,
      serviceShift,
      isNightActive: serviceShift === 'শুধুমাত্র রাতে' || serviceShift === 'দিন ও রাত (২৪ ঘণ্টা)',
      isVerified: true,
      facePhotoUrl: driverFacePhoto || undefined,
      isPhoneVerified: driverOtpVerified || true
    };

    setDrivers([newDriver, ...drivers]);
    saveCloudDriver(newDriver);

    // Broadcast localized notification to the area
    broadcastLocalizedDemandNotification({
      id: newDriver.id,
      title: `${newDriver.vehicleType} চালক সেবা প্রস্তুত (${newDriver.standLocation})`,
      category: 'নতুন পরিবহন চালক সেবা',
      scope: 'upazila',
      district: driverAddress.district,
      upazila: driverAddress.upazila,
      union: driverAddress.unionOrWard,
      sellerName: driverName.trim(),
      phone: driverPhone.trim(),
      targetRole: 'all',
      targetCategory: 'transport'
    });

    setShowDriverModal(false);
    setToastMessage('চালক হিসেবে আপনার তথ্য সফলভাবে যুক্ত হয়েছে! স্থানীয় যাত্রীরা এখন আপনার সাথে সরাসরি যোগাযোগ করতে পারবেন।');
    setTimeout(() => setToastMessage(null), 4000);

    // Reset Form
    setDriverName('');
    setVehicleNumber('');
    setDriverPhone('');
    setDriverAddress({
      district: currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা',
      upazila: 'সাভার',
      union: 'সাভার সদর',
      village: ''
    });
    setStandLocation('');
    setRegularRoutes('');
    setDriverFacePhoto(null);
    setDriverOtpSent(false);
    setDriverOtpVerified(false);
    setDriverTermsAccepted(false);
  };

  // Passenger / Citizen Request for Vehicle (Strictly NO registration required)
  const handleCreateVehicleRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentUser?.role === 'driver') {
      alert('চালকেরা শুধু তাদের তথ্য ও গাড়ি লিস্টিং করে রাখবেন। চালকেরা কোনো যাত্রী রিকোয়েস্ট পোস্ট করতে পারবেন না। খালি গাড়ি নিয়ে ফেরার পথের জন্য দয়া করে "ফিরতি পরিবহন" সেবা ব্যবহার করুন।');
      return;
    }

    if (!needName || !needPhone || !needDestination) {
      alert('অনুগ্রহ করে আপনার নাম, মোবাইল নম্বর এবং গন্তব্য পূরণ করুন');
      return;
    }

    const now = Date.now();
    const compiledLocation = [
      needAddress.village ? `গ্রাম/স্ট্যান্ড: ${needAddress.village}` : '',
      needAddress.union ? `${needAddress.union}` : '',
      needAddress.upazila ? `উপজেলা: ${needAddress.upazila}` : '',
      needAddress.district ? `${needAddress.district} জেলা` : ''
    ].filter(Boolean).join(', ') || `${needAddress.district}`;

    const newRequestItem = {
      id: `transport-need-${now}`,
      title: `${needVehicleType} প্রয়োজন (${needAddress.upazila || needAddress.district} থেকে ${needDestination})`,
      category: 'পরিবহন ও চালক সেবা',
      itemType: 'অন্যান্য' as const,
      price: 0,
      unit: 'ভাড়া আলোচনা সাপেক্ষে',
      sellerName: needName.trim(),
      sellerRole: 'citizen' as const,
      phone: needPhone.trim(),
      location: compiledLocation,
      district: needAddress.district,
      upazila: needAddress.upazila || undefined,
      unionOrWard: needAddress.union || undefined,
      village: needAddress.village || undefined,
      description: `গন্তব্য: ${needDestination}। সময়: ${needTripTime}। বিবরণ: ${needDescription || 'জরুরি গাড়ি প্রয়োজন'}`.trim(),
      createdAt: 'এইমাত্র পোস্ট করা হয়েছে',
      createdAtTimestamp: now,
      isNegotiable: true,
      expiryDays: 7,
      isSold: false
    };

    saveCloudHaatItem(newRequestItem as any).catch(err => console.warn('Sync notice:', err));

    // Auto localized notification broadcast ONLY to registered drivers of this vehicle type in this area
    broadcastLocalizedDemandNotification({
      id: newRequestItem.id,
      title: newRequestItem.title,
      category: 'জরুরি গাড়ি ও চালক আবশ্যক',
      scope: 'upazila',
      district: needAddress.district,
      upazila: needAddress.upazila,
      union: needAddress.unionOrWard,
      sellerName: needName.trim(),
      phone: needPhone.trim(),
      targetRole: 'driver',
      targetCategory: 'transport',
      targetSubTab: needVehicleType
    });

    setShowNeedVehicleModal(false);
    setToastMessage(`জরুরি ${needVehicleType} বিজ্ঞপ্তি সফলভাবে প্রকাশিত হয়েছে! ${needAddress.upazila ? `${needAddress.upazila} উপজেলার` : `${needAddress.district} জেলার`} শুধুমাত্র সংশ্লিষ্ট বাহনের চালকদের কাছে নোটিফিকেশন পৌঁছে দেওয়া হয়েছে।`);
    setTimeout(() => setToastMessage(null), 5000);

    // Reset
    setNeedDestination('');
    setNeedDescription('');
  };

  // Passenger Submit (Strictly NO NID collected)
  const handleRegisterPassenger = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passName || !passPhone) return;
    if (!passFacePhoto) {
      alert('নিরাপত্তার স্বার্থে যাত্রীর লাইভ ফেস ফটো / সেলফি তোলা বাধ্যতামূলক!');
      return;
    }
    if (!passTermsAccepted) {
      alert('নিবন্ধন সম্পন্ন করতে অনুগ্রহ করে শর্তাবলী ও দায়মুক্তি বক্সে সম্মতি দিন।');
      return;
    }

    const compiledArea = [
      passAddress.village ? `গ্রাম: ${passAddress.village}` : '',
      passAddress.union ? `${passAddress.union}` : '',
      passAddress.upazila ? `উপজেলা: ${passAddress.upazila}` : '',
      passArea ? `${passArea}` : ''
    ].filter(Boolean).join(', ') || passArea || `${passAddress.district}`;

    const newPassenger: TransportPassenger = {
      id: `pass-${Date.now()}`,
      name: passName,
      phone: passPhone,
      emergencyContact: passEmergencyPhone || '০১৭xxxxxxxx',
      emergencyRelation: passEmergencyRel || 'অভিভাবক',
      district: passAddress.district,
      upazila: passAddress.upazila || undefined,
      unionOrWard: passAddress.union || undefined,
      village: passAddress.village || undefined,
      upazilaOrArea: compiledArea,
      frequentRoute: passFrequentRoute || 'নিয়মিত রুট',
      facePhotoUrl: passFacePhoto || undefined,
      isFaceVerified: !!passFacePhoto,
      isPhoneVerified: true,
      registeredAt: 'আজকে'
    };

    setPassengers([newPassenger, ...passengers]);
    setShowPassengerModal(false);
    setToastMessage('নিরাপদ যাত্রী প্রোফাইল তৈরি হয়েছে! (মোবাইল নম্বর সম্পূর্ণ সুরক্ষিত ও মাস্কড)');
    setTimeout(() => setToastMessage(null), 4000);

    // Reset Form
    setPassName('');
    setPassPhone('');
    setPassEmergencyPhone('');
    setPassAddress({
      district: currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা',
      upazila: 'সাভার',
      union: 'সাভার সদর',
      village: ''
    });
    setPassArea('');
    setPassFrequentRoute('');
    setPassFacePhoto(null);
    setPassOtpSent(false);
    setPassOtpVerified(false);
    setPassTermsAccepted(false);
  };

  const handleOpenSafetyShare = (driver: TransportDriver) => {
    setSelectedDriverForSafety(driver);
    setShowSafetyModal(true);
  };

  const handleStartLiveTracking = (driver: TransportDriver) => {
    setSelectedDriverForTracking(driver);
    setShowLiveTrackerModal(true);
  };

  const handleShareToWhatsApp = () => {
    if (!selectedDriverForSafety) return;
    const msg = `🛡️ নিরাপত্তা সতর্কবার্তা (পল্লী পরিবহন):\nআমি বর্তমানে ${selectedDriverForSafety.vehicleType} যোগে ভ্রমণ করছি।\n• চালক: ${selectedDriverForSafety.driverName}\n• গাড়ির নম্বর: ${selectedDriverForSafety.vehicleNumber}\n• স্ট্যান্ড: ${selectedDriverForSafety.standLocation}, ${selectedDriverForSafety.district}\n• রুট: ${selectedDriverForSafety.regularRoutes}\n(জরুরিতে ৯৯৯ ডায়াল করুন)`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <div className="space-y-6 font-['Noto_Sans_Bengali']">
      
      {/* Top Safety & Privacy Architecture Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full inline-block">
                🛡️ নিরাপদ পল্লী পরিবহন নেটওয়ার্ক
              </span>
              <span className="bg-[#27AE60] text-white font-bold text-[11px] px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <Mic className="w-3 h-3" />
                ইন-অ্যাপ ভয়েস কলিং (১০০% নম্বর গোপন)
              </span>
              <span className="bg-white/20 text-[#D4E4BC] font-semibold text-[11px] px-2.5 py-0.5 rounded-full">
                কেবল OTP ও ফেস ফটো যাচাই
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
              সার্বজনীন নিরাপদ পরিবহন ও যাত্রী সুরক্ষা প্ল্যাটফর্ম
            </h2>
            <p className="text-[#D4E4BC] text-xs sm:text-sm max-w-2xl leading-relaxed">
              অ্যাপের ভেতর থেকে সরাসরি <strong>সুরক্ষিত ইন্টারনেট ভয়েস কল</strong> করুন—কোনো ফোনের ডায়ালার ওপেন হবে না এবং চালক বা যাত্রীর আসল মোবাইল নম্বর কখনোই প্রকাশ পাবে না।
            </p>

            <div className="flex items-center gap-3 pt-1">
              <button
                onClick={() => setShowTermsModal(true)}
                className="text-xs text-[#F9E5D4] hover:text-white underline font-semibold flex items-center gap-1 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>শর্তাবলী ও আইনগত দায়মুক্তি (Disclaimer) পড়ুন</span>
              </button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2.5 self-start lg:self-auto">
            {/* Direct Need Vehicle Button (Requires Login/Registration) */}
            <button
              onClick={() => {
                if (!currentUser) {
                  onOpenAuth?.('গাড়ি বা চালক প্রয়োজন হলে বিজ্ঞাপন দিতে লগইন বা নিবন্ধন করুন');
                  return;
                }
                if (currentUser.role === 'driver') {
                  alert('চালকেরা শুধু তাদের তথ্য ও গাড়ি লিস্টিং করে রাখবেন। চালকেরা যাত্রী রিকোয়েস্ট পোস্ট করতে পারবেন না। খালি গাড়ি নিয়ে ফিরতি ট্রিপের জন্য দয়া করে "ফিরতি পরিবহন" সেবা ব্যবহার করুন।');
                  return;
                }
                setShowNeedVehicleModal(true);
              }}
              className="flex items-center gap-1.5 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold px-4 py-2.5 rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer"
              title="জরুরি গাড়ি অথবা চালক প্রয়োজন হলে বিজ্ঞাপন দিন"
            >
              <PlusCircle className="w-4 h-4" />
              <span>জরুরি গাড়ি / চালক আবশ্যক বিজ্ঞাপন</span>
            </button>

            {/* Direct Driver Vehicle Post Button (Requires Login/Registration) */}
            <button
              onClick={() => {
                if (!currentUser) {
                  onOpenAuth?.('চালক হিসেবে গাড়ি ও সেবা যুক্ত করতে লগইন বা নিবন্ধন করুন');
                  return;
                }
                setShowDriverModal(true);
              }}
              className="flex items-center gap-1.5 bg-[#1B4332] hover:bg-[#143326] text-[#D4E4BC] hover:text-white border border-[#3D7A35] font-bold px-4 py-2.5 rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer"
              title="চালক হিসেবে আপনার গাড়ি ও সেবা যুক্ত করুন"
            >
              <Car className="w-4 h-4 text-[#E8924A]" />
              <span>চালক হিসেবে গাড়ি যুক্ত করুন</span>
            </button>

            {/* Live GPS Track Button */}
            <button
              onClick={() => {
                if (drivers.length > 0) {
                  setSelectedDriverForTracking(drivers[0]);
                  setShowLiveTrackerModal(true);
                } else {
                  alert('ট্র্যাকিং চালু করার জন্য কোনো সক্রিয় চালক প্রয়োজন।');
                }
              }}
              className="flex items-center gap-1.5 bg-[#27AE60] hover:bg-[#219653] text-white font-bold px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer"
            >
              <Radio className="w-4 h-4 animate-pulse" />
              <span>লাইভ রাইড ট্র্যাকিং</span>
            </button>
          </div>
        </div>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="p-3.5 bg-[#E8F8F5] border border-[#27AE60]/40 text-[#27AE60] text-xs sm:text-sm font-bold rounded-2xl flex items-center gap-2 shadow-xs animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ১. ইউআই লেআউট ও ডিসপ্লে: দুটি বড় ইন্টারঅ্যাকটিভ কার্ড (পল্লী পরিবহন vs ফিরতি পরিবহন) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 🟢 পল্লী পরিবহন (বিদ্যমান সেবা) */}
        <div
          onClick={() => setActiveTransportService('regular')}
          className={`p-4 sm:p-5 rounded-3xl cursor-pointer border-2 transition-all relative overflow-hidden shadow-xs hover:shadow-md ${
            activeTransportService === 'regular'
              ? 'bg-[#F2F8F0] border-[#2D5A27] ring-4 ring-[#2D5A27]/20 shadow-md'
              : 'bg-white border-[#E6E0D4] hover:border-[#2D5A27]/40 hover:bg-[#FAFDF9]'
          }`}
        >
          <div className="flex items-start gap-3.5">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 text-2xl shadow-xs transition ${
              activeTransportService === 'regular' ? 'bg-[#2D5A27] text-white' : 'bg-[#E8F5E9] text-[#2D5A27]'
            }`}>
              🚗
            </div>
            <div className="space-y-1.5 flex-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${activeTransportService === 'regular' ? 'bg-[#27AE60] animate-pulse' : 'bg-gray-300'}`} />
                  <h3 className="font-black text-base sm:text-lg text-[#1E3A1A]">
                    🟢 পল্লী পরিবহন
                  </h3>
                  <span className="text-[10px] font-bold text-[#2D5A27] bg-[#D4E4BC] px-2 py-0.5 rounded-full">
                    বিদ্যমান সেবা
                  </span>
                </div>
                {activeTransportService === 'regular' && (
                  <span className="bg-[#2D5A27] text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-full shadow-2xs">
                    সক্রিয়
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-[#4A5D4E] leading-relaxed font-medium">
                জরুরি প্রয়োজনে আপনার এলাকার চালকদের খুঁজুন এবং সরাসরি কল বা মেসেজ দিন।
              </p>
            </div>
          </div>
        </div>

        {/* 🔵 ফিরতি পরিবহন (নতুন সেবা) */}
        <div
          onClick={() => setActiveTransportService('return')}
          className={`p-4 sm:p-5 rounded-3xl cursor-pointer border-2 transition-all relative overflow-hidden shadow-xs hover:shadow-md ${
            activeTransportService === 'return'
              ? 'bg-[#F0F5FD] border-[#1D4ED8] ring-4 ring-[#1D4ED8]/20 shadow-md'
              : 'bg-white border-[#E6E0D4] hover:border-[#1D4ED8]/40 hover:bg-[#F8FAFC]'
          }`}
        >
          <div className="flex items-start gap-3.5">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 text-2xl shadow-xs transition ${
              activeTransportService === 'return' ? 'bg-[#1D4ED8] text-white' : 'bg-[#E0E7FF] text-[#1D4ED8]'
            }`}>
              🔄
            </div>
            <div className="space-y-1.5 flex-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${activeTransportService === 'return' ? 'bg-[#2563EB] animate-pulse' : 'bg-gray-300'}`} />
                  <h3 className="font-black text-base sm:text-lg text-[#1E3A8A]">
                    🔵 ফিরতি পরিবহন
                  </h3>
                  <span className="text-[10px] font-bold text-[#1E40AF] bg-[#DBEAFE] px-2 py-0.5 rounded-full">
                    নতুন ২-মুখী সেবা
                  </span>
                </div>
                {activeTransportService === 'return' && (
                  <span className="bg-[#1D4ED8] text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-full shadow-2xs">
                    সক্রিয়
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-[#3B5270] leading-relaxed font-medium">
                কম ভাড়ায় খালি ফিরতি গাড়ি খুঁজুন অথবা চালক হিসেবে খালি গাড়ির পোস্ট দিন।
              </p>
            </div>
          </div>
        </div>
      </div>

      {activeTransportService === 'return' ? (
        <ReturnTransportSection
          currentDistrict={currentDistrict}
          currentUser={currentUser}
          onOpenAuth={onOpenAuth}
          onInitiateCall={handleInitiateCall}
          onOpenChat={(target) => {
            setActiveChatTarget(target);
          }}
          onShowToast={(msg) => {
            setToastMessage(msg);
            setTimeout(() => setToastMessage(null), 5000);
          }}
        />
      ) : (
        <>
          {/* Main Switcher: Drivers vs Passengers */}
          <div className="flex items-center justify-center">
        <div className="bg-white p-1.5 rounded-3xl border border-[#E6E0D4] shadow-xs flex items-center gap-1">
          <button
            onClick={() => setActiveMainTab('drivers')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl font-bold text-xs sm:text-sm transition cursor-pointer ${
              activeMainTab === 'drivers'
                ? 'bg-[#2D5A27] text-white shadow-xs'
                : 'text-[#5A6B6B] hover:text-black'
            }`}
          >
            <Car className="w-4 h-4" />
            <span>যানবাহন ও চালক তালিকা ({filteredDrivers.length})</span>
          </button>

          <button
            onClick={() => setActiveMainTab('passengers')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl font-bold text-xs sm:text-sm transition cursor-pointer ${
              activeMainTab === 'passengers'
                ? 'bg-[#2D5A27] text-white shadow-xs'
                : 'text-[#5A6B6B] hover:text-black'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>নিবন্ধিত নিরাপদ যাত্রী ({filteredPassengers.length})</span>
          </button>
        </div>
      </div>

      {/* DRIVERS TAB (Viewed by Passengers) */}
      {activeMainTab === 'drivers' && (
        <div className="space-y-4">
          
          {/* Privacy Note for Passenger viewing Driver */}
          <div className="bg-[#FAF8F5] border border-[#D4C3A3] p-3 rounded-2xl flex items-center justify-between text-xs text-[#2D3A3A]">
            <div className="flex items-center gap-2">
              <EyeOff className="w-4 h-4 text-[#A65E2E] flex-shrink-0" />
              <span>
                <strong>প্রাইভেসী নীতি:</strong> যাত্রীরা চালকের নাম, ছবি ও গাড়ি নম্বর দেখতে পারেন। ব্যক্তিগত ফোন নম্বর প্রাইভেসী কারণে মাস্কড রাখা হয়েছে।
              </span>
            </div>
            <span className="hidden sm:inline-block bg-[#E8F8F5] text-[#27AE60] text-[10px] font-bold px-2 py-0.5 rounded-full">
              অ্যাডমিন নিয়ন্ত্রিত
            </span>
          </div>

          {/* Driver Live GPS Broadcast Control Bar (For logged-in Drivers) */}
          {(currentUser?.role === 'driver' || currentUser?.role === 'boatman' || currentUser?.role === 'agri_machinery_driver' || currentUser?.driverInfo) && (
            (() => {
              const isPending = currentUser.accountStatus === 'pending' ||
                currentUser.driverInfo?.status === 'পেন্ডিং' ||
                currentUser.boatmanInfo?.status === 'পেন্ডিং' ||
                currentUser.agriMachineryInfo?.status === 'পেন্ডিং';

              if (isPending) {
                return (
                  <div className="bg-amber-50 border-2 border-amber-400 text-slate-900 p-4 rounded-3xl shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in fade-in">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold text-lg shrink-0 shadow-2xs">
                        ⏳
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-extrabold text-sm sm:text-base text-amber-950">
                            আপনার চালক নিবন্ধন আবেদনটি বর্তমানে পর্যালোচনার অপেক্ষায় (পেন্ডিং) রয়েছে
                          </h4>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 border border-amber-300">
                            🔍 ভেরিফিকেশন প্রক্রিয়াধীন
                          </span>
                        </div>
                        <p className="text-xs text-amber-900/90 leading-tight mt-0.5">
                          যাত্রীদের সর্বোচ্চ সুরক্ষার স্বার্থে অ্যাডমিন কর্তৃক আপনার আপলোডকৃত এনআইডি (NID) ও লাইভ ক্যামেরা ফেস ছবি যাচাই করা হচ্ছে। অনুমোদন সম্পন্ন হলে ইনবক্সে স্বাগতম বার্তা পাবেন এবং আপনার গাড়িটি সরাসরি তালিকায় যুক্ত হবে।
                        </p>
                      </div>
                    </div>
                    <div className="text-xs font-bold px-3 py-1.5 rounded-xl bg-amber-100 border border-amber-300 text-amber-900 self-stretch sm:self-auto text-center whitespace-nowrap">
                      ধৈর্য ধারণের জন্য ধন্যবাদ
                    </div>
                  </div>
                );
              }

              return (
                <div className="bg-gradient-to-r from-[#1B3B1B] to-[#2D5A27] text-white p-3.5 sm:p-4 rounded-3xl shadow-md border border-[#2ECC71]/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in fade-in">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-2xl bg-white/10 text-[#2ECC71] flex items-center justify-center shrink-0 border border-white/20">
                      <Navigation className="w-5 h-5 animate-pulse" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm sm:text-base flex items-center gap-1.5 text-emerald-200">
                        <span>🚗 চালক কন্ট্রোল: আপনার লাইভ অবস্থান শেয়ার করুন</span>
                        <span className="text-[10px] bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-400/40">
                          ✓ সচল ও অনুমোদিত
                        </span>
                      </h4>
                      <p className="text-xs text-emerald-100/90 leading-tight">
                        আপনার ফোনের জিপিএস অন রেখে লাইভ লোকেশন আপডেট করুন, যাতে স্থানীয় যাত্রীদের সার্চে আপনার গাড়ি সবার উপরে (১ নম্বরে) থাকে।
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleUpdateDriverLiveLocation}
                    disabled={driverUpdatingLocation}
                    className="w-full sm:w-auto px-4 py-2 bg-[#2ECC71] hover:bg-[#27AE60] disabled:opacity-60 text-[#1B3B1B] font-extrabold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    <Radio className={`w-3.5 h-3.5 ${driverUpdatingLocation ? 'animate-spin' : 'animate-ping'}`} />
                    <span>{driverUpdatingLocation ? 'অবস্থান আপডেট হচ্ছে...' : '📡 গাড়ির লাইভ লোকেশন আপডেট করুন'}</span>
                  </button>
                </div>
              );
            })()
          )}

          {/* Passenger Proximity & Nearest-First GPS Bar */}
          <div className="bg-[#F0FDF4] border-2 border-[#86EFAC] p-3.5 sm:p-4 rounded-3xl shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
            <div className="flex items-start sm:items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-2xl bg-[#2D5A27] text-white flex items-center justify-center shrink-0 shadow-2xs">
                <Navigation className="w-4 h-4" />
              </div>
              <div className="space-y-0.5 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-extrabold text-xs sm:text-sm text-[#14532D] flex items-center gap-1">
                    <span>📍 নিকটবর্তী চালক সবার আগে (Smart Proximity Sorting)</span>
                  </span>
                  {passengerLocation ? (
                    <span className="bg-[#DCFCE7] text-[#15803D] border border-[#86EFAC] text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span>অবস্থান: {passengerLocation.districtName || 'শনাক্তকৃত'} {passengerLocation.isGps ? '(লাইভ জিপিএস)' : '(এলাকা)'}</span>
                    </span>
                  ) : (
                    <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                      জিপিএস বন্ধ রয়েছে
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-[#166534] leading-relaxed">
                  {passengerLocation
                    ? 'আপনার সবচেয়ে কাছাকাছি থাকা সচল চালকদের দূরত্ব (কিলোমিটার/মিটার) অনুযায়ী সবার উপরে সাজানো রয়েছে।'
                    : 'উভয় ফোনের লোকেশন বা জিপিএস অন থাকলে আপনার সবচেয়ে কাছের চালক চোখের পলকে সবার উপরে দেখতে পাবেন।'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto shrink-0 justify-between md:justify-end">
              <button
                type="button"
                onClick={() => setSortByNearest(!sortByNearest)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                  sortByNearest
                    ? 'bg-[#2D5A27] text-white shadow-2xs'
                    : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                }`}
                title="কাছাকাছি চালকদের অগ্রাধিকার দিয়ে সাজান"
              >
                <CheckCircle2 className={`w-3.5 h-3.5 ${sortByNearest ? 'text-emerald-300' : 'text-gray-400'}`} />
                <span>{sortByNearest ? 'নিকটতম চালক প্রথমে (অন)' : 'সাধারণ ক্রম'}</span>
              </button>

              <button
                type="button"
                onClick={handleDetectPassengerLocation}
                disabled={isDetectingGps}
                className="px-3.5 py-1.5 bg-white hover:bg-emerald-50 text-[#15803D] border border-[#86EFAC] rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-2xs cursor-pointer disabled:opacity-60"
                title="ব্রাউজার বা ফোনের জিপিএস দিয়ে বর্তমান সঠিক অবস্থান নির্ণয় করুন"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isDetectingGps ? 'animate-spin text-[#15803D]' : 'text-[#15803D]'}`} />
                <span>{isDetectingGps ? 'শনাক্ত হচ্ছে...' : passengerLocation?.isGps ? 'লোকেশন রিফ্রেশ' : '📡 আমার লোকেশন অন করুন'}</span>
              </button>
            </div>
          </div>

          {/* Filters & Search: 1. Vehicle Category First -> 2. Fare & Shift -> 3. Area Filter -> 4. Search */}
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-[#E6E0D4] space-y-4 shadow-2xs">
            
            {/* Step 1: কিসের চালক খুঁজবেন? (Vehicle Category Selection First) */}
            <div>
              <div className="flex items-center justify-between gap-2 mb-2.5">
                <div className="flex items-center gap-1.5 text-xs sm:text-sm font-extrabold text-[#2D5A27]">
                  <Car className="w-4 h-4 text-[#E8924A]" />
                  <span>১ম ধাপ: কিসের চালক খুঁজবেন? যানবাহনের ক্যাটাগরি বেছে নিন:</span>
                </div>
                <span className="text-[11px] font-bold text-[#A65E2E] bg-[#F9E5D4] px-2.5 py-0.5 rounded-full">
                  নির্বাচিত: {selectedVehicleType}
                </span>
              </div>

              <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
                {vehicleCategories.map((type) => {
                  const isSelected = selectedVehicleType === type;
                  return (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setSelectedVehicleType(type)}
                      className={`px-3.5 py-2 rounded-2xl font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs ${
                        isSelected
                          ? 'bg-[#2D5A27] text-white ring-2 ring-[#2D5A27]/30 scale-[1.02]'
                          : 'bg-[#FAF8F5] text-[#2D3A3A] border border-[#E6E0D4] hover:bg-[#F9E5D4] hover:border-[#D4C3A3]'
                      }`}
                    >
                      <span>
                        {type === 'সকল যানবাহন' && '🚗'}
                        {type === 'অটোরিকশা / ইজিবাইক' && '🛺'}
                        {type === 'সিএনজি' && '🛺'}
                        {type === 'বাইক রাইডার' && '🏍️'}
                        {type === 'পিকআপ / নসিমন' && '🛻'}
                        {type === 'মাইক্রোবাস / কার' && '🚘'}
                        {type === 'ট্র্যাক্টর / পাওয়ার টিলার' && '🚜'}
                        {type === 'হেস্কোভেটর (মাটি কাটা)' && '🏗️'}
                        {type === 'নৌকা / ইঞ্জিন ট্রলার' && '🚤'}
                      </span>
                      <span>{type}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: ভাড়া নির্ধারণ ও সময় শিফট পছন্দ */}
            <div className="bg-[#FAF8F5] p-3 sm:p-3.5 rounded-2xl border border-[#E6E0D4] flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
              {/* Fare Filter & Smart Estimator */}
              <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                <span className="text-[11px] font-bold text-[#2D3A3A] flex items-center gap-1">
                  <Calculator className="w-3.5 h-3.5 text-[#2D5A27]" />
                  <span>২য় ধাপ (ভাড়া):</span>
                </span>
                
                {(['সকল ভাড়া', 'আলোচনা সাপেক্ষে', 'নির্দিষ্ট ভাড়া'] as const).map((fare) => (
                  <button
                    key={fare}
                    type="button"
                    onClick={() => setSelectedFareFilter(fare)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                      selectedFareFilter === fare
                        ? 'bg-[#2D5A27] text-white shadow-2xs'
                        : 'bg-white text-[#5A6B6B] border border-[#D4C3A3] hover:text-black'
                    }`}
                  >
                    {fare}
                  </button>
                ))}

                <button
                  type="button"
                  onClick={() => {
                    setFareEstimatorDriver(null);
                    setShowFareEstimatorModal(true);
                  }}
                  className="bg-[#E8924A] hover:bg-[#D97D35] text-white px-3 py-1 rounded-xl text-xs font-bold shadow-2xs transition cursor-pointer flex items-center gap-1"
                  title="আনুমানিক দূরত্ব ও ভাড়ার সঠিক হিসাব দেখতে ক্লিক করুন"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>স্মার্ট ভাড়া প্রাক্কলন ও হিসাব</span>
                </button>
              </div>

              {/* Service Shift Filter */}
              <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-[#E6E0D4] overflow-x-auto w-full md:w-auto">
                {(['সকল সময়', 'শুধুমাত্র দিনে', 'শুধুমাত্র রাতে', 'দিন ও রাত (২৪ ঘণ্টা)'] as const).map((shift) => (
                  <button
                    key={shift}
                    type="button"
                    onClick={() => setSelectedShiftFilter(shift)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                      selectedShiftFilter === shift
                        ? 'bg-[#2D5A27] text-white shadow-2xs'
                        : 'text-[#5A6B6B] hover:text-black'
                    }`}
                  >
                    {shift === 'শুধুমাত্র দিনে' && '☀️ '}
                    {shift === 'শুধুমাত্র রাতে' && '🌙 '}
                    {shift === 'দিন ও রাত (২৪ ঘণ্টা)' && '🔄 '}
                    <span>{shift}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 3: Cascading Address Filter */}
            <div className="bg-[#FAF8F5] p-3 sm:p-3.5 rounded-2xl border border-[#E6E0D4]">
              <div className="text-[11px] font-bold text-[#2D5A27] mb-2 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                <span>৩য় ধাপ: এলাকা অনুযায়ী চালক খুঁজুন (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ স্ট্যান্ড/গ্রাম):</span>
              </div>
              <CascadingAddressSelector
                address={filterAddress}
                onChange={setFilterAddress}
                allowAllOption={true}
                layout="grid-4"
                villagePlaceholder="স্ট্যান্ড বা গ্রামের নাম লিখে খুঁজুন..."
              />
            </div>

            {/* Step 4: Quick Search Input */}
            <div className="relative w-full">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                placeholder="নির্দিষ্ট চালকের নাম, গাড়ির নম্বর বা স্ট্যান্ড/রুট লিখে সরাসরি সার্চ করুন..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-2xl pl-9 pr-3.5 py-2.5 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
              />
            </div>

          </div>

          {/* Dynamic Sponsored Ad in Transport */}
          <DynamicAdSection placement="transport_middle" district={currentDistrict} className="my-2" />

          {/* Drivers Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDrivers.length === 0 ? (
              <div className="col-span-full bg-white p-10 rounded-3xl border border-dashed border-[#D4C3A3] text-center text-[#5A6B6B]">
                কোনো চালক পাওয়া যায়নি। আপনার এলাকার কোনো চালক থাকলে প্রথম নিবন্ধনটি করুন।
              </div>
            ) : (
              filteredDrivers.map((driver) => {
                const distInfo = getDriverDistanceMeta(driver);
                return (
                <div 
                  key={driver.id} 
                  className={`bg-white rounded-3xl border p-5 flex flex-col justify-between shadow-xs transition ${
                    distInfo.isVeryClose 
                      ? 'border-emerald-400 ring-2 ring-emerald-400/20 shadow-sm' 
                      : 'border-[#E6E0D4] hover:border-[#2D5A27]/60'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className="bg-[#D4E4BC] text-[#2D5A27] text-[11px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <Car className="w-3 h-3" />
                        {driver.vehicleType}
                      </span>

                      {/* Shift Badge */}
                      {driver.serviceShift === 'শুধুমাত্র দিনে' ? (
                        <span className="bg-[#FFF9E6] text-[#B7791F] border border-[#F6E05E] text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                          ☀️ শুধুমাত্র দিনে
                        </span>
                      ) : driver.serviceShift === 'শুধুমাত্র রাতে' ? (
                        <span className="bg-[#1C2833] text-[#F4D03F] text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Moon className="w-3 h-3 text-[#F4D03F]" />
                          শুধুমাত্র রাতে
                        </span>
                      ) : (
                        <span className="bg-[#E8F8F5] text-[#27AE60] border border-[#27AE60]/30 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                          🔄 দিন ও রাত (২৪ ঘণ্টা)
                        </span>
                      )}
                      {isUserKeyOnline(driver.phone, onlineUsersMap) || (driver.isAvailable ?? true) ? (
                        <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-2xs">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                          <span>🟢 অনলাইনে আছেন</span>
                        </span>
                      ) : (
                        <span className="bg-gray-100 text-gray-500 border border-gray-200 text-[10px] font-medium px-2 py-0.5 rounded-full flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-gray-400" />
                          <span>⚪ অফলাইন</span>
                        </span>
                      )}
                    </div>

                    {/* Driver Profile Header (Driver's Name, Photo, Vehicle Number ONLY) */}
                    <div 
                      onClick={() => handleOpenDriverProfile(driver)}
                      className="flex items-center gap-3 mt-3 cursor-pointer group"
                      title="চালকের ফেসবুক/হোয়াটসঅ্যাপ স্টাইল বড় প্রোফাইল দেখতে স্পর্শ করুন"
                    >
                      {driver.facePhotoUrl ? (
                        <img 
                          src={driver.facePhotoUrl} 
                          alt={driver.driverName}
                          className="w-13 h-13 rounded-2xl object-cover border-2 border-[#2D5A27] shadow-xs group-hover:scale-105 transition"
                        />
                      ) : (
                        <div className="w-13 h-13 rounded-2xl bg-[#FAF8F5] border border-[#D4C3A3] flex items-center justify-center text-[#2D5A27] font-bold text-xl group-hover:scale-105 transition">
                          {driver.driverName.charAt(0)}
                        </div>
                      )}
                      
                      <div className="space-y-0.5">
                        <h3 className="font-bold text-base text-[#2D3A3A] group-hover:text-[#2D5A27] transition flex items-center gap-1.5">
                          <span>{driver.driverName}</span>
                          <ShieldCheck className="w-4 h-4 text-[#27AE60]" title="সেলফি ও ফোন OTP ভেরিফাইড" />
                        </h3>
                        <p className="text-xs text-[#5A6B6B]">
                          গাড়ির নম্বর: <span className="font-bold text-[#2D3A3A] bg-[#FDFBF7] px-1.5 py-0.5 rounded-md border border-[#E6E0D4]">{driver.vehicleNumber}</span>
                        </p>
                      </div>
                    </div>

                    {/* Proximity Distance Indicator Badge */}
                    {distInfo.distanceText && (
                      <div className={`mt-2.5 px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between border ${
                        distInfo.isVeryClose 
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-2xs'
                          : 'bg-[#F0FDF4] text-[#166534] border-[#BBF7D0]'
                      }`}>
                        <div className="flex items-center gap-1.5 min-w-0">
                          <Navigation className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span className="truncate">{distInfo.distanceText}</span>
                        </div>
                        {distInfo.isVeryClose ? (
                          <span className="bg-emerald-600 text-white text-[9px] px-1.5 py-0.2 rounded-full font-extrabold shrink-0 animate-pulse">
                            সবার নিকটে
                          </span>
                        ) : (
                          <span className="text-[10px] text-emerald-700/80 font-semibold shrink-0">
                            নিকটতম ক্রম
                          </span>
                        )}
                      </div>
                    )}

                    <div className="mt-3.5 space-y-1.5 text-xs text-[#5A6B6B] bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4]">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-[#E8924A] flex-shrink-0" />
                        <span>স্ট্যান্ড: <strong className="text-[#2D3A3A]">{driver.standLocation}</strong> ({driver.district})</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Share2 className="w-3.5 h-3.5 text-[#2D5A27] flex-shrink-0" />
                        <span>রুট: {driver.regularRoutes}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] text-[#736B5E] pt-0.5">
                        <Lock className="w-3 h-3 text-[#27AE60]" />
                        <span>চালকের ফোন: <strong className="text-[#2D3A3A]">{currentUser ? maskPhoneNumber(driver.phone) : '•••••••• (লগইন করুন)'}</strong></span>
                      </div>
                    </div>
                  </div>

                  {/* Actions for Passenger */}
                  <div className="mt-4 pt-3 border-t border-[#E6E0D4] flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          if (!currentUser) {
                            onOpenAuth?.('চালকের সাথে সুরক্ষিত কল করতে লগইন বা নিবন্ধন করুন');
                            return;
                          }
                          handleDirectInAppCall({
                            name: driver.driverName,
                            role: 'driver',
                            photo: driver.facePhotoUrl,
                            subtitle: `গাড়ির নম্বর: ${driver.vehicleNumber} (${driver.vehicleType})`,
                            rawPhone: driver.phone
                          });
                        }}
                        className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
                        title="১০০% সুরক্ষিত ইন-অ্যাপ ইন্টারনেট কল (নম্বর ডায়ালারে যাবে না)"
                      >
                        <Mic className="w-4 h-4 text-[#2ECC71]" />
                        <span>অনলাইন কল</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleOpenDriverProfile(driver)}
                        className="bg-[#FAF8F5] hover:bg-[#D4E4BC]/50 text-[#2D5A27] font-bold py-2.5 px-3 rounded-2xl text-xs flex items-center justify-center gap-1 border border-[#2D5A27]/30 transition cursor-pointer shadow-2xs"
                        title="চালকের পাবলিক প্রোফাইল ও জুম ফটো দেখুন"
                      >
                        <User className="w-3.5 h-3.5" />
                        <span>প্রোফাইল</span>
                      </button>

                      <button
                        onClick={() => {
                          if (!currentUser) {
                            onOpenAuth?.('চালকের সাথে চ্যাট করতে লগইন বা নিবন্ধন করুন');
                            return;
                          }
                          setActiveChatTarget({
                            id: `driver-${driver.phone}`,
                            name: driver.driverName,
                            role: 'driver',
                            phone: driver.phone,
                            photo: driver.facePhotoUrl,
                            subtitle: `গাড়ির নম্বর: ${driver.vehicleNumber} (${driver.vehicleType})`
                          });
                        }}
                        className="p-2.5 bg-[#FAF8F5] hover:bg-[#D4E4BC] border border-[#2D5A27] text-[#2D5A27] rounded-2xl transition cursor-pointer"
                        title="চালকের সাথে চ্যাট বা বার্তা আদান-প্রদান করুন"
                      >
                        <MessageCircle className="w-4 h-4" />
                      </button>

                      {/* Voice Chat Button */}
                      <button
                        onClick={() => {
                          if (!currentUser) {
                            onOpenAuth?.('চালকের সাথে ভয়েস চ্যাট করতে লগইন বা নিবন্ধন করুন');
                            return;
                          }
                          setActiveVoiceTarget({
                            name: driver.driverName,
                            role: 'driver',
                            phone: driver.phone,
                            avatar: driver.facePhotoUrl,
                            itemTitle: `গাড়ির নম্বর: ${driver.vehicleNumber} (${driver.vehicleType})`
                          });
                        }}
                        className="p-2.5 bg-[#D4E4BC] hover:bg-[#2D5A27] text-[#2D5A27] hover:text-white border border-[#2D5A27] rounded-2xl transition cursor-pointer shadow-2xs"
                        title="ভয়েস বার্তা / ভয়েস চ্যাট পাঠান"
                      >
                        <Mic className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => {
                          if (!currentUser) {
                            onOpenAuth?.('চালকের সাথে যোগাযোগ করতে লগইন বা নিবন্ধন করুন');
                            return;
                          }
                          handleInitiateCall({
                            name: driver.driverName,
                            role: 'driver',
                            photo: driver.facePhotoUrl,
                            subtitle: `গাড়ির নম্বর: ${driver.vehicleNumber} (${driver.vehicleType})`,
                            rawPhone: driver.phone
                          });
                        }}
                        className="p-2.5 bg-[#FAF8F5] hover:bg-[#F9E5D4] border border-[#D4C3A3] text-[#2D5A27] rounded-2xl transition cursor-pointer"
                        title="কলের মাধ্যম নির্বাচন করুন"
                      >
                        <PhoneCall className="w-4 h-4" />
                      </button>

                      {/* Two-Way Rating and Review Button */}
                      <button
                        onClick={() => {
                          setActiveReviewTarget({
                            id: driver.id,
                            name: driver.driverName,
                            role: 'driver',
                            serviceType: 'transport'
                          });
                        }}
                        className="p-2.5 bg-[#FFF9E6] hover:bg-[#F39C12]/20 border border-[#F39C12]/40 text-[#B7791F] rounded-2xl transition cursor-pointer"
                        title="রেটিং ও রিভিউ দিন"
                      >
                        <Star className="w-4 h-4 fill-current" />
                      </button>

                      {/* Smart Fare Estimator Button */}
                      <button
                        onClick={() => {
                          setFareEstimatorDriver(driver);
                          setShowFareEstimatorModal(true);
                        }}
                        className="p-2.5 bg-[#FAF8F5] hover:bg-[#D4E4BC] border border-[#D4C3A3] text-[#736B5E] hover:text-[#2D3A3A] rounded-2xl transition cursor-pointer"
                        title="ভাড়ার হিসাব ও প্রাক্কলন দেখুন"
                      >
                        <Calculator className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleOpenSafetyShare(driver)}
                        className="p-2.5 bg-[#FAF8F5] hover:bg-[#F9E5D4] border border-[#D4C3A3] text-[#A65E2E] rounded-2xl transition cursor-pointer"
                        title="পরিবারের সাথে চালকের বিস্তারিত শেয়ার করুন"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Live Ride Share Button */}
                    <button
                      onClick={() => handleStartLiveTracking(driver)}
                      className="w-full bg-[#E8F8F5] hover:bg-[#D4EFDF] border border-[#27AE60]/40 text-[#27AE60] font-bold py-2 rounded-2xl text-xs flex items-center justify-center gap-1.5 cursor-pointer transition"
                    >
                      <Radio className="w-3.5 h-3.5 animate-pulse" />
                      <span>লাইভ লোকেশন ট্র্যাকিং শুরু করুন</span>
                    </button>
                  </div>
                </div>
              );
            })
            )}
          </div>
        </div>
      )}

      {/* PASSENGERS TAB (Viewed by Drivers) */}
      {activeMainTab === 'passengers' && (
        <div className="space-y-4">
          <div className="bg-[#FAF8F5] p-4 rounded-3xl border border-[#E6E0D4] flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <h3 className="font-bold text-sm text-[#2D3A3A]">নিরাপদ যাত্রী কার্ড ও ভ্রমণ প্রোফাইল</h3>
                <span className="bg-[#E8F8F5] text-[#27AE60] text-[10px] font-bold px-2 py-0.5 rounded-full">
                  নম্বর মাস্কিং পলিসি
                </span>
              </div>
              <p className="text-xs text-[#5A6B6B]">
                চালকেরা কেবল যাত্রীর নাম এবং সেলফি ছবি দেখতে পান। কোনো NID বা লাইসেন্স চাওয়া হয় না।
              </p>
            </div>

            <button
              onClick={() => {
                if (!currentUser) {
                  onOpenAuth?.('জরুরি গাড়ি বা চালক খুঁজতে বিজ্ঞাপন দিতে লগইন বা নিবন্ধন করুন');
                  return;
                }
                setShowNeedVehicleModal(true);
              }}
              className="bg-[#2D5A27] hover:bg-[#23491E] text-white px-4 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>জরুরি গাড়ি / চালক আবশ্যক বিজ্ঞাপন দিন</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredPassengers.length === 0 ? (
              <div className="col-span-full bg-white p-10 rounded-3xl border border-dashed border-[#D4C3A3] text-center text-[#5A6B6B] space-y-2">
                <UserCheck className="w-8 h-8 text-gray-300 mx-auto" />
                <p className="text-sm font-semibold">কোনো নিবন্ধিত যাত্রী পাওয়া যায়নি</p>
                <p className="text-xs">আপনার বা পরিবারের সদস্যদের জন্য একটি নিরাপদ ট্রাভেল প্রোফাইল তৈরি করুন।</p>
              </div>
            ) : (
              filteredPassengers.map((pass) => (
                <div 
                  key={pass.id}
                  className="bg-white rounded-3xl border border-[#E6E0D4] p-5 flex flex-col justify-between shadow-xs space-y-3"
                >
                  {/* Passenger Profile UI (Name and Profile Photo ONLY) */}
                  <div className="flex items-start gap-3">
                    {pass.facePhotoUrl ? (
                      <img 
                        src={pass.facePhotoUrl} 
                        alt={pass.name}
                        className="w-14 h-14 rounded-2xl object-cover border-2 border-[#2D5A27] shadow-xs"
                      />
                    ) : (
                      <div className="w-14 h-14 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-bold text-xl">
                        {pass.name.charAt(0)}
                      </div>
                    )}
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-bold text-base text-[#2D3A3A]">{pass.name}</h4>
                        {pass.isFaceVerified && (
                          <span className="bg-[#E8F8F5] text-[#27AE60] text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-0.5">
                            <ShieldCheck className="w-3 h-3" /> ভেরিফাইড
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[#5A6B6B]">
                        এলাকা: <span className="font-medium text-[#2D3A3A]">{pass.upazilaOrArea}, {pass.district}</span>
                      </p>
                      <p className="text-[11px] text-[#736B5E] flex items-center gap-1">
                        <Lock className="w-2.5 h-2.5 text-[#27AE60]" />
                        <span>ফোন: {currentUser ? maskPhoneNumber(pass.phone) : '•••••••• (লগইন করুন)'}</span>
                      </p>
                    </div>
                  </div>

                  <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-1 text-xs text-[#5A6B6B]">
                    <p>
                      নিয়মিত রুট: <strong className="text-[#2D3A3A]">{pass.frequentRoute}</strong>
                    </p>
                    <p>
                      জরুরি অভিভাবক সম্পর্ক: <strong className="text-[#2D3A3A]">{pass.emergencyRelation}</strong>
                    </p>
                  </div>

                  <div className="pt-2 border-t border-[#E6E0D4] flex items-center justify-between gap-2">
                    <button
                      onClick={() => {
                        if (!currentUser) {
                          onOpenAuth?.('যাত্রীর সাথে যোগাযোগ করতে লগইন বা নিবন্ধন করুন');
                          return;
                        }
                        handleDirectInAppCall({
                          name: pass.name,
                          role: 'passenger',
                          photo: pass.facePhotoUrl,
                          subtitle: `এলাকা: ${pass.upazilaOrArea}, ${pass.district}`,
                          rawPhone: pass.phone
                        });
                      }}
                      className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white py-2.5 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
                      title="১০০% সুরক্ষিত ইন-অ্যাপ ইন্টারনেট কল (নম্বর ডায়ালারে যাবে না)"
                    >
                      <Mic className="w-3.5 h-3.5 text-[#2ECC71]" />
                      <span>নিরাপদ কল</span>
                    </button>

                    <button
                      onClick={() => {
                        if (!currentUser) {
                          onOpenAuth?.('যাত্রীর সাথে চ্যাট করতে লগইন বা নিবন্ধন করুন');
                          return;
                        }
                        setActiveChatTarget({
                          id: `passenger-${pass.phone}`,
                          name: pass.name,
                          role: 'passenger',
                          phone: pass.phone,
                          photo: pass.facePhotoUrl,
                          subtitle: `যাত্রী এলাকা: ${pass.upazilaOrArea}, ${pass.district}`
                        });
                      }}
                      className="p-2.5 bg-[#FAF8F5] hover:bg-[#D4E4BC] border border-[#2D5A27] text-[#2D5A27] rounded-2xl transition cursor-pointer"
                      title="যাত্রীর সাথে চ্যাট করুন"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => {
                        if (!currentUser) {
                          onOpenAuth?.('যাত্রীর সাথে যোগাযোগ করতে লগইন বা নিবন্ধন করুন');
                          return;
                        }
                        handleInitiateCall({
                          name: pass.name,
                          role: 'passenger',
                          photo: pass.facePhotoUrl,
                          subtitle: `এলাকা: ${pass.upazilaOrArea}, ${pass.district}`,
                          rawPhone: pass.phone
                        });
                      }}
                      className="p-2.5 bg-[#FAF8F5] hover:bg-[#F9E5D4] border border-[#D4C3A3] text-[#2D5A27] rounded-2xl transition cursor-pointer"
                      title="কল অপশন"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
        </>
      )}

      {/* DRIVER REGISTRATION / VEHICLE POST MODAL (NO REGISTRATION REQUIRED) */}
      {showDriverModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[88vh] sm:max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E0D4] overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] p-4 sm:p-5 shrink-0 bg-white">
              <div>
                <h3 className="font-bold text-base text-[#2D3A3A] flex items-center gap-2">
                  <Car className="w-5 h-5 text-[#2D5A27]" />
                  <span>চালক হিসেবে গাড়ি যুক্ত করুন (নিবন্ধন ছাড়া ফ্রি পোস্ট)</span>
                </h3>
                <p className="text-[11px] text-[#736B5E] mt-0.5">
                  🛡️ কোনো ফি বা NID কার্ড লাগবে না। গাড়ি যুক্ত করে সরাসরি যাত্রী পান।
                </p>
              </div>
              <button
                onClick={() => setShowDriverModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form id="driver-register-form" onSubmit={handleRegisterDriver} className="p-4 sm:p-5 overflow-y-auto overscroll-contain flex-1 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">চালকের পুরো নাম *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: মোঃ আল-আমিন শিকদার"
                  value={driverName}
                  onChange={(e) => setDriverName(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">যানবাহনের ধরন</label>
                  <select
                    value={vehicleType}
                    onChange={(e) => setVehicleType(e.target.value as any)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  >
                    <option value="অটোরিকশা / ইজিবাইক">অটোরিকশা / ইজিবাইক</option>
                    <option value="সিএনজি">সিএনজি</option>
                    <option value="বাইক রাইডার">বাইক রাইডার</option>
                    <option value="পিকআপ / নসিমন">পিকআপ / নসিমন</option>
                    <option value="মাইক্রোবাস / কার">মাইক্রোবাস / কার</option>
                    <option value="ট্র্যাক্টর / পাওয়ার টিলার">ট্র্যাক্টর / পাওয়ার টিলার</option>
                    <option value="হেস্কোভেটর (মাটি কাটা)">হেস্কোভেটর (মাটি কাটা)</option>
                    <option value="নৌকা / ইঞ্জিন ট্রলার">নৌকা / ইঞ্জিন ট্রলার</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">গাড়ির নম্বর / প্লেট *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: ঢাকা মেট্রো-থ ১১-২২৩৩"
                    value={vehicleNumber}
                    onChange={(e) => setVehicleNumber(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              {/* Phone with OTP Verification */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#D4C3A3] space-y-2">
                <label className="block text-xs font-semibold text-[#2D3A3A]">
                  মোবাইল নম্বর (OTP ভেরিফিকেশন) *
                </label>
                <div className="flex gap-2">
                  <input
                    type="tel"
                    required
                    disabled={driverOtpVerified}
                    placeholder="০১৭xxxxxxxx"
                    value={driverPhone}
                    onChange={(e) => setDriverPhone(e.target.value)}
                    className="flex-1 border border-[#D4C3A3] bg-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  />
                  {!driverOtpVerified ? (
                    <button
                      type="button"
                      onClick={handleSendDriverOtp}
                      className="bg-[#E8924A] hover:bg-[#D97D35] text-white px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer"
                    >
                      {driverOtpSent ? 'পুনরায় OTP' : 'OTP পাঠান'}
                    </button>
                  ) : (
                    <span className="bg-[#E8F8F5] text-[#27AE60] px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1 border border-[#27AE60]/40">
                      <Check className="w-3.5 h-3.5" /> ভেরিফাইড
                    </span>
                  )}
                </div>

                {driverOtpSent && !driverOtpVerified && (
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      placeholder="৪ ডিজিট কোড"
                      value={driverOtpInput}
                      onChange={(e) => setDriverOtpInput(e.target.value)}
                      className="w-32 border border-[#2D5A27] bg-white rounded-xl px-3 py-1.5 text-xs text-center font-bold tracking-widest"
                    />
                    <button
                      type="button"
                      onClick={handleVerifyDriverOtp}
                      className="bg-[#2D5A27] text-white px-4 py-1.5 rounded-xl text-xs font-bold cursor-pointer"
                    >
                      যাচাই করুন ✓
                    </button>
                  </div>
                )}
                <p className="text-[10px] text-[#736B5E]">
                  🔒 আপনার ফোন নম্বরটি সুরক্ষিত রাখা হবে এবং সাধারণ যাত্রীদের নিকট মাস্কড দেখাবে।
                </p>
              </div>

              {/* Cascading Address Selection */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#D4C3A3]">
                <label className="block text-xs font-bold text-[#2D5A27] mb-2 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                  <span>চালকের স্ট্যান্ড ও ঠিকানা নির্বাচন *</span>
                </label>
                <CascadingAddressSelector
                  address={driverAddress}
                  onChange={setDriverAddress}
                  layout="grid-2x2"
                  required={true}
                  villagePlaceholder="যেমন: বাসস্ট্যান্ড, বাজার বা মোড়"
                  labelPrefix="চালকের "
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">নিয়মিত চলাচলের রুট *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: বাজার হতে কলেজ মোড় ও রেলস্টেশন"
                  value={regularRoutes}
                  onChange={(e) => setRegularRoutes(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              {/* Face Live Verification */}
              <div className="p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1">
                    <Camera className="w-3.5 h-3.5 text-[#2D5A27]" />
                    <span>লাইভ ফেস / সেলফি ভেরিফিকেশন (বাধ্যতামূলক) *</span>
                  </span>
                  {driverFacePhoto && (
                    <span className="text-[11px] text-[#27AE60] font-bold flex items-center gap-0.5">
                      <Check className="w-3 h-3" /> সেলফি গৃহীত
                    </span>
                  )}
                </div>

                {driverFacePhoto ? (
                  <div className="flex items-center gap-3">
                    <img src={driverFacePhoto} alt="Driver" className="w-14 h-14 rounded-2xl object-cover border-2 border-[#2D5A27]" />
                    <button
                      type="button"
                      onClick={() => setDriverFacePhoto(null)}
                      className="text-xs text-[#C0392B] hover:underline cursor-pointer font-semibold"
                    >
                      ছবি পরিবর্তন করুন
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleOpenLiveFaceModal('driver')}
                    className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Camera className="w-4 h-4" />
                    <span>লাইভ ফেস স্ক্যান শুরু করুন (চোখের পলক ও মুখ যাচাই)</span>
                  </button>
                )}
              </div>

              {/* Service Shift Selection */}
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1.5">সেবা দেওয়ার সময়সূচি (শিফট) *</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setServiceShift('শুধুমাত্র দিনে')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold border transition cursor-pointer flex flex-col items-center gap-1 ${
                      serviceShift === 'শুধুমাত্র দিনে'
                        ? 'bg-[#FFF9E6] text-[#B7791F] border-[#F6E05E] shadow-2xs'
                        : 'bg-[#FAF8F5] text-[#5A6B6B] border-[#E6E0D4]'
                    }`}
                  >
                    <span>☀️ দিনে</span>
                    <span className="text-[10px] font-normal">শুধুমাত্র দিনে</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setServiceShift('শুধুমাত্র রাতে')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold border transition cursor-pointer flex flex-col items-center gap-1 ${
                      serviceShift === 'শুধুমাত্র রাতে'
                        ? 'bg-[#1C2833] text-[#F4D03F] border-[#1C2833] shadow-2xs'
                        : 'bg-[#FAF8F5] text-[#5A6B6B] border-[#E6E0D4]'
                    }`}
                  >
                    <span>🌙 রাতে</span>
                    <span className="text-[10px] font-normal">শুধুমাত্র রাতে</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setServiceShift('দিন ও রাত (২৪ ঘণ্টা)')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold border transition cursor-pointer flex flex-col items-center gap-1 ${
                      serviceShift === 'দিন ও রাত (২৪ ঘণ্টা)'
                        ? 'bg-[#E8F8F5] text-[#27AE60] border-[#27AE60] shadow-2xs'
                        : 'bg-[#FAF8F5] text-[#5A6B6B] border-[#E6E0D4]'
                    }`}
                  >
                    <span>🔄 ২৪ ঘণ্টা</span>
                    <span className="text-[10px] font-normal">দিন ও রাত</span>
                  </button>
                </div>
              </div>

              {/* Global Auto-fill & Offline Call Status Box */}
              <div className="bg-[#FAF6ED] border border-[#E6DEC8] rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                    <span>📞</span>
                    <span>অফলাইন সরাসরি কল পারমিশন (Auto-fill)</span>
                  </span>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                    driverAllowOfflineCall 
                      ? 'bg-[#D4E4BC] text-[#2D5A27] border-[#2D5A27]/30' 
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}>
                    {driverAllowOfflineCall ? 'অনুমোদিত (হ্যাঁ)' : 'সুরক্ষিত/মাস্কড (না)'}
                  </span>
                </div>

                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={driverAllowOfflineCall}
                    onChange={(e) => setDriverAllowOfflineCall(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2D5A27] focus:ring-[#2D5A27] cursor-pointer mt-0.5 shrink-0"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-[#2D3A3A] block">
                      আপনি কি যাত্রীদের সরাসরি অফলাইনে কলের সুযোগ দিতে চান?
                    </span>
                    <span className="text-[11px] text-[#736B5E] block mt-0.5 leading-relaxed">
                      {driverAllowOfflineCall
                        ? '✓ অনুমোদিত: যাত্রীরা সরাসরি আপনার সিম কার্ডের নম্বরে কল করতে পারবেন (তবে কল করার পূর্বে তাদের স্ক্রিনে সতর্কবার্তা দেখানো হবে)।'
                        : '🔒 বন্ধ (ডিফল্ট): আপনার আসল নম্বর মাস্কড থাকবে। যাত্রীরা সুরক্ষিত ইন-অ্যাপ কলের মাধ্যমে যোগাযোগ করবেন।'}
                    </span>
                  </div>
                </label>
              </div>

              {/* Terms Agreement Checkbox */}
              <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-1">
                <label className="flex items-start gap-2 cursor-pointer text-xs text-[#2D3A3A]">
                  <input
                    type="checkbox"
                    required
                    checked={driverTermsAccepted}
                    onChange={(e) => setDriverTermsAccepted(e.target.checked)}
                    className="mt-0.5 accent-[#2D5A27]"
                  />
                  <span>
                    আমি প্ল্যাটফর্মের{' '}
                    <button
                      type="button"
                      onClick={() => setShowTermsModal(true)}
                      className="text-[#2D5A27] underline font-bold"
                    >
                      ব্যবহারের শর্তাবলী ও আইনগত দায়মুক্তি (Disclaimer)
                    </button>{' '}
                    পড়েছি ও মেনে নিচ্ছি।
                  </span>
                </label>
              </div>

            </form>

            {/* Pinned Sticky Bottom Action Bar */}
            <div className="border-t border-[#E6E0D4] p-4 bg-[#FAF8F5] shrink-0 flex justify-end gap-2 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
              <button
                type="button"
                onClick={() => setShowDriverModal(false)}
                className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-white border border-[#E6E0D4] hover:bg-gray-50 cursor-pointer"
              >
                বাতিল
              </button>
              <button
                form="driver-register-form"
                type="submit"
                className="px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-sm cursor-pointer active:scale-98 transition"
              >
                গাড়ি ও চালক যুক্ত করুন (ফ্রি)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* NEED VEHICLE MODAL (NO REGISTRATION REQUIRED) */}
      {showNeedVehicleModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[88vh] sm:max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E0D4] overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] p-4 sm:p-5 shrink-0 bg-white">
              <div>
                <h3 className="font-bold text-base text-[#2D3A3A] flex items-center gap-2">
                  <Car className="w-5 h-5 text-[#E8924A]" />
                  <span>জরুরি গাড়ি / চালক আবশ্যক বিজ্ঞাপন (নিবন্ধন ছাড়া)</span>
                </h3>
                <p className="text-[11px] text-[#736B5E] mt-0.5">
                  📢 কোনো অ্যাকাউন্ট ছাড়াই পোস্ট করুন। স্থানীয় সকল চালকের কাছে নোটিফিকেশন পৌঁছে যাবে।
                </p>
              </div>
              <button
                onClick={() => setShowNeedVehicleModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateVehicleRequest} className="flex flex-col flex-1 overflow-hidden">
              <div className="p-4 sm:p-5 overflow-y-auto overscroll-contain flex-1 space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">কী গাড়ি প্রয়োজন? *</label>
                  <select
                    value={needVehicleType}
                    onChange={(e) => setNeedVehicleType(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  >
                    <option value="পিকআপ / নসিমন">পিকআপ / নসিমন (মালবাহী)</option>
                    <option value="সিএনজি">সিএনজি (অটোরিকশা)</option>
                    <option value="অটোরিকশা / ইজিবাইক">অটোরিকশা / ইজিবাইক</option>
                    <option value="মাইক্রোবাস / কার">মাইক্রোবাস / কার (রিজার্ভ)</option>
                    <option value="অ্যাম্বুলেন্স">জরুরি অ্যাম্বুলেন্স</option>
                    <option value="বাইক রাইডার">বাইক রাইডার</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">ভ্রমণের সময় *</label>
                  <select
                    value={needTripTime}
                    onChange={(e) => setNeedTripTime(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  >
                    <option value="আজই জরুরি ভিত্তিতে">আজই জরুরি ভিত্তিতে</option>
                    <option value="আজ বিকেলে/সন্ধ্যায়">আজ বিকেলে / সন্ধ্যায়</option>
                    <option value="আজ রাতে">আজ রাতে</option>
                    <option value="আগামীকাল সকালে">আগামীকাল সকালে</option>
                    <option value="আগামীকাল যেকোনো সময়">আগামীকাল যেকোনো সময়</option>
                    <option value="নির্দিষ্ট চুক্তিতে">নির্দিষ্ট চুক্তিতে</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">আপনার নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: হাজী রফিকুল ইসলাম"
                    value={needName}
                    onChange={(e) => setNeedName(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">মোবাইল নম্বর *</label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৭xxxxxxxx"
                    value={needPhone}
                    onChange={(e) => setNeedPhone(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              {/* Address / Pick up location */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#D4C3A3]">
                <label className="block text-xs font-bold text-[#2D5A27] mb-2 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                  <span>গাড়ি ওঠার স্থান (বর্তমান এলাকা) *</span>
                </label>
                <CascadingAddressSelector
                  address={needAddress}
                  onChange={setNeedAddress}
                  layout="grid-2x2"
                  required={true}
                  villagePlaceholder="যেমন: বাসস্ট্যান্ড, বাজার, বাড়ি"
                  labelPrefix="পিকআপ "
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">গন্তব্য (কোথায় যাবেন?) *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: সদর হাসপাতাল / কাঁচাবাজার / বিমানবন্দর"
                  value={needDestination}
                  onChange={(e) => setNeedDestination(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">বিস্তারিত বিবরণ (যাত্রী সংখ্যা / মালামাল)</label>
                <textarea
                  rows={2}
                  placeholder="যেমন: ৪ জন যাত্রী যাব, সাথে দুটি বস্তা আছে অথবা রোগী নিয়ে জরুরি যেতে হবে..."
                  value={needDescription}
                  onChange={(e) => setNeedDescription(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl p-2.5 text-xs focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              {/* Global Auto-fill & Offline Call Status Box */}
              <div className="bg-[#FAF6ED] border border-[#E6DEC8] rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                    <span>📞</span>
                    <span>অফলাইন সরাসরি কল পারমিশন (Auto-fill)</span>
                  </span>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                    needAllowOfflineCall 
                      ? 'bg-[#D4E4BC] text-[#2D5A27] border-[#2D5A27]/30' 
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}>
                    {needAllowOfflineCall ? 'অনুমোদিত (হ্যাঁ)' : 'সুরক্ষিত/মাস্কড (না)'}
                  </span>
                </div>

                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={needAllowOfflineCall}
                    onChange={(e) => setNeedAllowOfflineCall(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2D5A27] focus:ring-[#2D5A27] cursor-pointer mt-0.5 shrink-0"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-[#2D3A3A] block">
                      আপনি কি চালকদের সরাসরি অফলাইনে কলের সুযোগ দিতে চান?
                    </span>
                    <span className="text-[11px] text-[#736B5E] block mt-0.5 leading-relaxed">
                      {needAllowOfflineCall
                        ? '✓ অনুমোদিত: চালকেরা সরাসরি আপনার সিম কার্ডের নম্বরে কল করতে পারবেন (তবে কল করার পূর্বে তাদের স্ক্রিনে সতর্কবার্তা দেখানো হবে)।'
                        : '🔒 বন্ধ (ডিফল্ট): আপনার আসল নম্বর মাস্কড থাকবে। চালকেরা সুরক্ষিত ইন-অ্যাপ কল বা চ্যাটে যোগাযোগ করবেন।'}
                    </span>
                  </div>
                </label>
              </div>
              </div>

              {/* Pinned Sticky Bottom Action Bar */}
              <div className="border-t border-[#E6E0D4] p-4 bg-[#FAF8F5] shrink-0 flex justify-end gap-2 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
                <button
                  type="button"
                  onClick={() => setShowNeedVehicleModal(false)}
                  className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-white border border-[#E6E0D4] hover:bg-gray-50 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#E8924A] hover:bg-[#D97D35] shadow-sm cursor-pointer active:scale-98 transition flex items-center gap-1.5"
                >
                  <span>বিজ্ঞাপন দিন ও চালকদের নোটিফিকেশন পাঠান</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PASSENGER REGISTRATION MODAL (OTP + Face Photo ONLY - NO NID/License) */}
      {showPassengerModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[88vh] sm:max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E0D4] overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] p-4 sm:p-5 shrink-0 bg-white">
              <div>
                <h3 className="font-bold text-base text-[#2D3A3A] flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-[#E8924A]" />
                  <span>নিরাপদ যাত্রী ট্রাভেল প্রোফাইল (OTP ও সেলফি)</span>
                </h3>
                <p className="text-[11px] text-[#736B5E] mt-0.5">
                  🛡️ কোনো NID কার্ড দরকার নেই। ফোন নম্বর মাস্কড থাকবে।
                </p>
              </div>
              <button
                onClick={() => setShowPassengerModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form id="passenger-register-form" onSubmit={handleRegisterPassenger} className="p-4 sm:p-5 overflow-y-auto overscroll-contain flex-1 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">যাত্রীর পুরো নাম *</label>
                <input
                  type="text"
                  required
                  placeholder="আপনার নাম লিখুন"
                  value={passName}
                  onChange={(e) => setPassName(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              {/* Phone with OTP */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#D4C3A3] space-y-2">
                <label className="block text-xs font-semibold text-[#2D3A3A]">
                  মোবাইল নম্বর (OTP ভেরিফিকেশন) *
                </label>
                <div className="flex gap-2">
                  <input
                    type="tel"
                    required
                    disabled={passOtpVerified}
                    placeholder="০১৭xxxxxxxx"
                    value={passPhone}
                    onChange={(e) => setPassPhone(e.target.value)}
                    className="flex-1 border border-[#D4C3A3] bg-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                  />
                  {!passOtpVerified ? (
                    <button
                      type="button"
                      onClick={handleSendPassOtp}
                      className="bg-[#E8924A] hover:bg-[#D97D35] text-white px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer"
                    >
                      {passOtpSent ? 'পুনরায় OTP' : 'OTP পাঠান'}
                    </button>
                  ) : (
                    <span className="bg-[#E8F8F5] text-[#27AE60] px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1 border border-[#27AE60]/40">
                      <Check className="w-3.5 h-3.5" /> ভেরিফাইড
                    </span>
                  )}
                </div>

                {passOtpSent && !passOtpVerified && (
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      placeholder="৪ ডিজিট কোড"
                      value={passOtpInput}
                      onChange={(e) => setPassOtpInput(e.target.value)}
                      className="w-32 border border-[#2D5A27] bg-white rounded-xl px-3 py-1.5 text-xs text-center font-bold tracking-widest"
                    />
                    <button
                      type="button"
                      onClick={handleVerifyPassOtp}
                      className="bg-[#2D5A27] text-white px-4 py-1.5 rounded-xl text-xs font-bold cursor-pointer"
                    >
                      যাচাই করুন ✓
                    </button>
                  </div>
                )}
              </div>

              {/* Emergency Contact */}
              <div className="p-3 bg-[#FADBD8]/40 border border-[#C0392B]/30 rounded-2xl space-y-2">
                <span className="text-xs font-bold text-[#C0392B] flex items-center gap-1">
                  <PhoneForwarded className="w-3.5 h-3.5" />
                  <span>জরুরি পারিবারিক অভিভাবকের নম্বর (SOS Safety)</span>
                </span>
                
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="tel"
                    placeholder="অভিভাবকের মোবাইল নং"
                    value={passEmergencyPhone}
                    onChange={(e) => setPassEmergencyPhone(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-white rounded-xl px-3 py-1.5 text-xs focus:outline-none"
                  />
                  <input
                    type="text"
                    placeholder="সম্পর্ক (পিতা/মা/ভাই)"
                    value={passEmergencyRel}
                    onChange={(e) => setPassEmergencyRel(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-white rounded-xl px-3 py-1.5 text-xs focus:outline-none"
                  />
                </div>
              </div>

              {/* Cascading Address Selection */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#D4C3A3]">
                <label className="block text-xs font-bold text-[#2D5A27] mb-2 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                  <span>যাত্রীর এলাকা ও ঠিকানা নির্বাচন *</span>
                </label>
                <CascadingAddressSelector
                  address={passAddress}
                  onChange={setPassAddress}
                  layout="grid-2x2"
                  required={true}
                  villagePlaceholder="যেমন: উত্তরপাড়া, মোল্লাবাড়ি বা মোড়"
                  labelPrefix="যাত্রীর "
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">প্রায়শই যাতায়াতের রুট</label>
                <input
                  type="text"
                  placeholder="যেমন: বাড়ি হতে উপজেলা সদর ও হাট"
                  value={passFrequentRoute}
                  onChange={(e) => setPassFrequentRoute(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FAF8F5] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              {/* Face Live Verification for Passenger */}
              <div className="p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1">
                    <Camera className="w-3.5 h-3.5 text-[#E8924A]" />
                    <span>লাইভ সেলফি ফেস ভেরিফিকেশন (বাধ্যতামূলক) *</span>
                  </span>
                  {passFacePhoto && (
                    <span className="text-[11px] text-[#27AE60] font-bold flex items-center gap-0.5">
                      <Check className="w-3 h-3" /> সেলফি গৃহীত
                    </span>
                  )}
                </div>

                {passFacePhoto ? (
                  <div className="flex items-center gap-3">
                    <img src={passFacePhoto} alt="Passenger" className="w-14 h-14 rounded-2xl object-cover border-2 border-[#2D5A27]" />
                    <button
                      type="button"
                      onClick={() => setPassFacePhoto(null)}
                      className="text-xs text-[#C0392B] hover:underline cursor-pointer font-semibold"
                    >
                      ছবি পরিবর্তন করুন
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleOpenLiveFaceModal('passenger')}
                    className="w-full bg-[#E8924A] hover:bg-[#D97D35] text-white py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Camera className="w-4 h-4" />
                    <span>লাইভ ফেস স্ক্যান শুরু করুন (চোখের পলক ও মুখ যাচাই)</span>
                  </button>
                )}
              </div>

              {/* Global Auto-fill & Offline Call Status Box */}
              <div className="bg-[#FAF6ED] border border-[#E6DEC8] rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                    <span>📞</span>
                    <span>অফলাইন সরাসরি কল পারমিশন (Auto-fill)</span>
                  </span>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                    passAllowOfflineCall 
                      ? 'bg-[#D4E4BC] text-[#2D5A27] border-[#2D5A27]/30' 
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}>
                    {passAllowOfflineCall ? 'অনুমোদিত (হ্যাঁ)' : 'সুরক্ষিত/মাস্কড (না)'}
                  </span>
                </div>

                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={passAllowOfflineCall}
                    onChange={(e) => setPassAllowOfflineCall(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2D5A27] focus:ring-[#2D5A27] cursor-pointer mt-0.5 shrink-0"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-[#2D3A3A] block">
                      আপনি কি চালকদের সরাসরি অফলাইনে কলের সুযোগ দিতে চান?
                    </span>
                    <span className="text-[11px] text-[#736B5E] block mt-0.5 leading-relaxed">
                      {passAllowOfflineCall
                        ? '✓ অনুমোদিত: চালকেরা সরাসরি আপনার সিম কার্ডের নম্বরে কল করতে পারবেন (তবে কল করার পূর্বে তাদের স্ক্রিনে সতর্কবার্তা দেখানো হবে)।'
                        : '🔒 বন্ধ (ডিফল্ট): আপনার আসল নম্বর মাস্কড থাকবে। চালকেরা সুরক্ষিত ইন-অ্যাপ কল বা চ্যাটে যোগাযোগ করবেন।'}
                    </span>
                  </div>
                </label>
              </div>

              {/* Terms Agreement Checkbox */}
              <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-1">
                <label className="flex items-start gap-2 cursor-pointer text-xs text-[#2D3A3A]">
                  <input
                    type="checkbox"
                    required
                    checked={passTermsAccepted}
                    onChange={(e) => setPassTermsAccepted(e.target.checked)}
                    className="mt-0.5 accent-[#2D5A27]"
                  />
                  <span>
                    আমি প্ল্যাটফর্মের{' '}
                    <button
                      type="button"
                      onClick={() => setShowTermsModal(true)}
                      className="text-[#2D5A27] underline font-bold"
                    >
                      ব্যবহারের শর্তাবলী ও আইনগত দায়মুক্তি (Disclaimer)
                    </button>{' '}
                    পড়েছি ও মেনে নিচ্ছি।
                  </span>
                </label>
              </div>

            </form>

            {/* Pinned Sticky Bottom Action Bar */}
            <div className="border-t border-[#E6E0D4] p-4 bg-[#FAF8F5] shrink-0 flex justify-end gap-2 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
              <button
                type="button"
                onClick={() => setShowPassengerModal(false)}
                className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-white border border-[#E6E0D4] hover:bg-gray-50 cursor-pointer"
              >
                বাতিল
              </button>
              <button
                form="passenger-register-form"
                type="submit"
                className="px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-sm cursor-pointer active:scale-98 transition"
              >
                যাত্রী প্রোফাইল তৈরি করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BIOMETRIC LIVE FACE VERIFICATION MODAL */}
      {showLiveFaceModal && (
        <LiveFaceVerificationModal
          title={liveFaceTarget === 'driver' ? 'চালকের লাইভ বায়োমেট্রিক ফেস ভেরিফিকেশন' : 'যাত্রীর লাইভ বায়োমেট্রিক ফেস ভেরিফিকেশন'}
          subtitle={liveFaceTarget === 'driver' 
            ? 'যাত্রীদের আস্থা ও নিরাপত্তার জন্য চালকের জীবন্ত মুখমণ্ডল ও চোখের পলক যাচাই' 
            : 'নিরাপদ রাইডের স্বার্থে যাত্রীর জীবন্ত মুখমণ্ডল ও চোখের পলক যাচাই'}
          onCapture={(capturedBase64) => {
            if (liveFaceTarget === 'driver') {
              setDriverFacePhoto(capturedBase64);
            } else {
              setPassFacePhoto(capturedBase64);
            }
            setShowLiveFaceModal(false);
          }}
          onCancel={() => setShowLiveFaceModal(false)}
        />
      )}

      {/* SAFETY SHARE MODAL */}
      {showSafetyModal && selectedDriverForSafety && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-[#E6E0D4] space-y-4">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
              <h3 className="font-bold text-base text-[#2D3A3A] flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#27AE60]" />
                <span>নিরাপত্তা শেয়ার ও জরুরি সতর্কবার্তা</span>
              </h3>
              <button
                onClick={() => setShowSafetyModal(false)}
                className="text-[#736B5E] text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] text-xs text-[#2D3A3A] space-y-1.5">
              <p>চালক: <strong>{selectedDriverForSafety.driverName}</strong></p>
              <p>গাড়ির নম্বর: <strong>{selectedDriverForSafety.vehicleNumber}</strong> ({selectedDriverForSafety.vehicleType})</p>
              <p>স্ট্যান্ড: {selectedDriverForSafety.standLocation}, {selectedDriverForSafety.district}</p>
              <p>রুট: {selectedDriverForSafety.regularRoutes}</p>
            </div>

            <div className="space-y-2">
              <button
                onClick={handleShareToWhatsApp}
                className="w-full bg-[#25D366] hover:bg-[#20BE5A] text-white font-bold py-2.5 rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>হোয়াটসঅ্যাপে পরিবারের সাথে শেয়ার করুন</span>
              </button>

              <button
                onClick={() => {
                  setShowSafetyModal(false);
                  setSelectedDriverForTracking(selectedDriverForSafety);
                  setShowLiveTrackerModal(true);
                }}
                className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <Radio className="w-4 h-4" />
                <span>লাইভ GPS ট্র্যাকিং লিংক তৈরি করুন</span>
              </button>

              <a
                href="tel:999"
                className="w-full bg-[#C0392B] hover:bg-[#A93226] text-white font-bold py-2.5 rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs"
              >
                <PhoneCall className="w-4 h-4" />
                <span>জরুরি পুলিশ ও উদ্ধার সহায়তা (৯৯৯ কল)</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* LIVE GPS TRIP TRACKER MODAL */}
      {showLiveTrackerModal && selectedDriverForTracking && (
        <LiveTripTrackerModal
          driver={selectedDriverForTracking}
          onClose={() => setShowLiveTrackerModal(false)}
        />
      )}

      {/* TERMS AND DISCLAIMER MODAL */}
      {showTermsModal && (
        <TermsAndDisclaimerModal
          onClose={() => setShowTermsModal(false)}
        />
      )}

      {/* CALL METHOD SELECTOR MODAL */}
      {showCallChoiceModal && activeCallTarget && (
        <CallChoiceModal
          recipientName={activeCallTarget.name}
          recipientRole={activeCallTarget.role}
          recipientPhoto={activeCallTarget.photo}
          recipientSubtitle={activeCallTarget.subtitle}
          rawPhone={activeCallTarget.rawPhone}
          allowOfflineCall={activeCallTarget.allowOfflineCall}
          onSelectInAppCall={() => {
            setShowCallChoiceModal(false);
            setShowInAppVoiceCall(true);
          }}
          onOpenChat={() => {
            setShowCallChoiceModal(false);
            setActiveChatTarget({
              id: activeCallTarget.id || activeCallTarget.rawPhone,
              name: activeCallTarget.name,
              role: activeCallTarget.role,
              phone: activeCallTarget.rawPhone,
              photo: activeCallTarget.photo,
              subtitle: activeCallTarget.subtitle
            });
          }}
          onOpenVoiceNote={() => {
            setShowCallChoiceModal(false);
            setActiveVoiceTarget({
              name: activeCallTarget.name,
              role: activeCallTarget.role,
              phone: activeCallTarget.rawPhone,
              avatar: activeCallTarget.photo,
              itemTitle: activeCallTarget.subtitle
            });
          }}
          onClose={() => {
            setShowCallChoiceModal(false);
            setActiveCallTarget(null);
          }}
        />
      )}

      {/* IN-APP 100% PRIVATE VOICE CALL MODAL */}
      {showInAppVoiceCall && activeCallTarget && (
        <InAppVoiceCallModal
          recipientName={activeCallTarget.name}
          recipientRole={activeCallTarget.role}
          recipientPhoto={activeCallTarget.photo}
          recipientSubtitle={activeCallTarget.subtitle}
          maskedPhone={maskPhoneNumber(activeCallTarget.rawPhone)}
          rawPhone={activeCallTarget.rawPhone}
          currentUser={currentUser}
          onClose={() => {
            setShowInAppVoiceCall(false);
            setActiveCallTarget(null);
          }}
        />
      )}

      {/* REAL-TIME CLOUD CHAT MODAL */}
      {activeChatTarget && (
        <ChatModal
          isOpen={!!activeChatTarget}
          onClose={() => setActiveChatTarget(null)}
          currentUser={currentUser}
          recipientId={activeChatTarget.id}
          recipientName={activeChatTarget.name}
          recipientRole={activeChatTarget.role}
          recipientPhone={activeChatTarget.phone}
          recipientAvatar={activeChatTarget.photo}
          itemTitle={activeChatTarget.subtitle}
          onOpenAuth={onOpenAuth}
        />
      )}

      {/* VOICE CHAT MODAL */}
      {activeVoiceTarget && (
        <VoiceChatModal
          isOpen={true}
          onClose={() => setActiveVoiceTarget(null)}
          recipientName={activeVoiceTarget.name}
          recipientRole={activeVoiceTarget.role}
          recipientPhone={activeVoiceTarget.phone}
          recipientAvatar={activeVoiceTarget.avatar}
          itemTitle={activeVoiceTarget.itemTitle}
          currentUser={currentUser}
          onSendVoiceMessage={(audioUrl, duration, textSummary) => {
            setActiveChatTarget({
              id: `driver-${activeVoiceTarget.phone}`,
              name: activeVoiceTarget.name,
              role: activeVoiceTarget.role,
              phone: activeVoiceTarget.phone,
              photo: activeVoiceTarget.avatar,
              subtitle: activeVoiceTarget.itemTitle || ''
            });
            setActiveVoiceTarget(null);
          }}
        />
      )}

      {/* TWO-WAY REVIEW MODAL */}
      {activeReviewTarget && (
        <TwoWayReviewModal
          isOpen={true}
          onClose={() => setActiveReviewTarget(null)}
          targetId={activeReviewTarget.id}
          targetName={activeReviewTarget.name}
          targetRole={activeReviewTarget.role}
          serviceType={activeReviewTarget.serviceType}
          currentUser={currentUser}
        />
      )}

      {/* SMART FARE ESTIMATOR MODAL */}
      {showFareEstimatorModal && (
        <SmartFareEstimatorModal
          isOpen={true}
          onClose={() => {
            setShowFareEstimatorModal(false);
            setFareEstimatorDriver(null);
          }}
          selectedDriver={fareEstimatorDriver}
          onSelectDriverToCall={(driver) => {
            handleDirectInAppCall({
              name: driver.driverName,
              role: 'driver',
              photo: driver.facePhotoUrl,
              subtitle: `গাড়ির নম্বর: ${driver.vehicleNumber} (${driver.vehicleType})`,
              rawPhone: driver.phone
            });
          }}
        />
      )}

    </div>
  );
};
