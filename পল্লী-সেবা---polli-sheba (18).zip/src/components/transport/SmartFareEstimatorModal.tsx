import React, { useState } from 'react';
import { 
  Calculator, 
  X, 
  Sun, 
  Moon, 
  Car, 
  Navigation, 
  Sparkles, 
  AlertCircle, 
  ShieldCheck, 
  Info,
  ArrowRight,
  Users,
  Package
} from 'lucide-react';
import { TransportDriver } from '../../types';
import { useLanguage } from '../../context/LanguageContext';

interface SmartFareEstimatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDriver?: TransportDriver | null;
  onSelectDriverToCall?: (driver: TransportDriver) => void;
}

interface VehicleFareRate {
  name: string;
  dayBase: number;
  nightBase: number;
  perKmDay: number;
  perKmNight: number;
  desc: string;
}

const VEHICLE_RATES: Record<string, VehicleFareRate> = {
  'ভ্যান ও রিক্সা': {
    name: 'ভ্যান ও রিক্সা',
    dayBase: 15,
    nightBase: 25,
    perKmDay: 10,
    perKmNight: 15,
    desc: 'গ্রামীণ রাস্তা ও বাজারে স্বল্প দূরত্বের জন্য পরিবেশবান্ধব বাহন'
  },
  'অটোরিকশা / ইজিবাইক': {
    name: 'অটোরিকশা / ইজিবাইক',
    dayBase: 20,
    nightBase: 30,
    perKmDay: 12,
    perKmNight: 16,
    desc: 'লোকাল ও রিজার্ভ উভয় চলাচলের জন্য সাশ্রয়ী'
  },
  'সিএনজি': {
    name: 'সিএনজি',
    dayBase: 40,
    nightBase: 60,
    perKmDay: 18,
    perKmNight: 24,
    desc: 'মাঝারি দূরত্বের ইউনিয়ন বা উপজেলা সদরে দ্রুত যাতায়াত'
  },
  'বাইক রাইডার': {
    name: 'বাইক রাইডার',
    dayBase: 30,
    nightBase: 45,
    perKmDay: 15,
    perKmNight: 20,
    desc: 'একক যাত্রীর জন্য দ্রুততম গ্রামীণ বাহন'
  },
  'পিকআপ / নসিমন': {
    name: 'পিকআপ / নসিমন',
    dayBase: 150,
    nightBase: 200,
    perKmDay: 35,
    perKmNight: 45,
    desc: 'কৃষিপণ্য, সার বা ভারী মালামাল হাটে নেওয়ার জন্য'
  },
  'মাইক্রোবাস / কার': {
    name: 'মাইক্রোবাস / কার',
    dayBase: 300,
    nightBase: 400,
    perKmDay: 45,
    perKmNight: 60,
    desc: 'পারিবারিক ভ্রমণ, রোগী নেওয়া বা বিশেষ অনুষ্ঠান'
  },
  'অ্যাম্বুলেন্স': {
    name: 'অ্যাম্বুলেন্স (জরুরি রোগী পরিবহন)',
    dayBase: 500,
    nightBase: 600,
    perKmDay: 50,
    perKmNight: 65,
    desc: 'অক্সিজেন সুবিধা সহ জরুরি রোগী পরিবহন ও হাসপাতাল স্থানান্তর'
  },
  'হেস্কোভেটর (মাটি কাটা)': {
    name: 'হেস্কোভেটর (মাটি কাটা)',
    dayBase: 1200,
    nightBase: 1500,
    perKmDay: 0,
    perKmNight: 0,
    desc: 'পুকুর খনন, ভিটা ভরাট ও মাটি কাটার ভারী যন্ত্রপাতি (ঘণ্টা ভিত্তিক)'
  },
  'কলেরলাঙ্গল / ট্র্যাক্টর': {
    name: 'কলেরলাঙ্গল / ট্র্যাক্টর',
    dayBase: 800,
    nightBase: 900,
    perKmDay: 0,
    perKmNight: 0,
    desc: 'কৃষি জমি চাষ, মই দেওয়া ও জমি প্রস্তুতির পাওয়ার টিলার (বিঘা ভিত্তিক)'
  },
  'নৌকা ও খেয়া': {
    name: 'নৌকা ও খেয়া (ইঞ্জিন ট্রলার)',
    dayBase: 15,
    nightBase: 25,
    perKmDay: 10,
    perKmNight: 15,
    desc: 'নদী, হাওড় বা খাল পারাপার ও ইঞ্জিন ট্রলার রিজার্ভ'
  },
  'নৌকার মাঝি / খেয়া চালক': {
    name: 'নৌকার মাঝি / খেয়া চালক',
    dayBase: 15,
    nightBase: 25,
    perKmDay: 10,
    perKmNight: 15,
    desc: 'নদী বা হাওড় পারাপার'
  }
};

export const SmartFareEstimatorModal: React.FC<SmartFareEstimatorModalProps> = ({
  isOpen,
  onClose,
  selectedDriver,
  onSelectDriverToCall
}) => {
  const { t } = useLanguage();
  const initialVehicle = selectedDriver?.vehicleType || 'অটোরিকশা / ইজিবাইক';
  const [vehicleType, setVehicleType] = useState<string>(initialVehicle);
  const [timeOfDay, setTimeOfDay] = useState<'day' | 'night'>('day');
  const [distanceKm, setDistanceKm] = useState<number>(5);
  const [isReserve, setIsReserve] = useState<boolean>(true);
  const [passengerCount, setPassengerCount] = useState<'1-2' | '3-4' | '5+'>('1-2');
  const [hasLuggage, setHasLuggage] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentRate = VEHICLE_RATES[vehicleType] || VEHICLE_RATES['অটোরিকশা / ইজিবাইক'];

  // Base and km calculation
  let basePrice = timeOfDay === 'day' ? currentRate.dayBase : currentRate.nightBase;
  let kmPrice = timeOfDay === 'day' ? currentRate.perKmDay : currentRate.perKmNight;

  // If driver has customized rates:
  if (selectedDriver) {
    if (timeOfDay === 'day' && selectedDriver.baseFareDay) {
      basePrice = selectedDriver.baseFareDay;
    } else if (timeOfDay === 'night' && selectedDriver.baseFareNight) {
      basePrice = selectedDriver.baseFareNight;
    }
    if (selectedDriver.farePerKm) {
      kmPrice = selectedDriver.farePerKm;
    }
  }

  // Multipliers for passengers and luggage
  const passengerMultiplier = passengerCount === '1-2' ? 1.0 : passengerCount === '3-4' ? 1.15 : 1.3;
  const luggageMultiplier = hasLuggage ? 1.15 : 1.0;

  const calculatedBase = isReserve ? basePrice * 1.5 : basePrice;
  const calculatedTotal = Math.round((calculatedBase + (distanceKm * kmPrice)) * passengerMultiplier * luggageMultiplier);
  const minFare = Math.round(calculatedTotal * 0.9);
  const maxFare = Math.round(calculatedTotal * 1.15);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4 max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center shadow-xs">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#2D3A3A] flex items-center gap-1.5">
                <span>{t('স্মার্ট ভাড়া প্রাক্কলন ও হিসাব', 'Smart Fare Estimator')}</span>
                <span className="text-[10px] bg-[#E8924A] text-white px-2 py-0.5 rounded-full font-bold">
                  {t('এআই প্রাক্কলন', 'AI Estimator')}
                </span>
              </h3>
              <p className="text-xs text-[#736B5E]">{t('দিন ও রাতভিত্তিক গ্রামীণ ন্যায্য ভাড়া নির্দেশিকা', 'Fair Rural Fare Guidelines (Day & Night)')}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 text-[#736B5E] hover:text-[#2D3A3A] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Prominent Regional Difference Disclaimer */}
        <div className="bg-[#FFF9E6] border border-[#FFE082] p-3 rounded-2xl text-xs text-[#7A5800] flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-[#D97706] shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-[#8A5800]">{t('অঞ্চল ও পরিস্থিতি ভেদে ভাড়া কমবেশি হতে পারে:', 'Fare may vary by region and conditions:')}</p>
            <p className="text-[11px] leading-relaxed mt-0.5 text-[#6D4C00]">
              {t(
                'এই হিসাবটি একটি আনুমানিক ধারণা (প্রাক্কলন) মাত্র। স্থানীয় রাস্তার অবস্থা, যানজট, আবহাওয়া, অঞ্চল ও স্ট্যান্ডভেদে প্রকৃত ভাড়া কিছুটা কম বা বেশি হতে পারে। চূড়ান্ত ভাড়া চালকের সাথে পারস্পরিক আলোচনা সাপেক্ষে নির্ধারিত হবে।',
                'This calculation is an estimate only. Actual fare may vary slightly depending on road condition, traffic, weather, region and stand norms. Final fare is subject to mutual agreement with the driver.'
              )}
            </p>
          </div>
        </div>

        {/* Selected Driver Banner (if applicable) */}
        {selectedDriver && (
          <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] flex items-center justify-between">
            <div>
              <span className="text-[10px] text-[#736B5E] block font-semibold">{t('নির্দিষ্ট চালক:', 'Specific Driver:')}</span>
              <span className="font-bold text-xs text-[#2D3A3A]">{selectedDriver.driverName} ({selectedDriver.vehicleType})</span>
            </div>
            <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] font-bold px-2 py-0.5 rounded-full">
              {selectedDriver.standLocation}
            </span>
          </div>
        )}

        {/* Vehicle Selector */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#2D3A3A] block">যানবাহনের ধরন নির্বাচন করুন:</label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {Object.keys(VEHICLE_RATES).map((type) => {
              const isSelected = vehicleType === type;
              return (
                <button
                  key={type}
                  type="button"
                  onClick={() => setVehicleType(type)}
                  className={`p-2 rounded-xl text-left transition border cursor-pointer ${
                    isSelected
                      ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-xs'
                      : 'bg-[#FAF8F5] text-[#2D3A3A] border-[#E6E0D4] hover:border-[#2D5A27]'
                  }`}
                >
                  <span className="block text-xs font-bold truncate">{type}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Time of Day Toggle: Day vs Night */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#2D3A3A] block">যাত্রার সময় (দিন / রাত):</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setTimeOfDay('day')}
              className={`p-3 rounded-2xl flex items-center justify-center gap-2 border transition cursor-pointer ${
                timeOfDay === 'day'
                  ? 'bg-[#FFF9E6] border-[#F39C12] text-[#B7791F] font-bold shadow-xs'
                  : 'bg-white border-[#E6E0D4] text-[#5A6B6B]'
              }`}
            >
              <Sun className="w-5 h-5 text-[#F39C12]" />
              <div className="text-left">
                <span className="text-xs block font-bold">দিনের বেলা</span>
                <span className="text-[10px] text-[#736B5E]">সকাল ৬:০০ - সন্ধ্যা ৬:৫৯</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setTimeOfDay('night')}
              className={`p-3 rounded-2xl flex items-center justify-center gap-2 border transition cursor-pointer ${
                timeOfDay === 'night'
                  ? 'bg-[#1E2A38] border-[#2C3E50] text-white font-bold shadow-xs'
                  : 'bg-white border-[#E6E0D4] text-[#5A6B6B]'
              }`}
            >
              <Moon className="w-5 h-5 text-indigo-400" />
              <div className="text-left">
                <span className="text-xs block font-bold">রাতের বেলা (নাইট শিফট)</span>
                <span className="text-[10px] text-gray-300">রাত ৭:০০ - ভোর ৫:৫৯</span>
              </div>
            </button>
          </div>
        </div>

        {/* Distance Selector */}
        <div className="space-y-2 bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#D4C3A3]">
          <div className="flex items-center justify-between text-xs font-bold text-[#2D3A3A]">
            <span>আনুমানিক দূরত্ব:</span>
            <span className="text-[#2D5A27] font-mono text-sm">{distanceKm} কিলোমিটার</span>
          </div>

          <input
            type="range"
            min={1}
            max={35}
            step={1}
            value={distanceKm}
            onChange={(e) => setDistanceKm(Number(e.target.value))}
            className="w-full accent-[#2D5A27] cursor-pointer"
          />

          <div className="flex items-center justify-between gap-1 text-[10px]">
            {[2, 5, 10, 15, 20, 30].map(km => (
              <button
                key={km}
                type="button"
                onClick={() => setDistanceKm(km)}
                className={`px-2 py-0.5 rounded-md border cursor-pointer ${
                  distanceKm === km
                    ? 'bg-[#2D5A27] text-white border-[#2D5A27]'
                    : 'bg-white text-[#736B5E] border-gray-200 hover:bg-gray-50'
                }`}
              >
                {km} কিমি
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="chk-reserve"
              checked={isReserve}
              onChange={(e) => setIsReserve(e.target.checked)}
              className="accent-[#2D5A27] rounded"
            />
            <label htmlFor="chk-reserve" className="text-xs text-[#2D3A3A] font-medium cursor-pointer">
              {t('রিজার্ভ ট্রিপ (একক বা পারিবারিক রিজার্ভের ক্ষেত্রে অতিরিক্ত বেস চার্জ প্রযোজ্য)', 'Reserve Trip (extra base charge for solo/family reserve)')}
            </label>
          </div>
        </div>

        {/* Passenger Count & Luggage Options (User Request) */}
        <div className="space-y-3 bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4]">
          {/* Passenger count */}
          <div>
            <label className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5 mb-1.5">
              <Users className="w-3.5 h-3.5 text-[#2D5A27]" />
              <span>{t('যাত্রী সংখ্যা কতজন?', 'Number of Passengers?')}</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: '1-2', bn: '১-২ জন (স্বাভাবিক)', en: '1-2 Persons' },
                { id: '3-4', bn: '৩-৪ জন (মাঝারি)', en: '3-4 Persons' },
                { id: '5+', bn: '৫+ জন (দলগত/লোড)', en: '5+ Persons' },
              ].map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPassengerCount(p.id as any)}
                  className={`py-1.5 px-2 rounded-xl text-xs font-bold transition border cursor-pointer text-center ${
                    passengerCount === p.id
                      ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-xs'
                      : 'bg-white text-[#5A6B6B] border-[#E6E0D4] hover:border-[#2D5A27]'
                  }`}
                >
                  {t(p.bn, p.en)}
                </button>
              ))}
            </div>
          </div>

          {/* Luggage / Goods Checkbox */}
          <div className="flex items-center gap-2.5 pt-1 border-t border-[#E6E0D4]/70">
            <input
              type="checkbox"
              id="chk-luggage"
              checked={hasLuggage}
              onChange={(e) => setHasLuggage(e.target.checked)}
              className="w-4 h-4 accent-[#2D5A27] rounded cursor-pointer"
            />
            <label htmlFor="chk-luggage" className="text-xs text-[#2D3A3A] font-medium cursor-pointer flex items-center gap-1.5">
              <Package className="w-3.5 h-3.5 text-[#E8924A]" />
              <span>{t('মালামাল / ভারী বস্তা / লাগেজ আছে (+১০-১৫% লোড প্রাক্কলন)', 'Luggage / Cargo / Heavy bags included (+10-15% load est.)')}</span>
            </label>
          </div>
        </div>

        {/* Estimated Fare Result Box */}
        <div className="bg-[#E8F8F5] border-2 border-[#27AE60] p-4 rounded-2xl text-center space-y-1.5 shadow-xs">
          <span className="text-xs font-bold text-[#1E8449] flex items-center justify-center gap-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t('প্রাক্কলিত ন্যায্য ভাড়া পরিসীমা:', 'Estimated Fair Fare Range:')}</span>
          </span>
          <div className="text-2xl sm:text-3xl font-black text-[#2D5A27] font-mono">
            ৳ {minFare} - ৳ {maxFare} {t('টাকা', 'BDT')}
          </div>
          <div className="text-[11px] text-[#5A6B6B] flex items-center justify-center gap-2 font-medium flex-wrap">
            <span>{t('দূরত্ব:', 'Distance:')} {distanceKm} {t('কিমি', 'km')}</span>
            <span>•</span>
            <span>{timeOfDay === 'day' ? t('দিন', 'Day') : t('রাত (নাইট রেট)', 'Night Rate')}</span>
            <span>•</span>
            <span>{isReserve ? t('রিজার্ভ', 'Reserve') : t('শেয়ার', 'Shared')}</span>
            <span>•</span>
            <span>{passengerCount === '1-2' ? t('১-২ যাত্রী', '1-2 pax') : passengerCount === '3-4' ? t('৩-৪ যাত্রী', '3-4 pax') : t('৫+ যাত্রী', '5+ pax')}</span>
            {hasLuggage && (
              <>
                <span>•</span>
                <span className="text-[#E8924A] font-bold">{t('মালামাল সহ', 'With Luggage')}</span>
              </>
            )}
          </div>
        </div>

        {/* Advisory / Negotiable Note */}
        <div className="p-3 bg-[#FAF8F5] border border-[#E6E0D4] rounded-2xl space-y-1 text-[11px] text-[#736B5E]">
          <div className="flex items-center gap-1.5 text-[#2D3A3A] font-bold">
            <Info className="w-3.5 h-3.5 text-[#2D5A27]" />
            <span>{t('ভাড়া আলোচনা সাপেক্ষে (Negotiable):', 'Fare is Negotiable:')}</span>
          </div>
          <p>
            {t(
              'গ্রামীণ কাঁচা বা ভাঙা রাস্তা, ভারী মালামাল এবং আবহাওয়ার অবস্থার ওপর ভিত্তি করে প্রকৃত ভাড়া সামান্য কম-বেশি হতে পারে। চালকের সাথে কথা বলে চূড়ান্ত করুন।',
              'Actual fare may vary slightly based on village dirt/broken roads, heavy luggage, and weather. Please discuss and finalize with the driver.'
            )}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2.5 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-[#736B5E] hover:bg-gray-100 transition cursor-pointer"
          >
            {t('বন্ধ করুন', 'Close')}
          </button>
          {selectedDriver && onSelectDriverToCall && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onSelectDriverToCall(selectedDriver);
              }}
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-sm transition cursor-pointer flex items-center gap-1.5"
            >
              <span>{t('চালকের সাথে যোগাযোগ করুন', 'Contact Driver')}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
