import React, { useState, useEffect } from 'react';
import { 
  Car, 
  MapPin, 
  Calendar, 
  Clock, 
  DollarSign, 
  PlusCircle, 
  PhoneCall, 
  MessageCircle, 
  CheckCircle2, 
  ShieldCheck, 
  Filter, 
  Search, 
  ArrowRight, 
  X, 
  SlidersHorizontal,
  Armchair,
  Sparkles,
  Info,
  ChevronDown
} from 'lucide-react';
import { ReturnTransportRide } from '../../types';
import { UserProfile } from '../../types/auth';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';
import { 
  subscribeToReturnRides, 
  saveCloudReturnRide, 
  broadcastReturnTransportNotification,
  deleteCloudReturnRide
} from '../../lib/cloudSync';
import { INITIAL_RETURN_TRANSPORT_RIDES } from '../../data/extendedData';

interface ReturnTransportSectionProps {
  currentDistrict: string;
  currentUser?: UserProfile | null;
  onOpenAuth?: (action?: string) => void;
  onInitiateCall: (target: {
    name: string;
    role: 'driver' | 'passenger';
    photo?: string;
    subtitle: string;
    rawPhone: string;
  }) => void;
  onOpenChat: (target: {
    id: string;
    name: string;
    role: string;
    phone: string;
    photo?: string;
    subtitle?: string;
  }) => void;
  onShowToast: (message: string) => void;
}

const RETURN_VEHICLE_OPTIONS = [
  'কার',
  'মাইক্রো',
  'সিএনজি',
  'অটোরিকশা',
  'বাইক',
  'পিকআপ',
  'ট্রাক',
  'ট্রলার'
];

const RETURN_CAPACITY_OPTIONS = [
  '১ সিট',
  '২ সিট',
  '৩ সিট',
  '৪ সিট',
  'পুরো গাড়ি'
];

const RETURN_TIME_PRESETS = [
  'সকাল ০৬:০০',
  'সকাল ০৭:০০',
  'সকাল ০৮:০০',
  'সকাল ০৯:০০',
  'সকাল ১০:০০',
  'সকাল ১১:০০',
  'দুপুর ১২:০০',
  'দুপুর ০১:০০',
  'দুপুর ০২:০০',
  'বিকাল ০৩:০০',
  'বিকাল ০৪:০০',
  'বিকাল ০৫:০০',
  'সন্ধ্যা ০৬:০০',
  'সন্ধ্যা ০৭:০০',
  'রাত ০৮:০০',
  'রাত ০৯:০০',
  'রাত ১০:০০',
  'রাত ১১:০০'
];

export const ReturnTransportSection: React.FC<ReturnTransportSectionProps> = ({
  currentDistrict,
  currentUser,
  onOpenAuth,
  onInitiateCall,
  onOpenChat,
  onShowToast
}) => {
  // Rides State
  const [rides, setRides] = useState<ReturnTransportRide[]>(() => {
    const saved = localStorage.getItem('polli_return_rides_list');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_RETURN_TRANSPORT_RIDES;
      }
    }
    return INITIAL_RETURN_TRANSPORT_RIDES;
  });

  // Filter States
  const [subTab, setSubTab] = useState<'all' | 'driver_return' | 'passenger_request'>('all');
  const [selectedVehicleType, setSelectedVehicleType] = useState<string>('সকল যানবাহন');
  const [selectedCapacity, setSelectedCapacity] = useState<string>('সকল সিট');
  const [selectedFareFilter, setSelectedFareFilter] = useState<'সকল ভাড়া' | 'আলোচনা সাপেক্ষে' | 'নির্দিষ্ট ভাড়া'>('সকল ভাড়া');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterAddress, setFilterAddress] = useState<AddressState>({
    district: currentDistrict !== 'সকল জেলা' ? currentDistrict : '',
    upazila: '',
    union: '',
    village: ''
  });

  // Create Modal State
  const [showPostModal, setShowPostModal] = useState<boolean>(false);
  const [postType, setPostType] = useState<'driver_return' | 'passenger_request'>('driver_return');
  
  // Form fields
  const [postVehicleType, setPostVehicleType] = useState<string>('কার');
  const [postCapacity, setPostCapacity] = useState<string>('২ সিট');
  const todayStr = new Date().toISOString().split('T')[0];
  const [postDepartureDate, setPostDepartureDate] = useState<string>(todayStr);
  const [postDepartureTime, setPostDepartureTime] = useState<string>('সকাল ০৯:০০');
  const [postFromDistrict, setPostFromDistrict] = useState<string>(currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা');
  const [postFromLocation, setPostFromLocation] = useState<string>('');
  const [postToDistrict, setPostToDistrict] = useState<string>('টাঙ্গাইল');
  const [postToLocation, setPostToLocation] = useState<string>('');
  const [postFareType, setPostFareType] = useState<'negotiable' | 'fixed'>('fixed');
  const [postFareAmount, setPostFareAmount] = useState<string>('৩৫০');
  const [postDurationHours, setPostDurationHours] = useState<number>(3); // মেয়াদ ঘণ্টা হিসেবে (ডিফল্ট ৩ ঘণ্টা)
  const [postNote, setPostNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Real-time Cloud Sync
  useEffect(() => {
    const unsub = subscribeToReturnRides((updatedRides) => {
      setRides(updatedRides);
    });
    return () => {
      if (unsub) unsub();
    };
  }, []);

  // Open modal with pre-configured role
  const handleOpenCreateModal = (type: 'driver_return' | 'passenger_request') => {
    if (!currentUser) {
      onOpenAuth?.(type === 'driver_return' ? 'চালক হিসেবে ফিরতি গাড়ির পোস্ট দিতে লগইন বা নিবন্ধন করুন' : 'ফিরতি গাড়ি খুঁজতে পোস্ট দিতে লগইন বা নিবন্ধন করুন');
      return;
    }
    setPostType(type);
    setShowPostModal(true);
  };

  // Submit Handler
  const handleSubmitPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth?.();
      return;
    }

    if (!postFromDistrict || !postToDistrict) {
      alert('অনুগ্রহ করে প্রস্থান এবং গন্তব্য জেলা নির্বাচন করুন');
      return;
    }

    if (postFareType === 'fixed' && (!postFareAmount || Number(postFareAmount) <= 0)) {
      alert('নির্দিষ্ট ভাড়ার পরিমাণ লিখুন');
      return;
    }

    setIsSubmitting(true);
    try {
      const now = Date.now();
      const durationHoursVal = Number(postDurationHours) || 3;
      const durationMs = durationHoursVal * 60 * 60 * 1000;
      const expiresAt = now + durationMs;

      const newRide: ReturnTransportRide = {
        id: `ret-${now}`,
        type: postType,
        creatorId: currentUser.id || currentUser.phone || `user-${now}`,
        creatorName: currentUser.name || (postType === 'driver_return' ? 'সম্মানিত চালক' : 'সম্মানিত যাত্রী'),
        creatorPhone: currentUser.phone || '০১৭xxxxxxxx',
        creatorAvatar: currentUser.customAvatarUrl,
        creatorRole: postType === 'driver_return' ? 'driver' : 'citizen',
        vehicleType: postVehicleType,
        capacity: postCapacity,
        fromDistrict: postFromDistrict,
        fromLocation: postFromLocation.trim(),
        toDistrict: postToDistrict,
        toLocation: postToLocation.trim(),
        departureDate: postDepartureDate,
        departureTime: postDepartureTime,
        fareType: postFareType,
        fareAmount: postFareType === 'fixed' ? Number(postFareAmount) : undefined,
        note: postNote.trim(),
        createdAt: now,
        createdAtFormatted: 'এইমাত্র',
        durationHours: durationHoursVal,
        expiresAtTimestamp: expiresAt,
        status: 'active',
        isHidden: false,
        is_hidden: false,
        allowOfflineCall: currentUser.allowOfflineCall ?? true
      };

      await saveCloudReturnRide(newRide);
      await broadcastReturnTransportNotification(newRide);

      setRides(prev => [newRide, ...prev.filter(r => r.id !== newRide.id)]);
      setShowPostModal(false);

      if (postType === 'driver_return') {
        onShowToast(`🎉 খালি ফিরতি গাড়ির পোস্ট প্রকাশিত হয়েছে! ${postFromDistrict} এলাকার সকল সাধারণ যাত্রীদের ফোনে নোটিফিকেশন অ্যালার্ট পাঠানো হয়েছে।`);
      } else {
        onShowToast(`🎉 ফিরতি গাড়ির রিকোয়েস্ট প্রকাশিত হয়েছে! ${postFromDistrict} এলাকার সকল নিবন্ধিত চালকদের কাছে নোটিফিকেশন পৌঁছে দেওয়া হয়েছে।`);
      }

      // Reset
      setPostNote('');
    } catch (err) {
      console.error('Failed to save return ride:', err);
      alert('পোস্ট সংরক্ষণ করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter Logic
  const filteredRides = rides.filter((ride) => {
    // 0. Auto-Hide Expired Rides (নির্দিষ্ট ঘণ্টা পার হওয়ার পর স্বয়ংক্রিয়ভাবে হাইড)
    if (ride.isHidden || ride.is_hidden || ride.status === 'completed' || ride.status === 'cancelled') {
      return false;
    }
    const now = Date.now();
    if (ride.expiresAtTimestamp && now > ride.expiresAtTimestamp) {
      return false;
    }
    if (ride.createdAt) {
      const maxAgeMs = (ride.durationHours || 24) * 60 * 60 * 1000;
      if (now - ride.createdAt > maxAgeMs) {
        return false;
      }
    }

    // 1. SubTab Filter
    if (subTab !== 'all' && ride.type !== subTab) {
      return false;
    }

    // 2. Vehicle Type
    if (selectedVehicleType !== 'সকল যানবাহন') {
      const vq = selectedVehicleType.toLowerCase();
      const rv = (ride.vehicleType || '').toLowerCase();
      if (!rv.includes(vq) && !vq.includes(rv)) {
        return false;
      }
    }

    // 3. Capacity Filter
    if (selectedCapacity !== 'সকল সিট' && ride.capacity !== selectedCapacity) {
      return false;
    }

    // 4. Fare Filter
    if (selectedFareFilter === 'আলোচনা সাপেক্ষে' && ride.fareType !== 'negotiable') {
      return false;
    }
    if (selectedFareFilter === 'নির্দিষ্ট ভাড়া' && ride.fareType !== 'fixed') {
      return false;
    }

    // 5. Route / District Filter
    if (filterAddress.district && filterAddress.district !== 'সকল জেলা') {
      const targetD = filterAddress.district;
      const matchDistrict = ride.fromDistrict === targetD || ride.toDistrict === targetD;
      if (!matchDistrict) return false;
    }

    // 6. Upazila / Location Match
    if (filterAddress.upazila && filterAddress.upazila !== 'সকল উপজেলা') {
      const uq = filterAddress.upazila.toLowerCase();
      const fromU = (ride.fromUpazila || '').toLowerCase();
      const toU = (ride.toUpazila || '').toLowerCase();
      const fromL = (ride.fromLocation || '').toLowerCase();
      const toL = (ride.toLocation || '').toLowerCase();
      if (!fromU.includes(uq) && !toU.includes(uq) && !fromL.includes(uq) && !toL.includes(uq)) {
        return false;
      }
    }

    // 7. Search Query
    if (searchQuery.trim()) {
      const sq = searchQuery.toLowerCase();
      const nameMatch = ride.creatorName.toLowerCase().includes(sq);
      const fromMatch = ride.fromDistrict.toLowerCase().includes(sq) || (ride.fromLocation || '').toLowerCase().includes(sq);
      const toMatch = ride.toDistrict.toLowerCase().includes(sq) || (ride.toLocation || '').toLowerCase().includes(sq);
      const vehicleMatch = ride.vehicleType.toLowerCase().includes(sq);
      const noteMatch = (ride.note || '').toLowerCase().includes(sq);
      if (!nameMatch && !fromMatch && !toMatch && !vehicleMatch && !noteMatch) {
        return false;
      }
    }

    return true;
  });

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* Top Interactive Hero & Rules Banner */}
      <div className="bg-gradient-to-br from-[#1E3A8A] via-[#1D4ED8] to-[#1E40AF] text-white p-5 sm:p-6 rounded-3xl shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-12 -mt-12 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-[#DBEAFE] text-[#1E40AF] font-bold text-xs px-3 py-0.5 rounded-full inline-block">
                🔄 দুই-মুখী (Two-Way) ফিরতি পরিবহন
              </span>
              <span className="bg-[#10B981] text-white font-bold text-[11px] px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                ১০০% গোপন ও সুরক্ষিত কল
              </span>
              <span className="bg-white/20 text-[#DBEAFE] font-semibold text-[11px] px-2.5 py-0.5 rounded-full">
                সাশ্রয়ী ভাড়া ও খালি গাড়ি
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black font-['Noto_Sans_Bengali']">
              কম ভাড়ায় খালি ফিরতি গাড়ি খুঁজুন অথবা খালি গাড়ির পোস্ট দিন
            </h2>
            <p className="text-[#BFDBFE] text-xs sm:text-sm max-w-2xl leading-relaxed">
              এক স্থান থেকে অন্য স্থানে ট্রিপ শেষে খালি গাড়ি নিয়ে ফেরার সময় চালক কম ভাড়ায় যাত্রী নিতে পারেন, অথবা যাত্রী সাশ্রয়ী ভাড়ায় ফিরতি গাড়ি পেতে অগ্রিম পোস্ট দিতে পারেন।
            </p>
          </div>

          {/* Action Post Buttons: Driver vs Passenger */}
          <div className="flex flex-wrap sm:flex-nowrap gap-2.5 self-start lg:self-auto">
            {/* Driver Post Button */}
            <button
              onClick={() => handleOpenCreateModal('driver_return')}
              className="flex items-center gap-2 bg-[#F59E0B] hover:bg-[#D97706] text-white font-extrabold px-4 py-3 rounded-2xl text-xs sm:text-sm shadow-md transition active:scale-98 cursor-pointer"
              title="চালক খালি গাড়ি নিয়ে ফেরার পথে পোস্ট দিতে পারেন"
            >
              <Car className="w-4 h-4" />
              <span>ফিরতি গাড়ি যুক্ত করুন (চালক)</span>
            </button>

            {/* Passenger Post Button */}
            <button
              onClick={() => handleOpenCreateModal('passenger_request')}
              className="flex items-center gap-2 bg-white hover:bg-[#F3F4F6] text-[#1E40AF] font-extrabold px-4 py-3 rounded-2xl text-xs sm:text-sm shadow-md transition active:scale-98 cursor-pointer"
              title="যাত্রী সাশ্রয়ী ভাড়ায় ফিরতি গাড়ি পাওয়ার জন্য পোস্ট দিতে পারেন"
            >
              <PlusCircle className="w-4 h-4 text-[#1D4ED8]" />
              <span>ফিরতি গাড়ি খুঁজুন (যাত্রী)</span>
            </button>
          </div>
        </div>
      </div>

      {/* FCM Routing Policy Transparency Notice */}
      <div className="bg-[#EFF6FF] border border-[#BFDBFE] p-3.5 rounded-2xl flex items-start sm:items-center gap-3 text-xs text-[#1E3A8A]">
        <Info className="w-4 h-4 text-[#2563EB] flex-shrink-0 mt-0.5 sm:mt-0" />
        <div className="space-y-0.5 leading-relaxed">
          <span><strong>এফসিএম অটো-নোটিফিকেশন নিয়ম:</strong></span>
          <span className="block sm:inline sm:ml-1">
            চালকের ফিরতি গাড়ির পোস্টের নোটিফিকেশন যায় এলাকার <strong>সকল সাধারণ যাত্রীর ফোনে</strong>; আর যাত্রীর রিকোয়েস্টের অ্যালার্ট যায় শুধুমাত্র ওই এলাকার <strong>নিবন্ধিত চালকদের ফোনে</strong>।
          </span>
        </div>
      </div>

      {/* SubTab Switcher: All vs Driver Return vs Passenger Request */}
      <div className="flex items-center justify-center">
        <div className="bg-white p-1.5 rounded-3xl border border-[#E6E0D4] shadow-xs flex items-center gap-1">
          <button
            onClick={() => setSubTab('all')}
            className={`px-4 sm:px-5 py-2 rounded-2xl font-bold text-xs sm:text-sm transition cursor-pointer ${
              subTab === 'all'
                ? 'bg-[#1D4ED8] text-white shadow-xs'
                : 'text-[#5A6B6B] hover:text-black'
            }`}
          >
            সকল ফিরতি ট্রিপ ({rides.length})
          </button>
          
          <button
            onClick={() => setSubTab('driver_return')}
            className={`flex items-center gap-1.5 px-4 sm:px-5 py-2 rounded-2xl font-bold text-xs sm:text-sm transition cursor-pointer ${
              subTab === 'driver_return'
                ? 'bg-[#1D4ED8] text-white shadow-xs'
                : 'text-[#5A6B6B] hover:text-black'
            }`}
          >
            <Car className="w-3.5 h-3.5" />
            <span>চালকদের খালি গাড়ি ({rides.filter(r => r.type === 'driver_return').length})</span>
          </button>

          <button
            onClick={() => setSubTab('passenger_request')}
            className={`flex items-center gap-1.5 px-4 sm:px-5 py-2 rounded-2xl font-bold text-xs sm:text-sm transition cursor-pointer ${
              subTab === 'passenger_request'
                ? 'bg-[#1D4ED8] text-white shadow-xs'
                : 'text-[#5A6B6B] hover:text-black'
            }`}
          >
            <Armchair className="w-3.5 h-3.5" />
            <span>যাত্রীদের রিকোয়েস্ট ({rides.filter(r => r.type === 'passenger_request').length})</span>
          </button>
        </div>
      </div>

      {/* Filters: Easy Dropdowns & Pickers */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-[#E6E0D4] space-y-4 shadow-2xs">
        
        {/* Step 1: Vehicle Category Badges */}
        <div>
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-xs font-bold text-[#1E3A8A] flex items-center gap-1.5">
              <Car className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>যানবাহনের ধরন:</span>
            </span>
            <span className="text-[11px] font-semibold text-[#1E40AF] bg-[#DBEAFE] px-2 py-0.5 rounded-full">
              {selectedVehicleType}
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            {['সকল যানবাহন', ...RETURN_VEHICLE_OPTIONS].map((vType) => {
              const isSelected = selectedVehicleType === vType;
              return (
                <button
                  key={vType}
                  type="button"
                  onClick={() => setSelectedVehicleType(vType)}
                  className={`px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                    isSelected
                      ? 'bg-[#1D4ED8] text-white shadow-xs'
                      : 'bg-[#F8FAFC] text-[#334155] border border-[#E2E8F0] hover:bg-[#F1F5F9]'
                  }`}
                >
                  <span>
                    {vType === 'সকল যানবাহন' && '🚗'}
                    {vType === 'কার' && '🚘'}
                    {vType === 'মাইক্রো' && '🚐'}
                    {vType === 'সিএনজি' && '🛺'}
                    {vType === 'অটোরিকশা' && '🛺'}
                    {vType === 'বাইক' && '🏍️'}
                    {vType === 'পিকআপ' && '🛻'}
                    {vType === 'ট্রাক' && '🚚'}
                    {vType === 'ট্রলার' && '🚤'}
                  </span>
                  <span>{vType}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 2: Capacity & Fare Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-1">
          {/* Capacity Dropdown */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-[#475569] flex items-center gap-1">
              <Armchair className="w-3 h-3 text-[#2563EB]" />
              <span>সিটের সংখ্যা / ক্যাপাসিটি:</span>
            </label>
            <select
              value={selectedCapacity}
              onChange={(e) => setSelectedCapacity(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#1E293B] focus:outline-hidden focus:border-[#2563EB]"
            >
              <option value="সকল সিট">সকল সিট</option>
              {RETURN_CAPACITY_OPTIONS.map((cap) => (
                <option key={cap} value={cap}>{cap}</option>
              ))}
            </select>
          </div>

          {/* Fare Filter */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-[#475569] flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-[#2563EB]" />
              <span>ভাড়ার ধরন:</span>
            </label>
            <select
              value={selectedFareFilter}
              onChange={(e) => setSelectedFareFilter(e.target.value as any)}
              className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#1E293B] focus:outline-hidden focus:border-[#2563EB]"
            >
              <option value="সকল ভাড়া">সকল ভাড়া</option>
              <option value="নির্দিষ্ট ভাড়া">নির্দিষ্ট পরিমাণ ভাড়া</option>
              <option value="আলোচনা সাপেক্ষে">ভাড়া আলোচনা সাপেক্ষে</option>
            </select>
          </div>

          {/* Search Box */}
          <div className="space-y-1 sm:col-span-2 md:col-span-1">
            <label className="text-[11px] font-bold text-[#475569] flex items-center gap-1">
              <Search className="w-3 h-3 text-[#2563EB]" />
              <span>রুট / স্থান খুঁজুন:</span>
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="যেমন: ঢাকা, ঘাটাইল, সাভার..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl pl-8 pr-3 py-2 text-xs font-semibold text-[#1E293B] focus:outline-hidden focus:border-[#2563EB]"
              />
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>
        </div>

        {/* Cascading Address Selector for Area Filtering */}
        <div className="pt-2 border-t border-[#F1F5F9]">
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-xs font-bold text-[#1E3A8A] flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>এলাকা / জেলা ফিল্টারিং (স্বয়ংক্রিয় উপজেলাসহ):</span>
            </span>
            {(filterAddress.district || filterAddress.upazila) && (
              <button
                type="button"
                onClick={() => setFilterAddress({ district: '', upazila: '', union: '', village: '' })}
                className="text-[11px] text-[#DC2626] hover:underline font-semibold"
              >
                রিসেট করুন
              </button>
            )}
          </div>
          <CascadingAddressSelector
            address={filterAddress}
            onChange={setFilterAddress}
            allowAllOption={true}
            allDistrictLabel="সকল জেলা"
            showVillage={false}
            layout="row"
          />
        </div>
      </div>

      {/* Return Rides Listings Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-[#475569] px-1">
          <span>মোট পাওয়া গেছে: {filteredRides.length}টি ফিরতি ট্রিপ</span>
          <span className="text-[#2563EB]">সর্বশেষ আপডেটেড</span>
        </div>

        {filteredRides.length === 0 ? (
          <div className="bg-white p-10 rounded-3xl border border-[#E6E0D4] text-center space-y-3">
            <div className="w-14 h-14 mx-auto rounded-full bg-[#EFF6FF] text-[#2563EB] flex items-center justify-center text-2xl">
              🚗
            </div>
            <h3 className="font-bold text-base text-[#1E293B]">কোনো ফিরতি ট্রিপ পাওয়া যায়নি</h3>
            <p className="text-xs text-[#64748B] max-w-md mx-auto leading-relaxed">
              আপনার নির্বাচিত ফিল্টারে কোনো খালি ফিরতি গাড়ি বা রিকোয়েস্ট নেই। আপনি নতুন একটি পোস্ট দিতে পারেন!
            </p>
            <div className="pt-2 flex justify-center gap-2">
              <button
                onClick={() => handleOpenCreateModal('driver_return')}
                className="bg-[#1D4ED8] text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-[#1E40AF] cursor-pointer"
              >
                ফিরতি গাড়ি যোগ করুন
              </button>
              <button
                onClick={() => handleOpenCreateModal('passenger_request')}
                className="bg-[#F1F5F9] text-[#1E3A8A] border border-[#CBD5E1] text-xs font-bold px-4 py-2 rounded-xl hover:bg-[#E2E8F0] cursor-pointer"
              >
                ফিরতি গাড়ি খুঁজুন
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredRides.map((ride) => {
              const isDriverPost = ride.type === 'driver_return';

              return (
                <div
                  key={ride.id}
                  className={`bg-white rounded-3xl border-2 p-5 space-y-4 shadow-sm hover:shadow-md transition-all relative overflow-hidden ${
                    isDriverPost ? 'border-[#BFDBFE]' : 'border-[#DDD6FE]'
                  }`}
                >
                  {/* Top Header Badge */}
                  <div className="flex items-center justify-between gap-2">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold shadow-2xs ${
                      isDriverPost 
                        ? 'bg-[#DBEAFE] text-[#1E40AF] border border-[#93C5FD]' 
                        : 'bg-[#EDE9FE] text-[#5B21B6] border border-[#C4B5FD]'
                    }`}>
                      {isDriverPost ? '🚗 চালকের খালি ফিরতি গাড়ি' : '🙋‍♂️ যাত্রীর ফিরতি গাড়ি রিকোয়েস্ট'}
                    </span>

                    <span className="text-[11px] font-semibold text-gray-500">
                      {ride.createdAtFormatted}
                    </span>
                  </div>

                  {/* Route Visualizer: From ➔ To */}
                  <div className="bg-[#F8FAFC] p-3.5 rounded-2xl border border-[#E2E8F0] space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      {/* From */}
                      <div className="flex-1 space-y-0.5">
                        <span className="text-[10px] font-extrabold uppercase text-[#64748B] flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-[#10B981]" />
                          <span>কোথা থেকে (প্রস্থান)</span>
                        </span>
                        <div className="font-extrabold text-sm sm:text-base text-[#0F172A]">
                          {ride.fromLocation ? `${ride.fromLocation}, ` : ''}{ride.fromDistrict}
                        </div>
                      </div>

                      {/* Direction Arrow */}
                      <div className="w-8 h-8 rounded-full bg-white border border-[#CBD5E1] flex items-center justify-center text-[#2563EB] shadow-2xs flex-shrink-0">
                        <ArrowRight className="w-4 h-4" />
                      </div>

                      {/* To */}
                      <div className="flex-1 space-y-0.5 text-right">
                        <span className="text-[10px] font-extrabold uppercase text-[#64748B] flex items-center justify-end gap-1">
                          <MapPin className="w-3 h-3 text-[#EF4444]" />
                          <span>কোথায় (গন্তব্য)</span>
                        </span>
                        <div className="font-extrabold text-sm sm:text-base text-[#0F172A]">
                          {ride.toLocation ? `${ride.toLocation}, ` : ''}{ride.toDistrict}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Trip Parameters Badges */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                    {/* Vehicle */}
                    <div className="bg-[#F1F5F9] p-2 rounded-xl flex items-center gap-1.5 font-bold text-[#334155]">
                      <Car className="w-3.5 h-3.5 text-[#2563EB]" />
                      <span>{ride.vehicleType}</span>
                    </div>

                    {/* Capacity */}
                    <div className="bg-[#F1F5F9] p-2 rounded-xl flex items-center gap-1.5 font-bold text-[#334155]">
                      <Armchair className="w-3.5 h-3.5 text-[#2563EB]" />
                      <span>{ride.capacity}</span>
                    </div>

                    {/* Date & Time */}
                    <div className="bg-[#F1F5F9] p-2 rounded-xl flex items-center gap-1.5 font-bold text-[#334155] col-span-2 sm:col-span-1">
                      <Clock className="w-3.5 h-3.5 text-[#2563EB]" />
                      <span>{ride.departureDate} ({ride.departureTime})</span>
                    </div>
                  </div>

                  {/* Fare Display */}
                  <div className="flex items-center justify-between bg-[#F8FAFC] px-3.5 py-2.5 rounded-2xl border border-[#E2E8F0]">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#475569]">
                      <DollarSign className="w-4 h-4 text-[#10B981]" />
                      <span>ভাড়া নির্ধারণ:</span>
                    </div>
                    {ride.fareType === 'fixed' && ride.fareAmount ? (
                      <span className="text-sm font-black text-[#10B981] bg-[#ECFDF5] px-3 py-1 rounded-xl border border-[#A7F3D0]">
                        ৳{ride.fareAmount} (নির্দিষ্ট)
                      </span>
                    ) : (
                      <span className="text-xs font-bold text-[#D97706] bg-[#FEF3C7] px-3 py-1 rounded-xl border border-[#FDE68A]">
                        আলোচনা সাপেক্ষে
                      </span>
                    )}
                  </div>

                  {/* Optional Note if present */}
                  {ride.note && (
                    <div className="text-xs bg-[#FAF5FF] border border-[#E9D5FF] text-[#581C87] p-2.5 rounded-xl leading-relaxed">
                      <strong>নোট:</strong> {ride.note}
                    </div>
                  )}

                  {/* Creator Info & Privacy-Safe Contact Actions */}
                  <div className="pt-2 border-t border-[#F1F5F9] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-full bg-[#1E3A8A] text-white flex items-center justify-center font-bold text-xs shadow-xs">
                        {ride.creatorAvatar ? (
                          <img src={ride.creatorAvatar} alt="" className="w-full h-full rounded-full object-cover" />
                        ) : (
                          ride.creatorName.charAt(0)
                        )}
                      </div>
                      <div className="space-y-0.5">
                        <div className="text-xs font-bold text-[#0F172A]">{ride.creatorName}</div>
                        <div className="text-[10px] text-[#64748B] flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3 text-[#10B981]" />
                          <span>মোবাইল নম্বর ১০০% সুরক্ষিত ও গোপন</span>
                        </div>
                      </div>
                    </div>

                    {/* Communication Buttons */}
                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <button
                        onClick={() => {
                          onInitiateCall({
                            name: ride.creatorName,
                            role: ride.type === 'driver_return' ? 'driver' : 'passenger',
                            photo: ride.creatorAvatar,
                            subtitle: `ফিরতি ট্রিপ: ${ride.fromDistrict} ➔ ${ride.toDistrict} (${ride.vehicleType})`,
                            rawPhone: ride.creatorPhone
                          });
                        }}
                        className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-[#10B981] hover:bg-[#059669] text-white text-xs font-extrabold px-3.5 py-2 rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
                        title="ইন্টারনেট ভয়েস কল (১০০% নম্বর গোপন)"
                      >
                        <PhoneCall className="w-3.5 h-3.5" />
                        <span>ইন-অ্যাপ কল</span>
                      </button>

                      <button
                        onClick={() => {
                          onOpenChat({
                            id: ride.creatorId,
                            name: ride.creatorName,
                            role: ride.type === 'driver_return' ? 'driver' : 'citizen',
                            phone: ride.creatorPhone,
                            photo: ride.creatorAvatar,
                            subtitle: `ফিরতি ট্রিপ: ${ride.fromDistrict} ➔ ${ride.toDistrict}`
                          });
                        }}
                        className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-[#F1F5F9] hover:bg-[#E2E8F0] text-[#1E293B] text-xs font-extrabold px-3.5 py-2 rounded-xl border border-[#CBD5E1] transition active:scale-95 cursor-pointer"
                        title="ইন-অ্যাপ মেসেজ পাঠান"
                      >
                        <MessageCircle className="w-3.5 h-3.5 text-[#2563EB]" />
                        <span>মেসেজ</span>
                      </button>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* CREATE MODAL: Two-Way Return Ride Submission Form */}
      {showPostModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-5 sm:p-6 space-y-5 border border-[#CBD5E1] shadow-2xl relative my-6">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#F1F5F9]">
              <div>
                <h3 className="font-extrabold text-lg sm:text-xl text-[#0F172A]">
                  {postType === 'driver_return' ? '🚗 খালি ফিরতি গাড়ি যুক্ত করুন' : '🙋‍♂️ ফিরতি গাড়ির যাত্রী রিকোয়েস্ট'}
                </h3>
                <p className="text-xs text-[#64748B]">
                  টাইপিংয়ের ঝামেলা ছাড়া সহজ ড্রপডাউনে দ্রুত তথ্য নির্বাচন করুন
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowPostModal(false)}
                className="w-9 h-9 rounded-full bg-[#F1F5F9] hover:bg-[#E2E8F0] flex items-center justify-center text-gray-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Switcher in modal */}
            <div className="grid grid-cols-2 gap-2 bg-[#F8FAFC] p-1.5 rounded-2xl border border-[#E2E8F0]">
              <button
                type="button"
                onClick={() => setPostType('driver_return')}
                className={`py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  postType === 'driver_return'
                    ? 'bg-[#1D4ED8] text-white shadow-xs'
                    : 'text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                <Car className="w-3.5 h-3.5" />
                <span>আমি চালক (খালি গাড়ি)</span>
              </button>

              <button
                type="button"
                onClick={() => setPostType('passenger_request')}
                className={`py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  postType === 'passenger_request'
                    ? 'bg-[#1D4ED8] text-white shadow-xs'
                    : 'text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                <Armchair className="w-3.5 h-3.5" />
                <span>আমি যাত্রী (গাড়ি চাই)</span>
              </button>
            </div>

            <form onSubmit={handleSubmitPost} className="space-y-4">
              
              {/* 1. Vehicle Type & Capacity */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#334155] flex items-center gap-1">
                    <Car className="w-3.5 h-3.5 text-[#2563EB]" />
                    <span>গাড়ির ধরন (Dropdown) *</span>
                  </label>
                  <select
                    value={postVehicleType}
                    onChange={(e) => setPostVehicleType(e.target.value)}
                    className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl px-3 py-2.5 text-xs font-bold text-[#0F172A] focus:outline-hidden focus:border-[#2563EB]"
                    required
                  >
                    {RETURN_VEHICLE_OPTIONS.map((v) => (
                      <option key={v} value={v}>{v}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#334155] flex items-center gap-1">
                    <Armchair className="w-3.5 h-3.5 text-[#2563EB]" />
                    <span>সিটের সংখ্যা / ক্যাপাসিটি (Dropdown) *</span>
                  </label>
                  <select
                    value={postCapacity}
                    onChange={(e) => setPostCapacity(e.target.value)}
                    className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl px-3 py-2.5 text-xs font-bold text-[#0F172A] focus:outline-hidden focus:border-[#2563EB]"
                    required
                  >
                    {RETURN_CAPACITY_OPTIONS.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* 2. Departure Date & Time */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#334155] flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-[#2563EB]" />
                    <span>যাত্রার তারিখ (Calendar Picker) *</span>
                  </label>
                  <input
                    type="date"
                    min={todayStr}
                    value={postDepartureDate}
                    onChange={(e) => setPostDepartureDate(e.target.value)}
                    className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl px-3 py-2.5 text-xs font-bold text-[#0F172A] focus:outline-hidden focus:border-[#2563EB]"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#334155] flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#2563EB]" />
                    <span>যাত্রার সময় (Time Picker) *</span>
                  </label>
                  <select
                    value={postDepartureTime}
                    onChange={(e) => setPostDepartureTime(e.target.value)}
                    className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl px-3 py-2.5 text-xs font-bold text-[#0F172A] focus:outline-hidden focus:border-[#2563EB]"
                    required
                  >
                    {RETURN_TIME_PRESETS.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Dynamic Post Duration in Hours (ঘণ্টা ভিত্তিক মেয়াদ) */}
              <div className="space-y-1 bg-[#F8FAFC] p-3 rounded-2xl border border-[#E2E8F0]">
                <label className="text-xs font-bold text-[#334155] flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#2563EB]" />
                    <span>পোস্টের মেয়াদ (ঘণ্টা) *</span>
                  </span>
                  <span className="text-[10px] font-bold text-[#1D4ED8] bg-blue-100/70 px-2 py-0.5 rounded-md">
                    নির্দিষ্ট ঘণ্টা পর স্বয়ংক্রিয় হাইড
                  </span>
                </label>
                <select
                  value={postDurationHours}
                  onChange={(e) => setPostDurationHours(Number(e.target.value))}
                  className="w-full bg-white border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0F172A] focus:outline-hidden focus:border-[#2563EB]"
                >
                  <option value={2}>২ ঘণ্টা (খুব দ্রুত বা জরুরি রাইড)</option>
                  <option value={3}>৩ ঘণ্টা (সুপারিশকৃত আদর্শ মেয়াদ)</option>
                  <option value={5}>৫ ঘণ্টা</option>
                  <option value={8}>৮ ঘণ্টা</option>
                  <option value={12}>১২ ঘণ্টা (অর্ধেক দিন)</option>
                  <option value={24}>২৪ ঘণ্টা (১ দিন)</option>
                </select>
                <p className="text-[10px] text-gray-500 pt-0.5">
                  নির্ধারিত ঘণ্টা পার হওয়ার পর পোস্ট ও নোটিফিকেশন উভয়ই স্বয়ংক্রিয়ভাবে মুছে যাবে।
                </p>
              </div>

              {/* 3. Route: From and To */}
              <div className="bg-[#F8FAFC] p-3.5 rounded-2xl border border-[#E2E8F0] space-y-3">
                <span className="text-xs font-extrabold text-[#1E3A8A] block">
                  📍 যাত্রা পথ (রুট নির্বাচন)
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* From */}
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-[#475569]">
                      কোথা থেকে (প্রস্থান জেলা ও স্ট্যান্ড) *
                    </label>
                    <select
                      value={postFromDistrict}
                      onChange={(e) => setPostFromDistrict(e.target.value)}
                      className="w-full bg-white border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0F172A]"
                      required
                    >
                      {BANGLADESH_DISTRICTS.map((d) => (
                        <option key={d} value={d}>{d}</option>
                      ))}
                    </select>
                    <input
                      type="text"
                      placeholder="নির্দিষ্ট স্ট্যান্ড বা স্থান (যেমন: গাবতলী টার্মিনাল)"
                      value={postFromLocation}
                      onChange={(e) => setPostFromLocation(e.target.value)}
                      className="w-full bg-white border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-medium text-[#0F172A]"
                    />
                  </div>

                  {/* To */}
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-[#475569]">
                      কোথায় (গন্তব্য জেলা ও স্থান) *
                    </label>
                    <select
                      value={postToDistrict}
                      onChange={(e) => setPostToDistrict(e.target.value)}
                      className="w-full bg-white border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0F172A]"
                      required
                    >
                      {BANGLADESH_DISTRICTS.map((d) => (
                        <option key={d} value={d}>{d}</option>
                      ))}
                    </select>
                    <input
                      type="text"
                      placeholder="নির্দিষ্ট গন্তব্য স্থান (যেমন: ঘাটাইল বাজার)"
                      value={postToLocation}
                      onChange={(e) => setPostToLocation(e.target.value)}
                      className="w-full bg-white border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-medium text-[#0F172A]"
                    />
                  </div>
                </div>
              </div>

              {/* 4. Fare Options */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-[#334155] flex items-center gap-1">
                  <DollarSign className="w-3.5 h-3.5 text-[#2563EB]" />
                  <span>ভাড়া নির্ধারণ *</span>
                </label>

                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-[#334155]">
                    <input
                      type="radio"
                      name="postFareType"
                      checked={postFareType === 'fixed'}
                      onChange={() => setPostFareType('fixed')}
                      className="w-4 h-4 text-[#1D4ED8]"
                    />
                    <span>নির্দিষ্ট পরিমাণ</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-[#334155]">
                    <input
                      type="radio"
                      name="postFareType"
                      checked={postFareType === 'negotiable'}
                      onChange={() => setPostFareType('negotiable')}
                      className="w-4 h-4 text-[#1D4ED8]"
                    />
                    <span>আলোচনা সাপেক্ষে</span>
                  </label>
                </div>

                {postFareType === 'fixed' && (
                  <div className="pt-1">
                    <div className="relative">
                      <input
                        type="number"
                        placeholder="ভাড়ার পরিমাণ লিখুন (যেমন: ৩৫০)"
                        value={postFareAmount}
                        onChange={(e) => setPostFareAmount(e.target.value)}
                        className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl pl-9 pr-3 py-2.5 text-xs font-bold text-[#0F172A] focus:outline-hidden focus:border-[#2563EB]"
                        required={postFareType === 'fixed'}
                        min={10}
                      />
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-gray-500 text-xs">৳</span>
                    </div>
                  </div>
                )}
              </div>

              {/* 5. Optional Note */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#334155]">
                  বিশেষ নোট (অতিরিক্ত তথ্যের জন্য ছোট অপশনাল বক্স):
                </label>
                <textarea
                  rows={2}
                  placeholder="যেমন: এসি চালু থাকবে, ছোট লাগেজ নেওয়া যাবে, পরিবার সহ ভ্রমণ উপযোগী ইত্যাদি..."
                  value={postNote}
                  onChange={(e) => setPostNote(e.target.value)}
                  className="w-full bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-medium text-[#0F172A] focus:outline-hidden focus:border-[#2563EB]"
                />
              </div>

              {/* Routing Notice */}
              <div className="bg-[#F0FDF4] border border-[#BBF7D0] p-3 rounded-xl text-[11px] text-[#166534] leading-relaxed">
                🔔 <strong>নোটিফিকেশন নিশ্চয়তা:</strong>{' '}
                {postType === 'driver_return'
                  ? 'এই পোস্ট করার সাথে সাথে প্রস্থান এলাকার সকল সাধারণ যাত্রীদের ফোনে এফসিএম পুশ নোটিফিকেশন পৌঁছে যাবে।'
                  : 'এই রিকোয়েস্ট করার সাথে সাথে প্রস্থান এলাকার সংশ্লিষ্ট বাহনের সকল নিবন্ধিত চালকদের ফোনে নোটিফিকেশন পৌঁছে যাবে।'}
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-[#F1F5F9]">
                <button
                  type="button"
                  onClick={() => setShowPostModal(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-[#1D4ED8] hover:bg-[#1E40AF] disabled:opacity-50 text-white text-xs font-extrabold px-6 py-2.5 rounded-xl shadow-md transition cursor-pointer"
                >
                  {isSubmitting ? 'প্রকাশিত হচ্ছে...' : 'বিজ্ঞাপন পোস্ট করুন'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
