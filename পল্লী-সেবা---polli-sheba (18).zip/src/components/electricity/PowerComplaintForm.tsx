import React, { useState } from 'react';
import { 
  AlertOctagon, 
  Send, 
  Search, 
  CheckCircle2, 
  Truck, 
  Printer, 
  ShieldCheck
} from 'lucide-react';
import { ElectricityComplaint } from '../../types';
import { ALL_PALLI_BIDYUT_SAMITIES, PalliBidyutSamity } from '../../data/palliBidyutSamityData';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';

const DEFAULT_COMPLAINTS: ElectricityComplaint[] = [
  {
    id: 'cmp-1',
    trackingId: 'BREB-2026-8841',
    customerName: 'মোঃ রফিকুল ইসলাম',
    phone: '01712-334455',
    accountNumber: '102/4589',
    pbsName: 'বগুড়া পল্লী বিদ্যুৎ সমিতি-১',
    complainType: 'ট্রান্সফরমার বিকল',
    village: 'চক সূত্রাপুর, শিবগঞ্জ',
    description: 'বজ্রপাতের পর থেকে ট্রান্সফরমার ব্লাস্ট হয়ে পুরো পাড়ায় গত রাত থেকে বিদ্যুৎ নেই।',
    status: 'কারিগরি দল প্রেরিত',
    submittedAt: 'আজ সকাল ৭:৩০',
    estimatedResolution: 'আজ দুপুর ২:০০ এর মধ্যে'
  }
];

export const PowerComplaintForm: React.FC = () => {
  const [complaints, setComplaints] = useState<ElectricityComplaint[]>(() => {
    const saved = localStorage.getItem('polli_electricity_complaints');
    return saved ? JSON.parse(saved) : DEFAULT_COMPLAINTS;
  });

  // Form inputs
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [pbsName, setPbsName] = useState('ঢাকা পল্লী বিদ্যুৎ সমিতি-১');
  const [complainType, setComplainType] = useState<ElectricityComplaint['complainType']>('বিদ্যুৎ বিভ্রাট/লোডশেডিং');
  const [village, setVillage] = useState('');
  const [description, setDescription] = useState('');

  // Active / Submitted complaint
  const [activeComplaint, setActiveComplaint] = useState<ElectricityComplaint | null>(complaints[0]);
  const [searchTrackingId, setSearchTrackingId] = useState('');
  const [searchError, setSearchError] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const handleSubmitComplaint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !phone || !village || !description) return;

    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const trackingId = `BREB-2026-${randomNum}`;

    const newComplaint: ElectricityComplaint = {
      id: `cmp-${Date.now()}`,
      trackingId,
      customerName,
      phone,
      accountNumber: accountNumber || 'N/A',
      pbsName,
      complainType,
      village,
      description,
      status: 'গৃহীত হয়েছে',
      submittedAt: 'এইমাত্র',
      estimatedResolution: '৪ থেকে ৬ ঘণ্টার মধ্যে'
    };

    const updated = [newComplaint, ...complaints];
    setComplaints(updated);
    localStorage.setItem('polli_electricity_complaints', JSON.stringify(updated));
    setActiveComplaint(newComplaint);
    setSuccessToast(`অভিযোগ সফলভাবে গৃহীত হয়েছে! আপনার ট্র্যাকিং আইডি: ${trackingId}`);
    
    // Clear form
    setCustomerName('');
    setPhone('');
    setAccountNumber('');
    setVillage('');
    setDescription('');
  };

  const handleSearchTracking = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchError(null);
    const found = complaints.find(c => c.trackingId.toLowerCase() === searchTrackingId.trim().toLowerCase());
    if (found) {
      setActiveComplaint(found);
    } else {
      setSearchError('প্রদত্ত ট্র্যাকিং আইডির কোনো অভিযোগ পাওয়া যায়নি।');
    }
  };

  const [selectedDistrict, setSelectedDistrict] = useState<string>('সকল জেলা');
  const [pbsFilterQuery, setPbsFilterQuery] = useState<string>('');
  
  const filteredPbsList = ALL_PALLI_BIDYUT_SAMITIES.filter(pbs => {
    const matchDistrict = selectedDistrict === 'সকল জেলা' || pbs.district === selectedDistrict;
    const matchQuery = !pbsFilterQuery || pbs.name.toLowerCase().includes(pbsFilterQuery.toLowerCase()) || pbs.district.toLowerCase().includes(pbsFilterQuery.toLowerCase()) || pbs.headquarters.toLowerCase().includes(pbsFilterQuery.toLowerCase());
    return matchDistrict && matchQuery;
  });

  const selectedPbsInfo = ALL_PALLI_BIDYUT_SAMITIES.find(p => p.name === pbsName) || ALL_PALLI_BIDYUT_SAMITIES[0];

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
            ⚡ পল্লী বিদ্যুৎ কেন্দ্রীয় অভিযোগ সেল
          </span>
          <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
            বিদ্যুৎ বিভ্রাট ও ট্রান্সফরমার সমস্যা অভিযোগ দাখিল
          </h2>
          <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
            ঘরে বসেই অনলাইনে অভিযোগ জানান এবং অভিযোগের বর্তমান অগ্রগতি ট্র্যাক করুন
          </p>
        </div>

        <div className="bg-[#23491E] border border-[#3D7A35] p-3.5 rounded-2xl text-xs text-[#D4E4BC]">
          <p className="font-bold text-[#F9E5D4]">জরুরি কেন্দ্রীয় অভিযোগ হটলাইন</p>
          <p className="text-xl font-bold text-white mt-0.5 font-['Noto_Sans_Bengali']">১৬৯৯৯</p>
        </div>
      </div>

      {successToast && (
        <div className="p-4 bg-[#D4E4BC] border border-[#2D5A27]/30 text-[#2D5A27] rounded-2xl text-xs sm:text-sm flex items-center justify-between font-semibold shadow-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-[#2D5A27] flex-shrink-0" />
            <span>{successToast}</span>
          </div>
          <button
            onClick={() => setSuccessToast(null)}
            className="text-[#2D5A27] hover:text-[#23491E] text-base font-bold ml-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Track Existing Complaint Bar */}
      <div className="bg-white border border-[#E6E0D4] rounded-3xl p-5 shadow-xs">
        <form onSubmit={handleSearchTracking} className="flex flex-col sm:flex-row gap-3 items-center">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-bold text-[#2D3A3A] whitespace-nowrap">
            <Search className="w-4 h-4 text-[#A65E2E]" />
            <span>পূর্বের অভিযোগ ট্র্যাক করুন:</span>
          </div>
          <input
            type="text"
            placeholder="ট্র্যাকিং আইডি লিখুন (যেমন: BREB-2026-8841)"
            value={searchTrackingId}
            onChange={(e) => setSearchTrackingId(e.target.value)}
            className="w-full sm:flex-1 border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-4 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-medium text-[#2D3A3A]"
          />
          <button
            type="submit"
            className="w-full sm:w-auto bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold px-6 py-2.5 rounded-2xl text-xs sm:text-sm transition cursor-pointer shadow-xs"
          >
            খুঁজুন
          </button>
        </form>

        {searchError && (
          <p className="text-xs text-[#C0392B] font-medium mt-2">{searchError}</p>
        )}
      </div>

      {/* Grid: Complaint Form + Tracking Status */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Form */}
        <div className="lg:col-span-7 bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-[#E6E0D4] pb-3">
            <AlertOctagon className="w-5 h-5 text-[#A65E2E]" />
            <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
              নতুন অভিযোগ ফর্ম পূরণ করুন
            </h3>
          </div>

          <form onSubmit={handleSubmitComplaint} className="space-y-3.5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  গ্রাহক / আবেদনকারীর নাম *
                </label>
                <input
                  type="text"
                  required
                  placeholder="আপনার নাম লিখুন"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  মোবাইল নম্বর *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="০১৭xxxxxxxx"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>
            </div>

            {/* PBS Selector with District Filter */}
            <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] space-y-3">
              <div className="flex flex-col sm:flex-row gap-2 sm:items-center justify-between">
                <label className="block text-xs font-bold text-[#2D3A3A]">
                  পল্লী বিদ্যুৎ সমিতি (PBS) নির্বাচন করুন <span className="text-red-500">*</span>
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-[#736B5E]">জেলা ফিল্টার:</span>
                  <select
                    value={selectedDistrict}
                    onChange={(e) => {
                      const dist = e.target.value;
                      setSelectedDistrict(dist);
                      const matching = ALL_PALLI_BIDYUT_SAMITIES.filter(p => dist === 'সকল জেলা' || p.district === dist);
                      if (matching.length > 0) {
                        setPbsName(matching[0].name);
                      }
                    }}
                    className="bg-white border border-[#D4C3A3] text-xs font-semibold rounded-xl px-2.5 py-1 text-[#2D3A3A] focus:outline-none"
                  >
                    <option value="সকল জেলা">সকল জেলা (৮০টি সমিতি)</option>
                    {BANGLADESH_DISTRICTS.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <select
                    value={pbsName}
                    onChange={(e) => setPbsName(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-white rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm font-semibold text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  >
                    {filteredPbsList.map((pbs) => (
                      <option key={pbs.id} value={pbs.name}>
                        {pbs.name} ({pbs.district})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <input
                    type="text"
                    placeholder="হিসাব নম্বর / মিটার নম্বর (যেমন: 102/4589)"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-white rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              {/* Selected PBS Office Contact Info snippet */}
              {selectedPbsInfo && (
                <div className="bg-[#EBF3E8] border border-[#2D5A27]/20 rounded-xl p-2.5 text-xs text-[#2D3A3A] flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#2D5A27]">📍 সদর দফতর:</span>
                    <span>{selectedPbsInfo.headquarters} ({selectedPbsInfo.district})</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div>
                      <span className="font-bold text-[#2D5A27]">📞 হটলাইন: </span>
                      <a href={`tel:${selectedPbsInfo.hotline.replace(/[^0-9]/g, '')}`} className="font-semibold text-[#2D5A27] underline">
                        {selectedPbsInfo.hotline}
                      </a>
                    </div>
                    <div>
                      <span className="font-bold text-[#C0392B]">🚨 অভিযোগ সেল: </span>
                      <a href={`tel:${selectedPbsInfo.emergencyComplainNumber.replace(/[^0-9]/g, '')}`} className="font-semibold text-[#C0392B] underline">
                        {selectedPbsInfo.emergencyComplainNumber}
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  অভিযোগের ধরন *
                </label>
                <select
                  value={complainType}
                  onChange={(e) => setComplainType(e.target.value as any)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] font-medium"
                >
                  <option value="বিদ্যুৎ বিভ্রাট/লোডশেডিং">বিদ্যুৎ বিভ্রাট / দীর্ঘ সময় লোডশেডিং</option>
                  <option value="ট্রান্সফরমার বিকল">ট্রান্সফরমার বিকল / ধোঁয়া ওঠা / বিস্ফোরণ</option>
                  <option value="তার ছিঁড়ে যাওয়া">বৈদ্যুতিক তার ছিঁড়ে বিপদজনক অবস্থায় পড়া</option>
                  <option value="মিটার ত্রুটি">মিটার ডিসপ্লে নষ্ট / মিটার অতিরিক্ত ঘোরা</option>
                  <option value="অতিরিক্ত বিল">ভুতুড়ে বা অতিরিক্ত বিল সংক্রান্ত অভিযোগ</option>
                  <option value="নতুন সংযোগ দেরি">নতুন সংযোগের আবেদন সত্ত্বেও সংযোগ না পাওয়া</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  গ্রাম / পাড়া / এলাকা ও ইউনিয়ন *
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: চক সূত্রাপুর, দেউলী ইউনিয়ন"
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                সমস্যার বিস্তারিত বিবরণ *
              </label>
              <textarea
                required
                rows={3}
                placeholder="সমস্যাটি কখন থেকে হচ্ছে, কোন খুঁটি বা ল্যান্ডমার্কের কাছে..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl p-3 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-3 rounded-2xl text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>অনলাইনে অভিযোগ দাখিল করুন</span>
            </button>
          </form>
        </div>

        {/* Right: Live Tracking Status Card */}
        <div className="lg:col-span-5 space-y-4">
          {activeComplaint ? (
            <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
                <div>
                  <span className="text-[11px] font-bold text-[#A65E2E] bg-[#F9E5D4] px-2.5 py-0.5 rounded-full">
                    ট্র্যাকিং স্লিপ
                  </span>
                  <p className="text-sm sm:text-base font-bold text-[#2D3A3A] font-mono mt-1">
                    {activeComplaint.trackingId}
                  </p>
                </div>
                <button
                  onClick={() => window.print()}
                  className="p-2.5 bg-[#FDFBF7] hover:bg-[#E6E0D4] text-[#2D3A3A] rounded-2xl text-xs flex items-center gap-1 transition cursor-pointer border border-[#E6E0D4]"
                  title="প্রিন্ট বা ডাউনলোড করুন"
                >
                  <Printer className="w-4 h-4" />
                  <span>প্রিন্ট</span>
                </button>
              </div>

              {/* Status Timeline */}
              <div className="space-y-3 py-2">
                <h4 className="text-xs font-bold text-[#2D3A3A]">অভিযোগের বর্তমান অবস্থা:</h4>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-[#2D5A27] font-semibold">
                    <CheckCircle2 className="w-4 h-4 text-[#2D5A27]" />
                    <span>অভিযোগ গৃহীত ও রেজিস্টারভুক্ত হয়েছে</span>
                  </div>
                  <div className="flex items-center gap-2 text-[#2D5A27] font-semibold">
                    <CheckCircle2 className="w-4 h-4 text-[#2D5A27]" />
                    <span>লাইন সুপারভাইজার ও প্রকৌশলীর কাছে প্রেরিত</span>
                  </div>
                  <div className={`flex items-center gap-2 font-semibold ${
                    activeComplaint.status === 'কারিগরি দল প্রেরিত' || activeComplaint.status === 'সমাধান সম্পন্ন'
                      ? 'text-[#2D5A27]'
                      : 'text-[#736B5E]/50'
                  }`}>
                    <Truck className="w-4 h-4" />
                    <span>মাঠপর্যায়ে কারিগরি দল (লাইনম্যান) রওনা হয়েছে</span>
                  </div>
                  <div className={`flex items-center gap-2 font-semibold ${
                    activeComplaint.status === 'সমাধান সম্পন্ন'
                      ? 'text-[#2D5A27]'
                      : 'text-[#736B5E]/50'
                  }`}>
                    <ShieldCheck className="w-4 h-4" />
                    <span>মেরামত ও সমাধান সম্পন্ন</span>
                  </div>
                </div>
              </div>

              {/* Details table */}
              <div className="bg-[#FDFBF7] rounded-2xl p-4 text-xs space-y-2 border border-[#E6E0D4]">
                <div className="flex justify-between">
                  <span className="text-[#736B5E]">গ্রাহক:</span>
                  <span className="font-semibold text-[#2D3A3A]">{activeComplaint.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#736B5E]">সমিতি:</span>
                  <span className="font-semibold text-[#2D3A3A]">{activeComplaint.pbsName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#736B5E]">অভিযোগের ধরন:</span>
                  <span className="font-semibold text-[#A65E2E]">{activeComplaint.complainType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#736B5E]">স্থান:</span>
                  <span className="font-semibold text-[#2D3A3A]">{activeComplaint.village}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#736B5E]">সম্ভাব্য সমাধান সময়:</span>
                  <span className="font-semibold text-[#2D5A27]">{activeComplaint.estimatedResolution}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#FDFBF7] border border-[#E6E0D4] rounded-3xl p-8 text-center text-[#736B5E] text-xs">
              অভিযোগ দাখিল করলে এখানে লাইভ ট্র্যাকিং স্লিপ দেখা যাবে।
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
