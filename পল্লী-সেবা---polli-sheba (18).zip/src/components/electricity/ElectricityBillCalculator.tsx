import React, { useState, useEffect } from 'react';
import { FileText, CheckCircle, Zap, AlertOctagon, PhoneCall, ShieldCheck } from 'lucide-react';
import { toBanglaNumber, formatTaka } from '../../utils/banglaNumbers';
import { PowerComplaintForm } from './PowerComplaintForm';

interface ElectricityBillCalculatorProps {
  initialTab?: 'bill' | 'complaints';
}

export const ElectricityBillCalculator: React.FC<ElectricityBillCalculatorProps> = ({ 
  initialTab = 'bill' 
}) => {
  const [activeTab, setActiveTab] = useState<'bill' | 'complaints'>(initialTab);

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);
  const [customerType, setCustomerType] = useState<'residential' | 'irrigation' | 'commercial'>('residential');
  const [meterType, setMeterType] = useState<'single' | 'three'>('single');
  const [unitsUsed, setUnitsUsed] = useState<string>('১২৫');
  const [sanctionedLoad, setSanctionedLoad] = useState<string>('২'); // kW
  const [isPrepaid, setIsPrepaid] = useState<boolean>(false);

  const units = Math.max(0, parseFloat(unitsUsed) || 0);
  const load = Math.max(1, parseFloat(sanctionedLoad) || 1);

  // Calculation Logic according to BREB Tariff
  let energyCharge = 0;
  const slabBreakdown: { label: string; units: number; rate: number; cost: number }[] = [];

  if (customerType === 'irrigation') {
    const rate = 4.82;
    energyCharge = units * rate;
    slabBreakdown.push({ label: 'কৃষিসেচ সমহার', units, rate, cost: energyCharge });
  } else if (customerType === 'commercial') {
    const rate = 11.98;
    energyCharge = units * rate;
    slabBreakdown.push({ label: 'বাণিজ্যিক সমহার', units, rate, cost: energyCharge });
  } else {
    if (units <= 50) {
      const cost = units * 4.63;
      energyCharge = cost;
      slabBreakdown.push({ label: 'লাইফলাইন (০-৫০ ইউনিট)', units, rate: 4.63, cost });
    } else {
      let remaining = units;

      // Slab 1: 1-75 units @ 5.26
      const s1 = Math.min(remaining, 75);
      if (s1 > 0) {
        const c1 = s1 * 5.26;
        energyCharge += c1;
        slabBreakdown.push({ label: '১ম ধাপ (১-৭৫ ইউনিট)', units: s1, rate: 5.26, cost: c1 });
        remaining -= s1;
      }

      // Slab 2: 76-200 units (125 units max) @ 7.20
      if (remaining > 0) {
        const s2 = Math.min(remaining, 125);
        const c2 = s2 * 7.20;
        energyCharge += c2;
        slabBreakdown.push({ label: '২য় ধাপ (৭৬-২০০ ইউনিট)', units: s2, rate: 7.20, cost: c2 });
        remaining -= s2;
      }

      // Slab 3: 201-300 units (100 units max) @ 7.59
      if (remaining > 0) {
        const s3 = Math.min(remaining, 100);
        const c3 = s3 * 7.59;
        energyCharge += c3;
        slabBreakdown.push({ label: '৩য় ধাপ (২০১-৩০০ ইউনিট)', units: s3, rate: 7.59, cost: c3 });
        remaining -= s3;
      }

      // Slab 4: 301-400 units (100 units max) @ 8.02
      if (remaining > 0) {
        const s4 = Math.min(remaining, 100);
        const c4 = s4 * 8.02;
        energyCharge += c4;
        slabBreakdown.push({ label: '৪র্থ ধাপ (৩০১-৪০০ ইউনিট)', units: s4, rate: 8.02, cost: c4 });
        remaining -= s4;
      }

      // Slab 5: 401-600 units (200 units max) @ 12.67
      if (remaining > 0) {
        const s5 = Math.min(remaining, 200);
        const c5 = s5 * 12.67;
        energyCharge += c5;
        slabBreakdown.push({ label: '৫ম ধাপ (৪০১-৬০০ ইউনিট)', units: s5, rate: 12.67, cost: c5 });
        remaining -= s5;
      }

      // Slab 6: 600+ units @ 14.61
      if (remaining > 0) {
        const c6 = remaining * 14.61;
        energyCharge += c6;
        slabBreakdown.push({ label: '৬ষ্ঠ ধাপ (৬০০ ইউনিটের ঊর্ধ্বে)', units: remaining, rate: 14.61, cost: c6 });
      }
    }
  }

  const demandRate = customerType === 'commercial' ? 75 : 35;
  const demandCharge = load * demandRate;
  const meterRent = isPrepaid ? 0 : (meterType === 'three' ? 150 : 40);
  const subTotal = energyCharge + demandCharge + meterRent;
  const vatAmount = subTotal * 0.05;
  const agriRebate = customerType === 'irrigation' ? energyCharge * 0.20 : 0;
  const netTotal = Math.round(subTotal + vatAmount - agriRebate);

  return (
    <div className="space-y-6">
      {/* Sub-navigation bar inside Electricity services */}
      <div className="flex gap-2 border-b border-[#E6E0D4] pb-2 overflow-x-auto no-scrollbar">
        <button
          type="button"
          onClick={() => setActiveTab('bill')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'bill'
              ? 'bg-[#2D5A27] text-white shadow-xs'
              : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
          }`}
        >
          <Zap className="w-4 h-4" />
          <span>পল্লী বিদ্যুৎ বিল ক্যালকুলেটর</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('complaints')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
            activeTab === 'complaints'
              ? 'bg-[#A65E2E] text-white shadow-xs'
              : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
          }`}
        >
          <AlertOctagon className="w-4 h-4" />
          <span>অভিযোগ দাখিল ও লাইভ ট্র্যাকিং</span>
        </button>
      </div>

      {activeTab === 'complaints' ? (
        <PowerComplaintForm />
      ) : (
        <>
          {/* Banner in Natural Tones */}
          <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm">
            <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
              ⚡ পল্লী বিদ্যুৎ ট্যারিফ ক্যালকুলেটর
            </span>
            <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
              পল্লী বিদ্যুৎ মাসিক বিলের আনুমানিক হিসাব
            </h2>
            <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
              বাংলাদেশ পল্লী বিদ্যুতায়ন বোর্ড (BREB) এর সর্বশেষ সরকারি ট্যারিফ কাঠামো অনুযায়ী স্বয়ংক্রিয় হিসাব
            </p>
          </div>

      {/* Input Form */}
      <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-bold text-[#2D3A3A] mb-1.5">
              গ্রাহকের ধরন / সংযোগের ক্যাটাগরি:
            </label>
            <select
              value={customerType}
              onChange={(e) => setCustomerType(e.target.value as any)}
              className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-semibold text-[#2D3A3A]"
            >
              <option value="residential">আবাসিক (LT-A - গৃহস্থালী)</option>
              <option value="irrigation">কৃষিকাজে গভীর/অগভী সেচ পাম্প (LT-B)</option>
              <option value="commercial">বাণিজ্যিক ও ক্ষুদ্র কুটির শিল্প (LT-E)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2D3A3A] mb-1.5">
              ব্যবহৃত ইউনিটের পরিমাণ (kWh):
            </label>
            <input
              type="number"
              min="0"
              value={unitsUsed}
              onChange={(e) => setUnitsUsed(e.target.value)}
              placeholder="যেমন: ১২৫"
              className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D5A27]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2D3A3A] mb-1.5">
              অনুমোদিত লোড (কিলোওয়াট / kW):
            </label>
            <input
              type="number"
              min="1"
              max="50"
              value={sanctionedLoad}
              onChange={(e) => setSanctionedLoad(e.target.value)}
              placeholder="যেমন: ২"
              className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 pt-3.5 border-t border-[#E6E0D4]">
          <div className="flex items-center gap-4">
            <label className="text-xs font-bold text-[#2D3A3A]">মিটারের ধরন:</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setMeterType('single')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  meterType === 'single' ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FDFBF7] text-[#2D3A3A] border border-[#E6E0D4]'
                }`}
              >
                এক ফেজ (Single Phase)
              </button>
              <button
                type="button"
                onClick={() => setMeterType('three')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  meterType === 'three' ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FDFBF7] text-[#2D3A3A] border border-[#E6E0D4]'
                }`}
              >
                তিন ফেজ (Three Phase)
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="prepaid-checkbox"
              checked={isPrepaid}
              onChange={(e) => setIsPrepaid(e.target.checked)}
              className="w-4 h-4 text-[#2D5A27] accent-[#2D5A27] rounded cursor-pointer"
            />
            <label htmlFor="prepaid-checkbox" className="text-xs text-[#2D3A3A] font-semibold cursor-pointer">
              এটি প্রিপেইড মিটার (প্রিপেইড হলে মিটার ভাড়া বাদ যাবে)
            </label>
          </div>
        </div>
      </div>

      {/* Bill Summary Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Bill Breakdown Slabs */}
        <div className="lg:col-span-7 bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-3.5">
          <h3 className="text-xs sm:text-sm font-bold text-[#2D3A3A] flex items-center gap-2 font-['Noto_Sans_Bengali']">
            <FileText className="w-4 h-4 text-[#2D5A27]" />
            <span>ধাপভিত্তিক বিদ্যুৎ ব্যবহারের চার্জ বিবরণী:</span>
          </h3>

          <div className="space-y-2">
            {slabBreakdown.map((slab, idx) => (
              <div key={idx} className="flex items-center justify-between bg-[#FDFBF7] p-3 rounded-2xl border border-[#E6E0D4] text-xs">
                <div>
                  <span className="font-semibold text-[#2D3A3A]">{slab.label}</span>
                  <span className="text-[#736B5E] block text-[11px]">
                    {toBanglaNumber(slab.units)} ইউনিট × ৳{toBanglaNumber(slab.rate.toFixed(2))}
                  </span>
                </div>
                <span className="font-bold text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                  {formatTaka(Math.round(slab.cost))}
                </span>
              </div>
            ))}
          </div>

          <div className="border-t border-[#E6E0D4] pt-3.5 space-y-2 text-xs text-[#5A6B6B]">
            <div className="flex justify-between">
              <span>মোট জ্বালানি চার্জ (Energy Charge):</span>
              <span className="font-semibold text-[#2D3A3A]">{formatTaka(Math.round(energyCharge))}</span>
            </div>
            <div className="flex justify-between">
              <span>ডিমান্ড চার্জ ({toBanglaNumber(load)} কিলোওয়াট):</span>
              <span className="font-semibold text-[#2D3A3A]">{formatTaka(demandCharge)}</span>
            </div>
            <div className="flex justify-between">
              <span>মিটার ভাড়া:</span>
              <span className="font-semibold text-[#2D3A3A]">{formatTaka(meterRent)}</span>
            </div>
            <div className="flex justify-between">
              <span>সরকারি ভ্যাট (৫%):</span>
              <span className="font-semibold text-[#2D3A3A]">{formatTaka(Math.round(vatAmount))}</span>
            </div>
            {agriRebate > 0 && (
              <div className="flex justify-between text-[#2D5A27] font-semibold">
                <span>সরকারি কৃষি সেচ ২০% রিবেট ছাড় (-):</span>
                <span>-{formatTaka(Math.round(agriRebate))}</span>
              </div>
            )}
          </div>
        </div>

        {/* Grand Total Box */}
        <div className="lg:col-span-5 bg-[#2D5A27] rounded-3xl p-6 text-white shadow-md flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 -mt-6 -mr-6 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none" />

          <div className="relative z-10">
            <span className="text-xs uppercase tracking-wider font-bold bg-[#23491E] px-3.5 py-1 rounded-full text-[#D4E4BC] border border-[#3D7A35]">
              সর্বমোট প্রদেয় বিদ্যুৎ বিল
            </span>
            <div className="mt-5">
              <span className="text-xs text-[#D4E4BC] block">অনুমিত নিট প্রদেয় টাকা</span>
              <p className="text-3xl sm:text-4xl font-extrabold tracking-tight font-['Noto_Sans_Bengali'] mt-1 drop-shadow-xs">
                {formatTaka(netTotal)}
              </p>
            </div>
            <p className="text-xs text-[#D4E4BC] mt-2">
              মোট ব্যবহার: <strong className="text-white">{toBanglaNumber(units)} ইউনিট</strong>
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-white/20 text-xs text-[#D4E4BC] space-y-1 relative z-10">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-[#D4E4BC]" />
              <span>বিকাশ, নগদ, রকেট বা ইউপি ডিজিটাল সেন্টারে বিল প্রদান করা যায়</span>
            </div>
            <p className="text-[11px] text-[#D4E4BC]/80 pt-1">
              * প্রকৃত বিলে বিলম্ব ফি বা ন্যূনতম চার্জ সমন্বয় থাকতে পারে।
            </p>
          </div>
        </div>
      </div>
      </>
      )}
    </div>
  );
};
