import React, { useState, useEffect } from 'react';
import { 
  MessageSquare, 
  X, 
  Search, 
  Clock, 
  ShieldCheck, 
  ArrowRight, 
  PlusCircle, 
  Inbox, 
  PhoneCall, 
  Phone, 
  PhoneMissed, 
  PhoneIncoming, 
  PhoneOutgoing, 
  Smartphone, 
  Lock, 
  Delete,
  CheckCircle2
} from 'lucide-react';
import { UserProfile } from '../../types/auth';
import { 
  ConversationSummary, 
  subscribeToUserInbox, 
  markConversationRead, 
  MissedCallRecord, 
  subscribeToUserCalls, 
  markCallCallbackDone,
  resetMissedCallsBadge
} from '../../lib/cloudSync';
import { maskPhoneNumber } from '../transport/RuralTransport';
import { OfflineCallWarningModal } from '../common/OfflineCallWarningModal';
import { InAppVoiceCallModal } from '../transport/InAppVoiceCallModal';

interface UserInboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  onOpenConversation: (params: {
    recipientId: string;
    recipientName: string;
    recipientRole?: string;
    recipientPhone?: string;
    itemTitle?: string;
  }) => void;
  onOpenAuth: (actionName?: string) => void;
}

// Unified Inbox Item that represents either a Chat thread, a Call record, or both
interface UnifiedInboxItem {
  id: string;
  contactId: string;
  contactPhone: string;
  contactName: string;
  contactRole?: string;
  contactAvatar?: string;
  lastMessage?: string;
  lastMessageTime?: number;
  isChatUnread?: boolean;
  latestCall?: MissedCallRecord;
  hasMissedCall?: boolean;
  updatedAt: number;
  itemType: 'chat' | 'call' | 'merged';
}

export const UserInboxModal: React.FC<UserInboxModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onOpenConversation,
  onOpenAuth
}) => {
  const [conversations, setConversations] = useState<ConversationSummary[]>([]);
  const [calls, setCalls] = useState<MissedCallRecord[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'missed' | 'calls' | 'chats'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Quick Dial Pad State
  const [showDialPad, setShowDialPad] = useState(false);
  const [dialPadNumber, setDialPadNumber] = useState('');
  
  // Start New Manual Chat Form
  const [showStartNew, setShowStartNew] = useState(false);
  const [newRecipientPhone, setNewRecipientPhone] = useState('');
  const [newRecipientName, setNewRecipientName] = useState('');

  // Call & Dial Options Popup State
  const [activeDialTarget, setActiveDialTarget] = useState<{
    name: string;
    phone: string;
    role?: string;
    avatar?: string;
    subtitle?: string;
    callId?: string;
    allowOfflineCall?: boolean;
  } | null>(null);

  // In-App VoIP Call State
  const [activeVoipCall, setActiveVoipCall] = useState<{
    name: string;
    phone: string;
    role?: string;
    avatar?: string;
    subtitle?: string;
  } | null>(null);

  // Offline SIM Call Warning Modal State
  const [activeOfflineWarning, setActiveOfflineWarning] = useState<{
    name: string;
    phone: string;
    role?: string;
    allowOfflineCall?: boolean;
  } | null>(null);

  const myId = currentUser 
    ? (currentUser.phone ? currentUser.phone.replace(/[^0-9]/g, '') : currentUser.id)
    : '';

  // 1. Subscribe to User Inbox (Text Chats)
  useEffect(() => {
    if (!isOpen || !myId) return;

    const unsubscribe = subscribeToUserInbox(myId, (list) => {
      setConversations(list);
      list.forEach(c => {
        if (c.unreadBy === myId || (c.unreadBy && c.unreadBy.includes(myId))) {
          markConversationRead(c.conversationId, myId);
        }
      });
    });

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [isOpen, myId]);

  // 2. Subscribe to Real-Time Call History & Missed Calls
  useEffect(() => {
    if (!isOpen || !myId) return;

    const unsubscribeCalls = subscribeToUserCalls(myId, (callList) => {
      setCalls(callList);
    });

    const handleMissedUpdated = () => {
      try {
        const raw = localStorage.getItem('polli_missed_calls');
        if (raw) {
          const list: MissedCallRecord[] = JSON.parse(raw);
          setCalls(list);
        }
      } catch {}
    };

    window.addEventListener('polli_missed_calls_updated', handleMissedUpdated);

    return () => {
      if (unsubscribeCalls) unsubscribeCalls();
      window.removeEventListener('polli_missed_calls_updated', handleMissedUpdated);
    };
  }, [isOpen, myId]);

  if (!isOpen) return null;

  if (!currentUser) {
    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-150">
        <div className="bg-white rounded-3xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl border border-[#E6E0D4]">
          <div className="w-16 h-16 rounded-3xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center mx-auto text-2xl shadow-xs">
            <Inbox className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-[#2D3A3A]">আমার ইনবক্স, বার্তা ও কল হিস্ট্রি</h3>
          <p className="text-xs text-[#736B5E] leading-relaxed">
            আপনার ইনবক্সে ক্রেতা, বিক্রেতা বা গাড়ি চালকদের মিসড কল ও বার্তা দেখতে এবং নম্বর গোপন রেখে সুরক্ষিতভাবে কল ব্যাক করতে অনুগ্রহ করে আগে লগইন বা এককালীন সদস্য নিবন্ধন করুন।
          </p>
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => {
                onClose();
                onOpenAuth('ইনবক্স দেখতে ও মেসেজ/কল আদান-প্রদান করতে');
              }}
              className="w-full py-3 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold rounded-2xl text-xs shadow-md transition cursor-pointer"
            >
              🔑 লগইন / নতুন নিবন্ধন করুন
            </button>
            <button
              onClick={onClose}
              className="w-full py-2 text-xs font-semibold text-[#736B5E] hover:text-[#2D3A3A] cursor-pointer"
            >
              এখন নয়, পরে
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 3. Build Unified Inbox Entries (Chats + Calls)
  const contactMap = new Map<string, UnifiedInboxItem>();

  // Process text conversations
  conversations.forEach(c => {
    const isSenderMe = c.senderId === myId || (c.senderId && c.senderId.includes(myId));
    const otherId = isSenderMe ? c.recipientId : c.senderId;
    const cleanOtherPhone = (otherId || '').replace(/[^0-9]/g, '');
    const otherName = isSenderMe ? c.recipientName : c.senderName;
    const otherRole = isSenderMe ? '' : c.senderRole;
    const isUnread = c.unreadBy === myId || (c.unreadBy && c.unreadBy.replace(/[^0-9]/g, '') === myId);

    const key = cleanOtherPhone || otherId || c.conversationId;
    contactMap.set(key, {
      id: c.conversationId,
      contactId: otherId,
      contactPhone: cleanOtherPhone || otherId,
      contactName: otherName || 'ব্যবহারকারী',
      contactRole: otherRole,
      lastMessage: c.lastMessage,
      lastMessageTime: c.updatedAt || c.lastMessageTime || 0,
      isChatUnread: isUnread,
      updatedAt: c.updatedAt || c.lastMessageTime || 0,
      itemType: 'chat'
    });
  });

  // Merge call history
  calls.forEach(call => {
    const isIncoming = call.recipientPhone?.replace(/[^0-9]/g, '').endsWith(myId) ||
                       myId.endsWith(call.recipientPhone?.replace(/[^0-9]/g, '') || '');
    
    const otherPhone = isIncoming ? call.callerPhone : call.recipientPhone;
    const cleanPhone = (otherPhone || '').replace(/[^0-9]/g, '');
    const otherName = isIncoming ? call.callerName : call.recipientName;
    const otherRole = isIncoming ? call.callerRole : call.recipientRole;
    const otherAvatar = isIncoming ? call.callerAvatar : call.recipientAvatar;

    const key = cleanPhone || otherPhone || call.id;
    const existing = contactMap.get(key);

    const isMissed = isIncoming && (call.type === 'missed' || !call.type) && !call.isCallbackDone;

    if (existing) {
      existing.itemType = 'merged';
      if (!existing.latestCall || call.timestamp > (existing.latestCall.timestamp || 0)) {
        existing.latestCall = call;
        if (call.timestamp > existing.updatedAt) {
          existing.updatedAt = call.timestamp;
        }
      }
      if (isMissed) {
        existing.hasMissedCall = true;
      }
    } else {
      contactMap.set(key, {
        id: call.id,
        contactId: cleanPhone || otherPhone,
        contactPhone: otherPhone,
        contactName: otherName || 'অপরিচিত ব্যবহারকারী',
        contactRole: otherRole,
        contactAvatar: otherAvatar,
        latestCall: call,
        hasMissedCall: isMissed,
        updatedAt: call.timestamp || 0,
        itemType: 'call'
      });
    }
  });

  const unifiedList = Array.from(contactMap.values()).sort((a, b) => b.updatedAt - a.updatedAt);

  // Dedicated Call History List for 'calls' tab with dialed, received, and missed calls
  const callsHistoryList = calls
    .map(call => {
      const isCallerMe = call.callerPhone?.replace(/[^0-9]/g, '').endsWith(myId) || 
                         myId.endsWith(call.callerPhone?.replace(/[^0-9]/g, '') || '') ||
                         call.type === 'dialed' || 
                         call.type === 'outgoing';

      const contactName = isCallerMe ? call.recipientName : call.callerName;
      const contactPhone = isCallerMe ? call.recipientPhone : call.callerPhone;
      const contactRole = isCallerMe ? call.recipientRole : call.callerRole;
      const contactAvatar = isCallerMe ? call.recipientAvatar : call.callerAvatar;
      const contactSubtitle = isCallerMe ? call.recipientSubtitle : call.callerSubtitle;

      return {
        ...call,
        isCallerMe,
        displayName: contactName || 'অপরিচিত ব্যবহারকারী',
        displayPhone: contactPhone,
        displayRole: contactRole,
        displayAvatar: contactAvatar,
        displaySubtitle: contactSubtitle || 'পল্লী সেবা সদস্য'
      };
    })
    .filter(call => {
      if (!searchQuery) return true;
      const q = searchQuery.toLowerCase();
      return (call.displayName || '').toLowerCase().includes(q) || 
             (call.displayPhone || '').toLowerCase().includes(q);
    })
    .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

  // Filter items based on active tab and search query
  const filteredItems = unifiedList.filter(item => {
    // Search query match
    const matchName = item.contactName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchPhone = item.contactPhone.toLowerCase().includes(searchQuery.toLowerCase());
    const matchMsg = (item.lastMessage || '').toLowerCase().includes(searchQuery.toLowerCase());
    if (searchQuery && !matchName && !matchPhone && !matchMsg) return false;

    // Tab filter
    if (activeTab === 'missed') {
      return item.hasMissedCall || (item.latestCall && item.latestCall.type === 'missed');
    }
    if (activeTab === 'calls') {
      return !!item.latestCall;
    }
    if (activeTab === 'chats') {
      return item.itemType === 'chat' || !!item.lastMessage;
    }
    return true;
  });

  const totalMissedCount = unifiedList.filter(i => i.hasMissedCall).length;
  const totalCallsCount = Math.max(calls.length, unifiedList.filter(i => !!i.latestCall).length);

  const handleOpenDialOptions = (item: UnifiedInboxItem) => {
    setActiveDialTarget({
      name: item.contactName,
      phone: item.contactPhone,
      role: item.contactRole,
      avatar: item.contactAvatar,
      subtitle: item.latestCall?.callerSubtitle || item.latestCall?.recipientSubtitle || 'পল্লী সেবা সদস্য',
      callId: item.latestCall?.id,
      allowOfflineCall: item.latestCall?.allowOfflineCall ?? true
    });
  };

  const handleDirectChat = (item: UnifiedInboxItem) => {
    onClose();
    onOpenConversation({
      recipientId: item.contactId,
      recipientName: item.contactName,
      recipientRole: item.contactRole,
      recipientPhone: item.contactPhone
    });
  };

  const handleStartManualChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRecipientPhone.trim()) return;

    const clean = newRecipientPhone.replace(/[^0-9]/g, '');
    onClose();
    onOpenConversation({
      recipientId: clean || newRecipientPhone,
      recipientName: newRecipientName.trim() || `ব্যবহারকারী (${newRecipientPhone})`,
      recipientPhone: clean
    });
  };

  const handleDialPadVoipCall = () => {
    if (!dialPadNumber.trim()) return;
    const clean = dialPadNumber.replace(/[^0-9]/g, '');
    setActiveVoipCall({
      name: `ব্যবহারকারী (${dialPadNumber})`,
      phone: clean,
      subtitle: 'ডায়াল প্যাড থেকে সরাসরি কল'
    });
  };

  const handleDialPadSimCall = () => {
    if (!dialPadNumber.trim()) return;
    setActiveOfflineWarning({
      name: `ব্যবহারকারী (${dialPadNumber})`,
      phone: dialPadNumber,
      allowOfflineCall: true
    });
  };

  const formatConvoTime = (timestamp?: number) => {
    if (!timestamp) return 'এইমাত্র';
    const diffMin = Math.floor((Date.now() - timestamp) / 60000);
    if (diffMin < 1) return 'এইমাত্র';
    if (diffMin < 60) return `${diffMin} মিনিট আগে`;
    const diffHours = Math.floor(diffMin / 60);
    if (diffHours < 24) return `${diffHours} ঘণ্টা আগে`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} দিন আগে`;
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-150">
        <div className="bg-white rounded-3xl max-w-lg w-full h-[90vh] max-h-[680px] flex flex-col shadow-2xl border border-[#E6E0D4] overflow-hidden">
          
          {/* Header */}
          <div className="bg-[#2D5A27] text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center shadow-xs">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base sm:text-lg flex items-center gap-1.5">
                  <span>আমার ইনবক্স ও বার্তা</span>
                  {totalMissedCount > 0 && (
                    <span className="bg-rose-500 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full animate-pulse shadow-xs">
                      {totalMissedCount}টি মিসড কল
                    </span>
                  )}
                </h3>
                <p className="text-xs text-[#D4E4BC]/90">
                  মিসড কল, কল হিস্ট্রি ও গোপনীয় চ্যাট বক্স
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Dial Pad Toggle */}
              <button
                type="button"
                onClick={() => {
                  setShowDialPad(!showDialPad);
                  setShowStartNew(false);
                }}
                className={`p-2 rounded-2xl transition cursor-pointer flex items-center gap-1 text-xs font-bold ${
                  showDialPad 
                    ? 'bg-amber-400 text-slate-900 shadow-sm' 
                    : 'bg-[#D4E4BC]/20 hover:bg-[#D4E4BC]/40 text-[#D4E4BC] hover:text-white'
                }`}
                title="ডায়াল প্যাড চালু করুন"
              >
                <PhoneCall className="w-4 h-4" />
                <span className="hidden sm:inline">ডায়াল প্যাড</span>
              </button>

              {/* Start New Chat Toggle */}
              <button
                type="button"
                onClick={() => {
                  setShowStartNew(!showStartNew);
                  setShowDialPad(false);
                }}
                className="p-2 rounded-2xl bg-[#D4E4BC]/20 hover:bg-[#D4E4BC]/40 text-[#D4E4BC] hover:text-white transition cursor-pointer flex items-center gap-1 text-xs font-semibold"
                title="নতুন মেসেজ পাঠান"
              >
                <PlusCircle className="w-4 h-4" />
                <span className="hidden sm:inline">নতুন বার্তা</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-2xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Interactive Dial Pad Drawer */}
          {showDialPad && (
            <div className="bg-[#121B22] text-white p-4 border-b border-[#27AE60]/40 space-y-3 shrink-0 animate-in slide-in-from-top-2 duration-150">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5" />
                  <span>স্মার্ট ডায়াল প্যাড (কল অপশন)</span>
                </span>
                <button
                  type="button"
                  onClick={() => setShowDialPad(false)}
                  className="text-white/60 hover:text-white text-xs"
                >
                  ✕
                </button>
              </div>

              {/* Display Box */}
              <div className="bg-[#1E2A32] rounded-2xl p-2.5 flex items-center justify-between border border-white/10">
                <input
                  type="text"
                  value={dialPadNumber}
                  onChange={(e) => setDialPadNumber(e.target.value)}
                  placeholder="নম্বর লিখুন (যেমন: ০১৭...)"
                  className="bg-transparent text-emerald-300 font-mono text-sm sm:text-base font-bold w-full focus:outline-none px-2"
                />
                {dialPadNumber && (
                  <button
                    type="button"
                    onClick={() => setDialPadNumber(dialPadNumber.slice(0, -1))}
                    className="p-1 text-white/60 hover:text-rose-400 text-xs font-bold"
                  >
                    <Delete className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Number Buttons Grid */}
              <div className="grid grid-cols-3 gap-1.5 max-w-xs mx-auto">
                {['১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '*', '০', '#'].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setDialPadNumber(prev => prev + d)}
                    className="py-1.5 bg-[#1E2A32] hover:bg-[#2D3A3A] text-white font-bold text-sm rounded-xl transition cursor-pointer border border-white/5 active:scale-95"
                  >
                    {d}
                  </button>
                ))}
              </div>

              {/* Two Explicit Call Buttons (VoIP vs Cellular SIM) */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleDialPadVoipCall}
                  disabled={!dialPadNumber.trim()}
                  className="py-2 px-2 bg-[#2D5A27] hover:bg-[#23491E] disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition shadow-xs cursor-pointer"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-[#D4E4BC]" />
                  <span>🌐 অনলাইন ইন্টারনেট কল</span>
                </button>
                <button
                  type="button"
                  onClick={handleDialPadSimCall}
                  disabled={!dialPadNumber.trim()}
                  className="py-2 px-2 bg-[#E8924A] hover:bg-[#D97D35] disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition shadow-xs cursor-pointer"
                >
                  <Smartphone className="w-3.5 h-3.5 text-white" />
                  <span>📱 অফলাইন সিম কল</span>
                </button>
              </div>
            </div>
          )}

          {/* Start New Manual Chat Form (Collapsible) */}
          {showStartNew && (
            <form onSubmit={handleStartManualChat} className="bg-[#FAF8F5] p-4 border-b border-[#E6E0D4] space-y-3 shrink-0 animate-in fade-in">
              <span className="text-xs font-bold text-[#2D5A27] block">কাউকে সরাসরি মেসেজ পাঠাতে চান?</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  value={newRecipientPhone}
                  onChange={(e) => setNewRecipientPhone(e.target.value)}
                  placeholder="প্রাপকের মোবাইল নম্বর"
                  className="bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#2D5A27]"
                  required
                />
                <input
                  type="text"
                  value={newRecipientName}
                  onChange={(e) => setNewRecipientName(e.target.value)}
                  placeholder="প্রাপকের নাম (ঐচ্ছিক)"
                  className="bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#2D5A27]"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowStartNew(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-medium text-[#736B5E] bg-white border border-[#E6E0D4]"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-xs cursor-pointer"
                >
                  চ্যাট শুরু করুন
                </button>
              </div>
            </form>
          )}

          {/* Search Bar & Filter Tabs */}
          <div className="p-3 bg-[#FDFBF7] border-b border-[#E6E0D4] shrink-0 space-y-2">
            <div className="relative flex items-center">
              <Search className="w-4 h-4 text-[#736B5E] absolute left-3 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ইনবক্সে নাম, নম্বর বা মেসেজ খুঁজুন..."
                className="w-full bg-white border border-[#D4C3A3] rounded-2xl pl-9 pr-4 py-2 text-xs font-semibold text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] shadow-2xs"
              />
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              <button
                type="button"
                onClick={() => setActiveTab('all')}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer ${
                  activeTab === 'all'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#736B5E] border border-[#E6E0D4] hover:bg-[#FAF8F5]'
                }`}
              >
                সকল ({unifiedList.length})
              </button>
              
              <button
                type="button"
                onClick={() => setActiveTab('missed')}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                  activeTab === 'missed'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : totalMissedCount > 0
                    ? 'bg-rose-50 text-rose-700 border border-rose-300'
                    : 'bg-white text-[#736B5E] border border-[#E6E0D4] hover:bg-[#FAF8F5]'
                }`}
              >
                <PhoneMissed className="w-3.5 h-3.5" />
                <span>মিসড কল ({totalMissedCount})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('calls')}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                  activeTab === 'calls'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#736B5E] border border-[#E6E0D4] hover:bg-[#FAF8F5]'
                }`}
              >
                <PhoneIncoming className="w-3.5 h-3.5" />
                <span>কল হিস্ট্রি ({totalCallsCount})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('chats')}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                  activeTab === 'chats'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#736B5E] border border-[#E6E0D4] hover:bg-[#FAF8F5]'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>বার্তা</span>
              </button>
            </div>
          </div>

          {/* Unified Inbox Items List */}
          <div className="flex-1 overflow-y-auto p-2 sm:p-3 space-y-2 bg-[#FAF8F5]">
            {activeTab === 'calls' ? (
              callsHistoryList.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 my-auto">
                  <div className="w-14 h-14 rounded-3xl bg-[#D4E4BC]/40 text-[#2D5A27] flex items-center justify-center text-2xl">
                    📞
                  </div>
                  <div className="space-y-1 max-w-xs">
                    <h4 className="font-bold text-sm text-[#2D3A3A]">
                      {searchQuery ? 'কোনো কল তথ্য মেলেনি' : 'বর্তমানে কোনো কল হিস্ট্রি নেই'}
                    </h4>
                    <p className="text-xs text-[#736B5E] leading-relaxed">
                      {searchQuery 
                        ? 'অন্য নাম বা নম্বর দিয়ে সন্ধান করুন।' 
                        : 'আপনার করা ডায়ালড কল, রিসিভড কল ও মিসড কলসমূহ এখানে বিস্তারিত হিস্ট্রিসহ সংরক্ষিত থাকবে।'}
                    </p>
                  </div>
                </div>
              ) : (
                callsHistoryList.map((call) => {
                  const isDialed = call.isCallerMe || call.type === 'dialed' || call.type === 'outgoing';
                  const isReceived = call.type === 'received';
                  const isMissed = call.type === 'missed';

                  return (
                    <div
                      key={call.id}
                      className={`p-3 sm:p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 ${
                        isMissed 
                          ? 'bg-rose-50/70 border-rose-300 hover:border-rose-400 shadow-xs'
                          : isDialed
                          ? 'bg-blue-50/40 border-blue-200 hover:border-blue-300 shadow-xs'
                          : 'bg-white border-[#E6E0D4] hover:bg-[#FAF8F5]'
                      }`}
                    >
                      {/* Left: Avatar & Contact Info */}
                      <div 
                        onClick={() => {
                          setActiveDialTarget({
                            name: call.displayName,
                            phone: call.displayPhone,
                            role: call.displayRole,
                            avatar: call.displayAvatar,
                            subtitle: call.displaySubtitle,
                            callId: call.id,
                            allowOfflineCall: call.allowOfflineCall ?? true
                          });
                        }}
                        className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                      >
                        <div className={`w-11 h-11 rounded-2xl font-bold text-base flex items-center justify-center shrink-0 shadow-2xs relative ${
                          isMissed 
                            ? 'bg-rose-100 text-rose-700 border border-rose-300' 
                            : isDialed
                            ? 'bg-blue-100 text-blue-700 border border-blue-300'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        }`}>
                          {call.displayAvatar ? (
                            <img 
                              src={call.displayAvatar} 
                              alt={call.displayName} 
                              className="w-full h-full rounded-2xl object-cover" 
                            />
                          ) : (
                            call.displayName ? call.displayName.charAt(0) : 'U'
                          )}
                        </div>

                        <div className="min-w-0 flex-1 space-y-0.5">
                          <div className="flex items-center justify-between gap-2">
                            <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] truncate flex items-center gap-1.5">
                              <span>{call.displayName}</span>
                              {call.displayRole && (
                                <span className="text-[10px] bg-[#E8F8F5] text-[#27AE60] px-1.5 py-0.2 rounded-full font-bold">
                                  {call.displayRole === 'farmer' ? 'কৃষক' : 
                                   call.displayRole === 'driver' ? 'চালক' : 
                                   call.displayRole === 'agri_machinery_driver' ? 'ট্র্যাক্টর চালক' : 
                                   call.displayRole === 'boatman' ? 'মাঝি' : 
                                   call.displayRole === 'laborer' ? 'শ্রমিক' : 
                                   call.displayRole === 'mechanic' ? 'মেকানিক' : 
                                   call.displayRole === 'tutor_student' ? 'শিক্ষক' : call.displayRole}
                                </span>
                              )}
                            </h4>
                            <span className="text-[10px] text-[#736B5E] shrink-0">
                              {call.formattedTime || formatConvoTime(call.timestamp)}
                            </span>
                          </div>

                          {/* Status Line: Distinct Dialed / Received / Missed indicators with prominent Outgoing Call Icon */}
                          <div className="flex items-center justify-between gap-2">
                            {isMissed ? (
                              <div className="flex items-center gap-1.5 text-xs text-rose-600 font-bold truncate">
                                <PhoneMissed className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                                <span>মিসড কল • {call.formattedDate || 'আজ'}</span>
                              </div>
                            ) : isDialed ? (
                              <div className="flex items-center gap-1.5 text-xs text-blue-700 font-bold truncate">
                                <PhoneOutgoing className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                                <span>ডায়ালড কল (আউটগোয়িং)</span>
                                <span className="text-[11px] text-gray-500 font-normal">
                                  • {call.duration || 'উত্তর মেলেনি'}
                                </span>
                              </div>
                            ) : (
                              <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-bold truncate">
                                <PhoneIncoming className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                <span>রিসিভড কল (ইনকামিং)</span>
                                <span className="text-[11px] text-gray-500 font-normal">
                                  • {call.duration || 'কথা হয়েছে'}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right: Action Buttons */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveDialTarget({
                              name: call.displayName,
                              phone: call.displayPhone,
                              role: call.displayRole,
                              avatar: call.displayAvatar,
                              subtitle: call.displaySubtitle,
                              callId: call.id,
                              allowOfflineCall: call.allowOfflineCall ?? true
                            });
                          }}
                          className={`py-1.5 px-2.5 rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-2xs cursor-pointer ${
                            isMissed
                              ? 'bg-rose-600 hover:bg-rose-700 text-white'
                              : isDialed
                              ? 'bg-blue-600 hover:bg-blue-700 text-white'
                              : 'bg-[#D4E4BC] hover:bg-[#2D5A27] text-[#2D5A27] hover:text-white'
                          }`}
                          title="কল ব্যাক / পুনরায় ডায়াল"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                          <span>{isMissed ? 'কল ব্যাক' : 'ডায়াল'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onClose();
                            onOpenConversation({
                              recipientId: call.displayPhone?.replace(/[^0-9]/g, '') || call.displayName,
                              recipientName: call.displayName,
                              recipientRole: call.displayRole,
                              recipientPhone: call.displayPhone
                            });
                          }}
                          className="p-1.5 rounded-xl bg-white hover:bg-[#FAF8F5] border border-[#E6E0D4] text-[#2D5A27] hover:border-[#2D5A27] transition cursor-pointer"
                          title="মেসেজ উইন্ডো খুলুন"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )
            ) : filteredItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 my-auto">
                <div className="w-14 h-14 rounded-3xl bg-[#D4E4BC]/40 text-[#2D5A27] flex items-center justify-center text-2xl">
                  {activeTab === 'missed' ? '📞' : '💬'}
                </div>
                <div className="space-y-1 max-w-xs">
                  <h4 className="font-bold text-sm text-[#2D3A3A]">
                    {searchQuery 
                      ? 'কোনো তথ্য মেলেনি' 
                      : activeTab === 'missed' 
                      ? 'বর্তমানে কোনো মিসড কল নেই' 
                      : 'ইনবক্স বর্তমানে খালি'}
                  </h4>
                  <p className="text-xs text-[#736B5E] leading-relaxed">
                    {searchQuery 
                      ? 'অন্য নাম বা নম্বর দিয়ে সন্ধান করুন।' 
                      : activeTab === 'missed'
                      ? 'অ্যাপে আসা কোনো মিসড কল থাকলে তাৎক্ষণিক এখানে প্রদর্শন করবে এবং ডায়াল ব্যাক করতে পারবেন।'
                      : 'পল্লী সেবার চালক বা পণ্যের বিজ্ঞাপনে কল বা মেসেজ দিলে তা রিয়েল-টাইমে এখানে সংরক্ষিত থাকবে।'}
                  </p>
                </div>
              </div>
            ) : (
              filteredItems.map((item) => {
                const hasMissed = item.hasMissedCall;
                const latestCall = item.latestCall;
                const isUnread = item.isChatUnread || hasMissed;

                return (
                  <div
                    key={item.id}
                    className={`p-3 sm:p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 ${
                      hasMissed
                        ? 'bg-rose-50/70 border-rose-300 hover:border-rose-400 shadow-xs'
                        : isUnread 
                        ? 'bg-[#F4F9F2] border-[#27AE60] shadow-xs' 
                        : 'bg-white border-[#E6E0D4] hover:bg-[#FAF8F5] hover:border-[#D4C3A3]'
                    }`}
                  >
                    {/* Left: Avatar & Basic Info */}
                    <div 
                      onClick={() => {
                        if (hasMissed) {
                          handleOpenDialOptions(item);
                        } else {
                          handleDirectChat(item);
                        }
                      }}
                      className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                    >
                      <div className={`w-11 h-11 rounded-2xl font-bold text-base flex items-center justify-center shrink-0 shadow-2xs relative ${
                        hasMissed 
                          ? 'bg-rose-100 text-rose-700 border border-rose-300' 
                          : 'bg-[#D4E4BC] text-[#2D5A27]'
                      }`}>
                        {item.contactAvatar ? (
                          <img 
                            src={item.contactAvatar} 
                            alt={item.contactName} 
                            className="w-full h-full rounded-2xl object-cover" 
                          />
                        ) : (
                          item.contactName ? item.contactName.charAt(0) : 'U'
                        )}

                        {/* Unread / Missed Indicator Dot */}
                        {hasMissed ? (
                          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-600 border-2 border-white rounded-full animate-ping" />
                        ) : isUnread ? (
                          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-[#27AE60] border-2 border-white rounded-full animate-pulse" />
                        ) : null}
                      </div>

                      <div className="min-w-0 flex-1 space-y-0.5">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] truncate flex items-center gap-1.5">
                            <span>{item.contactName}</span>
                            {item.contactRole && (
                              <span className="text-[10px] bg-[#E8F8F5] text-[#27AE60] px-1.5 py-0.2 rounded-full font-bold">
                                {item.contactRole === 'admin' ? 'অফিসিয়াল' :
                                 item.contactRole === 'farmer' ? 'কৃষক' : 
                                 item.contactRole === 'driver' ? 'চালক' : 
                                 item.contactRole === 'agri_machinery_driver' ? 'ট্র্যাক্টর চালক' : 
                                 item.contactRole === 'boatman' ? 'মাঝি' : 
                                 item.contactRole === 'laborer' ? 'শ্রমিক' : 
                                 item.contactRole === 'mechanic' ? 'মেকানিক' : 
                                 item.contactRole === 'tutor_student' ? 'শিক্ষক' : item.contactRole}
                              </span>
                            )}
                          </h4>
                          <span className="text-[10px] text-[#736B5E] shrink-0">
                            {formatConvoTime(item.updatedAt)}
                          </span>
                        </div>

                        {/* Status Line: Call indicator or last message */}
                        <div className="flex items-center justify-between gap-2">
                          {hasMissed ? (
                            <div className="flex items-center gap-1.5 text-xs text-rose-600 font-bold truncate">
                              <PhoneMissed className="w-3.5 h-3.5 text-rose-600 shrink-0 animate-bounce" />
                              <span>মিসড কল • {formatConvoTime(latestCall?.timestamp)}</span>
                              <span className="bg-rose-600 text-white text-[9px] font-extrabold px-1.5 py-0.2 rounded-full ml-1">
                                নতুন মিসড কল
                              </span>
                            </div>
                          ) : latestCall && (!item.lastMessage || latestCall.timestamp > (item.lastMessageTime || 0)) ? (
                            <div className="flex items-center gap-1.5 text-xs text-[#5A6B6B] truncate">
                              {latestCall.type === 'received' ? (
                                <>
                                  <PhoneIncoming className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                  <span className="text-emerald-700 font-semibold">
                                    ইন-অ্যাপ কল {latestCall.duration ? `(${latestCall.duration})` : ''}
                                  </span>
                                </>
                              ) : (latestCall.type === 'dialed' || latestCall.type === 'outgoing') ? (
                                <>
                                  <PhoneOutgoing className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                                  <span className="text-blue-700 font-bold">
                                    ডায়ালড কল (আউটগোয়িং) {latestCall.duration ? `• ${latestCall.duration}` : ''}
                                  </span>
                                </>
                              ) : (
                                <>
                                  <PhoneCall className="w-3.5 h-3.5 text-[#2D5A27] shrink-0" />
                                  <span>কল হিস্ট্রি</span>
                                </>
                              )}
                              <span>• {formatConvoTime(latestCall.timestamp)}</span>
                            </div>
                          ) : (
                            <p className={`text-xs truncate ${item.isChatUnread ? 'font-bold text-[#1E5E3A]' : 'text-[#736B5E]'}`}>
                              {item.lastMessage || 'চ্যাট শুরু হয়েছে'}
                            </p>
                          )}

                          {item.isChatUnread && !hasMissed && (
                            <span className="bg-[#27AE60] text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full shrink-0 animate-pulse">
                              নতুন
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Right: Action Buttons (Call Back Dial / Chat Window) */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* Dial Back / Call Button (Triggers Dial Popup with 2 options) */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenDialOptions(item);
                        }}
                        className={`py-1.5 px-2.5 rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-2xs cursor-pointer ${
                          hasMissed
                            ? 'bg-rose-600 hover:bg-rose-700 text-white animate-pulse'
                            : 'bg-[#D4E4BC] hover:bg-[#2D5A27] text-[#2D5A27] hover:text-white'
                        }`}
                        title="কল ব্যাক / ডায়াল করুন"
                      >
                        <PhoneCall className="w-3.5 h-3.5" />
                        <span>{hasMissed ? 'কল ব্যাক' : 'ডায়াল'}</span>
                      </button>

                      {/* Direct Message / Open Chat Window */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDirectChat(item);
                        }}
                        className="p-1.5 rounded-xl bg-white hover:bg-[#FAF8F5] border border-[#E6E0D4] text-[#2D5A27] hover:border-[#2D5A27] transition cursor-pointer"
                        title="মেসেজ উইন্ডো খুলুন"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer Notice */}
          <div className="p-3 bg-white border-t border-[#E6E0D4] flex items-center justify-between text-[11px] text-[#736B5E] shrink-0">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#2D5A27]" />
              <span>১০০% নিরাপদ যোগাযোগ • ব্যক্তিগত নম্বর সুরক্ষিত • ডায়াল ব্যাক সুবিধা</span>
            </div>
            <button
              onClick={onClose}
              className="px-3 py-1 rounded-xl bg-[#FAF8F5] hover:bg-[#E6E0D4] text-[#2D3A3A] font-semibold text-xs border border-[#E6E0D4] cursor-pointer"
            >
              বন্ধ করুন
            </button>
          </div>

        </div>
      </div>

      {/* ========================================================================= */}
      {/* DIAL OPTIONS POP-UP (ডায়াল অপশন পপ-আপ) WITH 2 DISTINCT CHOICES          */}
      {/* 1. অনলাইনে নাম্বার গোপন রেখে ইন্টারনেট কল (Agora VoIP Call)              */}
      {/* 2. অফলাইন সাধারণ সিম কল (Direct Cellular Call)                           */}
      {/* ========================================================================= */}
      {activeDialTarget && (
        <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4">
            
            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-2xl bg-[#E8F8F5] text-[#27AE60] flex items-center justify-center">
                  <PhoneCall className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-[#2D3A3A]">কল ডায়াল অপশন</h3>
                  <p className="text-[11px] text-[#736B5E]">কল করার মাধ্যম নির্বাচন করুন</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveDialTarget(null)}
                className="text-[#736B5E] hover:text-[#2D3A3A] p-1.5 rounded-full hover:bg-gray-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Target Contact Information */}
            <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] flex items-center gap-3">
              {activeDialTarget.avatar ? (
                <img 
                  src={activeDialTarget.avatar} 
                  alt={activeDialTarget.name} 
                  className="w-12 h-12 rounded-2xl object-cover border border-[#2D5A27]" 
                />
              ) : (
                <div className="w-12 h-12 rounded-2xl bg-[#2D5A27] text-white font-bold text-lg flex items-center justify-center shadow-xs">
                  {activeDialTarget.name.charAt(0)}
                </div>
              )}
              <div className="space-y-0.5 flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <h4 className="font-bold text-sm text-[#2D3A3A] truncate">
                    {activeDialTarget.name}
                  </h4>
                  {activeDialTarget.role && (
                    <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] px-2 py-0.5 rounded-full font-bold">
                      {activeDialTarget.role}
                    </span>
                  )}
                </div>
                <p className="text-xs text-[#5A6B6B] truncate">{activeDialTarget.subtitle}</p>
                <p className="text-[11px] text-[#736B5E] flex items-center gap-1 font-semibold">
                  <Lock className="w-3 h-3 text-[#27AE60]" />
                  <span>নম্বর: {activeDialTarget.allowOfflineCall ? activeDialTarget.phone : maskPhoneNumber(activeDialTarget.phone)}</span>
                </p>
              </div>
            </div>

            {/* BUTTON 1: অনলাইনে নাম্বার গোপন রেখে ইন্টারনেট কল (Agora VoIP Call) */}
            <div 
              onClick={() => {
                if (activeDialTarget.callId) {
                  markCallCallbackDone(activeDialTarget.callId);
                }
                resetMissedCallsBadge(myId);
                const target = activeDialTarget;
                setActiveDialTarget(null);
                setActiveVoipCall({
                  name: target.name,
                  phone: target.phone,
                  role: target.role,
                  avatar: target.avatar,
                  subtitle: target.subtitle
                });
              }}
              className="p-3.5 rounded-2xl border-2 border-[#2D5A27] bg-[#FDFBF7] hover:bg-[#D4E4BC]/25 transition cursor-pointer space-y-2 shadow-xs group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-[#2D5A27] text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition">
                    <PhoneCall className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-bold text-sm text-[#2D5A27] flex items-center gap-1.5">
                      <span>অনলাইনে নাম্বার গোপন রেখে ইন্টারনেট কল</span>
                      <span className="bg-[#27AE60] text-white text-[9px] font-extrabold px-1.5 py-0.2 rounded-full">
                        ফ্রি ও সুরক্ষিত
                      </span>
                    </span>
                    <p className="text-xs text-[#2D3A3A] font-semibold">
                      Agora VoIP Call • ১০০% গোপন ইন-অ্যাপ অডিও কল
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-[#2D5A27] group-hover:translate-x-1 transition" />
              </div>

              <div className="flex items-center gap-1 text-[11px] text-[#5A6B6B] bg-white/80 p-2 rounded-xl border border-[#E6E0D4]/70">
                <ShieldCheck className="w-3.5 h-3.5 text-[#27AE60] shrink-0" />
                <span>আপনার ও অপর প্রান্তের ব্যক্তিগত ফোন নম্বর সম্পূর্ণ গোপন থাকবে।</span>
              </div>

              <button
                type="button"
                className="w-full py-2 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold text-xs rounded-xl transition shadow-xs flex items-center justify-center gap-1.5 cursor-pointer pointer-events-none"
              >
                <PhoneCall className="w-3.5 h-3.5 text-[#D4E4BC]" />
                <span>ইন্টারনেট কল দিন (Agora VoIP)</span>
              </button>
            </div>

            {/* BUTTON 2: অফলাইন সাধারণ সিম কল (Direct Cellular Call) */}
            <div 
              onClick={() => {
                if (activeDialTarget.callId) {
                  markCallCallbackDone(activeDialTarget.callId);
                }
                resetMissedCallsBadge(myId);
                const target = activeDialTarget;
                setActiveDialTarget(null);
                setActiveOfflineWarning({
                  name: target.name,
                  phone: target.phone,
                  role: target.role,
                  allowOfflineCall: target.allowOfflineCall
                });
              }}
              className="p-3.5 rounded-2xl border border-[#D4C3A3] bg-[#FAF8F5] hover:bg-orange-50/50 hover:border-[#E8924A] transition cursor-pointer space-y-2 shadow-xs group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-[#E8924A] text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-bold text-xs text-[#2D3A3A] flex items-center gap-1.5">
                      <span>অফলাইন সাধারণ সিম কল (Direct Cellular Call)</span>
                    </span>
                    <p className="text-[11px] text-[#736B5E]">
                      সরাসরি মোবাইল ফোন ডায়ালারে সাধারণ অপারেটর কল
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-[#E8924A] group-hover:translate-x-1 transition" />
              </div>

              <p className="text-[11px] text-[#736B5E] bg-white p-2 rounded-xl border border-[#E6E0D4]">
                ⚠️ এই মাধ্যমে কল করলে আপনার মোবাইল সিম কার্ডের ব্যালেন্স এবং ফোন নম্বর দৃশ্যমান হবে।
              </p>

              <button
                type="button"
                className="w-full py-2 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold text-xs rounded-xl transition shadow-xs flex items-center justify-center gap-1.5 cursor-pointer pointer-events-none"
              >
                <Phone className="w-3.5 h-3.5 text-white" />
                <span>সরাসরি সিম ডায়ালারে কল করুন</span>
              </button>
            </div>

            {/* Optional BUTTON 3: Open Text Chat Window */}
            <button
              type="button"
              onClick={() => {
                const target = activeDialTarget;
                setActiveDialTarget(null);
                onClose();
                onOpenConversation({
                  recipientId: target.phone.replace(/[^0-9]/g, ''),
                  recipientName: target.name,
                  recipientRole: target.role,
                  recipientPhone: target.phone
                });
              }}
              className="w-full py-2.5 bg-white hover:bg-[#FAF8F5] text-[#2D5A27] border-2 border-[#2D5A27] rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
            >
              <MessageSquare className="w-4 h-4" />
              <span>💬 লিখিত চ্যাট উইন্ডো খুলুন</span>
            </button>

            {/* Cancel Button */}
            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => setActiveDialTarget(null)}
                className="px-4 py-1.5 rounded-xl text-xs font-semibold text-[#5A6B6B] hover:text-[#2D3A3A] bg-[#FAF8F5] border border-[#E6E0D4] cursor-pointer"
              >
                বাতিল করুন
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Direct In-App VoIP Call Screen */}
      {activeVoipCall && (
        <InAppVoiceCallModal
          recipientName={activeVoipCall.name}
          recipientRole={activeVoipCall.role || 'ব্যবহারকারী'}
          recipientPhoto={activeVoipCall.avatar}
          recipientSubtitle={activeVoipCall.subtitle || 'ইন-অ্যাপ ইন্টারনেট কল'}
          maskedPhone={maskPhoneNumber(activeVoipCall.phone)}
          rawPhone={activeVoipCall.phone}
          currentUser={currentUser}
          onClose={() => setActiveVoipCall(null)}
        />
      )}

      {/* Offline SIM Call Privacy Warning Modal */}
      {activeOfflineWarning && (
        <OfflineCallWarningModal
          isOpen={true}
          phoneNumber={activeOfflineWarning.phone}
          recipientName={activeOfflineWarning.name}
          recipientRole={activeOfflineWarning.role}
          allowOfflineCall={activeOfflineWarning.allowOfflineCall}
          onProceedOfflineCall={() => {
            const clean = activeOfflineWarning.phone.replace(/[^0-9+]/g, '');
            setActiveOfflineWarning(null);
            if (clean) {
              window.location.href = `tel:${clean}`;
            }
          }}
          onOnlineVoiceCall={() => {
            const target = activeOfflineWarning;
            setActiveOfflineWarning(null);
            setActiveVoipCall({
              name: target.name,
              phone: target.phone,
              role: target.role
            });
          }}
          onOpenOnlineChat={() => {
            const target = activeOfflineWarning;
            setActiveOfflineWarning(null);
            onClose();
            onOpenConversation({
              recipientId: target.phone.replace(/[^0-9]/g, ''),
              recipientName: target.name,
              recipientRole: target.role,
              recipientPhone: target.phone
            });
          }}
          onCancel={() => setActiveOfflineWarning(null)}
        />
      )}
    </>
  );
};
