import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  X, 
  Phone, 
  ShieldCheck, 
  Lock, 
  Sparkles, 
  Check, 
  CheckCheck, 
  User, 
  Clock, 
  Smile, 
  PhoneCall, 
  Mic,
  Play,
  Pause,
  Volume2,
  Ban,
  ShieldAlert,
  Flag
} from 'lucide-react';
import { ChatMessage } from '../../types';
import { UserProfile } from '../../types/auth';
import { 
  subscribeToMessages, 
  saveCloudMessage, 
  markConversationRead, 
  subscribeToUserPresence,
  toggleBlockUser,
  isUserBlocked
} from '../../lib/cloudSync';
import { VoiceChatModal } from '../voice/VoiceChatModal';
import { ReportItemModal } from '../common/ReportItemModal';

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipientId: string;
  recipientName: string;
  recipientRole?: string;
  recipientPhone?: string;
  recipientAvatar?: string;
  recipientPhoto?: string;
  itemTitle?: string;
  itemPrice?: string;
  itemUnit?: string;
  itemPhoto?: string;
  currentUser: UserProfile | null;
  onOpenAuth: (actionName?: string) => void;
  onStartInAppCall?: () => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({
  isOpen,
  onClose,
  recipientId,
  recipientName,
  recipientRole,
  recipientPhone,
  recipientAvatar,
  recipientPhoto,
  itemTitle,
  itemPrice,
  itemUnit,
  itemPhoto,
  currentUser,
  onOpenAuth,
  onStartInAppCall
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [showVoiceModal, setShowVoiceModal] = useState(false);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [isRecipientOnline, setIsRecipientOnline] = useState<boolean>(false);
  const [showEnlargedPhoto, setShowEnlargedPhoto] = useState<boolean>(false);
  const audioInstanceRef = useRef<HTMLAudioElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const displayAvatar = recipientAvatar || recipientPhoto;

  // Generate a consistent deterministic conversation ID between 2 participants
  const [guestId] = useState<string>(() => {
    try {
      let g = localStorage.getItem('polli_chat_guest_id');
      if (!g) {
        g = 'guest_' + Math.floor(100000 + Math.random() * 900000);
        localStorage.setItem('polli_chat_guest_id', g);
      }
      return g;
    } catch (e) {
      return 'guest_' + Date.now();
    }
  });

  const myRawId = currentUser 
    ? (currentUser.phone ? currentUser.phone.replace(/[^0-9]/g, '') : currentUser.id) 
    : guestId;
  const targetRawId = recipientPhone 
    ? recipientPhone.replace(/[^0-9]/g, '') 
    : (recipientId || 'seller');

  const myId = (myRawId || 'guest').replace(/[/\\#?&.\s]/g, '_');
  const targetId = (targetRawId || 'peer').replace(/[/\\#?&.\s]/g, '_');

  // Strip all slashes, spaces, colons, brackets and special chars from title to guarantee 100% valid Firestore paths
  const sanitizedTitle = itemTitle 
    ? '_' + itemTitle.slice(0, 15).replace(/[^a-zA-Z0-9_\u0980-\u09FF]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '') 
    : '';

  const conversationId = [myId, targetId].sort().join('_') + sanitizedTitle;

  // Categorized Islamic Quick Replies based on recipient role & context
  const getContextualQuickReplies = () => {
    if (recipientRole === 'trader') {
      return [
        'আসসালামু আলাইকুম, পণ্যের বর্তমান পাইকারি দর কত?',
        'মাশাআল্লাহ, কত মণ/কেজি একসঙ্গে সরবরাহ দিতে পারবেন?',
        'আল্লাহ আপনার ব্যবসায় বারাকাহ দান করুন। পণ্যের কোয়ালিটি নিশ্চিত কি?',
        'পণ্য বুঝে পাওয়ার পর নগদ বা বিকাশে পেমেন্ট হবে?',
        'ইনশাআল্লাহ, আমি নিয়মিত পাইকারি নিতে আগ্রহী।'
      ];
    }
    if (recipientRole === 'home_entrepreneur') {
      return [
        'আসসালামু আলাইকুম, এটি কি আজকেই ফ্রেশ তৈরি করা হয়েছে?',
        'মাশাআল্লাহ, ঘরোয়া পারিবারিক অনুষ্ঠানের জন্য অর্ডার নিতে পারবেন?',
        'আল্লাহ আপনার ব্যবসায় বারাকাহ দান করুন। হোম ডেলিভারি ব্যবস্থা আছে কি?',
        'ইনশাআল্লাহ, আগামীকাল নির্ধারিত সময়ে ডেলিভারি পাওয়া যাবে?',
        'জাযাকাল্লাহু খাইরান! আপনার ঘরোয়া তৈরি খাবারের মান খুব ভালো।'
      ];
    }
    if (recipientRole === 'laborer') {
      return [
        'আসসালামু আলাইকুম ভাই, আগামীকালের জন্য আপনাদের দল কি ফ্রি আছে?',
        'দৈনিক কাজের সময়সূচি ও হাজিরা কত করে নির্ধারণ করা?',
        'আমাদের জমিতে ধান কাটা ও মাড়াইয়ের জন্য কতজন শ্রমিক পাওয়া যাবে?',
        'ইনশাআল্লাহ, কাল সকালে নির্দিষ্ট সময়ে জমিতে পৌঁছে যাবেন।',
        'আল্লাহ আপনার হালাল শ্রমে ও উপার্জনে বরকত দান করুন।'
      ];
    }
    if (recipientRole === 'driver') {
      return [
        'আসসালামু আলাইকুম ভাই, আপনি এখন কোন স্ট্যান্ড বা লোকেশনে আছেন?',
        'আমি জরুরি যাওয়ার জন্য গাড়ি রিজার্ভ/বুকিং করতে চাই।',
        'গাড়িতে কতজন যাত্রী বা মালামাল নেওয়া সম্ভব?',
        'ভাড়া কত নির্ধারণ করা হবে ভাই?',
        'আল্লাহ আপনার যাত্রা নিরাপদ ও বরকতময় করুন।'
      ];
    }
    if (recipientRole === 'agri_machinery_driver') {
      return [
        'আসসালামু আলাইকুম ভাই, আমাদের জমিতে হাল চাষ/মাটি কাটার জন্য ট্র্যাক্টর/হেস্কোভেটর লাগবে।',
        'আপনি কোন এলাকায় কাজ করছেন এবং কবে সময় দিতে পারবেন?',
        'ঘণ্টা বা বিঘা প্রতি কত ভাড়া রাখা যাবে ভাই?',
        'ইনশাআল্লাহ, কাজ সন্তোষজনক হলে আপনাকে দিয়ে নিয়মিত কাজ করাবো।',
        'আল্লাহ আপনার হালাল শ্রমে ও যন্ত্রে বরকত দান করুন।'
      ];
    }
    if (recipientRole === 'boatman') {
      return [
        'আসসালামু আলাইকুম মাঝি ভাই, ঘাটে কি এখন খেয়া নৌকা/ট্রলার প্রস্তুত আছে?',
        'আমরা কয়েকজন যাত্রী নিয়ে ওপারে যাব, পারাপারের ভাড়া কত?',
        'জরুরি পারাপারের জন্য কি রাতে নৌকা পাওয়া যাবে ভাই?',
        'মালামাল পারাপারের ব্যবস্থা আছে কি?',
        'আল্লাহ আপনার নদী পারাপার ও সফর নিরাপদ করুন।'
      ];
    }
    if (recipientRole === 'farmer') {
      return [
        'আসসালামু আলাইকুম ভাই, খেত থেকে সরাসরি ফ্রেশ পেড়ে দিবেন?',
        'মাশাআল্লাহ, মোট কত মণ বা কেজি বিক্রি করবেন?',
        'সর্বশেষ কত দর রাখা যাবে?',
        'আল্লাহ আপনার ফসলে ও চাষাবাদে বারাকাহ দান করুন।',
        'ইনশাআল্লাহ, আমি সরাসরি এসে নিয়ে যাব।'
      ];
    }
    return [
      'আসসালামু আলাইকুম, কেমন আছেন?',
      'মাশাআল্লাহ, পণ্যটি কি এখনো এভেইলেবল আছে?',
      'আল্লাহ আপনার ব্যবসায় ও রিজিক্বে বারাকাহ দান করুন।',
      'ইনশাআল্লাহ, আমি এটি নিতে আগ্রহী।',
      'সর্বশেষ কত সম্মানজনক দর রাখা যাবে?',
      'জাযাকাল্লাহু খাইরান! আল্লাহ আপনাকে উত্তম প্রতিদান দিন।'
    ];
  };

  const islamicQuickReplies = getContextualQuickReplies();

  // Subscribe to real-time messages from Firebase Cloud
  useEffect(() => {
    if (!isOpen || !conversationId) return;

    // Immediately mark read on open
    if (myId) {
      markConversationRead(conversationId, myId);
    }

    const unsubscribe = subscribeToMessages(conversationId, (liveMessages) => {
      setMessages(liveMessages);
      if (myId) {
        markConversationRead(conversationId, myId);
      }
    });

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [isOpen, conversationId, myId]);

  // Subscribe to real-time recipient online presence
  useEffect(() => {
    if (!isOpen || !targetRawId) return;
    const cleanTarget = recipientPhone ? recipientPhone.replace(/[^0-9]/g, '') : targetRawId;
    const unsub = subscribeToUserPresence(cleanTarget, (presence) => {
      setIsRecipientOnline(!!presence?.isOnline);
    });
    return () => {
      if (unsub) unsub();
    };
  }, [isOpen, targetRawId, recipientPhone]);

  // Auto scroll to bottom
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, [messages, isOpen]);

  // Check if current user has blocked recipient or recipient has blocked current user
  const [isRecipientBlocked, setIsRecipientBlocked] = useState<boolean>(() => {
    return isUserBlocked(myId, targetId, currentUser);
  });
  const [blockToast, setBlockToast] = useState<string | null>(null);
  const [showReportModal, setShowReportModal] = useState(false);

  useEffect(() => {
    setIsRecipientBlocked(isUserBlocked(myId, targetId, currentUser));
  }, [myId, targetId, currentUser]);

  const handleToggleBlock = async () => {
    const nextBlocked = !isRecipientBlocked;
    const confirmMsg = nextBlocked
      ? `আপনি কি নিশ্চিত যে "${recipientName}" কে ব্লক করতে চান? ব্লক করলে তার কোনো কল বা মেসেজ আর আপনার ফোনে আসবে না।`
      : `আপনি কি "${recipientName}" এর ব্লক প্রত্যাহার (Unblock) করতে চান?`;

    if (window.confirm(confirmMsg)) {
      const res = await toggleBlockUser(myId, targetId, nextBlocked);
      setIsRecipientBlocked(res.isBlocked);
      setBlockToast(res.isBlocked ? `🚫 "${recipientName}" কে সফলভাবে ব্লক করা হয়েছে` : `✓ "${recipientName}" এর ব্লক প্রত্যাহার করা হয়েছে`);
      setTimeout(() => setBlockToast(null), 4000);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    if (isRecipientBlocked) {
      alert('এই ব্যবহারকারীকে আপনি ব্লক করে রেখেছেন। মেসেজ পাঠাতে চাইলে আগে আনব্লক করুন।');
      return;
    }

    const text = (textToSend || inputText).trim();
    if (!text) return;

    setIsSending(true);
    const now = new Date();
    const timeFormatted = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      senderId: myId,
      senderName: currentUser?.name || 'সম্মানিত অতিথি ব্যবহারকারী',
      senderRole: currentUser?.role,
      recipientId: targetId,
      recipientName: recipientName,
      conversationId: conversationId,
      text: text,
      timestamp: Date.now(),
      timeFormatted: timeFormatted,
      isRead: false
    };

    try {
      await saveCloudMessage(newMsg);
      setInputText('');
    } catch (err) {
      console.error('Failed to send message:', err);
    } finally {
      setIsSending(false);
    }
  };

  const handleSendVoiceMessage = async (audioUrl: string, duration: number, textSummary: string) => {
    const now = new Date();
    const timeFormatted = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });

    const newVoiceMsg: ChatMessage = {
      id: `msg-voice-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      senderId: myId,
      senderName: currentUser?.name || 'সম্মানিত অতিথি ব্যবহারকারী',
      senderRole: currentUser?.role,
      recipientId: targetId,
      recipientName: recipientName,
      conversationId: conversationId,
      text: textSummary,
      timestamp: Date.now(),
      timeFormatted: timeFormatted,
      isRead: false,
      messageType: 'voice',
      audioUrl: audioUrl,
      audioDuration: duration
    };

    try {
      await saveCloudMessage(newVoiceMsg);
    } catch (err) {
      console.error('Failed to send voice message:', err);
    }
  };

  const togglePlayAudio = (msgId: string, audioUrl?: string) => {
    if (!audioUrl) return;

    if (playingAudioId === msgId) {
      if (audioInstanceRef.current) {
        audioInstanceRef.current.pause();
      }
      setPlayingAudioId(null);
    } else {
      if (audioInstanceRef.current) {
        audioInstanceRef.current.pause();
      }
      const audio = new Audio(audioUrl);
      audioInstanceRef.current = audio;
      setPlayingAudioId(msgId);
      audio.play().catch(e => console.warn('Audio play failed', e));
      audio.onended = () => {
        setPlayingAudioId(null);
      };
    }
  };

  const getRoleBadge = (role?: string) => {
    if (role === 'farmer') return '🌾 সম্মানিত কৃষক ও খামারি';
    if (role === 'laborer') return '🛠️ সম্মানিত কৃষিন ও দিনমজুর';
    if (role === 'driver') return '🚗 সম্মানিত চালক';
    if (role === 'agri_machinery_driver') return '🚜 সম্মানিত ট্র্যাক্টর / হেস্কোভেটর চালক';
    if (role === 'boatman') return '⛵ সম্মানিত নৌকার মাঝি / খেয়া চালক';
    if (role === 'mechanic') return '🔧 সম্মানিত ইলেকট্রিশিয়ান ও মেকার';
    if (role === 'tutor_student') return '📚 সম্মানিত শিক্ষক / ছাত্র-ছাত্রী';
    if (role === 'trader') return '🛍️ সম্মানিত ব্যবসায়ী';
    if (role === 'home_entrepreneur') return '🏡 সম্মানিত গৃহ উদ্যোক্তা';
    if (role === 'doctor') return '👨‍⚕️ সম্মানিত পল্লী চিকিৎসক';
    return '👤 সম্মানিত সাধারণ নাগরিক';
  };

  return (
    <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-lg w-full h-[90vh] sm:h-[650px] shadow-2xl border border-[#E6E0D4] flex flex-col overflow-hidden relative">
        
        {/* Chat Header */}
        <div className="bg-[#2D5A27] text-white p-3.5 sm:p-4 flex items-center justify-between shadow-md shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            {displayAvatar ? (
              <img 
                src={displayAvatar} 
                alt={recipientName} 
                onClick={() => setShowEnlargedPhoto(true)}
                className="w-11 h-11 rounded-2xl object-cover border-2 border-[#D4E4BC] shrink-0 cursor-pointer hover:scale-105 transition" 
                title="ছবি বড় করে দেখতে স্পর্শ করুন"
              />
            ) : (
              <div className="w-11 h-11 rounded-2xl bg-[#1E4620] text-[#D4E4BC] font-bold text-lg flex items-center justify-center border border-[#D4E4BC]/50 shrink-0">
                {recipientName ? recipientName.charAt(0) : 'U'}
              </div>
            )}
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="font-bold text-sm sm:text-base text-white truncate">{recipientName}</h3>
                <ShieldCheck className="w-4 h-4 text-[#D4E4BC] shrink-0" />
                {isRecipientOnline ? (
                  <span className="text-[10px] bg-emerald-800/90 text-emerald-100 font-bold px-2 py-0.2 rounded-full border border-emerald-400 flex items-center gap-1 shadow-2xs animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-300" />
                    <span>অনলাইন</span>
                  </span>
                ) : (
                  <span className="text-[10px] bg-black/20 text-emerald-100/70 font-medium px-1.5 py-0.2 rounded-full">
                    অফলাইন
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-[#D4E4BC] truncate">
                <span className="bg-[#23491E] px-2 py-0.2 rounded-full text-[10px] font-semibold">
                  {getRoleBadge(recipientRole)}
                </span>
                {itemTitle && (
                  <span className="text-[11px] text-white/80 truncate">• {itemTitle}</span>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Report Button (Requirement 6 & 8) */}
            <button
              type="button"
              onClick={() => setShowReportModal(true)}
              className="p-2 sm:px-2.5 sm:py-2 rounded-2xl text-xs font-bold transition cursor-pointer flex items-center gap-1 border shadow-xs bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border-amber-400/30"
              title="ভুয়া অ্যাকাউন্ট বা বিভ্রান্তিকর তথ্যের বিরুদ্ধে অভিযোগ করুন"
            >
              <Flag className="w-4 h-4 text-amber-300" />
              <span className="hidden sm:inline">রিপোর্ট</span>
            </button>

            {/* User-Level Block / Unblock Button */}
            <button
              type="button"
              onClick={handleToggleBlock}
              className={`p-2 sm:px-2.5 sm:py-2 rounded-2xl text-xs font-bold transition cursor-pointer flex items-center gap-1 border shadow-xs ${
                isRecipientBlocked
                  ? 'bg-red-500 hover:bg-red-600 text-white border-red-400'
                  : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
              }`}
              title={isRecipientBlocked ? 'ব্লক প্রত্যাহার করুন (Unblock)' : 'এই ব্যবহারকারীকে ব্লক করুন'}
            >
              <Ban className="w-4 h-4 text-white" />
              <span className="hidden sm:inline">{isRecipientBlocked ? 'আনব্লক' : 'ব্লক'}</span>
            </button>

            {/* In-App Call Button */}
            {onStartInAppCall && (
              <button
                onClick={() => {
                  if (isRecipientBlocked) {
                    alert('আপনি এই ব্যবহারকারীকে ব্লক করেছেন। কল করতে চাইলে আগে আনব্লক করুন।');
                    return;
                  }
                  onStartInAppCall();
                }}
                className={`p-2.5 rounded-2xl text-white shadow-xs transition cursor-pointer flex items-center gap-1 text-xs font-bold ${
                  isRecipientBlocked ? 'bg-gray-500 opacity-60 cursor-not-allowed' : 'bg-[#E8924A] hover:bg-[#D97D35]'
                }`}
                title="সুরক্ষিত ইন-অ্যাপ ইন্টারনেট কল করুন"
              >
                <PhoneCall className="w-4 h-4" />
                <span className="hidden sm:inline">ইন-অ্যাপ কল</span>
              </button>
            )}

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-2 rounded-2xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Block notification toast */}
        {blockToast && (
          <div className="bg-red-600 text-white px-4 py-2 text-xs font-bold flex items-center justify-between shrink-0 shadow-inner animate-in fade-in">
            <span className="flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4" />
              <span>{blockToast}</span>
            </span>
            <button onClick={() => setBlockToast(null)} className="text-white hover:opacity-80">✕</button>
          </div>
        )}

        {/* Recipient Blocked Warning Bar */}
        {isRecipientBlocked && (
          <div className="bg-red-50 border-b border-red-200 px-3.5 py-2 flex items-center justify-between text-xs text-red-900 shrink-0">
            <div className="flex items-center gap-1.5">
              <Ban className="w-4 h-4 text-red-600 shrink-0" />
              <span className="font-semibold">আপনি এই ব্যবহারকারীকে ব্লক করে রেখেছেন। নতুন কোনো মেসেজ বা কল আসবে না।</span>
            </div>
            <button
              type="button"
              onClick={handleToggleBlock}
              className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-[11px] cursor-pointer"
            >
              আনব্লক
            </button>
          </div>
        )}

        {/* Privacy & 7-Day Auto-Purge Notice Bar (Requirement 8) */}
        <div className="bg-[#FAF8F5] border-b border-[#E6E0D4] px-3.5 py-2 flex flex-wrap items-center justify-between text-[11px] text-[#5A6B6B] shrink-0 gap-1.5">
          <div className="flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-[#2D5A27]" />
            <span>১০০% নিরাপদ মেসেজিং • ফোন নম্বর সম্পূর্ণ গোপন</span>
          </div>
          <div className="flex items-center gap-1 text-emerald-800 font-semibold bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 text-[10px]">
            <Clock className="w-3 h-3 text-emerald-600" />
            <span>⏱️ চ্যাট হিস্ট্রি সর্বোচ্চ ৭ দিন সংরক্ষিত (স্বয়ংক্রিয়ভাবে মুছে যায়)</span>
          </div>
        </div>

        {/* Messages Scroll Area - WhatsApp Style Serial Stream */}
        <div className="flex-1 overflow-y-auto p-3.5 sm:p-4 space-y-2 bg-[#FDFBF7]">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 my-auto">
              <div className="w-14 h-14 rounded-3xl bg-[#D4E4BC]/50 text-[#2D5A27] flex items-center justify-center text-2xl shadow-inner">
                💬
              </div>
              <div className="space-y-1 max-w-xs">
                <h4 className="font-bold text-sm text-[#2D3A3A]">
                  {recipientName} এর সাথে চ্যাট শুরু করুন
                </h4>
                <p className="text-xs text-[#736B5E]">
                  নিচের দ্রুত উত্তরগুলো থেকে ট্যাপ করুন অথবা সালাম দিয়ে সরাসরি আপনার মেসেজ লিখুন।
                </p>
              </div>
            </div>
          ) : (
            messages.map((msg, idx) => {
              const isMine = msg.senderId === myId;
              const isVoiceMsg = msg.messageType === 'voice' || (msg.text && msg.text.startsWith('🎙️'));
              
              // WhatsApp Single Consecutive Thread: Check if previous message is from same sender
              const prevMsg = idx > 0 ? messages[idx - 1] : null;
              const isConsecutiveSameSender = prevMsg && (prevMsg.senderId === msg.senderId);

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMine ? 'items-end' : 'items-start'} ${isConsecutiveSameSender ? 'mt-0.5' : 'mt-2'}`}
                >
                  <div
                    className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-3.5 py-2 text-xs sm:text-sm shadow-xs ${
                      isMine
                        ? 'bg-[#2D5A27] text-white rounded-br-xs'
                        : 'bg-white text-[#2D3A3A] border border-[#E6E0D4] rounded-bl-xs'
                    }`}
                  >
                    {/* Only show sender name on first message of a consecutive series */}
                    {!isMine && !isConsecutiveSameSender && (
                      <span className="block text-[10px] font-bold text-[#A65E2E] mb-0.5">
                        {msg.senderName}
                      </span>
                    )}

                    {isVoiceMsg ? (
                      <div className="flex items-center gap-3 py-1">
                        <button
                          type="button"
                          onClick={() => togglePlayAudio(msg.id, msg.audioUrl)}
                          className={`w-8 h-8 rounded-full flex items-center justify-center transition shadow-2xs cursor-pointer ${
                            isMine
                              ? 'bg-white text-[#2D5A27] hover:bg-white/90'
                              : 'bg-[#2D5A27] text-white hover:bg-[#23491E]'
                          }`}
                        >
                          {playingAudioId === msg.id ? (
                            <Pause className="w-4 h-4 fill-current" />
                          ) : (
                            <Play className="w-4 h-4 fill-current ml-0.5" />
                          )}
                        </button>
                        <div>
                          <div className="flex items-center gap-1.5 font-bold text-xs">
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>{msg.text || 'ভয়েস বার্তা'}</span>
                          </div>
                          <span className={`text-[10px] ${isMine ? 'text-white/80' : 'text-[#736B5E]'}`}>
                            {msg.audioDuration ? `${msg.audioDuration} সে.` : 'শুনতে ট্যাপ করুন'}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                    )}
                  </div>
                  
                  {/* Message timestamp and double tick */}
                  <div className="flex items-center gap-1.5 text-[10px] text-[#736B5E] px-1 pt-0.5">
                    <Clock className="w-2.5 h-2.5" />
                    <span>{msg.timeFormatted}</span>
                    {/* WhatsApp-style Double Tick System: 1 Gray Tick (Offline/Sent), 2 Gray Ticks (Online/Delivered), 2 Green Ticks (Read/Seen) */}
                    {isMine && (
                      <span className="flex items-center gap-0.5 ml-1 select-none">
                        {(msg.isRead || msg.deliveryStatus === 'read') ? (
                          <span className="flex items-center gap-0.5 text-[#2ECC71]" title="পঠিত (Seen - ২টি সবুজ দাগ)">
                            <CheckCheck className="w-3.5 h-3.5 text-[#2ECC71]" />
                            <span className="text-[9px] font-bold text-[#2ECC71]">পঠিত</span>
                          </span>
                        ) : (isRecipientOnline || msg.isDelivered || msg.deliveryStatus === 'delivered') ? (
                          <span className="flex items-center gap-0.5 text-gray-400" title="ডেলিভারড (Delivered - ২টি ধূসর দাগ)">
                            <CheckCheck className="w-3.5 h-3.5 text-gray-400" />
                            <span className="text-[9px] font-medium text-gray-400">পৌঁছেছে</span>
                          </span>
                        ) : (
                          <span className="flex items-center gap-0.5 text-gray-400" title="প্রেরিত (Sent - ১টি ধূসর দাগ, অপরপ্রান্ত অফলাইনে)">
                            <Check className="w-3.5 h-3.5 text-gray-400" />
                            <span className="text-[9px] font-medium text-gray-400">প্রেরিত</span>
                          </span>
                        )}
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Islamic Preset Replies */}
        <div className="bg-[#FAF8F5] border-t border-[#E6E0D4] p-2 overflow-x-auto no-scrollbar flex items-center gap-1.5 shrink-0">
          <span className="text-[10px] font-bold text-[#2D5A27] shrink-0 pl-1 flex items-center gap-0.5">
            <Sparkles className="w-3 h-3" />
            <span>দ্রুত বার্তা:</span>
          </span>
          {islamicQuickReplies.map((reply, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(reply)}
              className="bg-white hover:bg-[#D4E4BC]/40 border border-[#E6E0D4] hover:border-[#2D5A27] text-[#2D3A3A] text-[11px] px-2.5 py-1 rounded-full whitespace-nowrap transition cursor-pointer shadow-2xs"
            >
              {reply}
            </button>
          ))}
        </div>

        {/* Message Input Box - Always available for direct custom messages */}
        <div className="p-3 sm:p-4 bg-white border-t border-[#E6E0D4] shrink-0">
          {isRecipientBlocked ? (
            <div className="p-3 bg-gray-50 border border-gray-200 rounded-2xl text-center text-xs text-gray-500 font-medium">
              🔒 আপনি এই ব্যবহারকারীকে ব্লক করেছেন। বার্তা পাঠাতে চাইলে উপরের "আনব্লক" বাটনে চাপুন।
            </div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <button
                type="button"
                onClick={() => setShowVoiceModal(true)}
                title="ভয়েস নোট / অডিও রেকর্ড করুন"
                className="bg-[#D4E4BC] hover:bg-[#2D5A27] text-[#2D5A27] hover:text-white p-2.5 sm:p-3 rounded-2xl font-bold text-xs flex items-center justify-center transition cursor-pointer shadow-2xs shrink-0 active:scale-95"
              >
                <Mic className="w-5 h-5" />
              </button>
              <input
                type="text"
                placeholder="আপনার বার্তা বাংলায় টাইপ করুন (যেমন: আসসালামু আলাইকুম...)..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="flex-1 bg-[#FAF8F5] border border-[#D4C3A3] rounded-2xl px-4 py-3 text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27] font-medium shadow-inner"
              />
              <button
                type="submit"
                disabled={!inputText.trim() || isSending}
                className="bg-[#2D5A27] hover:bg-[#23491E] text-white p-3 sm:px-5 sm:py-3 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer shadow-sm shrink-0 active:scale-95"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">পাঠান</span>
              </button>
            </form>
          )}
          {!currentUser && (
            <div className="mt-2 flex items-center justify-between text-[11px] text-[#736B5E] px-1">
              <span>💬 অতিথি হিসেবে বার্তা পাঠাচ্ছেন</span>
              <button
                type="button"
                onClick={() => onOpenAuth('চ্যাট ও বার্তা সংরক্ষণ করতে')}
                className="text-[#2D5A27] font-bold hover:underline cursor-pointer"
              >
                প্রোফাইল নিবন্ধন / লগইন করুন →
              </button>
            </div>
          )}
        </div>

        {/* Dedicated Voice Chat Recorder Modal */}
        <VoiceChatModal
          isOpen={showVoiceModal}
          onClose={() => setShowVoiceModal(false)}
          recipientName={recipientName}
          recipientRole={recipientRole}
          recipientPhone={recipientPhone}
          recipientAvatar={recipientAvatar}
          itemTitle={itemTitle}
          currentUser={currentUser}
          onSendVoiceMessage={handleSendVoiceMessage}
        />

        {/* Enlarged Photo Lightbox Modal (WhatsApp/Facebook style) */}
        {showEnlargedPhoto && displayAvatar && (
          <div 
            onClick={() => setShowEnlargedPhoto(false)}
            className="fixed inset-0 z-80 bg-black/95 backdrop-blur-md flex flex-col items-center justify-center p-4 animate-in fade-in"
          >
            <div className="relative max-w-sm w-full flex flex-col items-center space-y-4">
              <button
                onClick={() => setShowEnlargedPhoto(false)}
                className="absolute -top-12 right-0 p-2 text-white/80 hover:text-white bg-white/10 rounded-full cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
              <img 
                src={displayAvatar} 
                alt={recipientName} 
                className="w-72 h-72 rounded-full object-cover border-4 border-emerald-500 shadow-2xl" 
              />
              <h4 className="text-xl font-bold text-white text-center">{recipientName}</h4>
              <p className="text-xs text-gray-300">প্রোফাইল ছবি (পূর্ণরূপ)</p>
            </div>
          </div>
        )}

        {/* Report Fake Account or Misleading Info Modal */}
        {showReportModal && (
          <ReportItemModal
            isOpen={showReportModal}
            onClose={() => setShowReportModal(false)}
            targetId={recipientId || recipientPhone || 'chat-target'}
            targetTitle={`${recipientName} (${recipientRole || 'চ্যাট যোগাযোগ'})`}
            targetType="user"
            currentUser={currentUser}
          />
        )}

      </div>
    </div>
  );
};
