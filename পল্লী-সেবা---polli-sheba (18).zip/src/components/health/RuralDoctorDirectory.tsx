import React, { useState, useEffect } from 'react';
import { 
  Stethoscope, 
  Search, 
  MapPin, 
  Phone, 
  PlusCircle, 
  Clock, 
  Award, 
  CheckCircle, 
  Filter, 
  X, 
  Sparkles,
  HeartPulse,
  Syringe,
  AlertCircle,
  LogIn,
  UserCheck
} from 'lucide-react';
import { RuralDoctor } from '../../types';
import { INITIAL_RURAL_DOCTORS } from '../../data/extendedData';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { UserProfile } from '../../types/auth';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';

interface RuralDoctorDirectoryProps {
  currentUser?: UserProfile | null;
  defaultCategory?: 'all' | 'allopathic' | 'homeopathic' | 'village_practical' | 'veterinary';
  onRequireAuth?: () => void;
}

export const RuralDoctorDirectory: React.FC<RuralDoctorDirectoryProps> = ({
  currentUser,
  defaultCategory = 'all',
  onRequireAuth
}) => {
  const [doctors, setDoctors] = useState<RuralDoctor[]>(() => {
    const saved = localStorage.getItem('polli_rural_doctors');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Merge with initial if not already present
          const existingIds = new Set(parsed.map((d: RuralDoctor) => d.id));
          const missingInitial = INITIAL_RURAL_DOCTORS.filter(d => !existingIds.has(d.id));
          return [...missingInitial, ...parsed];
        }
      } catch (e) {
        console.error('Failed to parse saved rural doctors', e);
      }
    }
    return INITIAL_RURAL_DOCTORS;
  });

  const [selectedCategory, setSelectedCategory] = useState<'all' | 'allopathic' | 'homeopathic' | 'village_practical' | 'veterinary'>(defaultCategory);
  const [selectedDistrict, setSelectedDistrict] = useState<string>('সকল জেলা');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [showLoginPrompt, setShowLoginPrompt] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Add Doctor Form State
  const [formData, setFormData] = useState({
    name: '',
    category: 'allopathic' as 'allopathic' | 'homeopathic' | 'village_practical' | 'veterinary',
    degreeOrTraining: '',
    phone: '',
    district: currentUser?.district || 'ঢাকা',
    upazila: currentUser?.upazila || '',
    unionOrBazar: '',
    village: '',
    chamberName: '',
    visitingHours: '',
    experienceYears: '',
    servicesInput: ''
  });
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (defaultCategory) {
      setSelectedCategory(defaultCategory);
    }
  }, [defaultCategory]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const filteredDoctors = doctors.filter((doc) => {
    if (selectedCategory !== 'all' && doc.category !== selectedCategory) {
      return false;
    }
    if (selectedDistrict !== 'সকল জেলা' && doc.district !== selectedDistrict) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = doc.name.toLowerCase().includes(q);
      const matchChamber = doc.chamberName.toLowerCase().includes(q);
      const matchBazar = doc.unionOrBazar.toLowerCase().includes(q);
      const matchUpazila = doc.upazila.toLowerCase().includes(q);
      const matchService = doc.services.some(s => s.toLowerCase().includes(q));
      if (!matchName && !matchChamber && !matchBazar && !matchUpazila && !matchService) {
        return false;
      }
    }
    return true;
  });

  const handleOpenAddModal = () => {
    if (!currentUser) {
      setShowLoginPrompt(true);
      return;
    }
    setShowAddModal(true);
  };

  const handleProceedToLogin = () => {
    setShowLoginPrompt(false);
    if (onRequireAuth) {
      onRequireAuth();
    } else {
      window.location.hash = '#auth';
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      setFormError('অনুগ্রহ করে চিকিৎসকের নাম লিখুন');
      return;
    }
    if (!formData.phone.trim() || formData.phone.length < 11) {
      setFormError('সঠিক ১১ ডিজিটের সচল মোবাইল নম্বর দিন');
      return;
    }
    if (!formData.upazila.trim()) {
      setFormError('উপজেলার নাম লিখুন');
      return;
    }
    if (!formData.chamberName.trim()) {
      setFormError('ফার্মেসি বা চেম্বারের নাম দিন');
      return;
    }

    let categoryLabel = 'এলোপ্যাথিক পল্লী চিকিৎসক (LMAF/RMP)';
    if (formData.category === 'homeopathic') {
      categoryLabel = 'হোমিওপ্যাথিক চিকিৎসক (DHMS)';
    } else if (formData.category === 'village_practical') {
      categoryLabel = 'অভিজ্ঞ গ্রাম্য হাতুড়ে চিকিৎসক (ফার্মেসি ও প্রাথমিক সেবা)';
    } else if (formData.category === 'veterinary') {
      categoryLabel = 'পল্লী পশু চিকিৎসক ও কৃত্রিম প্রজনন কর্মী (Para-Vet)';
    }

    const servicesList = formData.servicesInput.trim()
      ? formData.servicesInput.split(',').map(s => s.trim()).filter(Boolean)
      : ['জরুরি প্রাথমিক চিকিৎসা', 'পরামর্শ ও সেবা'];

    const newDoc: RuralDoctor = {
      id: `rd-user-${Date.now()}`,
      name: formData.name.trim(),
      category: formData.category,
      categoryLabel,
      degreeOrTraining: formData.degreeOrTraining.trim() || 'অভিজ্ঞ পল্লী স্বাস্থ্যকর্মী',
      phone: formData.phone.trim(),
      district: formData.district,
      upazila: formData.upazila.trim(),
      unionOrBazar: formData.unionOrBazar.trim() || 'স্থানীয় বাজার',
      village: formData.village.trim() || '',
      chamberName: formData.chamberName.trim(),
      visitingHours: formData.visitingHours.trim() || 'সকাল ৮:০০ - রাত ৯:০০',
      experienceYears: formData.experienceYears.trim() ? `${formData.experienceYears} বছর` : undefined,
      services: servicesList,
      addedByName: currentUser?.name || 'নিবন্ধিত নাগরিক',
      addedByPhone: currentUser?.phone,
      isVerified: true
    };

    const updated = [newDoc, ...doctors];
    setDoctors(updated);
    localStorage.setItem('polli_rural_doctors', JSON.stringify(updated));

    setShowAddModal(false);
    setFormError(null);
    setFormData({
      name: '',
      category: 'allopathic',
      degreeOrTraining: '',
      phone: '',
      district: currentUser?.district || 'ঢাকা',
      upazila: currentUser?.upazila || '',
      unionOrBazar: '',
      village: '',
      chamberName: '',
      visitingHours: '',
      experienceYears: '',
      servicesInput: ''
    });

    showToast('আলহামদুলিল্লাহ! পল্লী চিকিৎসকের তথ্য সফলভাবে যুক্ত হয়েছে। গ্রামীণ রোগীরা এখন দ্রুত প্রাথমিক সেবা পাবেন।');
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-800 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
            <span className="text-sm font-medium">{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="text-emerald-600 hover:text-emerald-800">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-700 via-emerald-800 to-green-900 text-white p-6 rounded-2xl shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>গ্রামীণ জরুরি প্রাথমিক চিকিৎসা ও প্রাণী সেবা নেটওয়ার্ক</span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold tracking-tight">
              পল্লী চিকিৎসক, ফার্মেসি ও পল্লী পশু চিকিৎসক ডিরেক্টরি
            </h2>
            <p className="text-teal-100 text-sm mt-1 max-w-2xl">
              শহরের দূরবর্তী হাসপাতালের আগেই গ্রামের হাতুড়ে, এলোপ্যাথিক, হোমিওপ্যাথিক ও প্রাণিসম্পদ চিকিৎসকদের ঠিকানা ও তাৎক্ষণিক ফোন সুবিধা।
            </p>
          </div>

          <button
            id="btn-add-rural-doctor"
            onClick={handleOpenAddModal}
            className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold text-sm rounded-xl shadow transition flex items-center justify-center gap-2 flex-shrink-0"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ চিকিৎসকের তথ্য যোগ করুন</span>
          </button>
        </div>
      </div>

      {/* Filters and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-4">
        {/* Category Filter Tabs */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              selectedCategory === 'all'
                ? 'bg-teal-700 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            সকল পল্লী চিকিৎসক ({doctors.length})
          </button>
          <button
            onClick={() => setSelectedCategory('allopathic')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
              selectedCategory === 'allopathic'
                ? 'bg-teal-700 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <HeartPulse className="w-3.5 h-3.5" />
            <span>এলোপ্যাথিক (LMAF/RMP)</span>
          </button>
          <button
            onClick={() => setSelectedCategory('homeopathic')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              selectedCategory === 'homeopathic'
                ? 'bg-teal-700 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            হোমিওপ্যাথিক (DHMS)
          </button>
          <button
            onClick={() => setSelectedCategory('village_practical')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              selectedCategory === 'village_practical'
                ? 'bg-teal-700 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            অভিজ্ঞ হাতুড়ে ও ফার্মেসি
          </button>
          <button
            onClick={() => setSelectedCategory('veterinary')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
              selectedCategory === 'veterinary'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
            }`}
          >
            <Syringe className="w-3.5 h-3.5" />
            <span>পল্লী পশু চিকিৎসক ও এআই কর্মী</span>
          </button>
        </div>

        {/* Search and District Filter */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative sm:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="চিকিৎসকের নাম, ফার্মেসি, বাজার, উপজেলা বা রোগের নাম লিখে খুঁজুন..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
            />
          </div>

          <div>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white text-slate-800"
            >
              <option value="সকল জেলা">সকল জেলা (সমগ্র বাংলাদেশ)</option>
              {BANGLADESH_DISTRICTS.map((dist) => (
                <option key={dist} value={dist}>{dist} জেলা</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Doctor Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDoctors.length > 0 ? (
          filteredDoctors.map((doc) => (
            <div
              key={doc.id}
              className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                {/* Badge Category */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                    doc.category === 'veterinary'
                      ? 'bg-amber-100 text-amber-900 border border-amber-300'
                      : doc.category === 'homeopathic'
                      ? 'bg-purple-100 text-purple-900 border border-purple-300'
                      : doc.category === 'village_practical'
                      ? 'bg-blue-100 text-blue-900 border border-blue-300'
                      : 'bg-teal-100 text-teal-900 border border-teal-300'
                  }`}>
                    {doc.categoryLabel}
                  </span>
                  {doc.experienceYears && (
                    <span className="text-[11px] text-slate-500 flex items-center gap-1">
                      <Award className="w-3 h-3 text-amber-500" />
                      {doc.experienceYears} অভিজ্ঞতা
                    </span>
                  )}
                </div>

                {/* Doctor Name & Chamber */}
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-1.5">
                  <Stethoscope className="w-4 h-4 text-teal-600 flex-shrink-0" />
                  <span>{doc.name}</span>
                </h3>
                <p className="text-xs text-teal-700 font-medium mt-0.5">{doc.degreeOrTraining}</p>

                {/* Location */}
                <div className="mt-2 text-xs text-slate-600 space-y-1">
                  <div className="flex items-start gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 mt-0.5 flex-shrink-0" />
                    <span>
                      <strong className="text-slate-800">{doc.chamberName}</strong>, {doc.unionOrBazar}, {doc.upazila}, {doc.district}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                    <span>{doc.visitingHours}</span>
                  </div>
                </div>

                {/* Services list */}
                <div className="mt-3 pt-2 border-t border-slate-100">
                  <span className="text-[11px] font-semibold text-slate-500 block mb-1">প্রদত্ত সেবাসমূহ:</span>
                  <div className="flex flex-wrap gap-1">
                    {doc.services.map((srv, idx) => (
                      <span key={idx} className="px-1.5 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px]">
                        • {srv}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <div className="text-xs text-slate-600 font-mono">
                  {doc.phone}
                </div>
                <a
                  href={`tel:${doc.phone.replace(/[^0-9]/g, '')}`}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-lg transition flex items-center gap-1 shadow-sm"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>কল দিন</span>
                </a>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full py-12 text-center bg-slate-50 border border-slate-200 rounded-xl">
            <AlertCircle className="w-10 h-10 text-slate-400 mx-auto mb-2" />
            <p className="text-slate-700 font-medium">আপনার নির্বাচিত ফিল্টারে কোনো চিকিৎসকের তথ্য পাওয়া যায়নি</p>
            <p className="text-xs text-slate-500 mt-1">অনুগ্রহ করে জেলা বা ক্যাটাগরি পরিবর্তন করুন অথবা আপনি নিজেই নতুন চিকিৎসকের তথ্য যোগ করুন।</p>
            <button
              onClick={handleOpenAddModal}
              className="mt-3 px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold rounded-lg"
            >
              + নতুন চিকিৎসকের তথ্য দিন
            </button>
          </div>
        )}
      </div>

      {/* Add Doctor Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 my-8">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <PlusCircle className="w-5 h-5 text-teal-600" />
                  <span>পল্লী চিকিৎসক বা পশু চিকিৎসকের তথ্য যোগ</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">আপনার এলাকার পরিচিত অভিজ্ঞ ডাক্তার বা ভেটেরিনারি কর্মীর তথ্য দিন</p>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 mb-4 bg-rose-50 border border-rose-300 text-rose-800 text-xs rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleFormSubmit} className="space-y-3.5 text-xs text-slate-700">
              <div>
                <label className="block font-semibold mb-1 text-slate-800">চিকিৎসকের নাম *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: ডাঃ রফিকুল ইসলাম / করিম ডাক্তার"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-800">চিকিৎসকের ধরণ *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white"
                  >
                    <option value="allopathic">এলোপ্যাথিক পল্লী চিকিৎসক (LMAF/RMP)</option>
                    <option value="homeopathic">হোমিওপ্যাথিক চিকিৎসক (DHMS)</option>
                    <option value="village_practical">অভিজ্ঞ গ্রাম্য হাতুড়ে ও ফার্মেসি</option>
                    <option value="veterinary">পল্লী পশু চিকিৎসক ও কৃত্রিম প্রজনন (DLS)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-800">ডিগ্রি / প্রশিক্ষণ</label>
                  <input
                    type="text"
                    placeholder="যেমন: LMAF / DHMS / প্যারা-ভেট"
                    value={formData.degreeOrTraining}
                    onChange={(e) => setFormData({ ...formData, degreeOrTraining: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-800">মোবাইল নম্বর * (১১ ডিজিট)</label>
                  <input
                    type="tel"
                    required
                    placeholder="01711223344"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-800">অভিজ্ঞতা (বছর)</label>
                  <input
                    type="number"
                    placeholder="যেমন: 12"
                    value={formData.experienceYears}
                    onChange={(e) => setFormData({ ...formData, experienceYears: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Address selector with missing area addition */}
              <div>
                <label className="block text-xs font-semibold mb-1 text-slate-800">চেম্বারের ঠিকানা ও এলাকা *</label>
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                  <CascadingAddressSelector
                    address={{
                      district: formData.district,
                      upazila: formData.upazila,
                      union: formData.unionOrBazar,
                      village: formData.village
                    }}
                    onChange={(addr) => {
                      setFormData({
                        ...formData,
                        district: addr.district,
                        upazila: addr.upazila,
                        unionOrBazar: addr.union,
                        village: addr.village
                      });
                    }}
                    showVillageInput={true}
                    villagePlaceholder="গ্রাম বা মহল্লার নাম"
                    showAddAreaButton={true}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-800">চেম্বার বা ফার্মেসির নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: জনসেবা মেডিকেল স্টোর"
                    value={formData.chamberName}
                    onChange={(e) => setFormData({ ...formData, chamberName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-800">বাজার বা মোড়ের সুনির্দিষ্ট নাম</label>
                  <input
                    type="text"
                    placeholder="যেমন: বিরুলিয়া বাজার, বাসস্ট্যান্ড সংলগ্ন"
                    value={formData.unionOrBazar}
                    onChange={(e) => setFormData({ ...formData, unionOrBazar: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-800">রোগী দেখার সময়সূচি</label>
                <input
                  type="text"
                  placeholder="যেমন: সকাল ৯:০০ - দুপুর ১:০০ এবং বিকাল ৫:০০ - রাত ৯:০০"
                  value={formData.visitingHours}
                  onChange={(e) => setFormData({ ...formData, visitingHours: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-800">প্রদত্ত সেবাসমূহ (কমা দিয়ে লিখুন)</label>
                <input
                  type="text"
                  placeholder="যেমন: প্রাথমিক চিকিৎসা, স্যালাইন, ড্রেসিং, সুগার টেস্ট, গাভী প্রজনন"
                  value={formData.servicesInput}
                  onChange={(e) => setFormData({ ...formData, servicesInput: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-lg font-bold shadow transition"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Beautiful In-App Login Prompt Modal (Replaces browser alert) */}
      {showLoginPrompt && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 text-center relative animate-in fade-in zoom-in-95 duration-200">
            <button
              type="button"
              onClick={() => setShowLoginPrompt(false)}
              className="absolute right-4 top-4 text-slate-400 hover:text-slate-600 p-1.5 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-4">
              <LogIn className="w-7 h-7" />
            </div>

            <h3 className="font-bold text-lg text-slate-900 mb-1.5">
              লগইন বা নিবন্ধন প্রয়োজন
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed mb-5">
              নতুন চিকিৎসকের তথ্য যুক্ত করতে অনুগ্রহ করে আপনার একাউন্টে লগইন করুন। এর ফলে আপনার দেওয়া তথ্য সঠিকভাবে লিপিবদ্ধ থাকবে।
            </p>

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={handleProceedToLogin}
                className="w-full py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-sm font-bold shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <UserCheck className="w-4 h-4" />
                <span>লগইন / নিবন্ধন পেজে যান</span>
              </button>
              <button
                type="button"
                onClick={() => setShowLoginPrompt(false)}
                className="w-full py-2 px-4 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition cursor-pointer"
              >
                পরে করব
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
