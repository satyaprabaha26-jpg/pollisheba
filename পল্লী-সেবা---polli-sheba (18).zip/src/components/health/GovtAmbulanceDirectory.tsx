import React, { useState } from 'react';
import { 
  Ambulance, 
  PhoneCall, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  AlertCircle, 
  DollarSign, 
  Info,
  Search,
  CheckCircle2,
  Car
} from 'lucide-react';
import { GovtAmbulanceInfo } from '../../types';
import { GOVT_AMBULANCE_LIST } from '../../data/extendedData';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';

export const GovtAmbulanceDirectory: React.FC = () => {
  const [selectedDistrict, setSelectedDistrict] = useState<string>('সকল জেলা');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredAmbulances = GOVT_AMBULANCE_LIST.filter((amb) => {
    if (selectedDistrict !== 'সকল জেলা' && amb.district !== selectedDistrict) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchHospital = amb.hospitalName.toLowerCase().includes(q);
      const matchUpazila = amb.upazila.toLowerCase().includes(q);
      const matchDistrict = amb.district.toLowerCase().includes(q);
      if (!matchHospital && !matchUpazila && !matchDistrict) {
        return false;
      }
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-red-700 via-rose-800 to-red-950 text-white p-6 rounded-2xl shadow-md relative overflow-hidden">
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-xs font-semibold mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
            <span>স্বাস্থ্য অধিদপ্তর (DGHS) সরকারি অ্যাম্বুলেন্স ও অনুমোদিত ভাড়া চার্ট</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            সরকারি অ্যাম্বুলেন্স ডিরেক্টরি ও সরকারি ভাড়া নীতিমালা
          </h2>
          <p className="text-rose-100 text-sm mt-1 max-w-2xl">
            উপজেলা স্বাস্থ্য কমপ্লেক্স ও জেলা সদর হাসপাতালের সরকারি নির্ধারিত সুলভ ভাড়ায় জরুরি রোগী পরিবহন। চড়া বেসরকারি সিন্ডিকেট থেকে মুক্তি।
          </p>
        </div>
      </div>

      {/* Govt Fare Guideline Notice Card */}
      <div className="bg-amber-50 border border-amber-300 p-4 rounded-xl shadow-xs">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-700 mt-0.5 flex-shrink-0" />
          <div className="text-xs text-amber-900 space-y-1.5">
            <h4 className="font-bold text-sm text-amber-950">
              সরকারি অ্যাম্বুলেন্স ভাড়া নীতিমালা ও সতর্কবার্তা:
            </h4>
            <ul className="list-disc list-inside space-y-1 text-amber-900/90">
              <li>
                <strong>ভাড়ার হার:</strong> উপজেলা স্বাস্থ্য কমপ্লেক্সের অ্যাম্বুলেন্স প্রতি কিলোমিটার যাতায়াতে সরকারি নির্ধারিত হার ১০ থেকে ১২ টাকা (ফেরত আসা সহ হিসাব) এবং ন্যূনতম ফি ২৫০-৩০০ টাকা।
              </li>
              <li>
                <strong>রশিদ ছাড়া লেনদেন নয়:</strong> যেকোনো সরকারি অ্যাম্বুলেন্স ব্যবহারের সময় হাসপাতাল হিসাব শাখা বা চালকের কাছ থেকে সরকারি ট্রিপ রসিদ (M.R.) অবশ্যই বুঝে নেবেন।
              </li>
              <li>
                <strong>অসচ্ছল রোগীদের জন্য:</strong> চরম দরিদ্র ও অসহায় রোগীদের ক্ষেত্রে হাসপাতালের সমাজসেবা অফিসার অথবা আরএমও (RMO) মহোদয়ের সুপারিশে ভাড়ায় বিশেষ ছাড় বা বিনামূল্যে রোগী বহনের সুবিধা রয়েছে।
              </li>
              <li>
                <strong>জরুরি কেন্দ্রীয় হটলাইন:</strong> ১৬২৬৩ (স্বাস্থ্য বাতায়ন) অথবা ৯৯৯ (জাতীয় জরুরি সেবা)।
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Filters and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-2/3">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="উপজেলা, জেলা বা হাসপাতালের নাম দিয়ে খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
          />
        </div>

        <div className="w-full sm:w-1/3">
          <select
            value={selectedDistrict}
            onChange={(e) => setSelectedDistrict(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white font-medium text-slate-800"
          >
            <option value="সকল জেলা">সকল জেলা (সমগ্র বাংলাদেশ)</option>
            {BANGLADESH_DISTRICTS.map((dist) => (
              <option key={dist} value={dist}>{dist} জেলা</option>
            ))}
          </select>
        </div>
      </div>

      {/* Ambulances Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAmbulances.length > 0 ? (
          filteredAmbulances.map((amb) => (
            <div
              key={amb.id}
              className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:border-rose-300 transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-200">
                    {amb.type}
                  </span>
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                    {amb.acType}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 flex items-start gap-2">
                  <Ambulance className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
                  <span>{amb.hospitalName}</span>
                </h3>

                <div className="mt-2 text-xs text-slate-600 space-y-1">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                    <span>{amb.upazila}, {amb.district}</span>
                  </div>
                  {amb.driverName && (
                    <div className="flex items-center gap-1.5">
                      <Car className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                      <span>{amb.driverName}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
                    <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>২৪ ঘণ্টা জরুরি সেবা সচল</span>
                  </div>
                </div>

                {/* Government Rate Details */}
                <div className="mt-3 p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
                  <div className="flex items-center justify-between text-slate-700">
                    <span className="font-medium">সরকারি সর্বনিম্ন ফি:</span>
                    <span className="font-bold text-slate-900">{amb.baseFareInfo}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-700">
                    <span className="font-medium">কিলোমিটার প্রতি হার:</span>
                    <span className="font-bold text-rose-700">{amb.perKmRate}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <div>
                  <div className="text-xs text-slate-500">জরুরি কন্ট্রোল রুম / চালক:</div>
                  <div className="text-xs font-bold text-slate-800 font-mono">
                    {amb.phone}
                  </div>
                </div>

                <div className="flex gap-2">
                  {amb.controlRoomPhone && (
                    <a
                      href={`tel:${amb.controlRoomPhone.replace(/[^0-9]/g, '')}`}
                      className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-medium text-xs rounded-lg transition"
                      title="হাসপাতাল কন্ট্রোল রুম"
                    >
                      কন্ট্রোল রুম
                    </a>
                  )}
                  <a
                    href={`tel:${amb.phone.replace(/[^0-9]/g, '')}`}
                    className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-lg shadow transition flex items-center gap-1.5"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>কল দিন</span>
                  </a>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full py-10 text-center bg-slate-50 border border-slate-200 rounded-xl">
            <AlertCircle className="w-10 h-10 text-slate-400 mx-auto mb-2" />
            <p className="text-slate-700 font-medium">নির্বাচিত জেলায় সরকারি অ্যাম্বুলেন্স তথ্য লোড হচ্ছে...</p>
            <p className="text-xs text-slate-500 mt-1">জরুরি মুহূর্তে সরাসরি জাতীয় জরুরি সেবা <strong>৯৯৯</strong> বা স্বাস্থ্য বাতায়ন <strong>১৬২৬৩</strong> নম্বরে কল করুন।</p>
            <a
              href="tel:999"
              className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg shadow"
            >
              <PhoneCall className="w-4 h-4" />
              <span>৯৯৯ এ জরুরি কল দিন</span>
            </a>
          </div>
        )}
      </div>
    </div>
  );
};
