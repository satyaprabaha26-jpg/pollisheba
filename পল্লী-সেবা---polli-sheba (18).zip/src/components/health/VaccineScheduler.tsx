import React, { useState } from 'react';
import { ShieldAlert, Calendar, Baby, HeartHandshake, Printer } from 'lucide-react';
import { VACCINE_SCHEDULE_DATA } from '../../data/mockData';
import { toBanglaNumber } from '../../utils/banglaNumbers';

export const VaccineScheduler: React.FC = () => {
  const [babyDob, setBabyDob] = useState<string>('2026-01-15');
  const [babyName, setBabyName] = useState<string>('সন্তানের নাম');

  const calculateDueDate = (dobStr: string, daysToAdd: number): string => {
    const dob = new Date(dobStr);
    if (isNaN(dob.getTime())) return 'তারিখ নির্ধারণ করুন';
    const target = new Date(dob);
    target.setDate(target.getDate() + daysToAdd);
    
    const monthsBn = [
      'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
      'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
    ];
    return `${toBanglaNumber(target.getDate())} ${monthsBn[target.getMonth()]}, ${toBanglaNumber(target.getFullYear())}`;
  };

  const scheduleWithDates = [
    {
      ...VACCINE_SCHEDULE_DATA[0],
      dueDate: calculateDueDate(babyDob, 0),
      timeline: 'জন্মের সাথে সাথে'
    },
    {
      ...VACCINE_SCHEDULE_DATA[1],
      dueDate: calculateDueDate(babyDob, 42),
      timeline: '৬ সপ্তাহ (দেড় মাস)'
    },
    {
      ...VACCINE_SCHEDULE_DATA[2],
      dueDate: calculateDueDate(babyDob, 70),
      timeline: '১০ সপ্তাহ (আড়াই মাস)'
    },
    {
      ...VACCINE_SCHEDULE_DATA[3],
      dueDate: calculateDueDate(babyDob, 98),
      timeline: '১৪ সপ্তাহ (সাড়ে তিন মাস)'
    },
    {
      ...VACCINE_SCHEDULE_DATA[4],
      dueDate: calculateDueDate(babyDob, 270),
      timeline: '৯ মাস পূর্ণ হলে'
    },
    {
      ...VACCINE_SCHEDULE_DATA[5],
      dueDate: calculateDueDate(babyDob, 450),
      timeline: '১৫ মাস পূর্ণ হলে'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm">
        <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
          💉 জাতীয় ইপিআই টিকাদান ক্যালেন্ডার
        </span>
        <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
          শিশুর বয়স অনুযায়ী টিকাদানের স্বয়ংক্রিয় সময়সূচী
        </h2>
        <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
          শিশুর জন্মতারিখ প্রদান করে ১০টি মারাত্মক রোগ প্রতিরোধক সরকারি বিনামূল্যে টিকার তারিখ জেনে নিন
        </p>
      </div>

      {/* Date of birth selector */}
      <div className="bg-white border border-[#E6E0D4] rounded-3xl p-5 shadow-xs flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-3 items-center w-full sm:w-auto">
          <div className="flex items-center gap-2 text-[#2D5A27] font-bold text-xs sm:text-sm">
            <Baby className="w-5 h-5 text-[#2D5A27]" />
            <span>শিশুর নাম:</span>
          </div>
          <input
            type="text"
            value={babyName}
            onChange={(e) => setBabyName(e.target.value)}
            className="border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-medium text-[#2D3A3A]"
            placeholder="সন্তানের নাম লিখুন"
          />

          <div className="flex items-center gap-2 text-[#2D5A27] font-bold text-xs sm:text-sm sm:ml-4">
            <Calendar className="w-5 h-5 text-[#2D5A27]" />
            <span>জন্মতারিখ:</span>
          </div>
          <input
            type="date"
            value={babyDob}
            onChange={(e) => setBabyDob(e.target.value)}
            className="border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-medium text-[#2D3A3A]"
          />
        </div>

        <button
          onClick={() => window.print()}
          className="flex items-center gap-2 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold px-5 py-2.5 rounded-2xl text-xs sm:text-sm transition cursor-pointer shadow-xs whitespace-nowrap"
        >
          <Printer className="w-4 h-4" />
          <span>টিকা কার্ড প্রিন্ট করুন</span>
        </button>
      </div>

      {/* Schedule Timeline */}
      <div className="space-y-3.5">
        {scheduleWithDates.map((item, idx) => (
          <div
            key={item.id}
            className="bg-white border border-[#E6E0D4] rounded-3xl p-5 shadow-xs hover:border-[#2D5A27] transition"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E6E0D4] pb-3.5">
              <div className="flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs flex items-center justify-center flex-shrink-0">
                  {toBanglaNumber(idx + 1)}
                </span>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                    {item.vaccineName}
                  </h3>
                  <span className="text-xs font-semibold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                    বয়সসীমা: {item.targetAge}
                  </span>
                </div>
              </div>

              <div className="bg-[#F9E5D4]/60 border border-[#F9E5D4] px-3.5 py-2 rounded-2xl text-right">
                <span className="text-[11px] text-[#A65E2E] block">টিকা দেওয়ার সম্ভাব্য তারিখ:</span>
                <span className="text-xs sm:text-sm font-bold text-[#A65E2E] font-['Noto_Sans_Bengali']">
                  {item.dueDate}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3.5 text-xs">
              <div className="bg-[#FDFBF7] p-3 rounded-2xl border border-[#E6E0D4]">
                <span className="font-bold text-[#2D3A3A] block mb-0.5">যেসব রোগ প্রতিরোধ করে:</span>
                <p className="text-[#5A6B6B]">{item.diseasesPrevented}</p>
              </div>

              <div className="bg-[#FDFBF7] p-3 rounded-2xl border border-[#E6E0D4]">
                <span className="font-bold text-[#2D3A3A] block mb-0.5">ডোজ ও দেওয়ার নিয়ম:</span>
                <p className="text-[#5A6B6B]">{item.doses} ({item.route})</p>
              </div>
            </div>

            <div className="mt-3 text-[11px] text-[#2D5A27] flex items-center gap-1.5 font-medium">
              <ShieldAlert className="w-3.5 h-3.5 text-[#2D5A27]" />
              <span>{item.importance}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="p-4 bg-[#D4E4BC]/40 border border-[#D4E4BC] rounded-3xl flex items-start gap-3 text-xs text-[#2D5A27] leading-relaxed">
        <HeartHandshake className="w-5 h-5 text-[#2D5A27] flex-shrink-0 mt-0.5" />
        <div>
          <strong>জরুরি তথ্য: </strong>
          নিকটস্থ কমিউনিটি ক্লিনিক, ইউনিয়ন স্বাস্থ্য কেন্দ্র বা সরকারি ইপিআই টিকাদান কেন্দ্রে গিয়ে বিনামূল্যে শিশুকে সব কয়টি ডোজ সময়মতো সম্পন্ন করুন। কোনো ডোজ মিস হয়ে গেলেও স্বাস্থ্যকর্মীর সাথে পরামর্শ করে পুনরায় শুরু করা যায়।
        </div>
      </div>
    </div>
  );
};
