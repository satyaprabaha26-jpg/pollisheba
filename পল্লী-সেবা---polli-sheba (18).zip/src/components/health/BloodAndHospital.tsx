import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Search, 
  MapPin, 
  PhoneCall, 
  PlusCircle, 
  Check, 
  Navigation as NavIcon, 
  Clock, 
  Building2, 
  Calendar,
  AlertTriangle,
  UserCheck
} from 'lucide-react';
import { 
  INITIAL_BLOOD_DONORS, 
  BLOOD_BANKS_DATA, 
  HOSPITALS_DATA, 
  DOCTOR_SCHEDULES_DATA 
} from '../../data/extendedData';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { BloodDonor, HospitalInfo, DoctorSchedule } from '../../types';

interface BloodAndHospitalProps {
  currentDistrict: string;
}

export const BloodAndHospital: React.FC<BloodAndHospitalProps> = ({ currentDistrict }) => {
  const [activeTab, setActiveTab] = useState<'donors' | 'hospitals' | 'doctors'>('donors');
  const [selectedBloodGroup, setSelectedBloodGroup] = useState<string>('সকল রক্ত');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showRegisterModal, setShowRegisterModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Donors state with persistence
  const [donors, setDonors] = useState<BloodDonor[]>(() => {
    const saved = localStorage.getItem('polli_blood_donors');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_BLOOD_DONORS;
      }
    }
    return INITIAL_BLOOD_DONORS;
  });

  // Form State for new donor
  const [donorName, setDonorName] = useState('');
  const [donorBloodGroup, setDonorBloodGroup] = useState<BloodDonor['bloodGroup']>('O+');
  const [donorPhone, setDonorPhone] = useState('');
  const [donorDistrict, setDonorDistrict] = useState(currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা');
  const [donorUpazila, setDonorUpazila] = useState('');
  const [donorVillage, setDonorVillage] = useState('');

  useEffect(() => {
    localStorage.setItem('polli_blood_donors', JSON.stringify(donors));
  }, [donors]);

  const bloodGroups = ['সকল রক্ত', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

  const filteredDonors = donors.filter((d) => {
    const matchesGroup = selectedBloodGroup === 'সকল রক্ত' || d.bloodGroup === selectedBloodGroup;
    const matchesDistrict = currentDistrict === 'সকল জেলা' || d.district === currentDistrict;
    const matchesSearch = 
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.villageOrArea.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.upazila.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.district.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGroup && matchesDistrict && matchesSearch;
  });

  const filteredHospitals = HOSPITALS_DATA.filter((h) => {
    const matchesDistrict = currentDistrict === 'সকল জেলা' || h.district === currentDistrict;
    const matchesSearch = 
      h.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.services.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesDistrict && matchesSearch;
  });

  const filteredDoctors = DOCTOR_SCHEDULES_DATA.filter((doc) => {
    const matchesDistrict = currentDistrict === 'সকল জেলা' || doc.district === currentDistrict;
    const matchesSearch = 
      doc.doctorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.speciality.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.hospitalOrClinic.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesDistrict && matchesSearch;
  });

  const handleRegisterDonor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!donorName || !donorPhone || !donorVillage) return;

    const newDonor: BloodDonor = {
      id: `donor-${Date.now()}`,
      name: donorName,
      bloodGroup: donorBloodGroup,
      phone: donorPhone,
      district: donorDistrict,
      upazila: donorUpazila || 'সদর',
      villageOrArea: donorVillage,
      lastDonationDate: 'নতুন নিবন্ধিত',
      isAvailable: true,
      totalDonations: 1
    };

    setDonors([newDonor, ...donors]);
    setShowRegisterModal(false);
    setToastMessage('ধন্যবাদ! আপনি সফলভাবে স্বেচ্ছায় রক্তদাতা হিসেবে নিবন্ধিত হয়েছেন।');
    setTimeout(() => setToastMessage(null), 4000);

    // reset
    setDonorName('');
    setDonorPhone('');
    setDonorVillage('');
    setDonorUpazila('');
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
            🩸 জরুরি রক্ত ও হাসপাতাল সেবা
          </span>
          <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
            জরুরি রক্তদাতা ও হাসপাতাল ডিরেক্টরি
          </h2>
          <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
            তাৎক্ষণিক রক্তের সন্ধানে রক্তদাতা ও ব্লাড ব্যাংক, সরকারি হাসপাতালের জরুরি নম্বর, ম্যাপ এবং ডাক্তারের সময়সূচি
          </p>
        </div>

        <button
          onClick={() => setShowRegisterModal(true)}
          className="flex items-center gap-2 bg-[#E8924A] hover:bg-[#D47D35] text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-2xl shadow-xs transition cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" />
          <span>রক্তদাতা হিসেবে নাম যুক্ত করুন</span>
        </button>
      </div>

      {toastMessage && (
        <div className="p-4 bg-[#D4E4BC]/40 border border-[#D4E4BC] text-[#2D5A27] rounded-2xl text-xs sm:text-sm flex items-center gap-2 font-medium">
          <Check className="w-4 h-4 text-[#2D5A27]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Mode Tabs */}
      <div className="flex flex-wrap gap-2 bg-white p-2 rounded-2xl border border-[#E6E0D4] max-w-2xl">
        <button
          onClick={() => setActiveTab('donors')}
          className={`flex-1 min-w-[140px] py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
            activeTab === 'donors' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          🩸 রক্তদাতা ও ব্লাড ব্যাংক
        </button>
        <button
          onClick={() => setActiveTab('hospitals')}
          className={`flex-1 min-w-[140px] py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
            activeTab === 'hospitals' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          🏥 সরকারি হাসপাতাল ও ম্যাপ
        </button>
        <button
          onClick={() => setActiveTab('doctors')}
          className={`flex-1 min-w-[140px] py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
            activeTab === 'doctors' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          👨‍⚕️ ডাক্তারের সময়সূচি ও সিরিয়াল
        </button>
      </div>

      {/* TAB 1: BLOOD DONORS & BANKS */}
      {activeTab === 'donors' && (
        <div className="space-y-6">
          {/* Blood Groups Selector */}
          <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                <Heart className="w-4 h-4 text-[#C0392B]" />
                <span>রক্তের গ্রুপ নির্বাচন করুন:</span>
              </span>

              <div className="relative w-48 sm:w-64">
                <Search className="w-3.5 h-3.5 text-[#736B5E] absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="এলাকা বা নাম..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-[#FDFBF7] border border-[#E6E0D4] rounded-xl text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {bloodGroups.map((bg) => (
                <button
                  key={bg}
                  onClick={() => setSelectedBloodGroup(bg)}
                  className={`px-3.5 py-1.5 rounded-2xl text-xs font-bold transition cursor-pointer ${
                    selectedBloodGroup === bg
                      ? 'bg-[#C0392B] text-white shadow-xs'
                      : 'bg-[#FDFBF7] text-[#2D3A3A] hover:bg-[#F9E5D4] border border-[#E6E0D4]'
                  }`}
                >
                  {bg}
                </button>
              ))}
            </div>
          </div>

          {/* Donors Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDonors.map((donor) => (
              <div
                key={donor.id}
                className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 shadow-xs transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="w-10 h-10 rounded-2xl bg-[#F9E5D4] text-[#C0392B] border border-[#F9E5D4] font-black text-sm flex items-center justify-center shadow-xs">
                      {donor.bloodGroup}
                    </span>

                    <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold border ${
                      donor.isAvailable 
                        ? 'bg-[#D4E4BC]/50 text-[#2D5A27] border-[#D4E4BC]' 
                        : 'bg-gray-100 text-gray-500 border-gray-200'
                    }`}>
                      {donor.isAvailable ? '✓ রক্তদানে প্রস্তুত' : 'সাময়িক বিরতি'}
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                    {donor.name}
                  </h3>

                  <div className="mt-2 text-xs text-[#736B5E] space-y-1">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                      <span>{donor.villageOrArea}, {donor.upazila}, {donor.district}</span>
                    </div>
                    {donor.lastDonationDate && (
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-[#736B5E]" />
                        <span>সর্বশেষ রক্তদান: {donor.lastDonationDate}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#E6E0D4]">
                  <a
                    href={`tel:${donor.phone}`}
                    className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2 rounded-2xl text-xs flex items-center justify-center gap-2 shadow-xs transition"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>সরাসরি কল ({donor.phone})</span>
                  </a>
                </div>
              </div>
            ))}
          </div>

          {/* Blood Banks Directory */}
          <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
            <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali'] flex items-center gap-2">
              <Building2 className="w-5 h-5 text-[#2D5A27]" />
              <span>সার্বক্ষণিক জরুরি ব্লাড ব্যাংক ও হটলাইন</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {BLOOD_BANKS_DATA.map((bank) => (
                <div key={bank.id} className="bg-[#FDFBF7] p-4 rounded-2xl border border-[#E6E0D4] space-y-2">
                  <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">{bank.name}</h4>
                  <p className="text-[11px] text-[#736B5E]">{bank.address}</p>
                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-[10px] bg-[#D4E4BC]/50 text-[#2D5A27] font-bold px-2 py-0.5 rounded-full">
                      {bank.timing}
                    </span>
                    <a
                      href={`tel:${bank.emergencyMobile || bank.phone}`}
                      className="bg-[#2D5A27] text-white px-3 py-1 rounded-xl text-xs font-bold flex items-center gap-1"
                    >
                      <PhoneCall className="w-3 h-3" />
                      <span>{bank.emergencyMobile || bank.phone}</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: HOSPITALS & GOOGLE MAPS */}
      {activeTab === 'hospitals' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredHospitals.map((hosp) => (
              <div key={hosp.id} className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 shadow-xs transition space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                      {hosp.type}
                    </span>
                    <h3 className="font-bold text-base text-[#2D3A3A] mt-1.5 font-['Noto_Sans_Bengali']">
                      {hosp.name}
                    </h3>
                  </div>
                </div>

                <p className="text-xs text-[#736B5E] flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                  <span>{hosp.address}</span>
                </p>

                {/* Available Services */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {hosp.services.map((srv, idx) => (
                    <span key={idx} className="text-[10px] bg-[#FDFBF7] text-[#2D3A3A] border border-[#E6E0D4] px-2 py-0.5 rounded-full font-medium">
                      ✓ {srv}
                    </span>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="pt-3 border-t border-[#E6E0D4] grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <a
                    href={`tel:${hosp.emergencyNumber}`}
                    className="bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>জরুরি কল</span>
                  </a>

                  <a
                    href={`tel:${hosp.ambulanceNumber}`}
                    className="bg-[#E8924A] hover:bg-[#D47D35] text-white font-bold py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <span>🚑 অ্যাম্বুলেন্স</span>
                  </a>

                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(hosp.googleMapsQuery)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#FDFBF7] hover:bg-[#E6E0D4] text-[#2D3A3A] border border-[#E6E0D4] font-bold py-2 rounded-xl text-xs flex items-center justify-center gap-1.5"
                  >
                    <NavIcon className="w-3.5 h-3.5 text-[#2D5A27]" />
                    <span>ম্যাপে রাস্তা দেখুন</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: DOCTOR SCHEDULES */}
      {activeTab === 'doctors' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredDoctors.map((doc) => (
              <div key={doc.id} className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 shadow-xs transition space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[11px] font-bold text-[#A65E2E] bg-[#F9E5D4] px-2.5 py-0.5 rounded-full border border-[#F9E5D4]">
                      {doc.speciality}
                    </span>
                    <h3 className="font-bold text-base text-[#2D3A3A] mt-1.5 font-['Noto_Sans_Bengali']">
                      {doc.doctorName}
                    </h3>
                    <p className="text-xs text-[#736B5E]">{doc.designation}</p>
                  </div>
                </div>

                <div className="bg-[#FDFBF7] p-3 rounded-2xl border border-[#E6E0D4] space-y-1.5 text-xs text-[#5A6B6B]">
                  <p><strong>হাসপাতাল/চেম্বার:</strong> {doc.hospitalOrClinic}</p>
                  <p className="flex items-center gap-1.5 text-[#2D5A27] font-semibold">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{doc.visitingDays} ({doc.visitingHours})</span>
                  </p>
                  <p><strong>ভিজিট ফি:</strong> <span className="text-[#A65E2E] font-bold">{doc.fee}</span></p>
                </div>

                <div className="pt-2 border-t border-[#E6E0D4]">
                  <a
                    href={`tel:${doc.serialNumber}`}
                    className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-2xl text-xs flex items-center justify-center gap-2 shadow-xs transition"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>সিরিয়ালের জন্য ফোন করুন ({doc.serialNumber})</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* REGISTER DONOR MODAL */}
      {showRegisterModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-xl border border-[#E6E0D4] animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3 mb-4">
              <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali'] flex items-center gap-2">
                <Heart className="w-5 h-5 text-[#C0392B]" />
                <span>স্বেচ্ছায় রক্তদাতা নিবন্ধন ফরম</span>
              </h3>
              <button
                onClick={() => setShowRegisterModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleRegisterDonor} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  রক্তদাতার নাম *
                </label>
                <input
                  type="text"
                  required
                  placeholder="আপনার পূর্ণ নাম"
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    রক্তের গ্রুপ *
                  </label>
                  <select
                    value={donorBloodGroup}
                    onChange={(e) => setDonorBloodGroup(e.target.value as any)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map((bg) => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    মোবাইল নম্বর *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৭xxxxxxxx"
                    value={donorPhone}
                    onChange={(e) => setDonorPhone(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    জেলা *
                  </label>
                  <select
                    value={donorDistrict}
                    onChange={(e) => setDonorDistrict(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    {BANGLADESH_DISTRICTS.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    উপজেলা / থানা *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: সাভার, ঘিওর, সদর"
                    value={donorUpazila}
                    onChange={(e) => setDonorUpazila(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  গ্রাম / এলাকা / বাজার সংলগ্ন *
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: রামপুর বাজার সংলগ্ন"
                  value={donorVillage}
                  onChange={(e) => setDonorVillage(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                />
              </div>

              <div className="p-3 bg-[#D4E4BC]/30 rounded-2xl text-[11px] text-[#2D5A27] flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-[#2D5A27] flex-shrink-0" />
                <span>আপনার দেওয়া তথ্যটি এলাকার রোগীদের জরুরি রক্তের প্রয়োজনে প্রকাশ করা হবে।</span>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#E6E0D4]">
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(false)}
                  className="px-4 py-2 rounded-2xl text-xs font-semibold text-[#736B5E] bg-[#FDFBF7] hover:bg-[#E6E0D4] border border-[#E6E0D4] cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] cursor-pointer shadow-xs"
                >
                  নিবন্ধন সম্পন্ন করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
