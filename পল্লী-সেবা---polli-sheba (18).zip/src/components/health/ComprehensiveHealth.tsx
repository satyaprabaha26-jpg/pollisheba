import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Search, 
  MapPin, 
  PhoneCall, 
  PlusCircle, 
  Check, 
  Navigation as NavIcon, 
  Clock, 
  Building2, 
  Calendar,
  Baby,
  HeartHandshake,
  ShieldCheck,
  AlertTriangle,
  UserCheck,
  Stethoscope,
  Ambulance,
  Compass,
  ChevronDown,
  Filter,
  X,
  User
} from 'lucide-react';
import { 
  INITIAL_BLOOD_DONORS, 
  BLOOD_BANKS_DATA, 
  HOSPITALS_DATA, 
  DOCTOR_SCHEDULES_DATA 
} from '../../data/extendedData';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { getUpazilasForDistrict } from '../../data/bangladeshLocations';
import { BloodDonor, HospitalInfo, DoctorSchedule } from '../../types';
import { CommunityClinics } from './CommunityClinics';
import { VaccineScheduler } from './VaccineScheduler';
import { FirstAidGuide } from './FirstAidGuide';
import { RuralDoctorDirectory } from './RuralDoctorDirectory';
import { GovtAmbulanceDirectory } from './GovtAmbulanceDirectory';
import { subscribeToDonors, saveCloudDonor, subscribeToAllOnlineUsers, isUserKeyOnline } from '../../lib/cloudSync';
import { UserProfile, getUserFormDefaults } from '../../types/auth';
import { OfflineCallWarningModal } from '../common/OfflineCallWarningModal';
import { maskPhoneNumber } from '../transport/RuralTransport';

interface ComprehensiveHealthProps {
  currentDistrict: string;
  currentUser?: UserProfile | null;
  initialTab?: 'donors' | 'rural_doctors' | 'ambulances' | 'hospitals' | 'doctors' | 'clinics' | 'vaccine' | 'firstaid';
}

export const ComprehensiveHealth: React.FC<ComprehensiveHealthProps> = ({ currentDistrict, currentUser, initialTab }) => {
  const [activeTab, setActiveTab] = useState<'donors' | 'rural_doctors' | 'ambulances' | 'hospitals' | 'doctors' | 'clinics' | 'vaccine' | 'firstaid'>(initialTab || 'donors');

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);
  const [selectedBloodGroup, setSelectedBloodGroup] = useState<string>('সকল রক্ত');
  const [filterDistrict, setFilterDistrict] = useState<string>(currentDistrict || 'সকল জেলা');
  const [filterUpazila, setFilterUpazila] = useState<string>('সকল উপজেলা');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showRegisterModal, setShowRegisterModal] = useState<boolean>(false);
  const [showDoctorModal, setShowDoctorModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    setFilterDistrict(currentDistrict || 'সকল জেলা');
    setFilterUpazila('সকল উপজেলা');
  }, [currentDistrict]);

  // Offline Call Warning Modal State
  const [offlineCallTarget, setOfflineCallTarget] = useState<{
    isOpen: boolean;
    phoneNumber: string;
    recipientName?: string;
    recipientRole?: string;
  }>({
    isOpen: false,
    phoneNumber: '',
    recipientName: '',
    recipientRole: ''
  });

  const handleInitiateOfflineCall = (phone: string, name?: string, role?: string) => {
    setOfflineCallTarget({
      isOpen: true,
      phoneNumber: phone,
      recipientName: name,
      recipientRole: role
    });
  };

  // Real-time online presence tracking
  const [onlineUsersMap, setOnlineUsersMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const unsub = subscribeToAllOnlineUsers((map) => {
      setOnlineUsersMap(map);
    });
    return () => {
      if (unsub) unsub();
    };
  }, []);

  const handleOpenDonorProfile = (donor: BloodDonor) => {
    const userPayload: Partial<UserProfile> = {
      id: donor.id || donor.phone,
      name: donor.name,
      phone: donor.phone,
      role: 'citizen',
      district: donor.district,
      upazila: donor.upazila,
      bloodGroup: donor.bloodGroup,
      isBloodDonor: true,
      allowOfflineCall: true,
      isLiveVerified: true,
      verificationBadgeText: `🛡️ ভেরিফাইড রক্তদাতা (${donor.bloodGroup})`
    };
    window.dispatchEvent(new CustomEvent('polli_open_public_profile', { detail: { user: userPayload } }));
  };

  const handleProceedOfflineCall = () => {
    const rawPhone = offlineCallTarget.phoneNumber;
    setOfflineCallTarget(prev => ({ ...prev, isOpen: false }));
    window.location.href = `tel:${rawPhone.replace(/[^0-9+]/g, '')}`;
  };

  // Donors state with persistence
  const [donors, setDonors] = useState<BloodDonor[]>(() => {
    const saved = localStorage.getItem('polli_blood_donors');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_BLOOD_DONORS;
      }
    }
    return INITIAL_BLOOD_DONORS;
  });

  // Doctors state with persistence
  const [doctors, setDoctors] = useState<DoctorSchedule[]>(() => {
    const saved = localStorage.getItem('polli_doctor_schedules');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DOCTOR_SCHEDULES_DATA;
      }
    }
    return DOCTOR_SCHEDULES_DATA;
  });

  // Form State for new donor (Auto-filled from user profile)
  const [donorName, setDonorName] = useState('');
  const [donorBloodGroup, setDonorBloodGroup] = useState<BloodDonor['bloodGroup']>('O+');
  const [donorPhone, setDonorPhone] = useState('');
  const [donorDistrict, setDonorDistrict] = useState(currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা');
  const [donorUpazila, setDonorUpazila] = useState('');
  const [donorVillage, setDonorVillage] = useState('');
  const [donorAllowOfflineCall, setDonorAllowOfflineCall] = useState<boolean>(false);

  // Synchronize auto-fill whenever modal opens or currentUser changes
  const populateDonorFormWithDefaults = () => {
    const defaults = getUserFormDefaults(currentUser);
    if (defaults.name) setDonorName(defaults.name);
    if (defaults.phone) setDonorPhone(defaults.phone);
    if (defaults.district && defaults.district !== 'সকল জেলা') {
      setDonorDistrict(defaults.district);
    } else if (currentDistrict !== 'সকল জেলা') {
      setDonorDistrict(currentDistrict);
    }
    if (defaults.upazila) setDonorUpazila(defaults.upazila);
    if (defaults.village) setDonorVillage(defaults.village);
    setDonorAllowOfflineCall(defaults.allowOfflineCall);
  };

  const handleOpenRegisterModal = () => {
    populateDonorFormWithDefaults();
    setShowRegisterModal(true);
  };

  useEffect(() => {
    populateDonorFormWithDefaults();
  }, [currentUser, currentDistrict]);

  // Form State for new Doctor / Chamber
  const [docName, setDocName] = useState('');
  const [docDesignation, setDocDesignation] = useState('');
  const [docSpeciality, setDocSpeciality] = useState('মেডিসিন');
  const [docHospital, setDocHospital] = useState('');
  const [docVisitingDays, setDocVisitingDays] = useState('শনি থেকে বৃহস্পতি');
  const [docVisitingHours, setDocVisitingHours] = useState('বিকাল ৪:০০ - রাত ৮:০০');
  const [docSerialNumber, setDocSerialNumber] = useState('');
  const [docFee, setDocFee] = useState('৫০০ টাকা');
  const [docDistrict, setDocDistrict] = useState(currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা');

  useEffect(() => {
    const unsubscribe = subscribeToDonors((updatedDonors) => {
      setDonors(updatedDonors);
    });
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('polli_blood_donors', JSON.stringify(donors));
  }, [donors]);

  useEffect(() => {
    localStorage.setItem('polli_doctor_schedules', JSON.stringify(doctors));
  }, [doctors]);

  const bloodGroups = ['সকল রক্ত', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

  const filteredDonors = donors.filter((d) => {
    const matchesGroup = selectedBloodGroup === 'সকল রক্ত' || d.bloodGroup === selectedBloodGroup;
    const matchesDistrict = filterDistrict === 'সকল জেলা' || d.district === filterDistrict;
    const matchesUpazila = filterUpazila === 'সকল উপজেলা' || !filterUpazila || d.upazila === filterUpazila;
    const matchesSearch = 
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.villageOrArea.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.upazila.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.district.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGroup && matchesDistrict && matchesUpazila && matchesSearch;
  });

  const filteredHospitals = HOSPITALS_DATA.filter((h) => {
    const matchesDistrict = currentDistrict === 'সকল জেলা' || h.district === currentDistrict;
    const matchesSearch = 
      h.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.services.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesDistrict && matchesSearch;
  });

  const filteredDoctors = doctors.filter((doc) => {
    const matchesDistrict = currentDistrict === 'সকল জেলা' || doc.district === currentDistrict;
    const matchesSearch = 
      doc.doctorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.speciality.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.hospitalOrClinic.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesDistrict && matchesSearch;
  });

  const handleRegisterDonor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!donorName || !donorPhone || !donorVillage) return;

    const newDonor: BloodDonor = {
      id: `donor-${Date.now()}`,
      name: donorName,
      bloodGroup: donorBloodGroup,
      phone: donorPhone,
      district: donorDistrict,
      upazila: donorUpazila || 'সদর',
      villageOrArea: donorVillage,
      lastDonationDate: 'নতুন নিবন্ধিত',
      isAvailable: true,
      totalDonations: 1
    };

    setDonors([newDonor, ...donors]);
    saveCloudDonor(newDonor);
    setShowRegisterModal(false);
    setToastMessage('ধন্যবাদ! আপনি সফলভাবে ক্লাউড ডাটাবেজে স্বেচ্ছায় রক্তদাতা হিসেবে নিবন্ধিত হয়েছেন।');
    setTimeout(() => setToastMessage(null), 4000);

    // reset
    setDonorName('');
    setDonorPhone('');
    setDonorVillage('');
    setDonorUpazila('');
  };

  const handleRegisterDoctor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docName || !docSerialNumber || !docHospital) return;

    const newDoctor: DoctorSchedule = {
      id: `doc-${Date.now()}`,
      doctorName: docName,
      designation: docDesignation || 'অভিজ্ঞ চিকিৎসক',
      speciality: docSpeciality,
      hospitalOrClinic: docHospital,
      district: docDistrict,
      visitingDays: docVisitingDays || 'প্রতিদিন',
      visitingHours: docVisitingHours || 'বিকাল ৪টা - রাত ৮টা',
      serialNumber: docSerialNumber,
      fee: docFee || 'আলোচনা সাপেক্ষে'
    };

    setDoctors([newDoctor, ...doctors]);
    setShowDoctorModal(false);
    setToastMessage('ডাক্তার বা চেম্বারের তথ্য সফলভাবে তালিকায় যুক্ত হয়েছে!');
    setTimeout(() => setToastMessage(null), 4000);

    // reset
    setDocName('');
    setDocDesignation('');
    setDocHospital('');
    setDocSerialNumber('');
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
            🩺 সমন্বিত স্বাস্থ্য ও জরুরি রক্তসেবা
          </span>
          <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
            জরুরি রক্ত, সরকারি হাসপাতাল ও গ্রামীণ স্বাস্থ্যসেবা
          </h2>
          <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
            রক্তদাতা ও ব্লাড ব্যাংক, সরকারি হাসপাতাল, ডাক্তারের সময়সূচি, কমিউনিটি ক্লিনিক ফ্রি ওষুধ ও শিশু টিকাদান
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => handleOpenRegisterModal()}
            className="flex items-center gap-1.5 bg-[#C0392B] hover:bg-[#A93226] text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-2xl shadow-xs transition cursor-pointer"
          >
            <Heart className="w-4 h-4" />
            <span>রক্তদাতা হন</span>
          </button>

          <button
            onClick={() => setShowDoctorModal(true)}
            className="flex items-center gap-1.5 bg-[#E8924A] hover:bg-[#D47D35] text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-2xl shadow-xs transition cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>ডাক্তার/চেম্বার যুক্ত করুন</span>
          </button>
        </div>
      </div>

      {toastMessage && (
        <div className="p-4 bg-[#D4E4BC]/40 border border-[#D4E4BC] text-[#2D5A27] rounded-2xl text-xs sm:text-sm flex items-center gap-2 font-medium">
          <Check className="w-4 h-4 text-[#2D5A27]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Sub Tabs */}
      <div className="flex flex-wrap gap-2 bg-white p-2 rounded-2xl border border-[#E6E0D4] overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('donors')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'donors' ? 'bg-[#C0392B] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>🩸 রক্তদাতা ও ব্লাড ব্যাংক</span>
        </button>

        <button
          onClick={() => setActiveTab('rural_doctors')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'rural_doctors' ? 'bg-teal-700 text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <Stethoscope className="w-4 h-4" />
          <span>🩺 পল্লী ও পশু চিকিৎসক</span>
        </button>

        <button
          onClick={() => setActiveTab('ambulances')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'ambulances' ? 'bg-rose-700 text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <Ambulance className="w-4 h-4" />
          <span>🚑 সরকারি অ্যাম্বুলেন্স</span>
        </button>

        <button
          onClick={() => setActiveTab('hospitals')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'hospitals' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>🏥 সরকারি হাসপাতাল ও ম্যাপ</span>
        </button>

        <button
          onClick={() => setActiveTab('doctors')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'doctors' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>👨‍⚕️ ডাক্তারের সময়সূচি ও সিরিয়াল</span>
        </button>

        <button
          onClick={() => setActiveTab('clinics')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'clinics' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>💊 কমিউনিটি ক্লিনিক ও ফ্রি ওষুধ</span>
        </button>

        <button
          onClick={() => setActiveTab('vaccine')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'vaccine' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <Baby className="w-4 h-4" />
          <span>👶 ইপিআই টিকাদান ক্যালেন্ডার</span>
        </button>

        <button
          onClick={() => setActiveTab('firstaid')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'firstaid' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <HeartHandshake className="w-4 h-4" />
          <span>🩹 জরুরি প্রাথমিক চিকিৎসা</span>
        </button>
      </div>

      {/* TAB 1: BLOOD DONORS & BANKS */}
      {activeTab === 'donors' && (
        <div className="space-y-6">
          {/* PERMANENT OFFICIAL CARD: BANGLADESH RED CRESCENT SOCIETY BLOOD BANK */}
          <div className="bg-gradient-to-br from-[#FFF5F5] via-white to-[#FDF4F4] border-2 border-[#E74C3C]/40 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4 relative overflow-hidden">
            <div className="absolute -top-12 -right-12 w-36 h-36 bg-[#E74C3C]/5 rounded-full pointer-events-none" />
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E74C3C]/20 pb-4">
              <div className="flex items-start sm:items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-[#E74C3C] text-white flex items-center justify-center font-black text-2xl shadow-sm shrink-0">
                  <span>🌙</span>
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="bg-[#E74C3C] text-white text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full tracking-wider shadow-2xs">
                      ★ স্থায়ী অফিসিয়াল ব্লাড ব্যাংক
                    </span>
                    <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2 py-0.5 rounded-full border border-[#D4E4BC]">
                      ২৪ ঘণ্টা নিরাপদ সরকারি ও প্রাতিষ্ঠানিক সেবা
                    </span>
                  </div>
                  <h3 className="font-extrabold text-base sm:text-lg text-[#2D3A3A] font-['Noto_Sans_Bengali'] mt-1">
                    বাংলাদেশ রেড ক্রিসেন্ট সোসাইটি ব্লাড ব্যাংক (BDRCS)
                  </h3>
                  <p className="text-xs text-[#736B5E]">
                    জাতীয় সদর দপ্তর ও জরুরি ব্লাড সেন্টার, বাংলাদেশ রেড ক্রিসেন্ট সোসাইটি
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="bg-white/90 p-3 rounded-2xl border border-[#F2D7D5] space-y-1">
                <span className="text-[11px] font-bold text-[#E74C3C] flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>কেন্দ্রীয় অবস্থান ও ঠিকানা:</span>
                </span>
                <p className="text-[#2D3A3A] font-medium leading-relaxed">
                  ৭/৫ ঔরঙ্গজেব রোড, মোহাম্মদপুর, ঢাকা-১২০৭ (জাতীয় ব্লাড সেন্টার)
                </p>
              </div>

              <div className="bg-white/90 p-3 rounded-2xl border border-[#F2D7D5] space-y-1">
                <span className="text-[11px] font-bold text-[#2D5A27] flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>রক্তের উপাদান ও নিরাপত্তা:</span>
                </span>
                <p className="text-[#2D3A3A] font-medium leading-relaxed">
                  হোল ব্লাড, ফ্রেশ ফ্রোজেন প্লাজমা (FFP), প্লেটলেট কনসেন্ট্রেট ও পিআরবিসি (১০০% স্ক্রিন্ড)
                </p>
              </div>

              <div className="bg-white/90 p-3 rounded-2xl border border-[#F2D7D5] space-y-1">
                <span className="text-[11px] font-bold text-[#A65E2E] flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>সার্বক্ষণিক জরুরি সেবা:</span>
                </span>
                <p className="text-[#2D3A3A] font-medium leading-relaxed">
                  ২৪ ঘণ্টা জরুরি প্রয়োজনে সরাসরি কল করে রক্তের গ্রুপ ও মজুত জেনে নিন
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => handleInitiateOfflineCall('02-9330188', 'বাংলাদেশ রেড ক্রিসেন্ট ব্লাড ব্যাংক', 'অফিসিয়াল টেলিফোন')}
                  className="bg-[#E74C3C] hover:bg-[#C0392B] text-white font-bold px-4 py-2.5 rounded-2xl text-xs flex items-center gap-2 shadow-xs transition cursor-pointer active:scale-98"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>হটলাইন: ০২-৯৩৩০১৮৮</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleInitiateOfflineCall('01811-458524', 'বাংলাদেশ রেড ক্রিসেন্ট ব্লাড ব্যাংক', 'জরুরি মোবাইল')}
                  className="bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold px-4 py-2.5 rounded-2xl text-xs flex items-center gap-2 shadow-xs transition cursor-pointer active:scale-98"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>জরুরি মোবাইল: ০১৮১১-৪৫৮৫২৪</span>
                </button>
              </div>

              <span className="text-[11px] text-[#736B5E] italic">
                * অফলাইনে কলে কলদাতার মোবাইল নম্বর দৃশ্যমান হওয়ার প্রাইভেসী নোটিশ প্রদর্শিত হবে
              </span>
            </div>
          </div>

          {/* Blood Filters: District, Upazila, Search & Blood Groups */}
          <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* District Selector */}
              <div className="relative">
                <MapPin className="w-4 h-4 text-[#C0392B] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <select
                  value={filterDistrict}
                  onChange={(e) => {
                    setFilterDistrict(e.target.value);
                    setFilterUpazila('সকল উপজেলা');
                  }}
                  aria-label="জেলা দিয়ে ডোনার খুঁজুন"
                  className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl pl-9 pr-7 py-2 text-xs focus:outline-none focus:border-[#C0392B] font-semibold text-[#2D3A3A] cursor-pointer appearance-none"
                >
                  <option value="সকল জেলা">📍 সকল জেলা</option>
                  {BANGLADESH_DISTRICTS.map((d) => (
                    <option key={d} value={d}>
                      {d} জেলা
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>

              {/* Upazila Selector */}
              <div className="relative">
                <Filter className="w-4 h-4 text-[#E8924A] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <select
                  value={filterUpazila}
                  onChange={(e) => setFilterUpazila(e.target.value)}
                  aria-label="উপজেলা দিয়ে ডোনার ফিল্টার করুন"
                  className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl pl-9 pr-7 py-2 text-xs focus:outline-none focus:border-[#C0392B] font-semibold text-[#2D3A3A] cursor-pointer appearance-none"
                >
                  <option value="সকল উপজেলা">
                    {filterDistrict === 'সকল জেলা' ? '📍 সকল উপজেলা' : `📍 ${filterDistrict} এর সকল উপজেলা`}
                  </option>
                  {(filterDistrict !== 'সকল জেলা' ? getUpazilasForDistrict(filterDistrict) : []).map((u) => (
                    <option key={u} value={u}>
                      {u} উপজেলা
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>

              {/* Search box */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-[#736B5E] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  placeholder="উপজেলা, গ্রাম বা নাম..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-7 py-2 bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl text-xs text-[#2D3A3A] focus:outline-none focus:border-[#C0392B]"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Blood Groups Selector */}
            <div className="pt-2 border-t border-[#E6E0D4] flex items-center gap-2 overflow-x-auto no-scrollbar">
              <span className="text-[11px] font-bold text-[#2D3A3A] whitespace-nowrap flex items-center gap-1">
                <Heart className="w-3.5 h-3.5 text-[#C0392B]" />
                <span>রক্তের গ্রুপ:</span>
              </span>
              <div className="flex flex-wrap gap-1.5">
                {bloodGroups.map((bg) => (
                  <button
                    key={bg}
                    onClick={() => setSelectedBloodGroup(bg)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                      selectedBloodGroup === bg
                        ? 'bg-[#C0392B] text-white shadow-xs'
                        : 'bg-[#FAF8F5] text-[#2D3A3A] hover:bg-[#F9E5D4] border border-[#E6E0D4]'
                    }`}
                  >
                    {bg}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Donors Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDonors.map((donor) => (
              <div
                key={donor.id}
                className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 shadow-xs transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="w-10 h-10 rounded-2xl bg-[#F9E5D4] text-[#C0392B] border border-[#F9E5D4] font-black text-sm flex items-center justify-center shadow-xs">
                      {donor.bloodGroup}
                    </span>

                    <div className="flex items-center gap-1.5">
                      <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold border ${
                        donor.isAvailable 
                          ? 'bg-[#D4E4BC]/50 text-[#2D5A27] border-[#D4E4BC]' 
                          : 'bg-gray-100 text-gray-500 border-gray-200'
                      }`}>
                        {donor.isAvailable ? '✓ রক্তদানে প্রস্তুত' : 'সাময়িক বিরতি'}
                      </span>

                      {isUserKeyOnline(donor.phone, onlineUsersMap) || donor.isAvailable ? (
                        <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-2xs">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                          <span>🟢 অনলাইন</span>
                        </span>
                      ) : (
                        <span className="bg-gray-100 text-gray-500 border border-gray-200 text-[10px] font-medium px-2 py-0.5 rounded-full flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-gray-400" />
                          <span>⚪ অফলাইন</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <div 
                    onClick={() => handleOpenDonorProfile(donor)}
                    className="cursor-pointer group"
                    title="রক্তদাতার ফেসবুক/হোয়াটসঅ্যাপ স্টাইল বড় প্রোফাইল দেখতে স্পর্শ করুন"
                  >
                    <h3 className="font-bold text-base text-[#2D3A3A] group-hover:text-[#2D5A27] transition font-['Noto_Sans_Bengali'] flex items-center gap-1.5">
                      <span>{donor.name}</span>
                      <ShieldCheck className="w-3.5 h-3.5 text-[#27AE60]" />
                    </h3>
                  </div>

                  <div className="mt-2 text-xs text-[#736B5E] space-y-1">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                      <span>{donor.upazila ? `উপজেলা: ${donor.upazila}, ` : ''}{donor.district}</span>
                    </div>
                    <div className="text-[10px] text-[#27AE60] flex items-center gap-1 font-semibold">
                      <span>🔒 গ্রাম/ওয়ার্ড সুরক্ষিত (প্রয়োজনে জেনে নিন)</span>
                    </div>
                    {donor.lastDonationDate && (
                      <div className="flex items-center gap-1.5 text-[11px]">
                        <Clock className="w-3 h-3 text-[#736B5E]" />
                        <span>সর্বশেষ রক্তদান: {donor.lastDonationDate}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#E6E0D4] flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleInitiateOfflineCall(donor.phone, donor.name, 'স্বেচ্ছাসেবী রক্তদাতা')}
                    className="flex-1 bg-[#C0392B] hover:bg-[#A93226] text-white font-bold py-2 rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer active:scale-98"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>কল ({maskPhoneNumber(donor.phone)})</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleOpenDonorProfile(donor)}
                    className="bg-[#FAF8F5] hover:bg-[#D4E4BC]/50 text-[#2D5A27] font-bold py-2 px-3 rounded-2xl text-xs flex items-center justify-center gap-1 border border-[#2D5A27]/30 transition cursor-pointer shadow-2xs"
                    title="রক্তদাতার পাবলিক প্রোফাইল ও জুম ফটো দেখুন"
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>প্রোফাইল</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Blood Banks Helpline */}
          <div className="bg-[#FDFBF7] border border-[#E6E0D4] rounded-3xl p-5 shadow-xs space-y-3">
            <h3 className="font-bold text-sm text-[#2D3A3A] font-['Noto_Sans_Bengali'] flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#C0392B]" />
              <span>জাতীয় ও প্রাতিষ্ঠানিক ব্লাড ব্যাংক হটলাইন</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {BLOOD_BANKS_DATA.map((bank) => (
                <div key={bank.id} className="bg-white p-3.5 rounded-2xl border border-[#E6E0D4] space-y-1.5">
                  <span className="text-xs font-bold text-[#2D3A3A] block">{bank.name}</span>
                  <span className="text-[11px] text-[#736B5E] block">{bank.address}</span>
                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => handleInitiateOfflineCall(bank.emergencyMobile, bank.name, 'প্রাতিষ্ঠানিক ব্লাড ব্যাংক')}
                      className="text-xs text-[#C0392B] font-bold flex items-center gap-1 hover:underline cursor-pointer"
                    >
                      <PhoneCall className="w-3 h-3" />
                      <span>{bank.emergencyMobile}</span>
                    </button>
                    {bank.phone && (
                      <button
                        type="button"
                        onClick={() => handleInitiateOfflineCall(bank.phone, bank.name, 'ব্লাড ব্যাংক হটলাইন')}
                        className="text-xs text-[#736B5E] hover:underline cursor-pointer"
                      >
                        ({bank.phone})
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: HOSPITALS & MAPS */}
      {activeTab === 'hospitals' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredHospitals.map((hospital) => (
              <div
                key={hospital.id}
                className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 shadow-xs transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                      {hospital.type}
                    </span>
                    <span className="text-xs text-[#736B5E] font-medium">{hospital.district}</span>
                  </div>

                  <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                    {hospital.name}
                  </h3>

                  <p className="text-xs text-[#736B5E] mt-1 flex items-start gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[#E8924A] flex-shrink-0 mt-0.5" />
                    <span>{hospital.address}</span>
                  </p>

                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {hospital.services.map((srv, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] bg-[#FDFBF7] text-[#5A6B6B] px-2 py-0.5 rounded-md border border-[#E6E0D4]"
                      >
                        ✓ {srv}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3.5 border-t border-[#E6E0D4] grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleInitiateOfflineCall(hospital.emergencyNumber, hospital.name, 'হাসপাতাল জরুরি বিভাগ')}
                    className="bg-[#C0392B] hover:bg-[#A93226] text-white font-bold py-2 rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer active:scale-98"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>জরুরি নম্বর</span>
                  </button>

                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(hospital.googleMapsQuery)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2 rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition"
                  >
                    <NavIcon className="w-3.5 h-3.5" />
                    <span>ম্যাপে রাস্তা দেখুন</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: DOCTOR SCHEDULES */}
      {activeTab === 'doctors' && (
        <div className="space-y-5">
          {/* Doctor Toolbar */}
          <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-1 rounded-full">
                👨‍⚕️ মোট বিশেষজ্ঞ চিকিৎসক: {filteredDoctors.length} জন
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="relative w-full sm:w-60">
                <Search className="w-3.5 h-3.5 text-[#736B5E] absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="ডাক্তার, রোগ বা হাসপাতাল..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-[#FDFBF7] border border-[#E6E0D4] rounded-xl text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <button
                onClick={() => setShowDoctorModal(true)}
                className="flex items-center gap-1.5 bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold px-3.5 py-1.5 rounded-xl shadow-xs transition cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>নতুন ডাক্তার/চেম্বার যুক্ত করুন</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDoctors.map((doc) => (
              <div
                key={doc.id}
                className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 shadow-xs transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-[11px] font-bold text-[#A65E2E] bg-[#F9E5D4] px-2.5 py-0.5 rounded-full border border-[#F9E5D4]">
                      {doc.speciality}
                    </span>
                    <span className="text-xs font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2 py-0.5 rounded-md">
                      ফি: {doc.fee}
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                    {doc.doctorName}
                  </h3>

                  <p className="text-xs text-[#736B5E] mt-0.5">{doc.designation}</p>

                  <div className="mt-3 bg-[#FDFBF7] p-3 rounded-2xl border border-[#E6E0D4] space-y-1.5 text-xs text-[#5A6B6B]">
                    <div className="flex items-start gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-[#2D5A27] flex-shrink-0 mt-0.5" />
                      <span><strong>চেম্বার:</strong> {doc.hospitalOrClinic}</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#E8924A] flex-shrink-0 mt-0.5" />
                      <span><strong>বসার দিন:</strong> {doc.visitingDays}</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#736B5E] flex-shrink-0 mt-0.5" />
                      <span><strong>সময়:</strong> {doc.visitingHours}</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#736B5E] flex-shrink-0 mt-0.5" />
                      <span><strong>জেলা:</strong> {doc.district}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#E6E0D4]">
                  <button
                    type="button"
                    onClick={() => handleInitiateOfflineCall(doc.serialNumber, doc.doctorName, 'ডাক্তারের চেম্বার সিরিয়াল')}
                    className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer active:scale-98"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>সিরিয়াল দিন ({doc.serialNumber})</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: COMMUNITY CLINICS */}
      {activeTab === 'clinics' && (
        <CommunityClinics currentDistrict={currentDistrict} currentUser={currentUser} />
      )}

      {/* TAB 5: VACCINE SCHEDULER */}
      {activeTab === 'vaccine' && (
        <VaccineScheduler />
      )}

      {/* TAB 6: FIRST AID */}
      {activeTab === 'firstaid' && (
        <FirstAidGuide />
      )}

      {/* TAB 7: RURAL & VETERINARY DOCTORS */}
      {activeTab === 'rural_doctors' && (
        <RuralDoctorDirectory />
      )}

      {/* TAB 8: GOVT AMBULANCE DIRECTORY */}
      {activeTab === 'ambulances' && (
        <GovtAmbulanceDirectory />
      )}

      {/* DOCTOR REGISTRATION MODAL */}
      {showDoctorModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-4 sm:p-6 shadow-2xl border border-[#E6E0D4] max-h-[88vh] sm:max-h-[90vh] overflow-y-auto relative animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3 mb-4">
              <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali'] flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-[#2D5A27]" />
                <span>ডাক্তার বা চেম্বারের তথ্য যুক্ত করুন</span>
              </h3>
              <button
                onClick={() => setShowDoctorModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-[#5A6B6B] mb-4 bg-[#FDFBF7] p-2.5 rounded-xl border border-[#E6E0D4]">
              💡 যেকোনো ডাক্তার, সহকারী বা ক্লিনিক প্রতিনিধি সরাসরি তাদের চেম্বার ও ভিজিটিং শিডিউল এখানে যোগ করতে পারবেন।
            </p>

            <form onSubmit={handleRegisterDoctor} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  ডাক্তারের পূর্ণ নাম *
                </label>
                <input
                  type="text"
                  required
                  placeholder="উদাঃ ডাঃ মোঃ শফিকুল ইসলাম"
                  value={docName}
                  onChange={(e) => setDocName(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    বিশেষজ্ঞ ক্যাটাগরি *
                  </label>
                  <select
                    value={docSpeciality}
                    onChange={(e) => setDocSpeciality(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    <option value="মেডিসিন">মেডিসিন</option>
                    <option value="শিশু বিশেষজ্ঞ">শিশু বিশেষজ্ঞ</option>
                    <option value="স্ত্রী ও প্রসূতি (গাইনি)">স্ত্রী ও প্রসূতি (গাইনি)</option>
                    <option value="হৃদরোগ">হৃদরোগ</option>
                    <option value="অর্থোপেডিক ও বাত-ব্যথা">অর্থোপেডিক ও বাত-ব্যথা</option>
                    <option value="চক্ষু রোগ">চক্ষু রোগ</option>
                    <option value="নাক-কান-গলা">নাক-কান-গলা</option>
                    <option value="চর্ম ও যৌন">চর্ম ও যৌন</option>
                    <option value="দন্ত ও মুখরোগ">দন্ত ও মুখরোগ</option>
                    <option value="সাধারণ সার্জারি">সাধারণ সার্জারি</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    ডিগ্রি ও পদবী
                  </label>
                  <input
                    type="text"
                    placeholder="উদাঃ MBBS, BCS (স্বাস্থ্য), FCPS"
                    value={docDesignation}
                    onChange={(e) => setDocDesignation(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  হাসপাতাল / ডায়াগনস্টিক / চেম্বারের নাম ও ঠিকানা *
                </label>
                <input
                  type="text"
                  required
                  placeholder="উদাঃ পপুলার ডায়াগনস্টিক সেন্টার, সাভার বাজার"
                  value={docHospital}
                  onChange={(e) => setDocHospital(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    বসার দিনসমূহ
                  </label>
                  <input
                    type="text"
                    placeholder="উদাঃ শনি, সোম ও বুধবার"
                    value={docVisitingDays}
                    onChange={(e) => setDocVisitingDays(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    রোগী দেখার সময়
                  </label>
                  <input
                    type="text"
                    placeholder="উদাঃ বিকাল ৪:০০ - রাত ৮:০০"
                    value={docVisitingHours}
                    onChange={(e) => setDocVisitingHours(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    সিরিয়াল / বুকিং মোবাইল নম্বর *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৭xxxxxxxx"
                    value={docSerialNumber}
                    onChange={(e) => setDocSerialNumber(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    ভিজিট ফি (টাকা)
                  </label>
                  <input
                    type="text"
                    placeholder="উদাঃ ৫০০ টাকা"
                    value={docFee}
                    onChange={(e) => setDocFee(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  জেলা
                </label>
                <select
                  value={docDistrict}
                  onChange={(e) => setDocDistrict(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                >
                  {BANGLADESH_DISTRICTS.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3.5 pb-6 sm:pb-3 border-t border-[#E6E0D4] -mx-4 sm:-mx-6 px-4 sm:px-6 mt-4 z-20 flex justify-end gap-2 shadow-[0_-4px_14px_rgba(0,0,0,0.06)]">
                <button
                  type="button"
                  onClick={() => setShowDoctorModal(false)}
                  className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-[#736B5E] bg-[#FDFBF7] hover:bg-[#E6E0D4] border border-[#E6E0D4] cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] cursor-pointer shadow-md active:scale-98 transition-all"
                >
                  তথ্য যোগ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DONOR REGISTRATION MODAL */}
      {showRegisterModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-4 sm:p-6 shadow-2xl border border-[#E6E0D4] max-h-[88vh] sm:max-h-[90vh] overflow-y-auto relative animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3 mb-4">
              <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali'] flex items-center gap-2">
                <Heart className="w-5 h-5 text-[#C0392B]" />
                <span>স্বেচ্ছায় রক্তদাতা হিসেবে নাম নিবন্ধন করুন</span>
              </h3>
              <button
                onClick={() => setShowRegisterModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleRegisterDonor} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  আপনার পূর্ণ নাম *
                </label>
                <input
                  type="text"
                  required
                  placeholder="নাম লিখুন"
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    রক্তের গ্রুপ *
                  </label>
                  <select
                    value={donorBloodGroup}
                    onChange={(e) => setDonorBloodGroup(e.target.value as any)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map((g) => (
                      <option key={g} value={g}>{g}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    মোবাইল নম্বর (সরাসরি কল) *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৭xxxxxxxx"
                    value={donorPhone}
                    onChange={(e) => setDonorPhone(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    জেলা *
                  </label>
                  <select
                    value={donorDistrict}
                    onChange={(e) => {
                      setDonorDistrict(e.target.value);
                      setDonorUpazila('');
                    }}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    {BANGLADESH_DISTRICTS.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    উপজেলা *
                  </label>
                  <select
                    value={donorUpazila}
                    onChange={(e) => setDonorUpazila(e.target.value)}
                    required
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  >
                    <option value="">উপজেলা নির্বাচন করুন</option>
                    {getUpazilasForDistrict(donorDistrict).map((u) => (
                      <option key={u} value={u}>{u} উপজেলা</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  গ্রাম বা বর্তমান এলাকা *
                </label>
                <input
                  type="text"
                  required
                  placeholder="গ্রাম / পাড়ার নাম"
                  value={donorVillage}
                  onChange={(e) => setDonorVillage(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                />
              </div>

              {/* Global Auto-fill & Offline Call Status Box */}
              <div className="bg-[#FAF6ED] border border-[#E6DEC8] rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1.5">
                    <span>📞</span>
                    <span>অফলাইন সরাসরি কল পারমিশন (Auto-fill)</span>
                  </span>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                    donorAllowOfflineCall 
                      ? 'bg-[#D4E4BC] text-[#2D5A27] border-[#2D5A27]/30' 
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}>
                    {donorAllowOfflineCall ? 'অনুমোদিত (হ্যাঁ)' : 'সুরক্ষিত/গোপন (না)'}
                  </span>
                </div>

                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={donorAllowOfflineCall}
                    onChange={(e) => setDonorAllowOfflineCall(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2D5A27] focus:ring-[#2D5A27] cursor-pointer mt-0.5 shrink-0"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-[#2D3A3A] block">
                      আপনি কি রক্তগ্রহীতাদের অফলাইনে সরাসরি কলের সুযোগ দিতে চান?
                    </span>
                    <span className="text-[11px] text-[#736B5E] block mt-0.5 leading-relaxed">
                      {donorAllowOfflineCall
                        ? '✓ অনুমোদিত: রক্তগ্রহীতা আপনার নম্বরে সরাসরি অফলাইন কল করতে পারবেন (তবে কলের পূর্বে তাদের স্ক্রিনে সতর্কতা দেখানো হবে)।'
                        : '🔒 বন্ধ (ডিফল্ট): আপনার নম্বর ও গ্রাম/ওয়ার্ড সাধারণদের কাছে সুরক্ষিত ও গোপন থাকবে। জরুরি প্রয়োজনে ইন-অ্যাপ বার্তায় যোগাযোগ করা যাবে।'}
                    </span>
                  </div>
                </label>
              </div>

              {/* Sticky Submit Bar */}
              <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3.5 pb-6 sm:pb-3 border-t border-[#E6E0D4] -mx-4 sm:-mx-6 px-4 sm:px-6 mt-4 z-20 flex justify-end gap-2 shadow-[0_-4px_14px_rgba(0,0,0,0.06)]">
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(false)}
                  className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-[#736B5E] bg-[#FDFBF7] hover:bg-[#E6E0D4] border border-[#E6E0D4] cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#C0392B] hover:bg-[#A93226] cursor-pointer shadow-md active:scale-98 transition-all"
                >
                  নিবন্ধন সম্পন্ন করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Global Offline Call Warning Modal */}
      {offlineCallTarget.isOpen && (
        <OfflineCallWarningModal
          isOpen={offlineCallTarget.isOpen}
          phoneNumber={offlineCallTarget.phoneNumber}
          recipientName={offlineCallTarget.recipientName}
          recipientRole={offlineCallTarget.recipientRole}
          onProceedOfflineCall={handleProceedOfflineCall}
          onClose={() => setOfflineCallTarget(prev => ({ ...prev, isOpen: false }))}
        />
      )}
    </div>
  );
};
