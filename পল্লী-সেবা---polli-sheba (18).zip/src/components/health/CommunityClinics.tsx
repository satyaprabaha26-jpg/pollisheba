import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Phone, 
  Clock, 
  Pill, 
  Stethoscope, 
  MapPin, 
  CheckCircle2,
  Navigation,
  ExternalLink,
  ShieldCheck,
  Building2,
  ChevronDown,
  Sparkles,
  Map as MapIcon,
  ListFilter
} from 'lucide-react';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { getUpazilasForDistrict, getUnionsForUpazila } from '../../data/bangladeshLocations';
import { 
  EnhancedClinic, 
  getCommunityClinicsForLocation 
} from '../../data/communityClinicsData';
import { getSavedLocation, detectCurrentLocationGPS } from '../../utils/locationService';
import { UserProfile } from '../../types/auth';

interface CommunityClinicsProps {
  currentDistrict?: string;
  currentUser?: UserProfile | null;
}

export const CommunityClinics: React.FC<CommunityClinicsProps> = ({ 
  currentDistrict, 
  currentUser 
}) => {
  // Determine initial location from Profile, GPS Saved Location, or default
  const savedLoc = getSavedLocation();
  const initialDistrict = currentUser?.district || (savedLoc?.district && savedLoc.district !== 'সকল জেলা' ? savedLoc.district : (currentDistrict && currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা'));
  const initialUpazila = currentUser?.upazila || savedLoc?.upazila || '';
  const initialUnion = currentUser?.union || savedLoc?.union || '';

  const [selectedDistrict, setSelectedDistrict] = useState<string>(initialDistrict);
  const [selectedUpazila, setSelectedUpazila] = useState<string>(initialUpazila);
  const [selectedUnion, setSelectedUnion] = useState<string>(initialUnion);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [locationNotice, setLocationNotice] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'both' | 'map' | 'list'>('both');

  const [userCoords, setUserCoords] = useState<{ lat?: number; lng?: number }>({
    lat: savedLoc?.latitude,
    lng: savedLoc?.longitude
  });

  // Keep upazila in sync if district changes
  const availableUpazilas = getUpazilasForDistrict(selectedDistrict);
  const availableUnions = selectedUpazila ? getUnionsForUpazila(selectedDistrict, selectedUpazila) : [];

  useEffect(() => {
    // If current upazila is invalid for new district, select the first one
    if (availableUpazilas.length > 0 && (!selectedUpazila || !availableUpazilas.includes(selectedUpazila))) {
      setSelectedUpazila(availableUpazilas[0]);
    }
  }, [selectedDistrict]);

  // Load clinics automatically based on current district & upazila & union
  const clinics = getCommunityClinicsForLocation(
    selectedDistrict,
    selectedUpazila,
    selectedUnion,
    userCoords.lat,
    userCoords.lng
  );

  const [selectedClinic, setSelectedClinic] = useState<EnhancedClinic | null>(clinics[0] || null);

  useEffect(() => {
    if (clinics.length > 0) {
      // Keep selected clinic if it exists in new list, else set to first
      if (!selectedClinic || !clinics.some(c => c.id === selectedClinic.id)) {
        setSelectedClinic(clinics[0]);
      }
    }
  }, [selectedDistrict, selectedUpazila, selectedUnion]);

  // Auto-run GPS detection on first load if user doesn't have district set
  useEffect(() => {
    if (!currentUser?.district && !savedLoc?.district) {
      handleDetectLocation(false);
    }
  }, []);

  const handleDetectLocation = async (userInitiated = true) => {
    setIsLocating(true);
    try {
      const res = await detectCurrentLocationGPS();
      if (res.success && res.district) {
        setSelectedDistrict(res.district);
        const upzs = getUpazilasForDistrict(res.district);
        if (upzs.length > 0) {
          setSelectedUpazila(upzs[0]);
        }
        if (res.latitude && res.longitude) {
          setUserCoords({ lat: res.latitude, lng: res.longitude });
        }
        setLocationNotice(`আপনার জিপিএস অবস্থান অনুযায়ী ${res.district} জেলার নিকটস্থ স্বাস্থ্য কেন্দ্রসমূহ দেখানো হচ্ছে।`);
      } else if (userInitiated && res.errorMessage) {
        setLocationNotice(res.errorMessage);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLocating(false);
      setTimeout(() => setLocationNotice(null), 6000);
    }
  };

  const filteredClinics = clinics.filter(c => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.upazila.toLowerCase().includes(q) ||
      c.union.toLowerCase().includes(q) ||
      c.chcpName.toLowerCase().includes(q) ||
      c.availableServices.some(s => s.toLowerCase().includes(q)) ||
      c.keyMedicines.some(m => m.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6">
      {/* Banner in Polli Sheba Heritage Green */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full inline-block">
              🏥 গ্রামীণ স্বাস্থ্য কেন্দ্র ডিরেক্টরি
            </span>
            <span className="bg-white/20 text-white text-[11px] font-semibold px-2.5 py-0.5 rounded-full">
              অটো-লোকেশন সমর্থিত
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
            কমিউনিটি ক্লিনিক ও ইউনিয়ন স্বাস্থ্য কেন্দ্র
          </h2>
          <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
            আপনার নিকটস্থ স্বাস্থ্য কেন্দ্র, বিশেষজ্ঞ ও সিএইচসিপি কর্মী, সেবার সময়সূচি এবং সরকারি বিনামূল্যের ওষুধের তালিকা
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => handleDetectLocation(true)}
            disabled={isLocating}
            className="flex items-center gap-1.5 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold px-3.5 py-2 rounded-2xl text-xs shadow-md transition cursor-pointer"
          >
            <Navigation className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
            <span>{isLocating ? 'লোকেশন খোঁজা হচ্ছে...' : 'জিপিএস দিয়ে নিকটস্থ খুঁজুন'}</span>
          </button>

          <div className="bg-[#23491E] border border-[#3D7A35] p-2.5 rounded-2xl text-xs text-[#D4E4BC] flex items-center gap-2">
            <div>
              <p className="text-[10px] font-bold text-[#F9E5D4]">জাতীয় স্বাস্থ্য বাতায়ন</p>
              <p className="text-base font-bold text-white font-['Noto_Sans_Bengali']">১৬২৬৩</p>
            </div>
            <a
              href="tel:16263"
              className="bg-[#2D5A27] hover:bg-[#3D7A35] p-2 rounded-xl text-white transition"
              title="স্বাস্থ্য বাতায়নে কল দিন"
            >
              <Phone className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>

      {/* GPS / Location Notice */}
      {locationNotice && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900 flex items-center justify-between gap-2 animate-in fade-in">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{locationNotice}</span>
          </div>
          <button onClick={() => setLocationNotice(null)} className="text-emerald-700 hover:text-emerald-950 font-bold px-1.5">
            ✕
          </button>
        </div>
      )}

      {/* Auto-Detection & Filter Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-[#E6E0D4] shadow-xs space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#2D3A3A]">
            <MapPin className="w-4 h-4 text-[#E8924A]" />
            <span>আপনার এলাকা অনুযায়ী স্বাস্থ্য কেন্দ্র নির্বাচন করুন:</span>
            {currentUser?.district && (
              <span className="text-[11px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                ✓ প্রোফাইল লিঙ্কড
              </span>
            )}
          </div>

          {/* View Toggle */}
          <div className="flex items-center gap-1 bg-[#FDFBF7] p-1 border border-[#E6E0D4] rounded-xl text-xs">
            <button
              onClick={() => setViewMode('both')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer ${
                viewMode === 'both' ? 'bg-[#2D5A27] text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              তালিকা ও ম্যাপ
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer flex items-center gap-1 ${
                viewMode === 'map' ? 'bg-[#2D5A27] text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MapIcon className="w-3.5 h-3.5" />
              <span>ম্যাপ ভিউ</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer flex items-center gap-1 ${
                viewMode === 'list' ? 'bg-[#2D5A27] text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ListFilter className="w-3.5 h-3.5" />
              <span>তালিকা ভিউ</span>
            </button>
          </div>
        </div>

        {/* 3 Cascading Selectors */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* District */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">জেলা নির্বাচন</label>
            <div className="relative">
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="w-full bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl px-3 py-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#2D5A27] appearance-none cursor-pointer"
              >
                {BANGLADESH_DISTRICTS.map((d) => (
                  <option key={d} value={d}>{d} জেলা</option>
                ))}
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-3 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Upazila */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">উপজেলা নির্বাচন</label>
            <div className="relative">
              <select
                value={selectedUpazila}
                onChange={(e) => setSelectedUpazila(e.target.value)}
                className="w-full bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl px-3 py-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#2D5A27] appearance-none cursor-pointer"
              >
                {availableUpazilas.map((u) => (
                  <option key={u} value={u}>{u} উপজেলা</option>
                ))}
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-3 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Union */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">ইউনিয়ন / ওয়ার্ড</label>
            <div className="relative">
              <select
                value={selectedUnion}
                onChange={(e) => setSelectedUnion(e.target.value)}
                className="w-full bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl px-3 py-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#2D5A27] appearance-none cursor-pointer"
              >
                <option value="">সকল ইউনিয়ন ও ওয়ার্ড</option>
                {availableUnions.map((un) => (
                  <option key={un} value={un}>{un}</option>
                ))}
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-3 top-3 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Free text search bar */}
        <div className="relative pt-1">
          <Search className="w-4 h-4 text-[#736B5E] absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="ক্লিনিকের নাম, সেবা (যেমন: ডেলিভারি, রক্তচাপ) বা ফ্রি ওষুধ (প্যারাসিটামল) দিয়ে খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
          />
        </div>
      </div>

      {/* Embedded Live Map View (When active) */}
      {(viewMode === 'map' || viewMode === 'both') && (
        <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                <MapIcon className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-bold text-slate-900">
                  {selectedDistrict} &gt; {selectedUpazila} স্বাস্থ্য কেন্দ্রের ভৌগোলিক ম্যাপ
                </h3>
                <p className="text-[11px] text-slate-500">
                  নিকটস্থ প্রতিটি স্বাস্থ্য কেন্দ্রের দূরত্ব ও সরাসরি গুগল ম্যাপস নেভিগেশন
                </p>
              </div>
            </div>

            <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full">
              📍 {filteredClinics.length}টি কেন্দ্র সনাক্তকৃত
            </span>
          </div>

          {/* Interactive Map Visual Stage */}
          <div className="relative w-full h-64 sm:h-72 rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 shadow-inner">
            {/* Embedded OpenStreetMap Iframe for the exact district/upazila */}
            <iframe
              title="Community Clinics Map"
              width="100%"
              height="100%"
              frameBorder="0"
              scrolling="no"
              marginHeight={0}
              marginWidth={0}
              src={`https://www.openstreetmap.org/export/embed.html?bbox=${
                (selectedClinic?.longitude || 90.4125) - 0.08
              }%2C${(selectedClinic?.latitude || 23.8103) - 0.06}%2C${
                (selectedClinic?.longitude || 90.4125) + 0.08
              }%2C${(selectedClinic?.latitude || 23.8103) + 0.06}&layer=mapnik&marker=${
                selectedClinic?.latitude || 23.8103
              }%2C${selectedClinic?.longitude || 90.4125}`}
              className="w-full h-full opacity-90"
            />

            {/* Map Overlay Card for currently selected clinic */}
            {selectedClinic && (
              <div className="absolute bottom-3 left-3 right-3 sm:right-auto sm:max-w-sm bg-white/95 backdrop-blur-md p-3.5 rounded-2xl border border-slate-200 shadow-xl space-y-2 text-xs">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      {selectedClinic.typeLabel}
                    </span>
                    <h4 className="font-bold text-slate-900 mt-1 text-xs sm:text-sm">
                      {selectedClinic.name}
                    </h4>
                  </div>
                  {selectedClinic.distanceKm && (
                    <span className="text-[11px] font-extrabold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-lg shrink-0">
                      ≈ {selectedClinic.distanceKm} কি.মি.
                    </span>
                  )}
                </div>

                <p className="text-[11px] text-slate-600 line-clamp-1">
                  📍 {selectedClinic.address}
                </p>

                <div className="flex items-center gap-2 pt-1">
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                      selectedClinic.googleMapsQuery || selectedClinic.name + ' ' + selectedClinic.district
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-1.5 px-3 bg-[#2D5A27] hover:bg-[#23491E] text-white rounded-xl font-bold text-[11px] flex items-center justify-center gap-1 shadow-xs transition"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>গুগল ম্যাপে দিকনির্দেশনা</span>
                  </a>

                  <a
                    href={`tel:${selectedClinic.contactNumber}`}
                    className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-[11px] flex items-center justify-center gap-1 shadow-xs transition"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>কল</span>
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Grid View: Clinics List + Detail Card */}
      {(viewMode === 'list' || viewMode === 'both') && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left Clinic List */}
          <div className="lg:col-span-5 space-y-3 max-h-[640px] overflow-y-auto pr-1">
            {filteredClinics.length === 0 ? (
              <div className="p-8 text-center bg-white border border-[#E6E0D4] rounded-3xl text-[#736B5E] text-xs sm:text-sm">
                কোনো স্বাস্থ্য কেন্দ্র পাওয়া যায়নি। দয়া করে ফিল্টার পরিবর্তন করে দেখুন।
              </div>
            ) : (
              filteredClinics.map((clinic) => {
                const isSelected = selectedClinic?.id === clinic.id;
                return (
                  <div
                    key={clinic.id}
                    onClick={() => setSelectedClinic(clinic)}
                    className={`p-4 sm:p-5 rounded-3xl border transition cursor-pointer text-left ${
                      isSelected
                        ? 'bg-[#D4E4BC]/30 border-[#2D5A27] ring-2 ring-[#2D5A27]/20 shadow-xs'
                        : 'bg-white border-[#E6E0D4] hover:border-[#2D5A27]/50 hover:bg-[#FDFBF7]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap mb-1">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            clinic.type === 'upazila_health_complex'
                              ? 'bg-blue-100 text-blue-800'
                              : clinic.type === 'union_health_centre'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {clinic.typeLabel}
                          </span>
                          {clinic.emergencyAvailable && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-700">
                              ২৪/৭ জরুরি
                            </span>
                          )}
                        </div>

                        <h4 className="font-bold text-sm sm:text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                          {clinic.name}
                        </h4>

                        <p className="text-xs text-[#2D5A27] font-medium mt-1 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-[#2D5A27] shrink-0" />
                          <span>{clinic.union}, {clinic.upazila}, {clinic.district}</span>
                        </p>
                      </div>

                      {clinic.distanceKm && (
                        <span className="text-[11px] font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-1 rounded-xl shrink-0">
                          ≈ {clinic.distanceKm} কিমি
                        </span>
                      )}
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-slate-100 text-xs text-[#736B5E] flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-[#A65E2E] shrink-0" />
                        <span className="line-clamp-1">{clinic.timing.split(':')[0]}</span>
                      </div>
                      <span className="text-[11px] font-semibold text-emerald-700">
                        {clinic.keyMedicines.length}+ প্রকার ফ্রি ওষুধ &gt;
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Right Detail Card */}
          <div className="lg:col-span-7">
            {selectedClinic ? (
              <div className="bg-white border border-[#E6E0D4] rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 sticky top-28">
                <div className="flex items-start justify-between border-b border-[#E6E0D4] pb-3 gap-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC] px-3 py-0.5 rounded-full">
                        {selectedClinic.district} জেলা • {selectedClinic.upazila}
                      </span>
                      {selectedClinic.distanceKm && (
                        <span className="text-[11px] font-bold text-amber-800 bg-amber-100/60 px-2.5 py-0.5 rounded-full">
                          📍 প্রায় {selectedClinic.distanceKm} কি.মি. দূরত্ব
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                      {selectedClinic.name}
                    </h3>
                    <p className="text-xs text-[#736B5E] mt-1 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-[#736B5E] shrink-0" />
                      <span>{selectedClinic.address}</span>
                    </p>
                  </div>
                </div>

                {/* Incharge / Health Provider & Call */}
                <div className="bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl p-3.5 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-[11px] text-[#736B5E] block">দায়িত্বপ্রাপ্ত স্বাস্থ্য কর্মকর্তা / সিএইচসিপি:</span>
                    <p className="font-bold text-xs sm:text-sm text-[#2D3A3A]">{selectedClinic.chcpName}</p>
                    <span className="text-[11px] text-slate-500">ফোন: {selectedClinic.contactNumber}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <a
                      href={`tel:${selectedClinic.contactNumber}`}
                      className="flex items-center gap-1.5 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold text-xs px-4 py-2 rounded-2xl transition shadow-xs"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>সরাসরি কল দিন</span>
                    </a>
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                        selectedClinic.googleMapsQuery || selectedClinic.name + ' ' + selectedClinic.district
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-3 py-2 rounded-2xl transition shadow-xs"
                      title="গুগল ম্যাপে দিকনির্দেশনা ও রুট দেখুন"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>ম্যাপ রুট</span>
                    </a>
                  </div>
                </div>

                {/* Timing */}
                <div className="text-xs text-[#2D3A3A] bg-[#F9E5D4]/50 border border-[#F9E5D4] p-3 rounded-2xl flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#A65E2E] flex-shrink-0" />
                  <span><strong>সেবার সময়সূচি: </strong>{selectedClinic.timing}</span>
                </div>

                {/* Services Offered */}
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-[#2D3A3A] mb-2 flex items-center gap-1.5">
                    <Stethoscope className="w-4 h-4 text-[#2D5A27]" />
                    <span>প্রদত্ত সরকারি স্বাস্থ্যসেবাসমূহ:</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {selectedClinic.availableServices.map((srv, idx) => (
                      <div key={idx} className="bg-[#FDFBF7] p-2.5 rounded-2xl text-xs text-[#2D3A3A] flex items-center gap-2 border border-[#E6E0D4]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#2D5A27] flex-shrink-0" />
                        <span>{srv}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Key Free Medicines */}
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-[#2D3A3A] mb-2 flex items-center gap-1.5">
                    <Pill className="w-4 h-4 text-[#2D5A27]" />
                    <span>উপলব্ধ সরকারি বিনামূল্যের প্রধান ওষুধসমূহ (৩০ প্রকারের মধ্যে বিশেষ):</span>
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedClinic.keyMedicines.map((med, idx) => (
                      <span
                        key={idx}
                        className="bg-[#D4E4BC]/40 text-[#2D5A27] border border-[#D4E4BC] text-xs font-semibold px-3 py-1 rounded-full"
                      >
                        ✓ {med}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center bg-white border border-[#E6E0D4] rounded-3xl text-[#736B5E] text-xs">
                তালিকা থেকে যেকোনো স্বাস্থ্য কেন্দ্র নির্বাচন করুন।
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
