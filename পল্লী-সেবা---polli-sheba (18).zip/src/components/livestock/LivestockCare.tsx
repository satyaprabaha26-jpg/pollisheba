import React, { useState } from 'react';
import { Beef, Bird, Fish, Check, Syringe, Info, ShieldAlert } from 'lucide-react';
import { LIVESTOCK_CARE_DATA } from '../../data/mockData';
import { LivestockGuide } from '../../types';

export const LivestockCare: React.FC = () => {
  const [selectedAnimal, setSelectedAnimal] = useState<'গরু' | 'ছাগল ও ভেড়া' | 'হাঁস-মুরগি' | 'মাছ চাষ'>('গরু');
  const [selectedGuide, setSelectedGuide] = useState<LivestockGuide | null>(LIVESTOCK_CARE_DATA[0]);

  const filteredGuides = LIVESTOCK_CARE_DATA.filter((g) => g.animalType === selectedAnimal);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm">
        <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
          🐄 খামারি ও প্রাণীসম্পদ সহায়িকা
        </span>
        <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
          পশুসম্পদ, হাঁস-মুরগি ও মৎস্যচাষ পরিচর্যা
        </h2>
        <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
          গবাদিপশুর সাধারণ রোগবালাই, ভ্যাকসিন শিডিউল, কৃমিনাশক ও পুকুরের মাছের রোগ প্রতিকার
        </p>
      </div>

      {/* Animal Selection Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => {
            setSelectedAnimal('গরু');
            setSelectedGuide(LIVESTOCK_CARE_DATA.find(g => g.animalType === 'গরু') || null);
          }}
          className={`p-4 rounded-3xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer ${
            selectedAnimal === 'গরু'
              ? 'border-[#2D5A27] bg-[#D4E4BC]/30 text-[#2D5A27] shadow-xs'
              : 'border-[#E6E0D4] bg-white text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <Beef className="w-5 h-5 text-[#2D5A27]" />
          <span>গরু ও গাভী পালন</span>
        </button>

        <button
          onClick={() => {
            setSelectedAnimal('ছাগল ও ভেড়া');
            setSelectedGuide(LIVESTOCK_CARE_DATA.find(g => g.animalType === 'ছাগল ও ভেড়া') || null);
          }}
          className={`p-4 rounded-3xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer ${
            selectedAnimal === 'ছাগল ও ভেড়া'
              ? 'border-[#2D5A27] bg-[#D4E4BC]/30 text-[#2D5A27] shadow-xs'
              : 'border-[#E6E0D4] bg-white text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <span>🐐</span>
          <span>ছাগল ও ভেড়া পালন</span>
        </button>

        <button
          onClick={() => {
            setSelectedAnimal('হাঁস-মুরগি');
            setSelectedGuide(LIVESTOCK_CARE_DATA.find(g => g.animalType === 'হাঁস-মুরগি') || null);
          }}
          className={`p-4 rounded-3xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer ${
            selectedAnimal === 'হাঁস-মুরগি'
              ? 'border-[#2D5A27] bg-[#D4E4BC]/30 text-[#2D5A27] shadow-xs'
              : 'border-[#E6E0D4] bg-white text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <Bird className="w-5 h-5 text-[#A65E2E]" />
          <span>হাঁস-মুরগি ও পোল্ট্রি</span>
        </button>

        <button
          onClick={() => {
            setSelectedAnimal('মাছ চাষ');
            setSelectedGuide(LIVESTOCK_CARE_DATA.find(g => g.animalType === 'মাছ চাষ') || null);
          }}
          className={`p-4 rounded-3xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer ${
            selectedAnimal === 'মাছ চাষ'
              ? 'border-[#2D5A27] bg-[#D4E4BC]/30 text-[#2D5A27] shadow-xs'
              : 'border-[#E6E0D4] bg-white text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <Fish className="w-5 h-5 text-[#2B6CB0]" />
          <span>পুকুরে মাছ চাষ</span>
        </button>
      </div>

      {/* Topics / Guides Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Topic List */}
        <div className="lg:col-span-5 space-y-3">
          {filteredGuides.map((guide) => {
            const isSelected = selectedGuide?.id === guide.id;
            return (
              <div
                key={guide.id}
                onClick={() => setSelectedGuide(guide)}
                className={`p-5 rounded-3xl border transition cursor-pointer text-left ${
                  isSelected
                    ? 'bg-[#D4E4BC]/30 border-[#2D5A27] ring-2 ring-[#2D5A27]/20 shadow-xs'
                    : 'bg-white border-[#E6E0D4] hover:border-[#2D5A27]/50 hover:bg-[#FDFBF7]'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                    {guide.animalType}
                  </span>
                  {guide.vaccineInfo && (
                    <span className="text-[10px] bg-[#F9E5D4] text-[#A65E2E] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                      <Syringe className="w-3 h-3" />
                      <span>{guide.vaccineInfo}</span>
                    </span>
                  )}
                </div>

                <h4 className="font-bold text-sm sm:text-base text-[#2D3A3A] mt-1 font-['Noto_Sans_Bengali']">
                  {guide.topic}
                </h4>
              </div>
            );
          })}
        </div>

        {/* Right Detailed Advice */}
        <div className="lg:col-span-7">
          {selectedGuide ? (
            <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
              <div className="border-b border-[#E6E0D4] pb-3">
                <span className="text-xs font-bold text-[#2D5A27] bg-[#D4E4BC] px-3 py-0.5 rounded-full">
                  {selectedGuide.animalType} পরিচর্যা ও চিকিৎসা
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-[#2D3A3A] mt-2 font-['Noto_Sans_Bengali']">
                  {selectedGuide.topic}
                </h3>
              </div>

              {/* Symptoms */}
              {selectedGuide.symptoms && (
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-[#2D3A3A] mb-2 flex items-center gap-1.5 font-['Noto_Sans_Bengali']">
                    <ShieldAlert className="w-4 h-4 text-[#A65E2E]" />
                    <span>রোগের প্রধান লক্ষণসমূহ:</span>
                  </h4>
                  <div className="space-y-1.5">
                    {selectedGuide.symptoms.map((sym, idx) => (
                      <div key={idx} className="bg-[#FDFBF7] p-2.5 rounded-2xl text-xs sm:text-sm text-[#2D3A3A] flex items-start gap-2 border border-[#E6E0D4]">
                        <span className="text-[#2D5A27] font-bold">•</span>
                        <span>{sym}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Treatment */}
              <div className="bg-[#D4E4BC]/30 border border-[#D4E4BC] rounded-2xl p-4 space-y-1.5">
                <h4 className="text-xs sm:text-sm font-bold text-[#2D5A27] flex items-center gap-1.5 font-['Noto_Sans_Bengali']">
                  <Check className="w-4 h-4 text-[#2D5A27]" />
                  <span>কার্যকর চিকিৎসা ও প্রাথমিক শুশ্রূষা:</span>
                </h4>
                <p className="text-xs sm:text-sm text-[#2D3A3A] leading-relaxed font-medium">
                  {selectedGuide.treatment}
                </p>
              </div>

              {/* Prevention & Vaccination */}
              <div className="bg-[#F9E5D4]/60 border border-[#F9E5D4] rounded-2xl p-4 space-y-1.5">
                <h4 className="text-xs sm:text-sm font-bold text-[#A65E2E] flex items-center gap-1.5 font-['Noto_Sans_Bengali']">
                  <Syringe className="w-4 h-4 text-[#A65E2E]" />
                  <span>প্রতিরোধ ও টিকা প্রয়োগ নির্দেশিকা:</span>
                </h4>
                <p className="text-xs sm:text-sm text-[#A65E2E] leading-relaxed font-medium">
                  {selectedGuide.prevention}
                </p>
              </div>

              <div className="text-xs text-[#5A6B6B] bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#E6E0D4] flex items-start gap-2">
                <Info className="w-4 h-4 text-[#736B5E] flex-shrink-0 mt-0.5" />
                <span>
                  পশু বা মাছের জটিল অসুস্থতায় অবিলম্বে নিকটস্থ <strong>উপজেলা প্রাণীসম্পদ কর্মকর্তা / উপজেলা মৎস্য কর্মকর্তার</strong> পরামর্শ নিন।
                </span>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center bg-white border border-[#E6E0D4] rounded-3xl text-[#736B5E] text-xs">
              বিষয় নির্বাচন করুন।
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
