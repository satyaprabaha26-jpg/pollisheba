import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  MapPin, 
  AlertOctagon, 
  Compass, 
  BookOpen, 
  Volume2, 
  VolumeX, 
  Copy, 
  Check, 
  Search, 
  Navigation as NavIcon,
  Sun,
  Moon,
  Sparkles,
  Scroll,
  HelpCircle,
  Layers,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  CheckCircle2,
  Bookmark
} from 'lucide-react';
import { ISLAMIC_DUAS_DATA, DISTRICT_PRAYER_OFFSETS } from '../../data/extendedData';
import { 
  TEN_SURAH_DATA, 
  SALAT_DUAS_DATA, 
  SALAT_STEPS_COMPARISON,
  SurahItem,
  SalatDuaItem,
  SalatStepComparison
} from '../../data/salatData';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { toBanglaNumber } from '../../utils/banglaNumbers';
import { PrayerHeaderWidget } from './PrayerHeaderWidget';

interface PrayerAndIslamicProps {
  currentDistrict: string;
  onSelectDistrict?: (district: string) => void;
}

export const PrayerAndIslamic: React.FC<PrayerAndIslamicProps> = ({ currentDistrict, onSelectDistrict }) => {
  const [activeTab, setActiveTab] = useState<'prayer' | 'salat_rules' | 'salat_duas' | 'surahs' | 'duas' | 'mosques'>('prayer');
  const [selectedDuaCat, setSelectedDuaCat] = useState<string>('সকল দোয়া');
  const [searchDua, setSearchDua] = useState<string>('');
  const [searchSurah, setSearchSurah] = useState<string>('');
  const [selectedMaslak, setSelectedMaslak] = useState<'both' | 'hanafi' | 'ahlehadith'>('both');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const [localDistrict, setLocalDistrict] = useState<string>(
    currentDistrict && currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা'
  );

  useEffect(() => {
    if (currentDistrict && currentDistrict !== 'সকল জেলা') {
      setLocalDistrict(currentDistrict);
    }
  }, [currentDistrict]);

  const handleDistrictChange = (newDist: string) => {
    setLocalDistrict(newDist);
    if (onSelectDistrict) {
      onSelectDistrict(newDist);
    }
  };

  const district = localDistrict;
  const offset = DISTRICT_PRAYER_OFFSETS[district] || { fajar: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 };

  // Helper to calculate formatted time string based on base hour/minute + offset
  const formatTime = (baseH: number, baseM: number, offsetM: number) => {
    let totalMinutes = baseH * 60 + baseM + offsetM;
    let h = Math.floor(totalMinutes / 60) % 24;
    let m = totalMinutes % 60;
    if (m < 0) {
      m += 60;
      h -= 1;
    }
    const ampm = h >= 12 ? 'বিকাল/রাত' : 'সকাল/ভোর';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    const padM = m < 10 ? `০${m}` : toBanglaNumber(m);
    return `${toBanglaNumber(displayH)}:${padM}`;
  };

  // Standard Dhaka Base times for August (can adjust gracefully)
  const prayers = [
    { name: 'ফজর (Fajr)', icon: '🌌', time: formatTime(4, 28, offset.fajar), end: formatTime(5, 42, offset.sunrise), desc: 'সূর্যোদয়ের পূর্ব পর্যন্ত' },
    { name: 'সূর্যোদয় / ইশরাক', icon: '🌅', time: formatTime(5, 42, offset.sunrise), end: formatTime(6, 5, offset.sunrise), desc: 'ইশরাকের ওয়াক্ত শুরু' },
    { name: 'যোহর (Dhuhr)', icon: '☀️', time: formatTime(12, 5, offset.dhuhr), end: formatTime(16, 28, offset.asr), desc: 'আসর পর্যন্ত ওয়াক্ত' },
    { name: 'আসর (Asr)', icon: '🌤️', time: formatTime(16, 28, offset.asr), end: formatTime(18, 25, offset.maghrib), desc: 'সূর্যাস্তের পূর্ব পর্যন্ত' },
    { name: 'মাগরিব (Maghrib)', icon: '🌆', time: formatTime(18, 25, offset.maghrib), end: formatTime(19, 45, offset.isha), desc: 'ইফতার ও সন্ধ্যার নামাজ' },
    { name: 'এশা ও বিতর (Isha)', icon: '🌙', time: formatTime(19, 45, offset.isha), end: formatTime(4, 25, offset.fajar), desc: 'ফজরের পূর্ব পর্যন্ত' },
    { name: 'তাহাজ্জুদ ও সাহরি', icon: '✨', time: formatTime(3, 15, offset.fajar), end: formatTime(4, 20, offset.fajar), desc: 'রাতের শেষ তৃতীয়াংশ' }
  ];

  // Forbidden Times
  const forbiddenTimes = [
    { name: '১. সূর্যোদয়ের সময়', time: `${formatTime(5, 42, offset.sunrise)} থেকে প্রায় ১৫-২০ মিনিট (সকাল ৬:০২ পর্যন্ত)`, reason: 'সূর্যোদয়ের সময় কোনো নামাজ পড়া বা সিজদা করা নিষিদ্ধ।' },
    { name: '২. ঠিক দ্বিপ্রহরের সময় (সূর্য মাথার উপরে)', time: `${formatTime(11, 55, offset.dhuhr)} থেকে ${formatTime(12, 5, offset.dhuhr)} পর্যন্ত`, reason: 'সূর্য ঠিক মাথার উপর থাকাকালে এবং যোহরের ওয়াক্ত শুরুর আগের ১০ মিনিট।' },
    { name: '৩. সূর্যাস্তের সময়', time: `${formatTime(18, 10, offset.maghrib)} থেকে ${formatTime(18, 25, offset.maghrib)} পর্যন্ত (সূর্য ডোবার পূর্ববর্তী ১৫ মিনিট)`, reason: 'ঐ দিনের আসর কাযা হয়ে থাকলে শুধু তা আদায় করা যাবে, অন্য কোনো নফল পড়া হারাম।' }
  ];

  const duaCategories = ['সকল দোয়া', 'দৈনন্দিন', 'বিপদমুক্তি ও রোগমুক্তি', 'রিজিক ও বরকত', 'সফর ও বাহন', 'ক্ষমা ও তওবা'];

  const filteredDuas = ISLAMIC_DUAS_DATA.filter((dua) => {
    const matchesCat = selectedDuaCat === 'সকল দোয়া' || dua.category === selectedDuaCat;
    const matchesSearch = 
      dua.title.toLowerCase().includes(searchDua.toLowerCase()) ||
      dua.meaning.toLowerCase().includes(searchDua.toLowerCase()) ||
      dua.pronunciation.toLowerCase().includes(searchDua.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const filteredSurahs = TEN_SURAH_DATA.filter((surah) => {
    const q = searchSurah.toLowerCase();
    return (
      surah.nameBangla.toLowerCase().includes(q) ||
      surah.meaningName.toLowerCase().includes(q) ||
      surah.banglaPronunciation.toLowerCase().includes(q) ||
      surah.banglaMeaning.toLowerCase().includes(q)
    );
  });

  const handleSpeak = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeaking && speakingId === id) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'bn-BD';
    utterance.rate = 0.9;
    utterance.onend = () => {
      setIsSpeaking(false);
      setSpeakingId(null);
    };
    utterance.onerror = () => {
      setIsSpeaking(false);
      setSpeakingId(null);
    };

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
    setSpeakingId(id);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* 1. DYNAMIC ISLAMIC & WAQT HEADER WIDGET (আরবি তারিখ, জেলা ও লাইভ ওয়াক্ত কাউন্টডাউন) */}
      <PrayerHeaderWidget 
        currentDistrict={district} 
        onDistrictChange={handleDistrictChange} 
      />

      {/* Banner */}
      <div className="bg-[#2D5A27] text-white p-5 sm:p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
            🕌 ইসলামিক সেবা, সালাত ও আমল
          </span>
          <h2 className="text-lg sm:text-xl font-bold font-['Noto_Sans_Bengali']">
            নামাজের সময়সূচি, সালাতের নিয়ম ও প্রয়োজনীয় সূরা-দোয়া
          </h2>
          <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1 max-w-2xl">
            ৬৪ জেলার ওয়াক্ত, হানাফী ও আহলে হাদিস সালাতের নিয়ম, তাশাহহুদ, দরূদ, দোয়া মাসুরা, বিতরের কুনূত এবং নামাজে পঠিত ১০টি ছোট সূরা (ফাতিহা সহ)
          </p>
        </div>

        <div className="flex items-center gap-2 bg-[#23491E] border border-[#3D7A35] px-4 py-2 rounded-2xl text-xs text-[#D4E4BC]">
          <MapPin className="w-4 h-4 text-[#E8924A]" />
          <span>নির্বাচিত জেলা: <strong>{district}</strong></span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 bg-white p-2 rounded-3xl border border-[#E6E0D4] shadow-xs">
        <button
          onClick={() => setActiveTab('prayer')}
          className={`px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'prayer' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <span>🕌</span>
          <span>নামাজের সময় ও ওয়াক্ত</span>
        </button>

        <button
          onClick={() => setActiveTab('salat_rules')}
          className={`px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'salat_rules' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <span>📖</span>
          <span>সালাতের নিয়ম (হানাফী ও আহলে হাদিস)</span>
        </button>

        <button
          onClick={() => setActiveTab('salat_duas')}
          className={`px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'salat_duas' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <span>🤲</span>
          <span>তাশাহহুদ, দরূদ, মাসূরা ও কুনূত</span>
        </button>

        <button
          onClick={() => setActiveTab('surahs')}
          className={`px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'surahs' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <span>📜</span>
          <span>১০টি ছোট সূরা ও ফাতিহা</span>
        </button>

        <button
          onClick={() => setActiveTab('duas')}
          className={`px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'duas' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <span>✨</span>
          <span>দৈনন্দিন জীবনের দোয়া</span>
        </button>

        <button
          onClick={() => setActiveTab('mosques')}
          className={`px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'mosques' ? 'bg-[#2D5A27] text-white shadow-xs' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          <span>🧭</span>
          <span>কিবলা ও মসজিদ</span>
        </button>
      </div>

      {/* TAB 1: PRAYER TIMES & FORBIDDEN */}
      {activeTab === 'prayer' && (
        <div className="space-y-6">
          {/* Daily Prayers Card Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5">
            {prayers.map((p, idx) => (
              <div
                key={idx}
                className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 shadow-xs transition flex flex-col justify-between text-center"
              >
                <div>
                  <span className="text-2xl mb-1 block">{p.icon}</span>
                  <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                    {p.name}
                  </h3>
                  <p className="text-xl sm:text-2xl font-extrabold text-[#2D5A27] mt-2 font-['Noto_Sans_Bengali']">
                    {p.time}
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-[#E6E0D4] text-[11px] text-[#736B5E]">
                  <span>শেষ সময়: {p.end}</span>
                  <span className="block text-[10px] text-[#A65E2E] mt-0.5">{p.desc}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Forbidden Prayer Times (মাকরুহ/হারাম সময়) */}
          <div className="bg-[#FFF5F5] border border-[#FED7D7] rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-2">
              <AlertOctagon className="w-5 h-5 text-[#C0392B]" />
              <h3 className="font-bold text-base text-[#C0392B] font-['Noto_Sans_Bengali']">
                নামাজের ৩টি নিষিদ্ধ সময় (মাকরুহে তাহরিমি ও হারাম)
              </h3>
            </div>
            <p className="text-xs text-[#736B5E]">
              রাসুলুল্লাহ (সাঃ) এই ৩টি সময়ে যেকোনো ফরজ বা নফল নামাজ পড়তে এবং জানাজার নামাজ বা মৃতদেহ দাফন করতে নিষেধ করেছেন (সহিহ মুসলিম):
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {forbiddenTimes.map((f, idx) => (
                <div key={idx} className="bg-white p-4 rounded-2xl border border-[#FED7D7] space-y-1.5 shadow-2xs">
                  <span className="text-xs font-bold text-[#C0392B] block">{f.name}</span>
                  <p className="text-sm font-extrabold text-[#2D3A3A] font-['Noto_Sans_Bengali']">{f.time}</p>
                  <p className="text-[11px] text-[#736B5E] leading-relaxed pt-1">{f.reason}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB: SALAT RULES (HANAFI & AHLE HADITH) */}
      {activeTab === 'salat_rules' && (
        <div className="space-y-6">
          {/* Header & Harmony Message */}
          <div className="bg-[#FDFBF7] border border-[#E6E0D4] rounded-3xl p-5 sm:p-6 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs font-bold text-[#2D5A27] bg-[#D4E4BC]/60 px-3 py-1 rounded-full inline-flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  সহিহ সুন্নাহ ও মাযহাব নির্দেশিকা
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-[#2D3A3A] mt-2 font-['Noto_Sans_Bengali']">
                  সালাত আদায়ের ধারাবাহিক নিয়ম (হানাফী ও আহলে হাদীস)
                </h3>
              </div>

              {/* Maslak Filter Buttons */}
              <div className="flex flex-wrap gap-1.5 bg-white p-1.5 rounded-2xl border border-[#E6E0D4]">
                <button
                  onClick={() => setSelectedMaslak('both')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    selectedMaslak === 'both' ? 'bg-[#2D5A27] text-white' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
                  }`}
                >
                  উভয় পদ্ধতির তুলনা
                </button>
                <button
                  onClick={() => setSelectedMaslak('hanafi')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    selectedMaslak === 'hanafi' ? 'bg-[#2D5A27] text-white' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
                  }`}
                >
                  হানাফী পদ্ধতি
                </button>
                <button
                  onClick={() => setSelectedMaslak('ahlehadith')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    selectedMaslak === 'ahlehadith' ? 'bg-[#2D5A27] text-white' : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
                  }`}
                >
                  আহলে হাদীস পদ্ধতি
                </button>
              </div>
            </div>

            <div className="bg-amber-50/80 border border-amber-200/80 p-3.5 rounded-2xl text-xs text-amber-900 leading-relaxed flex items-start gap-2.5">
              <span className="text-base shrink-0">🤝</span>
              <p>
                <strong>ভ্রাতৃত্ব ও সহনশীলতার বার্তা:</strong> হানাফী ও আহলে হাদীস উভয় ধারার সালাতের পদ্ধতির স্বপক্ষেই রাসুলুল্লাহ (সাঃ) ও সাহাবিদের আমল থেকে নির্ভরযোগ্য সহিহ হাদিস বর্ণিত রয়েছে। এগুলো শাখা-প্রশাখাগত ইজতিহাদী বৈচিত্র্য। পরস্পরকে অপবাদ বা অবজ্ঞা না করে সহমর্মিতা রক্ষা করে পরম নিষ্ঠা ও একাগ্রতার সাথে সালাত কায়েম করাই ইসলামের মূল শিক্ষা।
              </p>
            </div>
          </div>

          {/* Steps List */}
          <div className="space-y-4">
            {SALAT_STEPS_COMPARISON.map((step) => (
              <div
                key={step.id}
                className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 sm:p-6 shadow-xs transition space-y-4"
              >
                {/* Step Title Header */}
                <div className="flex items-center justify-between gap-3 border-b border-[#E6E0D4] pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{step.icon}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-bold text-white bg-[#2D5A27] px-2 py-0.5 rounded-full">
                          ধাপ {toBanglaNumber(step.stepNumber)}
                        </span>
                        <h4 className="font-bold text-sm sm:text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                          {step.stepName}
                        </h4>
                      </div>
                    </div>
                  </div>

                  <span className="text-[11px] text-[#736B5E] hidden sm:inline bg-[#FDFBF7] px-3 py-1 rounded-xl border border-[#E6E0D4]">
                    দলিল: {step.hadithReference}
                  </span>
                </div>

                {/* General Rule */}
                <div className="text-xs sm:text-sm text-[#2D3A3A] bg-[#FDFBF7] p-3 rounded-2xl border border-[#E6E0D4] leading-relaxed">
                  <strong className="text-[#2D5A27]">মৌলিক সুন্নাহ নিয়ম: </strong>
                  <span>{step.generalRule}</span>
                </div>

                {/* Comparison Columns */}
                <div className={`grid gap-3.5 ${selectedMaslak === 'both' ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'}`}>
                  {/* Hanafi */}
                  {(selectedMaslak === 'both' || selectedMaslak === 'hanafi') && (
                    <div className="bg-emerald-50/40 border border-emerald-200 p-4 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full inline-block">
                          হানাফী মাযহাব পদ্ধতি
                        </span>
                        <span className="text-[10px] text-emerald-700">ইমাম আবু হানিফা (রহ.) অনুসৃত</span>
                      </div>
                      <p className="text-xs sm:text-sm text-[#2D3A3A] leading-relaxed pt-1">
                        {step.hanafiRule}
                      </p>
                    </div>
                  )}

                  {/* Ahle Hadith */}
                  {(selectedMaslak === 'both' || selectedMaslak === 'ahlehadith') && (
                    <div className="bg-sky-50/40 border border-sky-200 p-4 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-sky-800 bg-sky-100 px-2.5 py-0.5 rounded-full inline-block">
                          আহলে হাদীস / সালাফি পদ্ধতি
                        </span>
                        <span className="text-[10px] text-sky-700">সহিহ সুন্নাহ ও সরাসরি আমল</span>
                      </div>
                      <p className="text-xs sm:text-sm text-[#2D3A3A] leading-relaxed pt-1">
                        {step.ahleHadithRule}
                      </p>
                    </div>
                  )}
                </div>

                <div className="text-[11px] text-[#736B5E] sm:hidden pt-1">
                  <strong>হাদিস রেফারেন্স:</strong> {step.hadithReference}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: SALAT DUAS (TASHAHHUD, DUROOD, MASURA, QUNUT) */}
      {activeTab === 'salat_duas' && (
        <div className="space-y-6">
          <div className="bg-[#FDFBF7] border border-[#E6E0D4] rounded-3xl p-5 shadow-xs">
            <div className="flex items-center gap-3">
              <span className="p-2.5 rounded-2xl bg-[#D4E4BC] text-[#2D5A27]">
                <BookOpen className="w-5 h-5" />
              </span>
              <div>
                <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                  সালাতের ওয়াজিব ও সুন্নত দোয়াসমূহ
                </h3>
                <p className="text-xs text-[#736B5E] mt-0.5">
                  ছানা, রুকু-সিজদার তাসবিহ, তাশাহহুদ (আত্তাহিয়্যাতু), দরূদে ইব্রাহিম, দোয়ায়ে মাসুরা এবং বিতরের দোয়ায়ে কুনূত (হানাফী ও আহলে হাদিস পাঠ)
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {SALAT_DUAS_DATA.map((dua) => (
              <div
                key={dua.id}
                className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 sm:p-6 shadow-xs transition space-y-4"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-2 border-b border-[#E6E0D4] pb-3">
                  <div>
                    <h4 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                      {dua.title}
                    </h4>
                    <p className="text-xs text-[#736B5E] mt-0.5">{dua.subTitle}</p>
                    <span className="inline-block mt-2 text-[11px] font-semibold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                      কখন পড়বেন: {dua.whenToRecite}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => handleSpeak(dua.id, `${dua.title}। উচ্চারণ: ${dua.pronunciation}। অর্থ: ${dua.meaning}`)}
                      className="p-2 rounded-xl bg-[#FDFBF7] hover:bg-[#D4E4BC]/40 text-[#2D5A27] border border-[#E6E0D4] cursor-pointer"
                      title="বাংলায় শুনুন"
                    >
                      {isSpeaking && speakingId === dua.id ? <VolumeX className="w-4 h-4 text-[#C0392B]" /> : <Volume2 className="w-4 h-4" />}
                    </button>

                    <button
                      onClick={() => handleCopy(dua.id, `${dua.title}\n\nআরবি:\n${dua.arabic}\n\nউচ্চারণ:\n${dua.pronunciation}\n\nঅর্থ:\n${dua.meaning}\n\nরেফারেন্স: ${dua.reference}`)}
                      className="p-2 rounded-xl bg-[#FDFBF7] hover:bg-[#D4E4BC]/40 text-[#2D5A27] border border-[#E6E0D4] cursor-pointer"
                      title="কপি করুন"
                    >
                      {copiedId === dua.id ? <Check className="w-4 h-4 text-[#2D5A27]" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Arabic */}
                <div className="bg-[#FDFBF7] p-4 sm:p-5 rounded-2xl border border-[#E6E0D4] text-right">
                  <p className="text-lg sm:text-2xl font-serif text-[#2D5A27] leading-loose tracking-wide">
                    {dua.arabic}
                  </p>
                </div>

                {/* Pronunciation & Meaning */}
                <div className="space-y-2.5 text-xs sm:text-sm text-[#2D3A3A] leading-relaxed">
                  <p className="bg-[#FDFBF7] p-3 rounded-xl border border-[#E6E0D4]">
                    <strong className="text-[#A65E2E] block mb-1">বাংলা উচ্চারণ: </strong>
                    <span className="text-[#4A5568]">{dua.pronunciation}</span>
                  </p>

                  <p className="bg-[#FDFBF7] p-3 rounded-xl border border-[#E6E0D4]">
                    <strong className="text-[#2D5A27] block mb-1">বাংলা অর্থ: </strong>
                    <span className="text-[#2D3A3A]">{dua.meaning}</span>
                  </p>

                  {dua.maslakNote && (
                    <div className="text-xs bg-amber-50/80 p-3 rounded-xl border border-amber-200 text-amber-900 leading-relaxed">
                      <strong>মাযহাব ও সুন্নাহ নোট: </strong> {dua.maslakNote}
                    </div>
                  )}

                  <p className="text-[11px] text-[#736B5E] pt-1">
                    <strong>হাদিস রেফারেন্স: </strong> {dua.reference}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: 10 SHORT SURAHS + AL-FATIHA */}
      {activeTab === 'surahs' && (
        <div className="space-y-6">
          {/* Header & Search */}
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-[#E6E0D4] shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
            <div>
              <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                নামাজে পঠিত ১০টি ছোট সূরা ও সূরা আল-ফাতিহা
              </h3>
              <p className="text-xs text-[#736B5E] mt-0.5">
                প্রতিটি সূরার বিশুদ্ধ আরবি পাঠ, বাংলা উচ্চারণ, অনুবাদ ও সালাতে পাঠের ফজিলত
              </p>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-[#736B5E] absolute left-3.5 top-3" />
              <input
                type="text"
                placeholder="সূরার নাম বা অর্থ খুঁজুন..."
                value={searchSurah}
                onChange={(e) => setSearchSurah(e.target.value)}
                className="w-full pl-9 pr-3.5 py-2 bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
              />
            </div>
          </div>

          {/* Surahs List */}
          <div className="space-y-5">
            {filteredSurahs.map((surah) => (
              <div
                key={surah.id}
                className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 sm:p-6 shadow-xs transition space-y-4"
              >
                {/* Header with Badges */}
                <div className="flex flex-wrap items-start justify-between gap-2 border-b border-[#E6E0D4] pb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-[#D4E4BC]/60 flex items-center justify-center text-[#2D5A27] font-bold text-sm">
                      {toBanglaNumber(surah.number)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-base sm:text-lg text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                          {surah.nameBangla}
                        </h4>
                        <span className="text-sm font-serif text-[#2D5A27]">{surah.nameArabic}</span>
                      </div>
                      <p className="text-xs text-[#736B5E]">
                        অর্থ: <strong>{surah.meaningName}</strong> • {surah.revelationType} • {toBanglaNumber(surah.ayahCount)} আয়াত
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleSpeak(surah.id, `${surah.nameBangla}। অর্থ: ${surah.meaningName}। উচ্চারণ: ${surah.banglaPronunciation}। অনুবাদ: ${surah.banglaMeaning}`)}
                      className="p-2 rounded-xl bg-[#FDFBF7] hover:bg-[#D4E4BC]/40 text-[#2D5A27] border border-[#E6E0D4] cursor-pointer"
                      title="উচ্চারণ ও অর্থ শুনুন"
                    >
                      {isSpeaking && speakingId === surah.id ? <VolumeX className="w-4 h-4 text-[#C0392B]" /> : <Volume2 className="w-4 h-4" />}
                    </button>

                    <button
                      onClick={() => handleCopy(surah.id, `${surah.nameBangla} (${surah.nameArabic})\n\nআরবি:\n${surah.arabicText}\n\nউচ্চারণ:\n${surah.banglaPronunciation}\n\nবাংলা অনুবাদ:\n${surah.banglaMeaning}\n\nনামাজে পাঠ: ${surah.prayerContext}`)}
                      className="p-2 rounded-xl bg-[#FDFBF7] hover:bg-[#D4E4BC]/40 text-[#2D5A27] border border-[#E6E0D4] cursor-pointer"
                      title="সূরা কপি করুন"
                    >
                      {copiedId === surah.id ? <Check className="w-4 h-4 text-[#2D5A27]" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Arabic Text */}
                <div className="bg-[#FDFBF7] p-4 sm:p-6 rounded-2xl border border-[#E6E0D4] text-right">
                  <p className="text-lg sm:text-2xl font-serif text-[#2D5A27] leading-loose tracking-wide whitespace-pre-line">
                    {surah.arabicText}
                  </p>
                </div>

                {/* Pronunciation & Translation */}
                <div className="space-y-3 text-xs sm:text-sm text-[#2D3A3A] leading-relaxed">
                  <div className="bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#E6E0D4]">
                    <strong className="text-[#A65E2E] block mb-1.5 font-bold">বাংলা উচ্চারণ:</strong>
                    <div className="text-[#4A5568] whitespace-pre-line leading-relaxed">
                      {surah.banglaPronunciation}
                    </div>
                  </div>

                  <div className="bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#E6E0D4]">
                    <strong className="text-[#2D5A27] block mb-1.5 font-bold">বাংলা অনুবাদ ও অর্থ:</strong>
                    <div className="text-[#2D3A3A] whitespace-pre-line leading-relaxed">
                      {surah.banglaMeaning}
                    </div>
                  </div>

                  <div className="text-xs text-[#736B5E] bg-[#F9E5D4]/40 p-3 rounded-2xl border border-[#F9E5D4] leading-relaxed">
                    <strong className="text-[#A65E2E]">নামাজে পড়ার নিয়ম ও ফজিলত: </strong> {surah.prayerContext}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: IMPORTANT DUAS */}
      {activeTab === 'duas' && (
        <div className="space-y-6">
          {/* Categories & Search */}
          <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full sm:w-auto pb-1 sm:pb-0">
              {duaCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedDuaCat(cat)}
                  className={`px-3.5 py-1.5 rounded-2xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                    selectedDuaCat === cat
                      ? 'bg-[#2D5A27] text-white shadow-xs'
                      : 'bg-[#FDFBF7] text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-[#736B5E] absolute left-3.5 top-3" />
              <input
                type="text"
                placeholder="দোয়া বা অর্থ খুঁজুন..."
                value={searchDua}
                onChange={(e) => setSearchDua(e.target.value)}
                className="w-full pl-9 pr-3.5 py-2 bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
              />
            </div>
          </div>

          {/* Duas List */}
          <div className="space-y-4">
            {filteredDuas.map((dua) => (
              <div
                key={dua.id}
                className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-6 shadow-xs transition space-y-4"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                      {dua.category}
                    </span>
                    <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                      {dua.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleSpeak(dua.id, `${dua.title}। উচ্চারণ: ${dua.pronunciation}। অর্থ: ${dua.meaning}`)}
                      className="p-2 rounded-xl bg-[#FDFBF7] hover:bg-[#D4E4BC]/40 text-[#2D5A27] border border-[#E6E0D4] cursor-pointer"
                      title="বাংলায় শুনুন"
                    >
                      {isSpeaking && speakingId === dua.id ? <VolumeX className="w-4 h-4 text-[#C0392B]" /> : <Volume2 className="w-4 h-4" />}
                    </button>

                    <button
                      onClick={() => handleCopy(dua.id, `${dua.title}\n\nআরবি: ${dua.arabic}\n\nউচ্চারণ: ${dua.pronunciation}\n\nঅর্থ: ${dua.meaning}\n\nফজিলত: ${dua.virtue}`)}
                      className="p-2 rounded-xl bg-[#FDFBF7] hover:bg-[#D4E4BC]/40 text-[#2D5A27] border border-[#E6E0D4] cursor-pointer"
                      title="দোয়া কপি করুন"
                    >
                      {copiedId === dua.id ? <Check className="w-4 h-4 text-[#2D5A27]" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Arabic */}
                <div className="bg-[#FDFBF7] p-4 rounded-2xl border border-[#E6E0D4] text-right">
                  <p className="text-lg sm:text-xl font-serif text-[#2D5A27] leading-loose tracking-wide">
                    {dua.arabic}
                  </p>
                </div>

                {/* Pronunciation & Meaning */}
                <div className="space-y-2 text-xs sm:text-sm text-[#2D3A3A] leading-relaxed">
                  <p>
                    <strong className="text-[#A65E2E]">উচ্চারণ: </strong>
                    <span className="text-[#5A6B6B]">{dua.pronunciation}</span>
                  </p>
                  <p>
                    <strong className="text-[#2D5A27]">অর্থ: </strong>
                    <span>{dua.meaning}</span>
                  </p>
                  <p className="text-xs text-[#736B5E] bg-[#F9E5D4]/40 p-2.5 rounded-xl border border-[#F9E5D4]">
                    <strong>ফজিলত ও হাদিস রেফারেন্স: </strong> {dua.virtue}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: NEARBY MOSQUES & QIBLA */}
      {activeTab === 'mosques' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Qibla Compass Guide */}
            <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <Compass className="w-6 h-6 text-[#2D5A27]" />
                <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                  কিবলা নির্দেশিকা (বাংলাদেশ থেকে)
                </h3>
              </div>

              <div className="bg-[#FDFBF7] p-4 rounded-2xl border border-[#E6E0D4] space-y-2 text-xs text-[#5A6B6B] leading-relaxed">
                <p>
                  • বাংলাদেশ থেকে পবিত্র কাবার (কিবলা) দিক হলো <strong>পশ্চিম-দক্ষিণ কোণে (West-Southwest)</strong>।
                </p>
                <p>
                  • কম্পাসের কাঁটা অনুযায়ী কিবলার কোণ হলো <strong>২৭১° থেকে ২৭৫° ডিগ্রি (Degrees)</strong>।
                </p>
                <p>
                  • সূর্য অস্ত যাওয়ার দিক (পশ্চিম) থেকে সামান্য বামে মুখ করে দাঁড়ালে কিবলামুখী হওয়া যায়।
                </p>
              </div>

              <div className="p-4 bg-[#D4E4BC]/30 rounded-2xl border border-[#D4E4BC] text-center">
                <span className="text-xs text-[#2D5A27] font-semibold block">সঠিক কিবলার অভিমুখ</span>
                <p className="text-2xl font-black text-[#2D5A27] mt-1 font-['Noto_Sans_Bengali']">
                  ২৭২° পশ্চিম-দক্ষিণ কোণ
                </p>
              </div>
            </div>

            {/* Google Maps Nearby Mosques */}
            <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-6 h-6 text-[#E8924A]" />
                  <h3 className="font-bold text-base text-[#2D3A3A] font-['Noto_Sans_Bengali']">
                    আশপাশের জামে মসজিদ খুঁজুন
                  </h3>
                </div>

                <p className="text-xs text-[#736B5E] mt-2 leading-relaxed">
                  গুগল ম্যাপসের মাধ্যমে আপনার বর্তমান এলাকার নিকটস্থ জামে মসজিদ, দূরত্ব ও পৌঁছানোর রাস্তা এক ক্লিকে সরাসরি দেখে নিন।
                </p>
              </div>

              <div className="space-y-3 pt-4">
                <a
                  href={`https://www.google.com/maps/search/Mosque+near+me`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-3.5 rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition"
                >
                  <NavIcon className="w-4 h-4" />
                  <span>গুগল ম্যাপে আশপাশের মসজিদ দেখুন</span>
                </a>

                <a
                  href={`https://www.google.com/maps/search/Jame+Mosque+${encodeURIComponent(district)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-[#FDFBF7] hover:bg-[#E6E0D4] text-[#2D3A3A] border border-[#E6E0D4] font-bold py-3 rounded-2xl text-xs flex items-center justify-center gap-2 transition"
                >
                  <span>📍 {district} জেলার ঐতিহাসিক ও কেন্দ্রীয় মসজিদসমূহ</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
