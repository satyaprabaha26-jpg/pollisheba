import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Clock, 
  Navigation, 
  ChevronDown, 
  Sparkles, 
  Moon, 
  Sun, 
  Sunrise, 
  Compass, 
  Check, 
  AlertCircle, 
  Calendar as CalendarIcon,
  RefreshCw,
  Search,
  X
} from 'lucide-react';
import { 
  calculateDailyPrayerSchedule, 
  getWaqtCountdownStatus, 
  getHijriDateInfo,
  DailyPrayerSchedule,
  WaqtCountdownStatus,
  HijriDateInfo,
  normalizeDistrictName
} from '../../utils/prayerTimesCalculator';
import { toBanglaNumber } from '../../utils/banglaNumbers';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { detectCurrentLocationGPS } from '../../utils/locationService';

interface PrayerHeaderWidgetProps {
  currentDistrict: string;
  onDistrictChange?: (district: string) => void;
}

export const PrayerHeaderWidget: React.FC<PrayerHeaderWidgetProps> = ({
  currentDistrict,
  onDistrictChange
}) => {
  const [now, setNow] = useState<Date>(new Date());
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [gpsMessage, setGpsMessage] = useState<{ text: string; isError?: boolean } | null>(null);
  const [isDistrictModalOpen, setIsDistrictModalOpen] = useState<boolean>(false);
  const [searchDistrict, setSearchDistrict] = useState<string>('');
  const [manualHijriOffset, setManualHijriOffset] = useState<number>(0);
  const [showHijriAdjust, setShowHijriAdjust] = useState<boolean>(false);

  // Active district
  const district = currentDistrict && currentDistrict !== 'সকল জেলা' ? currentDistrict : 'ঢাকা';

  // Live timer tick every 1000ms
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Compute daily schedule and dynamic countdown status
  const schedule: DailyPrayerSchedule = calculateDailyPrayerSchedule(now, district);
  const countdown: WaqtCountdownStatus = getWaqtCountdownStatus(now, schedule);
  const hijri: HijriDateInfo = getHijriDateInfo(now, countdown.isAfterMaghrib, manualHijriOffset);

  // Handle GPS location detection
  const handleGPSDetect = async () => {
    setIsLocating(true);
    setGpsMessage(null);
    try {
      const res = await detectCurrentLocationGPS();
      if (res.success && res.district) {
        if (onDistrictChange) {
          onDistrictChange(res.district);
        }
        setGpsMessage({
          text: `জিপিএস দ্বারা আপনার জেলা '${res.district}' শনাক্ত হয়েছে!`
        });
        setTimeout(() => setGpsMessage(null), 4000);
      } else {
        setGpsMessage({
          text: res.errorMessage || 'লোকেশন পাওয়া যায়নি। তালিকা থেকে জেলা বেছে নিন।',
          isError: true
        });
        setTimeout(() => setGpsMessage(null), 5000);
      }
    } catch (err) {
      setGpsMessage({
        text: 'জিপিএস সংযোগে সমস্যা হয়েছে। তালিকা থেকে জেলা নির্বাচন করুন।',
        isError: true
      });
      setTimeout(() => setGpsMessage(null), 5000);
    } finally {
      setIsLocating(false);
    }
  };

  const handleSelectDistrict = (dist: string) => {
    if (onDistrictChange) {
      onDistrictChange(dist);
    }
    setIsDistrictModalOpen(false);
    setSearchDistrict('');
  };

  // Filtered districts for modal
  const filteredDistricts = BANGLADESH_DISTRICTS.filter((d) =>
    d.toLowerCase().includes(searchDistrict.trim().toLowerCase())
  );

  const padNum = (n: number) => (n < 10 ? `০${toBanglaNumber(n)}` : toBanglaNumber(n));

  // Get icon for upcoming waqt
  const getWaqtIcon = (name: string) => {
    switch (name) {
      case 'ফজর':
        return '🌌';
      case 'যোহর':
        return '☀️';
      case 'আসর':
        return '🌤️';
      case 'মাগরিব':
        return '🌆';
      case 'এশা':
        return '🌙';
      case 'তাহাজ্জুদ':
        return '✨';
      default:
        return '🕌';
    }
  };

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1B3E17] via-[#24541F] to-[#173814] text-white shadow-lg border border-[#3D7A35]/60">
      {/* Subtle Islamic Motif Background Overlay */}
      <div 
        className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#D4AF37_1px,transparent_1px)] [background-size:16px_16px]"
        aria-hidden="true"
      />

      {/* Decorative ambient light */}
      <div className="absolute -top-16 -right-16 w-56 h-56 bg-[#4CA63B]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-16 -left-16 w-56 h-56 bg-[#D4AF37]/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative p-5 sm:p-7 space-y-5">
        {/* =========================================================================
            ১. লেআউট ও অবস্থান (UI Design):
            - বাম দিকে বর্তমান হিজরী/আরবি তারিখ স্পষ্ট অক্ষরে থাকবে
            - ডান দিকে ব্যবহারকারীর নির্বাচিত জেলা/এলাকার নাম থাকবে
           ========================================================================= */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#3D7A35]/50 pb-4">
          {/* LEFT: Hijri / Arabic Date */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#173814] border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shadow-inner shrink-0">
              <Moon className="w-6 h-6 text-[#E5C158]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-wider text-[#D4E4BC] font-medium flex items-center gap-1">
                  <span>আরবি / হিজরি ক্যালেন্ডার</span>
                  {countdown.isAfterMaghrib && (
                    <span className="inline-flex items-center text-[10px] bg-[#122D10] text-[#F39C12] border border-[#F39C12]/40 px-1.5 py-0.2 rounded-full">
                      মাগরিব পরবর্তী দিন
                    </span>
                  )}
                </span>
              </div>
              {/* Prominent Hijri Date Display */}
              <div className="text-lg sm:text-xl font-bold font-['Noto_Sans_Bengali'] text-[#FFF4D9] tracking-wide flex items-center gap-2">
                <span>{hijri.fullBanglaDate}</span>
                <button
                  type="button"
                  onClick={() => setShowHijriAdjust(!showHijriAdjust)}
                  title="চাঁদ দেখা অনুযায়ী দিন সমন্বয়"
                  className="text-[11px] text-[#A3D9A5] hover:text-[#FFF] underline cursor-pointer"
                >
                  {manualHijriOffset !== 0 ? `(${manualHijriOffset > 0 ? '+' : ''}${toBanglaNumber(manualHijriOffset)} দিন)` : 'সমন্বয়'}
                </button>
              </div>

              {/* Day rollover tip */}
              <p className="text-[11px] text-[#A3D9A5]/90 mt-0.5">
                {countdown.isAfterMaghrib 
                  ? '• সূর্যাস্ত (মাগরিব) পেরিয়ে যাওয়ায় নতুন আরবি দিন গণনা হচ্ছে'
                  : '• মাগরিবের পর স্বয়ংক্রিয়ভাবে পরবর্তী আরবি তারিখ শুরু হবে'}
              </p>
            </div>
          </div>

          {/* RIGHT: District & GPS Location Selector */}
          <div className="flex flex-wrap items-center gap-2 sm:self-center w-full sm:w-auto justify-between sm:justify-end">
            <div className="flex items-center gap-1.5 bg-[#173814]/90 border border-[#3D7A35] px-3.5 py-2 rounded-2xl shadow-xs">
              <MapPin className="w-4 h-4 text-[#F39C12] shrink-0" />
              <div className="text-xs">
                <span className="text-[#A3D9A5] block text-[10px]">নির্বাচিত এলাকা</span>
                <strong className="text-white font-bold">{district} জেলা</strong>
              </div>
            </div>

            {/* District Change Button */}
            <button
              type="button"
              onClick={() => setIsDistrictModalOpen(true)}
              className="px-3 py-2 rounded-2xl bg-[#2D5A27] hover:bg-[#386B31] border border-[#4CA63B]/60 text-xs font-semibold text-white transition flex items-center gap-1 cursor-pointer shadow-xs"
            >
              <span>জেলা বদলান</span>
              <ChevronDown className="w-3.5 h-3.5 text-[#D4E4BC]" />
            </button>

            {/* GPS Auto-detect Button */}
            <button
              type="button"
              onClick={handleGPSDetect}
              disabled={isLocating}
              className="px-3 py-2 rounded-2xl bg-[#F39C12] hover:bg-[#E67E22] text-[#1B3E17] text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-75"
              title="জিপিএস দিয়ে আপনার নিকটবর্তী জেলা নির্ধারণ করুন"
            >
              <Navigation className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
              <span>{isLocating ? 'শনাক্ত হচ্ছে...' : 'জিপিএস (GPS)'}</span>
            </button>
          </div>
        </div>

        {/* GPS Alert Toast if applicable */}
        {gpsMessage && (
          <div className={`text-xs px-4 py-2.5 rounded-2xl flex items-center justify-between gap-2 animate-fadeIn ${
            gpsMessage.isError ? 'bg-red-900/80 text-red-100 border border-red-600' : 'bg-emerald-800/80 text-emerald-100 border border-emerald-500'
          }`}>
            <span className="flex items-center gap-2">
              {gpsMessage.isError ? <AlertCircle className="w-4 h-4 text-red-300" /> : <Check className="w-4 h-4 text-emerald-300" />}
              {gpsMessage.text}
            </span>
            <button onClick={() => setGpsMessage(null)} className="text-white/80 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Manual Hijri Offset Adjuster (if toggled) */}
        {showHijriAdjust && (
          <div className="bg-[#173814] border border-[#D4AF37]/50 p-3 rounded-2xl text-xs flex flex-wrap items-center justify-between gap-2">
            <span className="text-[#D4E4BC]">
              🌙 স্থানীয় চাঁদ দেখা অনুসারে আরবি তারিখ সামঞ্জস্য করুন:
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setManualHijriOffset((prev) => prev - 1)}
                className="px-2.5 py-1 bg-[#24541F] hover:bg-[#2D5A27] rounded-lg border border-[#3D7A35] text-white cursor-pointer"
              >
                -১ দিন
              </button>
              <span className="font-bold text-white px-2">
                {manualHijriOffset === 0 ? 'স্বাভাবিক' : `${manualHijriOffset > 0 ? '+' : ''}${toBanglaNumber(manualHijriOffset)} দিন`}
              </span>
              <button
                type="button"
                onClick={() => setManualHijriOffset((prev) => prev + 1)}
                className="px-2.5 py-1 bg-[#24541F] hover:bg-[#2D5A27] rounded-lg border border-[#3D7A35] text-white cursor-pointer"
              >
                +১ দিন
              </button>
              {manualHijriOffset !== 0 && (
                <button
                  type="button"
                  onClick={() => setManualHijriOffset(0)}
                  className="text-[11px] text-[#E74C3C] hover:underline ml-2 cursor-pointer"
                >
                  রিসেট
                </button>
              )}
            </div>
          </div>
        )}

        {/* =========================================================================
            ২. টাইমার ও ওয়াক্তের লজিক (Dynamic Countdown):
            কার্ডের মাঝখানে পরবর্তী ওয়াক্ত শুরু হতে আর কত সময় বাকি আছে, তার একটি লাইভ
            কাউন্টডাউন টাইমার চলবে।
            লেখাগুলো স্বয়ংক্রিয়ভাবে নির্ধারিত নিয়মে পরিবর্তিত হবে:
            - ফজরের পর থেকে যোহর পর্যন্ত: "যোহরের ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
            - যোহরের পর থেকে আসর পর্যন্ত: "আসরের ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
            - আসরের পর থেকে মাগরিব পর্যন্ত: "মাগরিবের ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
            - মাগরিবের পর থেকে এশা পর্যন্ত: "এশার ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
            - এশার পর থেকে মধ্যরাত/তাহাজ্জুদ পর্যন্ত: "তাহাজ্জুদের ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
            - তাহাজ্জুদের সময় থেকে ফজর পর্যন্ত: "ফজরের ওয়াক্তের বাকি: XX ঘণ্টা XX মিনিট"
           ========================================================================= */}
        <div className="bg-[#153412]/80 border border-[#3D7A35] rounded-3xl p-5 sm:p-6 text-center shadow-inner relative overflow-hidden">
          {/* Subtle Top badge */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#23491E] border border-[#3D7A35] text-xs text-[#D4E4BC] mb-3">
            <span>{getWaqtIcon(countdown.targetWaqtName)}</span>
            <span>বর্তমান অবস্থা: <strong>{countdown.currentWaqtName}</strong></span>
            <span className="text-[#4CA63B]">•</span>
            <span>পরবর্তী ওয়াক্ত: <strong>{countdown.targetWaqtName}</strong> ({countdown.nextStartTimeFormatted})</span>
          </div>

          {/* EXACT USER-REQUESTED DYNAMIC COUNTDOWN TEXT PHRASE */}
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold font-['Noto_Sans_Bengali'] text-[#FFF] tracking-wide mb-4">
            {countdown.targetPhrase}
          </h1>

          {/* Large Live Digital Countdown Boxes */}
          <div className="flex items-center justify-center gap-2 sm:gap-4 my-2">
            {/* Hours Box */}
            <div className="flex flex-col items-center">
              <div className="w-16 sm:w-20 h-16 sm:h-20 bg-gradient-to-b from-[#1C4518] to-[#0E240C] border-2 border-[#D4AF37]/50 rounded-2xl flex items-center justify-center text-2xl sm:text-4xl font-bold font-mono text-[#F39C12] shadow-md">
                {padNum(countdown.hours)}
              </div>
              <span className="text-[11px] sm:text-xs text-[#A3D9A5] mt-1.5 font-medium">ঘণ্টা</span>
            </div>

            <span className="text-2xl sm:text-4xl font-bold text-[#D4AF37] mb-5 animate-pulse">:</span>

            {/* Minutes Box */}
            <div className="flex flex-col items-center">
              <div className="w-16 sm:w-20 h-16 sm:h-20 bg-gradient-to-b from-[#1C4518] to-[#0E240C] border-2 border-[#D4AF37]/50 rounded-2xl flex items-center justify-center text-2xl sm:text-4xl font-bold font-mono text-[#F39C12] shadow-md">
                {padNum(countdown.minutes)}
              </div>
              <span className="text-[11px] sm:text-xs text-[#A3D9A5] mt-1.5 font-medium">মিনিট</span>
            </div>

            <span className="text-2xl sm:text-4xl font-bold text-[#D4AF37] mb-5 animate-pulse">:</span>

            {/* Seconds Box */}
            <div className="flex flex-col items-center">
              <div className="w-16 sm:w-20 h-16 sm:h-20 bg-gradient-to-b from-[#1C4518] to-[#0E240C] border-2 border-[#D4AF37]/50 rounded-2xl flex items-center justify-center text-2xl sm:text-4xl font-bold font-mono text-[#F39C12] shadow-md">
                {padNum(countdown.seconds)}
              </div>
              <span className="text-[11px] sm:text-xs text-[#A3D9A5] mt-1.5 font-medium">সেকেন্ড</span>
            </div>
          </div>

          {/* Progress Bar showing how much time has passed toward the next waqt */}
          <div className="max-w-md mx-auto mt-4">
            <div className="flex items-center justify-between text-[11px] text-[#A3D9A5] mb-1">
              <span>চলমান ওয়াক্ত অতিবাহিত</span>
              <span>{toBanglaNumber(countdown.elapsedPercent)}% সমাপ্ত</span>
            </div>
            <div className="w-full bg-[#0E240C] h-2 rounded-full overflow-hidden border border-[#23491E]">
              <div 
                className="bg-gradient-to-r from-[#2D5A27] via-[#F39C12] to-[#E67E22] h-full rounded-full transition-all duration-1000 ease-linear"
                style={{ width: `${countdown.elapsedPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* =========================================================================
            Today's 6 Waqts at a Glance for Selected District
           ========================================================================= */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-[#D4E4BC] px-1">
            <span className="font-semibold flex items-center gap-1.5">
              <span>🕌</span>
              <span>{district} জেলার আজকের নির্ধারিত ওয়াক্তসমূহ:</span>
            </span>
            <span className="text-[11px] text-[#A3D9A5]">
              {schedule.offsetMinutes === 0 
                ? 'ঢাকার স্ট্যান্ডার্ড সময়' 
                : `ঢাকার সাথে অফসেট: ${schedule.offsetMinutes > 0 ? '+' : ''}${toBanglaNumber(schedule.offsetMinutes)} মিনিট`}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
            {/* Fajr */}
            <div className={`p-2.5 rounded-2xl border text-center transition ${
              countdown.targetWaqtName === 'ফজর'
                ? 'bg-[#F39C12]/20 border-[#F39C12] shadow-sm'
                : 'bg-[#173814]/70 border-[#3D7A35]/60'
            }`}>
              <div className="text-sm">🌌</div>
              <div className="text-xs font-semibold text-white mt-0.5">ফজর</div>
              <div className="text-sm font-bold text-[#E5C158] mt-0.5 font-mono">
                {schedule.fajr.formattedTime}
              </div>
              <div className="text-[10px] text-[#A3D9A5]">ভোর</div>
            </div>

            {/* Dhuhr */}
            <div className={`p-2.5 rounded-2xl border text-center transition ${
              countdown.targetWaqtName === 'যোহর'
                ? 'bg-[#F39C12]/20 border-[#F39C12] shadow-sm'
                : 'bg-[#173814]/70 border-[#3D7A35]/60'
            }`}>
              <div className="text-sm">☀️</div>
              <div className="text-xs font-semibold text-white mt-0.5">যোহর</div>
              <div className="text-sm font-bold text-[#E5C158] mt-0.5 font-mono">
                {schedule.dhuhr.formattedTime}
              </div>
              <div className="text-[10px] text-[#A3D9A5]">দুপুর</div>
            </div>

            {/* Asr */}
            <div className={`p-2.5 rounded-2xl border text-center transition ${
              countdown.targetWaqtName === 'আসর'
                ? 'bg-[#F39C12]/20 border-[#F39C12] shadow-sm'
                : 'bg-[#173814]/70 border-[#3D7A35]/60'
            }`}>
              <div className="text-sm">🌤️</div>
              <div className="text-xs font-semibold text-white mt-0.5">আসর</div>
              <div className="text-sm font-bold text-[#E5C158] mt-0.5 font-mono">
                {schedule.asr.formattedTime}
              </div>
              <div className="text-[10px] text-[#A3D9A5]">বিকাল</div>
            </div>

            {/* Maghrib */}
            <div className={`p-2.5 rounded-2xl border text-center transition ${
              countdown.targetWaqtName === 'মাগরিব'
                ? 'bg-[#F39C12]/20 border-[#F39C12] shadow-sm'
                : 'bg-[#173814]/70 border-[#3D7A35]/60'
            }`}>
              <div className="text-sm">🌆</div>
              <div className="text-xs font-semibold text-white mt-0.5">মাগরিব</div>
              <div className="text-sm font-bold text-[#E5C158] mt-0.5 font-mono">
                {schedule.maghrib.formattedTime}
              </div>
              <div className="text-[10px] text-[#A3D9A5]">সন্ধ্যা</div>
            </div>

            {/* Isha */}
            <div className={`p-2.5 rounded-2xl border text-center transition ${
              countdown.targetWaqtName === 'এশা'
                ? 'bg-[#F39C12]/20 border-[#F39C12] shadow-sm'
                : 'bg-[#173814]/70 border-[#3D7A35]/60'
            }`}>
              <div className="text-sm">🌙</div>
              <div className="text-xs font-semibold text-white mt-0.5">এশা ও বিতর</div>
              <div className="text-sm font-bold text-[#E5C158] mt-0.5 font-mono">
                {schedule.isha.formattedTime}
              </div>
              <div className="text-[10px] text-[#A3D9A5]">রাত</div>
            </div>

            {/* Tahajjud */}
            <div className={`p-2.5 rounded-2xl border text-center transition ${
              countdown.targetWaqtName === 'তাহাজ্জুদ'
                ? 'bg-[#F39C12]/20 border-[#F39C12] shadow-sm'
                : 'bg-[#173814]/70 border-[#3D7A35]/60'
            }`}>
              <div className="text-sm">✨</div>
              <div className="text-xs font-semibold text-white mt-0.5">তাহাজ্জুদ</div>
              <div className="text-sm font-bold text-[#E5C158] mt-0.5 font-mono">
                {schedule.tahajjud.formattedTime}
              </div>
              <div className="text-[10px] text-[#A3D9A5]">শেষরাত</div>
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          District Selector Modal (Searchable 64 Districts)
         ========================================================================= */}
      {isDistrictModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fadeIn">
          <div className="bg-[#1C4518] border-2 border-[#D4AF37]/60 text-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-[#173814] border-b border-[#3D7A35] flex items-center justify-between">
              <div>
                <h3 className="text-base sm:text-lg font-bold flex items-center gap-2 text-[#FFF4D9]">
                  <MapPin className="w-5 h-5 text-[#F39C12]" />
                  <span>জেলা নির্বাচন করুন (৬৪ জেলা)</span>
                </h3>
                <p className="text-xs text-[#A3D9A5] mt-0.5">
                  আপনার নির্বাচিত জেলা অনুযায়ী সঠিক নামাজের সময় ও ওয়াক্ত নির্ধারিত হবে।
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsDistrictModalOpen(false)}
                className="w-9 h-9 rounded-full bg-[#24541F] hover:bg-[#2D5A27] flex items-center justify-center text-white/80 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Search Input & GPS Quick Action */}
            <div className="p-4 border-b border-[#3D7A35]/50 bg-[#1A4016] space-y-3">
              <div className="relative">
                <Search className="w-4 h-4 text-[#A3D9A5] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchDistrict}
                  onChange={(e) => setSearchDistrict(e.target.value)}
                  placeholder="জেলার নাম লিখুন (যেমন: ঢাকা, বগুড়া, সিলেট...)"
                  className="w-full bg-[#112910] border border-[#3D7A35] rounded-2xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder:text-[#A3D9A5]/60 focus:outline-hidden focus:border-[#F39C12]"
                  autoFocus
                />
                {searchDistrict && (
                  <button
                    type="button"
                    onClick={() => setSearchDistrict('')}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-[#A3D9A5] hover:text-white"
                  >
                    মুছুন
                  </button>
                )}
              </div>

              {/* GPS Auto Detect Banner inside Modal */}
              <button
                type="button"
                onClick={() => {
                  setIsDistrictModalOpen(false);
                  handleGPSDetect();
                }}
                className="w-full py-2.5 px-4 bg-[#F39C12] hover:bg-[#E67E22] text-[#1B3E17] font-bold rounded-2xl text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <Navigation className="w-4 h-4" />
                <span>আমার বর্তমান জিপিএস (GPS) অবস্থান অনুযায়ী স্বয়ংক্রিয় নির্ধারণ</span>
              </button>
            </div>

            {/* Districts Grid */}
            <div className="p-4 overflow-y-auto max-h-[50vh] space-y-2">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {filteredDistricts.map((d) => {
                  const isSelected = normalizeDistrictName(d) === normalizeDistrictName(district);
                  return (
                    <button
                      key={d}
                      type="button"
                      onClick={() => handleSelectDistrict(d)}
                      className={`p-2.5 rounded-2xl text-xs font-semibold text-left transition flex items-center justify-between cursor-pointer border ${
                        isSelected
                          ? 'bg-[#F39C12] text-[#1B3E17] border-[#F39C12] shadow-sm'
                          : 'bg-[#153412] hover:bg-[#23491E] text-white border-[#3D7A35]/50'
                      }`}
                    >
                      <span className="truncate">{d}</span>
                      {isSelected && <Check className="w-4 h-4 shrink-0 text-[#1B3E17]" />}
                    </button>
                  );
                })}
              </div>

              {filteredDistricts.length === 0 && (
                <div className="text-center py-8 text-[#A3D9A5] text-xs">
                  '{searchDistrict}' নামে কোনো জেলা খুঁজে পাওয়া যায়নি।
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-[#173814] border-t border-[#3D7A35] flex items-center justify-between text-xs text-[#A3D9A5]">
              <span>বর্তমান নির্বাচন: <strong className="text-white">{district}</strong></span>
              <button
                type="button"
                onClick={() => setIsDistrictModalOpen(false)}
                className="px-4 py-1.5 rounded-xl bg-[#24541F] hover:bg-[#2D5A27] text-white cursor-pointer font-medium"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
