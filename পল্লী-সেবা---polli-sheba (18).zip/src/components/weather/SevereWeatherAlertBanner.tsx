import React, { useState, useEffect } from 'react';
import { 
  CloudLightning, 
  ShieldAlert, 
  X, 
  Volume2, 
  VolumeX, 
  AlertTriangle, 
  CheckCircle2, 
  PhoneCall, 
  Info,
  MapPin,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { getDistrictWeather, DistrictWeatherData } from '../../utils/weatherService';

interface SevereWeatherAlertBannerProps {
  district: string;
  upazila?: string;
}

export const SevereWeatherAlertBanner: React.FC<SevereWeatherAlertBannerProps> = ({ district, upazila }) => {
  const [weather, setWeather] = useState<DistrictWeatherData | null>(null);
  const [isDismissed, setIsDismissed] = useState<boolean>(false);
  const [showSafetyGuide, setShowSafetyGuide] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Load weather whenever district changes
  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      try {
        const data = await getDistrictWeather(district || 'ঢাকা');
        if (isMounted) {
          setWeather(data);
          // Check if session dismissed this specific alert
          const dismissedKey = `pollisheba_alert_dismissed_${district}_${new Date().toDateString()}`;
          const alreadyDismissed = sessionStorage.getItem(dismissedKey);
          if (alreadyDismissed) {
            setIsDismissed(true);
          } else {
            setIsDismissed(false);
          }
        }
      } catch (err) {
        console.error('Failed to load alert weather data:', err);
      }
    };
    load();
    return () => {
      isMounted = false;
    };
  }, [district]);

  // Audio Speech synthesis for rural farmers
  const handleToggleVoice = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      alert('আপনার ব্রাউজারে ভয়েস সাপোর্ট নেই।');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    // Clean district name to avoid double "জেলা জেলা" or awkward grammar
    const isAll = !district || district === 'সকল জেলা';
    const cleanDist = isAll ? 'সকল জেলা' : district.replace(/\s*জেলা\s*$/, '').trim();
    const distInRegion = isAll ? 'সারাদেশে' : `${cleanDist} জেলায়`;

    const speechText = `সতর্কবার্তা! ${distInRegion} বজ্রপাত ও দুর্যোগপূর্ণ আবহাওয়ার সম্ভাবনা রয়েছে। মাঠে থাকা কৃষকরা দ্রুত নিরাপদ পাকা ঘরে আশ্রয় নিন। কোনো অবস্থাতেই বড় গাছের নিচে দাঁড়াবেন না। কাস্তে, কোদাল ও ধাতব সামগ্রী দূরে রাখুন।`;
    const utterance = new SpeechSynthesisUtterance(speechText);
    utterance.lang = 'bn-BD';
    utterance.rate = 0.9;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const handleDismiss = () => {
    setIsDismissed(true);
    if (typeof window !== 'undefined') {
      const dismissedKey = `pollisheba_alert_dismissed_${district}_${new Date().toDateString()}`;
      sessionStorage.setItem(dismissedKey, 'true');
    }
    if (isSpeaking && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  // Check if there is an alert: either lightning, high rain >= 70%, or explicit safetyAlert
  const hasSevereWeather = weather && (
    weather.safetyAlert?.type === 'lightning' ||
    weather.iconType === 'cloud-lightning' ||
    weather.conditionText.includes('বজ্র') ||
    weather.rainChance >= 70 ||
    weather.safetyAlert?.level === 'red' ||
    weather.safetyAlert?.level === 'orange'
  );

  if (!hasSevereWeather || isDismissed) {
    return null;
  }

  const isLightning = weather?.safetyAlert?.type === 'lightning' || 
                      weather?.iconType === 'cloud-lightning' || 
                      weather?.conditionText.includes('বজ্র');

  // Clean district name to avoid double "জেলা জেলা" and ensure natural Bengali phrasing
  const isAllDistricts = !district || district === 'সকল জেলা';
  const cleanDistrict = isAllDistricts ? 'সকল জেলা' : district.replace(/\s*জেলা\s*$/, '').trim();
  const districtBadgeLabel = isAllDistricts ? 'সকল জেলা' : `${cleanDistrict} জেলা`;
  const districtInRegion = isAllDistricts ? 'সারাদেশে' : `${cleanDistrict} জেলায়`;
  const districtArea = isAllDistricts ? 'সারাদেশ ও পার্শ্ববর্তী এলাকায়' : `${cleanDistrict} ও পার্শ্ববর্তী এলাকায়`;

  return (
    <>
      {/* Prominent Dismissible Banner */}
      <div 
        id="severe-weather-alert-banner"
        className={`mb-4 rounded-3xl p-4 sm:p-5 text-white shadow-lg border relative overflow-hidden transition-all duration-300 animate-in fade-in slide-in-from-top-3 ${
          isLightning 
            ? 'bg-gradient-to-r from-red-700 via-rose-700 to-amber-700 border-red-500/80 shadow-red-900/20' 
            : 'bg-gradient-to-r from-amber-700 via-orange-700 to-rose-700 border-amber-500/80 shadow-amber-900/20'
        }`}
      >
        {/* Subtle decorative background pulse */}
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-yellow-300/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex items-start justify-between gap-3">
          {/* Alert Icon & Text Content */}
          <div className="flex items-start gap-3 sm:gap-4 flex-1">
            <div className={`w-11 h-11 sm:w-13 sm:h-13 rounded-2xl flex items-center justify-center shrink-0 shadow-md ${
              isLightning ? 'bg-red-950/70 text-yellow-300 animate-pulse' : 'bg-amber-950/70 text-yellow-200'
            }`}>
              {isLightning ? (
                <CloudLightning className="w-6 h-6 sm:w-7 sm:h-7 animate-bounce" />
              ) : (
                <ShieldAlert className="w-6 h-6 sm:w-7 sm:h-7" />
              )}
            </div>

            <div className="space-y-1.5 flex-1 pr-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[11px] font-black uppercase tracking-wider bg-black/30 backdrop-blur-xs px-2.5 py-0.5 rounded-full text-yellow-300 border border-yellow-300/30 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  <span>জরুরি আবহাওয়া সতর্কতা</span>
                </span>
                <span className="text-xs text-white/90 font-bold flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-yellow-300" />
                  <span>{districtBadgeLabel} {upazila ? `(${upazila})` : ''}</span>
                </span>
              </div>

              <h3 className="font-extrabold text-sm sm:text-base text-white font-['Noto_Sans_Bengali'] leading-snug">
                {isLightning 
                  ? `বজ্রপাত ও কালবৈশাখীর আশঙ্কা: ${districtInRegion} কৃষকদের সতর্ক থাকার নির্দেশ` 
                  : (weather.safetyAlert?.title 
                      ? (isAllDistricts ? weather.safetyAlert.title : `${weather.safetyAlert.title}: ${cleanDistrict}`)
                      : `ভারী বৃষ্টিপাত ও দুর্যোগপূর্ণ আবহাওয়ার সতর্কতা: ${cleanDistrict}`)}
              </h3>

              <p className="text-xs sm:text-sm text-white/95 leading-relaxed font-medium max-w-3xl">
                {isLightning 
                  ? `${districtArea} বজ্রবিদ্যুৎসহ ঝড়ো বৃষ্টি হতে পারে। মাঠে বা খোলা আকাশের নিচে থাকা অত্যন্ত ঝুঁকিপূর্ণ। অবিলম্বে নিরাপদ আশ্রয়ে অবস্থান নিন।`
                  : (isAllDistricts 
                      ? `সারাদেশের বিভিন্ন অঞ্চলে টানা ভারী বৃষ্টির সম্ভাবনা রয়েছে (${weather.rainChance}%)। মাঠের পাকা ফসল দ্রুত গোলায় তুলুন এবং প্রয়োজনীয় সতর্কতা অবলম্বন করুন।`
                      : (weather.safetyAlert?.message || `${cleanDistrict} এলাকায় প্রবল বৃষ্টির সম্ভাবনা রয়েছে (${weather.rainChance}%)। পাকা ফসল গোলায় তুলুন এবং প্রয়োজনীয় সতর্কতা অবলম্বন করুন।`))}
              </p>

              {/* Action Buttons: Safety Guide + Voice + Hotline */}
              <div className="pt-2 flex flex-wrap items-center gap-2 sm:gap-3">
                <button
                  type="button"
                  id="open-safety-guide-btn"
                  onClick={() => setShowSafetyGuide(true)}
                  className="bg-white hover:bg-amber-50 text-red-900 font-extrabold text-xs sm:text-sm px-4 py-2 rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5 hover:scale-[1.02]"
                >
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>বজ্রপাত থেকে বাঁচতে করণীয় নির্দেশিকা দেখুন</span>
                  <ChevronRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={handleToggleVoice}
                  className="bg-black/30 hover:bg-black/40 text-yellow-200 border border-yellow-300/40 text-xs font-bold px-3 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5"
                  title="সতর্কবার্তা মুখে শুনে জানুন"
                >
                  {isSpeaking ? <VolumeX className="w-4 h-4 text-red-300 animate-pulse" /> : <Volume2 className="w-4 h-4" />}
                  <span>{isSpeaking ? 'থামান' : 'মুখে শুনুন'}</span>
                </button>

                <a
                  href="tel:999"
                  className="bg-black/30 hover:bg-black/40 text-white border border-white/30 text-xs font-bold px-3 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-green-300" />
                  <span>জরুরি ৯৯৯</span>
                </a>
              </div>
            </div>
          </div>

          {/* Dismiss / Close Button (✕ চিহ্ন) */}
          <button
            type="button"
            id="dismiss-alert-banner-btn"
            onClick={handleDismiss}
            className="w-8 h-8 rounded-full bg-black/25 hover:bg-black/50 text-white flex items-center justify-center transition cursor-pointer shrink-0 border border-white/20"
            title="সতর্কবার্তাটি এই সেশনের জন্য বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Emergency Thunderstorm & Severe Weather Life-Saving Modal */}
      {showSafetyGuide && (
        <div 
          id="thunderstorm-safety-modal"
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
        >
          <div className="bg-[#FAF8F5] max-w-2xl w-full rounded-3xl border-2 border-red-500 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 my-6 max-h-[90vh] flex flex-col font-['Noto_Sans_Bengali']">
            {/* Header */}
            <div className="bg-gradient-to-r from-red-700 to-rose-800 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-yellow-300 shadow-inner">
                  <CloudLightning className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base sm:text-lg">
                    বজ্রপাত ও দুর্যোগপূর্ণ আবহাওয়ায় জীবনরক্ষার জরুরি নির্দেশিকা
                  </h3>
                  <p className="text-xs text-yellow-200">
                    মাঠে বা গ্রামে থাকা অবস্থায় প্রত্যেক কৃষকের যা জানা অতীব জরুরি
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowSafetyGuide(false)}
                className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-[#2D3A3A] leading-relaxed">
              
              {/* Alert Callout */}
              <div className="p-3.5 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-2.5 text-red-900">
                <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-xs font-bold text-red-800">
                    বিশেষ সতর্কতা (বাংলাদেশ আবহাওয়া অধিদপ্তর ও দুর্যোগ ব্যবস্থাপনা):
                  </strong>
                  <span>
                    বাংলাদেশে প্রতিবছর গড়ে প্রায় তিন শতাধিক মানুষ বজ্রপাতে প্রাণ হারান, যার সিংহভাগই মাঠে কর্মরত কৃষক। সামান্য সচেতনতাই জীবন বাঁচাতে পারে।
                  </span>
                </div>
              </div>

              {/* 1. খোলা মাঠ ও কৃষি জমিতে থাকাকালীন করণীয় */}
              <div className="bg-white p-4 rounded-2xl border border-[#D4C3A3] shadow-xs space-y-2">
                <h4 className="font-bold text-sm text-[#2D5A27] flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-black text-xs">১</span>
                  <span>খোলা মাঠ ও ফসলি জমিতে থাকাকালীন করণীয়</span>
                </h4>
                <ul className="space-y-1.5 pl-8 list-disc text-[#5A6B6B]">
                  <li>
                    <strong>দ্রুত মাঠ ত্যাগ করুন:</strong> আকাশে কালো মেঘ ও বিদ্যুৎ চমকাতে দেখলেই সঙ্গে সঙ্গে কৃষিকাজ বন্ধ করে নিকটস্থ পাকা বাড়িতে আশ্রয় নিন।
                  </li>
                  <li>
                    <strong>ধাতব বস্তু স্পর্শ নিষেধ:</strong> কাস্তে, কোদাল, লাঙল, নিড়ানি বা যেকোনো লোহার যন্ত্রপাতি অবিলম্বে মাটি থেকে দূরে রেখে সরে আসুন।
                  </li>
                  <li>
                    <strong>আশ্রয় না পেলে সঠিক বসার ভঙ্গি:</strong> আশেপাশে কোনো পাকা দালান না থাকলে খোলা মাঠে উঁচু হয়ে দাঁড়াবেন না। মাটিতে শুয়ে পড়বেন না। বরং দুই হাঁটু মুড়ে হাত দিয়ে দুই কান চেপে ধরে আঙুলের অগ্রভাগে নিচু হয়ে কুঁকড়ে বসে পড়ুন।
                  </li>
                </ul>
              </div>

              {/* 2. গাছের নিচে ভুলেও আশ্রয় নেবেন না */}
              <div className="bg-white p-4 rounded-2xl border border-[#D4C3A3] shadow-xs space-y-2">
                <h4 className="font-bold text-sm text-red-700 flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-red-100 text-red-700 flex items-center justify-center font-black text-xs">২</span>
                  <span>গাছের নিচে ভুলেও দাঁড়াবেন না (সবচেয়ে বড় ভুল)</span>
                </h4>
                <ul className="space-y-1.5 pl-8 list-disc text-[#5A6B6B]">
                  <li>
                    বজ্রপাতে নিহতদের প্রায় ৭০% মানুষ কোনো না কোনো বড় গাছ (যেমন বট, তালগাছ, নারিকেল গাছ বা একা দাঁড়িয়ে থাকা আম গাছ)-এর নিচে আশ্রয় নিয়েছিলেন।
                  </li>
                  <li>
                    উঁচু গাছ বজ্রপাতকে আকর্ষণ করে এবং গাছের গা বেয়ে বিদ্যুৎ মাটিতে ছড়িয়ে পড়ে। তাই কোনো গাছের নিচে আশ্রয় নেবেন না।
                  </li>
                </ul>
              </div>

              {/* 3. জলাশয়, নদী ও পুকুর */}
              <div className="bg-white p-4 rounded-2xl border border-[#D4C3A3] shadow-xs space-y-2">
                <h4 className="font-bold text-sm text-[#2D5A27] flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-black text-xs">৩</span>
                  <span>পুকুর, ডোবা বা নদীতে মাছ ধরার সময়</span>
                </h4>
                <ul className="space-y-1.5 pl-8 list-disc text-[#5A6B6B]">
                  <li>
                    পানি বিদ্যুতের অত্যন্ত সুপরিবাহী। মেঘ ডাকলে পুকুরে গোসল করা বা জাল দিয়ে মাছ ধরা তাৎক্ষণিক বন্ধ করে শুকনো ডাঙায় উঠে আসুন।
                  </li>
                  <li>
                    ছোট খোলা নৌকায় থাকলে দ্রুত তীরে এসে নৌকা বেঁধে নিরাপদ ঘরে প্রবেশ করুন।
                  </li>
                </ul>
              </div>

              {/* 4. বাড়িতে অবস্থানকালে করণীয় */}
              <div className="bg-white p-4 rounded-2xl border border-[#D4C3A3] shadow-xs space-y-2">
                <h4 className="font-bold text-sm text-[#2D5A27] flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-black text-xs">৪</span>
                  <span>টিনের ঘরে বা বাড়িতে অবস্থানকালে করণীয়</span>
                </h4>
                <ul className="space-y-1.5 pl-8 list-disc text-[#5A6B6B]">
                  <li>
                    টিনের বেড়া বা টিনের খুঁটি স্পর্শ করবেন না। ঘরের জানালাপট্টি থেকে দূরে ঘরের ভেতরের অংশে থাকুন।
                  </li>
                  <li>
                    মোবাইল ফোন চার্জে লাগানো অবস্থায় ব্যবহার করবেন না। টিভি, ফ্রিজ ও রাউটারের প্লাগ খুলে রাখুন।
                  </li>
                  <li>
                    বিদ্যুৎ চমকানোর সময় ধাতব পাইপের পানির কল চালু করে গোসল বা থালাবাসন ধোয়া থেকে বিরত থাকুন।
                  </li>
                </ul>
              </div>

              {/* 5. কেউ বজ্রপাতে আহত হলে তাৎক্ষণিক চিকিৎসা */}
              <div className="bg-[#E8F8F5] p-4 rounded-2xl border border-[#27AE60] shadow-xs space-y-2 text-[#145A32]">
                <h4 className="font-bold text-sm text-[#1E8449] flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[#27AE60]" />
                  <span>কেউ বজ্রপাতে আহত হলে তাৎক্ষণিক করণীয় (প্রাথমিক চিকিৎসা)</span>
                </h4>
                <p className="text-xs">
                  বজ্রপাতে আহত ব্যক্তির শরীরে কোনো বিদ্যুৎ জমে থাকে না, তাই তাকে নির্ভয়ে স্পর্শ করে সেবা দিন:
                </p>
                <ul className="space-y-1.5 pl-8 list-disc text-xs font-medium">
                  <li>
                    শ্বাসপ্রশ্বাস ও নাড়ির স্পন্দন পরীক্ষা করুন। যদি শ্বাস বন্ধ থাকে, তবে দ্রুত মুখে মুখ দিয়ে কৃত্রিম শ্বাস ও বুকে সিপিআর (CPR) চাপ দিন।
                  </li>
                  <li>
                    দেরি না করে তাৎক্ষণিক <strong>৯৯৯</strong> বা <strong>১৬২৬৩</strong> (স্বাস্থ্য বাতায়ন)-এ ফোন করে অ্যাম্বুলেন্স ডাকুন এবং নিকটস্থ উপজেলা স্বাস্থ্য কমপ্লেক্সে নিয়ে যান।
                  </li>
                </ul>
              </div>

            </div>

            {/* Footer */}
            <div className="bg-[#FAF8F5] border-t border-[#E6E0D4] p-4 flex flex-wrap items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2 text-xs text-[#736B5E]">
                <Info className="w-4 h-4 text-[#2D5A27]" />
                <span>জনস্বার্থে: পল্লী সেবা কৃষি ও দুর্যোগ সচেতনতা সেল</span>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href="tel:1090"
                  className="px-3 py-1.5 rounded-xl bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold transition flex items-center gap-1.5"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>দুর্যোগ বার্তা ১০৯০ (টোল ফ্রি)</span>
                </a>
                <button
                  type="button"
                  onClick={() => setShowSafetyGuide(false)}
                  className="px-4 py-1.5 rounded-xl bg-gray-200 hover:bg-gray-300 text-[#2D3A3A] text-xs font-bold transition cursor-pointer"
                >
                  বন্ধ করুন
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
