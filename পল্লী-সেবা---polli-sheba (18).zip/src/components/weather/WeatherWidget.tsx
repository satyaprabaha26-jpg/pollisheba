import React, { useState, useEffect } from 'react';
import { 
  CloudRain, 
  Sun, 
  Wind, 
  Droplets, 
  AlertTriangle, 
  RefreshCw, 
  MapPin, 
  Navigation, 
  Calendar, 
  Compass, 
  Eye, 
  Sunset, 
  Sunrise, 
  ShieldAlert, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp,
  Sparkles,
  CloudLightning,
  CloudDrizzle,
  CloudFog,
  CloudSun,
  Cloud
} from 'lucide-react';
import { toBanglaNumber } from '../../utils/banglaNumbers';
import { fetchDistrictWeather, DistrictWeatherData, DayForecast } from '../../utils/weatherService';
import { detectCurrentLocationGPS, getSavedLocation, saveUserLocation } from '../../utils/locationService';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { BANGLADESH_LOCATIONS } from '../../data/bangladeshLocations';

interface WeatherWidgetProps {
  district: string;
  onDistrictChange?: (district: string) => void;
}

export const WeatherWidget: React.FC<WeatherWidgetProps> = ({ district, onDistrictChange }) => {
  const activeDistrict = district === 'সকল জেলা' ? 'ঢাকা' : district;
  const [weatherData, setWeatherData] = useState<DistrictWeatherData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isDetectingGPS, setIsDetectingGPS] = useState<boolean>(false);
  const [gpsMessage, setGpsMessage] = useState<string | null>(null);
  const [show7DayForecast, setShow7DayForecast] = useState<boolean>(false);
  const [isManualSelectorOpen, setIsManualSelectorOpen] = useState<boolean>(false);
  const [selectedUpazila, setSelectedUpazila] = useState<string>('');

  // Load weather when activeDistrict changes
  const loadWeather = async (targetDistrict: string) => {
    setLoading(true);
    try {
      const data = await fetchDistrictWeather(targetDistrict);
      setWeatherData(data);
    } catch (err) {
      console.error('Weather load error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadWeather(activeDistrict);
  }, [activeDistrict]);

  // Check saved upazila for district
  useEffect(() => {
    const saved = getSavedLocation();
    if (saved && saved.district === activeDistrict && saved.upazila) {
      setSelectedUpazila(saved.upazila);
    } else {
      const distData = BANGLADESH_LOCATIONS.find(d => d.district === activeDistrict);
      if (distData && distData.upazilas.length > 0) {
        setSelectedUpazila(distData.upazilas[0].name);
      } else {
        setSelectedUpazila('');
      }
    }
  }, [activeDistrict]);

  const handleRefresh = () => {
    loadWeather(activeDistrict);
  };

  const handleGPSDetect = async () => {
    setIsDetectingGPS(true);
    setGpsMessage(null);
    try {
      const res = await detectCurrentLocationGPS();
      if (res.success && res.district) {
        setGpsMessage(`লোকেশন শনাক্ত হয়েছে: ${res.district} জেলা!`);
        if (onDistrictChange) {
          onDistrictChange(res.district);
        }
        loadWeather(res.district);
      } else {
        setGpsMessage(res.errorMessage || 'লোকেশন পাওয়া যায়নি');
      }
    } catch (err) {
      setGpsMessage('লোকেশন শনাক্তকরণে সমস্যা হয়েছে');
    } finally {
      setIsDetectingGPS(false);
      setTimeout(() => setGpsMessage(null), 5000);
    }
  };

  const handleSelectDistrict = (newDist: string) => {
    if (onDistrictChange) {
      onDistrictChange(newDist);
    }
    const distData = BANGLADESH_LOCATIONS.find(d => d.district === newDist);
    const newUpazila = distData && distData.upazilas.length > 0 ? distData.upazilas[0].name : '';
    setSelectedUpazila(newUpazila);

    saveUserLocation({
      district: newDist,
      upazila: newUpazila,
      detectedAt: Date.now()
    });
    setIsManualSelectorOpen(false);
  };

  const handleUpazilaChange = (upazilaName: string) => {
    setSelectedUpazila(upazilaName);
    saveUserLocation({
      district: activeDistrict,
      upazila: upazilaName,
      detectedAt: Date.now()
    });
  };

  const renderWeatherIcon = (iconType: string, className = "w-6 h-6") => {
    switch (iconType) {
      case 'sun':
        return <Sun className={`${className} text-[#F9E5D4]`} />;
      case 'cloud-sun':
        return <CloudSun className={`${className} text-[#F9E5D4]`} />;
      case 'cloud':
        return <Cloud className={`${className} text-[#D1E5F0]`} />;
      case 'cloud-drizzle':
        return <CloudDrizzle className={`${className} text-[#D1E5F0]`} />;
      case 'cloud-rain':
        return <CloudRain className={`${className} text-[#A9CCE3]`} />;
      case 'cloud-lightning':
        return <CloudLightning className={`${className} text-[#FADBD8]`} />;
      case 'cloud-fog':
        return <CloudFog className={`${className} text-[#D5D8DC]`} />;
      default:
        return <Sun className={`${className} text-[#F9E5D4]`} />;
    }
  };

  const currentDistUpazilas = BANGLADESH_LOCATIONS.find(d => d.district === activeDistrict)?.upazilas || [];

  return (
    <div className="bg-[#2D5A27] rounded-3xl p-4 sm:p-6 text-white shadow-md relative overflow-hidden border border-[#3D7A35]">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-56 h-56 bg-white/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-44 h-44 bg-[#D4E4BC]/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header Bar: Location Info + GPS Detector + District Switcher + Refresh */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4 relative z-10 border-b border-white/10 pb-3.5">
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-12 h-12 sm:w-14 sm:h-14 bg-white/15 backdrop-blur-xs rounded-2xl flex items-center justify-center text-[#D4E4BC] shadow-inner shrink-0 mt-0.5 sm:mt-0">
            {weatherData ? renderWeatherIcon(weatherData.iconType, "w-7 h-7 sm:w-8 sm:h-8") : <Sun className="w-7 h-7" />}
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-bold text-base sm:text-xl font-['Noto_Sans_Bengali'] flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-[#E8924A] shrink-0" />
                <span>{activeDistrict} জেলা</span>
                {selectedUpazila && (
                  <span className="text-sm font-semibold text-[#D4E4BC]">
                    • {selectedUpazila} উপজেলা
                  </span>
                )}
              </span>
              
              {weatherData?.isLiveApi ? (
                <span className="text-[10px] sm:text-[11px] bg-[#3D7A35] text-[#D4E4BC] font-bold px-2.5 py-0.5 rounded-full border border-[#D4E4BC]/40 shadow-xs flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  স্যাটেলাইট লাইভ
                </span>
              ) : (
                <span className="text-[10px] sm:text-[11px] bg-white/15 text-[#D4E4BC] font-medium px-2 py-0.5 rounded-full">
                  আঞ্চলিক মডেল
                </span>
              )}
            </div>

            <p className="text-xs text-[#D4E4BC]/90 mt-0.5 flex items-center gap-2 flex-wrap">
              <span>{weatherData?.conditionText || 'আবহাওয়া তথ্য লোড হচ্ছে...'}</span>
              <span>•</span>
              <span>সর্বশেষ আপডেট: {weatherData?.lastUpdated || 'আজ'}</span>
            </p>
          </div>
        </div>

        {/* Action Buttons Row */}
        <div className="flex flex-wrap items-center gap-2">
          {/* GPS Auto-Detect Button */}
          <button
            onClick={handleGPSDetect}
            disabled={isDetectingGPS}
            className="text-xs flex items-center gap-1.5 bg-[#E8924A] hover:bg-[#D4823B] text-white font-bold px-3 py-1.5 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
            title="জিপিএস দিয়ে আপনার বর্তমান জেলা ও উপজেলা স্বয়ংক্রিয়ভাবে শনাক্ত করুন"
          >
            <Navigation className={`w-3.5 h-3.5 ${isDetectingGPS ? 'animate-spin' : ''}`} />
            <span>{isDetectingGPS ? 'খোঁজা হচ্ছে...' : 'আমার লোকেশন (GPS)'}</span>
          </button>

          {/* District / Upazila Manual Change Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsManualSelectorOpen(!isManualSelectorOpen)}
              className="text-xs flex items-center gap-1.5 bg-white/15 hover:bg-white/25 px-3 py-1.5 rounded-xl text-white font-medium transition cursor-pointer border border-white/15"
            >
              <span>জেলা পরিবর্তন</span>
              <ChevronDown className="w-3.5 h-3.5" />
            </button>

            {isManualSelectorOpen && (
              <div className="absolute right-0 top-full mt-2 w-64 sm:w-72 bg-[#FAF8F5] text-[#2D3A3A] rounded-2xl shadow-xl border border-[#D4C3A3] p-3 z-50 animate-in fade-in zoom-in-95">
                <div className="text-xs font-bold text-[#2D5A27] mb-2 flex items-center justify-between">
                  <span>জেলা নির্বাচন করুন:</span>
                  <button 
                    onClick={() => setIsManualSelectorOpen(false)}
                    className="text-gray-400 hover:text-black text-xs"
                  >
                    ✕ বন্ধ
                  </button>
                </div>
                <div className="max-h-48 overflow-y-auto space-y-1 pr-1 text-xs">
                  {BANGLADESH_DISTRICTS.map((d) => (
                    <button
                      key={d}
                      onClick={() => handleSelectDistrict(d)}
                      className={`w-full text-left px-2.5 py-1.5 rounded-xl transition font-medium flex items-center justify-between ${
                        activeDistrict === d 
                          ? 'bg-[#2D5A27] text-white font-bold' 
                          : 'hover:bg-[#E6E0D4] text-[#2D3A3A]'
                      }`}
                    >
                      <span>{d} জেলা</span>
                      {activeDistrict === d && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Refresh Button */}
          <button
            onClick={handleRefresh}
            disabled={loading}
            className="text-xs flex items-center gap-1.5 bg-white/15 hover:bg-white/25 px-3 py-1.5 rounded-xl text-white transition cursor-pointer disabled:opacity-50"
            title="আবহাওয়া তথ্য রিফ্রেশ করুন"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">রিফ্রেশ</span>
          </button>
        </div>
      </div>

      {/* GPS Confirmation / Error Notification */}
      {gpsMessage && (
        <div className="mb-3 bg-white/20 border border-white/30 rounded-2xl px-3.5 py-2 text-xs text-white font-semibold flex items-center gap-2 animate-in fade-in">
          <Sparkles className="w-4 h-4 text-[#F9E5D4]" />
          <span>{gpsMessage}</span>
        </div>
      )}

      {/* Upazila Quick Selection Row if District selected */}
      {currentDistUpazilas.length > 0 && (
        <div className="mb-3 flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
          <span className="text-[11px] font-bold text-[#D4E4BC] shrink-0 mr-1 flex items-center gap-1">
            <Compass className="w-3 h-3 text-[#E8924A]" />
            <span>উপজেলা:</span>
          </span>
          {currentDistUpazilas.map((u) => (
            <button
              key={u.name}
              onClick={() => handleUpazilaChange(u.name)}
              className={`px-2.5 py-1 rounded-xl text-xs whitespace-nowrap transition cursor-pointer ${
                selectedUpazila === u.name
                  ? 'bg-white text-[#2D5A27] font-bold shadow-xs'
                  : 'bg-white/15 hover:bg-white/25 text-[#FDFBF7]'
              }`}
            >
              {u.name}
            </button>
          ))}
        </div>
      )}

      {/* Severe Weather Alert Warning Banner */}
      {weatherData?.safetyAlert && (
        <div className={`mb-3.5 rounded-2xl p-3 flex items-start gap-2.5 text-xs font-semibold shadow-xs ${
          weatherData.safetyAlert.level === 'red'
            ? 'bg-rose-600 text-white border border-rose-400'
            : weatherData.safetyAlert.level === 'orange'
            ? 'bg-amber-600 text-white border border-amber-400'
            : 'bg-yellow-500 text-black border border-yellow-300'
        }`}>
          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 animate-bounce" />
          <div>
            <span className="font-bold underline">{weatherData.safetyAlert.title}:</span> {weatherData.safetyAlert.message}
          </div>
        </div>
      )}

      {/* Main Meteorological Stats Grid: 4 Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 py-1 my-1 relative z-10">
        {/* 1. Temperature & Feels Like */}
        <div className="bg-black/20 backdrop-blur-xs rounded-2xl p-3 sm:p-3.5 border border-white/15">
          <div className="flex items-center justify-between text-xs text-[#D4E4BC] mb-1">
            <div className="flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-[#F9E5D4]" />
              <span>তাপমাত্রা</span>
            </div>
            <span className="text-[10px] bg-white/15 px-1.5 py-0.5 rounded-md text-white">
              {weatherData?.conditionText || 'স্বাভাবিক'}
            </span>
          </div>
          <p className="text-2xl sm:text-3xl font-bold font-['Noto_Sans_Bengali'] text-white">
            {toBanglaNumber(weatherData?.currentTemp ?? 31)}° <span className="text-sm font-normal text-[#D4E4BC]">সে.</span>
          </p>
          <div className="flex items-center justify-between text-[11px] text-[#D4E4BC]/90 mt-1">
            <span>অনুভূত: {toBanglaNumber(weatherData?.feelsLike ?? 33)}°</span>
            <span>সর্বোচ্চ: {toBanglaNumber(weatherData?.maxTemp ?? 34)}°</span>
          </div>
        </div>

        {/* 2. Rain Probability & Precipitation */}
        <div className="bg-black/20 backdrop-blur-xs rounded-2xl p-3 sm:p-3.5 border border-white/15">
          <div className="flex items-center justify-between text-xs text-[#D4E4BC] mb-1">
            <div className="flex items-center gap-1.5">
              <CloudRain className="w-3.5 h-3.5 text-[#D1E5F0]" />
              <span>বৃষ্টির সম্ভাবনা</span>
            </div>
            {(weatherData?.rainChance ?? 0) >= 50 && (
              <span className="text-[10px] bg-sky-500/30 border border-sky-300/40 px-1.5 py-0.5 rounded-md text-white font-bold">
                বৃষ্টি সতর্কতা
              </span>
            )}
          </div>
          <p className="text-2xl sm:text-3xl font-bold font-['Noto_Sans_Bengali'] text-white">
            {toBanglaNumber(weatherData?.rainChance ?? 20)}%
          </p>
          <div className="text-[11px] text-[#D4E4BC]/90 mt-1 flex items-center justify-between">
            <span>{((weatherData?.rainChance ?? 0) > 60) ? 'ভারী বৃষ্টিপাত' : ((weatherData?.rainChance ?? 0) > 30) ? 'হালকা বৃষ্টি' : 'বৃষ্টির সম্ভাবনা কম'}</span>
            {weatherData?.precipitationMm ? <span>{toBanglaNumber(weatherData.precipitationMm)} মিমি</span> : null}
          </div>
        </div>

        {/* 3. Humidity & Air Quality */}
        <div className="bg-black/20 backdrop-blur-xs rounded-2xl p-3 sm:p-3.5 border border-white/15">
          <div className="flex items-center justify-between text-xs text-[#D4E4BC] mb-1">
            <div className="flex items-center gap-1.5">
              <Droplets className="w-3.5 h-3.5 text-[#D4E4BC]" />
              <span>বাতাসের আর্দ্রতা</span>
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-bold font-['Noto_Sans_Bengali'] text-white">
            {toBanglaNumber(weatherData?.humidity ?? 74)}%
          </p>
          <div className="text-[11px] text-[#D4E4BC]/90 mt-1 flex items-center justify-between">
            <span>বাতাস: {weatherData?.airQuality || 'স্বাভাবিক'}</span>
            <span>UV: {toBanglaNumber(weatherData?.uvIndex ?? 6)}</span>
          </div>
        </div>

        {/* 4. Wind Speed & Solar Info */}
        <div className="bg-black/20 backdrop-blur-xs rounded-2xl p-3 sm:p-3.5 border border-white/15">
          <div className="flex items-center justify-between text-xs text-[#D4E4BC] mb-1">
            <div className="flex items-center gap-1.5">
              <Wind className="w-3.5 h-3.5 text-[#D1E5F0]" />
              <span>বাতাসের গতি ও দিক</span>
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-bold font-['Noto_Sans_Bengali'] text-white">
            {toBanglaNumber(weatherData?.windSpeedKmH ?? 12)} <span className="text-xs font-normal text-[#D4E4BC]">কিমি/ঘণ্টা</span>
          </p>
          <div className="text-[11px] text-[#D4E4BC]/90 mt-1 flex items-center justify-between">
            <span className="truncate">{weatherData?.windDirectionText || 'দক্ষিণ দিক'}</span>
          </div>
        </div>
      </div>

      {/* Sun times mini strip */}
      <div className="mt-2.5 flex items-center justify-between text-[11px] text-[#D4E4BC] bg-black/15 rounded-xl px-3 py-1.5 border border-white/10">
        <span className="flex items-center gap-1.5">
          <Sunrise className="w-3.5 h-3.5 text-[#E8924A]" />
          <span>সূর্যোদয়: <strong>{weatherData?.sunriseTime || 'সকাল ৫:৩৮'}</strong></span>
        </span>
        <span>•</span>
        <span className="flex items-center gap-1.5">
          <Sunset className="w-3.5 h-3.5 text-[#F9E5D4]" />
          <span>সূর্যাস্ত: <strong>{weatherData?.sunsetTime || 'সন্ধ্যা ৬:১২'}</strong></span>
        </span>
        <span>•</span>
        <button
          onClick={() => setShow7DayForecast(!show7DayForecast)}
          className="text-[#F9E5D4] hover:text-white font-bold underline flex items-center gap-1 cursor-pointer"
        >
          <span>৭ দিনের পূর্বাভাস</span>
          {show7DayForecast ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>
      </div>

      {/* 7-Day Day-by-Day Forecast Expansion */}
      {show7DayForecast && weatherData?.weeklyForecast && (
        <div className="mt-3.5 bg-black/25 rounded-2xl p-3.5 border border-white/15 animate-in fade-in">
          <div className="flex items-center justify-between text-xs font-bold text-[#D4E4BC] mb-2.5">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#E8924A]" />
              <span>{activeDistrict} জেলার আগামী ৭ দিনের বিস্তারিত আবহাওয়া পূর্বাভাস:</span>
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
            {weatherData.weeklyForecast.map((day, idx) => (
              <div 
                key={idx}
                className={`bg-white/10 border rounded-xl p-2.5 text-center flex flex-col items-center justify-between ${
                  idx === 0 ? 'border-[#E8924A] bg-white/20' : 'border-white/10'
                }`}
              >
                <span className="text-xs font-bold text-white">{day.dayName}</span>
                <span className="text-[10px] text-[#D4E4BC]">{day.dateStr}</span>
                <div className="my-1.5">
                  {renderWeatherIcon(day.iconType, "w-6 h-6")}
                </div>
                <div className="text-xs font-bold text-white">
                  {toBanglaNumber(day.maxTemp)}° / {toBanglaNumber(day.minTemp)}°
                </div>
                <div className="text-[10px] text-[#D1E5F0] mt-1 flex items-center gap-0.5">
                  <CloudRain className="w-2.5 h-2.5" />
                  <span>{toBanglaNumber(day.rainProbability)}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Local Farmers Advisory Bulletin */}
      <div className="mt-3 bg-white/15 border border-white/20 rounded-2xl p-3.5 flex items-start gap-3 relative z-10 backdrop-blur-xs">
        <AlertTriangle className="w-4 h-4 text-[#F9E5D4] shrink-0 mt-0.5" />
        <div className="text-xs text-[#FDFBF7] leading-relaxed">
          <strong className="text-[#D4E4BC] font-bold">
            {activeDistrict} জেলার কৃষি ও ফসল সুরক্ষা পরামর্শ: 
          </strong>{' '}
          {weatherData?.agroAdvisory || `${activeDistrict} অঞ্চলের কৃষকদের জন্য অনুকূল আবহাওয়া। রবি ও খরিপ ফসলের জমিতে সেচ ও সার প্রয়োগের সঠিক সময় নির্ধারণে মাটির আর্দ্রতা পরীক্ষা করুন।`}
        </div>
      </div>
    </div>
  );
};
