import React, { useState } from 'react';
import { toBanglaNumber } from '../../utils/banglaNumbers';

export const LandCalculator: React.FC = () => {
  const [activeMode, setActiveMode] = useState<'converter' | 'shape'>('converter');

  // Converter State
  const [inputValue, setInputValue] = useState<string>('১০');
  const [fromUnit, setFromUnit] = useState<string>('decimal');

  // Shape State (Length & Width in Feet)
  const [lengthFeet, setLengthFeet] = useState<string>('১২০');
  const [widthFeet, setWidthFeet] = useState<string>('৮০');

  // Triangular shape
  const [sideA, setSideA] = useState<string>('১০০');
  const [sideB, setSideB] = useState<string>('৮০');
  const [sideC, setSideC] = useState<string>('৬০');
  const [shapeType, setShapeType] = useState<'rectangle' | 'triangle'>('rectangle');

  const getBaseSqFeet = (): number => {
    const val = parseFloat(inputValue) || 0;
    switch (fromUnit) {
      case 'decimal': return val * 435.6;
      case 'katha': return val * 720;
      case 'bigha': return val * 14400;
      case 'acre': return val * 43560;
      case 'sqft': return val;
      case 'sqyard': return val * 9;
      case 'kani': return val * 17424;
      default: return val * 435.6;
    }
  };

  const baseSqFt = getBaseSqFeet();

  const conversions = {
    decimal: (baseSqFt / 435.6).toFixed(3),
    katha: (baseSqFt / 720).toFixed(3),
    bigha: (baseSqFt / 14400).toFixed(3),
    acre: (baseSqFt / 43560).toFixed(4),
    sqft: baseSqFt.toFixed(2),
    sqyard: (baseSqFt / 9).toFixed(2),
    kani: (baseSqFt / 17424).toFixed(3)
  };

  // Shape area calculation
  let calculatedAreaSqFt = 0;
  if (shapeType === 'rectangle') {
    const l = parseFloat(lengthFeet) || 0;
    const w = parseFloat(widthFeet) || 0;
    calculatedAreaSqFt = l * w;
  } else {
    const a = parseFloat(sideA) || 0;
    const b = parseFloat(sideB) || 0;
    const c = parseFloat(sideC) || 0;
    const s = (a + b + c) / 2;
    if (s > a && s > b && s > c) {
      calculatedAreaSqFt = Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }
  }

  const shapeDecimal = (calculatedAreaSqFt / 435.6).toFixed(3);
  const shapeKatha = (calculatedAreaSqFt / 720).toFixed(3);
  const shapeBigha = (calculatedAreaSqFt / 14400).toFixed(3);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm">
        <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
          📐 আমিন ও ভূমি পরিমাপক
        </span>
        <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
          জমির সঠিক মাপ, রূপান্তর ও আয়তন ক্যালকুলেটর
        </h2>
        <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
          শতক, কাঠা, বিঘা, একর, কানি ও বর্গফুটের নির্ভুল হিসেব এবং নকশা অনুযায়ী জমি মাপার টুল
        </p>
      </div>

      {/* Tabs for Converter vs Shape Calculator */}
      <div className="flex gap-2 bg-white p-2 rounded-2xl border border-[#E6E0D4] max-w-md">
        <button
          onClick={() => setActiveMode('converter')}
          className={`flex-1 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
            activeMode === 'converter'
              ? 'bg-[#2D5A27] text-white shadow-xs'
              : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          🔄 একক রূপান্তর (Converter)
        </button>
        <button
          onClick={() => setActiveMode('shape')}
          className={`flex-1 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
            activeMode === 'shape'
              ? 'bg-[#2D5A27] text-white shadow-xs'
              : 'text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          📐 জমি মাপুন (ফুট দিয়ে)
        </button>
      </div>

      {activeMode === 'converter' ? (
        <div className="space-y-5">
          <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  পরিমাপের সংখ্যা লিখুন:
                </label>
                <input
                  type="number"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="যেমন: ১০"
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2.5 text-sm sm:text-base focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D5A27]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                  প্রদত্ত একক:
                </label>
                <select
                  value={fromUnit}
                  onChange={(e) => setFromUnit(e.target.value)}
                  className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2.5 text-sm sm:text-base focus:outline-none focus:border-[#2D5A27] font-semibold text-[#2D3A3A]"
                >
                  <option value="decimal">শতক / শতাংশ / ডেসিমাল</option>
                  <option value="katha">কাঠা (১ কাঠা = ১.৬৫ শতক)</option>
                  <option value="bigha">বিঘা (১ বিঘা = ৩৩ শতক / ২০ কাঠা)</option>
                  <option value="acre">একর (১ একর = ১০০ শতক / ৩ বিঘা ৮ ছটাক)</option>
                  <option value="sqft">বর্গফুট (Square Feet)</option>
                  <option value="sqyard">বর্গগজ (Square Yard)</option>
                  <option value="kani">কানি (১ কানি = ৪০ শতক)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Results Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5">
            <div className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 text-center shadow-xs transition">
              <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                শতক / শতাংশ
              </span>
              <p className="text-xl sm:text-2xl font-extrabold text-[#2D5A27] mt-2.5 font-['Noto_Sans_Bengali']">
                {toBanglaNumber(conversions.decimal)}
              </p>
              <span className="text-xs text-[#736B5E]">শতক</span>
            </div>

            <div className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 text-center shadow-xs transition">
              <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                কাঠা
              </span>
              <p className="text-xl sm:text-2xl font-extrabold text-[#2D5A27] mt-2.5 font-['Noto_Sans_Bengali']">
                {toBanglaNumber(conversions.katha)}
              </p>
              <span className="text-xs text-[#736B5E]">কাঠা</span>
            </div>

            <div className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 text-center shadow-xs transition">
              <span className="text-[11px] font-bold text-[#A65E2E] bg-[#F9E5D4] px-2.5 py-0.5 rounded-full border border-[#F9E5D4]">
                বিঘা
              </span>
              <p className="text-xl sm:text-2xl font-extrabold text-[#A65E2E] mt-2.5 font-['Noto_Sans_Bengali']">
                {toBanglaNumber(conversions.bigha)}
              </p>
              <span className="text-xs text-[#736B5E]">বিঘা</span>
            </div>

            <div className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 text-center shadow-xs transition">
              <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                একর
              </span>
              <p className="text-xl sm:text-2xl font-extrabold text-[#2D5A27] mt-2.5 font-['Noto_Sans_Bengali']">
                {toBanglaNumber(conversions.acre)}
              </p>
              <span className="text-xs text-[#736B5E]">একর</span>
            </div>

            <div className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 text-center shadow-xs transition">
              <span className="text-[11px] font-bold text-[#736B5E] bg-[#FDFBF7] px-2.5 py-0.5 rounded-full border border-[#E6E0D4]">
                বর্গফুট (Sq Ft)
              </span>
              <p className="text-xl sm:text-2xl font-extrabold text-[#2D3A3A] mt-2.5 font-['Noto_Sans_Bengali']">
                {toBanglaNumber(conversions.sqft)}
              </p>
              <span className="text-xs text-[#736B5E]">বর্গফুট</span>
            </div>

            <div className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 text-center shadow-xs transition">
              <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                কানি (চট্টগ্রাম/কুমিল্লা)
              </span>
              <p className="text-xl sm:text-2xl font-extrabold text-[#2D5A27] mt-2.5 font-['Noto_Sans_Bengali']">
                {toBanglaNumber(conversions.kani)}
              </p>
              <span className="text-xs text-[#736B5E]">কানি</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-5">
          {/* Shape Calculator Form */}
          <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShapeType('rectangle')}
                className={`px-4 py-2 rounded-2xl text-xs font-bold transition cursor-pointer ${
                  shapeType === 'rectangle' ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FDFBF7] text-[#2D3A3A] border border-[#E6E0D4]'
                }`}
              >
                আয়তাকার বা চারকোনা জমি
              </button>
              <button
                type="button"
                onClick={() => setShapeType('triangle')}
                className={`px-4 py-2 rounded-2xl text-xs font-bold transition cursor-pointer ${
                  shapeType === 'triangle' ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FDFBF7] text-[#2D3A3A] border border-[#E6E0D4]'
                }`}
              >
                ত্রিভুজাকার বা কোণাকুণি জমি
              </button>
            </div>

            {shapeType === 'rectangle' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    জমির গড় দৈর্ঘ্য (ফুট):
                  </label>
                  <input
                    type="number"
                    value={lengthFeet}
                    onChange={(e) => setLengthFeet(e.target.value)}
                    placeholder="যেমন: ১২০"
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D3A3A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    জমির গড় প্রস্থ (ফুট):
                  </label>
                  <input
                    type="number"
                    value={widthFeet}
                    onChange={(e) => setWidthFeet(e.target.value)}
                    placeholder="যেমন: ৮০"
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D3A3A]"
                  />
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    ১ম বাহুর দৈর্ঘ্য (ফুট):
                  </label>
                  <input
                    type="number"
                    value={sideA}
                    onChange={(e) => setSideA(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D3A3A]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    ২য় বাহুর দৈর্ঘ্য (ফুট):
                  </label>
                  <input
                    type="number"
                    value={sideB}
                    onChange={(e) => setSideB(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D3A3A]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    ৩য় বাহুর দৈর্ঘ্য (ফুট):
                  </label>
                  <input
                    type="number"
                    value={sideC}
                    onChange={(e) => setSideC(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D3A3A]"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Computed Area */}
          <div className="bg-[#2D5A27] rounded-3xl p-6 text-white shadow-sm">
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-center">
              <div className="bg-[#23491E] rounded-2xl p-4 border border-[#3D7A35]">
                <span className="text-xs text-[#D4E4BC] block">মোট বর্গফুট (Sq Ft)</span>
                <p className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali'] mt-1">
                  {toBanglaNumber(calculatedAreaSqFt.toFixed(1))}
                </p>
              </div>

              <div className="bg-[#E8924A]/30 rounded-2xl p-4 border border-[#E8924A]">
                <span className="text-xs text-[#F9E5D4] block">শতক / শতাংশ</span>
                <p className="text-2xl sm:text-3xl font-extrabold text-white font-['Noto_Sans_Bengali'] mt-1">
                  {toBanglaNumber(shapeDecimal)}
                </p>
              </div>

              <div className="bg-[#23491E] rounded-2xl p-4 border border-[#3D7A35]">
                <span className="text-xs text-[#D4E4BC] block">কাঠা</span>
                <p className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali'] mt-1">
                  {toBanglaNumber(shapeKatha)}
                </p>
              </div>

              <div className="bg-[#23491E] rounded-2xl p-4 border border-[#3D7A35]">
                <span className="text-xs text-[#D4E4BC] block">বিঘা</span>
                <p className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali'] mt-1">
                  {toBanglaNumber(shapeBigha)}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Traditional Formula Reference */}
      <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-3 text-xs text-[#2D3A3A]">
        <h4 className="font-bold text-[#2D3A3A] text-xs sm:text-sm font-['Noto_Sans_Bengali']">
          💡 গ্রামবাংলার ঐতিহ্যবাহী ভূমি পরিমাপ সূত্র:
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1 text-[#5A6B6B]">
          <div className="bg-[#FDFBF7] p-2.5 rounded-2xl border border-[#E6E0D4]">• ১ শতক = ৪৩৫.৬ বর্গফুট = ১ ডেসিমাল</div>
          <div className="bg-[#FDFBF7] p-2.5 rounded-2xl border border-[#E6E0D4]">• ১ কাঠা = ১.৬৫ শতক = ৭২০ বর্গফুট</div>
          <div className="bg-[#FDFBF7] p-2.5 rounded-2xl border border-[#E6E0D4]">• ১ বিঘা = ৩৩ শতক = ২০ কাঠা</div>
          <div className="bg-[#FDFBF7] p-2.5 rounded-2xl border border-[#E6E0D4]">• ১ একর = ১০০ শতক = ৩ বিঘা ৮ ছটাক</div>
          <div className="bg-[#FDFBF7] p-2.5 rounded-2xl border border-[#E6E0D4]">• ১ কানি = ৪০ শতক (চট্টগ্রাম ও কুমিল্লা)</div>
          <div className="bg-[#FDFBF7] p-2.5 rounded-2xl border border-[#E6E0D4]">• ১ গণ্ডা = ৪ কড়া = ৮৭১.২ বর্গফুট</div>
        </div>
      </div>
    </div>
  );
};
