import React, { useState } from 'react';
import { toBanglaNumber, formatTaka } from '../../utils/banglaNumbers';

export const LoanCalculator: React.FC = () => {
  const [loanAmount, setLoanAmount] = useState<string>('৫০,০০০');
  const [interestRate, setInterestRate] = useState<string>('৯');
  const [durationMonths, setDurationMonths] = useState<string>('১২');
  const [installmentType, setInstallmentType] = useState<'monthly' | 'weekly'>('monthly');

  const principal = parseFloat(loanAmount.replace(/[,০-৯]/g, (m) => {
    const map: Record<string, string> = { '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4', '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9' };
    return map[m] || m;
  })) || 50000;

  const rate = parseFloat(interestRate) || 9;
  const months = parseFloat(durationMonths) || 12;

  const totalInterest = (principal * (rate / 100) * (months / 12));
  const totalPayable = principal + totalInterest;

  const totalInstallments = installmentType === 'monthly' ? months : Math.round(months * 4.33);
  const perInstallment = Math.round(totalPayable / totalInstallments);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm">
        <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
          💳 কৃষি ঋণ ও ক্ষুদ্রঋণ কিস্তি ক্যালকুলেটর
        </span>
        <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
          কৃষি ব্যাংক ও সমিতি ঋণের কিস্তির হিসাব
        </h2>
        <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
          ঋণের আসল টাকা, সুদের হার ও মেয়াদ দিয়ে সাপ্তাহিক বা মাসিক কিস্তির পরিমাণ জানুন
        </p>
      </div>

      {/* Input Card */}
      <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
              ঋণের পরিমাণ (আসল টাকা):
            </label>
            <input
              type="text"
              value={loanAmount}
              onChange={(e) => setLoanAmount(e.target.value)}
              placeholder="৫০,০০০"
              className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D5A27]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
              বার্ষিক সুদের হার (%):
            </label>
            <input
              type="number"
              value={interestRate}
              onChange={(e) => setInterestRate(e.target.value)}
              placeholder="যেমন: ৯ (কৃষি ঋণ)"
              className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D3A3A]"
            />
            <span className="text-[10px] text-[#736B5E] mt-0.5 block">সরকারি কৃষি ঋণ সাধারণত ৪-৯%</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
              ঋণের মেয়াদ (মাস):
            </label>
            <input
              type="number"
              value={durationMonths}
              onChange={(e) => setDurationMonths(e.target.value)}
              placeholder="যেমন: ১২"
              className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D3A3A]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
              কিস্তি প্রদানের ধরন:
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setInstallmentType('monthly')}
                className={`py-2 rounded-2xl text-xs font-bold transition cursor-pointer ${
                  installmentType === 'monthly' ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FDFBF7] text-[#2D3A3A] border border-[#E6E0D4]'
                }`}
              >
                মাসিক কিস্তি
              </button>
              <button
                type="button"
                onClick={() => setInstallmentType('weekly')}
                className={`py-2 rounded-2xl text-xs font-bold transition cursor-pointer ${
                  installmentType === 'weekly' ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FDFBF7] text-[#2D3A3A] border border-[#E6E0D4]'
                }`}
              >
                সাপ্তাহিক কিস্তি
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#2D5A27] rounded-3xl p-6 text-white shadow-sm">
          <span className="text-xs uppercase tracking-wider text-[#D4E4BC] block">
            প্রতি {installmentType === 'monthly' ? 'মাসে' : 'সপ্তাহে'} কিস্তির পরিমাণ
          </span>
          <p className="text-2xl sm:text-3xl font-extrabold text-[#E8924A] font-['Noto_Sans_Bengali'] mt-1">
            {formatTaka(perInstallment)}
          </p>
          <span className="text-xs text-[#D4E4BC] mt-2 block">
            সর্বমোট কিস্তির সংখ্যা: {toBanglaNumber(totalInstallments)} টি
          </span>
        </div>

        <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs">
          <span className="text-xs text-[#736B5E] block">মোট সুদের পরিমাণ</span>
          <p className="text-xl sm:text-2xl font-bold text-[#A65E2E] font-['Noto_Sans_Bengali'] mt-1">
            {formatTaka(Math.round(totalInterest))}
          </p>
          <span className="text-xs text-[#736B5E] mt-2 block">
            আসল ঋণের উপর {toBanglaNumber(rate)}% হারে
          </span>
        </div>

        <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs">
          <span className="text-xs text-[#736B5E] block">সর্বমোট পরিশোধযোগ্য টাকা</span>
          <p className="text-xl sm:text-2xl font-bold text-[#2D3A3A] font-['Noto_Sans_Bengali'] mt-1">
            {formatTaka(Math.round(totalPayable))}
          </p>
          <span className="text-xs text-[#736B5E] mt-2 block">
            আসল {formatTaka(principal)} + সুদ {formatTaka(Math.round(totalInterest))}
          </span>
        </div>
      </div>
    </div>
  );
};
