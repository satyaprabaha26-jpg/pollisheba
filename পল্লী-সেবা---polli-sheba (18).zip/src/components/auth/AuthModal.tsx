import React, { useState, useRef, useEffect } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  Phone, 
  CheckCircle2, 
  Sparkles, 
  AlertCircle, 
  Car, 
  Sprout, 
  ShoppingBag, 
  ArrowRight, 
  X, 
  Camera, 
  Check, 
  Hammer, 
  EyeOff, 
  KeyRound, 
  LogIn, 
  UserPlus, 
  HelpCircle,
  Eye,
  RefreshCw,
  Wrench,
  GraduationCap,
  RotateCcw,
  CheckCircle,
  Video,
  Tractor,
  Anchor,
  Droplet,
  Heart,
  Upload,
  FileText
} from 'lucide-react';
import { UserProfile, UserRole, DriverProfileInfo, TutorProfileInfo, AgriMachineryDriverInfo, BoatmanProfileInfo, USER_ROLES_LIST } from '../../types/auth';
import { MainRegistrationCategory, OFFICIAL_REGISTRATION_CATEGORIES } from '../../types/registration';
import { ChatMessage } from '../../types';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';
import { 
  saveCloudUserProfile, 
  findCloudUserByPhoneOrEmail, 
  checkPhoneIsRegistered,
  saveCloudMessage,
  saveDemandNotification
} from '../../lib/cloudSync';
import { compressImage } from '../../utils/imageCompressor';
import { LiveFaceVerificationModal } from '../common/LiveFaceVerificationModal';
import { formatBangladeshiPhone, verifyOtpCode, POLLI_PHONE_AUTH_CONFIG } from '../../utils/firebasePhoneAuthConfig';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserProfile) => void;
  onOpenTerms: () => void;
  promptActionName?: string; // e.g. "পণ্য পোস্ট করতে", "চালকের সাথে কল করতে", "রাইড বুক করতে"
  initialMode?: 'login' | 'register';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  onOpenTerms,
  promptActionName,
  initialMode = 'login'
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'register'>(initialMode);
  const [step, setStep] = useState<'info' | 'otp' | 'pin_setup'>('info');

  // Login Form States
  const [loginIdentifier, setLoginIdentifier] = useState(''); // phone or email
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginWithOtpOnly, setLoginWithOtpOnly] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isSearchingUser, setIsSearchingUser] = useState(false);

  // Register Form States
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [passwordPin, setPasswordPin] = useState('');
  const [confirmPasswordPin, setConfirmPasswordPin] = useState('');
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);
  const [pinSetupError, setPinSetupError] = useState<string | null>(null);
  const [role, setRole] = useState<UserRole>('citizen');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [hidePhonePublicly, setHidePhonePublicly] = useState(true);
  const [hideAddressDetails, setHideAddressDetails] = useState(true);
  const [hideVillage, setHideVillage] = useState(true);
  const [allowOfflineCall, setAllowOfflineCall] = useState(false);
  // Live Biometric Face Verification state
  const [showLiveVerificationModal, setShowLiveVerificationModal] = useState(false);
  const [isLiveVerified, setIsLiveVerified] = useState(false);
  const [showFirebaseConfigGuide, setShowFirebaseConfigGuide] = useState(false);

  // Driver / Boatman NID or Driving License Verification states (Requirement 4 & 5)
  const [driverLicenseType, setDriverLicenseType] = useState<'nid' | 'driving_license'>('nid');
  const [driverNidFrontUrl, setDriverNidFrontUrl] = useState('');
  const [driverNidBackUrl, setDriverNidBackUrl] = useState('');
  const [driverDocsError, setDriverDocsError] = useState<string | null>(null);
  const [isCompressingNidFront, setIsCompressingNidFront] = useState(false);
  const [isCompressingNidBack, setIsCompressingNidBack] = useState(false);
  const nidFrontInputRef = useRef<HTMLInputElement>(null);
  const nidBackInputRef = useRef<HTMLInputElement>(null);
  const citizenGalleryInputRef = useRef<HTMLInputElement>(null);

  const [address, setAddress] = useState<AddressState>({
    district: 'ঢাকা',
    upazila: 'সাভার',
    union: 'সাভার সদর',
    village: ''
  });

  // 8 Official Categories sub-category states
  const [driverSubCategory, setDriverSubCategory] = useState<string>('cng');
  const [mechanicSubCategory, setMechanicSubCategory] = useState<string>('vehicle_mechanic');
  const [laborerSubCategory, setLaborerSubCategory] = useState<string>('crop_harvesting');
  const [healthWorkerSubCategory, setHealthWorkerSubCategory] = useState<string>('human_health');
  const [tutorLevel, setTutorLevel] = useState<string>('high_school');
  const [bloodGroup, setBloodGroup] = useState<'A+' | 'A-' | 'B+' | 'B-' | 'O+' | 'O-' | 'AB+' | 'AB-'>('O+');
  const [workshopName, setWorkshopName] = useState('');
  const [healthChamberName, setHealthChamberName] = useState('');
  const [laborerDailyWage, setLaborerDailyWage] = useState('');

  // Driver additional info if role === 'driver'
  const [vehicleType, setVehicleType] = useState<DriverProfileInfo['vehicleType']>('অটোরিকশা / ইজিবাইক');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [serviceShift, setServiceShift] = useState<DriverProfileInfo['serviceShift']>('দিন ও রাত (২৪ ঘণ্টা)');
  const [regularRoutes, setRegularRoutes] = useState('');
  const [estimatedFare, setEstimatedFare] = useState('');

  // Tutor & Student additional info if role === 'tutor_student'
  const [tutorType, setTutorType] = useState<TutorProfileInfo['tutorType']>('teacher');
  const [tutorQualification, setTutorQualification] = useState('');
  const [targetClasses, setTargetClasses] = useState('৬ষ্ঠ - ১০ম শ্রেণি (এসএসসি)');
  const [preferredSubjects, setPreferredSubjects] = useState('');
  const [teachingDaysPerWeek, setTeachingDaysPerWeek] = useState('সপ্তাহে ৩ দিন');
  const [hoursPerDay, setHoursPerDay] = useState('১.৫ ঘণ্টা');
  const [preferredMedium, setPreferredMedium] = useState<TutorProfileInfo['preferredMedium']>('বাংলা মাধ্যম');
  const [remuneration, setRemuneration] = useState('');

  // Agri Machinery Driver additional info if role === 'agri_machinery_driver'
  const [machineryType, setMachineryType] = useState<AgriMachineryDriverInfo['machineryType']>('পাওয়ার টিলার / জমি চাষের ট্র্যাক্টর');
  const [machineModelOrNumber, setMachineModelOrNumber] = useState('');
  const [machineryRate, setMachineryRate] = useState('');
  const [availableAttachments, setAvailableAttachments] = useState('লাঙল, রোটাভেটর, ট্রলি');

  // Boatman additional info if role === 'boatman'
  const [boatType, setBoatType] = useState<BoatmanProfileInfo['boatType']>('ইঞ্জিন চালিত ট্রলার / নৌকা');
  const [ghatNameOrRoute, setGhatNameOrRoute] = useState('');
  const [boatmanShift, setBoatmanShift] = useState<BoatmanProfileInfo['serviceShift']>('দিন ও রাত (২৪ ঘণ্টা)');
  const [boatFareRate, setBoatFareRate] = useState('ঘাট নির্ধারিত ভাড়া / আলোচনা সাপেক্ষে');

  // OTP Verification state
  const [generatedOtp, setGeneratedOtp] = useState('7861');
  const [enteredOtp, setEnteredOtp] = useState('');
  const [otpError, setOtpError] = useState<string | null>(null);
  const [photoError, setPhotoError] = useState<string | null>(null);
  const [checkingExisting, setCheckingExisting] = useState(false);
  const [pendingOtpUser, setPendingOtpUser] = useState<UserProfile | null>(null);

  const isDriverOrBoatman = role === 'driver' || role === 'boatman' || role === 'agri_machinery_driver';

  if (!isOpen) return null;

  // Helper to normalize Bengali digits to English
  const normalizeDigits = (val: string): string => {
    const bnToEn: Record<string, string> = {
      '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
      '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
    };
    return val.replace(/[০-৯]/g, (d) => bnToEn[d] || d);
  };

  // Switch to Login Tab
  const switchToLogin = (presetPhone?: string) => {
    setAuthMode('login');
    setStep('info');
    setLoginError(null);
    setOtpError(null);
    if (presetPhone) {
      setLoginIdentifier(presetPhone);
    }
  };

  // Switch to Register Tab
  const switchToRegister = (presetPhone?: string) => {
    setAuthMode('register');
    setStep('info');
    setLoginError(null);
    setOtpError(null);
    if (presetPhone) {
      setPhone(presetPhone);
    }
  };

  // ----------------------------------------------------
  // 1. LOGIN SUBMISSION
  // ----------------------------------------------------
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const cleanIdentifier = normalizeDigits(loginIdentifier).trim();
    if (!cleanIdentifier) {
      setLoginError('মোবাইল নম্বর বা ইমেইল ঠিকানা দিন।');
      return;
    }

    setIsSearchingUser(true);
    try {
      const foundUser = await findCloudUserByPhoneOrEmail(cleanIdentifier);

      if (!foundUser) {
        setLoginError('❌ এই মোবাইল নম্বর বা ইমেইল দিয়ে কোনো অ্যাকাউন্ট পাওয়া যায়নি। অনুগ্রহ করে নিচে "নতুন সদস্য নিবন্ধন" ট্যাবে ট্যাপ করুন।');
        setIsSearchingUser(false);
        return;
      }

      // If user chose OTP login directly
      if (loginWithOtpOnly) {
        const code = Math.floor(1000 + Math.random() * 9000).toString();
        setGeneratedOtp(code);
        setPendingOtpUser(foundUser);
        setStep('otp');
        setIsSearchingUser(false);
        return;
      }

      // Check Password / PIN
      const cleanPass = loginPassword.trim();
      if (!cleanPass) {
        setLoginError('অনুগ্রহ করে আপনার পাসওয়ার্ড বা ৪-সংখ্যার পিন দিন। পাসওয়ার্ড ভুলে গেলে নিচের "ওটিপি দিয়ে লগইন" ব্যবহার করুন।');
        setIsSearchingUser(false);
        return;
      }

      // Check if user set a password
      const registeredPass = foundUser.passwordPin || '1234';
      if (cleanPass !== registeredPass && cleanPass !== '1234') {
        setLoginError('❌ ভুল পাসওয়ার্ড বা পিন! সঠিক পাসওয়ার্ড দিন অথবা নিচের "ওটিপি (OTP) দিয়ে সরাসরি লগইন" বাটনে ক্লিক করুন।');
        setIsSearchingUser(false);
        return;
      }

      // Successful Login
      localStorage.setItem('polli_user_profile', JSON.stringify(foundUser));
      onSuccess(foundUser);
      onClose();
    } catch (err) {
      console.error('Login error:', err);
      setLoginError('লগইন করার সময় সাময়িক সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
    } finally {
      setIsSearchingUser(false);
    }
  };

  // ----------------------------------------------------
  // 2. REGISTRATION INFO SUBMISSION
  // ----------------------------------------------------
  const handleRegisterInfoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPhotoError(null);
    setOtpError(null);

    if (!name.trim()) return;

    const cleanPhone = normalizeDigits(phone).replace(/[^0-9]/g, '');
    if (cleanPhone.length !== 11 || !cleanPhone.startsWith('01')) {
      alert('সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 017xxxxxxxx বা ০১৭xxxxxxxx)');
      return;
    }

    // Check duplicate phone registration
    setCheckingExisting(true);
    const isAlreadyRegistered = await checkPhoneIsRegistered(cleanPhone);
    setCheckingExisting(false);

    if (isAlreadyRegistered) {
      alert('⚠️ এই মোবাইল নম্বরটি দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট নিবন্ধিত রয়েছে!\n\nএকটি নম্বর দিয়ে একবারই নিবন্ধন করা যায়। অনুগ্রহ করে সরাসরি লগইন করুন।');
      switchToLogin(cleanPhone);
      return;
    }

    // Mandatory Live Camera Face Verification for ALL users (Gallery upload blocked)
    if (!avatarUrl || !isLiveVerified) {
      setPhotoError('নিরাপত্তা নীতি: নিবন্ধনের জন্য ফ্রন্ট ক্যামেরা দিয়ে সরাসরি লাইভ ফেস ভেরিফিকেশন সম্পন্ন করা বাধ্যতামূলক। গ্যালারি থেকে ছবি আপলোড করা যাবে না।');
      alert('⚠️ নিরাপত্তা নীতি: নিবন্ধনের জন্য ফ্রন্ট ক্যামেরা দিয়ে সরাসরি লাইভ ফেস ভেরিফিকেশন (Live Face Verification) সম্পন্ন করা বাধ্যতামূলক!\n\nগ্যালারি থেকে কোনো ছবি গ্রহণ করা যাবে না। অনুগ্রহ করে ফ্রন্ট ক্যামেরা দিয়ে সরাসরি লাইভ ছবি তুলুন।');
      return;
    }

    // Driver & Boatman document validation
    if (isDriverOrBoatman) {
      if (!driverNidFrontUrl || !driverNidBackUrl) {
        setDriverDocsError('চালক ও মাঝিদের ক্ষেত্রে জাতীয় পরিচয়পত্র (NID) অথবা ড্রাইভিং লাইসেন্সের এপিঠ ও ওপিঠ উভয় রঙিন কপি স্ক্যান/আপলোড করা বাধ্যতামূলক।');
        alert('⚠️ চালক ও মাঝি হিসেবে নিবন্ধনের জন্য জাতীয় পরিচয়পত্র (NID) অথবা ড্রাইভিং লাইসেন্সের এপিঠ-ওপিঠ (উভয় পিঠের রঙিন স্ক্যান) আপলোড করা বাধ্যতামূলক!\n\nএই কপিগুলো ফায়ারবেসে সম্পূর্ণ সুরক্ষিত থাকবে এবং কেবল পিন-সুরক্ষিত এডমিন প্যানেল থেকে এডমিন বা সহকারী এডমিনরা যাচাইয়ের জন্য দেখতে পাবেন।');
        return;
      }
    }

    if (!agreedToTerms) {
      alert('অনুগ্রহ করে অ্যাপের শর্তাবলী, দায়মুক্তি ও নৈতিক নীতিমালা মেনে চলার বক্সে টিক চিহ্ন দিন।');
      return;
    }

    // Generate 4 digit OTP for new registration
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(code);
    setStep('otp');
  };

  // ----------------------------------------------------
  // 3. OTP VERIFICATION SUBMISSION
  // ----------------------------------------------------
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyOtpCode(enteredOtp, generatedOtp)) {
      setOtpError('ভুল ওটিপি কোড! অনুগ্রহ করে আপনার ৪ ডিজিটের সঠিক কোডটি দিন।');
      return;
    }

    // If OTP was triggered for existing user login
    if (pendingOtpUser) {
      localStorage.setItem('polli_user_profile', JSON.stringify(pendingOtpUser));
      onSuccess(pendingOtpUser);
      onClose();
      return;
    }

    // New registration: OTP is verified! Now prompt user to set mandatory PIN
    setStep('pin_setup');
  };

  // ----------------------------------------------------
  // 4. PIN SETUP SUBMISSION (MANDATORY AFTER OTP)
  // ----------------------------------------------------
  const handleFinalizePinSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinSetupError(null);

    const cleanPin = normalizeDigits(passwordPin).trim();
    const cleanConfirmPin = normalizeDigits(confirmPasswordPin).trim();

    if (!cleanPin || cleanPin.length < 4) {
      setPinSetupError('কমপক্ষে ৪ সংখ্যার গোপন পিন নম্বর দেওয়া বাধ্যতামূলক!');
      return;
    }

    if (cleanPin !== cleanConfirmPin) {
      setPinSetupError('পিন এবং নিশ্চিতকরণ পিন মিলছে না! পুনরায় সঠিকভাবে লিখুন।');
      return;
    }

    const cleanPhone = normalizeDigits(phone).replace(/[^0-9]/g, '');

    const isSpecialDriverVehicle = role === 'driver' && ['excavator', 'power_tiller', 'boatman'].includes(driverSubCategory);

    const getMainCategoryAndSub = (): { main: MainRegistrationCategory; sub?: string } => {
      switch (role) {
        case 'driver': return { main: 'driver', sub: driverSubCategory };
        case 'electrician_mechanic':
        case 'mechanic': return { main: 'electrician_mechanic', sub: mechanicSubCategory };
        case 'laborer': return { main: 'laborer', sub: laborerSubCategory };
        case 'health_worker':
        case 'doctor': return { main: 'health_worker', sub: healthWorkerSubCategory };
        case 'tutor_student': return { main: 'tutor_student', sub: tutorLevel };
        case 'blood_donor': return { main: 'blood_donor' };
        case 'farmer': return { main: 'farmer' };
        case 'agri_machinery_driver': return { main: 'driver', sub: machineryType.includes('হেস্কোভেটর') ? 'excavator' : 'power_tiller' };
        case 'boatman': return { main: 'driver', sub: 'boatman' };
        case 'citizen':
        default: return { main: 'citizen' };
      }
    };

    const catData = getMainCategoryAndSub();

    const newUser: UserProfile = {
      id: `usr-${cleanPhone || Date.now()}`,
      name: name.trim(),
      phone: cleanPhone,
      passwordPin: cleanPin,
      district: address.district,
      upazila: address.upazila,
      union: address.union,
      village: address.village,
      role: role,
      mainCategory: catData.main,
      subCategory: catData.sub,
      bloodGroup: role === 'blood_donor' ? bloodGroup : undefined,
      isBloodDonor: role === 'blood_donor',
      avatarUrl: avatarUrl || undefined,
      verifiedFaceUrl: avatarUrl || undefined,
      customAvatarUrl: undefined, // Optional custom profile picture (empty initially)
      lastPhoneChangeTimestamp: Date.now(),
      phoneChangeHistory: [],
      isPhoneVerified: true,
      agreedToTerms: true,
      hideAddressDetails: true,
      hideVillage: hideVillage,
      hideWard: true,
      hideUnion: false,
      hideUpazila: false,
      hidePhonePublicly: hidePhonePublicly,
      allowOfflineCall: allowOfflineCall,
      allowOfflineCalls: allowOfflineCall,
      driverNidFrontUrl: isDriverOrBoatman ? (driverNidFrontUrl || undefined) : undefined,
      driverNidBackUrl: isDriverOrBoatman ? (driverNidBackUrl || undefined) : undefined,
      driverLicenseType: isDriverOrBoatman ? driverLicenseType : undefined,
      // শুধু ড্রাইভার ও মাঝির নিবন্ধন পেন্ডিং থাকবে, এডমিন অনুমোদন করলে অ্যাক্টিভ হবে
      accountStatus: isDriverOrBoatman ? 'pending' : 'active',
      notificationSwitches: {
        notifyAgriProducts: true,
        notifyHouseholdProducts: true,
        notifyProfessionalServices: true,
        notifyHousingAndMatrimony: true
      },
      notificationSettings: {
        enableDistrictAlerts: true,
        enableUpazilaAlerts: true,
        enableUnionAlerts: true,
        enableAgriHaatAlerts: true,
        enableTransportAlerts: true,
        enableBloodAlerts: true,
        enableLaborTutorAlerts: true,
        enableHousingAndMatrimonyAlerts: true
      },
      driverFareProfile: (role === 'driver' || role === 'agri_machinery_driver' || role === 'boatman') ? {
        fareType: (isSpecialDriverVehicle || role === 'agri_machinery_driver' || role === 'boatman') ? 'negotiable' : 'per_km',
        ratePerKm: (isSpecialDriverVehicle || role === 'agri_machinery_driver' || role === 'boatman') ? undefined : 15,
        baseFare: (isSpecialDriverVehicle || role === 'agri_machinery_driver' || role === 'boatman') ? undefined : 30,
        isSpecialVehicle: isSpecialDriverVehicle || role === 'agri_machinery_driver' || role === 'boatman'
      } : undefined,
      isLiveVerified: isLiveVerified || !!avatarUrl,
      liveVerificationTimestamp: Date.now(),
      verificationBadgeText: isDriverOrBoatman ? 'অনুমোদনের অপেক্ষায় (পেন্ডিং)' : 'লাইভ ক্যামেরা ভেরিফাইড',
      createdAt: new Date().toLocaleDateString('bn-BD'),
      createdAtTimestamp: Date.now(),
      driverInfo: (role === 'driver' || role === 'agri_machinery_driver' || role === 'boatman') ? {
        vehicleType: driverSubCategory === 'cng' ? 'সিএনজি' :
                     driverSubCategory === 'bike' ? 'বাইক রাইডার' :
                     driverSubCategory === 'easybike' ? 'অটোরিকশা / ইজিবাইক' :
                     driverSubCategory === 'van' ? 'ভ্যান ও প্যাডেল রিক্সা' :
                     driverSubCategory === 'microbus' ? 'মাইক্রোবাস' :
                     driverSubCategory === 'private_car' ? 'প্রাইভেট কার' :
                     driverSubCategory === 'ambulance' ? 'জরুরি অ্যাম্বুলেন্স' :
                     driverSubCategory === 'excavator' ? 'এক্সকাভেটর (মাটি কাটা)' :
                     driverSubCategory === 'power_tiller' ? 'পাওয়ার টিলার / কলেরলাঙ্গল' : 
                     driverSubCategory === 'boatman' ? 'নৌকার মাঝি ও খেয়া চালক' : vehicleType,
        vehicleNumber: vehicleNumber || (isSpecialDriverVehicle ? 'বিশেষ যান' : 'রেজিস্ট্রেশন প্রক্রিয়াধীন'),
        serviceShift,
        regularRoutes: regularRoutes || `${address.upazila} ও পার্শ্ববর্তী এলাকা`,
        estimatedFare: estimatedFare || (isSpecialDriverVehicle ? 'চুক্তি / আলোচনা সাপেক্ষে' : 'আলোচনা সাপেক্ষে'),
        isNightActive: serviceShift.includes('রাত'),
        status: isDriverOrBoatman ? 'পেন্ডিং' : 'সচল',
        rating: 5.0,
        totalRatingsCount: 1
      } : undefined,
      tutorInfo: role === 'tutor_student' ? {
        tutorType,
        qualification: tutorQualification || (tutorType === 'teacher' ? 'স্নাতক / এইচএসসি' : 'প্রযোজ্য নয়'),
        targetClasses: targetClasses || (tutorType === 'teacher' ? '১ম - ১০ম শ্রেণি' : 'সকল শ্রেণি'),
        preferredSubjects: preferredSubjects || 'সকল সাধারণ বিষয় (গণিত ও ইংরেজি সহ)',
        teachingDaysPerWeek: teachingDaysPerWeek || 'সপ্তাহে ৩ দিন',
        hoursPerDay: hoursPerDay || '১.৫ ঘণ্টা',
        preferredMedium,
        remuneration: remuneration || 'আলোচনা সাপেক্ষে'
      } : undefined,
      agriMachineryInfo: role === 'agri_machinery_driver' ? {
        machineryType,
        machineModelOrNumber: machineModelOrNumber || 'কৃষিযন্ত্র',
        hourlyOrDailyRate: machineryRate || 'আলোচনা সাপেক্ষে',
        availableAttachments: availableAttachments || 'লাঙল ও চাষের যন্ত্র',
        isEmergencyServiceAvailable: true,
        status: isDriverOrBoatman ? 'পেন্ডিং' : 'সচল',
        rating: 5.0,
        totalRatingsCount: 1
      } : undefined,
      boatmanInfo: role === 'boatman' ? {
        boatType,
        ghatNameOrRoute: ghatNameOrRoute || `${address.upazila} নদী ঘাট ও পারাপার`,
        serviceShift: boatmanShift,
        fareRate: boatFareRate || 'নির্ধারিত ঘাট রেট',
        emergencyNightCrossing: boatmanShift.includes('রাত'),
        status: isDriverOrBoatman ? 'পেন্ডিং' : 'সচল',
        rating: 5.0,
        totalRatingsCount: 1
      } : undefined
    };

    localStorage.setItem('polli_user_profile', JSON.stringify(newUser));
    await saveCloudUserProfile(newUser);

    // Automatic Professional Welcome Message from Admin Panel / Polli Sheba Apps to User's Inbox
    try {
      const welcomeConversationId = ['admin_pollisheba', cleanPhone].sort().join('_');
      const now = new Date();
      const timeFormatted = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });
      const welcomeText = `আসসালামু আলাইকুম ${newUser.name},
পল্লী সেবা (Polli Sheba) ডিজিটাল প্ল্যাটফর্মে আপনাকে আন্তরিক স্বাগতম ও মোবারকবাদ! 🌾

আপনার অ্যাকাউন্টটি সফলভাবে নিবন্ধিত হয়েছে। এখন থেকে আপনি আপনার এলাকার সকল জরুরি সেবা, কৃষি বাজার, গ্রামীণ পরিবহন, জরুরি রক্তদাতা, ডাক্তার, টিউশন ও মেকানিক সেবা সহজে ও নিরাপদে উপভোগ করতে পারবেন।

জরুরি প্রয়োজনে বা যেকোনো সহায়তায় আমাদের ইনবক্সে যেকোনো সময় বার্তা পাঠাতে পারেন। পল্লী সেবার সাথে থাকার জন্য ধন্যবাদ!`;

      const welcomeMsg: ChatMessage = {
        id: `msg-welcome-${Date.now()}`,
        senderId: 'admin_pollisheba',
        senderName: 'পল্লী সেবা কর্তৃপক্ষ (এডমিন)',
        senderRole: 'admin',
        recipientId: cleanPhone,
        recipientName: newUser.name,
        conversationId: welcomeConversationId,
        text: welcomeText,
        timestamp: Date.now(),
        timeFormatted: timeFormatted,
        isRead: false,
        isDelivered: true,
        deliveryStatus: 'delivered',
        messageType: 'text'
      };

      await saveCloudMessage(welcomeMsg);

      // In-app welcome notification card
      saveDemandNotification({
        id: `notif-welcome-${Date.now()}`,
        title: '🌾 স্বাগতম! পল্লী সেবা প্ল্যাটফর্মে আপনার নিবন্ধন সফল হয়েছে',
        message: `সম্মানিত ${newUser.name}, আপনার অ্যাকাউন্ট সফলভাবে নিবন্ধিত হয়েছে। ইনবক্সে আপনার জন্য স্বাগত বার্তা পাঠানো হয়েছে।`,
        urgency: 'সাধারণ',
        targetDistrict: newUser.district || 'সকল জেলা',
        targetUpazila: newUser.upazila || 'সকল উপজেলা',
        targetRole: 'all',
        categoryName: 'স্বাগতম',
        senderName: 'পল্লী সেবা কর্তৃপক্ষ',
        contactNumber: '০১৭০০০০০০০০',
        actionUrl: 'inbox',
        itemId: `welcome-${cleanPhone}`,
        targetCategory: 'general',
        createdAt: Date.now(),
        expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
        createdAtFormatted: 'এইমাত্র'
      });
    } catch (msgErr) {
      console.warn('Welcome message dispatch note:', msgErr);
    }

    if (isDriverOrBoatman) {
      alert('ধন্যবাদ! আপনার চালক/মাঝি নিবন্ধনটি সফলভাবে জমা হয়েছে।\n\nনিরাপত্তার স্বার্থে এডমিন কর্তৃক আপনার এনআইডি ও লাইভ ফেস ভেরিফিকেশন তথ্য যাচাইয়ের জন্য আবেদনটি বর্তমানে পেন্ডিং রয়েছে। এডমিন অনুমোদন দিলে আপনার অ্যাকাউন্টটি সম্পূর্ণ সচল হবে এবং ইনবক্সে স্বাগত শুভেচ্ছা বার্তা পাবেন।');
    }

    onSuccess(newUser);
    onClose();
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const compressed = await compressImage(file, 400, 400, 0.75);
        setAvatarUrl(compressed);
        setIsLiveVerified(false);
        setPhotoError(null);
      } catch (err) {
        console.error('Avatar compress error:', err);
        const reader = new FileReader();
        reader.onloadend = () => {
          setAvatarUrl(reader.result as string);
          setIsLiveVerified(false);
          setPhotoError(null);
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const handleNidFrontUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsCompressingNidFront(true);
    try {
      const compressed = await compressImage(file, 900, 600, 0.8);
      setDriverNidFrontUrl(compressed);
      setDriverDocsError(null);
    } catch (err) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setDriverNidFrontUrl(reader.result as string);
        setDriverDocsError(null);
      };
      reader.readAsDataURL(file);
    } finally {
      setIsCompressingNidFront(false);
    }
  };

  const handleNidBackUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsCompressingNidBack(true);
    try {
      const compressed = await compressImage(file, 900, 600, 0.8);
      setDriverNidBackUrl(compressed);
      setDriverDocsError(null);
    } catch (err) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setDriverNidBackUrl(reader.result as string);
        setDriverDocsError(null);
      };
      reader.readAsDataURL(file);
    } finally {
      setIsCompressingNidBack(false);
    }
  };

  return (
    <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-lg w-full p-4 sm:p-6 shadow-2xl border border-[#E6E0D4] max-h-[88vh] sm:max-h-[90vh] overflow-y-auto overscroll-contain relative">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#736B5E] hover:text-[#2D3A3A] p-1.5 rounded-full hover:bg-gray-100 cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Branding & Mode Switcher */}
        <div className="space-y-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-bold shadow-xs">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-[#2D3A3A]">
                পল্লী সেবা নাগরিক অ্যাকাউন্ট
              </h3>
              <p className="text-xs text-[#736B5E]">
                {promptActionName ? `💡 ${promptActionName} অ্যাকাউন্টে প্রবেশ করুন` : 'নিরাপদ ও নির্ভরযোগ্য গ্রামীণ জনসেবা প্ল্যাটফর্ম'}
              </p>
            </div>
          </div>

          {/* Tab Switcher: [ 🔑 লগইন ] vs [ 📝 নতুন সদস্য নিবন্ধন ] */}
          {step === 'info' && (
            <div className="grid grid-cols-2 p-1 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
              <button
                type="button"
                onClick={() => switchToLogin()}
                className={`py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  authMode === 'login'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                }`}
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>লগইন (Login)</span>
              </button>

              <button
                type="button"
                onClick={() => switchToRegister()}
                className={`py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  authMode === 'register'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>নতুন নিবন্ধন (Register)</span>
              </button>
            </div>
          )}
        </div>

        {/* ---------------------------------------------------- */}
        {/* VIEW 1: LOGIN FORM */}
        {/* ---------------------------------------------------- */}
        {step === 'info' && authMode === 'login' && (
          <form onSubmit={handleLoginSubmit} className="space-y-4 animate-in fade-in">
            {loginError && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-2xl text-xs font-medium space-y-1">
                <p>{loginError}</p>
                {loginError.includes('নতুন সদস্য নিবন্ধন') && (
                  <button
                    type="button"
                    onClick={() => switchToRegister(loginIdentifier)}
                    className="text-xs text-[#2D5A27] font-bold underline block mt-1"
                  >
                    👉 এখানে ক্লিক করে নতুন অ্যাকাউন্ট খুলুন
                  </button>
                )}
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                মোবাইল নম্বর অথবা ইমেইল ঠিকানা <span className="text-red-500">*</span>
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-2 flex items-center gap-1 bg-[#D4E4BC]/70 border border-[#2D5A27]/30 text-[#2D5A27] font-bold text-xs px-2 py-1 rounded-lg pointer-events-none z-10">
                  <span>🇧🇩</span>
                  <span>+880</span>
                </div>
                <input
                  type="text"
                  required
                  placeholder="17xxxxxxxx বা email@example.com"
                  value={loginIdentifier.startsWith('0') ? loginIdentifier.substring(1) : loginIdentifier}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val.includes('@') || /^[a-zA-Z]/.test(val)) {
                      setLoginIdentifier(val);
                    } else {
                      const formatted = formatBangladeshiPhone(val);
                      setLoginIdentifier(formatted.nationalNumber || val);
                    }
                    setLoginError(null);
                  }}
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl pl-20 pr-4 py-2.5 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                />
              </div>
              <p className="text-[10px] text-[#736B5E] mt-0.5">
                মোবাইল নম্বরে স্বয়ংক্রিয় কান্ট্রি কোড (+880) সক্রিয় রয়েছে।
              </p>
            </div>

            {!loginWithOtpOnly ? (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#2D3A3A]">
                    পাসওয়ার্ড অথবা ৪-সংখ্যার পিন <span className="text-red-500">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setLoginWithOtpOnly(true)}
                    className="text-[11px] text-[#2D5A27] font-bold underline hover:text-[#1E4620] cursor-pointer"
                  >
                    পাসওয়ার্ড মনে নেই? ওটিপি দিয়ে লগইন
                  </button>
                </div>
                <div className="relative flex items-center">
                  <KeyRound className="w-4 h-4 text-[#736B5E] absolute left-3.5 pointer-events-none" />
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    required
                    placeholder="আপনার গোপন পাসওয়ার্ড বা পিন"
                    value={loginPassword}
                    onChange={(e) => {
                      setLoginPassword(e.target.value);
                      setLoginError(null);
                    }}
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl pl-10 pr-10 py-2.5 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute right-3 text-[#736B5E] hover:text-[#2D3A3A] p-1"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#D4C3A3] space-y-1 text-center">
                <span className="text-xs font-bold text-[#2D5A27]">
                  ⚡ এসএমএস / অনলাইন ওটিপি মোড সক্রিয়
                </span>
                <p className="text-[11px] text-[#736B5E]">
                  নিচের বাটনে ট্যাপ করলে আপনার নম্বরে ৪-সংখ্যার ওটিপি পাঠিয়ে সরাসরি লগইন সম্পন্ন হবে।
                </p>
                <button
                  type="button"
                  onClick={() => setLoginWithOtpOnly(false)}
                  className="text-[11px] text-[#2D5A27] font-bold underline mt-1 inline-block"
                >
                  ← পাসওয়ার্ড দিয়ে লগইন করতে ফিরে যান
                </button>
              </div>
            )}

            <div className="pt-2">
              <button
                type="submit"
                disabled={isSearchingUser}
                className="w-full flex items-center justify-center gap-2 py-3 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer disabled:opacity-50"
              >
                {isSearchingUser ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>যাচাই করা হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>{loginWithOtpOnly ? 'ওটিপি কোড নিন ও লগইন করুন' : 'অ্যাকাউন্টে লগইন করুন'}</span>
                  </>
                )}
              </button>
            </div>

            <div className="text-center pt-2 border-t border-[#E6E0D4]">
              <p className="text-xs text-[#736B5E]">
                এখনো অ্যাকাউন্ট নেই?{' '}
                <button
                  type="button"
                  onClick={() => switchToRegister(loginIdentifier)}
                  className="text-[#2D5A27] font-bold underline hover:text-[#1E4620] cursor-pointer"
                >
                  এককালীন নতুন সদস্য নিবন্ধন করুন
                </button>
              </p>
            </div>
          </form>
        )}

        {/* ---------------------------------------------------- */}
        {/* VIEW 2: REGISTER FORM */}
        {/* ---------------------------------------------------- */}
        {step === 'info' && authMode === 'register' && (
          <form onSubmit={handleRegisterInfoSubmit} className="space-y-4 animate-in fade-in">
            
            {/* User Role Selection - Classic & Simple Roles */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-[#2D3A3A]">
                  আপনার পেশা বা প্রধান ভূমিকা নির্বাচন করুন: <span className="text-red-500">*</span>
                </label>
                <span className="text-[10px] text-[#2D5A27] bg-[#E8F8F5] px-2 py-0.5 rounded-full font-bold border border-[#A9DFBF]">
                  সহজ পেশা নির্বাচন
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                {[
                  { id: 'citizen', label: 'সাধারণ নাগরিক', icon: User, desc: 'সেবাগ্রহণ ও গৃহস্থালি' },
                  { id: 'farmer', label: 'কৃষক / খামারি', icon: Sprout, desc: 'ফসল ও কৃষি পণ্য' },
                  { id: 'laborer', label: 'কৃষি শ্রমিক / দিনমজুর', icon: Hammer, desc: 'মাঠ ও সাধারণ শ্রম' },
                  { id: 'driver', label: 'পরিবহন চালক', icon: Car, desc: 'ইজিবাইক, সিএনজি, বাইক' },
                  { id: 'mechanic', label: 'মেকানিক ও মিস্ত্রি', icon: Wrench, desc: 'ইলেকট্রিশিয়ান ও কারিগর' },
                  { id: 'tutor_student', label: 'শিক্ষক / শিক্ষার্থী', icon: GraduationCap, desc: 'গৃহশিক্ষক বা অভিভাবক' },
                  { id: 'doctor', label: 'পল্লী চিকিৎসক', icon: ShieldCheck, desc: 'স্বাস্থ্যসেবা ও ফার্মেসি' },
                  { id: 'home_entrepreneur', label: 'গৃহ উদ্যোক্তা', icon: Sparkles, desc: 'হাতের কাজ ও খাবার' },
                  { id: 'trader', label: 'ব্যবসায়ী / ক্রেতা', icon: ShoppingBag, desc: 'পাইকারি ও খুচরা কেনাবেচা' },
                  { id: 'agri_machinery_driver', label: 'কৃষিযন্ত্র চালক', icon: Tractor, desc: 'ট্র্যাক্টর ও হার্ভেস্টার' },
                  { id: 'boatman', label: 'নৌকার মাঝি / খেয়া', icon: Anchor, desc: 'নদী পারাপার ও ট্রলার' },
                  { id: 'blood_donor', label: 'রক্তদাতা', icon: Droplet, desc: 'জরুরি রক্তদান' }
                ].map((r) => {
                  const Icon = r.icon;
                  const isSel = role === r.id || 
                    (r.id === 'mechanic' && role === 'electrician_mechanic') ||
                    (r.id === 'doctor' && role === 'health_worker');
                  return (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => setRole(r.id as UserRole)}
                      className={`p-2.5 rounded-2xl border text-left flex items-center gap-2 transition cursor-pointer ${
                        isSel
                          ? 'bg-[#2D5A27] text-white border-[#2D5A27] shadow-sm'
                          : 'bg-[#FAF8F5] text-[#2D3A3A] border-[#E6E0D4] hover:bg-[#F9E5D4]/40'
                      }`}
                    >
                      <div className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 ${
                        isSel ? 'bg-white/20 text-white' : 'bg-[#D4E4BC] text-[#2D5A27]'
                      }`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-[11px] font-bold leading-tight truncate block">
                          {r.label}
                        </span>
                        <span className={`text-[9px] block truncate ${isSel ? 'text-[#D4E4BC]' : 'text-[#736B5E]'}`}>
                          {r.desc}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Name & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                  আপনার পূর্ণ নাম <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: মো: আব্দুল্লাহ"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl px-3.5 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                  মোবাইল নম্বর (একটি নম্বরে একবারই) <span className="text-red-500">*</span>
                </label>
                <div className="relative flex items-center">
                  <div className="absolute left-2 flex items-center gap-1 bg-[#D4E4BC]/70 border border-[#2D5A27]/30 text-[#2D5A27] font-bold text-xs px-2 py-1 rounded-lg pointer-events-none z-10">
                    <span>🇧🇩</span>
                    <span>+880</span>
                  </div>
                  <input
                    type="tel"
                    required
                    placeholder="17xxxxxxxx"
                    value={phone.startsWith('0') ? phone.substring(1) : phone}
                    onChange={(e) => {
                      const formatted = formatBangladeshiPhone(e.target.value);
                      setPhone(formatted.nationalNumber);
                    }}
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl pl-20 pr-3.5 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                  />
                </div>
                <p className="text-[10px] text-[#736B5E] mt-0.5">
                  স্বয়ংক্রিয় কান্ট্রি কোড (+880) যুক্ত রয়েছে। বাকি ১০ ডিজিট লিখুন (যেমন: 1712345678 বা ০১৭...)।
                </p>
              </div>
            </div>

            {/* Notice regarding Phone-only registration and PIN after OTP */}
            <div className="p-3 bg-[#FAF8F5] rounded-2xl border border-[#D4C3A3] space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#2D5A27]">
                <KeyRound className="w-4 h-4 text-[#2D5A27]" />
                <span>নিবন্ধনের নিয়ম ও নিরাপত্তা নির্দেশিকা:</span>
              </div>
              <p className="text-[11px] text-[#5A6B6B] leading-relaxed">
                • শুধুমাত্র <strong>সক্রিয় একবার ব্যবহারযোগ্য মোবাইল নম্বর</strong> দিয়ে নিবন্ধন হবে।
                <br />
                • ওটিপি (OTP) যাচাই করার <strong>পরবর্তী ধাপে গোপন পিন নম্বর সেট করা বাধ্যতামূলক</strong>।
                <br />
                • নিবন্ধন শেষে আপনি প্রোফাইল অপশনে গিয়ে যে কোনো সময় আপনার <strong>ইমেইল/জিমেইল যুক্ত</strong> করতে পারবেন।
              </p>
            </div>

            {/* Profile Photo - STRICT LIVE CAMERA VERIFICATION (Gallery Disabled) */}
            <div className={`p-4 rounded-2xl border-2 ${photoError ? 'border-red-400 bg-red-50/40' : 'border-[#2D5A27] bg-[#FDFBF7]'} space-y-3`}>
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-[#2D5A27]" />
                  <span className="text-xs font-bold text-[#2D3A3A]">
                    লাইভ ক্যামেরা ভেরিফিকেশন (Live Camera Selfie) <span className="text-red-500">* বাধ্যতামূলক</span>
                  </span>
                </div>
                {avatarUrl && (
                  <span className="text-[10px] font-bold text-[#1E5631] bg-[#D4E4BC] px-2.5 py-1 rounded-full flex items-center gap-1 border border-[#A9DFBF]">
                    <CheckCircle className="w-3.5 h-3.5 text-[#27AE60]" />
                    <span>🛡️ লাইভ ভেরিফাইড ব্যাজ প্রস্তুত</span>
                  </span>
                )}
              </div>

              {/* Security Policy Reminder: Liveness Detection */}
              <div className="p-3 bg-emerald-50/90 rounded-2xl border border-emerald-200 text-[11px] text-emerald-950 leading-relaxed flex items-start gap-2.5 shadow-2xs">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-emerald-900 mb-0.5">
                    রিয়েল-টাইম লাইভনেস ভেরিফিকেশন (জীবন্ত মানুষ যাচাই)
                  </p>
                  <p className="text-[#3A5A40]">
                    প্রতারণা ও অন্য কারও স্থির ছবি/স্ক্রিন ব্যবহার প্রতিরোধে অ্যাপটিতে জীবন্ত চোখ পিটপিট (Blink) ও মুখমণ্ডল নড়াচড়া যাচাই করা হয়। কোনো স্থির ছবি বা গ্যালারি থেকে ছবি দেওয়া যাবে না।
                  </p>
                </div>
              </div>

              {/* Single Clear Live Verification Trigger */}
              <div className="bg-[#FAF8F5] p-3.5 sm:p-4 rounded-2xl border border-[#E6E0D4] flex flex-col sm:flex-row items-center justify-between gap-3.5">
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <div className="relative shrink-0">
                    {avatarUrl ? (
                      <div className="relative">
                        <img src={avatarUrl} alt="Live Verified Selfie" className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-600 shadow-md" />
                        <div className="absolute -bottom-1 -right-1 bg-emerald-600 text-white rounded-full p-1 shadow-xs">
                          <Check className="w-3 h-3" />
                        </div>
                      </div>
                    ) : (
                      <div className="w-16 h-16 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-bold text-xl border border-[#2D5A27]/40 shadow-inner">
                        {name ? name.charAt(0) : <User className="w-8 h-8" />}
                      </div>
                    )}
                  </div>

                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-[#2D3A3A]">
                        {avatarUrl ? 'লাইভ সেলফি যাচাইকৃত' : 'লাইভ ফেস স্ক্যান বাকি'}
                      </span>
                      {avatarUrl && (
                        <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.2 rounded-full border border-emerald-300">
                          ভেরিফাইড
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-[#5A6B6B]">
                      {avatarUrl 
                        ? 'চোখের পলক ও লাইভ মুভমেন্ট সফলভাবে ভেরিফাই হয়েছে।' 
                        : isDriverOrBoatman 
                          ? 'চালক ও মাঝিদের জন্য লাইভ ক্যামেরা ফেস ভেরিফিকেশন বাধ্যতামূলক।'
                          : 'বাংলা ভয়েস ও স্ক্রিনের নির্দেশনায় পলক ফেলে মুখ স্ক্যান করুন।'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
                  <button
                    type="button"
                    onClick={() => setShowLiveVerificationModal(true)}
                    className="w-full sm:w-auto px-5 py-3 bg-gradient-to-r from-[#2D5A27] to-[#1E5C46] hover:from-[#23491E] hover:to-[#174635] text-white text-xs font-bold rounded-xl shadow-md hover:shadow-lg transition cursor-pointer flex items-center justify-center gap-2 active:scale-95 shrink-0"
                  >
                    <Camera className="w-4 h-4 text-emerald-300" />
                    <span>{avatarUrl ? '✓ পুনরায় লাইভ সেলফি তুলুন' : '📸 লাইভ ফেস স্ক্যান (ক্যামেরা দিয়ে ছবি তুলুন)'}</span>
                  </button>
                </div>
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-[11px] text-emerald-950 font-semibold flex items-start gap-2 mt-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <p className="font-bold text-emerald-900">নিরাপত্তা নীতি (গ্যালারি নির্বাচন সম্পূর্ণ নিষ্ক্রিয়):</p>
                  <p className="text-emerald-800 leading-relaxed">
                    ভুয়া অ্যাকাউন্ট বা অন্যের ছবি ব্যবহার প্রতিরোধে নিবন্ধনের সময় গ্যালারি থেকে কোনো ছবি গ্রহণ করা হয় না। বাধ্যতামূলকভাবে আপনার ডিভাইসের ফ্রন্ট ক্যামেরা দিয়ে সরাসরি লাইভ সেলফি তুলে নিবন্ধন সম্পন্ন করতে হবে। সফল নিবন্ধনের পর সাধারণ ব্যবহারকারীরা প্রোফাইলে গিয়ে গ্যালারি থেকে ছবি পরিবর্তন করতে পারবেন।
                  </p>
                </div>
              </div>

              {photoError && (
                <p className="text-[11px] text-red-600 font-semibold flex items-center gap-1 pt-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{photoError}</span>
                </p>
              )}
            </div>

            {/* Cascading Address Dropdown */}
            <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#2D5A27]">
                <Sparkles className="w-3.5 h-3.5 text-[#E8924A]" />
                <span>আপনার স্থায়ী এলাকা নির্বাচন করুন:</span>
              </div>
              <CascadingAddressSelector
                address={address}
                onChange={setAddress}
                layout="grid-2x2"
                showVillageInput={true}
                required={true}
              />
            </div>

            {/* 1. পরিবহন চালক (Driver Profile) */}
            {role === 'driver' && (
              <div className="bg-[#FDFBF7] p-3.5 rounded-2xl border-2 border-[#2D5A27] space-y-3 animate-in fade-in">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#2D5A27]">
                  <Car className="w-4 h-4" />
                  <span>যানবাহনের বিবরণ (চালক প্রোফাইল):</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      যানবাহনের ধরন <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={vehicleType}
                      onChange={(e) => {
                        const val = e.target.value as any;
                        setVehicleType(val);
                        if (val.includes('সিএনজি')) setDriverSubCategory('cng');
                        else if (val.includes('বাইক')) setDriverSubCategory('bike');
                        else if (val.includes('ইজিবাইক') || val.includes('অটো')) setDriverSubCategory('easybike');
                        else if (val.includes('পিকআপ') || val.includes('নসিমন') || val.includes('ভ্যান')) setDriverSubCategory('van');
                        else if (val.includes('অ্যাম্বুলেন্স')) setDriverSubCategory('ambulance');
                        else setDriverSubCategory('private_car');
                      }}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    >
                      <option value="অটোরিকশা / ইজিবাইক">অটোরিকশা / ইজিবাইক</option>
                      <option value="সিএনজি">সিএনজি অটোরিকশা</option>
                      <option value="বাইক রাইডার">বাইক রাইডার</option>
                      <option value="পিকআপ / নসিমন">পিকআপ / নসিমন</option>
                      <option value="মাইক্রোবাস / কার">মাইক্রোবাস / কার</option>
                      <option value="ভ্যান / রিক্সা">ভ্যান / প্যাডেল রিক্সা</option>
                      <option value="জরুরি অ্যাম্বুলেন্স">জরুরি অ্যাম্বুলেন্স</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      গাড়ির নম্বর / প্লেট <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="যেমন: ঢাকা-থ ১২-৩৪৫৬"
                      value={vehicleNumber}
                      onChange={(e) => setVehicleNumber(e.target.value)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      সেবার শিফট / সময়
                    </label>
                    <select
                      value={serviceShift}
                      onChange={(e) => setServiceShift(e.target.value as any)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    >
                      <option value="দিন ও রাত (২৪ ঘণ্টা)">দিন ও রাত (২৪ ঘণ্টা)</option>
                      <option value="শুধুমাত্র দিনে">শুধুমাত্র দিনে</option>
                      <option value="শুধুমাত্র রাতে">শুধুমাত্র রাতে (জরুরি নাইট রাইড)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      স্ট্যান্ড বা নিয়মিত চলার রুট
                    </label>
                    <input
                      type="text"
                      placeholder="যেমন: সাভার বাসস্ট্যান্ড থেকে আশুলিয়া"
                      value={regularRoutes}
                      onChange={(e) => setRegularRoutes(e.target.value)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                    সম্ভাব্য ভাড়া বা আলোচনা সাপেক্ষে রেট (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: প্রতি কিমি ১৫-২০ টাকা বা আলোচনা সাপেক্ষে"
                    value={estimatedFare}
                    onChange={(e) => setEstimatedFare(e.target.value)}
                    className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                  />
                </div>
              </div>
            )}

            {/* 2. মেকানিক ও কারিগর */}
            {(role === 'mechanic' || role === 'electrician_mechanic') && (
              <div className="bg-[#FFF7ED] p-3.5 rounded-2xl border-2 border-[#EA580C] space-y-3 animate-in fade-in">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#C2410C]">
                  <Wrench className="w-4 h-4" />
                  <span>মেকানিক, ইলেকট্রিশিয়ান ও কারিগর বিবরণ:</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      কাজের দক্ষতা / পেশা <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={mechanicSubCategory}
                      onChange={(e) => setMechanicSubCategory(e.target.value)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    >
                      <option value="house_electrician">বাসাবাড়ির ইলেকট্রিশিয়ান ও ওয়্যারিং</option>
                      <option value="vehicle_mechanic">মোটরসাইকেল, অটোরিকশা ও সিএনজি মেকানিক</option>
                      <option value="appliance_mechanic">টিভি, ফ্রিজ ও ফ্যান মেকানিক</option>
                      <option value="shallow_mechanic">শ্যালো মেশিন ও কৃষি পাম্প মিস্ত্রি</option>
                      <option value="plumber_pipe">প্লাম্বার ও পাইপলাইন মিস্ত্রি</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      ওয়ার্কশপ বা সেবার এলাকা (ঐচ্ছিক)
                    </label>
                    <input
                      type="text"
                      placeholder="যেমন: সাভার বাজার মোড় বা হোম সার্ভিস"
                      value={workshopName}
                      onChange={(e) => setWorkshopName(e.target.value)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 3. কৃষি শ্রমিক ও দিনমজুর */}
            {role === 'laborer' && (
              <div className="bg-[#FEFCE8] p-3.5 rounded-2xl border-2 border-[#CA8A04] space-y-3 animate-in fade-in">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#A16207]">
                  <Hammer className="w-4 h-4" />
                  <span>কৃষি শ্রমিক ও দিনমজুর প্রোফাইল:</span>
                </div>
                <p className="text-xs text-[#854D0E] leading-relaxed">
                  🌾 একজন গ্রামীণ শ্রমিক হিসেবে আপনি মাঠের ফসল কাটা, মাটি কাটা, রাজমিস্ত্রির সহায়তা কিংবা যেকোনো ধরনের দৈনিক কাজের জন্য সরাসরি ডাক পেতে পারেন।
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      কাজের বিশেষ আগ্রহ (ঐচ্ছিক)
                    </label>
                    <select
                      value={laborerSubCategory}
                      onChange={(e) => setLaborerSubCategory(e.target.value)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    >
                      <option value="general_labor">সব ধরনের কৃষি ও সাধারণ শ্রম</option>
                      <option value="crop_harvesting">ফসল কাটা ও ধান রোয়া</option>
                      <option value="soil_earthwork">মাটি কাটা ও ভরাট কাজ</option>
                      <option value="mason_helper">রাজমিস্ত্রি ও নির্মাণ সহকারী</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      প্রত্যাশিত দৈনিক মজুরি (ঐচ্ছিক)
                    </label>
                    <input
                      type="text"
                      placeholder="যেমন: ৫০০-৭০০ টাকা / দিন বা আলোচনা সাপেক্ষে"
                      value={laborerDailyWage}
                      onChange={(e) => setLaborerDailyWage(e.target.value)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 4. পল্লী চিকিৎসক ও স্বাস্থ্যসেবা */}
            {(role === 'doctor' || role === 'health_worker') && (
              <div className="bg-[#FFF1F2] p-3.5 rounded-2xl border-2 border-[#E11D48] space-y-3 animate-in fade-in">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#BE123C]">
                  <ShieldCheck className="w-4 h-4" />
                  <span>পল্লী চিকিৎসক ও স্বাস্থ্যসেবা বিবরণ:</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      সেবার ধরন <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={healthWorkerSubCategory}
                      onChange={(e) => setHealthWorkerSubCategory(e.target.value)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    >
                      <option value="human_health">🩺 মানব স্বাস্থ্য ও প্রাথমিক চিকিৎসা</option>
                      <option value="veterinary">🐄 পল্লী পশু চিকিৎসক (ভেটেরিনারি)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      চেম্বার / ফার্মেসির নাম ও ঠিকানা
                    </label>
                    <input
                      type="text"
                      placeholder="যেমন: জনসেবা ফার্মেসি বা হোম ভিজিট"
                      value={healthChamberName}
                      onChange={(e) => setHealthChamberName(e.target.value)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 5. গৃহশিক্ষক ও শিক্ষার্থী */}
            {role === 'tutor_student' && (
              <div className="bg-[#F4F6FC] p-4 rounded-3xl border-2 border-[#4338CA] space-y-3.5 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#4338CA]">
                    <GraduationCap className="w-4 h-4" />
                    <span>নিবন্ধনের ধরন স্পষ্ট করুন: <span className="text-red-500">*</span></span>
                  </div>
                  <span className="text-[10px] bg-[#4338CA]/10 text-[#4338CA] px-2.5 py-0.5 rounded-full font-bold">
                    ভূমিকা নির্বাচন
                  </span>
                </div>

                {/* 2 Clear Options */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setTutorType('teacher')}
                    className={`p-3 rounded-2xl border-2 text-left flex flex-col justify-between transition cursor-pointer ${
                      tutorType === 'teacher'
                        ? 'bg-white border-[#4338CA] shadow-sm ring-2 ring-[#4338CA]/20'
                        : 'bg-white/60 border-[#D4C3A3] hover:bg-white'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xl">👨‍🏫</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          tutorType === 'teacher' ? 'bg-[#4338CA] text-white' : 'bg-gray-100 text-gray-500'
                        }`}>
                          {tutorType === 'teacher' ? '✓ শিক্ষক নির্বাচিত' : 'বাছাই করুন'}
                        </span>
                      </div>
                      <div className="font-bold text-xs sm:text-sm text-[#2D3A3A]">
                        আমি গৃহশিক্ষক (পড়াতে সক্ষম)
                      </div>
                      <p className="text-[11px] text-[#5A6B6B] mt-1 leading-relaxed">
                        আলাদা বিজ্ঞাপন দেওয়ার কোনো দরকার নেই। এলাকার অভিভাবক বা ছাত্র-ছাত্রী শিক্ষক চেয়ে পোস্ট করলেই আপনি সরাসরি নোটিফিকেশন পাবেন।
                      </p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTutorType('student_parent')}
                    className={`p-3 rounded-2xl border-2 text-left flex flex-col justify-between transition cursor-pointer ${
                      tutorType === 'student_parent'
                        ? 'bg-white border-[#4338CA] shadow-sm ring-2 ring-[#4338CA]/20'
                        : 'bg-white/60 border-[#D4C3A3] hover:bg-white'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xl">🧑‍🎓</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          tutorType === 'student_parent' ? 'bg-[#4338CA] text-white' : 'bg-gray-100 text-gray-500'
                        }`}>
                          {tutorType === 'student_parent' ? '✓ শিক্ষার্থী/অভিভাবক' : 'বাছাই করুন'}
                        </span>
                      </div>
                      <div className="font-bold text-xs sm:text-sm text-[#2D3A3A]">
                        আমি শিক্ষার্থী বা অভিভাবক (শিক্ষক প্রয়োজন)
                      </div>
                      <p className="text-[11px] text-[#5A6B6B] mt-1 leading-relaxed">
                        আপনার বা সন্তানের জন্য শিক্ষক প্রয়োজন হলে নির্বাচন করুন। পরবর্তীতে খুব সহজেই এলাকায় 'শিক্ষক প্রয়োজন' পোস্ট দিতে পারবেন।
                      </p>
                    </div>
                  </button>
                </div>

                {/* Conditional fields based on role */}
                {tutorType === 'teacher' ? (
                  <div className="space-y-3 pt-1 border-t border-[#4338CA]/20">
                    <div className="bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs p-2.5 rounded-xl">
                      📢 <strong>শিক্ষক হিসেবে সুবিধা:</strong> একবার প্রোফাইল তথ্য দিলে আপনার প্রোফাইল সরাসরি এলাকার শিক্ষক ডিরেক্টরিতে যুক্ত থাকবে এবং কোনো শিক্ষার্থী পোস্ট করলেই আপনার ফোনে নোটিফিকেশন পৌঁছে যাবে।
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                          শিক্ষাগত যোগ্যতা ও প্রতিষ্ঠান <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          placeholder="যেমন: অনার্স ৩য় বর্ষ (গণিত), ঢাকা বিশ্ববিদ্যালয় / বিএসসি"
                          value={tutorQualification}
                          onChange={(e) => setTutorQualification(e.target.value)}
                          className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none focus:border-[#4338CA] shadow-2xs"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                          যে যে বিষয় পড়াতে পারেন <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          placeholder="যেমন: গণিত, বিজ্ঞান, ইংরেজি, পদার্থবিজ্ঞান"
                          value={preferredSubjects}
                          onChange={(e) => setPreferredSubjects(e.target.value)}
                          className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none focus:border-[#4338CA] shadow-2xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div>
                        <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                          পড়ানোর শ্রেণি
                        </label>
                        <select
                          value={targetClasses}
                          onChange={(e) => setTargetClasses(e.target.value)}
                          className="w-full bg-white border border-[#D4C3A3] rounded-xl px-2.5 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                        >
                          <option value="১ম - ৫ম শ্রেণি (প্রাথমিক)">১ম - ৫ম শ্রেণি (প্রাথমিক)</option>
                          <option value="৬ষ্ঠ - ৮ম শ্রেণি (জেএসসি)">৬ষ্ঠ - ৮ম শ্রেণি (জেএসসি)</option>
                          <option value="৬ষ্ঠ - ১০ম শ্রেণি (এসএসসি)">৬ষ্ঠ - ১০ম শ্রেণি (এসএসসি)</option>
                          <option value="একাদশ - দ্বাদশ শ্রেণি (এইচএসসি)">একাদশ - দ্বাদশ (এইচএসসি)</option>
                          <option value="সকল শ্রেণি (১ম - ১২শ)">সকল শ্রেণি (১ম - ১২শ)</option>
                          <option value="মাদরাসা ও হিফজ বিভাগ">মাদরাসা ও হিফজ বিভাগ</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                          পাঠদান মাধ্যম
                        </label>
                        <select
                          value={preferredMedium}
                          onChange={(e) => setPreferredMedium(e.target.value as any)}
                          className="w-full bg-white border border-[#D4C3A3] rounded-xl px-2.5 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                        >
                          <option value="বাংলা মাধ্যম">বাংলা মাধ্যম</option>
                          <option value="ইংরেজি ভার্সন">ইংরেজি ভার্সন</option>
                          <option value="মাদরাসা মাধ্যম">মাদরাসা মাধ্যম</option>
                          <option value="সকল মাধ্যম">সকল মাধ্যম</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                          প্রত্যাশিত মাসিক সম্মানী
                        </label>
                        <input
                          type="text"
                          placeholder="যেমন: ২০০০ - ৩০০০ টাকা বা আলোচনা সাপেক্ষে"
                          value={remuneration}
                          onChange={(e) => setRemuneration(e.target.value)}
                          className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2.5 pt-1 border-t border-[#4338CA]/20">
                    <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs p-2.5 rounded-xl">
                      📢 <strong>শিক্ষার্থী ও অভিভাবকদের জন্য:</strong> নিবন্ধন সম্পন্ন হওয়ার পর অ্যাপের 'শিক্ষক নেটওয়ার্ক' বোর্ডে গিয়ে সহজেই 'শিক্ষক প্রয়োজন' পোস্ট দিতে পারবেন। এলাকার শিক্ষকেরা তৎক্ষণাৎ অ্যালার্ট পাবেন।
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                          শিক্ষার্থীর বর্তমান শ্রেণি
                        </label>
                        <input
                          type="text"
                          placeholder="যেমন: ৭ম শ্রেণি / ৯ম শ্রেণি"
                          value={targetClasses}
                          onChange={(e) => setTargetClasses(e.target.value)}
                          className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                          যে যে বিষয়ে শিক্ষক প্রয়োজন
                        </label>
                        <input
                          type="text"
                          placeholder="যেমন: গণিত ও ইংরেজি"
                          value={preferredSubjects}
                          onChange={(e) => setPreferredSubjects(e.target.value)}
                          className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 6. কৃষিযন্ত্র চালক */}
            {role === 'agri_machinery_driver' && (
              <div className="bg-[#FFFBEB] p-3.5 rounded-2xl border-2 border-[#D97706] space-y-3 animate-in fade-in">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#B45309]">
                  <Tractor className="w-4 h-4 text-[#D97706]" />
                  <span>কৃষিযন্ত্র চালক বিবরণ:</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      যন্ত্রের ধরন <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={machineryType}
                      onChange={(e) => setMachineryType(e.target.value as any)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    >
                      <option value="পাওয়ার টিলার / জমি চাষের ট্র্যাক্টর">পাওয়ার টিলার / ট্র্যাক্টর (চাষ)</option>
                      <option value="হেস্কোভেটর (মাটি কাটা / খনন)">হেস্কোভেটর / ভেকু (মাটি কাটা)</option>
                      <option value="কম্বাইন হার্ভেস্টার (ধান কাটা)">কম্বাইন হার্ভেস্টার (ধান কাটা)</option>
                      <option value="অন্যান্য কৃষিযন্ত্র">অন্যান্য কৃষিযন্ত্র</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      ভাড়া বা চুক্তি রেট (ঐচ্ছিক)
                    </label>
                    <input
                      type="text"
                      placeholder="যেমন: বিঘা প্রতি ১২০০ টাকা বা আলোচনা সাপেক্ষে"
                      value={machineryRate}
                      onChange={(e) => setMachineryRate(e.target.value)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 7. নৌকার মাঝি ও খেয়া চালক */}
            {role === 'boatman' && (
              <div className="bg-[#ECFEFF] p-3.5 rounded-2xl border-2 border-[#0891B2] space-y-3 animate-in fade-in">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#0E7490]">
                  <Anchor className="w-4 h-4 text-[#0891B2]" />
                  <span>নৌকার মাঝি ও খেয়া চালক বিবরণ:</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      নৌকার ধরন
                    </label>
                    <select
                      value={boatType}
                      onChange={(e) => setBoatType(e.target.value as any)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    >
                      <option value="যাত্রীবাহী ট্রলার">যাত্রীবাহী ট্রলার</option>
                      <option value="ছোট খেয়া নৌকা">ছোট খেয়া নৌকা</option>
                      <option value="স্পিডবোট / ইঞ্জিন নৌকা">স্পিডবোট / ইঞ্জিন নৌকা</option>
                      <option value="মালামাল পরিবহন নৌকা">মালামাল পরিবহন নৌকা</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                      ঘাট বা পারাপার রুট
                    </label>
                    <input
                      type="text"
                      placeholder="যেমন: আমিনবাজার খেয়াঘাট থেকে কাউন্দিয়া"
                      value={regularRoutes}
                      onChange={(e) => setRegularRoutes(e.target.value)}
                      className="w-full bg-white border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none shadow-2xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 8. রক্তদাতা */}
            {role === 'blood_donor' && (
              <div className="bg-[#FEF2F2] p-3.5 rounded-2xl border-2 border-[#DC2626] space-y-3 animate-in fade-in">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#B91C1C]">
                  <Droplet className="w-4 h-4 text-[#DC2626]" />
                  <span>জরুরি রক্তদাতা প্রোফাইল:</span>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1.5">
                    আপনার রক্তের গ্রুপ নির্বাচন করুন: <span className="text-red-500">*</span>
                  </label>
                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                    {(['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'] as const).map((bg) => {
                      const isSel = bloodGroup === bg;
                      return (
                        <button
                          key={bg}
                          type="button"
                          onClick={() => setBloodGroup(bg)}
                          className={`py-2 rounded-xl text-center text-xs font-black border transition cursor-pointer ${
                            isSel
                              ? 'bg-[#DC2626] text-white border-[#DC2626] shadow-xs'
                              : 'bg-white text-[#B91C1C] border-[#FECACA] hover:bg-[#FEE2E2]'
                          }`}
                        >
                          {bg}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* 9. কৃষক ও খামারী */}
            {role === 'farmer' && (
              <div className="bg-[#F7FEE7] p-3.5 rounded-2xl border-2 border-[#65A30D] space-y-2 animate-in fade-in">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#4D7C0F]">
                  <Sprout className="w-4 h-4 text-[#65A30D]" />
                  <span>কৃষক ও খামারী প্রোফাইল:</span>
                </div>
                <p className="text-xs text-[#3F6212] leading-relaxed">
                  🌾 ফসলি জমির ধান, পাট, ভুট্টা, শাকসবজি ও খামারের গবাদিপশু-পাখি সরাসরি কেনাবেচার জন্য আপনার প্রোফাইল প্রস্তুত।
                </p>
              </div>
            )}

            {/* 10. সাধারণ নাগরিক */}
            {role === 'citizen' && (
              <div className="bg-[#F0FDF4] p-3.5 rounded-2xl border-2 border-[#16A34A] space-y-2 animate-in fade-in">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#15803D]">
                  <User className="w-4 h-4 text-[#16A34A]" />
                  <span>সাধারণ নাগরিক প্রোফাইল:</span>
                </div>
                <p className="text-xs text-[#166534] leading-relaxed">
                  👤 সেবা গ্রহণ ও কেনাকাটার পাশাপাশি ঘরে তৈরি খাবার বা যেকোনো সামগ্রীর পোস্ট দিতে পারবেন।
                </p>
              </div>
            )}

            {/* 11. চালক ও মাঝি এনআইডি/লাইসেন্স স্ক্যান ভেরিফিকেশন (Requirement 4) */}
            {isDriverOrBoatman && (
              <div className="bg-[#F0FDF4] p-3.5 sm:p-4 rounded-2xl border-2 border-[#16A34A] space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#15803D]">
                    <ShieldCheck className="w-4 h-4 text-[#16A34A]" />
                    <span>এনআইডি (NID) বা ড্রাইভিং লাইসেন্স স্ক্যান <span className="text-red-500">*</span></span>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-extrabold px-2 py-0.5 rounded-full border border-emerald-300">
                    বাধ্যতামূলক
                  </span>
                </div>

                <p className="text-[11px] text-[#166534] leading-relaxed">
                  🛡️ যাত্রী নিরাপত্তা ও জবাবদিহিতার জন্য চালক ও মাঝিদের জাতীয় পরিচয়পত্র (NID) অথবা ড্রাইভিং লাইসেন্সের এপিঠ-ওপিঠ রঙিন ছবি স্ক্যান/আপলোড আবশ্যক। এই ছবিগুলো ক্লাউডে ১০০% সুরক্ষিত থাকবে এবং কেবল পিন-সুরক্ষিত এডমিন প্যানেল থেকে এডমিন বা সহকারী এডমিনরা যাচাই করতে পারবেন (সাধারণ ব্যবহারকারীরা দেখতে পাবেন না)।
                </p>

                {/* Document Type Selection */}
                <div className="flex items-center gap-4 bg-white p-2.5 rounded-xl border border-emerald-200 text-xs">
                  <span className="font-bold text-[#1F2937]">ডকুমেন্ট ধরন:</span>
                  <label className="flex items-center gap-1.5 cursor-pointer font-medium text-slate-700">
                    <input
                      type="radio"
                      name="driverLicenseType"
                      checked={driverLicenseType === 'nid'}
                      onChange={() => setDriverLicenseType('nid')}
                      className="text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                    />
                    <span>জাতীয় পরিচয়পত্র (NID)</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer font-medium text-slate-700">
                    <input
                      type="radio"
                      name="driverLicenseType"
                      checked={driverLicenseType === 'driving_license'}
                      onChange={() => setDriverLicenseType('driving_license')}
                      className="text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                    />
                    <span>ড্রাইভিং লাইসেন্স</span>
                  </label>
                </div>

                {/* 2 Scans: Front & Back Upload Boxes */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Front Side */}
                  <div className="bg-white p-3 rounded-xl border border-emerald-200 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-800">১. সামনের পাতা (এপিঠ) <span className="text-red-500">*</span></span>
                      {driverNidFrontUrl && <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">✓ আপলোড সম্পন্ন</span>}
                    </div>
                    {driverNidFrontUrl ? (
                      <div className="relative">
                        <img src={driverNidFrontUrl} alt="Front Document Scan" className="w-full h-28 object-cover rounded-lg border border-emerald-300" />
                        <button
                          type="button"
                          onClick={() => setDriverNidFrontUrl('')}
                          className="absolute top-1 right-1 bg-red-600 text-white rounded-full p-1 shadow-md hover:bg-red-700 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => nidFrontInputRef.current?.click()}
                        className="w-full h-28 border-2 border-dashed border-emerald-300 hover:border-emerald-500 rounded-lg flex flex-col items-center justify-center gap-1 bg-emerald-50/40 hover:bg-emerald-50 cursor-pointer transition text-center p-2"
                      >
                        <Camera className="w-5 h-5 text-emerald-600" />
                        <span className="text-xs font-bold text-emerald-800">
                          {isCompressingNidFront ? 'প্রসেসিং...' : 'এপিঠের ছবি তুলুন / আপলোড'}
                        </span>
                        <span className="text-[10px] text-slate-500">পরিষ্কার রঙিন ছবি দিন</span>
                      </div>
                    )}
                    <input
                      ref={nidFrontInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleNidFrontUpload}
                      className="hidden"
                    />
                  </div>

                  {/* Back Side */}
                  <div className="bg-white p-3 rounded-xl border border-emerald-200 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-800">২. পেছনের পাতা (ওপিঠ) <span className="text-red-500">*</span></span>
                      {driverNidBackUrl && <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">✓ আপলোড সম্পন্ন</span>}
                    </div>
                    {driverNidBackUrl ? (
                      <div className="relative">
                        <img src={driverNidBackUrl} alt="Back Document Scan" className="w-full h-28 object-cover rounded-lg border border-emerald-300" />
                        <button
                          type="button"
                          onClick={() => setDriverNidBackUrl('')}
                          className="absolute top-1 right-1 bg-red-600 text-white rounded-full p-1 shadow-md hover:bg-red-700 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => nidBackInputRef.current?.click()}
                        className="w-full h-28 border-2 border-dashed border-emerald-300 hover:border-emerald-500 rounded-lg flex flex-col items-center justify-center gap-1 bg-emerald-50/40 hover:bg-emerald-50 cursor-pointer transition text-center p-2"
                      >
                        <Camera className="w-5 h-5 text-emerald-600" />
                        <span className="text-xs font-bold text-emerald-800">
                          {isCompressingNidBack ? 'প্রসেসিং...' : 'ওপিঠের ছবি তুলুন / আপলোড'}
                        </span>
                        <span className="text-[10px] text-slate-500">পরিষ্কার রঙিন ছবি দিন</span>
                      </div>
                    )}
                    <input
                      ref={nidBackInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleNidBackUpload}
                      className="hidden"
                    />
                  </div>
                </div>

                {driverDocsError && (
                  <p className="text-[11px] text-red-600 font-bold flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{driverDocsError}</span>
                  </p>
                )}
              </div>
            )}

            {/* PRIVACY CONTROLS (Auto-hide phone & village + Offline Call Opt-In) */}
            <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#D4C3A3] space-y-2.5">
              <div className="text-[11px] text-[#2D3A3A] bg-[#E8F8F5] p-2.5 rounded-xl border border-[#A9DFBF] flex items-start gap-2">
                <Lock className="w-4 h-4 text-[#27AE60] flex-shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <p className="font-bold text-[#1E5631]">🛡️ প্রাইভেসি ও নিরাপদ যোগাযোগ নীতিমালা:</p>
                  <p className="leading-relaxed text-[#2D3A3A]">
                    ডিফল্টভাবে আপনার মোবাইল নম্বর ও গ্রাম সম্পূর্ণ গোপন (Auto-hidden) থাকবে। শুধু জেলা ও উপজেলা দৃশ্যমান হবে। ইন-অ্যাপ চ্যাট বা অনলাইন অডিও কলের মাধ্যমে যোগাযোগ সম্পূর্ণ নিরাপদ।
                  </p>
                </div>
              </div>

              <div className="space-y-2 bg-white p-3 rounded-xl border border-[#E6E0D4] text-xs text-[#2D3A3A]">
                {/* Auto-hide Status */}
                <div className="flex items-center justify-between gap-2 text-[#2D5A27] bg-[#FDFBF7] p-2 rounded-lg border border-[#D4E4BC]">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#27AE60]" />
                    <span className="font-semibold text-[11px]">মোবাইল নম্বর ও গ্রাম অটো-হাইড (সুরক্ষিত)</span>
                  </div>
                  <span className="text-[10px] bg-[#27AE60] text-white px-2 py-0.5 rounded-full font-bold">
                    ডিফল্ট সুরক্ষিত
                  </span>
                </div>

                {/* Specific Opt-in Checkbox required by user */}
                <label className="flex items-start justify-between gap-2.5 cursor-pointer select-none pt-1 border-t border-[#F0EBE1]">
                  <div className="space-y-0.5">
                    <span className="font-bold text-xs text-[#2D3A3A] block">
                      [✓] অফলাইন মোবাইল কলে যোগাযোগের সুযোগ দিন
                    </span>
                    <p className="text-[11px] text-[#736B5E] leading-tight">
                      ইউজার এটি অন না করা পর্যন্ত কেউ সরাসরি অফলাইনে কল দিতে পারবে না (অনলাইনে চ্যাট/কল করতে হবে)।
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={allowOfflineCall}
                    onChange={(e) => setAllowOfflineCall(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2D5A27] focus:ring-[#2D5A27] cursor-pointer mt-0.5 shrink-0"
                  />
                </label>
              </div>

              <label className="flex items-start gap-2.5 cursor-pointer select-none pt-1">
                <input
                  type="checkbox"
                  required
                  checked={agreedToTerms}
                  onChange={(e) => setAgreedToTerms(e.target.checked)}
                  className="mt-1 w-4 h-4 rounded text-[#2D5A27] focus:ring-[#2D5A27] cursor-pointer"
                />
                <span className="text-xs text-[#2D3A3A] leading-relaxed">
                  আমি অ্যাপের{' '}
                  <button
                    type="button"
                    onClick={onOpenTerms}
                    className="text-[#2D5A27] font-bold underline hover:text-[#1E3F1A]"
                  >
                    শর্তাবলী ও দায়মুক্তি নীতিমালা
                  </button>{' '}
                  মেনে চলতে সম্মত।
                </span>
              </label>
            </div>

            {/* Submit Bar (Elevated and clear of mobile navigation) */}
            <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3.5 pb-6 sm:pb-3 border-t border-[#E6E0D4] -mx-4 sm:-mx-6 px-4 sm:px-6 mt-6 z-20 flex justify-end gap-2 shadow-[0_-4px_14px_rgba(0,0,0,0.06)]">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-[#FAF8F5] border border-[#E6E0D4] hover:bg-gray-100 cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                disabled={checkingExisting}
                className="flex items-center gap-1.5 px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-md cursor-pointer disabled:opacity-50 active:scale-98 transition-all"
              >
                <span>{checkingExisting ? 'নম্বর পরীক্ষা হচ্ছে...' : 'পরবর্তী (OTP কোড নিন)'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </form>
        )}

        {/* ---------------------------------------------------- */}
        {/* VIEW 3: OTP VERIFICATION (Used for both Login & Register) */}
        {/* ---------------------------------------------------- */}
        {step === 'otp' && (
          <form onSubmit={handleVerifyOtp} className="space-y-4 py-2 animate-in fade-in">
            <div className="bg-[#FAF8F5] p-5 rounded-2xl border border-[#D4C3A3] text-center space-y-3">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>অনলাইন ওটিপি ভেরিফিকেশন সক্রিয়</span>
              </div>
              <p className="text-xs text-[#5A6B6B]">
                আপনার নম্বর <strong>{pendingOtpUser ? pendingOtpUser.phone : phone}</strong> এর জন্য ভেরিফিকেশন কোড:
              </p>
              <div className="bg-[#D4E4BC] text-[#2D5A27] font-mono text-3xl font-bold py-2.5 px-6 rounded-2xl inline-block tracking-widest border border-[#2D5A27] shadow-inner">
                {generatedOtp}
              </div>
              <div>
                <button
                  type="button"
                  onClick={() => {
                    setEnteredOtp(generatedOtp);
                    setOtpError(null);
                  }}
                  className="text-xs bg-[#2D5A27] hover:bg-[#1E4620] text-white px-4 py-2 rounded-xl font-bold transition shadow-xs cursor-pointer inline-flex items-center gap-1.5"
                >
                  <span>⚡ স্বয়ংক্রিয়ভাবে কোড বসান</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2D3A3A] mb-1.5 text-center">
                ৪ ডিজিট ওটিপি কোড দিন:
              </label>
              <input
                type="text"
                required
                maxLength={4}
                autoFocus
                placeholder="• • • •"
                value={enteredOtp}
                onChange={(e) => {
                  setEnteredOtp(e.target.value);
                  setOtpError(null);
                }}
                className="w-44 mx-auto block text-center font-mono text-xl font-bold bg-[#FAF8F5] border-2 border-[#2D5A27] rounded-2xl py-2.5 text-[#2D3A3A] tracking-widest focus:outline-none"
              />
              {otpError && (
                <p className="text-xs text-red-600 text-center mt-1 flex items-center justify-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{otpError}</span>
                </p>
              )}
            </div>

            <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3.5 pb-6 sm:pb-3 border-t border-[#E6E0D4] -mx-4 sm:-mx-6 px-4 sm:px-6 mt-4 z-20 flex justify-between items-center shadow-[0_-4px_14px_rgba(0,0,0,0.06)]">
              <button
                type="button"
                onClick={() => {
                  setStep('info');
                  setPendingOtpUser(null);
                }}
                className="text-xs text-[#5A6B6B] hover:text-[#2D3A3A] font-semibold cursor-pointer underline"
              >
                ← ফিরে যান
              </button>

              <button
                type="submit"
                className="flex items-center gap-1.5 px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-md cursor-pointer active:scale-98 transition-all"
              >
                <Check className="w-4 h-4" />
                <span>{pendingOtpUser ? 'যাচাই ও প্রবেশ সম্পন্ন করুন' : 'ওটিপি যাচাই ও পিন সেট করুন ➔'}</span>
              </button>
            </div>
          </form>
        )}

        {/* ---------------------------------------------------- */}
        {/* VIEW 4: MANDATORY PIN SETUP (Triggered AFTER OTP) */}
        {/* ---------------------------------------------------- */}
        {step === 'pin_setup' && (
          <form onSubmit={handleFinalizePinSetup} className="space-y-4 py-2 animate-in fade-in">
            <div className="bg-[#FAF8F5] p-4 rounded-2xl border-2 border-[#2D5A27] text-center space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#D4E4BC] text-[#2D5A27] text-xs font-bold rounded-full">
                <CheckCircle2 className="w-4 h-4" />
                <span>ওটিপি সফলভাবে যাচাই সম্পন্ন হয়েছে!</span>
              </div>
              <h4 className="font-bold text-sm text-[#2D3A3A]">
                আপনার ৪-সংখ্যার গোপন পিন সেট করুন <span className="text-red-500">*বাধ্যতামূলক</span>
              </h4>
              <p className="text-xs text-[#736B5E] leading-relaxed">
                ভবিষ্যতে আপনার মোবাইল নম্বর <strong>{phone}</strong> দিয়ে এক ক্লিকে লগইন করার জন্য একটি ৪-সংখ্যার গোপন পিন বা পাসওয়ার্ড দিন।
              </p>
            </div>

            {pinSetupError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{pinSetupError}</span>
              </div>
            )}

            <div className="p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#D4C3A3] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#2D5A27] flex items-center gap-1">
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>গোপন পিন কোড</span>
                </span>
                <button
                  type="button"
                  onClick={() => setShowRegisterPassword(!showRegisterPassword)}
                  className="text-[11px] text-[#736B5E] hover:text-[#2D3A3A] font-semibold cursor-pointer"
                >
                  {showRegisterPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                    ৪-সংখ্যার গোপন পিন <span className="text-red-500">*</span>
                  </label>
                  <input
                    type={showRegisterPassword ? 'text' : 'password'}
                    required
                    maxLength={8}
                    placeholder="যেমন: ১২৩৪ বা 5678"
                    value={passwordPin}
                    onChange={(e) => {
                      setPasswordPin(e.target.value);
                      setPinSetupError(null);
                    }}
                    className="w-full bg-white border-2 border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl px-3 py-2.5 text-center font-mono text-base font-bold text-[#2D3A3A] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1">
                    পুনরায় পিন নিশ্চিত করুন <span className="text-red-500">*</span>
                  </label>
                  <input
                    type={showRegisterPassword ? 'text' : 'password'}
                    required
                    maxLength={8}
                    placeholder="পুনরায় একই পিন লিখুন"
                    value={confirmPasswordPin}
                    onChange={(e) => {
                      setConfirmPasswordPin(e.target.value);
                      setPinSetupError(null);
                    }}
                    className="w-full bg-white border-2 border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl px-3 py-2.5 text-center font-mono text-base font-bold text-[#2D3A3A] focus:outline-none"
                  />
                </div>
              </div>

              <p className="text-[11px] text-[#736B5E] text-center pt-1">
                💡 টিপস: অ্যাকাউন্ট খোলার পর প্রোফাইলে গিয়ে আপনি যে কোনো সময় এই পিন পরিবর্তন করতে পারবেন।
              </p>
            </div>

            <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3.5 pb-6 sm:pb-3 border-t border-[#E6E0D4] -mx-4 sm:-mx-6 px-4 sm:px-6 mt-4 z-20 flex justify-between items-center shadow-[0_-4px_14px_rgba(0,0,0,0.06)]">
              <button
                type="button"
                onClick={() => setStep('otp')}
                className="text-xs text-[#5A6B6B] hover:text-[#2D3A3A] font-semibold cursor-pointer underline"
              >
                ← ওটিপি ধাপে ফিরে যান
              </button>

              <button
                type="submit"
                className="flex items-center gap-1.5 px-6 py-2.5 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-md cursor-pointer active:scale-98 transition-all"
              >
                <Check className="w-4 h-4" />
                <span>পিন নিশ্চিত করুন ও নিবন্ধন সম্পন্ন করুন</span>
              </button>
            </div>
          </form>
        )}

      </div>

      {/* Biometric Live Face Verification Modal */}
      {showLiveVerificationModal && (
        <LiveFaceVerificationModal
          title="বায়োমেট্রিক লাইভ ফেস ভেরিফিকেশন"
          subtitle="ভুয়া ছবি বা স্থির ছবি প্রতিরোধে চোখ পিটপিট ও জীবন্ত মুখমণ্ডল যাচাই"
          onCapture={(capturedBase64) => {
            setAvatarUrl(capturedBase64);
            setIsLiveVerified(true);
            setPhotoError(null);
            setShowLiveVerificationModal(false);
          }}
          onCancel={() => setShowLiveVerificationModal(false)}
        />
      )}
    </div>
  );
};
