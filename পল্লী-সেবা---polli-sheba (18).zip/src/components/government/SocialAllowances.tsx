import React, { useState } from 'react';
import { CheckCircle, XCircle, UserCheck } from 'lucide-react';

export const SocialAllowances: React.FC = () => {
  const [allowanceType, setAllowanceType] = useState<'old_age' | 'widow' | 'disability' | 'maternity'>('old_age');
  
  // Form fields
  const [age, setAge] = useState<number>(65);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [annualIncome, setAnnualIncome] = useState<number>(8000);
  const [hasGovPension, setHasGovPension] = useState<boolean>(false);
  const [hasDisabilityCard, setHasDisabilityCard] = useState<boolean>(false);

  // Check qualification
  const checkEligibility = (): { eligible: boolean; reasons: string[]; amount: string } => {
    const reasons: string[] = [];
    let eligible = true;

    if (hasGovPension) {
      eligible = false;
      reasons.push('সরকারি চাকরিজীবী হিসেবে পেনশনভোগী হলে এ ভাতা প্রযোজ্য নয়।');
    }

    if (allowanceType === 'old_age') {
      if (gender === 'male' && age < 65) {
        eligible = false;
        reasons.push('পুরুষের ক্ষেত্রে ন্যূনতম বয়স ৬৫ বছর হতে হবে।');
      }
      if (gender === 'female' && age < 62) {
        eligible = false;
        reasons.push('নারীর ক্ষেত্রে ন্যূনতম বয়স ৬২ বছর হতে হবে।');
      }
      if (annualIncome > 10000) {
        eligible = false;
        reasons.push('বার্ষিক ব্যক্তিগত আয় ১০,০০০ টাকার কম হতে হবে।');
      }
      return {
        eligible,
        reasons: eligible ? ['আপনি বয়স্ক ভাতার জন্য শতভাগ যোগ্য!'] : reasons,
        amount: 'প্রতি মাসে ৬০০ টাকা (সরাসরি বিকাশ/নগদ অ্যাকাউন্টে)'
      };
    }

    if (allowanceType === 'widow') {
      if (gender !== 'female') {
        eligible = false;
        reasons.push('বিধবা ও স্বামী নিগৃহীতা ভাতা শুধুমাত্র নারীদের জন্য প্রযোজ্য।');
      }
      return {
        eligible,
        reasons: eligible ? ['আপনি বিধবা ও স্বামী নিগৃহীতা ভাতার যোগ্য!'] : reasons,
        amount: 'প্রতি মাসে ৫৫০ টাকা'
      };
    }

    if (allowanceType === 'disability') {
      if (!hasDisabilityCard) {
        eligible = false;
        reasons.push('সমাজসেবা অধিদপ্তর কর্তৃক প্রদত্ত সুবর্ণ নাগরিক বা প্রতিবন্ধী পরিচয়পত্র থাকা আবশ্যক।');
      }
      return {
        eligible,
        reasons: eligible ? ['আপনি অসচ্ছল প্রতিবন্ধী ভাতার যোগ্য!'] : reasons,
        amount: 'প্রতি মাসে ৮৫০ টাকা'
      };
    }

    // maternity
    return {
      eligible: gender === 'female' && !hasGovPension,
      reasons: gender === 'female' && !hasGovPension ? ['আপনি মাতৃত্বকালীন ভাতার যোগ্য!'] : ['শুধুমাত্র গর্ভবতী বা স্তন্যদাত্রী মা প্রযোজ্য।'],
      amount: 'প্রতি মাসে ৮০০ টাকা (সর্বোচ্চ ৩৬ মাস পর্যন্ত)'
    };
  };

  const result = checkEligibility();

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm">
        <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
          🤝 সামাজিক নিরাপত্তা কর্মসূচি
        </span>
        <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
          সরকারি ভাতা যোগ্যতা যাচাই ও নিয়মাবলী
        </h2>
        <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
          বয়স্ক, বিধবা, প্রতিবন্ধী ও মাতৃত্বকালীন ভাতার জন্য আপনার যোগ্যতা কয়েক সেকেন্ডে যাচাই করুন
        </p>
      </div>

      {/* Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => { setAllowanceType('old_age'); setGender('male'); }}
          className={`p-4 rounded-3xl border-2 font-bold text-xs sm:text-sm transition cursor-pointer ${
            allowanceType === 'old_age'
              ? 'border-[#2D5A27] bg-[#D4E4BC]/30 text-[#2D5A27] shadow-xs'
              : 'border-[#E6E0D4] bg-white text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          👴 বয়স্ক ভাতা
        </button>

        <button
          onClick={() => { setAllowanceType('widow'); setGender('female'); }}
          className={`p-4 rounded-3xl border-2 font-bold text-xs sm:text-sm transition cursor-pointer ${
            allowanceType === 'widow'
              ? 'border-[#2D5A27] bg-[#D4E4BC]/30 text-[#2D5A27] shadow-xs'
              : 'border-[#E6E0D4] bg-white text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          🧕 বিধবা ও স্বামী নিগৃহীতা ভাতা
        </button>

        <button
          onClick={() => setAllowanceType('disability')}
          className={`p-4 rounded-3xl border-2 font-bold text-xs sm:text-sm transition cursor-pointer ${
            allowanceType === 'disability'
              ? 'border-[#2D5A27] bg-[#D4E4BC]/30 text-[#2D5A27] shadow-xs'
              : 'border-[#E6E0D4] bg-white text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          ♿ অসচ্ছল প্রতিবন্ধী ভাতা
        </button>

        <button
          onClick={() => { setAllowanceType('maternity'); setGender('female'); }}
          className={`p-4 rounded-3xl border-2 font-bold text-xs sm:text-sm transition cursor-pointer ${
            allowanceType === 'maternity'
              ? 'border-[#2D5A27] bg-[#D4E4BC]/30 text-[#2D5A27] shadow-xs'
              : 'border-[#E6E0D4] bg-white text-[#2D3A3A] hover:bg-[#FDFBF7]'
          }`}
        >
          🤱 মাতৃত্বকালীন ভাতা
        </button>
      </div>

      {/* Questions Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4">
          <h3 className="text-sm sm:text-base font-bold text-[#2D3A3A] border-b border-[#E6E0D4] pb-3 flex items-center gap-2 font-['Noto_Sans_Bengali']">
            <UserCheck className="w-4 h-4 text-[#2D5A27]" />
            <span>তথ্য প্রদান করুন:</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">লিঙ্গ:</label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setGender('male')}
                  className={`flex-1 py-2.5 rounded-2xl text-xs font-bold transition cursor-pointer ${
                    gender === 'male' ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FDFBF7] text-[#2D3A3A] border border-[#E6E0D4]'
                  }`}
                >
                  পুরুষ
                </button>
                <button
                  type="button"
                  onClick={() => setGender('female')}
                  className={`flex-1 py-2.5 rounded-2xl text-xs font-bold transition cursor-pointer ${
                    gender === 'female' ? 'bg-[#2D5A27] text-white shadow-xs' : 'bg-[#FDFBF7] text-[#2D3A3A] border border-[#E6E0D4]'
                  }`}
                >
                  মহিলা
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                বয়স (জাতীয় পরিচয়পত্র অনুযায়ী):
              </label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(parseInt(e.target.value) || 0)}
                className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] font-bold text-[#2D5A27]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
              বার্ষিক ব্যক্তিগত আয় (টাকা):
            </label>
            <input
              type="number"
              value={annualIncome}
              onChange={(e) => setAnnualIncome(parseInt(e.target.value) || 0)}
              className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
            />
          </div>

          <div className="space-y-2 pt-2 border-t border-[#E6E0D4]">
            <label className="flex items-center gap-2 text-xs text-[#2D3A3A] cursor-pointer">
              <input
                type="checkbox"
                checked={hasGovPension}
                onChange={(e) => setHasGovPension(e.target.checked)}
                className="w-4 h-4 text-[#2D5A27] accent-[#2D5A27] rounded"
              />
              <span>আমি বা আমার পরিবার কোনো সরকারি পেনশন গ্রহণ করি না</span>
            </label>

            {allowanceType === 'disability' && (
              <label className="flex items-center gap-2 text-xs text-[#2D3A3A] cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasDisabilityCard}
                  onChange={(e) => setHasDisabilityCard(e.target.checked)}
                  className="w-4 h-4 text-[#2D5A27] accent-[#2D5A27] rounded"
                />
                <span>আমার সুবর্ণ নাগরিক বা প্রতিবন্ধী সনদপত্র রয়েছে</span>
              </label>
            )}
          </div>
        </div>

        {/* Eligibility Result Box */}
        <div className="lg:col-span-5 bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <span className="text-[11px] font-bold text-[#736B5E] uppercase tracking-wider block">
              ফলাফল ও স্ট্যাটাস
            </span>

            <div className={`mt-3 p-4 rounded-2xl border ${
              result.eligible
                ? 'bg-[#D4E4BC]/40 border-[#2D5A27]/30 text-[#2D5A27]'
                : 'bg-[#FADBD8]/60 border-[#C0392B]/30 text-[#C0392B]'
            }`}>
              <div className="flex items-center gap-2 font-bold text-sm sm:text-base mb-1 font-['Noto_Sans_Bengali']">
                {result.eligible ? (
                  <>
                    <CheckCircle className="w-5 h-5 text-[#2D5A27] flex-shrink-0" />
                    <span>যোগ্যতা নিশ্চিত হয়েছে</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-5 h-5 text-[#C0392B] flex-shrink-0" />
                    <span>শর্তাবলীর অপূর্ণতা রয়েছে</span>
                  </>
                )}
              </div>

              <ul className="text-xs space-y-1 mt-2">
                {result.reasons.map((r, idx) => (
                  <li key={idx} className="leading-relaxed font-medium">• {r}</li>
                ))}
              </ul>
            </div>

            {result.eligible && (
              <div className="mt-4 p-3.5 bg-[#F9E5D4]/60 border border-[#F9E5D4] rounded-2xl text-xs">
                <span className="text-[#A65E2E] font-bold block mb-0.5">সরকারি ভাতার পরিমাণ:</span>
                <span className="text-[#2D5A27] font-bold text-sm font-['Noto_Sans_Bengali']">
                  {result.amount}
                </span>
              </div>
            )}
          </div>

          <div className="text-xs text-[#736B5E] border-t border-[#E6E0D4] pt-3">
            আবেদন করতে আপনার NID ও বিকাশ/নগদ নম্বর নিয়ে নিকটস্থ <strong>ইউনিয়ন পরিষদ ডিজিটাল সেন্টারে</strong> যোগাযোগ করুন।
          </div>
        </div>
      </div>
    </div>
  );
};
