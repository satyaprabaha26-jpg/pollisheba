import React, { useState } from 'react';
import { 
  Search, 
  FileText, 
  Clock, 
  CheckCircle2, 
  MapPin, 
  ExternalLink, 
  CreditCard
} from 'lucide-react';
import { CITIZEN_SERVICES_DATA } from '../../data/mockData';
import { CitizenServiceGuide } from '../../types';

export const CitizenServices: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('সকল সেবা');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedService, setSelectedService] = useState<CitizenServiceGuide | null>(CITIZEN_SERVICES_DATA[0]);

  const categories = ['সকল সেবা', 'সনদ ও প্রত্যয়ন', 'ভাতা ও সহায়তা', 'ভূমি সেবা'];

  const filteredServices = CITIZEN_SERVICES_DATA.filter((s) => {
    const matchesCat = selectedCategory === 'সকল সেবা' || s.category === selectedCategory;
    const matchesSearch = s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.requiredDocs.some(d => d.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
            🏛️ ইউনিয়ন পরিষদ ও ডিজিটাল সেন্টার
          </span>
          <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
            সরকারি নাগরিক সেবা ও সনদ প্রাপ্তির নির্দেশিকা
          </h2>
          <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
            নাগরিকত্ব সনদ, ওয়ারিশান সনদ, জন্ম নিবন্ধন, জমির ই-নামজারি ও সরকারি ভাতার নিয়মাবলী
          </p>
        </div>

        <div className="bg-[#23491E] border border-[#3D7A35] p-3.5 rounded-2xl text-xs text-[#D4E4BC]">
          <p className="font-bold text-[#F9E5D4]">জাতীয় তথ্য সেবা</p>
          <p className="text-xl font-bold text-white mt-0.5 font-['Noto_Sans_Bengali']">৩৩৩</p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full sm:w-auto pb-1 sm:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-2xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#2D5A27] text-white shadow-xs'
                  : 'bg-[#FDFBF7] text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-[#736B5E] absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="সেবার নাম লিখে খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
          />
        </div>
      </div>

      {/* Master-Detail Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left List */}
        <div className="lg:col-span-5 space-y-3 max-h-[600px] overflow-y-auto pr-1">
          {filteredServices.map((srv) => {
            const isSelected = selectedService?.id === srv.id;
            return (
              <div
                key={srv.id}
                onClick={() => setSelectedService(srv)}
                className={`p-5 rounded-3xl border transition cursor-pointer text-left ${
                  isSelected
                    ? 'bg-[#D4E4BC]/30 border-[#2D5A27] ring-2 ring-[#2D5A27]/20 shadow-xs'
                    : 'bg-white border-[#E6E0D4] hover:border-[#2D5A27]/50 hover:bg-[#FDFBF7]'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/60 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                    {srv.category}
                  </span>
                  <span className="text-xs text-[#736B5E] flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#A65E2E]" />
                    <span>{srv.deliveryTime}</span>
                  </span>
                </div>

                <h4 className="font-bold text-sm sm:text-base text-[#2D3A3A] mt-2 leading-snug font-['Noto_Sans_Bengali']">
                  {srv.title}
                </h4>

                <div className="mt-2.5 text-xs text-[#736B5E] flex items-center gap-1">
                  <CreditCard className="w-3.5 h-3.5 text-[#2D5A27]" />
                  <span>সরকারি ফি: <strong className="text-[#2D3A3A]">{srv.fee}</strong></span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Detail */}
        <div className="lg:col-span-7">
          {selectedService ? (
            <div className="bg-white border border-[#E6E0D4] rounded-3xl p-6 shadow-xs space-y-4 sticky top-36">
              <div className="border-b border-[#E6E0D4] pb-3">
                <span className="text-xs font-bold text-[#2D5A27] bg-[#D4E4BC] px-3 py-0.5 rounded-full">
                  {selectedService.category}
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-[#2D3A3A] mt-2 font-['Noto_Sans_Bengali']">
                  {selectedService.title}
                </h3>
              </div>

              {/* Quick Info Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#E6E0D4]">
                  <span className="text-[#736B5E] block mb-0.5">সরকারি নির্ধারিত ফি:</span>
                  <span className="font-bold text-[#2D5A27] text-sm">{selectedService.fee}</span>
                </div>
                <div className="bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#E6E0D4]">
                  <span className="text-[#736B5E] block mb-0.5">সেবা প্রদানের সর্বোচ্চ সময়:</span>
                  <span className="font-bold text-[#2D3A3A] text-sm">{selectedService.deliveryTime}</span>
                </div>
              </div>

              {/* Required Documents */}
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-[#2D3A3A] mb-2 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-[#2D5A27]" />
                  <span>আবেদনের প্রয়োজনীয় কাগজপত্র ও শর্তাবলী:</span>
                </h4>
                <ul className="space-y-1.5">
                  {selectedService.requiredDocs.map((doc, idx) => (
                    <li key={idx} className="text-xs sm:text-sm text-[#2D3A3A] bg-[#FDFBF7] p-2.5 rounded-2xl flex items-start gap-2 border border-[#E6E0D4]">
                      <span className="text-[#2D5A27] font-bold">•</span>
                      <span>{doc}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Step by Step */}
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-[#2D3A3A] mb-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#2D5A27]" />
                  <span>ধাপে ধাপে আবেদন প্রক্রিয়া:</span>
                </h4>
                <div className="space-y-2">
                  {selectedService.stepByStepGuide.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 bg-[#FDFBF7] p-2.5 rounded-2xl text-xs sm:text-sm text-[#2D3A3A] border border-[#E6E0D4]">
                      <span className="w-5 h-5 rounded-full bg-[#2D5A27] text-white font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Office Location & Online link */}
              <div className="bg-[#D4E4BC]/30 border border-[#D4E4BC] rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#2D5A27] flex-shrink-0" />
                  <span className="text-[#2D3A3A]"><strong>অফলাইন আবেদনের স্থান: </strong>{selectedService.offlinePlace}</span>
                </div>

                {selectedService.applicationUrl && (
                  <a
                    href={selectedService.applicationUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold px-3.5 py-1.5 rounded-2xl transition whitespace-nowrap shadow-xs"
                  >
                    <span>অনলাইন পোর্টাল</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center bg-white border border-[#E6E0D4] rounded-3xl text-[#736B5E] text-xs">
              তালিকা থেকে যেকোনো নাগরিক সেবা নির্বাচন করুন।
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
