import React, { useState } from 'react';
import { PhoneCall, Search } from 'lucide-react';
import { HOTLINES_DATA } from '../../data/mockData';
import { LocalEmergencyHub } from '../emergency/LocalEmergencyHub';
import { Prominent999Banner } from '../common/Prominent999Banner';

export const HotlinesDirectory: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('সকল হেল্পলাইন');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = ['সকল হেল্পলাইন', 'জরুরি', 'কৃষি', 'স্বাস্থ্য', 'নারী ও শিশু', 'সরকারি তথ্য', 'ইউটিলিটি ও ব্যাংক'];

  const filteredHotlines = HOTLINES_DATA.filter((h) => {
    const matchesCat = selectedCategory === 'সকল হেল্পলাইন' || h.category === selectedCategory;
    const matchesSearch = h.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.number.includes(searchQuery) ||
      h.shortCode.includes(searchQuery) ||
      h.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-[#2D5A27] text-white p-6 rounded-3xl shadow-sm">
        <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-xs px-3 py-0.5 rounded-full mb-2 inline-block">
          ☎️ সার্বক্ষণিক জরুরি সেবা ডিরেক্টরি
        </span>
        <h2 className="text-xl sm:text-2xl font-bold font-['Noto_Sans_Bengali']">
          জাতীয় জরুরি ও সরকারি হটলাইন নম্বরসমূহ
        </h2>
        <p className="text-[#D4E4BC] text-xs sm:text-sm mt-1">
          জরুরি পুলিশ, ফায়ার সার্ভিস, কৃষি পরামর্শ, স্বাস্থ্য বাতায়ন ও নারী-শিশু সুরক্ষায় সরাসরি কল করুন
        </p>
      </div>

      {/* Stylized Prominent 999 Hero Banner */}
      <Prominent999Banner />

      {/* Local Emergency Hub for District/Upazila Police & Fire Service */}
      <LocalEmergencyHub />

      {/* Filter and Search */}
      <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full sm:w-auto pb-1 sm:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-2xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#2D5A27] text-white shadow-xs'
                  : 'bg-[#FDFBF7] text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-[#736B5E] absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="হটলাইন বা বিষয়ের নাম খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 bg-[#FDFBF7] border border-[#E6E0D4] rounded-2xl text-xs sm:text-sm text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
          />
        </div>
      </div>

      {/* Hotlines Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredHotlines.map((item) => (
          <div
            key={item.id}
            className="bg-white border border-[#E6E0D4] hover:border-[#2D5A27] rounded-3xl p-5 shadow-xs transition hover:shadow-md flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/50 px-2.5 py-0.5 rounded-full border border-[#D4E4BC]">
                  {item.category}
                </span>

                <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                  item.isFree ? 'bg-[#D4E4BC] text-[#2D5A27]' : 'bg-[#FDFBF7] border border-[#E6E0D4] text-[#736B5E]'
                }`}>
                  {item.isFree ? 'টোল-ফ্রি (ফ্রি কল)' : 'নিয়মিত কলরেট'}
                </span>
              </div>

              <div className="flex items-center gap-3 my-2.5">
                <div className="w-12 h-12 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-extrabold text-xl font-['Noto_Sans_Bengali'] shadow-xs border border-[#2D5A27]/20 flex-shrink-0">
                  {item.shortCode}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-[#2D3A3A] leading-snug font-['Noto_Sans_Bengali']">
                    {item.name}
                  </h3>
                  <span className="text-[11px] text-[#736B5E] block mt-0.5">
                    সময়: {item.activeHours}
                  </span>
                </div>
              </div>

              <p className="text-xs text-[#5A6B6B] line-clamp-2 mt-2 leading-relaxed">
                {item.description}
              </p>
            </div>

            <div className="mt-4 pt-3.5 border-t border-[#E6E0D4]">
              <a
                href={`tel:${item.number}`}
                className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition cursor-pointer"
              >
                <PhoneCall className="w-4 h-4" />
                <span>সরাসরি কল করুন ({item.shortCode})</span>
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
