import React, { useState } from 'react';
import { 
  Bell, 
  MapPin, 
  Users, 
  PhoneCall, 
  Phone,
  X, 
  CheckCircle, 
  Clock, 
  AlertTriangle,
  Send,
  ArrowRight,
  ExternalLink,
  MessageSquare,
  Mic,
  Lock,
  ShieldCheck
} from 'lucide-react';
import { DemandNotification, isNotificationTargetedToUser } from '../lib/cloudSync';
import { UserProfile, USER_ROLES_LIST } from '../types/auth';
import { CallChoiceModal } from './transport/CallChoiceModal';
import { InAppVoiceCallModal } from './transport/InAppVoiceCallModal';
import { OfflineCallWarningModal } from './common/OfflineCallWarningModal';
import { VoiceChatModal } from './voice/VoiceChatModal';
import { ChatModal } from './chat/ChatModal';
import { maskPhoneNumber } from './transport/RuralTransport';

interface AreaAlertsModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: DemandNotification[];
  currentUser?: UserProfile | null;
  selectedDistrict: string;
  onNavigateToItem?: (notif: DemandNotification) => void;
  onStartChat?: (recipient: { recipientId: string; recipientName: string; recipientPhone?: string; itemTitle?: string }) => void;
}

export const AreaAlertsModal: React.FC<AreaAlertsModalProps> = ({
  isOpen,
  onClose,
  notifications,
  currentUser,
  selectedDistrict,
  onNavigateToItem,
  onStartChat
}) => {
  const [filterMode, setFilterMode] = useState<'targeted' | 'all'>('targeted');

  // Interactive Modals State
  const [activeCallChoice, setActiveCallChoice] = useState<{
    notif: DemandNotification;
  } | null>(null);

  const [activeInAppCall, setActiveInAppCall] = useState<{
    name: string;
    role: string;
    phone?: string;
    photo?: string;
    subtitle: string;
  } | null>(null);

  const [activeVoiceRecipient, setActiveVoiceRecipient] = useState<{
    name: string;
    role: string;
    phone?: string;
    avatar?: string;
    itemTitle: string;
  } | null>(null);

  const [offlineCallAlert, setOfflineCallAlert] = useState<string | null>(null);
  const [activeDirectOfflineCall, setActiveDirectOfflineCall] = useState<{
    phone: string;
    recipientName: string;
    recipientRole?: string;
  } | null>(null);
  const [internalChatTarget, setInternalChatTarget] = useState<{
    recipientId: string;
    recipientName: string;
    recipientRole?: string;
    recipientPhone?: string;
    itemTitle?: string;
  } | null>(null);

  if (!isOpen) return null;

  // Filter based on user profile (district, upazila, union, role, phone and blood donor status)
  const userDist = currentUser?.district || (selectedDistrict !== 'সকল জেলা' ? selectedDistrict : undefined);
  const userUpz = currentUser?.upazila;
  const userRole = currentUser?.role;
  const userUnion = currentUser?.union;
  const isDonor = currentUser?.isBloodDonor || !!currentUser?.bloodGroup;

  const targetedNotifications = notifications.filter((notif) => {
    return isNotificationTargetedToUser(notif, userDist, userUpz, userRole, userUnion, currentUser?.phone, isDonor);
  });

  const displayList = filterMode === 'targeted' ? targetedNotifications : notifications;

  return (
    <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-xl w-full max-h-[88vh] flex flex-col shadow-2xl border border-[#E6E0D4] overflow-hidden">
        {/* Header */}
        <div className="bg-[#2D5A27] text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-[#E8924A] rounded-2xl text-white shadow-xs">
              <Bell className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg leading-tight">
                এলাকাভিত্তিক জরুরি চাহিদা ও নোটিফিকেশন
              </h3>
              <p className="text-xs text-[#D4E4BC] mt-0.5">
                {selectedDistrict} জেলা {currentUser?.role ? `• ${USER_ROLES_LIST.find(r => r.id === currentUser.role)?.label || ''}` : ''}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/10 rounded-xl text-white/80 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Offline Call Disallowed Toast Alert */}
        {offlineCallAlert && (
          <div className="bg-amber-50 text-amber-900 border-b border-amber-200 px-4 py-2.5 text-xs font-bold flex items-center justify-between animate-in fade-in">
            <span>⚠️ {offlineCallAlert}</span>
            <button 
              onClick={() => setOfflineCallAlert(null)} 
              className="text-amber-700 hover:text-amber-950 font-bold px-2 py-0.5 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {/* Tab switcher */}
        <div className="flex items-center gap-2 px-4 py-2.5 bg-[#FAF8F5] border-b border-[#E6E0D4]">
          <button
            onClick={() => setFilterMode('targeted')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
              filterMode === 'targeted'
                ? 'bg-[#2D5A27] text-white shadow-xs'
                : 'bg-white text-[#5A6B6B] border border-[#E6E0D4]'
            }`}
          >
            <span>🎯 আমার এলাকার নোটিশ ({targetedNotifications.length})</span>
          </button>
          <button
            onClick={() => setFilterMode('all')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
              filterMode === 'all'
                ? 'bg-[#2D5A27] text-white shadow-xs'
                : 'bg-white text-[#5A6B6B] border border-[#E6E0D4]'
            }`}
          >
            <span>🌐 সকল নোটিশ ({notifications.length})</span>
          </button>
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {displayList.length === 0 ? (
            <div className="text-center py-12 px-4 space-y-3">
              <div className="w-14 h-14 bg-[#FAF8F5] rounded-full flex items-center justify-center mx-auto border border-[#E6E0D4]">
                <Bell className="w-7 h-7 text-gray-300" />
              </div>
              <p className="font-bold text-sm text-[#2D3A3A]">
                {filterMode === 'targeted' 
                  ? 'আপনার এলাকায় এই মুহূর্তে কোনো জরুরি চাহিদা বা নোটিশ নেই' 
                  : 'এখনও কোনো নোটিফিকেশন পাওয়া যায়নি'}
              </p>
              <p className="text-xs text-[#736B5E] max-w-xs mx-auto">
                যখনই আপনার এলাকায় কোনো কৃষি শ্রমিক, গাড়ি, বা কৃষকদের জন্য জরুরি বার্তা আসবে, তা এখানে সাথে সাথে দৃশ্যমান হবে।
              </p>
            </div>
          ) : (
            displayList.map((notif) => {
              const honorificRoleName = (() => {
                const tr = notif.targetRole?.toLowerCase().trim();
                if (tr === 'driver') return '🚗 সম্মানিত চালক';
                if (tr === 'agri_machinery_driver' || tr === 'tractor' || tr === 'excavator' || tr === 'agri_machinery') return '🚜 সম্মানিত ট্র্যাক্টর / হেস্কোভেটর / কৃষিযন্ত্র চালক';
                if (tr === 'boatman' || tr === 'boat' || tr === 'ferry_driver') return '⛵ সম্মানিত নৌকার মাঝি / খেয়া চালক';
                if (tr === 'mechanic' || tr === 'electrician') return '🔧 সম্মানিত ইলেকট্রিশিয়ান ও মেকার';
                if (tr === 'laborer' || tr === 'worker') return '🌾 সম্মানিত কৃষাণ ও দিনমজুর';
                if (tr === 'tutor' || tr === 'teacher' || tr === 'tutor_student') return '📚 সম্মানিত শিক্ষক / ছাত্র-ছাত্রী';
                if (tr === 'farmer') return '🌱 সম্মানিত কৃষক ও খামারি';
                return '👥 স্থানীয় সম্মানিত সকল নাগরিক ও ক্রেতা';
              })();

              return (
                <div
                  key={notif.id}
                  className="bg-white rounded-2xl p-4 border border-[#E6E0D4] shadow-xs space-y-2.5 transition hover:border-[#2D5A27]"
                >
                  <div className="flex items-center justify-between gap-2 flex-wrap border-b border-[#FAF8F5] pb-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        notif.categoryName === 'মিসড কল'
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : notif.targetRole === 'blood_donor' || notif.categoryName === 'জরুরি রক্তসেবা'
                          ? 'bg-red-600 text-white shadow-2xs'
                          : notif.urgency === 'জরুরি'
                          ? 'bg-red-100 text-red-800 border border-red-300'
                          : notif.urgency === 'সতর্কবার্তা'
                          ? 'bg-amber-100 text-amber-800 border border-amber-300'
                          : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      }`}>
                        {notif.categoryName === 'মিসড কল'
                          ? '📞 মিসড কল'
                          : notif.targetRole === 'blood_donor' || notif.categoryName === 'জরুরি রক্তসেবা'
                          ? '🩸 জরুরি রক্তের ডাক'
                          : notif.urgency === 'জরুরি' 
                          ? '🚨 জরুরি' 
                          : notif.urgency === 'সতর্কবার্তা' 
                          ? '⚠️ সতর্কতা' 
                          : '📢 সাধারণ বিজ্ঞপ্তি'}
                      </span>

                      <span className="text-[11px] font-semibold text-[#2D5A27] bg-[#D4E4BC]/50 px-2 py-0.5 rounded-md flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        <span>{notif.targetDistrict}</span>
                        {notif.targetUpazila && notif.targetUpazila !== 'সকল উপজেলা' && (
                          <span>({notif.targetUpazila})</span>
                        )}
                        {notif.targetUnion && (
                          <span className="text-[10px] bg-white/90 px-1.5 py-0.2 rounded border border-[#2D5A27]/20 font-medium">
                            {notif.targetUnion}
                          </span>
                        )}
                      </span>
                    </div>

                    <span className="text-[10px] text-[#736B5E] flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{notif.createdAtFormatted || 'সাম্প্রতিক'}</span>
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-sm text-[#2D3A3A] leading-snug">
                      {notif.title}
                    </h4>
                    <p className="text-xs text-[#5A6B6B] mt-1 whitespace-pre-wrap leading-relaxed">
                      {notif.message}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-[#FAF8F5] flex items-center justify-between text-xs gap-2 flex-wrap">
                    <div className="flex items-center gap-2 flex-wrap">
                      <div className="text-[11px] text-[#736B5E]">
                        <span>প্রেরক: </span>
                        <strong className="text-[#2D3A3A]">{notif.senderName || 'এলাকাবাসী'}</strong>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                        notif.allowOfflineCall 
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                          : 'bg-amber-100 text-amber-800 border border-amber-200'
                      }`}>
                        {notif.allowOfflineCall ? (
                          <>
                            <Phone className="w-2.5 h-2.5" />
                            <span>অফলাইন কল চালু</span>
                          </>
                        ) : (
                          <>
                            <Lock className="w-2.5 h-2.5" />
                            <span>অনলাইন সুরক্ষিত</span>
                          </>
                        )}
                      </span>
                    </div>

                    {/* Action Buttons: Free Call, Offline Call, Text Message, Voice Message, Details */}
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {/* 1. Free In-App Online Call */}
                      <button
                        type="button"
                        onClick={() => {
                          setActiveInAppCall({
                            name: notif.senderName || 'বিজ্ঞাপনদাতা',
                            role: notif.targetRole || 'requester',
                            phone: notif.contactNumber,
                            photo: notif.senderAvatar,
                            subtitle: notif.title
                          });
                        }}
                        className="px-2.5 py-1.5 bg-[#D4E4BC] hover:bg-[#2D5A27] text-[#2D5A27] hover:text-white rounded-xl font-bold flex items-center gap-1 shadow-2xs transition cursor-pointer text-xs"
                        title="ফ্রি ইন-অ্যাপ অনলাইন কল"
                      >
                        <PhoneCall className="w-3 h-3" />
                        <span>অনলাইন কল</span>
                      </button>

                      {/* 2. Offline SIM Call with Direct Action & Guard */}
                      <button
                        type="button"
                        onClick={() => {
                          const contactNum = notif.contactNumber || (notif.senderUserId && notif.senderUserId.match(/^01[3-9]\d{8}$/) ? notif.senderUserId : '');
                          if (notif.allowOfflineCall === false) {
                            setOfflineCallAlert("দুঃখিত! এই বিজ্ঞাপনদাতা তাঁর অফলাইন সাধারণ সিম কল অপশন বন্ধ রেখেছেন। গোপনীয়তা সুরক্ষার্থে আপনি শুধুমাত্র 'অনলাইন কল' অথবা 'লিখিত মেসেজ' বা 'ভয়েস মেসেজ' পাঠাতে পারবেন।");
                            setTimeout(() => setOfflineCallAlert(null), 6000);
                          } else if (!contactNum) {
                            setOfflineCallAlert("এই বিজ্ঞাপনে কোনো সরাসরি মোবাইল নম্বর পাওয়া যায়নি। অনুগ্রহ করে 'অনলাইন কল' বা 'লিখিত মেসেজ' ব্যবহার করুন।");
                            setTimeout(() => setOfflineCallAlert(null), 5000);
                          } else {
                            setActiveDirectOfflineCall({
                              phone: contactNum,
                              recipientName: notif.senderName || 'বিজ্ঞাপনদাতা',
                              recipientRole: notif.targetRole || 'requester'
                            });
                          }
                        }}
                        className={`px-2.5 py-1.5 rounded-xl font-bold flex items-center gap-1 shadow-2xs transition cursor-pointer text-xs ${
                          notif.allowOfflineCall === false
                            ? 'bg-gray-100 hover:bg-gray-200 text-gray-700 border border-gray-300'
                            : 'bg-[#2D5A27] hover:bg-[#23491E] text-white'
                        }`}
                        title={notif.allowOfflineCall === false ? 'অফলাইন কল অনুমতি বন্ধ' : 'অফলাইন সাধারণ মোবাইল কল'}
                      >
                        <Phone className="w-3 h-3" />
                        <span>অফলাইন কল</span>
                      </button>

                      {/* 3. Written Text Message / Chat */}
                      <button
                        type="button"
                        onClick={() => {
                          const chatParams = {
                            recipientId: notif.senderUserId || notif.itemId || notif.id,
                            recipientName: notif.senderName || 'বিজ্ঞাপনদাতা',
                            recipientPhone: notif.contactNumber || '',
                            itemTitle: notif.title
                          };
                          if (onStartChat) {
                            onStartChat(chatParams);
                            onClose();
                          } else {
                            setInternalChatTarget(chatParams);
                          }
                        }}
                        className="px-2.5 py-1.5 bg-white hover:bg-emerald-50 text-[#2D5A27] border-2 border-[#2D5A27] rounded-xl font-bold flex items-center gap-1 shadow-2xs transition cursor-pointer text-xs"
                        title="লিখিত মেসেজ / চ্যাট করুন"
                      >
                        <MessageSquare className="w-3 h-3 text-[#2D5A27]" />
                        <span>লিখিত মেসেজ</span>
                      </button>

                      {/* 4. Voice Note */}
                      <button
                        type="button"
                        onClick={() => {
                          setActiveVoiceRecipient({
                            name: notif.senderName || 'বিজ্ঞাপনদাতা',
                            role: notif.targetRole || 'requester',
                            phone: notif.contactNumber,
                            avatar: notif.senderAvatar,
                            itemTitle: notif.title
                          });
                        }}
                        className="px-2.5 py-1.5 bg-[#FAF8F5] hover:bg-[#F3EFE6] text-[#2D3A3A] border border-[#E6E0D4] hover:border-[#2D5A27] rounded-xl font-bold flex items-center gap-1 shadow-2xs transition cursor-pointer text-xs"
                        title="ভয়েস বার্তা পাঠান"
                      >
                        <Mic className="w-3 h-3 text-[#2D5A27]" />
                        <span>ভয়েস মেসেজ</span>
                      </button>

                      {/* 5. View Full Details */}
                      {onNavigateToItem && notif.targetCategory && (
                        <button
                          type="button"
                          onClick={() => onNavigateToItem(notif)}
                          className="px-2.5 py-1.5 bg-white hover:bg-gray-50 text-[#5A6B6B] border border-[#D4C3A3] rounded-xl font-bold flex items-center gap-1 shadow-2xs transition cursor-pointer text-xs"
                        >
                          <span>বিস্তারিত</span>
                          <ArrowRight className="w-3 h-3 text-[#E8924A]" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#FAF8F5] border-t border-[#E6E0D4] text-center">
          <p className="text-[11px] text-[#736B5E]">
            🛡️ এলাকাভিত্তিক পুশ অ্যালার্ট ও বিশ্বস্ত নাগরিক সংযোগ • পল্লী সেবা প্ল্যাটফর্ম
          </p>
        </div>
      </div>

      {/* Call Choice Modal for Selected Notification */}
      {activeCallChoice && (
        <CallChoiceModal
          recipientName={activeCallChoice.notif.senderName || 'বিজ্ঞাপনদাতা'}
          recipientRole={activeCallChoice.notif.targetRole || 'requester'}
          recipientPhoto={activeCallChoice.notif.senderAvatar}
          recipientSubtitle={activeCallChoice.notif.title}
          rawPhone={activeCallChoice.notif.contactNumber || ''}
          allowOfflineCall={activeCallChoice.notif.allowOfflineCall ?? false}
          onSelectInAppCall={() => {
            const notif = activeCallChoice.notif;
            setActiveCallChoice(null);
            setActiveInAppCall({
              name: notif.senderName || 'বিজ্ঞাপনদাতা',
              role: notif.targetRole || 'requester',
              phone: notif.contactNumber,
              photo: notif.senderAvatar,
              subtitle: notif.title
            });
          }}
          onOpenChat={() => {
            const notif = activeCallChoice.notif;
            const chatParams = {
              recipientId: notif.senderUserId || notif.itemId || notif.id,
              recipientName: notif.senderName || 'বিজ্ঞাপনদাতা',
              recipientPhone: notif.contactNumber || '',
              itemTitle: notif.title
            };
            setActiveCallChoice(null);
            if (onStartChat) {
              onStartChat(chatParams);
              onClose();
            } else {
              setInternalChatTarget(chatParams);
            }
          }}
          onOpenVoiceNote={() => {
            const notif = activeCallChoice.notif;
            setActiveCallChoice(null);
            setActiveVoiceRecipient({
              name: notif.senderName || 'বিজ্ঞাপনদাতা',
              role: notif.targetRole || 'requester',
              phone: notif.contactNumber,
              avatar: notif.senderAvatar,
              itemTitle: notif.title
            });
          }}
          onClose={() => setActiveCallChoice(null)}
        />
      )}

      {/* In-App Voice Call Screen */}
      {activeInAppCall && (
        <InAppVoiceCallModal
          recipientName={activeInAppCall.name}
          recipientRole={activeInAppCall.role}
          recipientPhoto={activeInAppCall.photo}
          recipientSubtitle={activeInAppCall.subtitle}
          maskedPhone={maskPhoneNumber(activeInAppCall.phone || '')}
          rawPhone={activeInAppCall.phone}
          currentUser={currentUser}
          onClose={() => setActiveInAppCall(null)}
        />
      )}

      {/* In-App Voice Message Modal */}
      {activeVoiceRecipient && (
        <VoiceChatModal
          isOpen={true}
          onClose={() => setActiveVoiceRecipient(null)}
          recipientName={activeVoiceRecipient.name}
          recipientRole={activeVoiceRecipient.role}
          recipientPhone={activeVoiceRecipient.phone}
          recipientAvatar={activeVoiceRecipient.avatar}
          itemTitle={activeVoiceRecipient.itemTitle}
          currentUser={currentUser || null}
          onSendVoiceMessage={(audioUrl, duration, textSummary) => {
            setActiveVoiceRecipient(null);
          }}
        />
      )}

      {/* Direct In-App Text Chat Modal (Fallback if onStartChat not provided) */}
      {internalChatTarget && (
        <ChatModal
          isOpen={true}
          onClose={() => setInternalChatTarget(null)}
          currentUser={currentUser || null}
          recipientId={internalChatTarget.recipientId}
          recipientName={internalChatTarget.recipientName}
          recipientRole={internalChatTarget.recipientRole}
          recipientPhone={internalChatTarget.recipientPhone}
          itemTitle={internalChatTarget.itemTitle}
          onOpenAuth={() => {}}
        />
      )}

      {/* Offline SIM Call Warning Modal */}
      {activeDirectOfflineCall && (
        <OfflineCallWarningModal
          isOpen={true}
          phoneNumber={activeDirectOfflineCall.phone}
          recipientName={activeDirectOfflineCall.recipientName}
          recipientRole={activeDirectOfflineCall.recipientRole}
          onProceedOfflineCall={() => {
            const clean = activeDirectOfflineCall.phone.replace(/[^0-9+]/g, '');
            setActiveDirectOfflineCall(null);
            if (clean) {
              window.location.href = `tel:${clean}`;
            }
          }}
          onOnlineVoiceCall={() => {
            const phone = activeDirectOfflineCall.phone;
            const name = activeDirectOfflineCall.recipientName;
            const role = activeDirectOfflineCall.recipientRole;
            setActiveDirectOfflineCall(null);
            setActiveInAppCall({
              name,
              role: role || 'requester',
              phone,
              subtitle: 'নোটিফিকেশন থেকে সরাসরি কল'
            });
          }}
          onOpenOnlineChat={() => {
            const phone = activeDirectOfflineCall.phone;
            const name = activeDirectOfflineCall.recipientName;
            setActiveDirectOfflineCall(null);
            const chatParams = {
              recipientId: phone.replace(/[^0-9]/g, ''),
              recipientName: name,
              recipientPhone: phone,
              itemTitle: 'জরুরি নোটিফিকেশন যোগাযোগ'
            };
            if (onStartChat) {
              onStartChat(chatParams);
              onClose();
            } else {
              setInternalChatTarget(chatParams);
            }
          }}
          onCancel={() => setActiveDirectOfflineCall(null)}
        />
      )}
    </div>
  );
};
