import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  ExternalLink, 
  PhoneCall, 
  Volume2, 
  VolumeX, 
  Play, 
  Pause, 
  BadgePercent,
  ChevronLeft,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { AdBanner } from '../../types';
import { INITIAL_AD_BANNERS } from '../../data/extendedData';
import { OfflineCallWarningModal } from './OfflineCallWarningModal';
import { subscribeToAdBanners } from '../../lib/cloudSync';

interface DynamicAdSectionProps {
  placement: 'home_weather_bottom' | 'marketplace_top' | 'transport_middle' | 'all';
  district: string;
  className?: string;
}

export const DynamicAdSection: React.FC<DynamicAdSectionProps> = ({
  placement,
  district,
  className = ''
}) => {
  const [ads, setAds] = useState<AdBanner[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [isVideoPlaying, setIsVideoPlaying] = useState<boolean>(true);
  
  // Call warning modal state
  const [callModalOpen, setCallModalOpen] = useState<boolean>(false);
  const [activeCallNumber, setActiveCallNumber] = useState<string>('');
  const [activeSponsorName, setActiveSponsorName] = useState<string>('');

  useEffect(() => {
    const unsubscribe = subscribeToAdBanners((allAds) => {
      // Filter active and matching placement + district
      const filtered = allAds.filter(ad => {
        if (!ad.isActive) return false;
        const matchesPlacement = placement === 'all' || ad.placement === placement || ad.placement === 'all';
        const matchesDistrict = ad.districtTarget === 'সকল জেলা' || !ad.districtTarget || ad.districtTarget === district;
        return matchesPlacement && matchesDistrict;
      });

      setAds(filtered.length > 0 ? filtered : allAds.filter(a => a.isActive));
    });

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [placement, district]);

  // Auto slide if multiple ads
  useEffect(() => {
    if (ads.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % ads.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [ads.length]);

  if (ads.length === 0) return null;

  const currentAd = ads[currentIndex] || ads[0];

  const handleTrackClick = (ad: AdBanner) => {
    try {
      const saved = localStorage.getItem('polli_ad_banners');
      const allAds: AdBanner[] = saved ? JSON.parse(saved) : INITIAL_AD_BANNERS;
      const updated = allAds.map(a => a.id === ad.id ? { ...a, clicksCount: (a.clicksCount || 0) + 1 } : a);
      localStorage.setItem('polli_ad_banners', JSON.stringify(updated));
    } catch (e) {}
  };

  const handleCallClick = (e: React.MouseEvent, phone: string, sponsorName: string) => {
    e.stopPropagation();
    setActiveCallNumber(phone);
    setActiveSponsorName(sponsorName);
    setCallModalOpen(true);
  };

  const handleProceedCall = () => {
    if (activeCallNumber) {
      window.location.href = `tel:${activeCallNumber}`;
    }
    setCallModalOpen(false);
  };

  return (
    <div className={`w-full font-['Noto_Sans_Bengali'] ${className}`}>
      <div className="bg-white rounded-3xl border border-[#E6E0D4] p-4 sm:p-5 shadow-xs relative overflow-hidden group hover:shadow-md transition-all">
        
        {/* Top Header Row with Sponsored Tag */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 bg-[#FAF8F5] text-[#A65E2E] text-[10px] sm:text-[11px] font-extrabold px-2.5 py-0.5 rounded-full border border-[#D4C3A3]">
              <Sparkles className="w-3 h-3 text-[#E8924A]" />
              <span>বিজ্ঞাপন • Sponsored</span>
            </span>
            {currentAd.badgeText && (
              <span className="bg-[#D4E4BC] text-[#2D5A27] text-[10px] font-bold px-2 py-0.5 rounded-full">
                {currentAd.badgeText}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5">
            {ads.length > 1 && (
              <div className="flex items-center gap-1 text-[10px] text-[#736B5E] mr-1">
                <span>{currentIndex + 1}/{ads.length}</span>
                <button
                  onClick={() => setCurrentIndex((prev) => (prev === 0 ? ads.length - 1 : prev - 1))}
                  className="p-1 rounded-lg hover:bg-[#FAF8F5] text-[#736B5E] cursor-pointer"
                  title="পূর্ববর্তী বিজ্ঞাপন"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setCurrentIndex((prev) => (prev + 1) % ads.length)}
                  className="p-1 rounded-lg hover:bg-[#FAF8F5] text-[#736B5E] cursor-pointer"
                  title="পরবর্তী বিজ্ঞাপন"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
            <span className="text-[10px] text-[#736B5E]/80 hidden sm:inline">
              এলাকা: {currentAd.districtTarget || 'সমগ্র বাংলাদেশ'}
            </span>
          </div>
        </div>

        {/* Ad Media & Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          
          {/* Media Player / Image / 3D GIF */}
          <div className="md:col-span-5 relative rounded-2xl overflow-hidden bg-black/5 aspect-video md:aspect-[4/3] flex items-center justify-center border border-[#E6E0D4] group-hover:border-[#2D5A27]/40 transition">
            {currentAd.adType === 'video' ? (
              <div className="relative w-full h-full">
                <video
                  src={currentAd.mediaUrl}
                  autoPlay
                  loop
                  muted={isMuted}
                  playsInline
                  className="w-full h-full object-cover"
                />
                {/* Video controls overlay */}
                <div className="absolute bottom-2 right-2 flex items-center gap-1 bg-black/60 backdrop-blur-xs p-1 rounded-xl text-white">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsMuted(!isMuted);
                    }}
                    className="p-1 hover:text-[#E8924A] transition cursor-pointer"
                    title={isMuted ? 'সাউন্ড অন করুন' : 'মিউট করুন'}
                  >
                    {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="absolute top-2 left-2 bg-black/60 text-white text-[9px] font-bold px-2 py-0.5 rounded-md backdrop-blur-xs flex items-center gap-1">
                  <span>🎥 3D Video</span>
                </div>
              </div>
            ) : currentAd.adType === 'gif_3d' ? (
              <div className="relative w-full h-full">
                <img
                  src={currentAd.mediaUrl}
                  alt={currentAd.title}
                  className="w-full h-full object-cover transform group-hover:scale-103 transition duration-500"
                />
                <div className="absolute top-2 left-2 bg-[#2D5A27]/85 text-[#D4E4BC] text-[9px] font-bold px-2 py-0.5 rounded-md backdrop-blur-xs flex items-center gap-1">
                  <span>✨ 3D অ্যানিমেশন</span>
                </div>
              </div>
            ) : (
              <img
                src={currentAd.mediaUrl}
                alt={currentAd.title}
                className="w-full h-full object-cover group-hover:scale-102 transition duration-500"
              />
            )}
          </div>

          {/* Ad Copy & Action Buttons */}
          <div className="md:col-span-7 space-y-2.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs text-[#2D5A27] font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#27AE60]" />
                  <span>{currentAd.sponsorName}</span>
                </span>
              </div>
              <h4 className="text-base sm:text-lg font-bold text-[#2D3A3A] leading-snug group-hover:text-[#2D5A27] transition">
                {currentAd.title}
              </h4>
              {currentAd.description && (
                <p className="text-xs sm:text-sm text-[#5A6B6B] leading-relaxed line-clamp-2">
                  {currentAd.description}
                </p>
              )}
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              {currentAd.targetUrl && (
                <a
                  href={currentAd.targetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => handleTrackClick(currentAd)}
                  className="flex items-center gap-1.5 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs transition cursor-pointer"
                >
                  <span>বিস্তারিত অফার দেখুন</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}

              {currentAd.callNumber && (
                <button
                  onClick={(e) => handleCallClick(e, currentAd.callNumber!, currentAd.sponsorName)}
                  className="flex items-center gap-1.5 bg-[#FAF8F5] hover:bg-[#F9E5D4] text-[#A65E2E] border border-[#D4C3A3] font-bold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>সরাসরি কল দিন</span>
                </button>
              )}
            </div>
          </div>

        </div>

      </div>

      {/* Offline Call Warning Modal Integration */}
      <OfflineCallWarningModal
        isOpen={callModalOpen}
        phoneNumber={activeCallNumber}
        recipientName={activeSponsorName}
        onProceed={handleProceedCall}
        onCancel={() => setCallModalOpen(false)}
      />
    </div>
  );
};
