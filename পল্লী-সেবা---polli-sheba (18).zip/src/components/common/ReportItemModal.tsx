import React, { useState } from 'react';
import { AlertTriangle, X, Check, ShieldAlert, Flag } from 'lucide-react';
import { UserProfile } from '../../types/auth';
import { ReportItemRecord } from '../../types';
import { saveCloudCitizenReport } from '../../lib/cloudSync';

export type { ReportItemRecord };

interface ReportItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetId: string;
  targetTitle: string;
  targetType: 'listing' | 'driver' | 'passenger' | 'review' | 'other' | 'user';
  currentUser?: UserProfile | null;
}

export const ReportItemModal: React.FC<ReportItemModalProps> = ({
  isOpen,
  onClose,
  targetId,
  targetTitle,
  targetType,
  currentUser
}) => {
  const [reason, setReason] = useState<string>('ভুয়া অ্যাকাউন্ট বা পরিচয় ভাঁড়ামি');
  const [details, setDetails] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!details.trim()) return;

    const newReport: ReportItemRecord = {
      id: `rep-${Date.now()}`,
      targetId,
      targetTitle,
      targetType,
      reporterName: currentUser?.name || 'নাগরিক',
      reporterPhone: currentUser?.phone || '০১৭xxxxxxxx',
      reason,
      details: details.trim(),
      status: 'নতুন',
      createdAt: new Date().toLocaleDateString('bn-BD'),
      createdAtTimestamp: Date.now()
    };

    const savedReports = JSON.parse(localStorage.getItem('polli_reports_list') || '[]');
    localStorage.setItem('polli_reports_list', JSON.stringify([newReport, ...savedReports]));
    await saveCloudCitizenReport(newReport);

    setIsSubmitted(true);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali']">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] animate-in fade-in zoom-in-95 duration-150 relative">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#736B5E] hover:text-[#2D3A3A] p-1.5 rounded-full hover:bg-gray-100 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {isSubmitted ? (
          <div className="text-center py-6 space-y-3">
            <div className="w-14 h-14 bg-[#D4E4BC] text-[#2D5A27] rounded-full flex items-center justify-center mx-auto">
              <Check className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-lg text-[#2D3A3A]">অভিযোগটি সফলভাবে অ্যাডমিন প্যানেলে পাঠানো হয়েছে</h4>
            <p className="text-xs text-[#736B5E]">আমরা দ্রুত তথ্যটি যাচাই করে প্রয়োজনীয় ব্যবস্থা গ্রহণ করব। প্ল্যাটফর্ম পরিচ্ছন্ন রাখতে সহায়তার জন্য ধন্যবাদ।</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-10 h-10 rounded-2xl bg-red-50 text-[#C0392B] flex items-center justify-center">
                <Flag className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-base text-[#2D3A3A]">অসংগতি বা প্রতারণার রিপোর্ট</h4>
                <p className="text-xs text-[#736B5E] truncate max-w-[240px] font-medium">{targetTitle}</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                রিপোর্টের কারণ নির্বাচন করুন:
              </label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold focus:outline-none focus:border-[#C0392B]"
              >
                <option value="ভুয়া অ্যাকাউন্ট বা পরিচয় ভাঁড়ামি">ভুয়া অ্যাকাউন্ট বা পরিচয় ভাঁড়ামি (Fake Profile)</option>
                <option value="ভুল বা বিভ্রান্তিকর তথ্য">ভুল বা বিভ্রান্তিকর তথ্য (Misleading Info)</option>
                <option value="অতিরিক্ত অযৌক্তিক দাম বা ভাড়া দাবি">অতিরিক্ত অযৌক্তিক দাম বা ভাড়া দাবি</option>
                <option value="ভুয়া ফোন নম্বর বা ফেক প্রোফাইল">ভুয়া ফোন নম্বর বা ফেক প্রোফাইল</option>
                <option value="মেয়াদোত্তীর্ণ বা বিক্রি হয়ে যাওয়া পণ্য">মেয়াদোত্তীর্ণ বা বিক্রি হয়ে যাওয়া পণ্য</option>
                <option value="অশোভন বা আপত্তিকর আচরণ">অশোভন বা আপত্তিকর আচরণ</option>
                <option value="অন্যান্য প্রতারণামূলক সন্দেহ">অন্যান্য প্রতারণামূলক সন্দেহ</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                বিস্তারিত বিবরণ লিখুন: <span className="text-red-500">*</span>
              </label>
              <textarea
                required
                rows={3}
                placeholder="সমস্যার সুনির্দিষ্ট কারণ বা কী ঘটেছে লিখুন..."
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                className="w-full bg-[#FAF8F5] border border-[#D4C3A3] focus:border-[#C0392B] rounded-xl p-3 text-xs text-[#2D3A3A] focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-[#FAF8F5] border border-[#E6E0D4] cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                className="px-6 py-2 rounded-2xl text-xs font-bold text-white bg-[#C0392B] hover:bg-[#A93226] shadow-xs cursor-pointer"
              >
                রিপোর্ট জমা দিন
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
