import React, { useState } from 'react';
import { Star, X, CheckCircle, ShieldCheck, Heart, ThumbsUp } from 'lucide-react';
import { ServiceReview } from '../../types';
import { UserProfile } from '../../types/auth';

interface TwoWayReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetId: string;
  targetName: string;
  targetRole: string; // 'driver' | 'passenger' | 'seller' | 'buyer' | 'laborer'
  serviceType: string; // 'transport' | 'haat' | 'labor' | 'general'
  currentUser: UserProfile | null;
  onReviewSubmitted?: (review: ServiceReview) => void;
}

const PRESET_TAGS_FOR_PROVIDER = [
  'সময়মতো এসেছেন',
  'ভদ্র ও বিনয়ী ব্যবহার',
  'ন্যায্য ভাড়া / মূল্য',
  'নির্ভরযোগ্য সেবা',
  'নিরাপদ ড্রাইভিং',
  'সততা ও বিশ্বস্ততা'
];

const PRESET_TAGS_FOR_USER = [
  'সময়মতো উপস্থিত ছিলেন',
  'ভদ্র ব্যবহার',
  'সঠিকভাবে ভাড়া পরিশোধ করেছেন',
  'সম্মান প্রদর্শন করেছেন',
  'সহযোগিতাপূর্ণ যাত্রী'
];

export const TwoWayReviewModal: React.FC<TwoWayReviewModalProps> = ({
  isOpen,
  onClose,
  targetId,
  targetName,
  targetRole,
  serviceType,
  currentUser,
  onReviewSubmitted
}) => {
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [comment, setComment] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const isRatingUser = targetRole === 'passenger' || targetRole === 'buyer' || targetRole === 'user';
  const tagList = isRatingUser ? PRESET_TAGS_FOR_USER : PRESET_TAGS_FOR_PROVIDER;

  const toggleTag = (tag: string) => {
    setSelectedTags(prev => 
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  const getRatingLabel = (stars: number) => {
    switch (stars) {
      case 5: return '⭐⭐⭐⭐⭐ অসাধারণ সেবা!';
      case 4: return '⭐⭐⭐⭐ খুব ভালো';
      case 3: return '⭐⭐⭐ চলনসই / সন্তোষজনক';
      case 2: return '⭐⭐ উন্নতির প্রয়োজন';
      case 1: return '⭐ হতাশাজনক / সমস্যা হয়েছে';
      default: return '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) return;

    setIsSubmitting(true);

    const newReview: ServiceReview = {
      id: `rev-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      targetId,
      targetName,
      targetRole,
      authorId: currentUser?.phone || currentUser?.id || 'guest-user',
      authorName: currentUser?.name || 'সম্মানিত ব্যবহারকারী',
      authorRole: currentUser?.role || (isRatingUser ? 'provider' : 'passenger'),
      rating,
      comment: comment.trim(),
      tags: selectedTags,
      createdAt: Date.now(),
      serviceType
    };

    try {
      const stored = localStorage.getItem('polli_service_reviews');
      const reviews: ServiceReview[] = stored ? JSON.parse(stored) : [];
      reviews.unshift(newReview);
      localStorage.setItem('polli_service_reviews', JSON.stringify(reviews));

      window.dispatchEvent(new CustomEvent('polli_review_submitted', { detail: newReview }));

      if (onReviewSubmitted) {
        onReviewSubmitted(newReview);
      }

      setSuccessMsg('আপনার মূল্যবান রিভিউ ও রেটিং সফলভাবে জমা হয়েছে!');
      setTimeout(() => {
        setIsSubmitting(false);
        setSuccessMsg('');
        onClose();
      }, 1500);
    } catch (err) {
      console.error(err);
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center shadow-xs">
              <Star className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#2D3A3A]">
                {isRatingUser ? 'যাত্রী / ক্রেতাকে রেটিং দিন' : 'সেবাদাতাকে রেটিং ও রিভিউ দিন'}
              </h3>
              <p className="text-xs text-[#736B5E]">দ্বিপাক্ষিক রেটিংয়ের মাধ্যমে গ্রামীণ আস্থা গড়ে তুলুন</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 text-[#736B5E] hover:text-[#2D3A3A] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {successMsg ? (
          <div className="p-6 bg-[#E8F8F5] border border-[#27AE60] rounded-2xl text-center space-y-2.5">
            <CheckCircle className="w-10 h-10 text-[#27AE60] mx-auto animate-bounce" />
            <h4 className="text-sm font-bold text-[#1E8449]">{successMsg}</h4>
            <p className="text-xs text-[#5A6B6B]">পল্লী সেবা সম্প্রদায়ে স্বচ্ছতা বজায় রাখায় ধন্যবাদ।</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Target Card */}
            <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] flex items-center justify-between">
              <div>
                <span className="text-[11px] text-[#736B5E] block">মূল্যায়ন করছেন:</span>
                <span className="font-bold text-sm text-[#2D3A3A]">{targetName}</span>
              </div>
              <span className="text-[11px] bg-[#D4E4BC] text-[#2D5A27] font-bold px-2 py-0.5 rounded-full">
                {targetRole === 'driver' ? 'চালক' : targetRole === 'passenger' ? 'যাত্রী' : targetRole === 'seller' ? 'বিক্রেতা' : 'নাগরিক'}
              </span>
            </div>

            {/* Interactive Star Rating */}
            <div className="text-center py-2 space-y-1.5">
              <span className="text-xs font-bold text-[#736B5E] block">স্টার রেটিং নির্বাচন করুন:</span>
              <div className="flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => {
                  const active = (hoverRating || rating) >= star;
                  return (
                    <button
                      key={star}
                      type="button"
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      onClick={() => setRating(star)}
                      className="p-1 transition-transform hover:scale-110 cursor-pointer"
                    >
                      <Star
                        className={`w-8 h-8 ${
                          active
                            ? 'text-[#F39C12] fill-[#F39C12]'
                            : 'text-gray-300'
                        }`}
                      />
                    </button>
                  );
                })}
              </div>
              <p className="text-xs font-bold text-[#2D5A27] pt-1">
                {getRatingLabel(hoverRating || rating)}
              </p>
            </div>

            {/* Quick Tag Chips */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#2D3A3A] block">
                দ্রুত ট্যাগ নির্বাচন করুন (ঐচ্ছিক):
              </label>
              <div className="flex flex-wrap gap-1.5">
                {tagList.map((tag) => {
                  const isSelected = selectedTags.includes(tag);
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => toggleTag(tag)}
                      className={`text-xs px-2.5 py-1 rounded-xl transition cursor-pointer border ${
                        isSelected
                          ? 'bg-[#2D5A27] text-white border-[#2D5A27]'
                          : 'bg-white text-[#5A6B6B] border-[#E6E0D4] hover:border-[#2D5A27]'
                      }`}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Comment Area */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-[#2D3A3A] block">
                আপনার বিস্তারিত অভিজ্ঞতা লিখুন (ঐচ্ছিক):
              </label>
              <textarea
                rows={3}
                placeholder="কেমন ছিল আপনার অভিজ্ঞতা? ব্যবহার, সঠিক সময়, নির্ভরযোগ্যতা ইত্যাদি নিয়ে লিখুন..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="w-full bg-[#FDFBF7] border border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl p-3 text-xs text-[#2D3A3A] placeholder-[#736B5E]/50 focus:outline-none transition"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-bold text-[#736B5E] hover:bg-gray-100 transition cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                disabled={isSubmitting || rating === 0}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-sm transition cursor-pointer flex items-center gap-1.5"
              >
                <CheckCircle className="w-3.5 h-3.5" />
                <span>রিভিউ জমা দিন</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
