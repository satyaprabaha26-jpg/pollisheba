import React from 'react';
import { PhoneCall, ShieldAlert, Siren, Sparkles, CheckCircle2 } from 'lucide-react';

interface Prominent999BannerProps {
  className?: string;
  onNavigateHotlines?: () => void;
}

export const Prominent999Banner: React.FC<Prominent999BannerProps> = ({
  className = '',
  onNavigateHotlines
}) => {
  return (
    <div
      className={`relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#991B1B] via-[#DC2626] to-[#B91C1C] text-white p-5 sm:p-6 shadow-lg border-2 border-red-400/40 ${className}`}
    >
      {/* Background visual accents */}
      <div className="absolute -right-10 -bottom-10 w-44 h-44 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -left-10 -top-10 w-36 h-36 bg-amber-400/20 rounded-full blur-xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
        
        {/* Left info & Badge */}
        <div className="space-y-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1.5 bg-white text-[#B91C1C] font-extrabold text-xs px-3 py-1 rounded-full shadow-xs animate-pulse">
              <Siren className="w-3.5 h-3.5" />
              <span>জাতীয় জরুরি হেল্পলাইন</span>
            </span>
            <span className="bg-black/25 text-amber-200 text-xs px-2.5 py-0.5 rounded-full font-bold border border-amber-300/30">
              টোল-ফ্রি ২৪/৭ (কোনো চার্জ নেই)
            </span>
          </div>

          <div className="flex items-center gap-3.5 pt-1">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white text-[#B91C1C] font-black text-2xl sm:text-3xl flex items-center justify-center font-['Noto_Sans_Bengali'] shadow-md border-2 border-amber-300 shrink-0">
              ৯৯৯
            </div>

            <div>
              <h3 className="text-xl sm:text-2xl font-extrabold font-['Noto_Sans_Bengali'] tracking-tight text-white drop-shadow-xs">
                জাতীয় জরুরি সেবা ৯৯৯
              </h3>
              <p className="text-xs sm:text-sm text-red-100 mt-0.5 leading-snug">
                🚨 পুলিশ • 🚒 ফায়ার সার্ভিস • 🚑 সরকারি অ্যাম্বুলেন্স
              </p>
            </div>
          </div>

          <p className="text-xs text-red-100/90 max-w-xl leading-relaxed pt-1">
            যেকোনো মোবাইল বা টেলিফোন থেকে ব্যালেন্স ছাড়াই সম্পূর্ণ ফ্রিতে ডায়াল করুন। তাৎক্ষণিক পুলিশি সহায়তা, অগ্নিকাণ্ড নির্বাপণ ও রোগী পরিবহনে সরকার পরিচালিত কেন্দ্রীয় জরুরি সেবা।
          </p>
        </div>

        {/* Right Action Call Button */}
        <div className="flex flex-col sm:flex-row md:flex-col items-stretch sm:items-center md:items-end gap-2.5 shrink-0">
          <a
            href="tel:999"
            className="inline-flex items-center justify-center gap-2.5 bg-white hover:bg-amber-100 text-[#B91C1C] hover:text-[#991B1B] font-extrabold px-7 py-3.5 rounded-2xl text-base sm:text-lg shadow-xl hover:shadow-2xl transition-all transform hover:scale-102 active:scale-98 cursor-pointer border-2 border-amber-300"
            title="৯৯৯ এ কল করুন"
          >
            <PhoneCall className="w-6 h-6 animate-bounce" />
            <span>সরাসরি কল করুন ৯৯৯</span>
          </a>

          {onNavigateHotlines && (
            <button
              onClick={onNavigateHotlines}
              className="text-xs text-white/90 hover:text-white underline cursor-pointer text-center md:text-right py-1 font-medium"
            >
              অন্যান্য সব জরুরি নম্বর দেখুন →
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
