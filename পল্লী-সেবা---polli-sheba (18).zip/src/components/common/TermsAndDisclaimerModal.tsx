import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  AlertTriangle, 
  Check, 
  Globe, 
  MapPin, 
  Share2, 
  UserCheck, 
  FileText, 
  X,
  PhoneOff,
  Mail,
  Scale,
  HeartPulse,
  Sprout,
  Users,
  GraduationCap,
  Wrench,
  Bot
} from 'lucide-react';

interface TermsAndDisclaimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialLanguage?: 'bn' | 'en';
}

export const TermsAndDisclaimerModal: React.FC<TermsAndDisclaimerModalProps> = ({
  isOpen,
  onClose,
  initialLanguage = 'bn'
}) => {
  const [lang, setLang] = useState<'bn' | 'en'>(initialLanguage);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto font-['Noto_Sans_Bengali']">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-5 sm:p-7 shadow-2xl border border-[#E6E0D4] max-h-[92vh] overflow-y-auto space-y-5 my-auto">
        
        {/* Modal Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E6E0D4] pb-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#2D5A27] text-white flex items-center justify-center shadow-xs shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-[#2D3A3A] leading-snug">
                {lang === 'bn' 
                  ? 'পল্লী সেবা – ব্যবহারের শর্তাবলী, দায়মুক্তি ও গোপনীয়তা নীতিমালা' 
                  : 'Polli Sheba – Terms of Service, Disclaimer & Privacy Policy'}
              </h3>
              <p className="text-xs text-[#5A6B6B]">
                {lang === 'bn' 
                  ? 'ব্যবহারকারীদের সচেতনতা, আইনি দায়মুক্তি ও স্বচ্ছ প্ল্যাটফর্ম ব্যবহারের নির্দেশিকা' 
                  : 'Platform Transparency, Absolute Legal Disclaimer & User Privacy Architecture'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            {/* Language Switcher */}
            <div className="bg-[#FAF8F5] p-1 rounded-2xl border border-[#D4C3A3] flex items-center gap-1">
              <button
                onClick={() => setLang('bn')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                  lang === 'bn' 
                    ? 'bg-[#2D5A27] text-white shadow-2xs' 
                    : 'text-[#5A6B6B] hover:text-black'
                }`}
              >
                <span>বাংলা</span>
              </button>
              <button
                onClick={() => setLang('en')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                  lang === 'en' 
                    ? 'bg-[#2D5A27] text-white shadow-2xs' 
                    : 'text-[#5A6B6B] hover:text-black'
                }`}
              >
                <Globe className="w-3 h-3" />
                <span>English</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="text-[#736B5E] hover:text-[#2D3A3A] text-lg font-bold p-1.5 rounded-xl hover:bg-[#FAF8F5] cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* BENGALI CONTENT */}
        {lang === 'bn' ? (
          <div className="space-y-4 text-xs sm:text-sm text-[#2D3A3A] leading-relaxed">
            
            {/* ১. সেবার ধরন ও উদ্দেশ্য */}
            <div className="bg-[#D4E4BC]/30 p-4 rounded-2xl border border-[#D4E4BC] space-y-1.5">
              <h4 className="font-bold text-sm text-[#2D5A27] flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#2D5A27]" />
                <span>১. সেবার ধরন ও উদ্দেশ্য</span>
              </h4>
              <p className="text-[#3E4D4D]">
                "পল্লী সেবা" একটি স্বাধীন, অলাভজনক এবং তথ্যপ্রযুক্তিভিত্তিক ডিজিটাল প্ল্যাটফর্ম। এই অ্যাপের প্রধান উদ্দেশ্য হলো গ্রামীণ নাগরিক, কৃষক, শ্রমিক, চালক, কারিগর ও সেবাগ্রহীতাদের মধ্যে পারস্পরিক যোগাযোগের তথ্যগত সংযোগ ঘটানো। <strong>অ্যাপ কর্তৃপক্ষ নিজে কোনো পণ্য কেনাবেচা করে না, কোনো যানবাহনের মালিক নয় এবং কোনো প্রকার নিয়োগকর্তা বা আর্থিক লেনদেনকারী প্রতিষ্ঠান নয়।</strong>
              </p>
            </div>

            {/* ২. পরিচয় সুরক্ষা ও গোপনীয়তা */}
            <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] space-y-1.5">
              <h4 className="font-bold text-sm text-[#2D5A27] flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#E8924A]" />
                <span>২. পরিচয় সুরক্ষা ও গোপনীয়তা</span>
              </h4>
              <ul className="space-y-1.5 text-xs text-[#3E4D4D] list-disc list-inside">
                <li>ব্যবহারকারীর মোবাইল নম্বর সুরক্ষিত রাখতে এবং অনাকাঙ্ক্ষিত কল এড়াতে অ্যাপের অভ্যন্তরে সুরক্ষিত কল (Masked Call) প্রযুক্তি ব্যবহারের সুবিধা রাখা হয়েছে।</li>
                <li>ব্যবহারকারীর ব্যক্তিগত তথ্য কোনো বাণিজ্যিক বিজ্ঞাপনী প্রতিষ্ঠানের কাছে বিক্রি বা বিনিময় করা হয় না।</li>
                <li>নিবন্ধনের জন্য ব্যবহৃত ওটিপি (OTP) ভেরিফাইড ডেটা আমাদের কেন্দ্রীয় ডেটাবেজে সম্পূর্ণ সুরক্ষিত রাখা হয়।</li>
              </ul>
            </div>

            {/* ৩. সম্পূর্ণ দায়মুক্তি (Absolute Disclaimer) */}
            <div className="bg-[#FAF8F5] p-4.5 rounded-2xl border border-[#E6E0D4] space-y-3">
              <h4 className="font-bold text-sm text-[#C0392B] flex items-center gap-2 border-b border-[#E6E0D4] pb-2">
                <AlertTriangle className="w-4 h-4 text-[#C0392B]" />
                <span>৩. সম্পূর্ণ দায়মুক্তি (Absolute Disclaimer)</span>
              </h4>
              
              <ul className="space-y-2.5 text-xs text-[#3E4D4D]">
                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#C0392B] mt-0.5">•</span>
                  <div>
                    <strong>পণ্য কেনাবেচা (পল্লী হাট ও বাজারদর):</strong> পণ্যের সঠিক মান, সতেজতা, ওজন এবং টাকা লেনদেনের সম্পূর্ণ দায়িত্ব ক্রেতা ও বিক্রেতার। কোনো প্রকার অগ্রিম টাকা দেওয়ার আগে সরজমিনে পণ্য দেখে নেওয়ার অনুরোধ করা হচ্ছে। অ্যাপে প্রদর্শিত দৈনিক কৃষি বাজারদর কেবল ধারণামূলক তথ্য।
                  </div>
                </li>

                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#C0392B] mt-0.5">•</span>
                  <div>
                    <strong>শ্রমিক ও কৃষাণ নিয়োগ:</strong> "শ্রমিকদের গায়ের ঘাম শুকানোর আগেই তাদের মজুরি পরিশোধ করার চেষ্টা করুন।" (সুনানে ইবনে মাজাহ: ২৪৪৩)। তবে কোনো শ্রমিকের বকেয়া মজুরি আদায় বা শ্রম বিরোধ মীমাংসায় অ্যাপ কর্তৃপক্ষ আইনত বাধ্য নয়। যেকোনো শ্রম বিরোধে সরকারি জাতীয় শ্রম হেল্পলাইন <strong>১৬১৯৯</strong> (16199) এ যোগাযোগ করুন।
                  </div>
                </li>

                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#C0392B] mt-0.5">•</span>
                  <div>
                    <strong>পরিবহন যাত্রা, নিরাপত্তা ও লাইভ ট্র্যাকিং:</strong> পরিবহন সেবা বা যাত্রা চলাকালীন কোনো দুর্ঘটনা, মালামাল হারানো বা আর্থিক ক্ষতির দায় অ্যাপ কর্তৃপক্ষ বহন করবে না। যাত্রীর সুরক্ষায় অ্যাপে ব্যবহৃত লাইভ ট্র্যাকিং লিঙ্কটি যাত্রা সম্পন্ন হওয়ার সাথে সাথে স্বয়ংক্রিয়ভাবে নিষ্ক্রিয় হয়ে যাবে।
                  </div>
                </li>

                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#C0392B] mt-0.5">•</span>
                  <div>
                    <strong>স্বাস্থ্য ও চিকিৎসা গাইড (হাসপাতাল, ডাক্তার, টিকা ও ফার্স্ট এইড):</strong> অ্যাপে প্রদর্শিত হাসপাতাল তথ্য, ডাক্তারদের চেম্বার, ইপিআই টিকাদান শিডিউল ও জরুরি প্রাথমিক চিকিৎসা (ফার্স্ট এইড) কেবল সাধারণ নাগরিক সচেতনতার জন্য। "পল্লী সেবা" কোনো সরাসরি চিকিৎসা প্রদানকারী প্রতিষ্ঠান নয়। জরুরি চিকিৎসায় তাৎক্ষণিক নিকটস্থ হাসপাতালে যোগাযোগের অনুরোধ করা হচ্ছে।
                  </div>
                </li>

                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#C0392B] mt-0.5">•</span>
                  <div>
                    <strong>আইন, সরকারি লিগ্যাল এইড ও থানা/কোর্ট গাইড:</strong> অ্যাপে প্রদর্শিত সরকারি লিগ্যাল এইড (Legal Aid), নির্বাহী ম্যাজিস্ট্রেট কোর্ট ও জজ কোর্ট সংক্রান্ত তথ্য নির্দেশিকামূলক। অ্যাপ কর্তৃপক্ষ কোনো আইনি ফার্ম নয়। যেকোনো দেওয়ানি বা ফৌজদারি মামলায় সরাসরি জেলা জজ কোর্টের সরকারি লিগ্যাল এইড অফিস (হটলাইন: <strong>১৬৪৩০</strong>) বা নিবন্ধিত আইনজীবীর পরামর্শ নিন।
                  </div>
                </li>

                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#C0392B] mt-0.5">•</span>
                  <div>
                    <strong>মিস্ত্রি, কারিগর ও গৃহশিক্ষক (টিউটর):</strong> কাজ দেওয়া বা নেওয়ার পূর্বে সংশ্লিষ্ট মিস্ত্রি বা টিউটরের পরিচয় ও কাজের দক্ষতা নিজ দায়িত্বে যাচাই করে নিন। ব্যক্তিগত কোনো অঘটন বা আর্থিক ক্ষতির দায় অ্যাপ বহন করবে না।
                  </div>
                </li>

                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#C0392B] mt-0.5">•</span>
                  <div>
                    <strong>কৃষি পরামর্শ, ক্যালকুলেটর ও কিস্তি হিসাব (সার, জমি ও ঋণ):</strong> সার ক্যালকুলেটর, আমিন ক্যালকুলেটর বা কৃষি ঋণ হিসাবকের তথ্যগুলো সাধারণ গাণিতিক ফলাফলের ওপর ভিত্তি করে তৈরি। চূড়ান্ত সিদ্ধান্ত নেওয়ার পূর্বে অনুমোদিত উপজেলা কৃষি অফিসার, স্থানীয় আমিন (সার্ভেয়ার) বা সংশ্লিষ্ট ব্যাংক কর্মকর্তার পরামর্শ নিন।
                  </div>
                </li>

                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#C0392B] mt-0.5">•</span>
                  <div>
                    <strong>এআই পল্লী পরামর্শক (AI Assistant):</strong> কৃত্রিম বুদ্ধিমত্তা থেকে প্রাপ্ত উত্তরগুলো প্রযুক্তিভিত্তিক। প্রাপ্ত পরামর্শের বাস্তবিক ব্যবহারের পূর্বে ব্যবহারকারীর নিজ দায়িত্বে এর সত্যতা যাচাই করা উচিত।
                  </div>
                </li>

                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#C0392B] mt-0.5">•</span>
                  <div>
                    <strong>আইনি বাধ্যবাধকতা ও ডাটা শেয়ারিং:</strong> অ্যাপে কোনো ফৌজদারি অপরাধ সংঘটিত হলে বা আইনি বাধ্যবাধকতায় কেবল আইন প্রয়োগকারী সংস্থার লিখিত আবেদনের প্রেক্ষিতে সার্ভার লগ ও নিবন্ধিত তথ্য প্রদান করা হবে।
                  </div>
                </li>
              </ul>
            </div>

            {/* ৪. অ্যাকাউন্ট বাতিল করার অধিকার */}
            <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] space-y-1.5">
              <h4 className="font-bold text-sm text-[#2D5A27] flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-[#E8924A]" />
                <span>৪. অ্যাকাউন্ট বাতিল করার অধিকার</span>
              </h4>
              <p className="text-[#3E4D4D]">
                কোনো ব্যবহারকারী ভুয়া ফোন নম্বর, ভুল তথ্য, অশালীন আচরণ বা বিভ্রান্তিকর বিজ্ঞপ্তি পোস্ট করলে অ্যাপ কর্তৃপক্ষ পূর্বসংকেত ছাড়াই তার অ্যাকাউন্ট বাতিল বা পোস্ট মুছে ফেলার পূর্ণ অধিকার রাখে।
              </p>
            </div>

            {/* ৫. অ্যাডমিনের সাথে যোগাযোগ বাক্স */}
            <div className="bg-[#FAF8F5] border-2 border-[#15803D]/40 p-4.5 rounded-2xl shadow-xs space-y-2.5">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#15803D]" />
                  <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">
                    অফিসিয়াল ইমেইল সাপোর্ট
                  </h5>
                </div>
              </div>

              <p className="text-xs text-[#5A6B6B] leading-relaxed">
                তথ্য সংশোধন, নতুন ইউনিয়ন বা উপজেলা সংযোজন এবং যেকোনো সহায়তার জন্য সরাসরি ওপরের ইমেইলে যোগাযোগ করুন:
              </p>

              <div className="flex items-center gap-2 pt-1 flex-wrap">
                <a
                  href="mailto:polliseba26@gmail.com"
                  className="inline-flex items-center gap-2 bg-gradient-to-r from-[#15803D] via-[#22C55E] to-[#15803D] text-white px-3.5 py-1.5 rounded-xl font-bold text-xs shadow-md transition cursor-pointer border-2 border-emerald-300 animate-pulse tracking-wide"
                  title="ইমেইল পাঠান"
                >
                  <Mail className="w-3.5 h-3.5 text-white" />
                  <span>polliseba26@gmail.com</span>
                </a>
              </div>
            </div>

          </div>
        ) : (
          /* ENGLISH CONTENT */
          <div className="space-y-4 text-xs sm:text-sm text-[#2D3A3A] leading-relaxed">
            
            {/* 1. Nature & Purpose */}
            <div className="bg-[#D4E4BC]/30 p-4 rounded-2xl border border-[#D4E4BC] space-y-1.5">
              <h4 className="font-bold text-sm text-[#2D5A27]">
                1. Nature & Purpose of Service
              </h4>
              <p className="text-[#3E4D4D]">
                "Polli Sheba" is an independent, non-profit, and information-technology-based digital platform. Its main objective is to establish an informational bridge among rural citizens, farmers, laborers, drivers, artisans, and service recipients. <strong>The app authority does not buy or sell goods, does not own any vehicles, and is neither an employer nor a financial transaction entity.</strong>
              </p>
            </div>

            {/* 2. Identity Protection & Privacy */}
            <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] space-y-1.5">
              <h4 className="font-bold text-sm text-[#2D5A27]">
                2. Identity Protection & Privacy
              </h4>
              <ul className="space-y-1.5 text-xs text-[#3E4D4D] list-disc list-inside">
                <li>Masked calling technology is provided inside the app to protect user phone numbers and prevent unsolicited calls.</li>
                <li>Personal data of users is never sold or exchanged with commercial advertising entities.</li>
                <li>OTP-verified registration data is stored securely in our central database.</li>
              </ul>
            </div>

            {/* 3. Absolute Legal Disclaimer */}
            <div className="bg-[#FAF8F5] p-4.5 rounded-2xl border border-[#E6E0D4] space-y-2.5">
              <h4 className="font-bold text-sm text-[#C0392B] flex items-center gap-2 border-b border-[#E6E0D4] pb-2">
                <AlertTriangle className="w-4 h-4 text-[#C0392B]" />
                <span>3. Absolute Disclaimer of Liability</span>
              </h4>
              <ul className="space-y-2 text-xs text-[#3E4D4D] list-disc list-inside">
                <li>
                  <strong>Commerce & Market Prices:</strong> Quality, freshness, weight, and payments are solely the responsibility of buyers and sellers. Always inspect items in person before making advance payments.
                </li>
                <li>
                  <strong>Labor & Harvester Hiring:</strong> "Pay the worker his wages before his sweat has dried." (Sunan Ibn Majah: 2443). The platform is not legally bound to recover unpaid wages. For disputes, contact the National Labor Helpline at <strong>16199</strong>.
                </li>
                <li>
                  <strong>Transport & Live Tracking:</strong> The platform bears no liability for accidents, loss of belongings, or financial damage. Live tracking links deactivate automatically after trip completion.
                </li>
                <li>
                  <strong>Health & Medical Guide:</strong> Hospital listings, doctors' chambers, EPI vaccine schedules, and first aid guides are for public awareness only. In emergency, contact the nearest hospital immediately.
                </li>
                <li>
                  <strong>Legal, Legal Aid & Court Guide:</strong> Information regarding Legal Aid (16430), Executive Magistrate Courts, and District Judge Courts is advisory. Consult the District Judge Court Legal Aid office (16430) or a registered lawyer.
                </li>
                <li>
                  <strong>Mechanics & Home Tutors:</strong> Verify identity and competence before hiring. The platform accepts no liability for personal or financial damages.
                </li>
                <li>
                  <strong>Agri Advisory & Calculators:</strong> Fertilizer, Land Amin, and Loan calculators provide general mathematical results. Consult an authorized Upazila Agriculture Officer or surveyor for final decisions.
                </li>
                <li>
                  <strong>AI Polli Advisor:</strong> Artificial Intelligence answers are algorithmic. Users must independently verify facts before taking practical action.
                </li>
                <li>
                  <strong>Legal Compliance:</strong> Server logs and registered data are shared with law enforcement only upon formal written requests.
                </li>
              </ul>
            </div>

            {/* 4. Right to Terminate */}
            <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] space-y-1.5">
              <h4 className="font-bold text-sm text-[#2D5A27]">
                4. Right to Terminate Accounts
              </h4>
              <p className="text-[#3E4D4D]">
                The app authority reserves the unconditional right to suspend accounts or delete listings without prior notice if fake phone numbers, false information, offensive conduct, or misleading ads are detected.
              </p>
            </div>

            {/* 5. Official Support */}
            <div className="bg-[#FAF8F5] border-2 border-[#15803D]/40 p-4 rounded-2xl space-y-2">
              <div className="flex items-center justify-between">
                <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A] flex items-center gap-1.5">
                  <Mail className="w-4 h-4 text-[#15803D]" />
                  <span>Official Email Support</span>
                </h5>
              </div>
              <p className="text-xs text-[#5A6B6B]">
                For info corrections, adding new unions/upazilas, or assistance, reach out directly:
              </p>
              <div className="flex items-center gap-2 pt-1 flex-wrap">
                <a
                  href="mailto:polliseba26@gmail.com"
                  className="inline-flex items-center gap-2 bg-gradient-to-r from-[#15803D] via-[#22C55E] to-[#15803D] text-white px-3.5 py-1.5 rounded-xl font-bold text-xs shadow-md transition border-2 border-emerald-300 animate-pulse tracking-wide"
                >
                  <Mail className="w-3.5 h-3.5 text-white" />
                  <span>polliseba26@gmail.com</span>
                </a>
              </div>
            </div>

          </div>
        )}

        {/* Modal Bottom Acceptance */}
        <div className="pt-3 border-t border-[#E6E0D4] flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-[11px] text-[#5A6B6B]">
            {lang === 'bn' 
              ? 'অ্যাপ ব্যবহারের মাধ্যমে আপনি উপরোক্ত শর্তাবলী ও দায়মুক্তিতে পূর্ণ সম্মতি দিচ্ছেন।'
              : 'By using this app, you acknowledge and agree to the terms and disclaimers above.'}
          </div>

          <button
            onClick={onClose}
            className="w-full sm:w-auto bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 px-6 rounded-2xl text-xs sm:text-sm cursor-pointer shadow-xs transition"
          >
            {lang === 'bn' ? 'আমি শর্তাবলী বুঝেছি ও একমত ✓' : 'I Understand & Agree ✓'}
          </button>
        </div>

      </div>
    </div>
  );
};
