import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, Compass, ChevronDown, Home, PlusCircle, X, CheckCircle2, AlertCircle, ShieldCheck } from 'lucide-react';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { getUpazilasForDistrict, getUnionsForUpazila, addCustomLocation } from '../../data/bangladeshLocations';

export interface AddressState {
  district: string;
  upazila: string;
  union: string;
  village: string;
}

interface CascadingAddressSelectorProps {
  address?: AddressState;
  value?: AddressState;
  onChange: (address: AddressState) => void;
  layout?: 'stacked' | 'grid-2x2' | 'grid-4' | 'compact-row';
  showVillageInput?: boolean;
  showVillage?: boolean;
  villagePlaceholder?: string;
  required?: boolean;
  disabled?: boolean;
  labelPrefix?: string;
  allowAllOption?: boolean; // For search/filter bars (e.g. 'সকল জেলা', 'সকল উপজেলা', 'সকল ইউনিয়ন')
  allDistrictLabel?: string;
  allUpazilaLabel?: string;
  allUnionLabel?: string;
  showAddAreaButton?: boolean;
}

export const CascadingAddressSelector: React.FC<CascadingAddressSelectorProps> = ({
  address: propAddress,
  value: propValue,
  onChange,
  layout = 'grid-2x2',
  showVillageInput = true,
  showVillage,
  villagePlaceholder = 'যেমন: উত্তরপাড়া, ৩নং ওয়ার্ড',
  required = true,
  disabled = false,
  labelPrefix = '',
  allowAllOption = false,
  allDistrictLabel = 'সকল জেলা (সমগ্র বাংলাদেশ)',
  allUpazilaLabel = 'সকল উপজেলা / থানা',
  allUnionLabel = 'সকল ইউনিয়ন / ওয়ার্ড',
  showAddAreaButton = true
}) => {
  const [revision, setRevision] = useState(0);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newDistrict, setNewDistrict] = useState('ঢাকা');
  const [newUpazila, setNewUpazila] = useState('');
  const [newUnion, setNewUnion] = useState('');
  const [newVillage, setNewVillage] = useState('');
  const [submitterName, setSubmitterName] = useState('');
  const [submitterPhone, setSubmitterPhone] = useState('');
  const [addErrorMsg, setAddErrorMsg] = useState('');
  const [addSuccessMsg, setAddSuccessMsg] = useState('');

  // Listen for newly added custom locations from any instance
  useEffect(() => {
    const handleLocationAdded = () => {
      setRevision((r) => r + 1);
    };
    window.addEventListener('pollisheba_location_added', handleLocationAdded);
    return () => {
      window.removeEventListener('pollisheba_location_added', handleLocationAdded);
    };
  }, []);

  const address: AddressState = propAddress || propValue || {
    district: '',
    upazila: '',
    union: '',
    village: ''
  };

  const isVillageVisible = showVillage !== undefined ? showVillage : showVillageInput;
  
  const rawDistrict = address.district || '';
  const isAllDistrict = !rawDistrict || rawDistrict === 'সকল জেলা' || rawDistrict === allDistrictLabel;
  const currentDistrict = isAllDistrict ? (allowAllOption ? '' : 'ঢাকা') : rawDistrict;
  const upazilas = currentDistrict && currentDistrict !== 'সকল জেলা' && currentDistrict !== allDistrictLabel
    ? getUpazilasForDistrict(currentDistrict) 
    : [];

  const rawUpazila = address.upazila || '';
  const isAllUpazila = !rawUpazila || rawUpazila === 'সকল উপজেলা' || rawUpazila === 'সকল উপজেলা / থানা' || rawUpazila === allUpazilaLabel;
  const currentUpazila = isAllUpazila ? (allowAllOption ? '' : (upazilas[0] || '')) : rawUpazila;

  const unions = currentDistrict && currentUpazila && currentUpazila !== 'সকল উপজেলা' && currentUpazila !== allUpazilaLabel
    ? getUnionsForUpazila(currentDistrict, currentUpazila)
    : [];

  const rawUnion = address.union || '';
  const isAllUnion = !rawUnion || rawUnion === 'সকল ইউনিয়ন' || rawUnion === 'সকল ইউনিয়ন / ওয়ার্ড' || rawUnion === allUnionLabel;
  const currentUnion = isAllUnion ? (allowAllOption ? '' : (unions[0] || '')) : rawUnion;

  const handleDistrictChange = (selectedDistrict: string) => {
    if (allowAllOption && (!selectedDistrict || selectedDistrict === 'সকল জেলা' || selectedDistrict === allDistrictLabel)) {
      onChange({
        ...address,
        district: '',
        upazila: '',
        union: '',
        village: ''
      });
      return;
    }

    const newUpazilas = getUpazilasForDistrict(selectedDistrict);
    const firstUpazila = allowAllOption ? '' : (newUpazilas[0] || '');
    const newUnions = firstUpazila ? getUnionsForUpazila(selectedDistrict, firstUpazila) : [];
    const firstUnion = allowAllOption ? '' : (newUnions[0] || '');

    onChange({
      ...address,
      district: selectedDistrict,
      upazila: firstUpazila,
      union: firstUnion
    });
  };

  const handleUpazilaChange = (selectedUpazila: string) => {
    if (allowAllOption && (!selectedUpazila || selectedUpazila === 'সকল উপজেলা' || selectedUpazila === allUpazilaLabel)) {
      onChange({
        ...address,
        upazila: '',
        union: ''
      });
      return;
    }

    const newUnions = getUnionsForUpazila(currentDistrict, selectedUpazila);
    const firstUnion = allowAllOption ? '' : (newUnions[0] || '');

    onChange({
      ...address,
      upazila: selectedUpazila,
      union: firstUnion
    });
  };

  const handleUnionChange = (selectedUnion: string) => {
    onChange({
      ...address,
      union: (allowAllOption && (selectedUnion === 'সকল ইউনিয়ন' || selectedUnion === allUnionLabel)) ? '' : selectedUnion
    });
  };

  const handleVillageChange = (villageText: string) => {
    onChange({
      ...address,
      village: villageText
    });
  };

  const handleOpenAddArea = () => {
    setNewDistrict(currentDistrict || 'ঢাকা');
    setNewUpazila(currentUpazila || '');
    setNewUnion('');
    setNewVillage('');
    setSubmitterName('');
    setSubmitterPhone('');
    setAddErrorMsg('');
    setAddSuccessMsg('');
    setShowAddModal(true);
  };

  const handleSaveCustomArea = (e: React.FormEvent) => {
    e.preventDefault();
    setAddErrorMsg('');

    const normDistrict = newDistrict.trim();
    const normUpazila = newUpazila.trim();
    const normUnion = newUnion.trim();
    const normName = submitterName.trim();
    const normPhone = submitterPhone.trim();

    // 1. Basic required checks
    if (!normDistrict || !normUpazila || !normUnion) {
      setAddErrorMsg('জেলা, উপজেলা এবং ইউনিয়নের নাম পূরণ করা বাধ্যতামূলক।');
      return;
    }

    if (normUnion.length < 3) {
      setAddErrorMsg('ইউনিয়ন বা ওয়ার্ডের নাম কমপক্ষে ৩ অক্ষরের হতে হবে।');
      return;
    }

    // 2. Submitter name validation
    if (!normName || normName.length < 2) {
      setAddErrorMsg('ভুয়া তথ্য রোধে আপনার পূর্ণ নাম প্রদান করা বাধ্যতামূলক।');
      return;
    }

    // 3. Submitter phone number validation (Must be valid BD 11-digit mobile: 013, 014, 015, 016, 017, 018, 019)
    const bdPhoneRegex = /^01[3-9]\d{8}$/;
    if (!bdPhoneRegex.test(normPhone)) {
      setAddErrorMsg('অনুগ্রহ করে আপনার সঠিক ১১ ডিজিটের সচল মোবাইল নম্বর প্রদান করুন (যেমন: 01712345678)। ভুয়া তথ্য যোগ করা সম্পূর্ণ নিষিদ্ধ।');
      return;
    }

    // 4. Duplicate union detection
    const existingUnions = getUnionsForUpazila(normDistrict, normUpazila);
    const isDuplicate = existingUnions.some(
      u => u.trim().toLowerCase() === normUnion.toLowerCase() ||
           u.trim().replace(/\s+/g, '') === normUnion.replace(/\s+/g, '')
    );

    if (isDuplicate) {
      setAddErrorMsg(`সতর্কতা: "${normUnion}" ইউনিয়নটি ইতিমধ্যে এই উপজেলায় বিদ্যমান রয়েছে। ড্রপডাউন তালিকা থেকে সরাসরি এটি নির্বাচন করুন।`);
      return;
    }

    const record = addCustomLocation({
      district: normDistrict,
      upazila: normUpazila,
      union: normUnion,
      village: newVillage.trim() || undefined,
      submittedBy: normName,
      phone: normPhone
    });

    // Auto-select this newly added location in the form
    onChange({
      ...address,
      district: record.district,
      upazila: record.upazila,
      union: record.union,
      village: record.village || address.village || ''
    });

    setAddSuccessMsg(`অভিনন্দন! "${record.union}, ${record.upazila}" যাচাইপূর্বক স্থায়ীভাবে যুক্ত হয়েছে ও নির্বাচন করা হয়েছে।`);
    setTimeout(() => {
      setShowAddModal(false);
      setAddSuccessMsg('');
    }, 1500);
  };

  const gridClass = 
    layout === 'grid-4' ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3' :
    layout === 'grid-2x2' ? 'grid grid-cols-1 sm:grid-cols-2 gap-3' :
    layout === 'compact-row' ? 'flex flex-wrap items-center gap-2.5' :
    'space-y-3';

  return (
    <div className="font-['Noto_Sans_Bengali'] space-y-1.5">
      <div className={gridClass}>
        {/* 1. জেলা (District) */}
        <div className="flex-1 min-w-[150px]">
          <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-[#2D5A27]" />
            <span>{labelPrefix}জেলা {required && <span className="text-red-500">*</span>}</span>
          </label>
          <div className="relative">
            <select
              value={currentDistrict}
              onChange={(e) => handleDistrictChange(e.target.value)}
              disabled={disabled}
              className="w-full appearance-none bg-white border border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold pr-8 focus:outline-none transition shadow-2xs cursor-pointer disabled:opacity-50"
            >
              {allowAllOption && <option key="__all_districts__" value="">{allDistrictLabel}</option>}
              {BANGLADESH_DISTRICTS.map((d) => (
                <option key={`dist-${d}`} value={d}>{d}</option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-[#736B5E] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        {/* 2. উপজেলা / থানা (Upazila) */}
        <div className="flex-1 min-w-[150px]">
          <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1 flex items-center gap-1">
            <Navigation className="w-3.5 h-3.5 text-[#E8924A]" />
            <span>{labelPrefix}উপজেলা / থানা {required && <span className="text-red-500">*</span>}</span>
          </label>
          <div className="relative">
            <select
              value={currentUpazila}
              onChange={(e) => handleUpazilaChange(e.target.value)}
              disabled={disabled || (allowAllOption && !currentDistrict)}
              className="w-full appearance-none bg-white border border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold pr-8 focus:outline-none transition shadow-2xs cursor-pointer disabled:opacity-50 disabled:bg-gray-50"
            >
              {allowAllOption && <option key="__all_upazilas__" value="">{allUpazilaLabel}</option>}
              {!allowAllOption && upazilas.length === 0 && <option key="__none_upazila__" value="">উপজেলা নির্বাচন করুন</option>}
              {upazilas.map((u) => (
                <option key={`upz-${u}`} value={u}>{u}</option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-[#736B5E] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        {/* 3. ইউনিয়ন / পৌরসভা (Union) */}
        <div className="flex-1 min-w-[150px]">
          <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1 flex items-center gap-1">
            <Compass className="w-3.5 h-3.5 text-[#27AE60]" />
            <span>{labelPrefix}ইউনিয়ন / পৌরসভা {required && <span className="text-red-500">*</span>}</span>
          </label>
          <div className="relative">
            <select
              value={currentUnion}
              onChange={(e) => handleUnionChange(e.target.value)}
              disabled={disabled || (allowAllOption && (!currentDistrict || !currentUpazila))}
              className="w-full appearance-none bg-white border border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] font-semibold pr-8 focus:outline-none transition shadow-2xs cursor-pointer disabled:opacity-50 disabled:bg-gray-50"
            >
              {allowAllOption && <option key="__all_unions__" value="">{allUnionLabel}</option>}
              {!allowAllOption && unions.length === 0 && <option key="__none_union__" value="">ইউনিয়ন নির্বাচন করুন</option>}
              {unions.map((un) => (
                <option key={`uni-${un}`} value={un}>{un}</option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-[#736B5E] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        {/* 4. গ্রাম / পাড়া ও ওয়ার্ড নং (Village / Ward) */}
        {isVillageVisible && (
          <div className="flex-1 min-w-[150px]">
            <label className="block text-[11px] font-bold text-[#2D3A3A] mb-1 flex items-center gap-1">
              <Home className="w-3.5 h-3.5 text-[#A65E2E]" />
              <span>{labelPrefix}গ্রাম / পাড়া ও ওয়ার্ড {required && !allowAllOption && <span className="text-red-500">*</span>}</span>
            </label>
            <input
              type="text"
              placeholder={villagePlaceholder}
              value={address.village || ''}
              onChange={(e) => handleVillageChange(e.target.value)}
              disabled={disabled}
              className="w-full bg-white border border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] placeholder-[#736B5E]/50 focus:outline-none transition shadow-2xs disabled:opacity-50"
            />
          </div>
        )}
      </div>

      {/* Button to add missing area/union */}
      {showAddAreaButton && !disabled && (
        <div className="flex items-center justify-between pt-1.5 px-0.5">
          <button
            type="button"
            onClick={handleOpenAddArea}
            id="btn-missing-union-trigger"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#2D5A27] hover:text-[#1E3F1A] bg-[#FAF8F5] hover:bg-[#D4E4BC]/30 border border-[#D4C3A3] px-3 py-1.5 rounded-xl transition cursor-pointer shadow-2xs group"
          >
            <PlusCircle className="w-3.5 h-3.5 text-[#E8924A] group-hover:rotate-90 transition-transform" />
            <span className="font-bold">আপনার ইউনিয়ন খুঁজে পাচ্ছেন না?</span>
            <span className="text-[10px] text-[#736B5E] hidden sm:inline">(এখানে ক্লিক করে যুক্ত করুন)</span>
          </button>
        </div>
      )}

      {/* Modal: Add Missing Area/Union */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-[#E6E0D4] relative animate-in fade-in zoom-in-95 duration-200">
            <button
              type="button"
              onClick={() => setShowAddModal(false)}
              className="absolute right-4 top-4 text-[#736B5E] hover:text-[#2D3A3A] p-1.5 rounded-full hover:bg-gray-100 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-[#D4E4BC] flex items-center justify-center text-[#2D5A27]">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-[#2D3A3A]">
                  আপনার ইউনিয়ন খুঁজে পাচ্ছেন না?
                </h3>
                <p className="text-xs text-[#736B5E]">
                  এখানে আপনার ইউনিয়ন বা ওয়ার্ড লিখুন; এটি তাৎক্ষণিকভাবে ড্রপডাউনে যুক্ত হবে
                </p>
              </div>
            </div>

            {addSuccessMsg ? (
              <div className="p-4 bg-[#E8F8F5] border border-[#27AE60] rounded-2xl text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-[#27AE60] mx-auto" />
                <p className="text-xs font-bold text-[#1E8449]">{addSuccessMsg}</p>
              </div>
            ) : (
              <form onSubmit={handleSaveCustomArea} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                    জেলা <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={newDistrict}
                    onChange={(e) => setNewDistrict(e.target.value)}
                    className="w-full bg-[#FDFBF7] border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs font-semibold text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  >
                    {BANGLADESH_DISTRICTS.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                    উপজেলা / থানার নাম <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: শিবগঞ্জ, সদর বা আপনার উপজেলার নাম"
                    value={newUpazila}
                    onChange={(e) => setNewUpazila(e.target.value)}
                    className="w-full bg-[#FDFBF7] border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                    ইউনিয়ন / পৌরসভার নাম <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: দেউলী ইউনিয়ন বা ৭নং ওয়ার্ড"
                    value={newUnion}
                    onChange={(e) => setNewUnion(e.target.value)}
                    className="w-full bg-[#FDFBF7] border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                    গ্রাম / পাড়া (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: পশ্চিমপাড়া বা রামপুর"
                    value={newVillage}
                    onChange={(e) => setNewVillage(e.target.value)}
                    className="w-full bg-[#FDFBF7] border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                {/* Error Alert Box */}
                {addErrorMsg && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-semibold text-red-700 flex items-start gap-2 animate-in fade-in">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                    <span>{addErrorMsg}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                      আপনার নাম <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="আপনার পূর্ণ নাম লিখুন"
                      value={submitterName}
                      onChange={(e) => setSubmitterName(e.target.value)}
                      className="w-full bg-[#FDFBF7] border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                      সক্রিয় মোবাইল নম্বর <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      maxLength={11}
                      placeholder="যেমন: 01712345678"
                      value={submitterPhone}
                      onChange={(e) => setSubmitterPhone(e.target.value.replace(/[^\d]/g, ''))}
                      className="w-full bg-[#FDFBF7] border border-[#D4C3A3] rounded-xl px-3 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                    />
                  </div>
                </div>

                <div className="p-2.5 bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl flex items-start gap-2 text-[11px] text-[#736B5E]">
                  <ShieldCheck className="w-4 h-4 text-[#2D5A27] shrink-0 mt-0.5" />
                  <span>
                    <strong>ভুয়া তথ্য প্রতিরোধ নীতি:</strong> ভুল বা অসত্য ইউনিয়ন যুক্ত হওয়া ঠেকাতে আবেদনকারীর নাম ও ১১ ডিজিটের সচল ফোন নম্বর সংরক্ষণ ও যাচাই করা হয়।
                  </span>
                </div>

                <div className="flex items-center justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-[#736B5E] hover:bg-gray-100 transition cursor-pointer"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-sm transition cursor-pointer flex items-center gap-1.5"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>যুক্ত করুন ও নির্বাচন করুন</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
