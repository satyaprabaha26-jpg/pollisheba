import React, { useRef, useState, useEffect, useCallback } from 'react';
import { 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Volume2, 
  VolumeX, 
  ShieldCheck, 
  Eye, 
  Smile, 
  Sparkles,
  UserCheck,
  X,
  Scan,
  AlertTriangle
} from 'lucide-react';

export interface LiveFaceVerificationProps {
  onCapture: (photoBase64: string) => void;
  onCancel?: () => void;
  title?: string;
  subtitle?: string;
}

type VerificationStep = 'align' | 'blink' | 'turn' | 'smile' | 'success';

export const LiveFaceVerificationModal: React.FC<LiveFaceVerificationProps> = ({
  onCapture,
  onCancel,
  title = 'বায়োমেট্রিক লাইভ ফেস ভেরিফিকেশন',
  subtitle = 'ভুয়া ছবি বা স্থির ফটো প্রতিরোধে রিয়েল-টাইম মুখমণ্ডল ও চোখের পলক যাচাই'
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const motionCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [streamActive, setStreamActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<VerificationStep>('align');
  const [stepProgress, setStepProgress] = useState<number>(15);
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(true);
  const [feedbackMessage, setFeedbackMessage] = useState<string>('ক্যামেরার বৃত্তের মাঝে আপনার মুখ রাখুন এবং স্থির থাকুন');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isSpoofSuspected, setIsSpoofSuspected] = useState<boolean>(false);
  const [autoCaptureCountdown, setAutoCaptureCountdown] = useState<number | null>(null);

  // Analysis frame refs
  const animFrameIdRef = useRef<number | null>(null);
  const prevFrameDataRef = useRef<Uint8ClampedArray | null>(null);
  const consecutiveMotionFramesRef = useRef<number>(0);
  const consecutiveStillFramesRef = useRef<number>(0);
  const consecutiveZeroMotionFramesRef = useRef<number>(0);
  const stepStartTimeRef = useRef<number>(Date.now());
  const synthRef = useRef<SpeechSynthesis | null>(typeof window !== 'undefined' ? window.speechSynthesis : null);

  // Web Audio Synth for interactive feedback sounds
  const playBeep = useCallback((freq = 587.33, duration = 0.12, type: OscillatorType = 'sine') => {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Audio context may be restricted by browser
    }
  }, []);

  const playSuccessChime = useCallback(() => {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;
      [523.25, 659.25, 783.99, 1046.50].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + i * 0.09);
        gain.gain.setValueAtTime(0.18, now + i * 0.09);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.09 + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + i * 0.09);
        osc.stop(now + i * 0.09 + 0.28);
      });
    } catch {
      // Ignore
    }
  }, []);

  // Bengali Voice Prompts using SpeechSynthesis
  const speakInstruction = useCallback((text: string) => {
    if (!voiceEnabled || !synthRef.current) return;
    try {
      synthRef.current.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'bn-BD';
      utterance.rate = 0.95;
      utterance.pitch = 1.0;

      const voices = synthRef.current.getVoices();
      const bnVoice = voices.find(v => 
        v.lang.includes('bn') || 
        v.name.toLowerCase().includes('bangla') || 
        v.name.toLowerCase().includes('bengali')
      );
      if (bnVoice) {
        utterance.voice = bnVoice;
      }
      synthRef.current.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error:', e);
    }
  }, [voiceEnabled]);

  // Start Camera Stream
  const startCamera = useCallback(async () => {
    setCameraError(null);
    setIsSpoofSuspected(false);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { 
            facingMode: 'user', 
            width: { ideal: 640 }, 
            height: { ideal: 640 } 
          },
          audio: false
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current?.play().catch(e => console.warn('Video play error:', e));
            setStreamActive(true);
            setCurrentStep('align');
            setStepProgress(20);
            stepStartTimeRef.current = Date.now();
            speakInstruction('ক্যামেরার বৃত্তের মাঝে আপনার মুখ রাখুন এবং সোজা তাকান');
          };
        }
      } else {
        setCameraError('আপনার ডিভাইসে ক্যামেরা সাপোর্ট পাওয়া যায়নি।');
      }
    } catch (err: unknown) {
      console.error('Camera access failed:', err);
      const errMsg = err instanceof Error ? err.message : String(err);
      if (errMsg.includes('NotAllowedError') || errMsg.includes('Permission')) {
        setCameraError('ক্যামেরা ব্যবহারের অনুমতি দেওয়া হয়নি। অনুগ্রহ করে ব্রাউজার সেটিংসে গিয়ে ক্যামেরার অনুমতি দিন।');
      } else {
        setCameraError('ক্যামেরা চালু করা সম্ভব হয়নি। অনুগ্রহ করে ডিভাইস সেটিংস চেক করুন।');
      }
    }
  }, [speakInstruction]);

  // Stop Camera Stream
  const stopCamera = useCallback(() => {
    if (animFrameIdRef.current) {
      cancelAnimationFrame(animFrameIdRef.current);
      animFrameIdRef.current = null;
    }
    if (synthRef.current) {
      synthRef.current.cancel();
    }
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
    setStreamActive(false);
  }, []);

  // Capture current high-res frame
  const captureFrame = useCallback((): string | null => {
    if (!videoRef.current || !canvasRef.current) return null;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const width = video.videoWidth || 640;
    const height = video.videoHeight || 640;
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // Flip horizontally for natural selfie reflection
    ctx.translate(width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, 0, 0, width, height);

    return canvas.toDataURL('image/jpeg', 0.88);
  }, []);

  // Motion & Liveness Analysis Engine
  useEffect(() => {
    if (!streamActive || currentStep === 'success') return;

    let isRunning = true;

    const analyzeLiveness = () => {
      if (!isRunning || !videoRef.current || !motionCanvasRef.current) {
        animFrameIdRef.current = requestAnimationFrame(analyzeLiveness);
        return;
      }

      const video = videoRef.current;
      if (video.readyState < 2) {
        animFrameIdRef.current = requestAnimationFrame(analyzeLiveness);
        return;
      }

      const canvas = motionCanvasRef.current;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) {
        animFrameIdRef.current = requestAnimationFrame(analyzeLiveness);
        return;
      }

      const sampleW = 64;
      const sampleH = 64;
      canvas.width = sampleW;
      canvas.height = sampleH;

      ctx.drawImage(video, 0, 0, sampleW, sampleH);
      const currentFrame = ctx.getImageData(0, 0, sampleW, sampleH).data;

      if (prevFrameDataRef.current) {
        const prev = prevFrameDataRef.current;
        let diffPixels = 0;
        let totalBrightnessDiff = 0;

        // Sample center 60% of frame (face area)
        for (let y = 10; y < sampleH - 10; y++) {
          for (let x = 10; x < sampleW - 10; x++) {
            const idx = (y * sampleW + x) * 4;
            const rDiff = Math.abs(currentFrame[idx] - prev[idx]);
            const gDiff = Math.abs(currentFrame[idx + 1] - prev[idx + 1]);
            const bDiff = Math.abs(currentFrame[idx + 2] - prev[idx + 2]);
            const delta = (rDiff + gDiff + bDiff) / 3;

            if (delta > 10) {
              diffPixels++;
              totalBrightnessDiff += delta;
            }
          }
        }

        const activeAreaPixels = (sampleW - 20) * (sampleH - 20);
        const motionRatio = diffPixels / activeAreaPixels;
        const now = Date.now();
        const timeInStep = now - stepStartTimeRef.current;

        // Check if motion is completely ZERO (indicates someone placed a printed photo on a stand)
        if (motionRatio < 0.002) {
          consecutiveZeroMotionFramesRef.current++;
          if (consecutiveZeroMotionFramesRef.current > 60 && timeInStep > 3000) {
            setIsSpoofSuspected(true);
            setFeedbackMessage('⚠️ কোনো নড়াচড়া পাওয়া যাচ্ছে না! স্থির ছবি নয়, আসল মানুষ হিসেবে পলক ফেলুন');
          }
        } else {
          consecutiveZeroMotionFramesRef.current = Math.max(0, consecutiveZeroMotionFramesRef.current - 2);
          if (consecutiveZeroMotionFramesRef.current < 20) {
            setIsSpoofSuspected(false);
          }
        }

        // STEP 1: ALIGN (Verify natural face presence and initial composure)
        if (currentStep === 'align') {
          if (motionRatio < 0.40 && motionRatio > 0.003) {
            consecutiveStillFramesRef.current++;
            if (consecutiveStillFramesRef.current > 12 && timeInStep > 1000) {
              playBeep(659.25, 0.1);
              setCurrentStep('blink');
              setStepProgress(45);
              setFeedbackMessage('👀 এবার চোখের পলক ফেলুন (চোখ পিটপিট করুন)');
              speakInstruction('এবার চোখের পলক ফেলুন');
              stepStartTimeRef.current = Date.now();
              consecutiveStillFramesRef.current = 0;
              consecutiveMotionFramesRef.current = 0;
            }
          } else {
            consecutiveStillFramesRef.current = Math.max(0, consecutiveStillFramesRef.current - 1);
          }
        }

        // STEP 2: BLINK / EYE FLUTTER (Micro-motion burst in facial zone)
        else if (currentStep === 'blink') {
          // A blink produces a distinct micro-burst of motion (0.025 to 0.45)
          if (motionRatio > 0.025 && motionRatio < 0.50) {
            consecutiveMotionFramesRef.current++;
            if (consecutiveMotionFramesRef.current >= 3 && timeInStep > 700) {
              playBeep(783.99, 0.12);
              setCurrentStep('turn');
              setStepProgress(75);
              setFeedbackMessage('🔄 এবার মাথা সামান্য ডানে অথবা বামে ঘোরান');
              speakInstruction('মাথা সামান্য ডানে বা বামে ঘোরান');
              stepStartTimeRef.current = Date.now();
              consecutiveMotionFramesRef.current = 0;
            }
          }

          // Gentle reminder if taking longer than 4.5s
          if (timeInStep > 4500 && timeInStep < 4600) {
            speakInstruction('দয়া করে ক্যামেরার দিকে তাকিয়ে দুইবার চোখের পলক ফেলুন');
          }
        }

        // STEP 3: TURN HEAD (3D angular movement vs 2D flat paper)
        else if (currentStep === 'turn') {
          if (motionRatio > 0.05 && motionRatio < 0.65) {
            consecutiveMotionFramesRef.current++;
            if (consecutiveMotionFramesRef.current >= 4 && timeInStep > 600) {
              playBeep(880.00, 0.12);
              setCurrentStep('smile');
              setStepProgress(90);
              setFeedbackMessage('😊 চমৎকার! এবার সোজা তাকিয়ে মৃদু হাসুন (অটো ক্যাপচার হবে)');
              speakInstruction('চমৎকার! এবার সোজা তাকিয়ে মৃদু হাসুন');
              stepStartTimeRef.current = Date.now();
              consecutiveMotionFramesRef.current = 0;
              setAutoCaptureCountdown(2);
            }
          }
          if (timeInStep > 5000 && timeInStep < 5100) {
            speakInstruction('মাথা সামান্য ডানে বা বামে ঘুরিয়ে আবার সোজা করুন');
          }
        }

        // STEP 4: SMILE & STRICT AUTO-CAPTURE (No manual bypass!)
        else if (currentStep === 'smile') {
          if (timeInStep > 1200) {
            setAutoCaptureCountdown(1);
          }
          if (timeInStep > 1800) {
            // STRICT AUTO-CAPTURE FIRES AUTOMATICALLY!
            setAutoCaptureCountdown(null);
            setCurrentStep('success');
            setStepProgress(100);
            setFeedbackMessage('✅ বায়োমেট্রিক অটো-ক্যাপচার সফল হয়েছে!');
            playSuccessChime();
            speakInstruction('লাইভ ভেরিফিকেশন সফল হয়েছে, স্বয়ংক্রিয়ভাবে ছবি গ্রহণ করা হয়েছে!');

            const photo = captureFrame();
            if (photo) {
              setCapturedImage(photo);
            }
          }
        }
      }

      prevFrameDataRef.current = currentFrame;
      animFrameIdRef.current = requestAnimationFrame(analyzeLiveness);
    };

    animFrameIdRef.current = requestAnimationFrame(analyzeLiveness);

    return () => {
      isRunning = false;
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [streamActive, currentStep, captureFrame, speakInstruction, playBeep, playSuccessChime]);

  // Initial Camera Start on mount
  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, [startCamera, stopCamera]);

  // Handle final submission
  const handleConfirmPhoto = () => {
    if (capturedImage) {
      onCapture(capturedImage);
    }
  };

  // Retake verification
  const handleRetake = () => {
    setCapturedImage(null);
    setCurrentStep('align');
    setStepProgress(20);
    setIsSpoofSuspected(false);
    setAutoCaptureCountdown(null);
    stepStartTimeRef.current = Date.now();
    setFeedbackMessage('ক্যামেরার বৃত্তের মাঝে আপনার মুখ রাখুন এবং স্থির থাকুন');
    speakInstruction('ক্যামেরার বৃত্তের মাঝে আপনার মুখ রাখুন');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white max-w-md w-full rounded-3xl overflow-hidden shadow-2xl border border-[#E6E0D4] flex flex-col max-h-[95vh]">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#1B365D] via-[#24487A] to-[#1E5C46] text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-white border border-white/30 shrink-0">
              <ShieldCheck className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm sm:text-base text-white">{title}</h3>
                <span className="bg-emerald-500/30 text-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-400/40">
                  অটো-ক্যাপচার
                </span>
              </div>
              <p className="text-[11px] text-white/80 line-clamp-1">{subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {/* Bengali Voice Toggle */}
            <button
              type="button"
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              className={`p-2 rounded-xl border transition cursor-pointer ${
                voiceEnabled 
                  ? 'bg-white/20 text-white border-white/30' 
                  : 'bg-black/20 text-white/50 border-white/10'
              }`}
              title={voiceEnabled ? 'বাংলা ভয়েস চালু আছে' : 'ভয়েস বন্ধ আছে'}
            >
              {voiceEnabled ? <Volume2 className="w-4 h-4 text-emerald-300" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {onCancel && (
              <button
                type="button"
                onClick={() => {
                  stopCamera();
                  onCancel();
                }}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Step Progress Bar */}
        <div className="w-full bg-gray-100 h-1.5 overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-[#2D5A27] via-[#27AE60] to-emerald-400 transition-all duration-500"
            style={{ width: `${stepProgress}%` }}
          />
        </div>

        {/* Anti-Cheat / Strict Auto-Verification Security Notice */}
        <div className="bg-emerald-50/80 px-4 py-2 border-b border-emerald-100 flex items-center justify-between text-[11px] text-emerald-950">
          <span className="flex items-center gap-1.5 font-bold">
            <Scan className="w-3.5 h-3.5 text-emerald-700 animate-spin" style={{ animationDuration: '4s' }} />
            <span>জীবন্ত মানুষ যাচাই ও স্বয়ংক্রিয় ক্যাপচার সক্রিয়</span>
          </span>
          <span className="bg-white/80 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-200">
            হাতে তোলা নিষিদ্ধ
          </span>
        </div>

        {/* Camera Stage Container */}
        <div className="p-4 sm:p-5 flex-1 overflow-y-auto space-y-4">
          {cameraError ? (
            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-5 text-center space-y-3">
              <AlertCircle className="w-10 h-10 text-rose-600 mx-auto" />
              <div className="space-y-1">
                <h4 className="font-bold text-sm text-rose-900">ক্যামেরা ব্যবহারে সমস্যা</h4>
                <p className="text-xs text-rose-700 leading-relaxed">{cameraError}</p>
              </div>
              <button
                type="button"
                onClick={startCamera}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition cursor-pointer shadow-xs"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>আবার চেষ্টা করুন</span>
              </button>
            </div>
          ) : capturedImage && currentStep === 'success' ? (
            /* Success Snapshot Preview (Only shown after real AI biometric validation!) */
            <div className="space-y-4 text-center animate-in zoom-in-95 duration-300">
              <div className="relative w-56 h-56 mx-auto rounded-full overflow-hidden border-4 border-emerald-500 shadow-xl bg-black">
                <img 
                  src={capturedImage} 
                  alt="Verified Live Face" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/70 via-transparent to-transparent flex items-end justify-center pb-3">
                  <span className="bg-emerald-600 text-white text-[11px] font-bold px-3 py-0.5 rounded-full shadow-md flex items-center gap-1.5 border border-emerald-300/50">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-200" />
                    <span>১০০% আসল মানুষ যাচাইকৃত</span>
                  </span>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3.5 text-xs text-emerald-900 space-y-1 text-left">
                <p className="font-bold flex items-center gap-1.5 text-emerald-800">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>বায়োমেট্রিক অটো-ক্যাপচার সফলভাবে সম্পন্ন হয়েছে</span>
                </p>
                <p className="text-[11px] text-emerald-700 leading-relaxed">
                  চোখের পলক ও মুখের ত্রিমাত্রিক নড়াচড়া যাচাই করে সিস্টেমটি স্বয়ংক্রিয়ভাবে ছবিটি তুলেছে। কোনো স্থির ছবি বা ভুয়া ছবি দেওয়ার সুযোগ নেই।
                </p>
              </div>
            </div>
          ) : (
            /* Live Camera Feed with Biometric Face Ring Overlay */
            <div className="space-y-3">
              <div className="relative w-full aspect-square max-w-[320px] mx-auto rounded-3xl overflow-hidden bg-black shadow-inner flex items-center justify-center">
                {/* Hidden Canvas for motion analysis */}
                <canvas ref={motionCanvasRef} className="hidden" />
                <canvas ref={canvasRef} className="hidden" />

                {/* Live Video Feed */}
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover scale-x-[-1]"
                />

                {/* Circular Face Guide Mask */}
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  <div className={`relative w-56 h-56 sm:w-64 sm:h-64 rounded-full border-4 transition-all duration-300 flex items-center justify-center shadow-[0_0_0_9999px_rgba(0,0,0,0.50)] ${
                    currentStep === 'success' 
                      ? 'border-emerald-500 shadow-[0_0_30px_rgba(16,185,129,0.8)]' 
                      : currentStep === 'smile'
                      ? 'border-amber-400 shadow-[0_0_25px_rgba(251,191,36,0.7)] animate-pulse'
                      : currentStep === 'turn'
                      ? 'border-blue-400 shadow-[0_0_20px_rgba(96,165,250,0.6)]'
                      : currentStep === 'blink'
                      ? 'border-purple-400 shadow-[0_0_20px_rgba(192,132,252,0.6)] animate-pulse'
                      : isSpoofSuspected
                      ? 'border-rose-500 shadow-[0_0_20px_rgba(239,68,68,0.7)]'
                      : 'border-white/90 shadow-[0_0_15px_rgba(255,255,255,0.4)]'
                  }`}>
                    {/* Top Guide Indicator Icon */}
                    <div className="absolute -top-3.5 bg-white text-gray-800 text-[10px] font-bold px-3 py-0.5 rounded-full shadow-md flex items-center gap-1 border border-gray-200">
                      {currentStep === 'align' && <><span>👤</span> সোজা তাকিয়ে থাকুন</>}
                      {currentStep === 'blink' && <><Eye className="w-3 h-3 text-purple-600" /> চোখের পলক ফেলুন</>}
                      {currentStep === 'turn' && <><span>🔄</span> মাথা ডানে/বামে নাড়ান</>}
                      {currentStep === 'smile' && <><Smile className="w-3 h-3 text-amber-500" /> মৃদু হাসুন (অটো ক্যাপচার)</>}
                    </div>

                    {/* Auto-capture Countdown Overlay */}
                    {currentStep === 'smile' && autoCaptureCountdown !== null && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-full">
                        <span className="text-white font-black text-4xl drop-shadow-lg animate-ping">
                          {autoCaptureCountdown}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Audio Waves / Voice Prompt Badge */}
                {voiceEnabled && (
                  <div className="absolute bottom-3 left-3 bg-black/70 backdrop-blur-sm text-emerald-300 text-[10px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1.5 border border-emerald-500/30">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span>বাংলা ভয়েস সক্রিয়</span>
                  </div>
                )}

                {/* Auto Scanning Indicator */}
                <div className="absolute bottom-3 right-3 bg-black/70 backdrop-blur-sm text-white/90 text-[10px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1.5 border border-white/20">
                  <Sparkles className="w-3 h-3 text-amber-300" />
                  <span>অটো স্ক্যান</span>
                </div>
              </div>

              {/* Dynamic Live Instructions Banner */}
              <div className={`p-3.5 rounded-2xl border text-center transition-all duration-300 space-y-1 ${
                isSpoofSuspected
                  ? 'bg-rose-50 border-rose-200 text-rose-900 animate-pulse'
                  : currentStep === 'blink' 
                  ? 'bg-purple-50 border-purple-200 text-purple-900'
                  : currentStep === 'turn'
                  ? 'bg-blue-50 border-blue-200 text-blue-900'
                  : currentStep === 'smile'
                  ? 'bg-amber-50 border-amber-200 text-amber-900'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              }`}>
                <div className="text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5">
                  {isSpoofSuspected ? (
                    <span className="flex items-center gap-1 text-rose-700">
                      <AlertTriangle className="w-4 h-4" />
                      স্থির ছবি শনাক্ত হয়েছে!
                    </span>
                  ) : (
                    <>
                      {currentStep === 'align' && <span>👤 ধাপ ১: মুখ বৃত্তের মাঝে রাখুন</span>}
                      {currentStep === 'blink' && <span>👀 ধাপ ২: চোখের পলক ফেলুন (Blink)</span>}
                      {currentStep === 'turn' && <span>🔄 ধাপ ৩: মাথা সামান্য ডানে-বামে ঘোরান</span>}
                      {currentStep === 'smile' && <span>😊 ধাপ ৪: সোজা তাকিয়ে মৃদু হাসুন</span>}
                    </>
                  )}
                </div>
                <p className="text-[11px] opacity-90 leading-relaxed font-medium">
                  {feedbackMessage}
                </p>
              </div>
            </div>
          )}

          {/* 4 Interactive Visual Checkpoints Badge List */}
          <div className="grid grid-cols-4 gap-1.5 text-center text-[10px] font-semibold">
            <div className={`p-2 rounded-xl border transition ${
              currentStep !== 'align' 
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold' 
                : 'bg-blue-50 text-blue-800 border-blue-300 font-bold'
            }`}>
              <div className="text-xs mb-0.5">👤</div>
              <span>সোজা মুখ</span>
            </div>
            <div className={`p-2 rounded-xl border transition ${
              currentStep === 'turn' || currentStep === 'smile' || currentStep === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold' 
                : currentStep === 'blink'
                ? 'bg-purple-50 text-purple-800 border-purple-300 font-bold ring-1 ring-purple-300'
                : 'bg-gray-50 text-gray-400 border-gray-200'
            }`}>
              <div className="text-xs mb-0.5">👀</div>
              <span>পলক ফেলা</span>
            </div>
            <div className={`p-2 rounded-xl border transition ${
              currentStep === 'smile' || currentStep === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold' 
                : currentStep === 'turn'
                ? 'bg-blue-50 text-blue-800 border-blue-300 font-bold ring-1 ring-blue-300'
                : 'bg-gray-50 text-gray-400 border-gray-200'
            }`}>
              <div className="text-xs mb-0.5">🔄</div>
              <span>মাথা ঘোরানো</span>
            </div>
            <div className={`p-2 rounded-xl border transition ${
              currentStep === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold' 
                : currentStep === 'smile'
                ? 'bg-amber-50 text-amber-800 border-amber-300 font-bold ring-1 ring-amber-300'
                : 'bg-gray-50 text-gray-400 border-gray-200'
            }`}>
              <div className="text-xs mb-0.5">😊</div>
              <span>অটো ক্যাপচার</span>
            </div>
          </div>
        </div>

        {/* Modal Action Footer - STRICTLY AUTOMATED, NO MANUAL BUTTON */}
        <div className="p-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between gap-2.5">
          {capturedImage && currentStep === 'success' ? (
            <>
              <button
                type="button"
                onClick={handleRetake}
                className="px-4 py-2.5 bg-white border border-gray-300 hover:bg-gray-100 text-gray-700 text-xs font-bold rounded-2xl transition cursor-pointer flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>পুনরায় ভেরিফাই করুন</span>
              </button>

              <button
                type="button"
                onClick={handleConfirmPhoto}
                className="flex-1 py-3 bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs sm:text-sm font-bold rounded-2xl transition cursor-pointer flex items-center justify-center gap-2 shadow-md hover:shadow-lg"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                <span>যাচাইকৃত ছবি গ্রহণ করুন</span>
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => {
                  stopCamera();
                  onCancel?.();
                }}
                className="px-4 py-2.5 bg-white border border-gray-300 hover:bg-gray-100 text-gray-700 text-xs font-bold rounded-2xl transition cursor-pointer shrink-0"
              >
                বাতিল করুন
              </button>

              {/* Automated AI Status Indicator - NO MANUAL CLICK BYPASS */}
              <div className="flex-1 py-2.5 px-3 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-center gap-2 text-[#1E5C46]">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping shrink-0" />
                <span className="text-[11px] sm:text-xs font-bold text-center leading-tight">
                  {currentStep === 'smile' ? 'ছবি স্বয়ংক্রিয়ভাবে উঠছে...' : 'অটো ভেরিফিকেশন চলছে (নির্দেশনা মানুন)'}
                </span>
              </div>
            </>
          )}
        </div>

      </div>
    </div>
  );
};
