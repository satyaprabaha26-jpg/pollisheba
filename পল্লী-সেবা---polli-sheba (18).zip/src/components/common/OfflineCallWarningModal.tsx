import React from 'react';
import { 
  AlertTriangle, 
  PhoneCall, 
  MessageSquare, 
  ShieldAlert, 
  X, 
  Smartphone,
  Check,
  Radio,
  Lock,
  ShieldCheck
} from 'lucide-react';

export interface OfflineCallWarningModalProps {
  isOpen: boolean;
  phoneNumber: string;
  recipientName?: string;
  recipientRole?: string;
  allowOfflineCall?: boolean;
  onProceedOfflineCall?: () => void;
  onProceed?: () => void;
  onOpenOnlineChat?: () => void;
  onOnlineVoiceCall?: () => void;
  onCancel?: () => void;
  onClose?: () => void;
}

export const OfflineCallWarningModal: React.FC<OfflineCallWarningModalProps> = ({
  isOpen,
  phoneNumber,
  recipientName,
  recipientRole,
  allowOfflineCall = true,
  onProceedOfflineCall,
  onProceed,
  onOpenOnlineChat,
  onOnlineVoiceCall,
  onCancel,
  onClose
}) => {
  if (!isOpen) return null;

  const handleCancel = () => {
    if (onCancel) onCancel();
    else if (onClose) onClose();
  };

  const handleProceed = () => {
    if (!allowOfflineCall) return;
    if (onProceedOfflineCall) onProceedOfflineCall();
    else if (onProceed) onProceed();
  };

  return (
    <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-150">
      <div className={`bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 border-2 ${
        !allowOfflineCall ? 'border-rose-400' : 'border-amber-400'
      }`}>
        
        {/* Header */}
        <div className="flex items-start justify-between gap-3 border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-xs border ${
              !allowOfflineCall 
                ? 'bg-rose-50 border-rose-300 text-rose-600' 
                : 'bg-amber-50 border-amber-300 text-amber-600'
            }`}>
              {!allowOfflineCall ? (
                <ShieldAlert className="w-6 h-6 text-rose-600" />
              ) : (
                <AlertTriangle className="w-6 h-6 text-amber-600" />
              )}
            </div>
            <div>
              <span className={`text-[10px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded-md border ${
                !allowOfflineCall
                  ? 'bg-rose-100 text-rose-800 border-rose-300'
                  : 'bg-amber-100 text-amber-800 border-amber-300'
              }`}>
                {!allowOfflineCall ? '🔒 অফলাইন কল নিষিদ্ধ' : '⚠️ গোপনীয়তা ও ডায়ালার সতর্কতা'}
              </span>
              <h3 className="font-bold text-base text-[#2D3A3A] mt-0.5">
                {!allowOfflineCall ? 'অফলাইন কল সীমাবদ্ধতা' : 'সরাসরি অফলাইন কল নিশ্চিতকরণ'}
              </h3>
            </div>
          </div>
          <button
            onClick={handleCancel}
            className="text-[#736B5E] hover:text-[#2D3A3A] p-1.5 rounded-full hover:bg-gray-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Recipient Details */}
        {recipientName && (
          <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] flex items-center justify-between text-xs">
            <span className="text-[#736B5E]">কল প্রাপক:</span>
            <span className="font-bold text-[#2D5A27]">
              {recipientName} {recipientRole ? `(${recipientRole})` : ''}
            </span>
          </div>
        )}

        {/* CONDITION 1: DISALLOWED CASE */}
        {!allowOfflineCall ? (
          <div className="space-y-4">
            <div className="bg-rose-50 border-2 border-rose-300 p-4 rounded-2xl space-y-2">
              <div className="flex items-start gap-2.5 text-rose-950">
                <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-xs sm:text-sm leading-relaxed font-bold text-rose-900">
                    সম্মানিত ব্যবহারকারী অফলাইনে কলের অনুমতি দেননি, তাই অফলাইন কল করা সম্ভব নয়।
                  </p>
                  <p className="text-[11px] text-rose-700">
                    ব্যবহারকারীর প্রাইভেসির স্বার্থে তার সরাসরি ফোন নম্বর সুরক্ষিত রাখা হয়েছে। আপনি চাইলে নিচে ইন-অ্যাপ ইন্টারনেট অডিও কল বা অনলাইন চ্যাট করতে পারেন।
                  </p>
                </div>
              </div>
            </div>

            {/* In-app secure alternatives */}
            <div className="space-y-2">
              {onOnlineVoiceCall && (
                <button
                  type="button"
                  onClick={() => {
                    handleCancel();
                    onOnlineVoiceCall();
                  }}
                  className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 px-4 rounded-2xl text-xs sm:text-sm shadow-xs transition flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                >
                  <Radio className="w-4 h-4 text-emerald-300" />
                  <span>ইন-অ্যাপ অডিও কল করুন (১০০% সুরক্ষিত ও ফ্রি)</span>
                </button>
              )}

              {onOpenOnlineChat && (
                <button
                  type="button"
                  onClick={() => {
                    handleCancel();
                    onOpenOnlineChat();
                  }}
                  className="w-full bg-[#FAF8F5] hover:bg-[#E6E0D4] text-[#2D3A3A] border border-[#D4C3A3] font-bold py-2.5 px-4 rounded-2xl text-xs shadow-xs transition flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                >
                  <MessageSquare className="w-4 h-4 text-[#2D5A27]" />
                  <span>অনলাইন চ্যাট করুন (নম্বর সম্পূর্ণ গোপন)</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleCancel}
                className="w-full text-center text-xs font-bold text-[#736B5E] hover:text-[#2D3A3A] bg-gray-100 hover:bg-gray-200 py-2.5 px-4 rounded-2xl transition cursor-pointer"
              >
                বুঝেছি / বন্ধ করুন
              </button>
            </div>
          </div>
        ) : (
          /* CONDITION 2: ALLOWED CASE */
          <div className="space-y-4">
            <div className="bg-amber-50 border-2 border-amber-300 p-4 rounded-2xl space-y-2">
              <div className="flex items-start gap-2.5 text-amber-950">
                <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-xs sm:text-sm leading-relaxed font-bold text-amber-900">
                    অফলাইনে কল করলে আপনার ব্যক্তিগত ফোন নম্বরটি অপরপ্রান্তে দৃশ্যমান হবে। আপনি কি কল করতে চান?
                  </p>
                  <p className="text-[11px] text-amber-800">
                    সিস্টেম ডায়ালারে যাওয়ার পর আপনার সাধারণ সিম ব্যালেন্স থেকে অপারেটর চার্জ প্রযোজ্য হতে পারে।
                  </p>
                </div>
              </div>
            </div>

            {/* In-app voice alternative suggestion */}
            {onOnlineVoiceCall && (
              <div 
                onClick={() => {
                  handleCancel();
                  onOnlineVoiceCall();
                }}
                className="bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 p-2.5 rounded-2xl flex items-center justify-between gap-2 cursor-pointer transition"
              >
                <div className="flex items-center gap-2 text-emerald-900 text-xs font-semibold">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>নম্বর গোপন রাখতে চান? ইন-অ্যাপ অডিও কল দিন</span>
                </div>
                <span className="text-[11px] font-bold text-emerald-700 underline shrink-0">কল দিন</span>
              </div>
            )}

            {/* Confirmation Buttons: [হ্যাঁ] and [না / বাতিল] */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={handleCancel}
                className="w-full text-center text-xs font-bold text-[#736B5E] hover:text-[#2D3A3A] bg-[#FAF8F5] hover:bg-[#E6E0D4] border border-[#E6E0D4] py-2.5 px-4 rounded-2xl transition cursor-pointer"
              >
                না, বাতিল করুন
              </button>

              <button
                type="button"
                onClick={handleProceed}
                className="w-full bg-[#27AE60] hover:bg-[#219653] text-white font-bold py-2.5 px-4 rounded-2xl text-xs transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs active:scale-98"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>হ্যাঁ, কল করুন</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
