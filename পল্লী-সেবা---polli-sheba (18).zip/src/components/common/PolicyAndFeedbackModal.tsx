import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Mail, 
  Phone, 
  Send, 
  Check, 
  FileText, 
  AlertCircle, 
  HeartHandshake,
  MessageSquareHeart,
  Lock,
  Globe,
  UserCheck,
  AlertTriangle,
  PhoneOff,
  Share2
} from 'lucide-react';

interface PolicyAndFeedbackModalProps {
  initialTab?: 'policy' | 'feedback';
  onClose: () => void;
}

export const PolicyAndFeedbackModal: React.FC<PolicyAndFeedbackModalProps> = ({ 
  initialTab = 'policy', 
  onClose 
}) => {
  const [activeTab, setActiveTab] = useState<'policy' | 'feedback'>(initialTab);
  const [lang, setLang] = useState<'bn' | 'en'>('bn');
  
  // Feedback Form State
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState('পরামর্শ ও মতামত');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message) return;

    // Save locally for citizen feedbacks
    const feedbackList = JSON.parse(localStorage.getItem('polli_citizen_feedbacks') || '[]');
    const newFeedback = {
      id: `fb-${Date.now()}`,
      name: name || 'বেনামী নাগরিক',
      phone: phone || '০১xxxxxxxxx',
      email: email || undefined,
      category: (category.includes('অভিযোগ') ? 'অভিযোগ' : category.includes('পরামর্শ') ? 'পরামর্শ' : 'অন্যান্য') as any,
      message,
      createdAt: new Date().toLocaleDateString('bn-BD'),
      status: 'নতুন' as const
    };

    localStorage.setItem('polli_citizen_feedbacks', JSON.stringify([newFeedback, ...feedbackList]));

    // Construct Mailto for direct communication to owner
    const subject = encodeURIComponent(`পল্লী সেবা মতামত: ${category} - ${name || 'ব্যবহারকারী'}`);
    const body = encodeURIComponent(
      `নাম: ${name || 'বেনামী'}\nফোন: ${phone || 'নাই'}\nইমেইল: ${email || 'নাই'}\nবিষয়: ${category}\n\nমতামত/অভিযোগ:\n${message}`
    );
    
    setIsSubmitted(true);

    try {
      window.location.href = `mailto:polliseba26@gmail.com?subject=${subject}&body=${body}`;
    } catch (e) {}
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali']">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150 space-y-4">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2">
            {activeTab === 'policy' ? (
              <ShieldCheck className="w-6 h-6 text-[#2D5A27]" />
            ) : (
              <MessageSquareHeart className="w-6 h-6 text-[#E8924A]" />
            )}
            <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A]">
              {activeTab === 'policy' ? (
                lang === 'bn' ? 'ব্যবহারের শর্তাবলী, দায়মুক্তি ও প্রাইভেসী' : 'Terms of Service, Disclaimer & Privacy'
              ) : 'উদ্যোক্তাকে মতামত ও পরামর্শ দিন'}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {activeTab === 'policy' && (
              <div className="bg-[#FAF8F5] p-0.5 rounded-xl border border-[#D4C3A3] flex items-center gap-1">
                <button
                  onClick={() => setLang('bn')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                    lang === 'bn' ? 'bg-[#2D5A27] text-white' : 'text-[#5A6B6B]'
                  }`}
                >
                  বাংলা
                </button>
                <button
                  onClick={() => setLang('en')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                    lang === 'en' ? 'bg-[#2D5A27] text-white' : 'text-[#5A6B6B]'
                  }`}
                >
                  <Globe className="w-3 h-3" />
                  <span>EN</span>
                </button>
              </div>
            )}

            <button
              onClick={onClose}
              className="text-[#736B5E] hover:text-[#2D3A3A] text-lg font-bold cursor-pointer p-1"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex gap-2 bg-[#FDFBF7] p-1.5 rounded-2xl border border-[#E6E0D4]">
          <button
            onClick={() => setActiveTab('policy')}
            className={`flex-1 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'policy'
                ? 'bg-[#2D5A27] text-white shadow-xs'
                : 'text-[#2D3A3A] hover:bg-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>শর্তাবলী ও প্রাইভেসী</span>
          </button>

          <button
            onClick={() => setActiveTab('feedback')}
            className={`flex-1 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'feedback'
                ? 'bg-[#E8924A] text-white shadow-xs'
                : 'text-[#2D3A3A] hover:bg-white'
            }`}
          >
            <MessageSquareHeart className="w-4 h-4" />
            <span>মতামত ও যোগাযোগ</span>
          </button>
        </div>

        {/* TAB 1: POLICY */}
        {activeTab === 'policy' && (
          <div className="space-y-4 text-xs sm:text-sm text-[#2D3A3A] leading-relaxed">
            {lang === 'bn' ? (
              <>
                {/* ১. সেবার ধরন ও উদ্দেশ্য */}
                <div className="bg-[#D4E4BC]/30 border border-[#D4E4BC] p-4 rounded-2xl">
                  <h4 className="font-bold text-[#2D5A27] text-sm mb-1.5 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#2D5A27]" />
                    <span>১. সেবার ধরন ও উদ্দেশ্য</span>
                  </h4>
                  <p className="text-[#3E4D4D] text-xs sm:text-sm">
                    "পল্লী সেবা" একটি স্বাধীন, অলাভজনক এবং তথ্যপ্রযুক্তিভিত্তিক ডিজিটাল প্ল্যাটফর্ম। এই অ্যাপের প্রধান উদ্দেশ্য হলো গ্রামীণ নাগরিক, কৃষক, শ্রমিক, চালক, কারিগর ও সেবাগ্রহীতাদের মধ্যে পারস্পরিক যোগাযোগের তথ্যগত সংযোগ ঘটানো। <strong>অ্যাপ কর্তৃপক্ষ নিজে কোনো পণ্য কেনাবেচা করে না, কোনো যানবাহনের মালিক নয় এবং কোনো প্রকার নিয়োগকর্তা বা আর্থিক লেনদেনকারী প্রতিষ্ঠান নয়।</strong>
                  </p>
                </div>

                {/* ২. পরিচয় সুরক্ষা ও গোপনীয়তা */}
                <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] space-y-1.5">
                  <h4 className="font-bold text-[#2D5A27] flex items-center gap-1.5 text-sm">
                    <Lock className="w-4 h-4 text-[#E8924A]" />
                    <span>২. পরিচয় সুরক্ষা ও গোপনীয়তা</span>
                  </h4>
                  <ul className="space-y-1 text-xs text-[#3E4D4D] list-disc list-inside">
                    <li>ব্যবহারকারীর মোবাইল নম্বর সুরক্ষিত রাখতে এবং অনাকাঙ্ক্ষিত কল এড়াতে অ্যাপের অভ্যন্তরে সুরক্ষিত কল (Masked Call) প্রযুক্তি ব্যবহারের সুবিধা রাখা হয়েছে।</li>
                    <li>ব্যবহারকারীর ব্যক্তিগত তথ্য কোনো বাণিজ্যিক বিজ্ঞাপনী প্রতিষ্ঠানের কাছে বিক্রি বা বিনিময় করা হয় না।</li>
                    <li>নিবন্ধনের জন্য ব্যবহৃত ওটিপি (OTP) ভেরিফাইড ডেটা আমাদের কেন্দ্রীয় ডেটাবেজে সম্পূর্ণ সুরক্ষিত রাখা হয়।</li>
                  </ul>
                </div>

                {/* ৩. সম্পূর্ণ দায়মুক্তি (Absolute Disclaimer) */}
                <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] space-y-2.5">
                  <h4 className="font-bold text-[#C0392B] flex items-center gap-1.5 text-sm border-b border-[#E6E0D4] pb-2">
                    <AlertTriangle className="w-4 h-4 text-[#C0392B]" />
                    <span>৩. সম্পূর্ণ দায়মুক্তি (Absolute Disclaimer)</span>
                  </h4>
                  <ul className="space-y-2.5 text-xs text-[#3E4D4D]">
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#C0392B] font-bold mt-0.5">•</span>
                      <div><strong>পণ্য কেনাবেচা (পল্লী হাট ও বাজারদর):</strong> পণ্যের সঠিক মান, সতেজতা, ওজন এবং টাকা লেনদেনের সম্পূর্ণ দায়িত্ব ক্রেতা ও বিক্রেতার। কোনো প্রকার অগ্রিম টাকা দেওয়ার আগে সরজমিনে পণ্য দেখে নেওয়ার অনুরোধ করা হচ্ছে। অ্যাপে প্রদর্শিত দৈনিক কৃষি বাজারদর কেবল ধারণামূলক তথ্য।</div>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#C0392B] font-bold mt-0.5">•</span>
                      <div><strong>শ্রমিক ও কৃষাণ নিয়োগ:</strong> "শ্রমিকদের গায়ের ঘাম শুকানোর আগেই তাদের মজুরি পরিশোধ করার চেষ্টা করুন।" (সুনানে ইবনে মাজাহ: ২৪৪৩)। তবে কোনো শ্রমিকের বকেয়া মজুরি আদায় বা শ্রম বিরোধ মীমাংসায় অ্যাপ কর্তৃপক্ষ আইনত বাধ্য নয়। যেকোনো শ্রম বিরোধে সরকারি জাতীয় শ্রম হেল্পলাইন <strong>১৬১৯৯</strong> (16199) এ যোগাযোগ করুন।</div>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#C0392B] font-bold mt-0.5">•</span>
                      <div><strong>পরিবহন যাত্রা, নিরাপত্তা ও লাইভ ট্র্যাকিং:</strong> পরিবহন সেবা বা যাত্রা চলাকালীন কোনো দুর্ঘটনা, মালামাল হারানো বা আর্থিক ক্ষতির দায় অ্যাপ কর্তৃপক্ষ বহন করবে না। যাত্রীর সুরক্ষায় অ্যাপে ব্যবহৃত লাইভ ট্র্যাকিং লিঙ্কটি যাত্রা সম্পন্ন হওয়ার সাথে সাথে স্বয়ংক্রিয়ভাবে নিষ্ক্রিয় হয়ে যাবে।</div>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#C0392B] font-bold mt-0.5">•</span>
                      <div><strong>স্বাস্থ্য ও চিকিৎসা গাইড (হাসপাতাল, ডাক্তার, টিকা ও ফার্স্ট এইড):</strong> অ্যাপে প্রদর্শিত হাসপাতাল তথ্য, ডাক্তারদের চেম্বার, ইপিআই টিকাদান শিডিউল ও জরুরি প্রাথমিক চিকিৎসা (ফার্স্ট এইড) কেবল সাধারণ নাগরিক সচেতনতার জন্য। "পল্লী সেবা" কোনো সরাসরি চিকিৎসা প্রদানকারী প্রতিষ্ঠান নয়। জরুরি চিকিৎসায় তাৎক্ষণিক নিকটস্থ হাসপাতালে যোগাযোগের অনুরোধ করা হচ্ছে।</div>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#C0392B] font-bold mt-0.5">•</span>
                      <div><strong>আইন, সরকারি লিগ্যাল এইড ও থানা/কোর্ট গাইড:</strong> অ্যাপে প্রদর্শিত সরকারি লিগ্যাল এইড (Legal Aid), নির্বাহী ম্যাজিস্ট্রেট কোর্ট ও জজ কোর্ট সংক্রান্ত তথ্য নির্দেশিকামূলক। অ্যাপ কর্তৃপক্ষ কোনো আইনি ফার্ম নয়। যেকোনো দেওয়ানি বা ফৌজদারি মামলায় সরাসরি জেলা জজ কোর্টের সরকারি লিগ্যাল এইড অফিস (হটলাইন: <strong>১৬৪৩০</strong>) বা নিবন্ধিত আইনজীবীর পরামর্শ নিন।</div>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#C0392B] font-bold mt-0.5">•</span>
                      <div><strong>মিস্ত্রি, কারিগর ও গৃহশিক্ষক (টিউটর):</strong> কাজ দেওয়া বা নেওয়ার পূর্বে সংশ্লিষ্ট মিস্ত্রি বা টিউটরের পরিচয় ও কাজের দক্ষতা নিজ দায়িত্বে যাচাই করে নিন। ব্যক্তিগত কোনো অঘটন বা আর্থিক ক্ষতির দায় অ্যাপ বহন করবে না।</div>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#C0392B] font-bold mt-0.5">•</span>
                      <div><strong>কৃষি পরামর্শ, ক্যালকুলেটর ও কিস্তি হিসাব (সার, জমি ও ঋণ):</strong> সার ক্যালকুলেটর, আমিন ক্যালকুলেটর বা কৃষি ঋণ হিসাবকের তথ্যগুলো সাধারণ গাণিতিক ফলাফলের ওপর ভিত্তি করে তৈরি। চূড়ান্ত সিদ্ধান্ত নেওয়ার পূর্বে অনুমোদিত উপজেলা কৃষি অফিসার, স্থানীয় আমিন (সার্ভেয়ার) বা সংশ্লিষ্ট ব্যাংক কর্মকর্তার পরামর্শ নিন।</div>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#C0392B] font-bold mt-0.5">•</span>
                      <div><strong>এআই পল্লী পরামর্শক (AI Assistant):</strong> কৃত্রিম বুদ্ধিমত্তা থেকে প্রাপ্ত উত্তরগুলো প্রযুক্তিভিত্তিক। প্রাপ্ত পরামর্শের বাস্তবিক ব্যবহারের পূর্বে ব্যবহারকারীর নিজ দায়িত্বে এর সত্যতা যাচাই করা উচিত।</div>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#C0392B] font-bold mt-0.5">•</span>
                      <div><strong>আইনি বাধ্যবাধকতা ও ডাটা শেয়ারিং:</strong> অ্যাপে কোনো ফৌজদারি অপরাধ সংঘটিত হলে বা আইনি বাধ্যবাধকতায় কেবল আইন প্রয়োগকারী সংস্থার লিখিত আবেদনের প্রেক্ষিতে সার্ভার লগ ও নিবন্ধিত তথ্য প্রদান করা হবে।</div>
                    </li>
                  </ul>
                </div>

                {/* ৪. অ্যাকাউন্ট বাতিল করার অধিকার */}
                <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] space-y-1">
                  <h4 className="font-bold text-[#2D5A27] flex items-center gap-1.5 text-sm">
                    <UserCheck className="w-4 h-4 text-[#E8924A]" />
                    <span>৪. অ্যাকাউন্ট বাতিল করার অধিকার</span>
                  </h4>
                  <p className="text-[#3E4D4D] text-xs">
                    কোনো ব্যবহারকারী ভুয়া ফোন নম্বর, ভুল তথ্য, অশালীন আচরণ বা বিভ্রান্তিকর বিজ্ঞপ্তি পোস্ট করলে অ্যাপ কর্তৃপক্ষ পূর্বসংকেত ছাড়াই তার অ্যাকাউন্ট বাতিল বা পোস্ট মুছে ফেলার পূর্ণ অধিকার রাখে।
                  </p>
                </div>

                {/* অফিসিয়াল ইমেইল সাপোর্ট */}
                <div className="bg-[#FAF8F5] border-2 border-[#15803D]/40 p-4 rounded-2xl space-y-2">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-[#15803D]" />
                    <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">অফিসিয়াল ইমেইল সাপোর্ট</h5>
                  </div>
                  <p className="text-xs text-[#5A6B6B]">
                    তথ্য সংশোধন, নতুন ইউনিয়ন বা উপজেলা সংযোজন এবং যেকোনো সহায়তার জন্য সরাসরি ওপরের ইমেইলে যোগাযোগ করুন:
                  </p>
                  <div className="flex items-center gap-2 pt-1 flex-wrap">
                    <a
                      href="mailto:polliseba26@gmail.com"
                      className="inline-flex items-center gap-2 bg-gradient-to-r from-[#15803D] via-[#22C55E] to-[#15803D] text-white px-3.5 py-1.5 rounded-xl font-bold text-xs shadow-md transition cursor-pointer border-2 border-emerald-300 animate-pulse tracking-wide"
                      title="ইমেইল পাঠান"
                    >
                      <Mail className="w-3.5 h-3.5 text-white" />
                      <span>polliseba26@gmail.com</span>
                    </a>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="bg-[#D4E4BC]/30 border border-[#D4E4BC] p-4 rounded-2xl">
                  <h4 className="font-bold text-[#2D5A27] text-sm mb-1">
                    1. Nature & Purpose of Service
                  </h4>
                  <p className="text-[#3E4D4D] text-xs">
                    "Polli Sheba" is an independent, non-profit, and information-technology-based digital platform. Its primary mission is to create an informational communication bridge among rural citizens, farmers, laborers, drivers, artisans, and service seekers. <strong>The app authority does not buy or sell goods, does not own any vehicles, and is neither an employer nor a financial transaction entity.</strong>
                  </p>
                </div>

                <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] space-y-1">
                  <h4 className="font-bold text-[#2D5A27] flex items-center gap-1.5 text-sm">
                    <Lock className="w-4 h-4 text-[#E8924A]" />
                    <span>2. Identity Protection & Privacy</span>
                  </h4>
                  <ul className="space-y-1 text-xs text-[#3E4D4D] list-disc list-inside">
                    <li>Masked call technology is provided to protect user phone numbers.</li>
                    <li>User personal data is never sold or shared with commercial entities.</li>
                    <li>OTP-verified registration data is stored securely in our database.</li>
                  </ul>
                </div>

                <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] space-y-1.5">
                  <h4 className="font-bold text-[#C0392B] flex items-center gap-1.5 text-sm border-b border-[#E6E0D4] pb-1.5">
                    <AlertTriangle className="w-4 h-4 text-[#C0392B]" />
                    <span>3. Absolute Disclaimer of Liability</span>
                  </h4>
                  <ul className="space-y-1.5 text-xs text-[#3E4D4D] list-disc list-inside">
                    <li><strong>Marketplace:</strong> Buyer and seller bear sole responsibility for goods quality and payment.</li>
                    <li><strong>Labor:</strong> The platform is not legally bound to recover unpaid wages. For disputes, contact <strong>16199</strong>.</li>
                    <li><strong>Transport:</strong> Zero liability for accidents, transit loss, or damages during travel.</li>
                    <li><strong>Health & Legal Guides:</strong> For informational and civic awareness only. Seek doctors or registered advocates for critical matters.</li>
                    <li><strong>Calculators & AI:</strong> Algorithmic estimations; verify with local agriculture officers.</li>
                    <li><strong>Law Enforcement:</strong> Logs provided only upon official written police requests.</li>
                  </ul>
                </div>

                <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] space-y-1">
                  <h4 className="font-bold text-[#2D5A27] text-sm">
                    4. Right to Terminate Accounts
                  </h4>
                  <p className="text-[#3E4D4D] text-xs">
                    Accounts posting fraudulent information, offensive conduct, or deceptive ads will be terminated immediately.
                  </p>
                </div>

                <div className="bg-[#FAF8F5] border-2 border-[#15803D]/40 p-4 rounded-2xl space-y-2">
                  <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A] flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-[#15803D]" />
                    <span>Official Email Support</span>
                  </h5>
                  <p className="text-xs text-[#5A6B6B]">
                    For info corrections, adding new unions/upazilas, or assistance, reach out directly:
                  </p>
                  <div className="flex items-center gap-2 pt-1 flex-wrap">
                    <a
                      href="mailto:polliseba26@gmail.com"
                      className="inline-flex items-center gap-2 bg-gradient-to-r from-[#15803D] via-[#22C55E] to-[#15803D] text-white px-3.5 py-1.5 rounded-xl font-bold text-xs shadow-md transition border-2 border-emerald-300 animate-pulse tracking-wide"
                    >
                      <Mail className="w-3.5 h-3.5 text-white" />
                      <span>polliseba26@gmail.com</span>
                    </a>
                  </div>
                </div>
              </>
            )}

            <div className="flex justify-end pt-2">
              <button
                onClick={onClose}
                className="bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 px-6 rounded-2xl text-xs cursor-pointer shadow-xs"
              >
                {lang === 'bn' ? 'আমি নীতিমালা বুঝেছি ও সম্মত ✓' : 'I Understand & Agree ✓'}
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: FEEDBACK & CONTACT */}
        {activeTab === 'feedback' && (
          <div>
            {isSubmitted ? (
              <div className="text-center py-8 space-y-3">
                <div className="w-14 h-14 bg-[#D4E4BC] text-[#2D5A27] rounded-full flex items-center justify-center mx-auto">
                  <Check className="w-8 h-8" />
                </div>
                <h3 className="font-bold text-lg text-[#2D3A3A]">
                  আপনার মূল্যবান মতামত গ্রহণ করা হয়েছে!
                </h3>
                <p className="text-xs text-[#736B5E] max-w-md mx-auto">
                  আপনার বার্তাটি পল্লী সেবার কেন্দ্রীয় তথ্যভাণ্ডারে সংরক্ষিত হয়েছে এবং উদ্যোক্তার ইমেইলে প্রেরণ করা হয়েছে। জনকল্যাণে পল্লী সেবার সাথে থাকার জন্য ধন্যবাদ।
                </p>
                <div className="pt-4">
                  <button
                    onClick={onClose}
                    className="bg-[#2D5A27] text-white px-6 py-2.5 rounded-2xl text-xs font-bold shadow-xs cursor-pointer"
                  >
                    সম্পন্ন করুন
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="bg-[#F9E5D4]/40 border border-[#F9E5D4] p-3.5 rounded-2xl text-xs text-[#A65E2E]">
                  💡 <strong>উদ্যোক্তার প্রতি বার্তা:</strong> অ্যাপ সম্পর্কিত কোনো ত্রুটি সংশোধন, নতুন তথ্য সংযোজন বা আপনার এলাকার সেবামূলক তথ্য যুক্ত করার প্রস্তাব থাকলে নিচে লিখে পাঠান।
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                      আপনার নাম (ঐচ্ছিক)
                    </label>
                    <input
                      type="text"
                      placeholder="নাম লিখুন"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                      মোবাইল বা হোয়াটসঅ্যাপ (ঐচ্ছিক)
                    </label>
                    <input
                      type="tel"
                      placeholder="০১৭xxxxxxxx"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                      ইমেইল ঠিকানা (ঐচ্ছিক)
                    </label>
                    <input
                      type="email"
                      placeholder="example@mail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                      বিষয়
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                    >
                      <option value="পরামর্শ ও মতামত">পরামর্শ ও মতামত</option>
                      <option value="নতুন তথ্য বা এলাকা সংযোজন">নতুন তথ্য বা এলাকা সংযোজন</option>
                      <option value="অভিযোগ বা ত্রুটি">অভিযোগ বা ত্রুটি</option>
                      <option value="অন্যান্য">অন্যান্য</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D3A3A] mb-1">
                    আপনার বিস্তারিত বার্তা *
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="আপনার মতামত, পরামর্শ বা যেকোনো অভিযোগ বিস্তারিত লিখুন..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full border border-[#D4C3A3] bg-[#FDFBF7] rounded-2xl p-3 text-xs focus:outline-none focus:border-[#2D5A27] text-[#2D3A3A]"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-[#E6E0D4]">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-[#FAF8F5] border border-[#E6E0D4] cursor-pointer"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-6 py-2 rounded-2xl text-xs font-bold text-white bg-[#E8924A] hover:bg-[#D97D35] shadow-xs cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>মতামত জমা দিন</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
