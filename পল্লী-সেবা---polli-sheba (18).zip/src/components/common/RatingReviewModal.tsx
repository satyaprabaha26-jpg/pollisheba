import React, { useState } from 'react';
import { Star, X, Check, MessageSquare, ShieldCheck, AlertTriangle, Flag } from 'lucide-react';
import { UserProfile } from '../../types/auth';
import { saveCloudCitizenReport } from '../../lib/cloudSync';
import { ReportItemRecord } from '../../types';

export interface ServiceReview {
  id: string;
  targetId: string; // Driver ID, Haat Listing ID, or Service ID
  targetName: string;
  targetType: 'driver' | 'seller' | 'service';
  userId: string;
  userName: string;
  rating: number; // 1 to 5
  comment: string;
  createdAt: string;
  createdAtTimestamp: number;
}

interface RatingReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetId: string;
  targetName: string;
  targetType: 'driver' | 'seller' | 'service';
  currentUser?: UserProfile | null;
  onSuccess: (review: ServiceReview) => void;
}

export const RatingReviewModal: React.FC<RatingReviewModalProps> = ({
  isOpen,
  onClose,
  targetId,
  targetName,
  targetType,
  currentUser,
  onSuccess
}) => {
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [comment, setComment] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Crowd-sourced moderation & complaint state (Requirement 6)
  const [hasComplaint, setHasComplaint] = useState(false);
  const [complaintType, setComplaintType] = useState('ভুল বা বিভ্রান্তিকর তথ্য প্রদান');
  const [complaintDetails, setComplaintDetails] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) return;

    const newReview: ServiceReview = {
      id: `rev-${Date.now()}`,
      targetId,
      targetName,
      targetType,
      userId: currentUser?.id || 'guest-user',
      userName: currentUser?.name || 'পল্লী সেবা নাগরিক',
      rating,
      comment: comment.trim(),
      createdAt: new Date().toLocaleDateString('bn-BD'),
      createdAtTimestamp: Date.now()
    };

    // Save locally
    const savedReviews = JSON.parse(localStorage.getItem('polli_service_reviews') || '[]');
    localStorage.setItem('polli_service_reviews', JSON.stringify([newReview, ...savedReviews]));

    // If user selected complaint or gave <= 2 rating, save to Admin Reports
    if (hasComplaint || rating <= 2) {
      const newReport: ReportItemRecord = {
        id: `rep-${Date.now()}`,
        targetId,
        targetTitle: targetName,
        targetType: targetType === 'driver' ? 'driver' : targetType === 'seller' ? 'listing' : 'other',
        reporterName: currentUser?.name || 'নাগরিক',
        reporterPhone: currentUser?.phone || '০১৭xxxxxxxx',
        reason: hasComplaint ? complaintType : 'অসন্তোষজনক সেবা ও নিম্ন রেটিং',
        details: complaintDetails.trim() || comment.trim(),
        status: 'নতুন',
        createdAt: new Date().toLocaleDateString('bn-BD'),
        createdAtTimestamp: Date.now()
      };
      const savedReports = JSON.parse(localStorage.getItem('polli_reports_list') || '[]');
      localStorage.setItem('polli_reports_list', JSON.stringify([newReport, ...savedReports]));
      saveCloudCitizenReport(newReport);
    }

    // If driver, update driver rating in transport list
    if (targetType === 'driver') {
      try {
        const drivers = JSON.parse(localStorage.getItem('polli_transport_drivers') || '[]');
        const targetDriver = drivers.find((d: any) => d.id === targetId);
        if (targetDriver) {
          const currentCount = targetDriver.totalRatingsCount || 1;
          const currentRating = targetDriver.rating || 5.0;
          const newCount = currentCount + 1;
          const newAvg = Number(((currentRating * currentCount + rating) / newCount).toFixed(1));
          
          targetDriver.rating = newAvg;
          targetDriver.totalRatingsCount = newCount;
          localStorage.setItem('polli_transport_drivers', JSON.stringify(drivers));
        }
      } catch (err) {}
    }

    setIsSubmitted(true);
    setTimeout(() => {
      onSuccess(newReview);
      onClose();
    }, 1000);
  };

  const getRatingLabel = (score: number) => {
    switch (score) {
      case 5: return '🌟 অসাধারণ ও প্রশংসনীয়!';
      case 4: return '👍 খুব ভালো ও সন্তোষজনক';
      case 3: return '👌 মোটামুটি ভালো';
      case 2: return '⚠️ প্রত্যাশার চেয়ে কম';
      case 1: return '❌ অত্যন্ত অসন্তোষজনক';
      default: return '';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 font-['Noto_Sans_Bengali']">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] animate-in fade-in zoom-in-95 duration-150 relative">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#736B5E] hover:text-[#2D3A3A] p-1.5 rounded-full hover:bg-gray-100 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {isSubmitted ? (
          <div className="text-center py-6 space-y-3">
            <div className="w-14 h-14 bg-[#D4E4BC] text-[#2D5A27] rounded-full flex items-center justify-center mx-auto">
              <Check className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-lg text-[#2D3A3A]">আপনার মূল্যবান রেটিং ও রিভিউ যুক্ত হয়েছে!</h4>
            <p className="text-xs text-[#736B5E]">অন্যান্য সেবাগ্রহীতাদের সুবিধার্থে সত্য মতামত দেওয়ার জন্য ধন্যবাদ।</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-10 h-10 rounded-2xl bg-[#FFF9E6] text-[#D49A2A] flex items-center justify-center">
                <Star className="w-6 h-6 fill-[#D49A2A]" />
              </div>
              <div>
                <h4 className="font-bold text-base text-[#2D3A3A]">রেটিং ও রিভিউ দিন</h4>
                <p className="text-xs text-[#736B5E] font-medium">{targetName}</p>
              </div>
            </div>

            {/* Star Rating Select */}
            <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4] text-center space-y-2">
              <div className="flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    className="p-1 transition-transform hover:scale-125 cursor-pointer focus:outline-none"
                  >
                    <Star
                      className={`w-8 h-8 ${
                        (hoverRating || rating) >= star
                          ? 'text-[#F39C12] fill-[#F39C12]'
                          : 'text-[#D4C3A3]'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <p className="text-xs font-bold text-[#D49A2A]">
                {getRatingLabel(hoverRating || rating)}
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
                আপনার অভিজ্ঞতা বা মন্তব্য লিখুন: <span className="text-red-500">*</span>
              </label>
              <textarea
                required
                rows={3}
                placeholder="যেমন: চালকের ব্যবহার খুব চমৎকার ছিল এবং সময়মতো পৌঁছে দিয়েছেন..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="w-full bg-[#FAF8F5] border border-[#D4C3A3] focus:border-[#2D5A27] rounded-xl p-3 text-xs text-[#2D3A3A] focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-2xl text-xs font-semibold text-[#5A6B6B] bg-[#FAF8F5] border border-[#E6E0D4] cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                className="px-6 py-2 rounded-2xl text-xs font-bold text-white bg-[#2D5A27] hover:bg-[#23491E] shadow-xs cursor-pointer"
              >
                রিভিউ জমা দিন
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
