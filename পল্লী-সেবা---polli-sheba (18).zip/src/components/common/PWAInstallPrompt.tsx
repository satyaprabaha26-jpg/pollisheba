import React, { useState, useEffect } from 'react';
import { 
  Download, 
  Smartphone, 
  X, 
  Share, 
  PlusSquare, 
  CheckCircle2, 
  Sparkles, 
  Zap,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showBanner, setShowBanner] = useState<boolean>(() => {
    // Initial check: if already running as installed standalone app or dismissed recently
    try {
      const isRunningStandalone = 
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true;
      if (isRunningStandalone) return false;

      const dismissedUntil = localStorage.getItem('polli_pwa_dismissed_until');
      if (dismissedUntil && Date.now() < parseInt(dismissedUntil, 10)) {
        return false;
      }
      return true;
    } catch (e) {
      return true;
    }
  });
  const [isIOS, setIsIOS] = useState<boolean>(false);
  const [showIOSModal, setShowIOSModal] = useState<boolean>(false);
  const [isStandalone, setIsStandalone] = useState<boolean>(false);
  const [installedSuccess, setInstalledSuccess] = useState<boolean>(false);

  useEffect(() => {
    // Check if already installed / running in standalone PWA mode
    const isRunningStandalone = 
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true ||
      document.referrer.includes('android-app://');

    setIsStandalone(isRunningStandalone);
    if (isRunningStandalone) {
      setShowBanner(false);
      return;
    }

    // Check if on iOS Safari
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIosDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIosDevice);

    // Listen for Chrome / Android / Desktop PWA install event
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      // Check if user previously dismissed recently
      const dismissedUntil = localStorage.getItem('polli_pwa_dismissed_until');
      if (!dismissedUntil || Date.now() > parseInt(dismissedUntil, 10)) {
        setShowBanner(true);
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // App installed event
    const handleAppInstalled = () => {
      setInstalledSuccess(true);
      setShowBanner(false);
      setDeferredPrompt(null);
      setTimeout(() => setInstalledSuccess(false), 5000);
    };

    window.addEventListener('appinstalled', handleAppInstalled);

    // Global listener for manual "Install App" triggers (from Settings / Header)
    const handleManualTrigger = () => {
      if (isIosDevice) {
        setShowIOSModal(true);
      } else if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
          if (choiceResult.outcome === 'accepted') {
            setShowBanner(false);
          }
        });
      } else {
        setShowBanner(true);
      }
    };

    window.addEventListener('polli_trigger_pwa_install', handleManualTrigger);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('polli_trigger_pwa_install', handleManualTrigger);
    };
  }, [deferredPrompt]);

  const handleInstallClick = async () => {
    if (isIOS) {
      setShowIOSModal(true);
      return;
    }

    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setShowBanner(false);
        setInstalledSuccess(true);
      }
      setDeferredPrompt(null);
    } else {
      // Fallback instruction popup for browsers without beforeinstallprompt
      setShowIOSModal(true);
    }
  };

  const handleDismiss = () => {
    setShowBanner(false);
    // Dismiss for 24 hours
    localStorage.setItem('polli_pwa_dismissed_until', (Date.now() + 24 * 60 * 60 * 1000).toString());
  };

  if (isStandalone) return null;

  return (
    <>
      {/* 1. Success Toast after installation */}
      {installedSuccess && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-[#2D5A27] text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 font-['Noto_Sans_Bengali'] animate-in fade-in slide-in-from-top-4 duration-200">
          <CheckCircle2 className="w-5 h-5 text-[#D4E4BC]" />
          <span className="text-xs sm:text-sm font-bold">
            অভিনন্দন! 'পল্লী সেবা' আপনার ফোনে সফলভাবে ইনস্টল হয়েছে।
          </span>
        </div>
      )}

      {/* 2. Prominent PWA Direct Install Floating Bar / Card */}
      {showBanner && (
        <div className="fixed bottom-20 sm:bottom-6 left-3 right-3 sm:left-auto sm:right-6 sm:max-w-md z-45 font-['Noto_Sans_Bengali'] animate-in slide-in-from-bottom-5 fade-in duration-250">
          <div className="bg-linear-to-br from-[#2D5A27] via-[#23491E] to-[#1B3A17] text-white rounded-3xl p-4 sm:p-5 shadow-2xl border-2 border-[#D4E4BC]/50 relative overflow-hidden backdrop-blur-md">
            
            {/* Background Glow */}
            <div className="absolute -top-10 -right-10 w-28 h-28 bg-[#E8924A]/20 rounded-full blur-2xl pointer-events-none" />

            {/* Dismiss button */}
            <button
              onClick={handleDismiss}
              className="absolute top-3 right-3 text-[#D4E4BC]/80 hover:text-white p-1 rounded-full hover:bg-white/10 transition cursor-pointer"
              title="পরে করব"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-start gap-3.5">
              {/* App Icon */}
              <div className="w-12 h-12 rounded-2xl bg-white p-1 shadow-md border border-[#D4E4BC] flex items-center justify-center shrink-0 overflow-hidden">
                <img
                  src="/logo.png"
                  alt="পল্লী সেবা"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="flex-1 pr-4">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="bg-[#D4E4BC] text-[#2D5A27] font-extrabold text-[10px] px-2 py-0.5 rounded-full shadow-2xs">
                    📲 ফ্রি ইনস্টল
                  </span>
                  <span className="text-[10px] text-[#F9E5D4] font-medium">
                    প্লে-স্টোর ছাড়াই ১-ক্লিকে
                  </span>
                </div>
                <h4 className="font-bold text-sm sm:text-base text-white mt-1 leading-snug">
                  সহজে 'পল্লী সেবা' অ্যাপ ইনস্টল করুন
                </h4>
                <p className="text-xs text-[#D4E4BC] mt-0.5 line-clamp-2">
                  হোম স্ক্রিনে যুক্ত করে ইন্টারনেট ও অফলাইনে দ্রুত গ্রামীণ সেবা উপভোগ করুন।
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 mt-3.5 pt-2 border-t border-[#3D7A35]">
              <button
                onClick={handleInstallClick}
                className="flex-1 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold py-2.5 px-4 rounded-xl text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer active:scale-98"
              >
                <Download className="w-4 h-4" />
                <span>এক ক্লিকে অ্যাপ ইনস্টল করুন</span>
              </button>

              <button
                onClick={handleDismiss}
                className="bg-white/10 hover:bg-white/20 text-[#D4E4BC] hover:text-white px-3 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer"
              >
                পরে করব
              </button>
            </div>

          </div>
        </div>
      )}

      {/* 3. iOS / Manual Safari Step-by-Step Installation Modal */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4">
            
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-2xl bg-[#2D5A27] text-white flex items-center justify-center shadow-xs">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-[#2D3A3A]">হোম স্ক্রিনে অ্যাপ যুক্ত করার নিয়ম</h3>
                  <p className="text-xs text-[#736B5E]">সহজ ৩টি ধাপে ফোনে ইনস্টল করুন</p>
                </div>
              </div>
              <button
                onClick={() => setShowIOSModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] text-lg font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs sm:text-sm text-[#2D3A3A]">
              <div className="flex items-start gap-3 bg-[#FDFBF7] p-3 rounded-2xl border border-[#E6E0D4]">
                <div className="w-7 h-7 rounded-full bg-[#2D5A27] text-white font-bold flex items-center justify-center shrink-0 text-xs">
                  ১
                </div>
                <div className="space-y-0.5">
                  <p className="font-bold text-[#2D5A27] flex items-center gap-1.5">
                    <span>শেয়ার (Share) অপশনে চাপুন</span>
                    <Share className="w-4 h-4 text-[#2D5A27]" />
                  </p>
                  <p className="text-[#5A6B6B]">
                    আপনার মোবাইল ব্রাউজারের নিচে বা উপরে থাকা <strong>Share (শেয়ার)</strong> আইকনটিতে ট্যাপ করুন।
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-[#FDFBF7] p-3 rounded-2xl border border-[#E6E0D4]">
                <div className="w-7 h-7 rounded-full bg-[#2D5A27] text-white font-bold flex items-center justify-center shrink-0 text-xs">
                  ২
                </div>
                <div className="space-y-0.5">
                  <p className="font-bold text-[#2D5A27] flex items-center gap-1.5">
                    <span>'Add to Home Screen' চাপুন</span>
                    <PlusSquare className="w-4 h-4 text-[#2D5A27]" />
                  </p>
                  <p className="text-[#5A6B6B]">
                    নিচে স্ক্রোল করে <strong>"Add to Home Screen" (হোম স্ক্রিনে যোগ করুন)</strong> অপশনে চাপ দিন।
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-[#FDFBF7] p-3 rounded-2xl border border-[#E6E0D4]">
                <div className="w-7 h-7 rounded-full bg-[#2D5A27] text-white font-bold flex items-center justify-center shrink-0 text-xs">
                  ৩
                </div>
                <div className="space-y-0.5">
                  <p className="font-bold text-[#2D5A27] flex items-center gap-1.5">
                    <span>'Add' বা 'যুক্ত করুন' সম্পন্ন করুন</span>
                    <CheckCircle2 className="w-4 h-4 text-[#27AE60]" />
                  </p>
                  <p className="text-[#5A6B6B]">
                    উপরে ডানপাশের <strong>"Add"</strong> বাটনে চাপলেই প্লে-স্টোর ছাড়াই সাধারণ অ্যাপের মতো আপনার স্ক্রিনে চলে আসবে।
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-[#D4E4BC]/30 p-3 rounded-2xl border border-[#D4E4BC] text-[11px] text-[#2D5A27] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>এটি সম্পূর্ণ নিরাপদ এবং আপনার ফোনের মেমোরি খরচ হবে না বললেই চলে।</span>
            </div>

            <button
              onClick={() => setShowIOSModal(false)}
              className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
            >
              বুঝেছি, ধন্যবাদ
            </button>

          </div>
        </div>
      )}
    </>
  );
};
