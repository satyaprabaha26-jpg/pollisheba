import React from 'react';
import { 
  Home, 
  Grid3X3, 
  User, 
  Settings as SettingsIcon 
} from 'lucide-react';
import { UserProfile } from '../../types/auth';
import { useLanguage } from '../../context/LanguageContext';

export type MainNavView = 'home' | 'services' | 'settings' | 'account' | 'ai-advisor' | 'terms-help' | 'service-detail';

interface BottomNavigationBarProps {
  currentView: MainNavView;
  onSelectView: (view: MainNavView) => void;
  currentUser: UserProfile | null;
  unreadNotificationsCount?: number;
}

// Friendly Village AI Robot Icon matching theme
const AIRobotIcon: React.FC<{ className?: string }> = ({ className = "w-7 h-7 sm:w-8 sm:h-8" }) => (
  <svg 
    viewBox="0 0 48 48" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    {/* Speech Bubble on top right */}
    <g transform="translate(24, 2)">
      <path 
        d="M2 0H15C16.1 0 17 0.9 17 2V7.5C17 8.6 16.1 9.5 15 9.5H6L2 12.5V9.5C0.9 9.5 0 8.6 0 7.5V2C0 0.9 0.9 0 2 0Z" 
        fill="white" 
      />
      <circle cx="5" cy="4.8" r="1.1" fill="#2E6539" />
      <circle cx="8.5" cy="4.8" r="1.1" fill="#2E6539" />
      <circle cx="12" cy="4.8" r="1.1" fill="#2E6539" />
    </g>

    {/* Antenna */}
    <path d="M24 10.5V14" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
    <circle cx="24" cy="9.5" r="2" fill="white" />

    {/* Robot Head */}
    <rect x="10" y="14" width="28" height="20" rx="9" fill="white" />
    
    {/* Ear pods */}
    <rect x="7" y="19" width="3" height="10" rx="1.5" fill="white" />
    <rect x="38" y="19" width="3" height="10" rx="1.5" fill="white" />

    {/* Face Screen */}
    <rect x="13.5" y="17.5" width="21" height="13" rx="5.5" fill="#205830" />

    {/* Smiling Happy Eyes */}
    <path d="M17.5 22.8C17.5 21.2 19 21.2 19.8 22.8" stroke="#86EFAC" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M28.2 22.8C28.2 21.2 29.7 21.2 30.5 22.8" stroke="#86EFAC" strokeWidth="1.8" strokeLinecap="round" />

    {/* Cheerful Smile */}
    <path d="M21 26C22.2 27.2 25.8 27.2 27 26" stroke="#86EFAC" strokeWidth="1.8" strokeLinecap="round" />

    {/* Body Base */}
    <path 
      d="M14 36.5C14 34.5 17.5 33.5 24 33.5C30.5 33.5 34 34.5 34 36.5V40C34 41.5 32 42.5 24 42.5C16 42.5 14 41.5 14 40V36.5Z" 
      fill="white" 
    />
  </svg>
);

export const BottomNavigationBar: React.FC<BottomNavigationBarProps> = ({
  currentView,
  onSelectView,
  currentUser,
  unreadNotificationsCount = 0
}) => {
  const { t } = useLanguage();

  const isHomeActive = currentView === 'home';
  const isMenuActive = currentView === 'services' || currentView === 'service-detail';
  const isAiActive = currentView === 'ai-advisor';
  const isAccountActive = currentView === 'account';
  const isSettingsActive = currentView === 'settings';

  return (
    <nav 
      id="main-bottom-navigation"
      aria-label="প্রধান নেভিগেশন বার"
      className="bottom-nav border-t border-[#E8ECE8] bg-white font-['Noto_Sans_Bengali'] select-none z-40"
    >
      <div className="w-full max-w-lg mx-auto grid grid-cols-5 items-end px-2 pt-1.5 pb-1 relative">
        
        {/* 1. হোম বাটন (ঘর আইকন) */}
        <button
          id="btn-nav-home"
          onClick={() => onSelectView('home')}
          className="flex flex-col items-center justify-center cursor-pointer transition-all duration-150 py-0.5 group"
          title={t('হোম', 'Home')}
        >
          <div 
            className={`w-13 h-8.5 rounded-2xl flex items-center justify-center transition-all duration-150 ${
              isHomeActive 
                ? 'bg-[#E2EBDC] text-[#1E5E3A]' 
                : 'text-[#4A554D] group-hover:text-[#1E5E3A]'
            }`}
          >
            <Home className={`w-6 h-6 ${isHomeActive ? 'stroke-[2.2]' : 'stroke-[1.9]'}`} />
          </div>
          <span className={`text-[11px] sm:text-xs leading-none mt-1 ${isHomeActive ? 'font-bold text-[#1E5E3A]' : 'font-medium text-[#4A554D]'}`}>
            {t('হোম', 'Home')}
          </span>
        </button>

        {/* 2. মেনু বাটন (গ্রিড আইকন) */}
        <button
          id="btn-nav-menu"
          onClick={() => onSelectView('services')}
          className="flex flex-col items-center justify-center cursor-pointer transition-all duration-150 py-0.5 group"
          title={t('মেনু', 'Menu')}
        >
          <div 
            className={`w-13 h-8.5 rounded-2xl flex items-center justify-center transition-all duration-150 ${
              isMenuActive 
                ? 'bg-[#E2EBDC] text-[#1E5E3A]' 
                : 'text-[#4A554D] group-hover:text-[#1E5E3A]'
            }`}
          >
            <Grid3X3 className={`w-6 h-6 ${isMenuActive ? 'stroke-[2.2]' : 'stroke-[1.9]'}`} />
          </div>
          <span className={`text-[11px] sm:text-xs leading-none mt-1 ${isMenuActive ? 'font-bold text-[#1E5E3A]' : 'font-medium text-[#4A554D]'}`}>
            {t('মেনু', 'Menu')}
          </span>
        </button>

        {/* 3. এআই সহকারী (মাঝখানে বড় ও বিশিষ্ট গোল ফ্লোটিং বাটন) */}
        <div className="flex flex-col items-center justify-end relative -top-3.5 sm:-top-4">
          <button
            id="btn-nav-ai-advisor"
            onClick={() => onSelectView('ai-advisor')}
            className={`relative p-1 rounded-full bg-white shadow-[0_4px_16px_rgba(20,60,30,0.18)] border border-[#E8ECE8] cursor-pointer transition-transform duration-200 active:scale-95 group ${
              isAiActive ? 'ring-3 ring-[#1E7C48] ring-offset-2 ring-offset-white' : ''
            }`}
            title="এআই সহকারী"
          >
            {/* Elegant Floating Round Button */}
            <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-gradient-to-tr from-[#1B7837] via-[#2E9946] to-[#E68A36] flex items-center justify-center shadow-md relative overflow-hidden group-hover:brightness-105 transition-all">
              <div className="absolute top-0 inset-x-0 h-3.5 bg-white/25 rounded-t-full pointer-events-none" />
              <AIRobotIcon className="w-7 h-7 sm:w-8 sm:h-8 relative z-10 drop-shadow-sm group-hover:scale-110 transition-transform" />
            </div>
          </button>
          
          <span className={`text-[11px] sm:text-xs leading-none mt-0.5 whitespace-nowrap ${
            isAiActive ? 'font-extrabold text-[#14472A]' : 'font-medium text-[#4A554D]'
          }`}>
            এআই সহকারী
          </span>
        </div>

        {/* 4. অ্যাকাউন্ট বাটন (প্রোফাইল আইকন / নিবন্ধিত হলে ইউজারের নাম) */}
        <button
          id="btn-nav-account"
          onClick={() => onSelectView('account')}
          className="flex flex-col items-center justify-center cursor-pointer transition-all duration-150 py-0.5 group relative"
          title={currentUser?.name ? `প্রোফাইল: ${currentUser.name}` : t('অ্যাকাউন্ট', 'Account')}
        >
          <div 
            className={`w-13 h-8.5 rounded-2xl flex items-center justify-center transition-all duration-150 relative ${
              isAccountActive 
                ? 'bg-[#E2EBDC] text-[#1E5E3A]' 
                : 'text-[#4A554D] group-hover:text-[#1E5E3A]'
            }`}
          >
            {currentUser?.customAvatarUrl || currentUser?.avatarUrl ? (
              <img 
                src={currentUser.customAvatarUrl || currentUser.avatarUrl} 
                alt={currentUser.name} 
                className="w-6 h-6 rounded-full object-cover border border-[#1E5E3A]" 
              />
            ) : (
              <User className={`w-6 h-6 ${isAccountActive ? 'stroke-[2.2]' : 'stroke-[1.9]'}`} />
            )}
            
            {/* Unread badge dot/count if user has unread messages or missed calls */}
            {unreadNotificationsCount > 0 ? (
              <span className="absolute -top-1 -right-0.5 bg-red-600 text-white font-extrabold text-[9px] min-w-4 h-4 px-1 rounded-full flex items-center justify-center border-2 border-white animate-pulse shadow-xs">
                {unreadNotificationsCount}
              </span>
            ) : currentUser?.role === 'driver' ? (
              <span className="absolute top-0 right-1 w-2.5 h-2.5 bg-[#E8924A] border-2 border-white rounded-full" />
            ) : currentUser ? (
              <span className="absolute top-0.5 right-1.5 w-2 h-2 bg-emerald-500 border border-white rounded-full" title="লগইন সক্রিয়" />
            ) : null}
          </div>
          <span className={`text-[11px] sm:text-xs leading-none mt-1 truncate max-w-[70px] ${isAccountActive ? 'font-bold text-[#1E5E3A]' : 'font-medium text-[#4A554D]'}`}>
            {currentUser?.name 
              ? (currentUser.name.trim().split(' ')[0] || currentUser.name.trim()) 
              : t('অ্যাকাউন্ট', 'Account')}
          </span>
        </button>

        {/* 5. সেটিংস বাটন (গিয়ার আইকন) */}
        <button
          id="btn-nav-settings"
          onClick={() => onSelectView('settings')}
          className="flex flex-col items-center justify-center cursor-pointer transition-all duration-150 py-0.5 group"
          title={t('সেটিংস', 'Settings')}
        >
          <div 
            className={`w-13 h-8.5 rounded-2xl flex items-center justify-center transition-all duration-150 ${
              isSettingsActive 
                ? 'bg-[#E2EBDC] text-[#1E5E3A]' 
                : 'text-[#4A554D] group-hover:text-[#1E5E3A]'
            }`}
          >
            <SettingsIcon className={`w-6 h-6 ${isSettingsActive ? 'stroke-[2.2]' : 'stroke-[1.9]'}`} />
          </div>
          <span className={`text-[11px] sm:text-xs leading-none mt-1 ${isSettingsActive ? 'font-bold text-[#1E5E3A]' : 'font-medium text-[#4A554D]'}`}>
            {t('সেটিংস', 'Settings')}
          </span>
        </button>

      </div>
    </nav>
  );
};



