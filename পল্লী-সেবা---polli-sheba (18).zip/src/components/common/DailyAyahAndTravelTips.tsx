import React, { useState } from 'react';
import { 
  BookOpen, 
  Compass, 
  MapPin, 
  ChevronRight, 
  ChevronLeft, 
  ShieldCheck, 
  Leaf, 
  Search, 
  Sparkles,
  Heart,
  Share2,
  AlertTriangle
} from 'lucide-react';
import { QuranAyah, TravelSpotGuide } from '../../types';
import { DAILY_QURAN_AYAHS, RURAL_TRAVEL_TIPS } from '../../data/extendedData';

export const DailyAyahAndTravelTips: React.FC = () => {
  // Quran Ayah state
  const [currentAyahIndex, setCurrentAyahIndex] = useState<number>(0);
  const [copiedAyah, setCopiedAyah] = useState<boolean>(false);

  // Travel Spot state
  const [selectedSpotIndex, setSelectedSpotIndex] = useState<number>(0);
  const [travelSearchQuery, setTravelSearchQuery] = useState<string>('');

  const currentAyah = DAILY_QURAN_AYAHS[currentAyahIndex] || DAILY_QURAN_AYAHS[0];

  const filteredSpots = RURAL_TRAVEL_TIPS.filter((spot) => {
    if (!travelSearchQuery.trim()) return true;
    const q = travelSearchQuery.toLowerCase();
    return (
      spot.spotName.toLowerCase().includes(q) ||
      spot.district.toLowerCase().includes(q) ||
      spot.division.toLowerCase().includes(q) ||
      spot.category.toLowerCase().includes(q)
    );
  });

  const activeSpot = filteredSpots[selectedSpotIndex] || filteredSpots[0] || RURAL_TRAVEL_TIPS[0];

  const handleNextAyah = () => {
    setCurrentAyahIndex((prev) => (prev + 1) % DAILY_QURAN_AYAHS.length);
  };

  const handlePrevAyah = () => {
    setCurrentAyahIndex((prev) => (prev - 1 + DAILY_QURAN_AYAHS.length) % DAILY_QURAN_AYAHS.length);
  };

  const handleCopyAyah = () => {
    const textToCopy = `"${currentAyah.arabicText}"\n\nঅর্থ: ${currentAyah.banglaMeaning}\n[${currentAyah.surahName}: আয়াত ${currentAyah.ayahNumber}] - পল্লি সেবা অ্যাপ`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedAyah(true);
    setTimeout(() => setCopiedAyah(false), 2500);
  };

  return (
    <div className="w-full my-8 space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ======================================================== */}
        {/* ১. প্রতিদিনের নির্বাচিত কোরআনের আয়াত ও মানবিক শিক্ষা */}
        {/* ======================================================== */}
        <div className="bg-gradient-to-br from-emerald-900 via-teal-950 to-slate-950 text-white rounded-2xl p-6 shadow-md border border-emerald-800/60 flex flex-col justify-between relative overflow-hidden">
          {/* Background Decorative Motif */}
          <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div>
            {/* Header */}
            <div className="flex items-center justify-between gap-2 border-b border-emerald-800/80 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-800/50 border border-emerald-600/40 rounded-xl">
                  <BookOpen className="w-5 h-5 text-amber-300" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-emerald-100 flex items-center gap-1.5">
                    <span>প্রতিদিনের নির্বাচিত কোরআনের আয়াত</span>
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  </h3>
                  <p className="text-[11px] text-emerald-300">
                    দৈনন্দিন গ্রামীণ জীবন ও হালাল জীবিকার দিশা
                  </p>
                </div>
              </div>

              {/* Next/Prev Navigation */}
              <div className="flex items-center gap-1">
                <button
                  onClick={handlePrevAyah}
                  title="পূর্ববর্তী আয়াত"
                  className="p-1.5 rounded-lg bg-emerald-800/40 hover:bg-emerald-700/60 text-emerald-200 transition"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-[11px] text-emerald-300 px-1 font-mono">
                  {currentAyahIndex + 1}/{DAILY_QURAN_AYAHS.length}
                </span>
                <button
                  onClick={handleNextAyah}
                  title="পরবর্তী আয়াত"
                  className="p-1.5 rounded-lg bg-emerald-800/40 hover:bg-emerald-700/60 text-emerald-200 transition"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Theme Tag */}
            <div className="mb-3">
              <span className="inline-block px-2.5 py-0.5 bg-amber-400/20 text-amber-300 border border-amber-400/30 rounded-full text-[11px] font-semibold">
                বিষয়: {currentAyah.theme}
              </span>
            </div>

            {/* Arabic Text */}
            <div className="p-4 bg-emerald-950/60 rounded-xl border border-emerald-800/50 text-right font-serif text-lg md:text-xl text-amber-100 leading-loose tracking-wide select-all">
              {currentAyah.arabicText}
            </div>

            {/* Bengali Translation */}
            <div className="mt-3 text-sm text-emerald-100/95 leading-relaxed">
              <span className="font-bold text-amber-300">অর্থ: </span>
              {currentAyah.banglaMeaning}
            </div>
          </div>

          {/* Footer of Ayah Card */}
          <div className="mt-5 pt-3 border-t border-emerald-800/60 flex items-center justify-between text-xs text-emerald-300">
            <span className="font-semibold text-amber-300/90">
              {currentAyah.surahName} • আয়াত {currentAyah.ayahNumber}
            </span>

            <button
              onClick={handleCopyAyah}
              className="flex items-center gap-1 px-3 py-1 bg-emerald-800/60 hover:bg-emerald-700 rounded-lg text-emerald-100 transition"
            >
              <Share2 className="w-3.5 h-3.5 text-amber-300" />
              <span>{copiedAyah ? 'কপি হয়েছে!' : 'শেয়ার বা কপি'}</span>
            </button>
          </div>
        </div>

        {/* ======================================================== */}
        {/* ২. গ্রামীণ ও বাংলাদেশ পর্যটন ভ্রমণ সহায়িকা ও নির্দেশিকা */}
        {/* ======================================================== */}
        <div className="bg-white rounded-2xl p-6 shadow-md border border-slate-200 flex flex-col justify-between">
          <div>
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-teal-50 border border-teal-200 rounded-xl">
                  <Compass className="w-5 h-5 text-teal-700" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900 flex items-center gap-1.5">
                    <span>গ্রামীণ ও পর্যটন ভ্রমণ সহায়িকা</span>
                    <Leaf className="w-3.5 h-3.5 text-emerald-600" />
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    নিরাপদ ও পরিবেশবান্ধব গ্রাম ও প্রকৃতি ভ্রমণ
                  </p>
                </div>
              </div>

              {/* Search Spot */}
              <div className="relative w-full sm:w-48">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="স্থান বা জেলা খুঁজুন..."
                  value={travelSearchQuery}
                  onChange={(e) => {
                    setTravelSearchQuery(e.target.value);
                    setSelectedSpotIndex(0);
                  }}
                  className="w-full pl-7 pr-3 py-1 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Quick Spot Selector Pills */}
            <div className="flex gap-1.5 overflow-x-auto pb-2 scrollbar-none mb-3">
              {filteredSpots.map((spot, idx) => (
                <button
                  key={spot.id}
                  onClick={() => setSelectedSpotIndex(idx)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition flex-shrink-0 ${
                    idx === selectedSpotIndex
                      ? 'bg-teal-700 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {spot.spotName.split(' ')[0]} ({spot.district})
                </button>
              ))}
            </div>

            {/* Active Spot Detail */}
            {activeSpot && (
              <div className="space-y-2.5 text-xs text-slate-700">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-base font-bold text-teal-900 flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-rose-500 flex-shrink-0" />
                    <span>{activeSpot.spotName}</span>
                  </h4>
                  <span className="px-2 py-0.5 bg-teal-50 text-teal-800 border border-teal-200 rounded-full font-semibold text-[11px]">
                    {activeSpot.district}, {activeSpot.division}
                  </span>
                </div>

                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                  <p>
                    <strong className="text-slate-900">কীভাবে যাবেন: </strong>
                    {activeSpot.howToGo}
                  </p>
                  <p>
                    <strong className="text-slate-900">যাতায়াত ও স্থানীয় বাহন: </strong>
                    {activeSpot.localTransportTips}
                  </p>
                  <p>
                    <strong className="text-slate-900">থাকা ও খাওয়ার টিপস: </strong>
                    {activeSpot.stayAndFood}
                  </p>
                </div>

                {/* Safety & Culture */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <div className="p-2 bg-amber-50/80 border border-amber-200 rounded-lg">
                    <div className="font-bold text-amber-950 flex items-center gap-1 mb-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
                      <span>ভ্রমণ নিরাপত্তা বিধি:</span>
                    </div>
                    <ul className="list-disc list-inside text-[11px] text-amber-900 space-y-0.5">
                      {activeSpot.safetyRules.map((rule, rIdx) => (
                        <li key={rIdx}>{rule}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-2 bg-emerald-50/80 border border-emerald-200 rounded-lg">
                    <div className="font-bold text-emerald-950 flex items-center gap-1 mb-1">
                      <Leaf className="w-3.5 h-3.5 text-emerald-700" />
                      <span>পরিবেশ ও সংস্কৃতি রক্ষা:</span>
                    </div>
                    <p className="text-[11px] text-emerald-900 mb-1">
                      {activeSpot.culturalEtiquette}
                    </p>
                    <p className="text-[10px] text-emerald-800 font-semibold bg-emerald-100/60 p-1 rounded">
                      ⚠️ {activeSpot.environmentalNotice}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="mt-4 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>উপযুক্ত সময়: <strong>{activeSpot?.bestTimeToVisit}</strong></span>
            <span className="text-teal-700 font-semibold">সবুজ ও পরিচ্ছন্ন বাংলাদেশ গড়ুন</span>
          </div>
        </div>
      </div>
    </div>
  );
};
