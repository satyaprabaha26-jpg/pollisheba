import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Plus, 
  MapPin, 
  ShieldCheck, 
  Phone, 
  MessageSquare, 
  Mic, 
  AlertTriangle, 
  Search, 
  Trash2, 
  Calendar, 
  Sparkles, 
  Clock, 
  CheckCircle,
  X,
  Users,
  GraduationCap,
  Briefcase,
  UserCheck,
  EyeOff,
  Info
} from 'lucide-react';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { CascadingAddressSelector, AddressState } from '../common/CascadingAddressSelector';
import { UserProfile } from '../../types/auth';
import { 
  MatrimonyListing, 
  MatrimonySeekingType, 
  MatrimonyReligion, 
  MatrimonyMaritalStatus, 
  isPostExpired 
} from '../../types/housingMatrimony';
import { 
  subscribeToMatrimonyListings, 
  saveCloudMatrimonyListing, 
  deleteCloudMatrimonyListing,
  saveDemandNotification
} from '../../lib/cloudSync';
import { ReportListingModal } from '../housing/ReportListingModal';

interface MatrimonyModuleProps {
  currentDistrict: string;
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
  onStartInAppCall?: (targetUser: Partial<UserProfile>) => void;
  onStartChat?: (targetUser: Partial<UserProfile>) => void;
  onOpenVoiceNote?: (targetUser: Partial<UserProfile>) => void;
}

const DURATION_OPTIONS = [
  { days: 7, label: '৭ দিন' },
  { days: 15, label: '১৫ দিন' },
  { days: 30, label: '১ মাস (৩০ দিন)' },
  { days: 60, label: '২ মাস (৬০ দিন)' },
  { days: 90, label: '৩ মাস (সর্বোচ্চ মেয়াদ)' }
];

export const MatrimonyModule: React.FC<MatrimonyModuleProps> = ({
  currentDistrict,
  currentUser,
  onOpenAuth,
  onStartInAppCall,
  onStartChat,
  onOpenVoiceNote
}) => {
  const [listings, setListings] = useState<MatrimonyListing[]>([]);
  const [selectedSeeking, setSelectedSeeking] = useState<'all' | MatrimonySeekingType>('all');
  const [selectedReligion, setSelectedReligion] = useState<'all' | MatrimonyReligion>('all');
  const [filterAddress, setFilterAddress] = useState<AddressState>({
    district: currentDistrict && currentDistrict !== 'সকল জেলা' ? currentDistrict : 'সকল জেলা',
    upazila: '',
    union: '',
    village: ''
  });
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'browse' | 'my_posts'>('browse');

  // Modal & Toast states
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [reportingListing, setReportingListing] = useState<MatrimonyListing | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form states
  const [seekingType, setSeekingType] = useState<MatrimonySeekingType>('পাত্র চাই');
  const [age, setAge] = useState<number>(24);
  const [height, setHeight] = useState('৫ ফুট ৩ ইঞ্চি');
  const [religion, setReligion] = useState<MatrimonyReligion>('ইসলাম');
  const [maritalStatus, setMaritalStatus] = useState<MatrimonyMaritalStatus>('অবিবাহিত');
  const [education, setEducation] = useState('স্নাতক / অনার্স ৩য় বর্ষ');
  const [profession, setProfession] = useState('');
  const [complexion, setComplexion] = useState('উজ্জ্বল শ্যামলা');
  const [bloodGroup, setBloodGroup] = useState('B+');
  const [postAddress, setPostAddress] = useState<AddressState>({
    district: currentUser?.district || (currentDistrict !== 'সকল জেলা' ? currentDistrict : 'বগুড়া'),
    upazila: currentUser?.upazila || '',
    union: currentUser?.union || '',
    village: currentUser?.village || ''
  });
  const [familyInfo, setFamilyInfo] = useState('');
  const [expectations, setExpectations] = useState('');
  const [posterRelation, setPosterRelation] = useState<'অভিভাবক (বাবা/মা)' | 'ভাই/বোন' | 'আত্মীয়' | 'নিজেই'>('অভিভাবক (বাবা/মা)');
  const [durationDays, setDurationDays] = useState<number>(30);
  const [notificationScope, setNotificationScope] = useState<'upazila' | 'district'>('district');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isRestricted = !!currentUser?.isRestrictedFromHousingAndMatrimony;

  useEffect(() => {
    const unsubscribe = subscribeToMatrimonyListings((data) => {
      setListings(data);
    });
    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, []);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (isRestricted) {
      alert('আপনার অ্যাকাউন্টটি আবাসন ও পাত্র-পাত্রী সেবায় আংশিকভাবে সীমাবদ্ধ করা হয়েছে। অন্যান্য সেবা নিয়মিত ব্যবহার করতে পারবেন।');
      return;
    }

    if (!education.trim() || !familyInfo.trim() || !expectations.trim() || !postAddress.district || !postAddress.upazila) {
      alert('অনুগ্রহ করে শিক্ষা, পারিবারিক বিবরণ, প্রত্যাশা, জেলা ও উপজেলা পূরণ করুন');
      return;
    }

    setIsSubmitting(true);
    const now = Date.now();
    const expiresAt = now + (durationDays * 24 * 60 * 60 * 1000);
    const dateFormatted = new Date(now).toLocaleDateString('bn-BD', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });

    const newListing: MatrimonyListing = {
      id: `matri-${now}-${Math.random().toString(36).substring(2, 7)}`,
      seekingType,
      age: Number(age),
      height: height.trim(),
      religion,
      maritalStatus,
      education: education.trim(),
      profession: profession.trim() || undefined,
      complexion: complexion.trim() || undefined,
      bloodGroup: bloodGroup.trim() || undefined,
      district: postAddress.district,
      upazila: postAddress.upazila || 'সদর',
      union: postAddress.union || undefined,
      village: postAddress.village || undefined,
      familyInfo: familyInfo.trim(),
      expectations: expectations.trim(),
      posterId: currentUser.id,
      posterName: currentUser.name,
      posterPhone: currentUser.phone,
      posterRelation,
      allowOfflineCall: currentUser.allowOfflineCall ?? currentUser.allowOfflineCalls ?? false,
      notificationScope,
      durationDays,
      status: 'active',
      createdAt: now,
      createdAtFormatted: dateFormatted,
      expiresAt,
      viewsCount: 1
    };

    try {
      await saveCloudMatrimonyListing(newListing);

      // Dispatch targeted demand notification to users
      const notifTitle = `💍 পাত্র-পাত্রীর সন্ধান: ${seekingType} (${religion})`;
      const notifMsg = `${postAddress.district}, ${postAddress.upazila} এলাকা থেকে ${age} বছর বয়সী ${maritalStatus} ${seekingType} চেয়ে বিজ্ঞাপন দেওয়া হয়েছে। মেয়াদ: ${durationDays} দিন।`;

      await saveDemandNotification({
        id: `notif-matri-${now}`,
        title: notifTitle,
        message: notifMsg,
        urgency: 'সাধারণ',
        targetDistrict: postAddress.district,
        targetUpazila: notificationScope === 'upazila' ? (postAddress.upazila || 'সকল উপজেলা') : 'সকল উপজেলা',
        targetRole: 'all',
        categoryName: 'পাত্র-পাত্রীর সন্ধান',
        senderName: currentUser.name,
        contactNumber: currentUser.phone,
        targetCategory: 'matrimony',
        scope: notificationScope,
        createdAt: now,
        expiresAt: now + (durationDays * 24 * 60 * 60 * 1000),
        createdAtFormatted: dateFormatted,
        allowOfflineCall: currentUser.allowOfflineCall
      });

      setIsCreateModalOpen(false);
      resetForm();
      triggerToast(`✓ বিজ্ঞাপনটি সফলভাবে প্রকাশিত হয়েছে এবং ${durationDays} দিন লাইভ থাকবে!`);
    } catch (err) {
      alert('বিজ্ঞাপনটি সংরক্ষণ করতে সমস্যা হয়েছে।');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setEducation('');
    setFamilyInfo('');
    setExpectations('');
    setProfession('');
    setPostAddress({
      district: currentUser?.district || (currentDistrict !== 'সকল জেলা' ? currentDistrict : 'বগুড়া'),
      upazila: currentUser?.upazila || '',
      union: currentUser?.union || '',
      village: currentUser?.village || ''
    });
  };

  const handleDeleteListing = async (id: string) => {
    if (confirm('আপনি কি নিশ্চিত যে বিজ্ঞাপনটি মুছে ফেলতে চান?')) {
      try {
        await deleteCloudMatrimonyListing(id);
        triggerToast('✓ বিজ্ঞাপনটি সফলভাবে মুছে ফেলা হয়েছে');
      } catch (err) {
        alert('মুছতে সমস্যা হয়েছে');
      }
    }
  };

  // Filter listings
  const publicListings = listings.filter(item => {
    // 1. AUTO-HIDE: expired items are hidden
    if (isPostExpired(item.expiresAt)) return false;
    if (item.status !== 'active') return false;
    // 2. Seeking type filter
    if (selectedSeeking !== 'all' && item.seekingType !== selectedSeeking) return false;
    // 3. Religion filter
    if (selectedReligion !== 'all' && item.religion !== selectedReligion) return false;
    // 4. District filter
    if (filterAddress.district && filterAddress.district !== 'সকল জেলা' && item.district !== filterAddress.district) {
      return false;
    }
    // 5. Upazila filter
    if (filterAddress.upazila && filterAddress.upazila !== 'সকল উপজেলা / থানা' && filterAddress.upazila !== 'সকল উপজেলা') {
      const qUpz = filterAddress.upazila.toLowerCase().trim();
      const matchUpz = item.upazila.toLowerCase().includes(qUpz) || qUpz.includes(item.upazila.toLowerCase());
      if (!matchUpz) return false;
    }
    // 6. Union filter
    if (filterAddress.union && filterAddress.union !== 'সকল ইউনিয়ন / ওয়ার্ড' && filterAddress.union !== 'সকল ইউনিয়ন') {
      const qUn = filterAddress.union.toLowerCase().trim();
      const matchUn = (item.union && item.union.toLowerCase().includes(qUn)) ||
        (item.village && item.village.toLowerCase().includes(qUn));
      if (!matchUn) return false;
    }
    // 7. Village / Ward filter
    if (filterAddress.village && filterAddress.village.trim()) {
      const qVil = filterAddress.village.toLowerCase().trim();
      const matchVil = (item.village && item.village.toLowerCase().includes(qVil)) ||
        item.familyInfo.toLowerCase().includes(qVil);
      if (!matchVil) return false;
    }
    // 8. Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const match = item.education.toLowerCase().includes(q) ||
        (item.profession && item.profession.toLowerCase().includes(q)) ||
        item.familyInfo.toLowerCase().includes(q) ||
        item.expectations.toLowerCase().includes(q) ||
        item.district.toLowerCase().includes(q) ||
        item.upazila.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const myListings = currentUser 
    ? listings.filter(item => item.posterId === currentUser.id)
    : [];

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-[#2D5A27] text-white px-4 py-3 rounded-2xl shadow-xl text-xs font-bold flex items-center gap-2 animate-in slide-in-from-top border border-emerald-400">
          <CheckCircle className="w-4 h-4 text-emerald-300" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* HEADER BANNER */}
      <div className="bg-linear-to-r from-[#8E44AD] to-[#C0392B] text-white rounded-3xl p-5 sm:p-7 shadow-sm relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-white/5 transform skew-x-12 pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/15 backdrop-blur-xs rounded-full text-xs font-bold text-rose-100">
              <span>💍 ২৬তম উন্মুক্ত নাগরিক সেবা</span>
              <span>•</span>
              <span>শতভাগ ছবিমুক্ত ও শালীন মেচমেকিং</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              পাত্র-পাত্রীর সন্ধান (Matchmaking)
            </h1>
            <p className="text-xs sm:text-sm text-rose-100/90 leading-relaxed">
              পারিবারিক শালীনতা ও কঠোর গোপনীয়তা বজায় রেখে পাত্র বা পাত্রী খুঁজুন। সরাসরি অভিভাবক ও পরিবারের সাথে ফ্রি ইন-অ্যাপ কল ও মেসেজে আলোচনা করুন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={() => {
                if (!currentUser) {
                  onOpenAuth();
                  return;
                }
                if (isRestricted) {
                  alert('আপনার অ্যাকাউন্টটি নিরাপত্তা সংক্রান্ত কারণে এই সেবায় পোস্ট করা থেকে সীমাবদ্ধ করা হয়েছে।');
                  return;
                }
                setIsCreateModalOpen(true);
              }}
              className="bg-white text-[#8E44AD] hover:bg-rose-50 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold shadow-md transition cursor-pointer flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4 text-[#8E44AD]" />
              <span>পাত্র/পাত্রীর বিজ্ঞাপন দিন</span>
            </button>

            {currentUser && (
              <button
                onClick={() => setActiveTab(activeTab === 'browse' ? 'my_posts' : 'browse')}
                className={`px-3.5 py-2.5 rounded-2xl text-xs font-bold transition cursor-pointer border ${
                  activeTab === 'my_posts'
                    ? 'bg-purple-900 text-white border-purple-400'
                    : 'bg-white/15 text-white hover:bg-white/25 border-white/20'
                }`}
              >
                <span>আমার পোস্ট ({myListings.length})</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ৩. ছবি সম্পূর্ণ নিষিদ্ধ ও আর্থিক লেনদেনহীন স্থায়ী নিরাপত্তা নোটিশ (PRIVACY & INDEPENDENT NOTICE) */}
      <div className="bg-[#FAF8F5] p-3.5 sm:p-4 rounded-2xl border-2 border-purple-200 shadow-2xs flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-900 flex items-center justify-center shrink-0">
          <EyeOff className="w-5 h-5" />
        </div>
        <div className="text-xs text-[#2D3A3A] leading-relaxed">
          <strong className="font-extrabold text-purple-950 block">
            🔒 কঠোর গোপনীয়তা, ছবি নিষেধাজ্ঞা ও লেনদেনহীন নীতি:
          </strong>
          <span>
            পারিবারিক শালীনতা রক্ষার্থে পাত্র বা পাত্রীর <strong>ছবি প্রদর্শন সম্পূর্ণ নিষিদ্ধ</strong>। এছাড়া পল্লী সেবা কোনো প্রকার আর্থিক লেনদেন করে না। উভয় পরিবারের অভিভাবকগণ পারস্পরিক সরাসরি আলোচনা করে নিজ দায়িত্বে তথ্য যাচাই করবেন।
          </span>
        </div>
      </div>

      {/* PARTIAL BAN BANNER IF APPLICABLE */}
      {isRestricted && (
        <div className="bg-red-50 p-4 rounded-2xl border-2 border-red-300 text-red-900 space-y-1">
          <div className="flex items-center gap-2 font-bold text-xs sm:text-sm text-red-800">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span>আপনার অ্যাকাউন্টের জন্য পাত্র-পাত্রী ও আবাসন সেবায় আংশিক সীমাবদ্ধতা রয়েছে</span>
          </div>
          <p className="text-xs text-red-700 leading-relaxed">
            কোনো ব্যবহারকারীর রিপোর্ট বা ভুল তথ্যের কারণে আপনাকে শুধুমাত্র ‘আবাসন’ ও ‘পাত্র-পাত্রীর সন্ধান’ ফিচারে পোস্ট করা থেকে আংশিকভাবে সাময়িক/স্থায়ীভাবে বিরত রাখা হয়েছে। তবে আপনি পল্লী সেবার অন্যান্য সকল সেবা (কৃষি, হাট, ডাক্তার, রক্তদান, পরিবহন ইত্যাদি) স্বাভাবিকভাবে ব্যবহার করতে পারবেন।
          </p>
        </div>
      )}

      {/* FILTER CONTROLS */}
      {activeTab === 'browse' && (
        <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            {/* Seeking Tabs */}
            <div className="flex gap-1.5 bg-[#FAF8F5] p-1 rounded-2xl border border-[#E6E0D4]">
              <button
                onClick={() => setSelectedSeeking('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  selectedSeeking === 'all'
                    ? 'bg-[#8E44AD] text-white shadow-2xs'
                    : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                }`}
              >
                সকল
              </button>
              <button
                onClick={() => setSelectedSeeking('পাত্র চাই')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                  selectedSeeking === 'পাত্র চাই'
                    ? 'bg-blue-700 text-white shadow-2xs'
                    : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                }`}
              >
                <span>🤵 পাত্র চাই</span>
              </button>
              <button
                onClick={() => setSelectedSeeking('পাত্রী চাই')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                  selectedSeeking === 'পাত্রী চাই'
                    ? 'bg-rose-700 text-white shadow-2xs'
                    : 'text-[#5A6B6B] hover:text-[#2D3A3A]'
                }`}
              >
                <span>👰 পাত্রী চাই</span>
              </button>
            </div>

            {/* Religion Filter */}
            <select
              value={selectedReligion}
              onChange={(e) => setSelectedReligion(e.target.value as any)}
              className="bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs font-bold text-[#2D3A3A] focus:outline-none focus:border-[#8E44AD]"
            >
              <option key="rel-all" value="all">সকল ধর্ম</option>
              <option key="rel-islam" value="ইসলাম">ইসলাম</option>
              <option key="rel-hindu" value="হিন্দু">সনাতন (হিন্দু)</option>
              <option key="rel-buddh" value="বৌদ্ধ">বৌদ্ধ</option>
              <option key="rel-christian" value="খ্রিস্টান">খ্রিস্টান</option>
            </select>
          </div>

          {/* Cascading Area Filter (District ➔ Upazila ➔ Union ➔ Ward/Village) */}
          <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-2">
            <div className="text-[11px] font-bold text-[#8E44AD] flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#E8924A]" />
                <span>এলাকা ভিত্তিক ফিল্টারিং (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ ওয়ার্ড/গ্রাম):</span>
              </div>
              {(filterAddress.district !== 'সকল জেলা' || filterAddress.upazila || filterAddress.union || filterAddress.village) && (
                <button
                  type="button"
                  onClick={() => setFilterAddress({ district: 'সকল জেলা', upazila: '', union: '', village: '' })}
                  className="text-[10px] text-red-600 hover:underline font-bold cursor-pointer"
                >
                  ✕ ফিল্টার রিসেট
                </button>
              )}
            </div>
            <CascadingAddressSelector
              address={filterAddress}
              onChange={setFilterAddress}
              allowAllOption={true}
              layout="grid-4"
              villagePlaceholder="ওয়ার্ড নং / গ্রাম / এলাকার নাম..."
            />
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#736B5E] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="শিক্ষা, পেশা বা এলাকার প্রত্যাশা খুঁজুন..."
              className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl pl-9 pr-3 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#8E44AD]"
            />
          </div>
        </div>
      )}

      {/* TAB: MY LISTINGS */}
      {activeTab === 'my_posts' && currentUser && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-white p-4 rounded-3xl border border-[#E6E0D4]">
            <div>
              <h3 className="font-bold text-sm text-[#2D3A3A]">আমার পোস্টকৃত পাত্র-পাত্রীর বিজ্ঞাপনসমূহ</h3>
              <p className="text-xs text-[#736B5E]">মেয়াদ শেষ হলে পোস্ট স্বয়ংক্রিয়ভাবে হাইড হয়। আপনি চাইলে যেকোনো সময় নিজেই পোস্ট মুছে ফেলতে পারেন।</p>
            </div>
            <button
              onClick={() => setActiveTab('browse')}
              className="text-xs text-[#8E44AD] font-bold underline cursor-pointer"
            >
              সব পোস্ট দেখুন
            </button>
          </div>

          {myListings.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 text-center border border-[#E6E0D4] space-y-3">
              <Heart className="w-12 h-12 text-gray-300 mx-auto" />
              <p className="text-sm font-bold text-[#2D3A3A]">আপনি এখনও কোনো পাত্র-পাত্রীর বিজ্ঞাপন দেননি</p>
              <button
                onClick={() => setIsCreateModalOpen(true)}
                className="px-4 py-2 bg-[#8E44AD] text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                নতুন বিজ্ঞাপন দিন
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {myListings.map(item => {
                const expired = isPostExpired(item.expiresAt);
                return (
                  <div key={item.id} className="bg-white rounded-3xl p-5 border border-[#E6E0D4] shadow-xs space-y-3 relative">
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            item.seekingType === 'পাত্র চাই'
                              ? 'bg-blue-100 text-blue-900'
                              : 'bg-rose-100 text-rose-900'
                          }`}>
                            {item.seekingType}
                          </span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-100 text-stone-700">
                            {item.religion}
                          </span>
                          {expired ? (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-200 text-stone-700">
                              ⌛ মেয়াদ শেষ (Auto-hidden)
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-300">
                              🟢 লাইভ ({item.durationDays} দিন)
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-sm text-[#2D3A3A]">
                          বয়স: {item.age} বছর • উচ্চতা: {item.height} • {item.maritalStatus}
                        </h4>
                      </div>

                      <button
                        onClick={() => handleDeleteListing(item.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer"
                        title="পোস্টটি ডিলিট করুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="text-xs text-[#5A6B6B] bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-1">
                      <div>শিক্ষা: <strong>{item.education}</strong></div>
                      {item.profession && <div>পেশা: <strong>{item.profession}</strong></div>}
                      <div>এলাকা: {item.upazila}, {item.district}</div>
                      <div className="text-[11px] text-[#736B5E] pt-1">পোস্টের তারিখ: {item.createdAtFormatted}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* PUBLIC LISTINGS */}
      {activeTab === 'browse' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-[#5A6B6B] px-1">
            <span>মোট {publicListings.length}টি লাইভ বিজ্ঞাপন পাওয়া গেছে</span>
            <span>মেয়াদ: ১ দিন থেকে ৩ মাস (মেয়াদান্তে অটো-হাইড)</span>
          </div>

          {publicListings.length === 0 ? (
            <div className="bg-white rounded-3xl p-10 text-center border border-[#E6E0D4] space-y-3">
              <Heart className="w-12 h-12 text-gray-300 mx-auto" />
              <h3 className="font-bold text-sm text-[#2D3A3A]">কোনো পাত্র-পাত্রীর বিজ্ঞাপন পাওয়া যায়নি</h3>
              <p className="text-xs text-[#736B5E] max-w-sm mx-auto">
                অন্য কোনো জেলা বা ফিল্টার নির্বাচন করুন অথবা পরিবারের জন্য শালীন পাত্র-পাত্রীর বিজ্ঞাপন দিন।
              </p>
              <button
                onClick={() => {
                  setSelectedSeeking('all');
                  setSelectedReligion('all');
                  setFilterAddress({ district: 'সকল জেলা', upazila: '', union: '', village: '' });
                  setSearchQuery('');
                }}
                className="px-4 py-2 bg-[#8E44AD] text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                সব ফিল্টার রিসেট করুন
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {publicListings.map(post => {
                const isGroom = post.seekingType === 'পাত্র চাই';
                return (
                  <div
                    key={post.id}
                    className="bg-white rounded-3xl p-5 border border-[#E6E0D4] shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-3">
                      {/* Top Header Card */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          {/* Picture strictly replaced with cultural icon */}
                          <div className={`w-11 h-11 rounded-2xl flex items-center justify-center text-xl shrink-0 ${
                            isGroom ? 'bg-blue-100 text-blue-900 border border-blue-200' : 'bg-rose-100 text-rose-900 border border-rose-200'
                          }`}>
                            {isGroom ? '🤵' : '👰'}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                isGroom ? 'bg-blue-100 text-blue-900' : 'bg-rose-100 text-rose-900'
                              }`}>
                                {post.seekingType}
                              </span>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-50 text-purple-900 border border-purple-200">
                                {post.religion}
                              </span>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-100 text-stone-700">
                                {post.maritalStatus}
                              </span>
                            </div>
                            <h4 className="font-bold text-sm text-[#2D3A3A] mt-0.5">
                              বয়স: {post.age} বছর • উচ্চতা: {post.height}
                            </h4>
                          </div>
                        </div>

                        {/* Privacy Shield */}
                        <div className="flex items-center gap-1 bg-stone-100 text-[#736B5E] text-[10px] font-bold px-2 py-1 rounded-full shrink-0" title="ছবি প্রদর্শন ১০০% নিষিদ্ধ">
                          <EyeOff className="w-3 h-3 text-purple-700" />
                          <span>ছবিমুক্ত</span>
                        </div>
                      </div>

                      {/* Details Box */}
                      <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] text-xs space-y-1.5">
                        <div className="flex items-center gap-2 text-[#2D3A3A]">
                          <GraduationCap className="w-3.5 h-3.5 text-[#8E44AD] shrink-0" />
                          <span>শিক্ষা: <strong>{post.education}</strong></span>
                        </div>
                        {post.profession && (
                          <div className="flex items-center gap-2 text-[#2D3A3A]">
                            <Briefcase className="w-3.5 h-3.5 text-[#8E44AD] shrink-0" />
                            <span>পেশা: <strong>{post.profession}</strong></span>
                          </div>
                        )}
                        <div className="flex items-center gap-2 text-[#2D3A3A]">
                          <MapPin className="w-3.5 h-3.5 text-[#8E44AD] shrink-0" />
                          <span>এলাকা: <strong>{[post.village ? `গ্রাম/ওয়ার্ড: ${post.village}` : '', post.union ? `ইউনিয়ন: ${post.union}` : '', post.upazila, post.district].filter(Boolean).join(', ')}</strong></span>
                        </div>
                        {post.bloodGroup && (
                          <div className="text-[11px] text-[#5A6B6B]">
                            রক্তের গ্রুপ: <strong>{post.bloodGroup}</strong> • গায়ের রঙ: {post.complexion || 'স্বাভাবিক'}
                          </div>
                        )}
                      </div>

                      {/* Family & Expectations */}
                      <div className="space-y-2 text-xs text-[#2D3A3A]">
                        <div>
                          <strong className="text-[#8E44AD] block text-[11px]">পারিবারিক বিবরণ:</strong>
                          <p className="text-[#5A6B6B] leading-relaxed line-clamp-2 mt-0.5">
                            {post.familyInfo}
                          </p>
                        </div>
                        <div>
                          <strong className="text-rose-700 block text-[11px]">পাত্র/পাত্রী সম্পর্কে প্রত্যাশা:</strong>
                          <p className="text-[#5A6B6B] leading-relaxed line-clamp-2 mt-0.5">
                            {post.expectations}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* POSTER / GUARDIAN & IN-APP CONTACT ACTIONS */}
                    <div className="space-y-3 pt-3 border-t border-[#E6E0D4]">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-purple-100 text-[#8E44AD] font-bold text-xs flex items-center justify-center">
                            {post.posterName ? post.posterName.charAt(0) : 'G'}
                          </div>
                          <div>
                            <span className="font-bold text-xs text-[#2D3A3A] block">{post.posterName}</span>
                            <span className="text-[10px] text-[#736B5E] block">যোগাযোগকারী: {post.posterRelation}</span>
                          </div>
                        </div>

                        {/* Report button */}
                        <button
                          onClick={() => setReportingListing(post)}
                          className="text-[11px] text-red-600 hover:text-red-700 hover:bg-red-50 p-1.5 rounded-xl transition flex items-center gap-1 cursor-pointer"
                          title="অভিযোগ দায়ের করুন"
                        >
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>রিপোর্ট</span>
                        </button>
                      </div>

                      {/* Free In-App & Offline Contact Action Buttons */}
                      <div className="grid grid-cols-3 gap-2">
                        {/* In-App Audio Call */}
                        <button
                          onClick={() => {
                            if (onStartInAppCall) {
                              onStartInAppCall({
                                id: post.posterId,
                                name: post.posterName,
                                phone: post.posterPhone,
                                role: 'citizen'
                              });
                            }
                          }}
                          className="bg-[#8E44AD] hover:bg-purple-800 text-white py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 shadow-xs cursor-pointer"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>ফ্রি কল</span>
                        </button>

                        {/* In-App Chat */}
                        <button
                          onClick={() => {
                            if (onStartChat) {
                              onStartChat({
                                id: post.posterId,
                                name: post.posterName,
                                phone: post.posterPhone
                              });
                            }
                          }}
                          className="bg-[#FAF8F5] hover:bg-purple-50 text-[#2D3A3A] border border-[#E6E0D4] py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-[#8E44AD]" />
                          <span>চ্যাট</span>
                        </button>

                        {/* Voice Note */}
                        <button
                          onClick={() => {
                            if (onOpenVoiceNote) {
                              onOpenVoiceNote({
                                id: post.posterId,
                                name: post.posterName,
                                phone: post.posterPhone
                              });
                            }
                          }}
                          className="bg-[#FAF8F5] hover:bg-purple-50 text-[#2D3A3A] border border-[#E6E0D4] py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Mic className="w-3.5 h-3.5 text-[#8E44AD]" />
                          <span>ভয়েস</span>
                        </button>
                      </div>

                      {/* Direct phone call if allowed */}
                      {post.allowOfflineCall && (
                        <div className="text-center pt-1">
                          <a
                            href={`tel:${post.posterPhone}`}
                            className="text-[11px] font-bold text-purple-900 hover:underline inline-flex items-center gap-1"
                          >
                            <span>📞 সরাসরি অভিভাবকের ফোন: {post.posterPhone}</span>
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Bottom Transparency & Family Direct Discussion Notice */}
          <div className="bg-[#FAF8F5] p-4 rounded-3xl border border-[#D4C3A3] text-xs text-[#5A6B6B] flex items-start gap-3">
            <Info className="w-4 h-4 text-purple-800 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <strong className="text-purple-900 font-bold block">
                সরাসরি আলোচনা ও লেনদেনহীন নীতিমালা:
              </strong>
              <p>
                পল্লী সেবা কর্তৃপক্ষ কোনো প্রকার অর্থ লেনদেন বা ঘটকালি ফি গ্রহণ করে না। পাত্র-পাত্রীর তথ্য যাচাই, পারিবারিক খোঁজখবর নেওয়া এবং বিয়ের সার্বিক সিদ্ধান্ত সম্পূর্ণ উভয় পরিবারের সরাসরি আলোচনার বিষয়।
              </p>
            </div>
          </div>
        </div>
      )}

      {/* CREATE MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div 
            className="bg-white w-full max-w-2xl rounded-3xl p-6 shadow-2xl border border-[#E6E0D4] space-y-4 relative max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between border-b border-[#E6E0D4] pb-3">
              <div>
                <h3 className="font-bold text-lg text-[#2D3A3A] flex items-center gap-2">
                  <span>💍 পাত্র-পাত্রীর নতুন সন্ধান বিজ্ঞাপন</span>
                </h3>
                <p className="text-xs text-[#736B5E]">
                  ছবি সম্পূর্ণ নিষিদ্ধ। সঠিক ও মার্জিত তথ্য দিয়ে বিজ্ঞাপন দিন। মেয়াদান্তে পোস্ট স্বয়ংক্রিয়ভাবে হাইড হবে।
                </p>
              </div>
              <button 
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              {/* Seeking Type & Religion */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] block">ক্যাটাগরি:</label>
                  <select
                    value={seekingType}
                    onChange={(e) => setSeekingType(e.target.value as any)}
                    className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs font-bold text-[#2D3A3A] focus:outline-none focus:border-[#8E44AD]"
                  >
                    <option key="m-opt-groom" value="পাত্র চাই">🤵 পাত্র চাই (বরের সন্ধান)</option>
                    <option key="m-opt-bride" value="পাত্রী চাই">👰 পাত্রী চাই (কনের সন্ধান)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] block">ধর্ম:</label>
                  <select
                    value={religion}
                    onChange={(e) => setReligion(e.target.value as any)}
                    className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs font-bold text-[#2D3A3A] focus:outline-none focus:border-[#8E44AD]"
                  >
                    <option key="m-rel-islam" value="ইসলাম">ইসলাম</option>
                    <option key="m-rel-hindu" value="সনাতন (হিন্দু)">সনাতন (হিন্দু)</option>
                    <option key="m-rel-buddh" value="বৌদ্ধ">বৌদ্ধ</option>
                    <option key="m-rel-christian" value="খ্রিস্টান">খ্রিস্টান</option>
                    <option key="m-rel-other" value="অন্যান্য">অন্যান্য</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] block">বৈবাহিক অবস্থা:</label>
                  <select
                    value={maritalStatus}
                    onChange={(e) => setMaritalStatus(e.target.value as any)}
                    className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs font-bold text-[#2D3A3A] focus:outline-none focus:border-[#8E44AD]"
                  >
                    <option key="m-mar-unmarried" value="অবিবাহিত">অবিবাহিত</option>
                    <option key="m-mar-divorced" value="ডিভোর্সড">ডিভোর্সড</option>
                    <option key="m-mar-widowed" value="বিপত্নীক/বিধবা">বিপত্নীক / বিধবা</option>
                  </select>
                </div>
              </div>

              {/* Age, Height, Blood Group */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4]">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-[#5A6B6B] block">বয়স (বছর):</label>
                  <input
                    type="number"
                    min={18}
                    max={80}
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    required
                    className="w-full bg-white border border-[#E6E0D4] rounded-xl p-1.5 text-xs text-center font-bold"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-[#5A6B6B] block">উচ্চতা:</label>
                  <input
                    type="text"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    placeholder="যেমন: ৫ ফুট ৪ ইঞ্চি"
                    required
                    className="w-full bg-white border border-[#E6E0D4] rounded-xl p-1.5 text-xs text-center font-bold"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-[#5A6B6B] block">রক্তের গ্রুপ (ঐচ্ছিক):</label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    className="w-full bg-white border border-[#E6E0D4] rounded-xl p-1.5 text-xs text-center font-bold"
                  >
                    <option key="bg-ap" value="A+">A+</option>
                    <option key="bg-an" value="A-">A-</option>
                    <option key="bg-bp" value="B+">B+</option>
                    <option key="bg-bn" value="B-">B-</option>
                    <option key="bg-op" value="O+">O+</option>
                    <option key="bg-on" value="O-">O-</option>
                    <option key="bg-abp" value="AB+">AB+</option>
                    <option key="bg-abn" value="AB-">AB-</option>
                  </select>
                </div>
              </div>

              {/* Education & Profession */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] block">
                    শিক্ষাগত যোগ্যতা: <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={education}
                    onChange={(e) => setEducation(e.target.value)}
                    placeholder="যেমন: অনার্স (অর্থনীতি), এইচএসসি, দাওরায়ে হাদিস"
                    required
                    className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3.5 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#8E44AD]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#2D3A3A] block">পেশা (ঐচ্ছিক):</label>
                  <input
                    type="text"
                    value={profession}
                    onChange={(e) => setProfession(e.target.value)}
                    placeholder="যেমন: সরকারি শিক্ষক, ব্যাংকার, ব্যবসায়ী, অধ্যয়নরত"
                    className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3.5 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#8E44AD]"
                  />
                </div>
              </div>

              {/* Cascading Location Selector (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ ওয়ার্ড/গ্রাম) */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-purple-200 space-y-2">
                <label className="text-xs font-bold text-purple-950 block flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#8E44AD]" />
                  <span>পাত্র/পাত্রীর সঠিক ঠিকানা বা এলাকা নির্বাচন করুন * (জেলা ➔ উপজেলা ➔ ইউনিয়ন ➔ ওয়ার্ড/গ্রাম):</span>
                </label>
                <CascadingAddressSelector
                  address={postAddress}
                  onChange={setPostAddress}
                  layout="grid-2x2"
                  showVillage={true}
                  villagePlaceholder="যেমন: ৩নং ওয়ার্ড, দক্ষিণপাড়া"
                  required={true}
                />
              </div>

              {/* Family Details */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#2D3A3A] block">
                  পারিবারিক সংক্ষিপ্ত বিবরণ: <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={familyInfo}
                  onChange={(e) => setFamilyInfo(e.target.value)}
                  rows={2}
                  required
                  placeholder="পিতা ও মাতার পেশা, ভাই-বোনের সংখ্যা, পারিবারিক সংস্কৃতি ও পরিবেশ সম্পর্কে লিখুন..."
                  className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl p-3 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#8E44AD] leading-relaxed"
                />
              </div>

              {/* Expectations */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#2D3A3A] block">
                  পাত্র/পাত্রী সম্পর্কে প্রত্যাশা: <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={expectations}
                  onChange={(e) => setExpectations(e.target.value)}
                  rows={2}
                  required
                  placeholder="কেমন জীবনসঙ্গী আশা করেন? (দ্বীনদারি, শিক্ষা, পছন্দসই জেলা ইত্যাদি)..."
                  className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl p-3 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#8E44AD] leading-relaxed"
                />
              </div>

              {/* Poster Relationship */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#2D3A3A] block">বিজ্ঞাপনদাতার সাথে সম্পর্ক:</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['অভিভাবক (বাবা/মা)', 'ভাই/বোন', 'আত্মীয়', 'নিজেই'] as const).map(rel => (
                    <button
                      type="button"
                      key={rel}
                      onClick={() => setPosterRelation(rel)}
                      className={`p-2 rounded-xl text-xs font-bold border transition cursor-pointer text-center ${
                        posterRelation === rel
                          ? 'bg-purple-800 text-white border-purple-800'
                          : 'bg-[#FAF8F5] text-[#2D3A3A] border-[#E6E0D4]'
                      }`}
                    >
                      {rel}
                    </button>
                  ))}
                </div>
              </div>

              {/* Duration: 1 day to 3 months (Auto-Hide Rule) */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-purple-200 space-y-2">
                <label className="text-xs font-bold text-purple-950 block flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-[#8E44AD]" />
                  <span>বিজ্ঞাপনের মেয়াদ নির্বাচন করুন (মেয়াদ শেষে অটো-হাইড হবে):</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {DURATION_OPTIONS.map(opt => (
                    <button
                      type="button"
                      key={opt.days}
                      onClick={() => setDurationDays(opt.days)}
                      className={`p-2 rounded-xl text-xs font-bold border transition cursor-pointer text-center ${
                        durationDays === opt.days
                          ? 'bg-[#8E44AD] text-white border-[#8E44AD]'
                          : 'bg-white text-[#2D3A3A] border-[#E6E0D4]'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-[#736B5E]">
                  মেয়াদ শেষ হওয়ার পর বিজ্ঞাপনটি আর কারো কাছে দৃশ্যমান থাকবে না। আপনি যেকোনো সময় প্রোফাইল থেকে ডিলিট করতে পারবেন।
                </p>
              </div>

              {/* Notification Scope */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#D4E4BC] space-y-2">
                <label className="text-xs font-bold text-[#2D5A27] block flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#2D5A27]" />
                  <span>নোটিফিকেশন কতদূর পাঠাতে চান?</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNotificationScope('upazila')}
                    className={`p-2.5 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center justify-center gap-1.5 ${
                      notificationScope === 'upazila'
                        ? 'bg-[#2D5A27] text-white border-[#2D5A27]'
                        : 'bg-white text-[#2D3A3A] border-[#E6E0D4]'
                    }`}
                  >
                    <span>📍 উপজেলা পর্যন্ত</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setNotificationScope('district')}
                    className={`p-2.5 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center justify-center gap-1.5 ${
                      notificationScope === 'district'
                        ? 'bg-[#2D5A27] text-white border-[#2D5A27]'
                        : 'bg-white text-[#2D3A3A] border-[#E6E0D4]'
                    }`}
                  >
                    <span>🏛️ জেলা পর্যন্ত (পুরো জেলা)</span>
                  </button>
                </div>
              </div>

              {/* Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E6E0D4]">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100 transition cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl text-xs font-bold bg-[#8E44AD] text-white hover:bg-purple-900 transition cursor-pointer shadow-md disabled:opacity-50"
                >
                  {isSubmitting ? 'সংরক্ষণ করা হচ্ছে...' : 'বিজ্ঞাপন প্রকাশ করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REPORT MODAL */}
      {reportingListing && (
        <ReportListingModal
          isOpen={true}
          onClose={() => setReportingListing(null)}
          currentUser={currentUser}
          itemType="matrimony"
          itemId={reportingListing.id}
          itemTitle={`${reportingListing.seekingType} (${reportingListing.religion}) - বয়স ${reportingListing.age} বছর`}
          accusedUserId={reportingListing.posterId}
          accusedUserName={reportingListing.posterName}
          accusedUserPhone={reportingListing.posterPhone}
          onSuccessToast={(msg) => triggerToast(msg)}
        />
      )}
    </div>
  );
};
