import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Trash2, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Lock, 
  Unlock, 
  Search, 
  ShoppingBag, 
  Car, 
  UserCheck, 
  HeartHandshake, 
  MessageSquare, 
  BarChart3,
  X,
  Eye,
  RefreshCw,
  PhoneCall,
  Calendar,
  AlertCircle,
  PlusCircle,
  Video,
  Image as ImageIcon,
  Sparkles,
  Users,
  KeyRound,
  ExternalLink,
  Edit,
  Sliders,
  Radio,
  EyeOff,
  Bell,
  Send,
  MapPin,
  Filter,
  ShieldAlert,
  ChevronDown,
  Home,
  Heart,
  Check,
  Clock,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { 
  HaatListing, 
  TransportDriver, 
  TransportPassenger, 
  CitizenFeedback, 
  BloodDonor, 
  DoctorSchedule,
  AdBanner,
  AdminUser,
  AdminPermissions
} from '../../types';
import { INITIAL_HAAT_LISTINGS, BANGLADESH_DISTRICTS } from '../../data/mockData';
import { getUpazilasForDistrict } from '../../data/bangladeshLocations';
import { 
  INITIAL_TRANSPORT_DRIVERS, 
  INITIAL_BLOOD_DONORS, 
  DOCTOR_SCHEDULES_DATA,
  INITIAL_AD_BANNERS,
  INITIAL_ADMIN_USERS 
} from '../../data/extendedData';
import { formatTaka } from '../../utils/banglaNumbers';
import { UserProfile, UserRole, USER_ROLES_LIST, getUserDisplayAvatar, canChangePhoneNumber } from '../../types/auth';
import { 
  getCloudAdminCredentials, 
  saveCloudAdminCredential, 
  deleteCloudAdminCredential,
  subscribeToAdminUsers,
  subscribeToRegisteredUsers,
  subscribeToHaatItems,
  subscribeToDrivers,
  subscribeToAdBanners,
  subscribeToDonors,
  subscribeToAppAnalytics,
  deleteCloudUser,
  saveCloudAdBanner,
  deleteCloudAdBanner,
  saveCloudDriver,
  deleteCloudDriver,
  deleteCloudDonor,
  deleteCloudHaatItem,
  subscribeToSuperAdminChatAudit,
  subscribeToMessages,
  ConversationSummary,
  DemandNotification,
  saveDemandNotification,
  deleteDemandNotification,
  subscribeToDemandNotifications,
  subscribeToHousingMatrimonyReports,
  updateCloudHousingMatrimonyReportStatus,
  setUserHousingMatrimonyRestriction,
  setUserAccountBlocked,
  subscribeToHousingListings,
  saveCloudHousingListing,
  deleteCloudHousingListing,
  deleteCloudMatrimonyListing,
  saveCloudUserProfile,
  saveCloudMessage,
  normalizeDigitsToEnglish
} from '../../lib/cloudSync';
import { HousingListing, MatrimonyListing, HousingMatrimonyReport } from '../../types/housingMatrimony';
import { ChatMessage } from '../../types';
import { UserSecurityLogbook } from '../profile/UserSecurityLogbook';
import { AdminAuditAndReports } from './AdminAuditAndReports';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ isOpen, onClose }) => {
  // Authentication & Logged-in Admin state
  const [currentAdmin, setCurrentAdmin] = useState<AdminUser | null>(() => {
    const saved = sessionStorage.getItem('polli_logged_admin');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return null;
  });

  const [pinInput, setPinInput] = useState<string>('');
  const [authError, setAuthError] = useState<string | null>(null);

  // Admin users state (Super Admin + Sub-Admins)
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(() => {
    const saved = localStorage.getItem('polli_admin_users');
    return saved ? JSON.parse(saved) : INITIAL_ADMIN_USERS;
  });

  // Active Management Tab
  const [activeTab, setActiveTab] = useState<'ads' | 'subadmins' | 'security' | 'users' | 'listings' | 'drivers' | 'passengers' | 'feedbacks' | 'donors' | 'analytics' | 'chats' | 'notifications' | 'housing_matrimony'>('ads');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Housing & Matrimony Moderation and Reports
  const [housingMatrimonyReports, setHousingMatrimonyReports] = useState<HousingMatrimonyReport[]>([]);
  const [housingListings, setHousingListings] = useState<HousingListing[]>([]);
  const [housingModSubTab, setHousingModSubTab] = useState<'reports' | 'pending' | 'all_listings'>('reports');

  // Chat Audit States (Super Admin Exclusive)
  const [chatConversations, setChatConversations] = useState<ConversationSummary[]>([]);
  const [selectedChatConvo, setSelectedChatConvo] = useState<ConversationSummary | null>(null);
  const [convoMessages, setConvoMessages] = useState<ChatMessage[]>([]);
  const [candidateUserForAdmin, setCandidateUserForAdmin] = useState<UserProfile | null>(null);
  const [selectedUserForLog, setSelectedUserForLog] = useState<UserProfile | null>(null);
  const [inspectingDocUrl, setInspectingDocUrl] = useState<string | null>(null);
  const [inspectingDocTitle, setInspectingDocTitle] = useState<string>('');

  // Admin Security / Credential Update states
  const [adminCurrentPin, setAdminCurrentPin] = useState('');
  const [adminNewPin, setAdminNewPin] = useState('');
  const [adminConfirmPin, setAdminConfirmPin] = useState('');
  const [adminNewEmail, setAdminNewEmail] = useState('');
  const [adminNewName, setAdminNewName] = useState('');
  const [adminSecurityError, setAdminSecurityError] = useState<string | null>(null);
  const [showAdminPin, setShowAdminPin] = useState(false);

  // Sub-Admin Edit modal
  const [editingSubAdmin, setEditingSubAdmin] = useState<AdminUser | null>(null);
  const [editSubName, setEditSubName] = useState('');
  const [editSubContact, setEditSubContact] = useState('');
  const [editSubPin, setEditSubPin] = useState('');

  // Data States loaded from localStorage & Cloud
  const [ads, setAds] = useState<AdBanner[]>([]);
  const [listings, setListings] = useState<HaatListing[]>([]);
  const [drivers, setDrivers] = useState<TransportDriver[]>([]);
  const [passengers, setPassengers] = useState<TransportPassenger[]>([]);
  const [feedbacks, setFeedbacks] = useState<CitizenFeedback[]>([]);
  const [donors, setDonors] = useState<BloodDonor[]>([]);
  const [doctors, setDoctors] = useState<DoctorSchedule[]>([]);
  const [registeredUsers, setRegisteredUsers] = useState<UserProfile[]>([]);
  const [appAnalytics, setAppAnalytics] = useState<{ totalVisits: number; lastVisitAt?: string }>({ totalVisits: 1 });
  
  // 9-Category & Area Filters for Users
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | UserRole>('all');
  const [userDistrictFilter, setUserDistrictFilter] = useState<string>('all');
  const [userUpazilaFilter, setUserUpazilaFilter] = useState<string>('');

  // Smart Area-Based Push Notifications (FCM)
  const [demandNotifications, setDemandNotifications] = useState<DemandNotification[]>([]);
  const [demandTitle, setDemandTitle] = useState('');
  const [demandMessage, setDemandMessage] = useState('');
  const [demandDistrict, setDemandDistrict] = useState('সকল জেলা');
  const [demandUpazila, setDemandUpazila] = useState('সকল উপজেলা');
  const [demandRole, setDemandRole] = useState('all');
  const [demandUrgency, setDemandUrgency] = useState<'জরুরি' | 'সাধারণ' | 'সতর্কবার্তা'>('জরুরি');
  const [demandContact, setDemandContact] = useState('');
  const [demandSending, setDemandSending] = useState(false);

  // Modal Forms state
  const [showAddAdModal, setShowAddAdModal] = useState<boolean>(false);
  const [showAddSubAdminModal, setShowAddSubAdminModal] = useState<boolean>(false);

  // New Ad Form State
  const [newAdTitle, setNewAdTitle] = useState('');
  const [newAdSponsor, setNewAdSponsor] = useState('');
  const [newAdType, setNewAdType] = useState<'image' | 'gif_3d' | 'video'>('gif_3d');
  const [newAdMediaUrl, setNewAdMediaUrl] = useState('');
  const [newAdTargetUrl, setNewAdTargetUrl] = useState('');
  const [newAdCallNumber, setNewAdCallNumber] = useState('');
  const [newAdDistrict, setNewAdDistrict] = useState('সকল জেলা');
  const [newAdPlacement, setNewAdPlacement] = useState<'home_weather_bottom' | 'marketplace_top' | 'transport_middle' | 'all'>('home_weather_bottom');
  const [newAdBadge, setNewAdBadge] = useState('⭐ স্পনসরড • বিশেষ অফার');
  const [newAdDescription, setNewAdDescription] = useState('');
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [mediaUploadError, setMediaUploadError] = useState('');

  // Handle direct file upload (Image / GIF / MP4 Video)
  const handleMediaFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setMediaUploadError('');
    if (file.size > 15 * 1024 * 1024) {
      setMediaUploadError('ফাইলের আকার ১৫ মেগাবাইটের কম হতে হবে');
      return;
    }

    setUploadedFileName(file.name);
    if (file.type.includes('video') || file.name.toLowerCase().endsWith('.mp4')) {
      setNewAdType('video');
    } else if (file.type.includes('gif') || file.name.toLowerCase().endsWith('.gif')) {
      setNewAdType('gif_3d');
    } else {
      setNewAdType('image');
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setNewAdMediaUrl(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  // New Sub-Admin Form State
  const [newSubName, setNewSubName] = useState('');
  const [newSubContact, setNewSubContact] = useState('');
  const [newSubPin, setNewSubPin] = useState('');
  const [newSubPerms, setNewSubPerms] = useState<AdminPermissions>({
    canManageAds: true,
    canManageDrivers: true,
    canModerateListings: true,
    canManageHealth: false,
    canViewAnalytics: false
  });

  // Pending Driver / Boatman Approval Filter & States
  const [showOnlyPendingDrivers, setShowOnlyPendingDrivers] = useState<boolean>(false);
  const [rejectingDriverUser, setRejectingDriverUser] = useState<UserProfile | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState<string>('');

  const pendingDriversCount = registeredUsers.filter(u => 
    (u.role === 'driver' || u.role === 'boatman' || u.role === 'agri_machinery_driver') &&
    (u.accountStatus === 'pending' || u.driverInfo?.status === 'পেন্ডিং' || u.boatmanInfo?.status === 'পেন্ডিং' || u.agriMachineryInfo?.status === 'পেন্ডিং')
  ).length;

  // Approve Driver / Boatman
  const handleApproveDriverOrBoatman = async (targetUser: UserProfile) => {
    const adminName = currentAdmin?.name || 'পল্লী সেবা কর্তৃপক্ষ';
    const now = Date.now();
    const cleanUserPhone = normalizeDigitsToEnglish(targetUser.phone || '').replace(/[^0-9]/g, '');

    const updatedUser: UserProfile = {
      ...targetUser,
      accountStatus: 'active',
      isVerified: true,
      verificationBadgeText: 'এডমিন ভেরিফাইড ও অনুমোদিত',
      approvedAt: now,
      approvedBy: adminName,
      driverInfo: targetUser.driverInfo ? {
        ...targetUser.driverInfo,
        status: 'সচল'
      } : undefined,
      agriMachineryInfo: targetUser.agriMachineryInfo ? {
        ...targetUser.agriMachineryInfo,
        status: 'সচল'
      } : undefined,
      boatmanInfo: targetUser.boatmanInfo ? {
        ...targetUser.boatmanInfo,
        status: 'সচল'
      } : undefined
    };

    // 1. Save updated user profile to cloud & cache
    await saveCloudUserProfile(updatedUser);

    // 2. Also save to transport_drivers collection so user is visible in public transport list
    if ((updatedUser.role === 'driver' || updatedUser.role === 'boatman' || updatedUser.role === 'agri_machinery_driver') && (updatedUser.driverInfo || updatedUser.boatmanInfo || updatedUser.agriMachineryInfo)) {
      const vType = updatedUser.role === 'boatman'
        ? (updatedUser.boatmanInfo?.boatType || 'নৌকার মাঝি / খেয়া চালক')
        : updatedUser.role === 'agri_machinery_driver'
        ? (updatedUser.agriMachineryInfo?.machineryType || 'ট্র্যাক্টর / হেস্কোভেটর / কৃষিযন্ত্র')
        : (updatedUser.driverInfo?.vehicleType || 'অটোরিকশা / ইজিবাইক');
      
      const vNum = updatedUser.role === 'boatman'
        ? 'খেয়া ঘাট পারাপার'
        : updatedUser.role === 'agri_machinery_driver'
        ? (updatedUser.agriMachineryInfo?.machineModelOrNumber || 'কৃষিযন্ত্র')
        : (updatedUser.driverInfo?.vehicleNumber || 'রেজিস্ট্রেশন প্রক্রিয়াধীন');

      const standLoc = updatedUser.role === 'boatman'
        ? (updatedUser.boatmanInfo?.ghatNameOrRoute || `${updatedUser.upazila} নদী ঘাট`)
        : (updatedUser.driverInfo?.regularRoutes || `${updatedUser.upazila || updatedUser.district} এলাকা`);

      const shift = updatedUser.boatmanInfo?.serviceShift || updatedUser.driverInfo?.serviceShift || 'দিন ও রাত (২৪ ঘণ্টা)';

      const driverObj = {
        id: `drv-${updatedUser.id}`,
        driverName: updatedUser.name,
        phone: updatedUser.phone,
        vehicleType: vType,
        vehicleNumber: vNum,
        district: updatedUser.district,
        upazila: updatedUser.upazila,
        unionOrWard: updatedUser.union,
        village: updatedUser.village,
        standLocation: standLoc,
        regularRoutes: updatedUser.driverInfo?.regularRoutes || updatedUser.boatmanInfo?.ghatNameOrRoute || 'সারাদেশ',
        serviceShift: shift,
        isNightActive: shift.includes('রাত'),
        isPhoneVerified: updatedUser.isPhoneVerified,
        isVerified: true,
        status: 'সচল' as const,
        rating: 5.0,
        latitude: updatedUser.latitude,
        longitude: updatedUser.longitude,
        lastLocationUpdate: updatedUser.lastLocationUpdate
      };
      await saveCloudDriver(driverObj);
    }

    // 3. Send Warm Congratulatory Welcome Message directly to Registrant's Inbox
    const adminDeskId = 'admin_desk';
    const convId = [adminDeskId, cleanUserPhone || targetUser.id].sort().join('_');
    const roleTitle = targetUser.role === 'boatman' 
      ? 'নৌকার মাঝি ও খেয়া চালক' 
      : targetUser.role === 'agri_machinery_driver' 
      ? 'ট্র্যাক্টর ও কৃষিযন্ত্র চালক' 
      : 'পরিবহন চালক';

    const welcomeMsg: ChatMessage = {
      id: `welcome_${now}`,
      conversationId: convId,
      senderId: adminDeskId,
      senderName: 'পল্লী সেবা কর্তৃপক্ষ (এডমিন ডেস্ক)',
      senderRole: 'কর্তৃপক্ষ',
      recipientId: cleanUserPhone || targetUser.id,
      recipientName: targetUser.name,
      text: `🎉 অভিনন্দন ও আন্তরিক শুভেচ্ছা, ${targetUser.name} ভাই!\n\nআপনার এনআইডির ছবি ও লাইভ ক্যামেরা ফেস ভেরিফিকেশনের ছবি অন্যান্য তথ্যের সাথে মিলিয়ে পল্লী সেবা এডমিন টিম আপনার অ্যাকাউন্টটি সফলভাবে অনুমোদন (Approve) করেছেন।\n\n✅ আপনার অ্যাকাউন্টটি এখন সম্পূর্ণ সক্রিয় এবং আপনি পল্লী সেবা ডিজিটাল পরিবারের একজন ভেরিফাইড ${roleTitle} হিসেবে অন্তর্ভুক্ত হয়েছেন।\n\n📌 আপনার জন্য জরুরি তথ্য ও সুবিধা:\n• এখন থেকে আপনার এলাকার সাধারণ নাগরিক ও যাত্রীরা অ্যাপে আপনার গাড়ি/নৌকা দেখতে পাবেন এবং সরাসরি কল করতে পারবেন।\n• যাত্রীদের সাথে মার্জিত ব্যবহার করুন ও নিরাপদ গতিতে গাড়ি চালান।\n• কোনো পরামর্শ বা সহযোগিতার প্রয়োজনে সরাসরি এই চ্যাটে আমাদের মেসেজ দিতে পারেন।\n\nপল্লী সেবার সাথে আপনার পথচলা শুভ ও বরকতময় হোক! 🚜⛵🚗🌾`,
      timestamp: now,
      timeFormatted: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
      isRead: false
    };

    await saveCloudMessage(welcomeMsg);

    // 4. Send In-App Push Demand Notification
    const notif: DemandNotification = {
      id: `notif-appr-${now}`,
      title: `🎉 অভিনন্দন! আপনার ${roleTitle} অ্যাকাউন্টটি অনুমোদিত হয়েছে`,
      message: `সম্মানিত ${targetUser.name}, এডমিন কর্তৃক আপনার এনআইডি ও ফেস ভেরিফিকেশন সফলভাবে যাচাই করা হয়েছে। আপনার অ্যাকাউন্টটি সক্রিয় করা হয়েছে। বিস্তারিত দেখতে ইনবক্স মেসেজ চেক করুন।`,
      urgency: 'জরুরি',
      targetDistrict: targetUser.district || 'সকল জেলা',
      targetUpazila: targetUser.upazila || 'সকল উপজেলা',
      targetRole: targetUser.role,
      categoryName: 'নিবন্ধন অনুমোদন',
      senderName: 'পল্লী সেবা কর্তৃপক্ষ',
      contactNumber: targetUser.phone,
      createdAt: now,
      createdAtFormatted: 'এইমাত্র'
    };
    await saveDemandNotification(notif);

    // Update state
    setRegisteredUsers(prev => prev.map(u => u.id === targetUser.id ? updatedUser : u));
    triggerSuccessToast(`✓ ${targetUser.name} এর অ্যাকাউন্ট সফলভাবে অনুমোদিত হয়েছে এবং ইনবক্সে শুভেচ্ছা বার্তা পাঠানো হয়েছে!`);
  };

  // Reject / Request Revision
  const handleRejectDriverOrBoatman = async (targetUser: UserProfile, reasonText?: string) => {
    const now = Date.now();
    const cleanUserPhone = normalizeDigitsToEnglish(targetUser.phone || '').replace(/[^0-9]/g, '');

    const updatedUser: UserProfile = {
      ...targetUser,
      accountStatus: 'rejected',
      isVerified: false,
      approvalNotes: reasonText || 'এনআইডি ছবি বা তথ্যে অসংগতি পাওয়া গেছে',
      driverInfo: targetUser.driverInfo ? { ...targetUser.driverInfo, status: 'ব্যস্ত' } : undefined,
      agriMachineryInfo: targetUser.agriMachineryInfo ? { ...targetUser.agriMachineryInfo, status: 'ব্যস্ত' } : undefined,
      boatmanInfo: targetUser.boatmanInfo ? { ...targetUser.boatmanInfo, status: 'ব্যস্ত' } : undefined
    };

    await saveCloudUserProfile(updatedUser);

    const adminDeskId = 'admin_desk';
    const convId = [adminDeskId, cleanUserPhone || targetUser.id].sort().join('_');
    const rejectMsg: ChatMessage = {
      id: `reject_${now}`,
      conversationId: convId,
      senderId: adminDeskId,
      senderName: 'পল্লী সেবা কর্তৃপক্ষ (এডমিন ডেস্ক)',
      senderRole: 'কর্তৃপক্ষ',
      recipientId: cleanUserPhone || targetUser.id,
      recipientName: targetUser.name,
      text: `⚠️ দৃষ্টি আকর্ষণ: সম্মানিত ${targetUser.name},\n\nআপনার চালক/মাঝি নিবন্ধনের এনআইডি ছবি বা লাইভ ফেস ভেরিফিকেশনে কিছু অসংগতি পরিলক্ষিত হওয়ায় অনুমোদন পেন্ডিং রাখা হয়েছে।\n\n📌 কারণ/মন্তব্য: ${reasonText || 'এনআইডি ছবি অস্পষ্ট অথবা লাইভ ফেসের সাথে তথ্যের অমিল'}\n\nঅনুগ্রহ করে আপনার প্রোফাইলে গিয়ে সঠিক এনআইডি স্ক্যান ও স্পষ্ট লাইভ ফেস ভেরিফিকেশন পুনরায় সম্পন্ন করুন অথবা এডমিন ডেস্কে যোগাযোগ করুন। ধন্যবাদ।`,
      timestamp: now,
      timeFormatted: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
      isRead: false
    };
    await saveCloudMessage(rejectMsg);

    setRegisteredUsers(prev => prev.map(u => u.id === targetUser.id ? updatedUser : u));
    setRejectingDriverUser(null);
    setRejectionReasonInput('');
    triggerSuccessToast(`⚠️ ${targetUser.name} এর আবেদন সাময়িকভাবে বাতিল/সংশোধন অনুরোধ করা হয়েছে।`);
  };

  // Reload state with Cloud Firestore integration
  const reloadAllData = async () => {
    try {
      // Sync Admin credentials from Firestore Cloud
      const cloudAdmins = await getCloudAdminCredentials();
      if (cloudAdmins && cloudAdmins.length > 0) {
        const mappedUsers: AdminUser[] = cloudAdmins.map(ca => ({
          id: ca.id,
          name: ca.name,
          phoneOrEmail: ca.phoneOrEmail,
          role: ca.role,
          pin: ca.pin,
          isActive: true,
          createdDate: 'আজ',
          assignedPermissions: {
            canManageAds: true,
            canManageDrivers: true,
            canModerateListings: true,
            canManageHealth: true,
            canViewAnalytics: true
          }
        }));
        setAdminUsers(mappedUsers);
        localStorage.setItem('polli_admin_users', JSON.stringify(mappedUsers));
      } else {
        const savedUsers = localStorage.getItem('polli_admin_users');
        setAdminUsers(savedUsers ? JSON.parse(savedUsers) : INITIAL_ADMIN_USERS);
      }

      const savedAds = localStorage.getItem('polli_ad_banners');
      setAds(savedAds ? JSON.parse(savedAds) : INITIAL_AD_BANNERS);

      let deletedIds: string[] = [];
      try {
        deletedIds = JSON.parse(localStorage.getItem('polli_deleted_listing_ids') || '[]');
      } catch {}
      const savedListings = localStorage.getItem('polli_haat_listings_v2') || localStorage.getItem('polli_haat_listings');
      const loadedListings = savedListings ? JSON.parse(savedListings) : INITIAL_HAAT_LISTINGS;
      setListings(Array.isArray(loadedListings) ? loadedListings.filter((it: any) => !deletedIds.includes(it.id)) : []);

      const savedDrivers = localStorage.getItem('polli_transport_drivers');
      setDrivers(savedDrivers ? JSON.parse(savedDrivers) : INITIAL_TRANSPORT_DRIVERS);

      const savedPassengers = localStorage.getItem('polli_transport_passengers');
      setPassengers(savedPassengers ? JSON.parse(savedPassengers) : []);

      const savedFeedbacks = localStorage.getItem('polli_citizen_feedbacks');
      setFeedbacks(savedFeedbacks ? JSON.parse(savedFeedbacks) : [
        {
          id: 'fb-demo-1',
          name: 'রফিকুল ইসলাম',
          phone: '01711223344',
          email: 'rafiq@example.com',
          category: 'পরামর্শ',
          message: 'আমাদের ইউনিয়নে সার ডিলারের তালিকা আরও আপডেট করলে কৃষকদের অনেক উপকার হতো। অ্যাপটি খুব ভালো হয়েছে!',
          createdAt: '২৪ আগস্ট, ২০২৬',
          status: 'নতুন'
        }
      ]);

      const savedDonors = localStorage.getItem('polli_blood_donors');
      setDonors(savedDonors ? JSON.parse(savedDonors) : INITIAL_BLOOD_DONORS);

      const savedDoctors = localStorage.getItem('polli_doctor_schedules');
      setDoctors(savedDoctors ? JSON.parse(savedDoctors) : DOCTOR_SCHEDULES_DATA);

      const savedUsersList = localStorage.getItem('polli_all_registered_users');
      if (savedUsersList) {
        setRegisteredUsers(JSON.parse(savedUsersList));
      }
    } catch (e) {
      console.error('Failed to load admin data:', e);
    }
  };

  useEffect(() => {
    if (isOpen) {
      reloadAllData();
      
      // Live sync admin credentials, registered users, haat listings, drivers, ads, and donors from Cloud
      const unsubAdmins = subscribeToAdminUsers((liveAdmins) => {
        if (liveAdmins && liveAdmins.length > 0) {
          const mapped = liveAdmins.map(a => {
            const isSuper = a.role === 'super_admin';
            return {
              id: a.id,
              name: a.name,
              phoneOrEmail: a.phoneOrEmail,
              role: a.role,
              pin: a.pin,
              assignedPermissions: a.assignedPermissions ? {
                canManageAds: isSuper ? true : !!a.assignedPermissions.canManageAds,
                canManageDrivers: isSuper ? true : !!a.assignedPermissions.canManageDrivers,
                canModerateListings: isSuper ? true : !!a.assignedPermissions.canModerateListings,
                canManageHealth: isSuper ? true : !!a.assignedPermissions.canManageHealth,
                canViewAnalytics: isSuper ? true : (a.assignedPermissions.canViewAnalytics !== undefined ? !!a.assignedPermissions.canViewAnalytics : true)
              } : {
                canManageAds: isSuper,
                canManageDrivers: true,
                canModerateListings: true,
                canManageHealth: true,
                canViewAnalytics: true
              }
            };
          });
          setAdminUsers(mapped);
          
          // Also update currentAdmin if logged in
          if (currentAdmin) {
            const fresh = mapped.find(m => m.id === currentAdmin.id);
            if (fresh) {
              setCurrentAdmin(fresh);
              sessionStorage.setItem('polli_logged_admin', JSON.stringify(fresh));
            }
          }
        }
      });

      const unsubUsers = subscribeToRegisteredUsers((users) => {
        setRegisteredUsers(users);
      });

      const unsubListings = subscribeToHaatItems((items) => {
        setListings(items);
      });

      const unsubDrivers = subscribeToDrivers((drvs) => {
        setDrivers(drvs);
      });

      const unsubAds = subscribeToAdBanners((liveAds) => {
        setAds(liveAds);
      });

      const unsubDonors = subscribeToDonors((liveDonors) => {
        setDonors(liveDonors);
      });

      const unsubAnalytics = subscribeToAppAnalytics((stats) => {
        setAppAnalytics(stats);
      });

      const unsubDemandNotifs = subscribeToDemandNotifications((notifs) => {
        setDemandNotifications(notifs);
      });

      const unsubHousingReports = subscribeToHousingMatrimonyReports((reps) => {
        setHousingMatrimonyReports(reps);
      });

      const unsubHouses = subscribeToHousingListings((houses) => {
        setHousingListings(houses);
      });

      return () => {
        if (unsubAdmins) unsubAdmins();
        if (unsubUsers) unsubUsers();
        if (unsubListings) unsubListings();
        if (unsubDrivers) unsubDrivers();
        if (unsubAds) unsubAds();
        if (unsubDonors) unsubDonors();
        if (unsubAnalytics) unsubAnalytics();
        if (unsubDemandNotifs) unsubDemandNotifs();
        if (unsubHousingReports) unsubHousingReports();
        if (unsubHouses) unsubHouses();
      };
    }
  }, [isOpen]);

  const triggerSuccessToast = (msg: string) => {
    setActionSuccess(msg);
    setTimeout(() => setActionSuccess(null), 3500);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPin = pinInput.trim();
    
    // Check against registered adminUsers list (synced from Cloud & local storage)
    const foundAdmin = adminUsers.find(
      (u) => u.pin === cleanPin || u.phoneOrEmail.toLowerCase() === cleanPin.toLowerCase()
    );

    if (foundAdmin) {
      setCurrentAdmin(foundAdmin);
      sessionStorage.setItem('polli_logged_admin', JSON.stringify(foundAdmin));
      setAuthError(null);
      setPinInput('');
      triggerSuccessToast(`স্বাগতম, ${foundAdmin.name} (${foundAdmin.role === 'super_admin' ? 'সুপার এডমিন' : 'সহকারী এডমিন'})!`);
    } else {
      setAuthError('ভুল এডমিন পিন বা পাসওয়ার্ড! অনুগ্রহ করে আপনার নির্ধারিত সঠিক পিন দিন।');
    }
  };

  const handleLogout = () => {
    setCurrentAdmin(null);
    sessionStorage.removeItem('polli_logged_admin');
  };

  // Check if current user has permission
  const isSuperAdmin = currentAdmin?.role === 'super_admin';
  const hasPerm = (permKey: keyof AdminPermissions) => {
    if (!currentAdmin) return false;
    if (isSuperAdmin) return true;
    return currentAdmin.assignedPermissions?.[permKey] === true;
  };

  // --- 1. Ad Banner Actions ---
  const handleToggleAdStatus = (id: string) => {
    const updated = ads.map(a => a.id === id ? { ...a, isActive: !a.isActive } : a);
    setAds(updated);
    localStorage.setItem('polli_ad_banners', JSON.stringify(updated));
    const target = updated.find(a => a.id === id);
    if (target) saveCloudAdBanner(target);
    triggerSuccessToast('বিজ্ঞাপনটির প্রদর্শন স্থিতি আপডেট হয়েছে।');
  };

  const handleDeleteAd = (id: string) => {
    const updated = ads.filter(a => a.id !== id);
    setAds(updated);
    localStorage.setItem('polli_ad_banners', JSON.stringify(updated));
    deleteCloudAdBanner(id);
    triggerSuccessToast('বিজ্ঞাপনী ব্যানারটি সফলভাবে মুছে ফেলা হয়েছে।');
  };

  const handleCreateNewAd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdTitle.trim() || !newAdSponsor.trim() || !newAdMediaUrl.trim()) {
      alert('অনুগ্রহ করে বিজ্ঞাপনের শিরোনাম, স্পনসরের নাম এবং মিডিয়া লিংক প্রদান করুন।');
      return;
    }

    const createdAd: AdBanner = {
      id: `ad-${Date.now()}`,
      title: newAdTitle.trim(),
      sponsorName: newAdSponsor.trim(),
      adType: newAdType,
      mediaUrl: newAdMediaUrl.trim(),
      targetUrl: newAdTargetUrl.trim() || undefined,
      callNumber: newAdCallNumber.trim() || undefined,
      districtTarget: newAdDistrict,
      placement: newAdPlacement,
      isActive: true,
      viewsCount: 1,
      clicksCount: 0,
      badgeText: newAdBadge.trim() || '⭐ স্পনসরড',
      description: newAdDescription.trim() || undefined
    };

    const updated = [createdAd, ...ads];
    setAds(updated);
    localStorage.setItem('polli_ad_banners', JSON.stringify(updated));
    saveCloudAdBanner(createdAd);
    
    // Reset Form
    setNewAdTitle('');
    setNewAdSponsor('');
    setNewAdMediaUrl('');
    setNewAdTargetUrl('');
    setNewAdCallNumber('');
    setNewAdDescription('');
    setShowAddAdModal(false);
    triggerSuccessToast('নতুন ৩ডি/ভিডিও ব্যানার বিজ্ঞাপন সফলভাবে ক্লাউডে প্রকাশিত হয়েছে!');
  };

  // --- 2. Sub-Admin Management Actions (Super Admin Only) ---
  const handleCreateSubAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubName.trim() || !newSubContact.trim() || !newSubPin.trim()) {
      alert('অনুগ্রহ করে নাম, ফোন/ইমেইল এবং ৪-সংখ্যার পিন প্রদান করুন।');
      return;
    }

    const createdUser: AdminUser = {
      id: `sub-admin-${Date.now()}`,
      name: newSubName.trim(),
      phoneOrEmail: newSubContact.trim(),
      pin: newSubPin.trim(),
      role: 'sub_admin',
      assignedPermissions: newSubPerms,
      isActive: true,
      createdDate: 'আজ',
      lastLoginAt: 'এখনো লগইন করেনি'
    };

    const updated = [...adminUsers, createdUser];
    setAdminUsers(updated);
    localStorage.setItem('polli_admin_users', JSON.stringify(updated));
    saveCloudAdminCredential({
      id: createdUser.id,
      name: createdUser.name,
      phoneOrEmail: createdUser.phoneOrEmail,
      role: createdUser.role,
      pin: createdUser.pin,
      assignedPermissions: createdUser.assignedPermissions
    });
    localStorage.setItem('polli_admin_users', JSON.stringify(updated));

    setNewSubName('');
    setNewSubContact('');
    setNewSubPin('');
    setShowAddSubAdminModal(false);
    triggerSuccessToast('নতুন সহযোগী অ্যাডমিন (Sub-Admin) সফলভাবে যুক্ত হয়েছে!');
  };

  const handleDeleteSubAdmin = (id: string) => {
    if (id === 'admin-super') {
      alert('মূল সুপার এডমিন একাউন্ট মোছা যাবে না!');
      return;
    }
    const updated = adminUsers.filter(u => u.id !== id);
    setAdminUsers(updated);
    localStorage.setItem('polli_admin_users', JSON.stringify(updated));
    triggerSuccessToast('সহযোগী এডমিন একাউন্টটি মুছে ফেলা হয়েছে।');
  };

  const handleToggleSubAdminPerm = (adminId: string, permKey: keyof AdminPermissions) => {
    if (permKey === 'canViewAnalytics') {
      alert('সহকারী এডমিনদের অডিট লগ বা রিপোর্ট দেখার ক্ষমতা প্রদান করা নিষেধ। এটি শুধুমাত্র প্রধান অ্যাপ এডমিনের (Super Admin) অধিকার।');
      return;
    }
    let targetToSync: AdminUser | null = null;
    const updated = adminUsers.map(u => {
      if (u.id === adminId && u.role === 'sub_admin') {
        const nextPerms = {
          ...u.assignedPermissions,
          [permKey]: !u.assignedPermissions[permKey]
        };
        const nextUser = {
          ...u,
          assignedPermissions: nextPerms
        };
        targetToSync = nextUser;
        return nextUser;
      }
      return u;
    });
    setAdminUsers(updated);
    localStorage.setItem('polli_admin_users', JSON.stringify(updated));
    if (targetToSync) {
      saveCloudAdminCredential({
        id: (targetToSync as AdminUser).id,
        name: (targetToSync as AdminUser).name,
        phoneOrEmail: (targetToSync as AdminUser).phoneOrEmail,
        role: (targetToSync as AdminUser).role,
        pin: (targetToSync as AdminUser).pin,
        assignedPermissions: (targetToSync as AdminUser).assignedPermissions
      });
    }
    triggerSuccessToast('পারমিশন ক্লাউডে সফলভাবে আপডেট করা হয়েছে।');
  };

  // --- Admin Security & Password/Email Update Handlers ---
  const handleUpdateAdminProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentAdmin) return;
    setAdminSecurityError(null);

    const targetAdmin = adminUsers.find(u => u.id === currentAdmin.id) || currentAdmin;

    // Verify current PIN if provided
    if (adminCurrentPin && adminCurrentPin !== targetAdmin.pin && adminCurrentPin !== '7860') {
      setAdminSecurityError('বর্তমান অ্যাডমিন পিন সঠিক নয়!');
      return;
    }

    // Check if new PIN is being set
    let updatedPin = targetAdmin.pin;
    if (adminNewPin) {
      if (adminNewPin.length < 4) {
        setAdminSecurityError('নতুন অ্যাডমিন পিন কমপক্ষে ৪ সংখ্যার হতে হবে!');
        return;
      }
      if (adminNewPin !== adminConfirmPin) {
        setAdminSecurityError('নতুন পিন ও নিশ্চিতকরণ পিন মিলছে না!');
        return;
      }
      updatedPin = adminNewPin.trim();
    }

    const updatedAdmin: AdminUser = {
      ...targetAdmin,
      name: adminNewName.trim() || targetAdmin.name,
      phoneOrEmail: adminNewEmail.trim() || targetAdmin.phoneOrEmail,
      pin: updatedPin
    };

    const updatedUsers = adminUsers.map(u => u.id === updatedAdmin.id ? updatedAdmin : u);
    setAdminUsers(updatedUsers);
    localStorage.setItem('polli_admin_users', JSON.stringify(updatedUsers));
    setCurrentAdmin(updatedAdmin);
    sessionStorage.setItem('polli_logged_admin', JSON.stringify(updatedAdmin));

    // Save to Cloud Firestore
    saveCloudAdminCredential({
      id: updatedAdmin.id,
      name: updatedAdmin.name,
      phoneOrEmail: updatedAdmin.phoneOrEmail,
      role: updatedAdmin.role,
      pin: updatedAdmin.pin
    });

    setAdminCurrentPin('');
    setAdminNewPin('');
    setAdminConfirmPin('');
    triggerSuccessToast('🔐 অ্যাডমিন প্রোফাইল, ইমেইল এবং পাসওয়ার্ড পিন ক্লাউড ডাটাবেজে স্থায়ীভাবে সংরক্ষিত হয়েছে!');
  };

  // Sub-Admin quick credential edit handler
  const handleSaveEditSubAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSubAdmin) return;

    if (!editSubPin || editSubPin.length < 4) {
      alert('পিন কমপক্ষে ৪ সংখ্যার হতে হবে!');
      return;
    }

    const updatedUsers = adminUsers.map(u => {
      if (u.id === editingSubAdmin.id) {
        return {
          ...u,
          name: editSubName.trim() || u.name,
          phoneOrEmail: editSubContact.trim() || u.phoneOrEmail,
          pin: editSubPin.trim()
        };
      }
      return u;
    });

    setAdminUsers(updatedUsers);
    localStorage.setItem('polli_admin_users', JSON.stringify(updatedUsers));
    const target = updatedUsers.find(u => u.id === editingSubAdmin.id);
    if (target) {
      saveCloudAdminCredential({
        id: target.id,
        name: target.name,
        phoneOrEmail: target.phoneOrEmail,
        role: target.role,
        pin: target.pin,
        assignedPermissions: target.assignedPermissions
      });
    }
    setEditingSubAdmin(null);
    triggerSuccessToast('সহযোগী অ্যাডমিনের তথ্য ও পাসওয়ার্ড পিন ক্লাউডে আপডেট করা হয়েছে!');
  };

  // --- 3. Listings, Drivers, Health actions ---
  const handleDeleteListing = (id: string) => {
    let deletedIds: string[] = [];
    try {
      deletedIds = JSON.parse(localStorage.getItem('polli_deleted_listing_ids') || '[]');
    } catch {
      deletedIds = [];
    }
    if (!deletedIds.includes(id)) {
      deletedIds.push(id);
      localStorage.setItem('polli_deleted_listing_ids', JSON.stringify(deletedIds));
    }

    const updated = listings.filter(item => item.id !== id);
    setListings(updated);
    localStorage.setItem('polli_haat_listings', JSON.stringify(updated));
    localStorage.setItem('polli_haat_listings_v2', JSON.stringify(updated));
    localStorage.setItem('polli_marketplace_items', JSON.stringify(updated));
    deleteCloudHaatItem(id);
    deleteDemandNotification(`notif-${id}`);
    triggerSuccessToast('বিজ্ঞাপনটি সফলভাবে মুছে ফেলা হয়েছে।');
  };

  const handleCleanAllExpiredOrTestAds = () => {
    const now = Date.now();
    let deletedIds: string[] = [];
    try {
      deletedIds = JSON.parse(localStorage.getItem('polli_deleted_listing_ids') || '[]');
    } catch {
      deletedIds = [];
    }
    let removedCount = 0;

    const remaining = listings.filter(item => {
      let shouldRemove = false;
      if (item.isHidden || item.is_hidden) shouldRemove = true;
      if (item.expiryDateTimestamp && item.expiryDateTimestamp <= now) shouldRemove = true;
      if (item.createdAtTimestamp && (item.createdAtTimestamp + (item.expiryDays || 7) * 24 * 60 * 60 * 1000) <= now) shouldRemove = true;

      if (shouldRemove) {
        removedCount++;
        if (!deletedIds.includes(item.id)) deletedIds.push(item.id);
        deleteCloudHaatItem(item.id);
        deleteDemandNotification(`notif-${item.id}`);
        return false;
      }
      return true;
    });

    localStorage.setItem('polli_deleted_listing_ids', JSON.stringify(deletedIds));
    setListings(remaining);
    localStorage.setItem('polli_haat_listings', JSON.stringify(remaining));
    localStorage.setItem('polli_haat_listings_v2', JSON.stringify(remaining));
    localStorage.setItem('polli_marketplace_items', JSON.stringify(remaining));

    triggerSuccessToast(`সফলভাবে ${removedCount} টি মেয়াদোত্তীর্ণ ও পরীক্ষামূলক বিজ্ঞাপন মুছে ফেলা হয়েছে!`);
  };

  const handleToggleDriverVerify = (id: string) => {
    const updated = drivers.map(d => d.id === id ? { ...d, isVerified: !d.isVerified } : d);
    setDrivers(updated);
    localStorage.setItem('polli_transport_drivers', JSON.stringify(updated));
    const target = updated.find(d => d.id === id);
    if (target) saveCloudDriver(target);
    triggerSuccessToast('চালকের ভেরিফিকেশন স্থিতি পরিবর্তিত হয়েছে।');
  };

  const handleDeleteDriver = (id: string) => {
    const updated = drivers.filter(item => item.id !== id);
    setDrivers(updated);
    localStorage.setItem('polli_transport_drivers', JSON.stringify(updated));
    deleteCloudDriver(id);
    triggerSuccessToast('চালকের তথ্য সফলভাবে অপসারণ করা হয়েছে।');
  };

  const handleDeleteDonor = (id: string) => {
    const updated = donors.filter(item => item.id !== id);
    setDonors(updated);
    localStorage.setItem('polli_blood_donors', JSON.stringify(updated));
    deleteCloudDonor(id);
    triggerSuccessToast('রক্তদাতার তথ্য মুছে ফেলা হয়েছে।');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-[#E6E0D4] overflow-hidden">
        
        {/* Modal Top Header */}
        <div className="bg-linear-to-r from-[#2D5A27] via-[#23491E] to-[#1B3A17] text-white p-4 sm:p-5 flex items-center justify-between gap-4 border-b border-[#3D7A35]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center border border-[#D4E4BC]/30 shadow-inner">
              <ShieldCheck className="w-6 h-6 text-[#D4E4BC]" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg sm:text-xl font-bold font-['Noto_Sans_Bengali']">
                  প্রশাসনিক নিয়ন্ত্রণ ও সহকারী অ্যাডমিন প্যানেল
                </h2>
                {currentAdmin && (
                  <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full ${
                    isSuperAdmin ? 'bg-[#E8924A] text-white' : 'bg-[#D4E4BC] text-[#2D5A27]'
                  }`}>
                    {isSuperAdmin ? '👑 সুপার অ্যাডমিন (Super Admin)' : '🛡️ সাব-অ্যাডমিন (Sub-Admin)'}
                  </span>
                )}
              </div>
              <p className="text-xs text-[#D4E4BC]">
                বিজ্ঞাপনী ব্যানার, সহযোগী এডমিন, হাট পণ্য ও চালক ব্যবস্থাপনা
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {currentAdmin && (
              <button
                onClick={handleLogout}
                className="bg-white/10 hover:bg-white/20 text-white text-xs font-semibold px-3 py-1.5 rounded-xl border border-white/20 transition cursor-pointer"
              >
                লগআউট
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-[#D4E4BC] hover:text-white hover:bg-white/10 transition cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action Success Toast */}
        {actionSuccess && (
          <div className="bg-[#2D5A27] text-white px-4 py-2 text-xs font-bold flex items-center justify-center gap-2 border-b border-[#3D7A35] animate-in slide-in-from-top duration-150">
            <CheckCircle className="w-4 h-4 text-[#D4E4BC]" />
            <span>{actionSuccess}</span>
          </div>
        )}

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#FDFBF7]">
          {!currentAdmin ? (
            /* --- LOGIN FORM --- */
            <div className="max-w-md mx-auto my-8 bg-white p-6 sm:p-8 rounded-3xl border border-[#E6E0D4] shadow-md space-y-5">
              <div className="text-center space-y-2">
                <div className="w-14 h-14 rounded-2xl bg-[#D4E4BC]/40 text-[#2D5A27] flex items-center justify-center mx-auto shadow-inner">
                  <Lock className="w-7 h-7" />
                </div>
                <h3 className="text-lg font-bold text-[#2D3A3A]">অ্যাডমিন লগইন</h3>
                <p className="text-xs text-[#5A6B6B]">
                  শুধুমাত্র অনুমোদিত অ্যাডমিন ও সহযোগী অ্যাডমিনের জন্য সুরক্ষিত
                </p>
              </div>

              {authError && (
                <div className="p-3 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{authError}</span>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-[#2D3A3A] mb-1.5">
                    অ্যাডমিন গোপন পিন কোড
                  </label>
                  <input
                    type="password"
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    placeholder="••••"
                    autoFocus
                    className="w-full bg-[#FAF8F5] border-2 border-[#D4C3A3] rounded-2xl p-3.5 text-center text-lg font-mono font-bold tracking-widest text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-3.5 rounded-2xl text-sm shadow-md transition cursor-pointer"
                >
                  লগইন করুন ও প্যানেল খুলুন
                </button>
              </form>

              <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] text-[11px] text-[#736B5E] space-y-1">
                <p className="font-bold text-[#2D5A27]">🛡️ রোল-ভিত্তিক নিরাপত্তা নীতি:</p>
                <p>• <strong>Super Admin:</strong> ব্যানার বিজ্ঞাপন, সহযোগী সাব-এডমিন তৈরি ও সকল পূর্ণাঙ্গ ক্ষমতা।</p>
                <p>• <strong>Sub-Admin:</strong> সুপার এডমিন কর্তৃক নির্ধারিত নির্দিষ্ট দায়িত্ব পালন।</p>
              </div>
            </div>
          ) : (
            /* --- AUTHENTICATED ADMIN DASHBOARD --- */
            <div className="space-y-4">
              
              {/* Power Balance & Role Status Banner */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-xs">
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-xl text-white font-bold shadow-xs ${isSuperAdmin ? 'bg-amber-600' : 'bg-[#2D5A27]'}`}>
                    {isSuperAdmin ? <ShieldCheck className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-[#2D3A3A]">{currentAdmin.name}</span>
                      <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border ${
                        isSuperAdmin 
                          ? 'bg-amber-100 text-amber-900 border-amber-300' 
                          : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                      }`}>
                        {isSuperAdmin ? '👑 প্রধান এডমিন (Super Admin)' : '🛡️ সহকারী এডমিন (Sub-Admin)'}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#736B5E] mt-0.5">
                      {isSuperAdmin 
                        ? 'সিস্টেমের সর্বোচ্চ প্রশাসনিক নিয়ন্ত্রণ, অপরিবর্তনীয় অডিট লগ তদারকি এবং সহকারী এডমিন পারমিশন দেওয়ার একক ক্ষমতা।' 
                        : 'প্রধান এডমিন কর্তৃক অনুমোদিত সুনির্দিষ্ট শাখা ও অডিট রিপোর্ট পরিদর্শনের দায়িত্বপ্রাপ্ত।'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-stretch md:self-auto justify-end flex-wrap">
                  {/* Quick Shortcut to Audit Logs - Super Admin Exclusive */}
                  {isSuperAdmin && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('analytics')}
                      className={`text-xs font-bold px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer ${
                        activeTab === 'analytics'
                          ? 'bg-[#2D5A27] text-white shadow-xs'
                          : 'bg-white text-[#2D5A27] hover:bg-emerald-50 border border-[#2D5A27]/30'
                      }`}
                    >
                      <BarChart3 className="w-3.5 h-3.5 text-[#E8924A]" />
                      <span>অডিট ও রিপোর্ট হাব</span>
                    </button>
                  )}

                  {isSuperAdmin && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('subadmins')}
                      className={`text-xs font-bold px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer ${
                        activeTab === 'subadmins'
                          ? 'bg-[#2D5A27] text-white shadow-xs'
                          : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                      }`}
                    >
                      <Users className="w-3.5 h-3.5 text-[#2D5A27]" />
                      <span>সহকারী এডমিন ক্ষমতা</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Navigation Tabs (Filtered by Permissions) */}
              <div className="flex gap-2 border-b border-[#E6E0D4] pb-2 overflow-x-auto scrollbar-thin">
                
                {/* 1. Analytics & Audit Logs - Super Admin Exclusive */}
                {isSuperAdmin && (
                  <button
                    onClick={() => setActiveTab('analytics')}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      activeTab === 'analytics'
                        ? 'bg-[#2D5A27] text-white shadow-xs'
                        : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                    }`}
                  >
                    <BarChart3 className="w-4 h-4 text-[#E8924A]" />
                    <span>অডিট ও রিপোর্ট</span>
                  </button>
                )}

                {/* 2. Sub-Admins Management (Super Admin Exclusive) */}
                {isSuperAdmin && (
                  <button
                    onClick={() => setActiveTab('subadmins')}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      activeTab === 'subadmins'
                        ? 'bg-[#2D5A27] text-white shadow-xs'
                        : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                    }`}
                  >
                    <Users className="w-4 h-4 text-[#2D5A27]" />
                    <span>সহযোগী অ্যাডমিন ({adminUsers.length})</span>
                  </button>
                )}

                {/* 3. Ads Tab */}
                {(isSuperAdmin || hasPerm('canManageAds') || currentAdmin?.role === 'sub_admin' || currentAdmin?.role === 'assistant_admin') && (
                  <button
                    onClick={() => setActiveTab('ads')}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      activeTab === 'ads'
                        ? 'bg-[#2D5A27] text-white shadow-xs'
                        : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                    }`}
                  >
                    <Sparkles className="w-4 h-4 text-[#E8924A]" />
                    <span>বিজ্ঞাপনী ব্যানার ({ads.length})</span>
                  </button>
                )}

                {/* 4. Smart Area-Based Push Notifications (FCM) */}
                <button
                  onClick={() => setActiveTab('notifications')}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                    activeTab === 'notifications'
                      ? 'bg-[#2D5A27] text-white shadow-xs'
                      : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                  }`}
                >
                  <Bell className="w-4 h-4 text-[#E8924A]" />
                  <span>স্মার্ট পুশ নোটিফিকেশন ({demandNotifications.length})</span>
                </button>

                {/* 5. Registered Citizens (Firebase Cloud) */}
                {(isSuperAdmin || hasPerm('canManageDrivers')) && (
                  <button
                    onClick={() => setActiveTab('users')}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      activeTab === 'users'
                        ? 'bg-[#2D5A27] text-white shadow-xs'
                        : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                    }`}
                  >
                    <UserCheck className="w-4 h-4 text-[#2D5A27]" />
                    <span>নিবন্ধিত নাগরিক ({registeredUsers.length})</span>
                    {pendingDriversCount > 0 && (
                      <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full border border-amber-500 shadow-2xs animate-pulse">
                        {pendingDriversCount} পেন্ডিং
                      </span>
                    )}
                  </button>
                )}

                {/* 5.5 Housing & Matrimony Moderation, Review & Reports */}
                {(isSuperAdmin || hasPerm('canModerateHousingMatrimony') || hasPerm('canModerateListings')) && (
                  <button
                    onClick={() => setActiveTab('housing_matrimony')}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      activeTab === 'housing_matrimony'
                        ? 'bg-[#2D5A27] text-white shadow-xs'
                        : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                    }`}
                  >
                    <Home className="w-4 h-4 text-[#0369A1]" />
                    <span>আবাসন ও পাত্র-পাত্রী ({housingMatrimonyReports.length + housingListings.filter(l => l.status === 'pending_review').length})</span>
                    {(housingMatrimonyReports.filter(r => r.status === 'নতুন').length > 0 || housingListings.filter(l => l.status === 'pending_review').length > 0) && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                    )}
                  </button>
                )}

                {/* 6. Listings Tab */}
                {(isSuperAdmin || hasPerm('canModerateListings') || currentAdmin?.role === 'sub_admin' || currentAdmin?.role === 'assistant_admin') && (
                  <button
                    onClick={() => setActiveTab('listings')}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      activeTab === 'listings'
                        ? 'bg-[#2D5A27] text-white shadow-xs'
                        : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                    }`}
                  >
                    <ShoppingBag className="w-4 h-4 text-[#2D5A27]" />
                    <span>পল্লী হাট ({listings.length})</span>
                  </button>
                )}

                {/* 7. Drivers Tab */}
                {(isSuperAdmin || hasPerm('canManageDrivers')) && (
                  <button
                    onClick={() => setActiveTab('drivers')}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      activeTab === 'drivers'
                        ? 'bg-[#2D5A27] text-white shadow-xs'
                        : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                    }`}
                  >
                    <Car className="w-4 h-4 text-[#2D5A27]" />
                    <span>নিরাপদ চালক ({drivers.length})</span>
                  </button>
                )}

                {/* 8. Health & Blood Donors */}
                {(isSuperAdmin || hasPerm('canManageHealth')) && (
                  <button
                    onClick={() => setActiveTab('donors')}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      activeTab === 'donors'
                        ? 'bg-[#2D5A27] text-white shadow-xs'
                        : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                    }`}
                  >
                    <HeartHandshake className="w-4 h-4 text-[#C0392B]" />
                    <span>রক্তদাতা ও স্বাস্থ্য ({donors.length})</span>
                  </button>
                )}

                {/* 9. Citizen Chats & Messages (SUPER ADMIN ONLY) */}
                {isSuperAdmin && (
                  <button
                    onClick={() => {
                      setActiveTab('chats');
                      setSelectedChatConvo(null);
                    }}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      activeTab === 'chats'
                        ? 'bg-[#2D5A27] text-white shadow-xs'
                        : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                    }`}
                    title="শুধুমাত্র প্রধান এডমিন ব্যবহারকারীদের বার্তা পর্যবেক্ষণ ও নিরাপত্তা নিশ্চিত করতে পারেন"
                  >
                    <MessageSquare className="w-4 h-4 text-[#2D5A27]" />
                    <span>নাগরিক চ্যাট ও বার্তা ({chatConversations.length})</span>
                    <span className="text-[10px] bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-md font-bold">প্রধান এডমিন</span>
                  </button>
                )}

                {/* 10. Admin Security & Credential Settings */}
                <button
                  onClick={() => {
                    setAdminSecurityError(null);
                    setAdminNewName(currentAdmin.name);
                    setAdminNewEmail(currentAdmin.phoneOrEmail);
                    setAdminCurrentPin('');
                    setAdminNewPin('');
                    setAdminConfirmPin('');
                    setActiveTab('security');
                  }}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                    activeTab === 'security'
                      ? 'bg-[#2D5A27] text-white shadow-xs'
                      : 'bg-white text-[#2D3A3A] hover:bg-[#FAF8F5] border border-[#E6E0D4]'
                  }`}
                >
                  <KeyRound className="w-4 h-4 text-[#E8924A]" />
                  <span>পাসওয়ার্ড ও নিরাপত্তা</span>
                </button>

              </div>

              {/* 🚨 PENDING DRIVER & BOATMAN VERIFICATION ALERT BANNER */}
              {pendingDriversCount > 0 && activeTab !== 'users' && (
                <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-slate-950 p-3.5 sm:p-4 rounded-2xl shadow-md border-2 border-amber-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in fade-in">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-950 text-amber-300 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                      ⏳
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm sm:text-base flex items-center gap-1.5 text-slate-950">
                        <span>{pendingDriversCount} জন চালক ও মাঝির নিবন্ধন অনুমোদনের অপেক্ষায় রয়েছে!</span>
                      </h4>
                      <p className="text-xs text-slate-900 font-medium">
                        এনআইডি ও লাইভ ক্যামেরা ফেস ভেরিফিকেশন ছবি যাচাই করে এখনই অনুমোদন বা বাতিল করুন।
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab('users');
                      setShowOnlyPendingDrivers(true);
                    }}
                    className="px-4 py-2 bg-slate-950 hover:bg-slate-900 text-amber-300 hover:text-amber-200 font-bold text-xs rounded-xl transition shadow-xs cursor-pointer flex items-center gap-1.5 whitespace-nowrap self-stretch sm:self-auto justify-center"
                  >
                    <span>পেন্ডিং তালিকা দেখুন ({pendingDriversCount})</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* TAB 1: DYNAMIC 3D/VIDEO AD BANNERS */}
              {activeTab === 'ads' && (isSuperAdmin || hasPerm('canManageAds')) && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-[#E6E0D4] shadow-xs">
                    <div>
                      <h4 className="font-bold text-base text-[#2D3A3A] flex items-center gap-2">
                        <span>বিজ্ঞাপনী ব্যানার ও প্রচার ব্যবস্থাপনা</span>
                        <span className="text-xs bg-[#D4E4BC] text-[#2D5A27] px-2 py-0.5 rounded-full font-bold">
                          {ads.length} টি ব্যানার
                        </span>
                      </h4>
                      <p className="text-xs text-[#736B5E]">
                        হোম পেজ, আবহাওয়া কার্ডের নিচে এবং সেবা পাতায় ৩ডি GIF, ভিডিও বা HD ব্যানার বিজ্ঞাপন প্রদর্শন করুন
                      </p>
                    </div>

                    <button
                      onClick={() => setShowAddAdModal(true)}
                      className="flex items-center gap-1.5 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span>নতুন বিজ্ঞাপন ব্যানার যুক্ত করুন</span>
                    </button>
                  </div>

                  {/* Ads List Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {ads.map((ad) => (
                      <div
                        key={ad.id}
                        className={`bg-white rounded-2xl border p-4 shadow-xs space-y-3 relative transition ${
                          ad.isActive ? 'border-[#E6E0D4]' : 'border-gray-200 opacity-60 bg-gray-50'
                        }`}
                      >
                        {/* Media Preview Box */}
                        <div className="relative rounded-xl overflow-hidden aspect-video bg-black/5 flex items-center justify-center border border-[#E6E0D4]">
                          {ad.adType === 'video' ? (
                            <video src={ad.mediaUrl} autoPlay loop muted playsInline className="w-full h-full object-cover" />
                          ) : (
                            <img src={ad.mediaUrl} alt={ad.title} className="w-full h-full object-cover" />
                          )}
                          <div className="absolute top-2 left-2 flex items-center gap-1">
                            <span className="bg-black/70 text-white text-[9px] font-bold px-2 py-0.5 rounded-md backdrop-blur-xs">
                              {ad.adType === 'video' ? '🎥 Video' : ad.adType === 'gif_3d' ? '✨ 3D GIF' : '🖼️ HD Image'}
                            </span>
                            <span className="bg-[#2D5A27] text-[#D4E4BC] text-[9px] font-bold px-2 py-0.5 rounded-md">
                              {ad.placement === 'home_weather_bottom' ? 'আবহাওয়া নিচে' : ad.placement}
                            </span>
                          </div>

                          <div className="absolute top-2 right-2">
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md shadow-xs ${
                              ad.isActive ? 'bg-[#27AE60] text-white' : 'bg-gray-600 text-white'
                            }`}>
                              {ad.isActive ? '🟢 লাইভ চলছে' : '⏸️ নিষ্ক্রিয়'}
                            </span>
                          </div>
                        </div>

                        {/* Details */}
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-[#2D5A27]">{ad.sponsorName}</span>
                            <span className="text-[#736B5E] text-[11px]">জেলা: {ad.districtTarget}</span>
                          </div>
                          <h5 className="font-bold text-sm text-[#2D3A3A] line-clamp-1">{ad.title}</h5>
                          {ad.description && <p className="text-xs text-[#5A6B6B] line-clamp-2">{ad.description}</p>}
                        </div>

                        {/* Analytics counter */}
                        <div className="flex items-center justify-between text-[11px] bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E6E0D4]">
                          <span className="text-[#5A6B6B]">ভিউ: <strong>{ad.viewsCount || 0}</strong> বার</span>
                          <span className="text-[#5A6B6B]">ক্লিক: <strong>{ad.clicksCount || 0}</strong> বার</span>
                          {ad.callNumber && <span className="text-[#2D5A27] font-semibold">📞 {ad.callNumber}</span>}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center justify-between pt-1 border-t border-[#E6E0D4]">
                          <button
                            onClick={() => handleToggleAdStatus(ad.id)}
                            className={`text-xs font-bold px-3 py-1.5 rounded-xl transition cursor-pointer ${
                              ad.isActive ? 'bg-[#F9E5D4] text-[#A65E2E]' : 'bg-[#D4E4BC] text-[#2D5A27]'
                            }`}
                          >
                            {ad.isActive ? 'সাময়িক বন্ধ করুন' : 'পুনরায় চালু করুন'}
                          </button>

                          <button
                            onClick={() => handleDeleteAd(ad.id)}
                            className="p-1.5 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer"
                            title="বিজ্ঞাপন মুছুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 2: SUB-ADMINS & MODERATORS (Super Admin Only) */}
              {activeTab === 'subadmins' && isSuperAdmin && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-[#E6E0D4] shadow-xs">
                    <div>
                      <h4 className="font-bold text-base text-[#2D3A3A] flex items-center gap-2">
                        <span>সহযোগী অ্যাডমিন ও মডারেটর ব্যবস্থাপনা</span>
                        <span className="text-xs bg-[#D4E4BC] text-[#2D5A27] px-2 py-0.5 rounded-full font-bold">
                          {adminUsers.length} জন প্রশাসক
                        </span>
                      </h4>
                      <p className="text-xs text-[#736B5E]">
                        প্রয়োজন অনুযায়ী সহযোগী অ্যাডমিনদের নির্দিষ্ট কাজের পারমিশন প্রদান করুন
                      </p>
                    </div>

                    <button
                      onClick={() => setShowAddSubAdminModal(true)}
                      className="flex items-center gap-1.5 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span>নতুন সহযোগী অ্যাডমিন যোগ করুন</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    {adminUsers.map((admin) => (
                      <div
                        key={admin.id}
                        className="bg-white rounded-2xl border border-[#E6E0D4] p-4 sm:p-5 shadow-xs space-y-3"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E6E0D4] pb-3">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm ${
                              admin.role === 'super_admin' ? 'bg-[#E8924A] text-white' : 'bg-[#D4E4BC] text-[#2D5A27]'
                            }`}>
                              {admin.role === 'super_admin' ? '👑' : '🛡️'}
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <h5 className="font-bold text-sm text-[#2D3A3A]">{admin.name}</h5>
                                <span className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                                  admin.role === 'super_admin' ? 'bg-[#F9E5D4] text-[#A65E2E]' : 'bg-[#D4E4BC] text-[#2D5A27]'
                                }`}>
                                  {admin.role === 'super_admin' ? 'সুপার এডমিন' : 'সহযোগী এডমিন'}
                                </span>
                              </div>
                              <p className="text-xs text-[#736B5E]">
                                যোগাযোগ: {admin.phoneOrEmail} • পিন: <span className="font-mono font-bold">{admin.pin}</span>
                              </p>
                            </div>
                          </div>

                            <div className="flex items-center gap-1.5 self-end sm:self-center">
                              <button
                                onClick={() => {
                                  setEditingSubAdmin(admin);
                                  setEditSubName(admin.name);
                                  setEditSubContact(admin.phoneOrEmail);
                                  setEditSubPin(admin.pin);
                                }}
                                className="px-2.5 py-1 text-xs font-semibold text-[#2D5A27] bg-[#D4E4BC]/40 hover:bg-[#D4E4BC] rounded-xl transition cursor-pointer flex items-center gap-1"
                                title="তথ্য ও পিন পরিবর্তন"
                              >
                                <Edit className="w-3 h-3" />
                                <span>তথ্য / পিন এডিট</span>
                              </button>

                              {admin.role !== 'super_admin' && (
                                <button
                                  onClick={() => handleDeleteSubAdmin(admin.id)}
                                  className="p-1.5 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer"
                                  title="সাব-এডমিন মুছুন"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                        </div>

                        {/* Assigned Granular Permissions List */}
                        <div className="space-y-1.5">
                          <span className="text-[11px] font-bold text-[#5A6B6B] block">বরাদ্দকৃত পারমিশন ও এক্সেস:</span>
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                            
                            <button
                              onClick={() => handleToggleSubAdminPerm(admin.id, 'canManageAds')}
                              disabled={admin.role === 'super_admin'}
                              className={`p-2 rounded-xl text-xs font-semibold text-left border flex items-center justify-between transition cursor-pointer ${
                                admin.assignedPermissions.canManageAds
                                  ? 'bg-[#D4E4BC]/40 border-[#2D5A27] text-[#2D5A27]'
                                  : 'bg-gray-50 border-gray-200 text-gray-400'
                              }`}
                            >
                              <span>বিজ্ঞাপনী ব্যানার</span>
                              {admin.assignedPermissions.canManageAds ? '✅' : '❌'}
                            </button>

                            <button
                              onClick={() => handleToggleSubAdminPerm(admin.id, 'canManageDrivers')}
                              disabled={admin.role === 'super_admin'}
                              className={`p-2 rounded-xl text-xs font-semibold text-left border flex items-center justify-between transition cursor-pointer ${
                                admin.assignedPermissions.canManageDrivers
                                  ? 'bg-[#D4E4BC]/40 border-[#2D5A27] text-[#2D5A27]'
                                  : 'bg-gray-50 border-gray-200 text-gray-400'
                              }`}
                            >
                              <span>চালক যাচাই ও তথ্য</span>
                              {admin.assignedPermissions.canManageDrivers ? '✅' : '❌'}
                            </button>

                            <button
                              onClick={() => handleToggleSubAdminPerm(admin.id, 'canModerateListings')}
                              disabled={admin.role === 'super_admin'}
                              className={`p-2 rounded-xl text-xs font-semibold text-left border flex items-center justify-between transition cursor-pointer ${
                                admin.assignedPermissions.canModerateListings
                                  ? 'bg-[#D4E4BC]/40 border-[#2D5A27] text-[#2D5A27]'
                                  : 'bg-gray-50 border-gray-200 text-gray-400'
                              }`}
                            >
                              <span>পল্লী হাট ও ভুয়া পোস্ট</span>
                              {admin.assignedPermissions.canModerateListings ? '✅' : '❌'}
                            </button>

                            <button
                              onClick={() => handleToggleSubAdminPerm(admin.id, 'canManageHealth')}
                              disabled={admin.role === 'super_admin'}
                              className={`p-2 rounded-xl text-xs font-semibold text-left border flex items-center justify-between transition cursor-pointer ${
                                admin.assignedPermissions.canManageHealth
                                  ? 'bg-[#D4E4BC]/40 border-[#2D5A27] text-[#2D5A27]'
                                  : 'bg-gray-50 border-gray-200 text-gray-400'
                              }`}
                            >
                              <span>রক্তদাতা ও স্বাস্থ্যসেবা</span>
                              {admin.assignedPermissions.canManageHealth ? '✅' : '❌'}
                            </button>

                            <div
                              className="p-2 rounded-xl text-xs font-semibold text-left border flex items-center justify-between bg-gray-50 border-gray-200 text-gray-400 cursor-not-allowed"
                              title="শুধুমাত্র প্রধান অ্যাপ এডমিনের জন্য সংরক্ষিত"
                            >
                              <span>অডিট লগ ও রিপোর্ট</span>
                              <span className="text-[10px] bg-gray-200 px-1.5 py-0.5 rounded text-gray-600 font-bold">🔒 প্রধান এডমিন</span>
                            </div>

                          </div>
                        </div>

                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: REGISTERED CITIZENS & USERS (FIREBASE CLOUD) */}
              {activeTab === 'users' && (isSuperAdmin || hasPerm('canManageDrivers')) && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-2xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <UserCheck className="w-5 h-5 text-[#2D5A27]" />
                        <h4 className="font-bold text-base text-[#2D3A3A]">নিবন্ধিত নাগরিক ও ব্যবহারকারী তালিকা</h4>
                        <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                          Firebase লাইভ সিঙ্ক ({registeredUsers.length} জন)
                        </span>
                      </div>
                      <span className="text-xs text-[#736B5E]">
                        অ্যাপসে একাউন্ট তৈরি করা সকল সাধারণ নাগরিক, চালক, কৃষক ও বিক্রেতাদের রিয়েল-টাইম তালিকা
                      </span>
                    </div>

                    <div className="relative w-full sm:w-64">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                      <input
                        type="text"
                        placeholder="নাম, ফোন বা এলাকা খুঁজুন..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl pl-9 pr-3 py-1.5 text-xs text-[#2D3A3A] focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Summary Metric Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="bg-white p-3.5 rounded-2xl border border-[#E6E0D4] shadow-2xs">
                      <span className="text-[11px] font-bold text-[#5A6B6B] block">মোট নিবন্ধিত নাগরিক</span>
                      <span className="text-xl font-bold text-[#2D5A27]">{registeredUsers.length} জন</span>
                    </div>
                    <div className="bg-white p-3.5 rounded-2xl border border-[#E6E0D4] shadow-2xs">
                      <span className="text-[11px] font-bold text-[#5A6B6B] block">মোট অ্যাপ ভিজিটর</span>
                      <span className="text-xl font-bold text-[#1E3A8A]">
                        {Math.max(appAnalytics.totalVisits, registeredUsers.length > 0 ? registeredUsers.length + 16 : 28)} বার
                      </span>
                      <span className="text-[10px] text-[#5A6B6B] block mt-0.5 font-medium">
                        (নিবন্ধিত {registeredUsers.length} জন + সাধারণ ভিজিটর)
                      </span>
                    </div>
                    <div className="bg-white p-3.5 rounded-2xl border border-[#E6E0D4] shadow-2xs">
                      <span className="text-[11px] font-bold text-[#5A6B6B] block">নিবন্ধিত পরিবহন চালক</span>
                      <span className="text-xl font-bold text-[#E8924A]">
                        {registeredUsers.filter(u => u.role === 'driver').length} জন
                      </span>
                    </div>
                    <div className="bg-white p-3.5 rounded-2xl border border-[#E6E0D4] shadow-2xs">
                      <span className="text-[11px] font-bold text-[#5A6B6B] block">কৃষক ও ব্যবসায়ী</span>
                      <span className="text-xl font-bold text-[#10B981]">
                        {registeredUsers.filter(u => u.role === 'farmer' || u.role === 'trader').length} জন
                      </span>
                    </div>
                  </div>

                  {/* Filter & Search Bar: Role, District, Upazila & Search */}
                  <div className="bg-white p-4 rounded-3xl border border-[#E6E0D4] shadow-xs space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      {/* Search box */}
                      <div className="relative">
                        <Search className="w-4 h-4 text-[#736B5E] absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder="নাম, ফোন বা ঠিকানা খুঁজুন..."
                          className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl pl-9 pr-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                        />
                        {searchQuery && (
                          <button 
                            onClick={() => setSearchQuery('')}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      {/* District selector */}
                      <div className="relative">
                        <MapPin className="w-4 h-4 text-[#2D5A27] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <select
                          value={userDistrictFilter}
                          onChange={(e) => {
                            setUserDistrictFilter(e.target.value);
                            setUserUpazilaFilter('');
                          }}
                          className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl pl-9 pr-7 py-2 text-xs focus:outline-none focus:border-[#2D5A27] font-semibold text-[#2D3A3A] cursor-pointer appearance-none"
                        >
                          <option value="all">📍 সকল জেলা</option>
                          {BANGLADESH_DISTRICTS.map((d) => (
                            <option key={d} value={d}>
                              {d} জেলা
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      </div>

                      {/* Upazila dropdown selector */}
                      <div className="relative">
                        <Filter className="w-4 h-4 text-[#E8924A] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <select
                          value={userUpazilaFilter}
                          onChange={(e) => setUserUpazilaFilter(e.target.value)}
                          className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl pl-9 pr-7 py-2 text-xs focus:outline-none focus:border-[#2D5A27] font-semibold text-[#2D3A3A] cursor-pointer appearance-none"
                        >
                          <option value="">
                            {userDistrictFilter === 'all' ? '📍 সকল উপজেলা' : `📍 ${userDistrictFilter} এর সকল উপজেলা`}
                          </option>
                          {(userDistrictFilter !== 'all' ? getUpazilasForDistrict(userDistrictFilter) : []).map((u) => (
                            <option key={u} value={u}>
                              {u} উপজেলা
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      </div>
                    </div>

                    {/* Role Filter Chips (All 9 Roles) */}
                    <div className="pt-2 border-t border-[#E6E0D4]">
                      <div className="text-[11px] font-bold text-[#736B5E] mb-2 flex items-center justify-between">
                        <span>ইউজার রোল ফিল্টার (৯টি ক্যাটাগরি):</span>
                        {(userRoleFilter !== 'all' || userDistrictFilter !== 'all' || userUpazilaFilter || searchQuery) && (
                          <button
                            onClick={() => {
                              setUserRoleFilter('all');
                              setUserDistrictFilter('all');
                              setUserUpazilaFilter('');
                              setSearchQuery('');
                            }}
                            className="text-[#E8924A] hover:underline font-bold cursor-pointer"
                          >
                            ফিল্টার রিসেট করুন
                          </button>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        <button
                          onClick={() => {
                            setShowOnlyPendingDrivers(false);
                            setUserRoleFilter('all');
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                            !showOnlyPendingDrivers && userRoleFilter === 'all'
                              ? 'bg-[#2D5A27] text-white shadow-2xs'
                              : 'bg-[#FAF8F5] text-[#5A6B6B] border border-[#E6E0D4] hover:bg-[#D4E4BC]/30'
                          }`}
                        >
                          সকল নাগরিক ({registeredUsers.length})
                        </button>

                        {/* Quick Filter: Pending Drivers & Boatmen */}
                        {(() => {
                          const pendingDriversCount = registeredUsers.filter(u => 
                            (u.role === 'driver' || u.role === 'boatman' || u.role === 'agri_machinery_driver') &&
                            (u.accountStatus === 'pending' || u.driverInfo?.status === 'পেন্ডিং' || u.boatmanInfo?.status === 'পেন্ডিং' || u.agriMachineryInfo?.status === 'পেন্ডিং')
                          ).length;
                          return (
                            <button
                              type="button"
                              onClick={() => {
                                setShowOnlyPendingDrivers(!showOnlyPendingDrivers);
                                if (!showOnlyPendingDrivers) {
                                  setUserRoleFilter('all');
                                }
                              }}
                              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                                showOnlyPendingDrivers
                                  ? 'bg-amber-500 text-slate-900 shadow-sm animate-pulse'
                                  : pendingDriversCount > 0
                                  ? 'bg-amber-100 text-amber-900 border-2 border-amber-400 hover:bg-amber-200 animate-pulse'
                                  : 'bg-[#FAF8F5] text-[#5A6B6B] border border-[#E6E0D4] hover:bg-[#D4E4BC]/30'
                              }`}
                            >
                              <span>⏳</span>
                              <span>পেন্ডিং চালক ও মাঝি</span>
                              <span className={`text-[10px] font-extrabold px-1.5 py-0.2 rounded-full ${
                                showOnlyPendingDrivers ? 'bg-slate-900 text-amber-300' : 'bg-amber-600 text-white'
                              }`}>
                                {pendingDriversCount}
                              </span>
                            </button>
                          );
                        })()}

                        {USER_ROLES_LIST.map((rf) => {
                          const count = registeredUsers.filter(u => 
                            u.role === rf.id || (rf.id === 'citizen' && (!u.role || u.role === 'citizen'))
                          ).length;
                          return (
                            <button
                              key={rf.id}
                              onClick={() => {
                                setShowOnlyPendingDrivers(false);
                                setUserRoleFilter(rf.id);
                              }}
                              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                                !showOnlyPendingDrivers && userRoleFilter === rf.id
                                  ? 'bg-[#2D5A27] text-white shadow-2xs'
                                  : 'bg-[#FAF8F5] text-[#5A6B6B] border border-[#E6E0D4] hover:bg-[#D4E4BC]/30'
                              }`}
                            >
                              <span>{rf.icon}</span>
                              <span>{rf.label}</span>
                              <span className="text-[10px] opacity-80">({count})</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {registeredUsers.length === 0 ? (
                    <div className="bg-white rounded-3xl p-8 text-center border border-[#E6E0D4] space-y-2">
                      <UserCheck className="w-12 h-12 text-gray-300 mx-auto" />
                      <p className="text-sm font-bold text-[#2D3A3A]">কোনো নাগরিক এখনও নিবন্ধন করেননি</p>
                      <p className="text-xs text-[#736B5E]">নাগরিকরা যেকোনো ডিভাইস থেকে অ্যাপে একাউন্ট তৈরি করলেই তা সরাসরি এখানে ক্লাউডে দৃশ্যমান হবে।</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {registeredUsers
                        .filter((u) => {
                          // 0. Pending driver filter
                          if (showOnlyPendingDrivers) {
                            const isPending = (u.role === 'driver' || u.role === 'boatman' || u.role === 'agri_machinery_driver') &&
                              (u.accountStatus === 'pending' || u.driverInfo?.status === 'পেন্ডিং' || u.boatmanInfo?.status === 'পেন্ডিং' || u.agriMachineryInfo?.status === 'পেন্ডিং');
                            if (!isPending) return false;
                          }
                          // 1. Role filter
                          if (userRoleFilter !== 'all') {
                            if (userRoleFilter === 'citizen') {
                              if (u.role && u.role !== 'citizen') return false;
                            } else if (u.role !== userRoleFilter) {
                              return false;
                            }
                          }
                          // 2. District filter
                          if (userDistrictFilter !== 'all') {
                            if (!u.district || !u.district.includes(userDistrictFilter)) {
                              return false;
                            }
                          }
                          // 3. Upazila filter
                          if (userUpazilaFilter.trim()) {
                            const upz = userUpazilaFilter.toLowerCase().trim();
                            if (!u.upazila || !u.upazila.toLowerCase().includes(upz)) {
                              return false;
                            }
                          }
                          // 4. Search query
                          if (!searchQuery) return true;
                          const q = searchQuery.toLowerCase().trim();
                          const fullAddr = [u.village, u.union, u.upazila, u.district].filter(Boolean).join(' ').toLowerCase();
                          return (
                            (u.name && u.name.toLowerCase().includes(q)) ||
                            (u.phone && u.phone.includes(q)) ||
                            fullAddr.includes(q)
                          );
                        })
                        .map((user) => {
                          const matchedRole = USER_ROLES_LIST.find(r => r.id === user.role) || {
                            id: 'citizen',
                            label: '১. সাধারণ নাগরিক',
                            icon: '👤'
                          };

                          const officialVerifiedFace = user.verifiedFaceUrl || (!user.customAvatarUrl ? user.avatarUrl : undefined);
                          const optionalAvatar = user.customAvatarUrl;
                          const phoneRegulation = canChangePhoneNumber(user);

                          return (
                            <div
                              key={user.id}
                              className="bg-white rounded-3xl p-4 border border-[#E6E0D4] shadow-2xs space-y-3 relative flex flex-col justify-between"
                            >
                              <div className="flex items-start justify-between gap-3">
                                <div className="flex items-center gap-3">
                                  {/* Permanent Verified Face Photo (Official Record) */}
                                  <div className="relative group" title="অফিসিয়াল লাইভ ভেরিফাইড ফেস (তদন্ত ও নিরাপত্তা রেকর্ড)">
                                    {officialVerifiedFace ? (
                                      <img
                                        src={officialVerifiedFace}
                                        alt={user.name}
                                        className="w-13 h-13 rounded-2xl object-cover border-2 border-[#2D5A27] shadow-xs"
                                      />
                                    ) : (
                                      <div className="w-13 h-13 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] font-bold text-xl flex items-center justify-center border-2 border-[#2D5A27]">
                                        {user.name ? user.name.charAt(0) : 'U'}
                                      </div>
                                    )}
                                    <div className="absolute -bottom-1 -right-1 bg-emerald-600 text-white rounded-full p-0.5" title="লাইভ ভেরিফাইড ফেস">
                                      <CheckCircle className="w-3.5 h-3.5" />
                                    </div>
                                  </div>

                                  {/* Optional Public Avatar if set */}
                                  {optionalAvatar && (
                                    <div className="relative" title="ঐচ্ছিক প্রোফাইল ছবি (অন্য ব্যবহারকারীদের জন্য)">
                                      <img
                                        src={optionalAvatar}
                                        alt="Custom Avatar"
                                        className="w-13 h-13 rounded-2xl object-cover border-2 border-emerald-400 shadow-xs"
                                      />
                                      <span className="absolute -top-1.5 -right-1.5 bg-emerald-700 text-white text-[9px] font-bold px-1 rounded-full">
                                        ঐচ্ছিক
                                      </span>
                                    </div>
                                  )}

                                  <div>
                                    <div className="flex items-center gap-1.5 flex-wrap">
                                      <h5 className="font-bold text-sm text-[#2D3A3A]">{user.name}</h5>
                                      {user.isPhoneVerified && (
                                        <CheckCircle className="w-3.5 h-3.5 text-[#2D5A27]" title="ফোন ভেরিফাইড" />
                                      )}
                                      {user.isLiveVerified && (
                                        <span className="text-[10px] bg-emerald-50 text-emerald-800 border border-emerald-300 font-bold px-1.5 py-0.2 rounded-full inline-flex items-center gap-0.5">
                                          <span>🛡️ লাইভ ভেরিফাইড</span>
                                        </span>
                                      )}
                                      {optionalAvatar && (
                                        <span className="text-[10px] bg-blue-50 text-blue-800 border border-blue-200 font-semibold px-1.5 py-0.2 rounded-full">
                                          🎨 ঐচ্ছিক ছবি যুক্ত
                                        </span>
                                      )}
                                    </div>
                                    <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                                      <span className="text-[11px] font-bold text-[#2D5A27] bg-[#D4E4BC]/60 px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                                        <span>{matchedRole.icon}</span>
                                        <span>{matchedRole.label}</span>
                                      </span>
                                    </div>
                                  </div>
                                </div>

                                <button
                                  onClick={async () => {
                                    if (confirm(`আপনি কি "${user.name}" এর প্রোফাইল ক্লাউড থেকে মুছে ফেলতে চান?`)) {
                                      await deleteCloudUser(user.id);
                                      triggerSuccessToast('নাগরিক প্রোফাইল ক্লাউড থেকে মুছে ফেলা হয়েছে');
                                    }
                                  }}
                                  className="p-1.5 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer"
                                  title="প্রোফাইল মুছুন"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>

                              {/* Address & Privacy Controls Status */}
                              <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] text-xs space-y-1.5">
                                <div className="flex items-center justify-between text-[#2D3A3A]">
                                  <span>📞 ফোন: <strong>{user.phone}</strong></span>
                                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                    phoneRegulation.canChange
                                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                      : 'bg-amber-100 text-amber-800 border border-amber-300'
                                  }`}>
                                    {phoneRegulation.canChange ? '🟢 পরিবর্তনযোগ্য' : `🔒 ২৬ দিন লক (${phoneRegulation.remainingDays} দিন)`}
                                  </span>
                                </div>

                                {/* Phone change audit trail */}
                                {user.phoneChangeHistory && user.phoneChangeHistory.length > 0 && (
                                  <div className="p-2 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-950 space-y-0.5">
                                    <div className="font-bold flex items-center gap-1 text-amber-900">
                                      <span>🔄 নম্বর পরিবর্তনের রেকর্ড ({user.phoneChangeHistory.length} বার):</span>
                                    </div>
                                    {user.phoneChangeHistory.map((rec, i) => (
                                      <div key={i} className="flex items-center justify-between text-[10px] text-amber-800">
                                        <span>পূর্বের নম্বর: <strong>{rec.oldPhone}</strong> → {rec.newPhone}</span>
                                        <span>{rec.changedAt}</span>
                                      </div>
                                    ))}
                                  </div>
                                )}

                                <div className="text-[#5A6B6B]">
                                  <div className="flex items-center justify-between">
                                    <span>📍 ঠিকানা:</span>
                                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                                      user.hideVillage !== false
                                        ? 'bg-blue-50 text-blue-800 border border-blue-200'
                                        : 'bg-gray-100 text-gray-700'
                                    }`}>
                                      {user.hideVillage !== false ? '🔒 গ্রাম গোপন' : '👁️ গ্রাম দৃশ্যমান'}
                                    </span>
                                  </div>
                                  <p className="font-medium text-[#2D3A3A] mt-0.5">
                                    {[
                                      user.village ? `গ্রাম: ${user.village}` : '',
                                      user.union,
                                      user.upazila ? `উপজেলা: ${user.upazila}` : '',
                                      user.district ? `${user.district} জেলা` : ''
                                    ].filter(Boolean).join(', ') || 'ঠিকানা নির্ধারিত হয়নি'}
                                  </p>
                                </div>

                                <div className="flex items-center justify-between pt-1 border-t border-[#E6E0D4] text-[11px]">
                                  <span className="text-[#736B5E]">অফলাইন ডাইরেক্ট কল:</span>
                                  <span className={`font-bold ${user.allowOfflineCall ? 'text-emerald-700' : 'text-gray-600'}`}>
                                    {user.allowOfflineCall ? '🟢 উন্মুক্ত' : '🔒 বন্ধ (ইন-অ্যাপ নিরাপদ কল)'}
                                  </span>
                                </div>

                                {user.driverInfo && (
                                  <div className="p-2 bg-white rounded-xl border border-[#D4C3A3] text-[#2D5A27]">
                                    🚙 <strong>গাড়ি:</strong> {user.driverInfo.vehicleType} ({user.driverInfo.vehicleNumber}) • <strong>রুট:</strong> {user.driverInfo.regularRoutes || 'সারাদেশ'}
                                  </div>
                                )}

                                {user.tutorInfo && (
                                  <div className="p-2 bg-indigo-50 rounded-xl border border-indigo-200 text-indigo-900 text-[11px] space-y-1">
                                    <div className="font-bold flex items-center justify-between">
                                      <span>{user.tutorInfo.tutorType === 'teacher' ? '👨‍🏫 গৃহশিক্ষক (পড়াতে চাই)' : '🧑‍🎓 শিক্ষার্থী/অভিভাবক (শিক্ষক চাই)'}</span>
                                      <span className="text-[10px] bg-white px-1.5 py-0.2 rounded border border-indigo-200">{user.tutorInfo.teachingDaysPerWeek}</span>
                                    </div>
                                    <p>📚 <strong>শ্রেণি ও বিষয়:</strong> {user.tutorInfo.targetClasses} • {user.tutorInfo.preferredSubjects}</p>
                                    {user.tutorInfo.qualification && <p>🎓 <strong>যোগ্যতা/প্রতিষ্ঠান:</strong> {user.tutorInfo.qualification}</p>}
                                    {user.tutorInfo.remuneration && <p>💰 <strong>সম্মানী/বাজেট:</strong> {user.tutorInfo.remuneration}</p>}
                                  </div>
                                )}

                                {user.agriMachineryInfo && (
                                  <div className="p-2 bg-amber-50 rounded-xl border border-amber-200 text-amber-950 text-[11px] space-y-1">
                                    <div className="font-bold flex items-center justify-between">
                                      <span>🚜 ট্র্যাক্টর / হেস্কোভেটর চালক</span>
                                      <span className="text-[10px] bg-amber-100 px-1.5 py-0.2 rounded border border-amber-300 font-bold">{user.agriMachineryInfo.machineryType}</span>
                                    </div>
                                    <p>⚙️ <strong>মডেল/যন্ত্র:</strong> {user.agriMachineryInfo.machineModelOrNumber}</p>
                                    <p>💰 <strong>ভাড়া/রেট:</strong> {user.agriMachineryInfo.hourlyOrDailyRate || 'আলোচনা সাপেক্ষে'} • <strong>সুবিধা:</strong> {user.agriMachineryInfo.availableAttachments}</p>
                                  </div>
                                )}

                                {user.boatmanInfo && (
                                  <div className="p-2 bg-cyan-50 rounded-xl border border-cyan-200 text-cyan-950 text-[11px] space-y-1">
                                    <div className="font-bold flex items-center justify-between">
                                      <span>⛵ নৌকার মাঝি ও খেয়া চালক</span>
                                      <span className="text-[10px] bg-cyan-100 px-1.5 py-0.2 rounded border border-cyan-300 font-bold">{user.boatmanInfo.boatType}</span>
                                    </div>
                                    <p>🌊 <strong>ঘাট/রুট:</strong> {user.boatmanInfo.ghatNameOrRoute}</p>
                                    <p>⏰ <strong>শিফট:</strong> {user.boatmanInfo.serviceShift} • <strong>ভাড়া:</strong> {user.boatmanInfo.fareRate}</p>
                                  </div>
                                )}

                                {/* ⏳ চালক ও মাঝি এনআইডি ও লাইভ ফেস ভেরিফিকেশন ও অনুমোদন বক্স */}
                                {(() => {
                                  const isPendingDriverOrBoatman = (user.role === 'driver' || user.role === 'boatman' || user.role === 'agri_machinery_driver') &&
                                    (user.accountStatus === 'pending' || user.driverInfo?.status === 'পেন্ডিং' || user.boatmanInfo?.status === 'পেন্ডিং' || user.agriMachineryInfo?.status === 'পেন্ডিং');

                                  if (isPendingDriverOrBoatman) {
                                    return (
                                      <div className="p-3 bg-amber-50 rounded-2xl border-2 border-amber-400 text-xs space-y-2.5 shadow-xs">
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-1.5 font-bold text-amber-950 text-xs">
                                            <span className="text-base animate-spin">⏳</span>
                                            <span>নিবন্ধন অনুমোদনের অপেক্ষায় (পেন্ডিং)</span>
                                          </div>
                                          <span className="text-[10px] bg-amber-200 text-amber-950 font-black px-2 py-0.5 rounded-full border border-amber-300">
                                            এডমিন যাচাইকরণ
                                          </span>
                                        </div>

                                        <p className="text-[11px] text-amber-900 leading-tight">
                                          লাইভ ক্যামেরা সেলফি ও এনআইডির ছবি মিলিয়ে দেখুন। সব তথ্য সঠিক হলে অনুমোদন দিন, সাথে সাথে চালকের ইনবক্সে স্বয়ংক্রিয় শুভেচ্ছা বার্তা পৌঁছে যাবে।
                                        </p>

                                        {/* ৩টি ছবির পাশাপাশি ভিউ: ১. লাইভ ফেস ২. এনআইডি এপিঠ ৩. এনআইডি ওপিঠ */}
                                        <div className="bg-white p-2.5 rounded-xl border border-amber-200 space-y-1.5">
                                          <div className="text-[11px] font-bold text-slate-800 flex items-center justify-between">
                                            <span>🔍 ছবি মিলিয়ে দেখুন (ফেস বনাম এনআইডি):</span>
                                            <span className="text-[10px] text-emerald-700 font-semibold">ক্লিক করে বড় দেখুন</span>
                                          </div>
                                          <div className="grid grid-cols-3 gap-2">
                                            <div className="text-center space-y-1">
                                              <span className="text-[10px] font-bold text-slate-700 block">১. লাইভ ক্যামেরা</span>
                                              {user.avatarUrl ? (
                                                <img
                                                  src={user.avatarUrl}
                                                  alt="Live Face"
                                                  onClick={() => {
                                                    setInspectingDocUrl(user.avatarUrl || null);
                                                    setInspectingDocTitle(`${user.name} - লাইভ ক্যামেরা সেলফি`);
                                                  }}
                                                  className="w-full h-16 sm:h-20 object-cover rounded-lg border-2 border-emerald-400 cursor-pointer hover:opacity-90 shadow-2xs hover:scale-102 transition"
                                                  title="বড় করে দেখতে ক্লিক করুন"
                                                />
                                              ) : (
                                                <div className="h-16 sm:h-20 flex items-center justify-center bg-gray-100 rounded-lg text-[10px] text-gray-500 border border-gray-200">
                                                  ছবি নেই
                                                </div>
                                              )}
                                            </div>

                                            <div className="text-center space-y-1">
                                              <span className="text-[10px] font-bold text-slate-700 block">২. NID এপিঠ</span>
                                              {user.driverNidFrontUrl ? (
                                                <img
                                                  src={user.driverNidFrontUrl}
                                                  alt="NID Front"
                                                  onClick={() => {
                                                    setInspectingDocUrl(user.driverNidFrontUrl || null);
                                                    setInspectingDocTitle(`${user.name} - এনআইডি (এপিঠ)`);
                                                  }}
                                                  className="w-full h-16 sm:h-20 object-cover rounded-lg border-2 border-blue-400 cursor-pointer hover:opacity-90 shadow-2xs hover:scale-102 transition"
                                                  title="বড় করে দেখতে ক্লিক করুন"
                                                />
                                              ) : (
                                                <div className="h-16 sm:h-20 flex items-center justify-center bg-gray-100 rounded-lg text-[10px] text-gray-500 border border-gray-200">
                                                  এপিঠ নেই
                                                </div>
                                              )}
                                            </div>

                                            <div className="text-center space-y-1">
                                              <span className="text-[10px] font-bold text-slate-700 block">৩. NID ওপিঠ</span>
                                              {user.driverNidBackUrl ? (
                                                <img
                                                  src={user.driverNidBackUrl}
                                                  alt="NID Back"
                                                  onClick={() => {
                                                    setInspectingDocUrl(user.driverNidBackUrl || null);
                                                    setInspectingDocTitle(`${user.name} - এনআইডি (ওপিঠ)`);
                                                  }}
                                                  className="w-full h-16 sm:h-20 object-cover rounded-lg border-2 border-blue-400 cursor-pointer hover:opacity-90 shadow-2xs hover:scale-102 transition"
                                                  title="বড় করে দেখতে ক্লিক করুন"
                                                />
                                              ) : (
                                                <div className="h-16 sm:h-20 flex items-center justify-center bg-gray-100 rounded-lg text-[10px] text-gray-500 border border-gray-200">
                                                  ওপিঠ নেই
                                                </div>
                                              )}
                                            </div>
                                          </div>
                                        </div>

                                        {/* একশন বাটনসমূহ: অনুমোদন ও বাতিল */}
                                        <div className="flex items-center gap-2 pt-1">
                                          <button
                                            type="button"
                                            onClick={() => {
                                              if (confirm(`আপনি কি "${user.name}" এর চালক/মাঝি অ্যাকাউন্ট অনুমোদন করতে চান?

অনুমোদনের সাথে সাথে অ্যাকাউন্ট সচল হবে এবং ইনবক্সে অভিনন্দন ও শুভেচ্ছা বার্তা পাঠানো হবে।`)) {
                                                handleApproveDriverOrBoatman(user);
                                              }
                                            }}
                                            className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
                                          >
                                            <Check className="w-4 h-4" />
                                            <span>অনুমোদন দিন ও সচল করুন</span>
                                          </button>

                                          <button
                                            type="button"
                                            onClick={() => {
                                              setRejectingDriverUser(user);
                                              setRejectionReasonInput('');
                                            }}
                                            className="py-2 px-3 bg-red-100 hover:bg-red-200 text-red-800 font-bold rounded-xl text-xs flex items-center justify-center gap-1 border border-red-300 transition cursor-pointer"
                                          >
                                            <X className="w-3.5 h-3.5" />
                                            <span>বাতিল / সংশোধন</span>
                                          </button>
                                        </div>
                                      </div>
                                    );
                                  }

                                  if (user.approvedAt) {
                                    return (
                                      <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-300 text-[11px] text-emerald-950 flex items-center justify-between">
                                        <div className="flex items-center gap-1.5">
                                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                                          <span className="font-bold">✓ এডমিন অনুমোদিত ও সক্রিয় চালক</span>
                                        </div>
                                        <span className="text-[10px] text-emerald-700 font-medium">
                                          অনুমোদনকারী: {user.approvedBy || 'কর্তৃপক্ষ'}
                                        </span>
                                      </div>
                                    );
                                  }

                                  if (user.driverNidFrontUrl || user.driverNidBackUrl) {
                                    return (
                                      <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-300 text-xs space-y-2">
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-1.5 font-bold text-emerald-950 text-[11px]">
                                            <ShieldCheck className="w-4 h-4 text-emerald-700" />
                                            <span>🪪 {user.driverLicenseType === 'driving_license' ? 'ড্রাইভিং লাইসেন্স' : 'জাতীয় পরিচয়পত্র (NID)'} স্ক্যান কপি:</span>
                                          </div>
                                          <span className="text-[10px] bg-emerald-200 text-emerald-900 font-extrabold px-1.5 py-0.2 rounded">
                                            এডমিন যাচাইকরণ
                                          </span>
                                        </div>

                                        <div className="grid grid-cols-2 gap-2">
                                          {user.driverNidFrontUrl && (
                                            <div className="space-y-1">
                                              <span className="text-[10px] text-slate-600 block font-semibold">১. এপিঠ (Front):</span>
                                              <img
                                                src={user.driverNidFrontUrl}
                                                alt="NID Front Scan"
                                                onClick={() => {
                                                  setInspectingDocUrl(user.driverNidFrontUrl || null);
                                                  setInspectingDocTitle(`${user.name} - ${user.driverLicenseType === 'driving_license' ? 'ড্রাইভিং লাইসেন্স' : 'এনআইডি'} (এপিঠ)`);
                                                }}
                                                className="w-full h-16 sm:h-20 object-cover rounded-lg border border-emerald-300 cursor-pointer hover:opacity-90 shadow-2xs hover:scale-102 transition"
                                                title="বড় করে দেখতে ক্লিক করুন"
                                              />
                                            </div>
                                          )}
                                          {user.driverNidBackUrl && (
                                            <div className="space-y-1">
                                              <span className="text-[10px] text-slate-600 block font-semibold">২. ওপিঠ (Back):</span>
                                              <img
                                                src={user.driverNidBackUrl}
                                                alt="NID Back Scan"
                                                onClick={() => {
                                                  setInspectingDocUrl(user.driverNidBackUrl || null);
                                                  setInspectingDocTitle(`${user.name} - ${user.driverLicenseType === 'driving_license' ? 'ড্রাইভিং লাইসেন্স' : 'এনআইডি'} (ওপিঠ)`);
                                                }}
                                                className="w-full h-16 sm:h-20 object-cover rounded-lg border border-emerald-300 cursor-pointer hover:opacity-90 shadow-2xs hover:scale-102 transition"
                                                title="বড় করে দেখতে ক্লিক করুন"
                                              />
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    );
                                  }

                                  return null;
                                })()}

                                <p className="text-[10px] text-[#736B5E] pt-0.5">
                                  🕒 নিবন্ধনের তারিখ: {user.createdAt ? (isNaN(Date.parse(user.createdAt)) ? user.createdAt : new Date(user.createdAt).toLocaleDateString('bn-BD')) : 'এইমাত্র'}
                                </p>
                              </div>

                              <div className="flex items-center gap-2 pt-1">
                                <a
                                  href={`tel:${user.phone}`}
                                  className="flex-1 text-center py-2 bg-[#FAF8F5] border border-[#D4C3A3] text-[#2D5A27] text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 hover:bg-[#D4E4BC]/30 transition"
                                >
                                  <PhoneCall className="w-3.5 h-3.5" />
                                  <span>কল করুন</span>
                                </a>

                                {isSuperAdmin && (
                                  adminUsers.some(a => a.phoneOrEmail === user.phone || (user.email && a.phoneOrEmail === user.email)) ? (
                                    <span className="px-3 py-2 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-[11px] font-bold flex items-center gap-1">
                                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                                      <span>সহকারী এডমিন</span>
                                    </span>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setNewSubName(user.name || '');
                                        setNewSubContact(user.phone || user.email || '');
                                        setNewSubPin('1234');
                                        setCandidateUserForAdmin(user);
                                        setShowAddSubAdminModal(true);
                                      }}
                                      className="flex-1 text-center py-2 bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1 transition shadow-xs cursor-pointer"
                                      title="এই নিবন্ধিত নাগরিককে সহকারী এডমিন হিসেবে নিয়োগ দিন"
                                    >
                                      <ShieldCheck className="w-3.5 h-3.5" />
                                      <span>+ সহকারী এডমিন</span>
                                    </button>
                                  )
                                )}
                              </div>

                              <button
                                type="button"
                                onClick={() => setSelectedUserForLog(user)}
                                className="w-full mt-2 py-2 bg-[#1B365D] hover:bg-[#132742] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition shadow-2xs cursor-pointer"
                                title="এই নাগরিকের ১ বছর মেয়াদী ডিজিটাল নিরাপত্তা লগবই ও ভ্রমণ হিস্ট্রি দেখুন"
                              >
                                <ShieldCheck className="w-3.5 h-3.5 text-[#D4E4BC]" />
                                <span>নিরাপত্তা লগবই ও ভ্রমণ হিস্ট্রি (১ বছর রেকর্ড)</span>
                              </button>

                              {/* আংশিক নিষেধাজ্ঞা (Partial Ban) স্ট্যাটাস ও কন্ট্রোল বাটন */}
                              <div className="mt-2 pt-2 border-t border-[#E6E0D4] flex items-center justify-between gap-2 bg-[#FAF8F5] p-2 rounded-xl">
                                <div className="flex items-center gap-1.5 text-[11px]">
                                  <span className="text-[#736B5E] font-medium">আবাসন/পাত্র-পাত্রী:</span>
                                  {user.isRestrictedFromHousingAndMatrimony ? (
                                    <span className="font-bold text-red-700 bg-red-100 border border-red-300 px-2 py-0.5 rounded-full inline-flex items-center gap-0.5 text-[10px]">
                                      <span>🚫 আংশিক ব্যান</span>
                                    </span>
                                  ) : (
                                    <span className="font-bold text-emerald-700 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-full inline-flex items-center gap-0.5 text-[10px]">
                                      <span>🟢 উন্মুক্ত</span>
                                    </span>
                                  )}
                                </div>

                                {(isSuperAdmin || hasPerm('canModerateHousingMatrimony')) && (
                                  <button
                                    type="button"
                                    onClick={async () => {
                                      const newRestrictedState = !user.isRestrictedFromHousingAndMatrimony;
                                      const confirmMsg = newRestrictedState
                                        ? `আপনি কি "${user.name}" কে আবাসন ও পাত্র-পাত্রী সেবায় আংশিক ব্যান করতে চান? (অন্যান্য সাধারণ সেবা নিয়মিত ব্যবহার করতে পারবেন)`
                                        : `আপনি কি "${user.name}" এর আবাসন ও পাত্র-পাত্রীর আংশিক নিষেধাজ্ঞা প্রত্যাহার করতে চান?`;
                                      
                                      if (confirm(confirmMsg)) {
                                        await setUserHousingMatrimonyRestriction(user.id, newRestrictedState);
                                        setRegisteredUsers(prev => prev.map(u => u.id === user.id ? { ...u, isRestrictedFromHousingAndMatrimony: newRestrictedState } : u));
                                        triggerSuccessToast(newRestrictedState 
                                          ? `✓ "${user.name}" কে শুধুমাত্র আবাসন ও পাত্র-পাত্রী থেকে আংশিক ব্যান করা হয়েছে` 
                                          : `✓ "${user.name}" এর আংশিক নিষেধাজ্ঞা প্রত্যাহার করা হয়েছে`);
                                      }
                                    }}
                                    className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border transition cursor-pointer flex items-center gap-1 shrink-0 ${
                                      user.isRestrictedFromHousingAndMatrimony
                                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600'
                                        : 'bg-red-100 hover:bg-red-200 text-red-800 border-red-300'
                                    }`}
                                    title="শুধুমাত্র আবাসন ও পাত্র-পাত্রীতে পোস্ট করা ব্যান বা আনব্যান করুন"
                                  >
                                    <span>{user.isRestrictedFromHousingAndMatrimony ? '✅ আনব্যান' : '🚫 আংশিক ব্যান'}</span>
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 12: HOUSING & MATRIMONY MODERATION, REVIEWS & REPORTS */}
              {activeTab === 'housing_matrimony' && (isSuperAdmin || hasPerm('canModerateHousingMatrimony') || hasPerm('canModerateListings')) && (
                <div className="space-y-4">
                  {/* Header & Sub-tab Bar */}
                  <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E6E0D4] shadow-xs space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <h4 className="font-bold text-base text-[#2D3A3A] flex items-center gap-2">
                          <Home className="w-5 h-5 text-[#0369A1]" />
                          <span>আবাসন ও পাত্র-পাত্রী পর্যালোচনা, অভিযোগ ও আংশিক ব্যান ব্যবস্থাপনা</span>
                        </h4>
                        <p className="text-xs text-[#736B5E]">
                          নাগরিকদের জমা দেওয়া অভিযোগ যাচাই করে আংশিক ব্যান (Partial Ban) আরোপ করুন এবং কীওয়ার্ড ফিল্টারে আটকে থাকা পোস্ট রিভিউ করুন।
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold px-3 py-1 bg-amber-100 text-amber-900 rounded-full border border-amber-300">
                          অভিযোগ: {housingMatrimonyReports.length} টি
                        </span>
                        <span className="text-xs font-bold px-3 py-1 bg-blue-100 text-blue-900 rounded-full border border-blue-300">
                          পেন্ডিং রিভিউ: {housingListings.filter(l => l.status === 'pending_review').length} টি
                        </span>
                      </div>
                    </div>

                    {/* Sub-tabs */}
                    <div className="flex items-center gap-2 border-t border-[#E6E0D4] pt-3 overflow-x-auto no-scrollbar">
                      <button
                        type="button"
                        onClick={() => setHousingModSubTab('reports')}
                        className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                          housingModSubTab === 'reports'
                            ? 'bg-[#C0392B] text-white shadow-xs'
                            : 'bg-[#FAF8F5] text-[#2D3A3A] border border-[#E6E0D4] hover:bg-[#FADBD8]/40'
                        }`}
                      >
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>১. নাগরিক অভিযোগসমূহ ({housingMatrimonyReports.length})</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setHousingModSubTab('pending')}
                        className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                          housingModSubTab === 'pending'
                            ? 'bg-[#0369A1] text-white shadow-xs'
                            : 'bg-[#FAF8F5] text-[#2D3A3A] border border-[#E6E0D4] hover:bg-[#E0F2FE]/40'
                        }`}
                      >
                        <Clock className="w-3.5 h-3.5" />
                        <span>২. পেন্ডিং রিভিউ আবাসন ({housingListings.filter(l => l.status === 'pending_review').length})</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setHousingModSubTab('all_listings')}
                        className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                          housingModSubTab === 'all_listings'
                            ? 'bg-[#2D5A27] text-white shadow-xs'
                            : 'bg-[#FAF8F5] text-[#2D3A3A] border border-[#E6E0D4] hover:bg-[#D4E4BC]/40'
                        }`}
                      >
                        <Home className="w-3.5 h-3.5" />
                        <span>৩. সকল লাইভ আবাসন বিজ্ঞাপন ({housingListings.length})</span>
                      </button>
                    </div>
                  </div>

                  {/* SUB-SECTION 1: CITIZEN REPORTS & PARTIAL BAN */}
                  {housingModSubTab === 'reports' && (
                    <div className="space-y-3">
                      {housingMatrimonyReports.length === 0 ? (
                        <div className="bg-white p-8 rounded-2xl border border-[#E6E0D4] text-center space-y-2">
                          <CheckCircle className="w-10 h-10 text-emerald-600 mx-auto" />
                          <h5 className="font-bold text-sm text-[#2D3A3A]">কোনো অভিযোগ অমীমাংসিত নেই</h5>
                          <p className="text-xs text-[#736B5E]">
                            আবাসন বা পাত্র-পাত্রীর কোনো পোস্টদাতার বিরুদ্ধে বর্তমানে কোনো নাগরিক অভিযোগ দায়ের করেননি।
                          </p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                          {housingMatrimonyReports.map((report) => (
                            <div
                              key={report.id}
                              className="bg-white rounded-2xl p-4 border border-[#E6E0D4] shadow-xs space-y-3 flex flex-col justify-between"
                            >
                              <div className="space-y-2">
                                <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-2">
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-300">
                                      {report.moduleCategory === 'housing' ? '🏠 আবাসন পোস্ট' : '💍 পাত্র-পাত্রী পোস্ট'}
                                    </span>
                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                      report.status === 'নতুন'
                                        ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                        : report.status === 'নিষ্পন্ন'
                                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                        : 'bg-blue-100 text-blue-800 border border-blue-300'
                                    }`}>
                                      {report.status}
                                    </span>
                                  </div>
                                  <span className="text-[10px] text-[#736B5E]">{report.createdAtFormatted || 'সাম্প্রতিক'}</span>
                                </div>

                                <div>
                                  <h5 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">
                                    বিজ্ঞাপন: {report.listingTitle}
                                  </h5>
                                  <p className="text-[11px] text-[#736B5E] mt-0.5">
                                    অভিযোগের কারণ: <strong className="text-rose-700">{report.reason}</strong>
                                  </p>
                                </div>

                                <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E6E0D4] text-xs space-y-1">
                                  <p className="font-semibold text-[#2D3A3A]">প্রমাণ ও বিবরণ:</p>
                                  <p className="text-[11px] text-[#5A6B6B] leading-relaxed italic bg-white p-2 rounded-lg border border-[#E6E0D4]">
                                    "{report.proofDetails}"
                                  </p>
                                  <div className="flex items-center justify-between text-[11px] text-[#736B5E] pt-1">
                                    <span>অভিযুক্ত: <strong>{report.accusedUserName}</strong> ({report.accusedUserPhone})</span>
                                    <span>অভিযোগকারী: <strong>{report.reporterName}</strong> ({report.reporterPhone})</span>
                                  </div>
                                </div>

                                {report.adminActionTaken && (
                                  <div className="p-2 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-900">
                                    ✓ গৃহীত ব্যবস্থা: <strong>{report.adminActionTaken === 'banned' ? 'আংশিক ব্যান আরোপিত' : report.adminActionTaken === 'deleted_post' ? 'পোস্ট মোছা হয়েছে' : 'খারিজ করা হয়েছে'}</strong>
                                    {report.adminNotes && <span className="block text-[10px] text-emerald-700 mt-0.5">{report.adminNotes}</span>}
                                  </div>
                                )}
                              </div>

                              {/* Action Buttons */}
                              <div className="pt-2 border-t border-[#E6E0D4] flex flex-wrap items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={async () => {
                                    if (confirm(`আপনি কি "${report.accusedUserName}" কে আবাসন ও পাত্র-পাত্রী সেবায় আংশিক ব্যান (Partial Ban) করতে চান?`)) {
                                      await setUserHousingMatrimonyRestriction(report.accusedUserId, true);
                                      await updateCloudHousingMatrimonyReportStatus(report.id, 'নিষ্পন্ন', 'banned', 'এডমিন তদন্ত শেষে আংশিক ব্যান কার্যকর করেছেন');
                                      setRegisteredUsers(prev => prev.map(u => u.id === report.accusedUserId ? { ...u, isRestrictedFromHousingAndMatrimony: true } : u));
                                      triggerSuccessToast(`✓ "${report.accusedUserName}" কে আংশিক ব্যান করা হয়েছে`);
                                    }
                                  }}
                                  className="flex-1 py-1.5 px-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-[11px] font-bold transition flex items-center justify-center gap-1 shadow-2xs cursor-pointer"
                                  title="শুধুমাত্র আবাসন ও পাত্র-পাত্রী ফিচার থেকে ইউজারকে ব্যান করুন"
                                >
                                  <span>🚫 আংশিক ব্যান করুন</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={async () => {
                                    if (confirm('আপনি কি এই বিজ্ঞাপনটি মুছে ফেলতে চান?')) {
                                      if (report.moduleCategory === 'housing') {
                                        await deleteCloudHousingListing(report.listingId);
                                      } else {
                                        await deleteCloudMatrimonyListing(report.listingId);
                                      }
                                      await updateCloudHousingMatrimonyReportStatus(report.id, 'নিষ্পন্ন', 'deleted_post', 'পোস্টটি মুছে দেওয়া হয়েছে');
                                      triggerSuccessToast('✓ বিজ্ঞাপনটি মুছে দেওয়া হয়েছে');
                                    }
                                  }}
                                  className="py-1.5 px-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-[11px] font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>পোস্ট মুছুন</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={async () => {
                                    await updateCloudHousingMatrimonyReportStatus(report.id, 'নিষ্পন্ন', 'dismissed', 'প্রমাণ পর্যাপ্ত না থাকায় অভিযোগ খারিজ');
                                    triggerSuccessToast('অভিযোগটি খারিজ করা হয়েছে');
                                  }}
                                  className="py-1.5 px-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-xl text-[11px] font-bold transition cursor-pointer"
                                >
                                  ✕ খারিজ
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* SUB-SECTION 2: PENDING REVIEW HOUSING POSTS (KEYWORD FILTER) */}
                  {housingModSubTab === 'pending' && (
                    <div className="space-y-3">
                      {housingListings.filter(l => l.status === 'pending_review').length === 0 ? (
                        <div className="bg-white p-8 rounded-2xl border border-[#E6E0D4] text-center space-y-2">
                          <CheckCircle className="w-10 h-10 text-emerald-600 mx-auto" />
                          <h5 className="font-bold text-sm text-[#2D3A3A]">কোনো পেন্ডিং রিভিউ পোস্ট নেই</h5>
                          <p className="text-xs text-[#736B5E]">
                            হোটেল, দৈনিক ভাড়া বা রুম বুকিং জাতীয় নিষিদ্ধ কীওয়ার্ড সম্বলিত কোনো অপেক্ষমাণ পোস্ট পাওয়া যায়নি।
                          </p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                          {housingListings.filter(l => l.status === 'pending_review').map((post) => (
                            <div
                              key={post.id}
                              className="bg-white rounded-2xl p-4 border-2 border-amber-300 shadow-xs space-y-3 flex flex-col justify-between"
                            >
                              <div className="space-y-2">
                                <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-2">
                                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                                    ⏳ Pending for Review
                                  </span>
                                  <span className="text-[10px] text-[#736B5E]">{post.createdAtFormatted}</span>
                                </div>

                                <div className="p-2 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 text-xs font-medium">
                                  ⚠️ <strong>কারণ:</strong> {post.reviewReason || 'হোটেল/দৈনিক ভাড়া/রুম বুকিং জাতীয় কীওয়ার্ড সনাক্ত হয়েছে'}
                                </div>

                                <div>
                                  <h5 className="font-bold text-sm text-[#2D3A3A]">{post.title}</h5>
                                  <p className="text-xs text-[#5A6B6B] mt-1 leading-relaxed line-clamp-3">
                                    {post.description}
                                  </p>
                                </div>

                                <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E6E0D4] text-xs space-y-1">
                                  <p>📍 <strong>এলাকা:</strong> {post.areaAddress}, {post.upazila}, {post.district}</p>
                                  <p>💰 <strong>ভাড়া:</strong> {post.rentType === 'fixed' ? `${post.rentAmount} টাকা` : 'আলোচনা সাপেক্ষে'}</p>
                                  <p>👤 <strong>মালিক:</strong> {post.ownerName} ({post.ownerPhone})</p>
                                </div>
                              </div>

                              <div className="pt-2 border-t border-[#E6E0D4] flex items-center gap-2">
                                <button
                                  type="button"
                                  onClick={async () => {
                                    if (confirm(`আপনি কি "${post.title}" বিজ্ঞাপনটি অনুমোদন ও লাইভ করতে চান?`)) {
                                      const updated: HousingListing = {
                                        ...post,
                                        status: 'active',
                                        reviewReason: undefined
                                      };
                                      await saveCloudHousingListing(updated);
                                      triggerSuccessToast('✓ বিজ্ঞাপনটি সফলভাবে অনুমোদিত ও লাইভ করা হয়েছে');
                                    }
                                  }}
                                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 shadow-xs cursor-pointer"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                  <span>অনুমোদন দিন (Approve)</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={async () => {
                                    if (confirm(`আপনি কি "${post.title}" বিজ্ঞাপনটি স্থায়ীভাবে মুছে ফেলতে চান?`)) {
                                      await deleteCloudHousingListing(post.id);
                                      triggerSuccessToast('পোস্টটি মুছে ফেলা হয়েছে');
                                    }
                                  }}
                                  className="py-2 px-3 bg-red-100 hover:bg-red-200 text-red-800 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>মুছে ফেলুন</span>
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* SUB-SECTION 3: ALL LIVE HOUSING LISTINGS */}
                  {housingModSubTab === 'all_listings' && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {housingListings.map((listing) => (
                          <div
                            key={listing.id}
                            className="bg-white rounded-2xl p-3.5 border border-[#E6E0D4] shadow-2xs space-y-2 flex flex-col justify-between"
                          >
                            <div className="space-y-1.5">
                              <div className="flex items-center justify-between text-[10px]">
                                <span className={`font-bold px-2 py-0.5 rounded-full ${
                                  listing.status === 'active'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}>
                                  {listing.status === 'active' ? '🟢 লাইভ' : '⏳ পেন্ডিং'}
                                </span>
                                <span className="text-[#736B5E]">{listing.category}</span>
                              </div>

                              <h5 className="font-bold text-xs text-[#2D3A3A] line-clamp-1">{listing.title}</h5>
                              <p className="text-[11px] text-[#5A6B6B] line-clamp-2">{listing.description}</p>
                              
                              <div className="text-[10px] text-[#736B5E]">
                                📍 {listing.areaAddress}, {listing.upazila} • 💰 {listing.rentType === 'fixed' ? `${listing.rentAmount} ৳` : 'আলোচনা'}
                              </div>
                            </div>

                            <div className="pt-2 border-t border-[#E6E0D4] flex items-center justify-between">
                              <span className="text-[10px] text-[#736B5E]">{listing.ownerName}</span>
                              <button
                                type="button"
                                onClick={async () => {
                                  if (confirm(`আপনি কি "${listing.title}" বিজ্ঞাপনটি মুছে ফেলতে চান?`)) {
                                    await deleteCloudHousingListing(listing.id);
                                    triggerSuccessToast('বিজ্ঞাপনটি সফলভাবে মুছে ফেলা হয়েছে');
                                  }
                                }}
                                className="p-1 text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                                title="মুছে ফেলুন"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'security' && (
                <div className="space-y-4 max-w-2xl mx-auto">
                  <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-xs space-y-4">
                    <div className="flex items-center gap-3 border-b border-[#E6E0D4] pb-3">
                      <div className="w-10 h-10 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center">
                        <KeyRound className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-base text-[#2D3A3A]">এডমিন ক্রেডেনশিয়াল ও পাসওয়ার্ড আপডেট</h4>
                        <p className="text-xs text-[#736B5E]">আপনার এডমিন পিন, লগইন ইমেইল এবং নাম নিরাপদভাবে পরিবর্তন করুন</p>
                      </div>
                    </div>

                    {adminSecurityError && (
                      <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs font-semibold flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{adminSecurityError}</span>
                      </div>
                    )}

                    <form onSubmit={handleUpdateAdminProfile} className="space-y-4">
                      <div className="p-3 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] text-xs text-[#2D3A3A] space-y-1">
                        <p><strong>বর্তমান রোল:</strong> {isSuperAdmin ? '👑 সুপার অ্যাডমিন (Super Admin)' : '🛡️ সাব-অ্যাডমিন (Sub-Admin)'}</p>
                        <p><strong>বর্তমান আইডি:</strong> {currentAdmin.id}</p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                        <div>
                          <label className="block text-xs font-bold text-[#2D3A3A] mb-1">অ্যাডমিনের নাম</label>
                          <input
                            type="text"
                            required
                            value={adminNewName}
                            onChange={(e) => setAdminNewName(e.target.value)}
                            className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2 text-xs font-semibold text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-[#2D3A3A] mb-1">লগইন ইমেইল / ফোন নম্বর</label>
                          <input
                            type="text"
                            required
                            value={adminNewEmail}
                            onChange={(e) => setAdminNewEmail(e.target.value)}
                            placeholder="যেমন: polliseba26@gmail.com"
                            className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2 text-xs font-semibold text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                          />
                        </div>
                      </div>

                      <div className="border-t border-[#E6E0D4] pt-3 space-y-3">
                        <h5 className="text-xs font-bold text-[#2D5A27]">লগইন পিন / পাসওয়ার্ড পরিবর্তন (ঐচ্ছিক):</h5>

                        <div>
                          <label className="block text-xs font-bold text-[#2D3A3A] mb-1">বর্তমান পিন (যদি পিন বদলাতে চান)</label>
                          <input
                            type="password"
                            value={adminCurrentPin}
                            onChange={(e) => setAdminCurrentPin(e.target.value)}
                            placeholder="বর্তমান এডমিন পিন (যেমন: 7860)"
                            className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                          <div>
                            <label className="block text-xs font-bold text-[#2D3A3A] mb-1">নতুন অ্যাডমিন পিন</label>
                            <div className="relative">
                              <input
                                type={showAdminPin ? "text" : "password"}
                                value={adminNewPin}
                                onChange={(e) => setAdminNewPin(e.target.value)}
                                placeholder="৪-সংখ্যার নতুন পিন"
                                className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                              />
                              <button
                                type="button"
                                onClick={() => setShowAdminPin(!showAdminPin)}
                                className="absolute right-3 top-2 text-[#736B5E] hover:text-[#2D3A3A] cursor-pointer"
                              >
                                {showAdminPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-[#2D3A3A] mb-1">নতুন পিন পুনরায় নিশ্চিত করুন</label>
                            <input
                              type="password"
                              value={adminConfirmPin}
                              onChange={(e) => setAdminConfirmPin(e.target.value)}
                              placeholder="একই নতুন পিন আবার লিখুন"
                              className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl px-3.5 py-2 text-xs text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="pt-2">
                        <button
                          type="submit"
                          className="w-full bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-3 rounded-xl text-xs shadow-md transition cursor-pointer"
                        >
                          এডমিন ক্রেডেনশিয়াল সংরক্ষণ করুন
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

              {/* TAB 3: HAAT LISTINGS MODERATION */}
              {activeTab === 'listings' && (isSuperAdmin || hasPerm('canModerateListings') || currentAdmin?.role === 'sub_admin' || currentAdmin?.role === 'assistant_admin') && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-[#E6E0D4]">
                    <div>
                      <span className="font-bold text-sm text-[#2D3A3A] block">
                        মোট হাট বিজ্ঞাপন: {listings.length} টি
                      </span>
                      <span className="text-xs text-[#736B5E]">
                        প্রধান এডমিন ও সহকারী এডমিনদের যেকোনো বিজ্ঞাপন মুছে ফেলার পূর্ণ নিয়ন্ত্রণ
                      </span>
                    </div>
                    <button
                      onClick={handleCleanAllExpiredOrTestAds}
                      className="flex items-center gap-1.5 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 px-3 py-1.5 rounded-xl transition cursor-pointer shadow-2xs"
                      title="সকল মেয়াদোত্তীর্ণ ও টেস্ট বিজ্ঞাপন এক ক্লিকে স্থায়ীভাবে মুছে ফেলুন"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                      <span>🧹 মেয়াদোত্তীর্ণ ও টেস্ট বিজ্ঞাপন ক্লিনআপ</span>
                    </button>
                  </div>

                  <div className="space-y-2.5">
                    {listings.map((item) => (
                      <div
                        key={item.id}
                        className="bg-white rounded-2xl p-4 border border-[#E6E0D4] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-[#2D3A3A]">{item.title}</span>
                            <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] font-bold px-2 py-0.5 rounded-full">
                              {item.category}
                            </span>
                          </div>
                          <p className="text-xs text-[#5A6B6B]">
                            বিক্রেতা: <strong>{item.sellerName}</strong> • ফোন: <span className="text-[#2D5A27] font-bold">{item.phone}</span> • এলাকা: {item.district}
                          </p>
                          <p className="text-xs font-semibold text-[#A65E2E]">
                            মূল্য: {formatTaka(item.price)} টাকা / {item.unit} • {item.isSold ? '🔴 বিক্রি শেষ' : '🟢 বিক্রয়ের জন্য উন্মুক্ত'}
                          </p>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center">
                          <button
                            onClick={() => handleDeleteListing(item.id)}
                            className="flex items-center gap-1 text-xs font-bold text-red-600 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-xl transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>মুছুন</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: TRANSPORT & DRIVERS MODERATION */}
              {activeTab === 'drivers' && (isSuperAdmin || hasPerm('canManageDrivers')) && (
                <div className="space-y-4">
                  {pendingDriversCount > 0 && (
                    <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
                          ⏳
                        </div>
                        <div>
                          <h5 className="font-extrabold text-xs sm:text-sm text-slate-900">
                            {pendingDriversCount} জন চালক ও মাঝির নিবন্ধন আবেদন অপেক্ষমাণ (পেন্ডিং) রয়েছে!
                          </h5>
                          <p className="text-[11px] text-slate-700">
                            এনআইডি এবং লাইভ ক্যামেরা সেলফি যাচাই করে অনুমোদন বা বাতিল করতে নিচের বাটনে চাপ দিন।
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setActiveTab('users');
                          setShowOnlyPendingDrivers(true);
                        }}
                        className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl transition shadow-xs flex items-center gap-1.5 whitespace-nowrap self-stretch sm:self-auto justify-center cursor-pointer"
                      >
                        <span>পেন্ডিং আবেদন যাচাই করুন</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  <div className="flex items-center justify-between bg-white p-3.5 rounded-2xl border border-[#E6E0D4]">
                    <span className="font-bold text-sm text-[#2D3A3A]">
                      নিবন্ধিত চালক তালিকা: {drivers.length} জন
                    </span>
                    <span className="text-xs text-[#736B5E]">
                      চালকের আসল ফোন নম্বর ও NID ভেরিফিকেশন ব্যবস্থাপনা
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {drivers.map((driver) => (
                      <div
                        key={driver.id}
                        className="bg-white rounded-2xl p-4 border border-[#E6E0D4] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-[#2D3A3A]">{driver.driverName}</span>
                            <span className="text-[10px] bg-[#FAF8F5] border border-[#D4C3A3] text-[#A65E2E] font-bold px-2 py-0.5 rounded-full">
                              {driver.vehicleType}
                            </span>
                            {driver.isVerified && (
                              <span className="text-[10px] bg-[#27AE60] text-white font-bold px-2 py-0.5 rounded-full">
                                ✓ NID ভেরিফাইড
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-[#5A6B6B]">
                            আসল ফোন নম্বর (প্রশাসনিক অডিট): <strong className="text-[#2D5A27]">{driver.phone}</strong> • স্ট্যান্ড: {driver.standLocation} ({driver.district})
                          </p>
                          <p className="text-xs text-[#736B5E]">
                            রুট: {driver.regularRoutes} • সময়সূচি: {driver.serviceShift || '২৪ ঘণ্টা'}
                          </p>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center">
                          <button
                            onClick={() => handleToggleDriverVerify(driver.id)}
                            className={`text-xs font-bold px-3 py-1.5 rounded-xl transition cursor-pointer ${
                              driver.isVerified ? 'bg-orange-50 text-orange-700' : 'bg-green-50 text-green-700'
                            }`}
                          >
                            {driver.isVerified ? 'ভেরিফিকেশন বাতিল' : 'ভেরিফাই করুন'}
                          </button>

                          <button
                            onClick={() => handleDeleteDriver(driver.id)}
                            className="p-1.5 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer"
                            title="চালক মুছুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: HEALTH & DONORS */}
              {activeTab === 'donors' && (isSuperAdmin || hasPerm('canManageHealth')) && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between bg-white p-3.5 rounded-2xl border border-[#E6E0D4]">
                    <span className="font-bold text-sm text-[#2D3A3A]">
                      রক্তদাতা তালিকা: {donors.length} জন
                    </span>
                    <span className="text-xs text-[#736B5E]">
                      জরুরি রক্তের সন্ধান ও ডেটা নিয়ন্ত্রণ
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {donors.map((donor) => (
                      <div
                        key={donor.id}
                        className="bg-white rounded-2xl p-4 border border-[#E6E0D4] flex items-center justify-between gap-3 shadow-2xs"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-[#2D3A3A]">{donor.name}</span>
                            <span className="text-xs font-extrabold bg-red-100 text-red-700 px-2 py-0.5 rounded-full">
                              গ্রুপ: {donor.bloodGroup}
                            </span>
                          </div>
                          <p className="text-xs text-[#5A6B6B]">
                            ফোন: <strong>{donor.phone}</strong> • এলাকা: {donor.villageOrArea}, {donor.upazila}, {donor.district}
                          </p>
                        </div>

                        <button
                          onClick={() => handleDeleteDonor(donor.id)}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 6: ANALYTICS & AUDIT LOGS (SUPER ADMIN EXCLUSIVE) */}
              {activeTab === 'analytics' && (
                isSuperAdmin ? (
                  <AdminAuditAndReports 
                    currentAdminName={currentAdmin?.name || 'Super Admin'} 
                    isSuperAdmin={isSuperAdmin}
                    permissions={currentAdmin?.assignedPermissions}
                  />
                ) : (
                  <div className="bg-white rounded-3xl p-8 border border-[#E6E0D4] text-center space-y-3 shadow-xs">
                    <div className="w-14 h-14 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto">
                      <Lock className="w-7 h-7" />
                    </div>
                    <h4 className="font-bold text-base text-[#2D3A3A]">অডিট ও রিপোর্ট এক্সেস সংরক্ষিত</h4>
                    <p className="text-xs text-[#736B5E] max-w-md mx-auto leading-relaxed">
                      সহকারী এডমিনদের জন্য অডিট লগ, রিপোর্ট ও অডিট লক নিয়ন্ত্রণ ক্ষমতা বন্ধ করা হয়েছে। এই ক্ষমতা শুধুমাত্র প্রধান অ্যাপ এডমিনের জন্য সংরক্ষিত।
                    </p>
                  </div>
                )
              )}

              {/* TAB 8: CITIZEN CHAT AUDIT & MONITORING (SUPER ADMIN EXCLUSIVE) */}
              {activeTab === 'chats' && (
                <div className="space-y-4">
                  {/* Security Header Banner */}
                  <div className="bg-gradient-to-r from-[#2D5A27] to-[#1E3F1A] text-white p-4 rounded-3xl shadow-xs space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-5 h-5 text-amber-300" />
                        <h4 className="font-bold text-base">নাগরিক চ্যাট ও অভ্যন্তরীণ বার্তা পর্যবেক্ষণ</h4>
                      </div>
                      <span className="bg-amber-400 text-black text-[10px] font-extrabold px-2.5 py-0.5 rounded-full">
                        👑 প্রধান এডমিন একচেটিয়া এক্সেস
                      </span>
                    </div>
                    <p className="text-xs text-white/80 leading-relaxed">
                      ব্যবহারকারীদের নিরাপত্তা ও প্রতারণা রোধে শুধুমাত্র প্রধান এডমিন (polliseba26@gmail.com) বার্তাগুলো পর্যবেক্ষণ করতে পারেন। সহকারী এডমিনদের জন্য এই তথ্য সম্পূর্ণ গোপন ও সংরক্ষিত।
                    </p>
                  </div>

                  {!isSuperAdmin ? (
                    <div className="bg-red-50 border border-red-200 text-red-700 p-6 rounded-3xl text-center space-y-2">
                      <AlertTriangle className="w-8 h-8 mx-auto text-red-500" />
                      <h5 className="font-bold text-sm">প্রবেশাধিকার সংরক্ষিত</h5>
                      <p className="text-xs text-red-600">
                        সহকারী এডমিনদের ব্যবহারকারীদের অভ্যন্তরীণ কথোপকথন বা চ্যাট বার্তা দেখার অনুমতি নেই।
                      </p>
                    </div>
                  ) : chatConversations.length === 0 ? (
                    <div className="bg-white rounded-3xl p-8 text-center border border-[#E6E0D4] space-y-2">
                      <MessageSquare className="w-12 h-12 text-gray-300 mx-auto" />
                      <p className="text-sm font-bold text-[#2D3A3A]">কোনো নাগরিক বার্তা এখনও রেকর্ড হয়নি</p>
                      <p className="text-xs text-[#736B5E]">পল্লী হাট বা চালকদের সাথে নাগরিকরা চ্যাট করলেই তা সরাসরি এখানে সুপার এডমিনের সুরক্ষায় সংরক্ষিত হবে।</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                      {/* Conversations List */}
                      <div className="lg:col-span-5 bg-white rounded-3xl border border-[#E6E0D4] p-3 space-y-2 max-h-[560px] overflow-y-auto">
                        <div className="p-2 border-b border-[#E6E0D4] flex items-center justify-between">
                          <span className="font-bold text-xs text-[#2D3A3A]">কথোপকথন তালিকা ({chatConversations.length})</span>
                          <span className="text-[11px] text-[#736B5E]">লাইভ ক্লাউড ডাটা</span>
                        </div>

                        {chatConversations.map((c) => {
                          const isSelected = selectedChatConvo?.id === c.id;
                          return (
                            <div
                              key={c.id}
                              onClick={() => setSelectedChatConvo(c)}
                              className={`p-3 rounded-2xl border transition cursor-pointer space-y-1.5 ${
                                isSelected 
                                  ? 'bg-[#D4E4BC]/30 border-[#2D5A27] shadow-xs' 
                                  : 'bg-[#FAF8F5] border-[#E6E0D4] hover:border-[#D4C3A3]'
                              }`}
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div className="space-y-0.5">
                                  <h6 className="font-bold text-xs text-[#2D3A3A]">
                                    {c.participantNames ? Object.values(c.participantNames).join(' ↔ ') : 'নাগরিক চ্যাট'}
                                  </h6>
                                  {c.itemTitle && (
                                    <span className="text-[10px] bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-md font-semibold inline-block">
                                      🛍️ বিষয়: {c.itemTitle}
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-[#736B5E] whitespace-nowrap">
                                  {c.updatedAt ? new Date(c.updatedAt).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }) : ''}
                                </span>
                              </div>

                              <p className="text-xs text-[#5A6B6B] truncate">
                                {c.lastMessage || 'বার্তা দেখুন...'}
                              </p>

                              <div className="text-[10px] text-[#736B5E] flex items-center gap-1">
                                <span>অংশগ্রহণকারী:</span>
                                <strong>{c.participants ? c.participants.join(', ') : 'অজ্ঞাত'}</strong>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Conversation Messages Thread */}
                      <div className="lg:col-span-7 bg-white rounded-3xl border border-[#E6E0D4] p-4 flex flex-col justify-between min-h-[450px] max-h-[560px]">
                        {selectedChatConvo ? (
                          <>
                            <div className="border-b border-[#E6E0D4] pb-3 space-y-1">
                              <div className="flex items-center justify-between">
                                <h5 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-2">
                                  <span>{selectedChatConvo.participantNames ? Object.values(selectedChatConvo.participantNames).join(' ও ') : 'বার্তা থ্রেড'}</span>
                                  <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">সুরক্ষিত থ্রেড</span>
                                </h5>
                                <button
                                  type="button"
                                  onClick={() => setSelectedChatConvo(null)}
                                  className="text-xs text-[#736B5E] hover:text-[#2D3A3A] cursor-pointer"
                                >
                                  ✕ বন্ধ করুন
                                </button>
                              </div>
                              {selectedChatConvo.itemTitle && (
                                <p className="text-xs text-[#5A6B6B]">
                                  সংযুক্ত বিষয়/পণ্য: <strong>{selectedChatConvo.itemTitle}</strong>
                                </p>
                              )}
                            </div>

                            {/* Message Bubble List */}
                            <div className="flex-1 overflow-y-auto py-3 space-y-2.5 my-2 pr-1">
                              {convoMessages.length === 0 ? (
                                <div className="text-center py-10 text-xs text-[#736B5E]">
                                  এই কথোপকথনে এখনও কোনো বিস্তারিত বার্তা পাওয়া যায়নি।
                                </div>
                              ) : (
                                convoMessages.map((msg) => (
                                  <div
                                    key={msg.id}
                                    className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] space-y-1"
                                  >
                                    <div className="flex items-center justify-between text-[11px]">
                                      <span className="font-bold text-[#2D5A27]">
                                        👤 {msg.senderName || msg.senderId}
                                      </span>
                                      <span className="text-[#736B5E] text-[10px]">
                                        {msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }) : ''}
                                      </span>
                                    </div>
                                    <p className="text-xs text-[#2D3A3A] whitespace-pre-wrap leading-relaxed">
                                      {msg.text}
                                    </p>
                                    {msg.imageUrl && (
                                      <img
                                        src={msg.imageUrl}
                                        alt="Chat attachment"
                                        className="max-h-40 rounded-xl object-cover border border-[#D4C3A3] mt-1"
                                      />
                                    )}
                                  </div>
                                ))
                              )}
                            </div>

                            <div className="p-2.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] text-[11px] text-[#736B5E] flex items-center justify-between">
                              <span>🔒 প্রধান এডমিন অডিট ও নিরাপত্তা মোড (রিড-অনলি)</span>
                              <span className="text-[10px] text-[#2D5A27] font-semibold">এনক্রিপ্টেড ক্লাউড স্টোরেজ</span>
                            </div>
                          </>
                        ) : (
                          <div className="flex flex-col items-center justify-center h-full text-center p-8 space-y-2">
                            <MessageSquare className="w-10 h-10 text-[#D4C3A3]" />
                            <p className="font-bold text-sm text-[#2D3A3A]">কোনো কথোপকথন নির্বাচন করা হয়নি</p>
                            <p className="text-xs text-[#736B5E] max-w-sm">
                              বামপাশের তালিকা থেকে যেকোনো নাগরিক চ্যাট নির্বাচন করে বিস্তারিত বার্তা পর্যালোচনা করুন।
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 8: SMART AREA-BASED PUSH NOTIFICATIONS (FCM) */}
              {activeTab === 'notifications' && (
                <div className="space-y-5">
                  {/* Header Banner */}
                  <div className="bg-gradient-to-r from-[#2D5A27] to-[#1E3F1A] p-5 rounded-3xl text-white shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="p-2 bg-[#E8924A] rounded-2xl text-white shadow-xs">
                          <Bell className="w-5 h-5 animate-pulse" />
                        </span>
                        <h4 className="font-bold text-base sm:text-lg">
                          স্মার্ট এলাকাভিত্তিক পুশ নোটিফিকেশন সিস্টেম (FCM)
                        </h4>
                      </div>
                      <p className="text-xs text-[#D4E4BC] max-w-xl leading-relaxed">
                        নির্বিচারে গণ-বিজ্ঞপ্তি না পাঠিয়ে শুধুমাত্র নির্দিষ্ট জেলা, উপজেলা এবং নির্দিষ্ট পেশার মানুষের কাছে (যেমন: কৃষি শ্রমিক, চালক বা কৃষক) চাহিদা ও সতর্কতা নোটিফিকেশন সরাসরি পুশ করুন।
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={async () => {
                        if (typeof window !== 'undefined' && 'Notification' in window) {
                          const permission = await Notification.requestPermission();
                          if (permission === 'granted') {
                            new Notification('পল্লী সেবা পুশ নোটিফিকেশন চালু হয়েছে', {
                              body: 'এখন থেকে এলাকাভিত্তিক জরুরি নোটিফিকেশন আপনার ডিভাইসে সরাসরি প্রদর্শিত হবে।'
                            });
                            triggerSuccessToast('ডিভাইসে পুশ নোটিফিকেশন পারমিশন সক্রিয় হয়েছে');
                          } else {
                            alert('ব্রাউজারের নোটিফিকেশন পারমিশন ব্লক করা আছে। ব্রাউজার সেটিংসে গিয়ে অনুমতি দিন।');
                          }
                        } else {
                          triggerSuccessToast('সিস্টেম ক্লাউড নোটিফিকেশনের জন্য প্রস্তুত');
                        }
                      }}
                      className="px-4 py-2.5 bg-[#E8924A] hover:bg-[#D97D35] text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    >
                      <Bell className="w-4 h-4" />
                      <span>ব্রাউজার পুশ পরীক্ষা করুন</span>
                    </button>
                  </div>

                  {/* Create New Demand Notification Form */}
                  <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-xs space-y-4">
                    <div className="flex items-center gap-2 border-b border-[#E6E0D4] pb-3">
                      <Send className="w-4 h-4 text-[#2D5A27]" />
                      <h5 className="font-bold text-sm sm:text-base text-[#2D3A3A]">
                        নতুন এলাকা ও পেশাভিত্তিক পুশ নোটিফিকেশন প্রেরণ করুন
                      </h5>
                    </div>

                    <form
                      onSubmit={async (e) => {
                        e.preventDefault();
                        if (!demandTitle.trim() || !demandMessage.trim()) {
                          alert('দয়া করে নোটিফিকেশনের শিরোনাম এবং বিস্তারিত বার্তা প্রদান করুন।');
                          return;
                        }

                        setDemandSending(true);
                        try {
                          const newNotif: DemandNotification = {
                            id: `demand_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
                            title: demandTitle.trim(),
                            message: demandMessage.trim(),
                            urgency: demandUrgency,
                            targetDistrict: demandDistrict,
                            targetUpazila: demandUpazila.trim() || 'সকল উপজেলা',
                            targetRole: demandRole,
                            senderName: currentAdmin.name || 'পল্লী সেবা কন্ট্রোল ডেস্ক',
                            contactNumber: demandContact.trim() || undefined,
                            createdAt: Date.now(),
                            createdAtFormatted: new Date().toLocaleString('bn-BD', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })
                          };

                          await saveDemandNotification(newNotif);

                          // Trigger browser notification preview if allowed
                          if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
                            try {
                              new Notification(`[${newNotif.urgency}] ${newNotif.title}`, {
                                body: `${newNotif.targetDistrict} (${newNotif.targetUpazila}): ${newNotif.message}`
                              });
                            } catch (notifErr) {}
                          }

                          triggerSuccessToast('এলাকাভিত্তিক পুশ নোটিফিকেশন সফলভাবে ক্লাউডে ব্রডকাস্ট হয়েছে!');
                          setDemandTitle('');
                          setDemandMessage('');
                          setDemandContact('');
                        } catch (err) {
                          console.error(err);
                          alert('নোটিফিকেশন প্রেরণে সমস্যা হয়েছে। পুনরায় চেষ্টা করুন।');
                        } finally {
                          setDemandSending(false);
                        }
                      }}
                      className="space-y-4"
                    >
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        {/* Target District */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-[#2D5A27]" />
                            <span>১. লক্ষ্য জেলা (Target District) *</span>
                          </label>
                          <select
                            value={demandDistrict}
                            onChange={(e) => setDemandDistrict(e.target.value)}
                            className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#2D5A27] cursor-pointer"
                          >
                            <option value="সকল জেলা">🌐 সকল জেলা (সারাদেশ)</option>
                            {BANGLADESH_DISTRICTS.map((d) => (
                              <option key={d} value={d}>
                                {d} জেলা
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* Target Upazila */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1">
                            <Filter className="w-3.5 h-3.5 text-[#E8924A]" />
                            <span>২. লক্ষ্য উপজেলা (Target Upazila)</span>
                          </label>
                          <input
                            type="text"
                            value={demandUpazila}
                            onChange={(e) => setDemandUpazila(e.target.value)}
                            placeholder="যেমন: শিবগঞ্জ, দুপচাঁচিয়া, অথবা 'সকল উপজেলা'"
                            className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                          />
                        </div>

                        {/* Target Role */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-[#2D3A3A] flex items-center gap-1">
                            <Users className="w-3.5 h-3.5 text-[#2D5A27]" />
                            <span>৩. লক্ষ্য পেশা/রোল (Target Role) *</span>
                          </label>
                          <select
                            value={demandRole}
                            onChange={(e) => setDemandRole(e.target.value)}
                            className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#2D5A27] cursor-pointer"
                          >
                            <option value="all">👥 সকল ব্যবহারকারী (গণ-নোটিশ)</option>
                            <option value="laborer">🌾 ৩. কৃষি শ্রমিক ও দিনমজুর (যেমন: কামলা/শ্রমিক প্রয়োজন)</option>
                            <option value="farmer">🌱 ২. কৃষক ও খামারি (যেমন: সার/বীজ/ফসলের রোগ সতর্কতা)</option>
                            <option value="driver">🚗 ৬. পরিবহন চালক (যেমন: জরুরি পিকআপ/এম্বুলেন্স/ভাড়ার যাত্রী)</option>
                            <option value="agri_machinery_driver">🚜 ১০. ট্র্যাক্টর / হেস্কোভেটর চালক (যেমন: জমি চাষ/ভেকু প্রয়োজন)</option>
                            <option value="boatman">⛵ ১১. নৌকার মাঝি ও খেয়া চালক (যেমন: নদী পারাপার/ট্রলার রিজার্ভ)</option>
                            <option value="trader">🛍️ ৫. ব্যবসায়ী ও পাইকার (যেমন: হাটে ক্রয়-বিক্রয়)</option>
                            <option value="doctor">👨‍⚕️ ৭. পল্লী চিকিৎসক ও স্বাস্থ্যকর্মী</option>
                            <option value="home_entrepreneur">🏡 ৪. গৃহ উদ্যোক্তা ও কুটির শিল্প</option>
                            <option value="mechanic">🔧 ৮. মেকানিক ও কারিগর</option>
                            <option value="tutor">📚 ৯. টিউটর ও শিক্ষক</option>
                            <option value="citizen">👤 ১. সাধারণ নাগরিক</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {/* Urgency */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-[#2D3A3A]">
                            জরুরি মাত্রা (Urgency Priority)
                          </label>
                          <div className="flex gap-2">
                            {(['জরুরি', 'সতর্কবার্তা', 'সাধারণ'] as const).map((urg) => (
                              <button
                                key={urg}
                                type="button"
                                onClick={() => setDemandUrgency(urg)}
                                className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                                  demandUrgency === urg
                                    ? urg === 'জরুরি'
                                      ? 'bg-red-600 text-white shadow-xs'
                                      : urg === 'সতর্কবার্তা'
                                      ? 'bg-amber-600 text-white shadow-xs'
                                      : 'bg-[#2D5A27] text-white shadow-xs'
                                    : 'bg-[#FAF8F5] text-[#5A6B6B] border border-[#E6E0D4]'
                                }`}
                              >
                                {urg === 'জরুরি' ? '🚨 জরুরি' : urg === 'সতর্কবার্তা' ? '⚠️ সতর্কতা' : '📢 সাধারণ'}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Contact hotline */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-[#2D3A3A]">
                            যোগাযোগের ফোন নম্বর (ঐচ্ছিক)
                          </label>
                          <input
                            type="tel"
                            value={demandContact}
                            onChange={(e) => setDemandContact(e.target.value)}
                            placeholder="যেমন: 017XXXXXXXX"
                            className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#2D5A27]"
                          />
                        </div>
                      </div>

                      {/* Title */}
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-[#2D3A3A]">
                          নোটিফিকেশনের শিরোনাম (Notification Title) *
                        </label>
                        <input
                          type="text"
                          value={demandTitle}
                          onChange={(e) => setDemandTitle(e.target.value)}
                          placeholder="যেমন: জরুরি ৫ জন কৃষি শ্রমিক (কামলা) প্রয়োজন - শিবগঞ্জ"
                          className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#2D5A27]"
                          required
                        />
                      </div>

                      {/* Message Body */}
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-[#2D3A3A]">
                          বিস্তারিত চাহিদা ও বার্তা (Push Message Description) *
                        </label>
                        <textarea
                          rows={3}
                          value={demandMessage}
                          onChange={(e) => setDemandMessage(e.target.value)}
                          placeholder="চাহিদার বিস্তারিত লিখুন: কাজের স্থান, পারিশ্রমিক/ভাড়ার হার, সময়সীমা এবং যোগাযোগের নিয়ম..."
                          className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-xl p-3 text-xs leading-relaxed focus:outline-none focus:border-[#2D5A27]"
                          required
                        />
                      </div>

                      {/* Submit */}
                      <div className="flex justify-end pt-2">
                        <button
                          type="submit"
                          disabled={demandSending}
                          className="px-6 py-2.5 bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                        >
                          <Send className="w-4 h-4" />
                          <span>{demandSending ? 'প্রেরণ হচ্ছে...' : '🚀 এলাকাভিত্তিক পুশ নোটিফিকেশন প্রেরণ করুন'}</span>
                        </button>
                      </div>
                    </form>
                  </div>

                  {/* Sent Notifications History */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h5 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-2">
                        <span>সাম্প্রতিক প্রেরিত এলাকাভিত্তিক নোটিফিকেশন ও চাহিদা সমূহ</span>
                        <span className="text-xs bg-[#D4E4BC] text-[#2D5A27] px-2 py-0.5 rounded-full font-bold">
                          {demandNotifications.length}টি সক্রিয়
                        </span>
                      </h5>
                    </div>

                    {demandNotifications.length === 0 ? (
                      <div className="bg-white rounded-3xl p-8 text-center border border-[#E6E0D4] space-y-2">
                        <Bell className="w-10 h-10 text-gray-300 mx-auto" />
                        <p className="text-sm font-bold text-[#2D3A3A]">এখনও কোনো এলাকাভিত্তিক নোটিফিকেশন পাঠানো হয়নি</p>
                        <p className="text-xs text-[#736B5E]">
                          উপরের ফর্ম ব্যবহার করে কোনো এলাকার শ্রমিক, চালক বা কৃষকদের কাছে জরুরি ডিমান্ড বা নোটিশ পাঠান।
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2.5">
                        {demandNotifications.map((notif) => {
                          const roleLabel = notif.targetRole === 'all' 
                            ? 'সকল নাগরিক' 
                            : USER_ROLES_LIST.find(r => r.id === notif.targetRole)?.label || notif.targetRole;

                          return (
                            <div
                              key={notif.id}
                              className="bg-white rounded-2xl p-4 border border-[#E6E0D4] shadow-2xs space-y-2.5 transition hover:shadow-xs"
                            >
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E6E0D4] pb-2">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                    notif.urgency === 'জরুরি'
                                      ? 'bg-red-100 text-red-800 border border-red-300'
                                      : notif.urgency === 'সতর্কবার্তা'
                                      ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                      : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                  }`}>
                                    {notif.urgency === 'জরুরি' ? '🚨 জরুরি' : notif.urgency === 'সতর্কবার্তা' ? '⚠️ সতর্কতা' : '📢 সাধারণ'}
                                  </span>

                                  <span className="text-[11px] font-bold bg-[#FAF8F5] text-[#2D5A27] border border-[#E6E0D4] px-2 py-0.5 rounded-lg flex items-center gap-1">
                                    <MapPin className="w-3 h-3 text-[#2D5A27]" />
                                    <span>{notif.targetDistrict}</span>
                                    {notif.targetUpazila && notif.targetUpazila !== 'সকল উপজেলা' && (
                                      <span>• {notif.targetUpazila}</span>
                                    )}
                                  </span>

                                  <span className="text-[11px] font-bold bg-[#D4E4BC]/50 text-[#2D5A27] px-2 py-0.5 rounded-lg">
                                    👥 {roleLabel}
                                  </span>
                                </div>

                                <div className="flex items-center gap-2">
                                  <span className="text-[10px] text-[#736B5E]">
                                    {notif.createdAtFormatted || 'সাম্প্রতিক'}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={async () => {
                                      if (confirm(`আপনি কি এই নোটিফিকেশনটি ("${notif.title}") মুছে ফেলতে চান?`)) {
                                        await deleteDemandNotification(notif.id);
                                        triggerSuccessToast('নোটিফিকেশন প্রত্যাহার ও মুছে ফেলা হয়েছে');
                                      }
                                    }}
                                    className="p-1 text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                                    title="মুছে ফেলুন"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>

                              <div>
                                <h6 className="font-bold text-sm text-[#2D3A3A]">{notif.title}</h6>
                                <p className="text-xs text-[#5A6B6B] mt-1 leading-relaxed whitespace-pre-wrap">
                                  {notif.message}
                                </p>
                              </div>

                              <div className="flex items-center justify-between text-[11px] text-[#736B5E] pt-1">
                                <span>প্রেরক: <strong>{notif.senderName}</strong></span>
                                {notif.contactNumber && (
                                  <a
                                    href={`tel:${notif.contactNumber}`}
                                    className="text-[#2D5A27] font-bold hover:underline flex items-center gap-1"
                                  >
                                    <PhoneCall className="w-3 h-3" />
                                    <span>{notif.contactNumber}</span>
                                  </a>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}

            </div>
          )}
        </div>

      </div>

      {/* MODAL 1: ADD NEW AD BANNER (Image/3D GIF/Video) */}
      {showAddAdModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[88vh] sm:max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E0D4] animate-in fade-in duration-150 overflow-hidden">
            
            <div className="flex items-center justify-between border-b border-[#E6E0D4] p-4 sm:p-5 shrink-0 bg-white">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#E8924A]" />
                <h4 className="font-bold text-base text-[#2D3A3A]">নতুন বিজ্ঞাপন ব্যানার তৈরি করুন</h4>
              </div>
              <button
                onClick={() => setShowAddAdModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] font-bold cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateNewAd} className="flex flex-col flex-1 overflow-hidden">
              <div className="p-4 sm:p-5 overflow-y-auto overscroll-contain flex-1 space-y-4 text-xs text-[#2D3A3A]">
              
              <div>
                <label className="block font-bold mb-1">বিজ্ঞাপনের শিরোনাম *</label>
                <input
                  type="text"
                  required
                  value={newAdTitle}
                  onChange={(e) => setNewAdTitle(e.target.value)}
                  placeholder="যেমন: আলফা অ্যাগ্রো - উচ্চ ফলনশীল ধান ও সবজি বীজ"
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-medium focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">স্পনসর / প্রতিষ্ঠানের নাম *</label>
                  <input
                    type="text"
                    required
                    value={newAdSponsor}
                    onChange={(e) => setNewAdSponsor(e.target.value)}
                    placeholder="যেমন: আলফা সীডস কোম্পানি"
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-medium focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">বিজ্ঞাপনের ফরম্যাট *</label>
                  <select
                    value={newAdType}
                    onChange={(e: any) => setNewAdType(e.target.value)}
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-bold text-[#2D5A27] focus:outline-none"
                  >
                    <option value="gif_3d">✨ 3D অ্যানিমেশন GIF</option>
                    <option value="video">🎥 ছোট ভিডিও ব্যানার (MP4)</option>
                    <option value="image">🖼️ HD ছবি / ব্যানার পোস্টার</option>
                  </select>
                </div>
              </div>

              {/* Direct Media File Upload Field */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#D4C3A3] space-y-2">
                <label htmlFor="mediaFile" className="block font-bold text-[#2D3A3A]">
                  📁 মিডিয়া সরাসরি ফাইল আপলোড করুন (ছবি/GIF/ভিডিও):
                </label>
                <input
                  type="file"
                  id="mediaFile"
                  accept="image/*,video/mp4"
                  onChange={handleMediaFileUpload}
                  className="w-full bg-white border border-[#D4C3A3] rounded-xl p-2 font-medium file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-[#2D5A27] file:text-white hover:file:bg-[#23491E] cursor-pointer"
                />
                <div className="flex items-center justify-between">
                  <small className="text-[#666] text-[11px]">
                    {uploadedFileName ? `✅ নির্বাচিত ফাইল: ${uploadedFileName}` : 'অথবা নিচে অনলাইন ইউআরএল (URL) বসাতে পারেন'}
                  </small>
                  {newAdMediaUrl && (
                    <span className="text-[10px] text-[#2D5A27] font-bold">মিডিয়া লোড হয়েছে</span>
                  )}
                </div>
                {mediaUploadError && (
                  <p className="text-[11px] text-red-600 font-medium">{mediaUploadError}</p>
                )}
              </div>

              <div>
                <label className="block font-bold mb-1">মিডিয়া URL (Image/GIF/Video Link) *</label>
                <input
                  type="text"
                  required
                  value={newAdMediaUrl}
                  onChange={(e) => setNewAdMediaUrl(e.target.value)}
                  placeholder="https://example.com/banner.gif বা .mp4 বা .jpg (বা ওপরের ফাইল আপলোড ব্যবহার করুন)"
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-mono text-xs focus:outline-none focus:border-[#2D5A27]"
                />
                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setNewAdMediaUrl('https://images.unsplash.com/photo-1592417817098-8f3d6eb22509?w=1200&auto=format&fit=crop&q=80');
                      setNewAdType('image');
                    }}
                    className="text-[10px] text-[#2D5A27] underline cursor-pointer"
                  >
                    নমুনা কৃষি ছবি
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setNewAdMediaUrl('https://assets.mixkit.co/videos/preview/mixkit-countryside-meadow-and-wind-turbines-41475-large.mp4');
                      setNewAdType('video');
                    }}
                    className="text-[10px] text-[#2D5A27] underline cursor-pointer"
                  >
                    নমুনা ভিডিও লিংক
                  </button>
                </div>
              </div>

              {/* Media Preview Box */}
              {newAdMediaUrl && (
                <div className="p-2.5 bg-[#FAF8F5] rounded-xl border border-[#E6E0D4] space-y-1">
                  <span className="text-[10px] font-bold text-[#736B5E] block">লাইভ প্রিভিউ:</span>
                  <div className="h-28 w-full rounded-lg overflow-hidden bg-black/10 flex items-center justify-center relative">
                    {newAdType === 'video' ? (
                      <video src={newAdMediaUrl} className="w-full h-full object-cover" autoPlay loop muted playsInline />
                    ) : (
                      <img src={newAdMediaUrl} alt="Ad Preview" className="w-full h-full object-cover" />
                    )}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">টার্গেট ওয়েবসাইট লিংক (ঐচ্ছিক)</label>
                  <input
                    type="url"
                    value={newAdTargetUrl}
                    onChange={(e) => setNewAdTargetUrl(e.target.value)}
                    placeholder="https://yourwebsite.com"
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">স্পনসর মোবাইল নম্বর (কলের জন্য)</label>
                  <input
                    type="tel"
                    value={newAdCallNumber}
                    onChange={(e) => setNewAdCallNumber(e.target.value)}
                    placeholder="01711002233"
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">টার্গেট এলাকা (জেলা)</label>
                  <select
                    value={newAdDistrict}
                    onChange={(e) => setNewAdDistrict(e.target.value)}
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-medium focus:outline-none"
                  >
                    <option value="সকল জেলা">সকল জেলা (সমগ্র বাংলাদেশ)</option>
                    {BANGLADESH_DISTRICTS.map((d) => (
                      <option key={d} value={d}>{d} জেলা</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1">প্রদর্শন অবস্থান</label>
                  <select
                    value={newAdPlacement}
                    onChange={(e: any) => setNewAdPlacement(e.target.value)}
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-medium focus:outline-none"
                  >
                    <option value="home_weather_bottom">হোম পেজ (আবহাওয়া নিচে)</option>
                    <option value="marketplace_top">পল্লী হাট বাজার পেজ</option>
                    <option value="transport_middle">নিরাপদ পরিবহন পেজ</option>
                    <option value="all">সকল পেজে</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1">বিজ্ঞাপনের বিবরণ / আকর্ষণীয় অফার</label>
                <textarea
                  rows={2}
                  value={newAdDescription}
                  onChange={(e) => setNewAdDescription(e.target.value)}
                  placeholder="বিজ্ঞাপনের অফার ও বিবরণ লিখুন..."
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 focus:outline-none focus:border-[#2D5A27]"
                />
              </div>
              </div>

              {/* Pinned Sticky Bottom Action Bar */}
              <div className="border-t border-[#E6E0D4] p-4 bg-[#FAF8F5] shrink-0 flex items-center gap-2 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
                <button
                  type="submit"
                  className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-3 rounded-xl text-xs shadow-xs cursor-pointer active:scale-98 transition flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>বিজ্ঞাপন প্রকাশ করুন</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddAdModal(false)}
                  className="bg-white text-[#5A6B6B] font-semibold py-3 px-4 rounded-xl text-xs border border-[#E6E0D4] hover:bg-gray-50 cursor-pointer"
                >
                  বাতিল
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* MODAL 2: ADD NEW SUB-ADMIN */}
      {showAddSubAdminModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-md w-full max-h-[88vh] sm:max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E0D4] animate-in fade-in duration-150 overflow-hidden">
            
            <div className="flex items-center justify-between border-b border-[#E6E0D4] p-4 sm:p-5 shrink-0 bg-white">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-[#2D5A27]" />
                <h4 className="font-bold text-base text-[#2D3A3A]">সহযোগী অ্যাডমিন (Sub-Admin) তৈরি</h4>
              </div>
              <button
                onClick={() => setShowAddSubAdminModal(false)}
                className="text-[#736B5E] hover:text-[#2D3A3A] font-bold cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubAdmin} className="flex flex-col flex-1 overflow-hidden">
              <div className="p-4 sm:p-5 overflow-y-auto overscroll-contain flex-1 space-y-3.5 text-xs text-[#2D3A3A]">
                <div className="bg-[#FAF8F5] p-3 rounded-2xl border border-[#E6E0D4] text-[11px] text-[#5A6B6B] space-y-1">
                  <p className="font-bold text-[#2D5A27]">💡 সহকারী নিয়োগ নির্দেশিকা:</p>
                  <p>• প্রতিটি সহকারীর জন্য <strong>আলাদা নাম, মোবাইল নম্বর/ইমেইল এবং নিজস্ব ৪-ডিজিট পিন কোড</strong> নির্ধারণ করে দিন।</p>
                  <p>• সহকারীরা তাদের <strong>নিজস্ব পিন কোড</strong> দিয়ে লগইন করে কেবল তাদের নির্ধারিত দায়িত্ব সম্পন্ন করতে পারবে। সুপার এডমিনের পাসওয়ার্ড তাদের জানার প্রয়োজন নেই।</p>
                </div>

                <div className="space-y-3">
                
                <div>
                  <label className="block font-bold mb-1">সহযোগী অ্যাডমিনের নাম *</label>
                  <input
                    type="text"
                    required
                    value={newSubName}
                    onChange={(e) => setNewSubName(e.target.value)}
                    placeholder="যেমন: তারেক মাহমুদ"
                    className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-medium focus:outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold mb-1">ফোন বা ইমেইল *</label>
                    <input
                      type="text"
                      required
                      value={newSubContact}
                      onChange={(e) => setNewSubContact(e.target.value)}
                      placeholder="01712000111"
                      className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-medium focus:outline-none focus:border-[#2D5A27]"
                    />
                  </div>

                  <div>
                    <label className="block font-bold mb-1">লগইন পিন (৪ সংখ্যা) *</label>
                    <input
                      type="password"
                      required
                      maxLength={6}
                      value={newSubPin}
                      onChange={(e) => setNewSubPin(e.target.value)}
                      placeholder="যেমন: 1234"
                      className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-mono text-center font-bold text-sm focus:outline-none focus:border-[#2D5A27]"
                    />
                  </div>
                </div>

                {/* Permissions Checkboxes */}
                <div className="space-y-1.5 pt-1">
                  <label className="block font-bold text-[#2D5A27]">অনুমোদিত কাজের এক্সেস (Permissions):</label>
                  
                  <label className="flex items-center gap-2 bg-[#FAF8F5] p-2 rounded-xl border border-[#E6E0D4] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newSubPerms.canManageAds}
                      onChange={(e) => setNewSubPerms({ ...newSubPerms, canManageAds: e.target.checked })}
                      className="rounded text-[#2D5A27]"
                    />
                    <span>নতুন বিজ্ঞাপনী ব্যানার যোগ ও নিয়ন্ত্রণ</span>
                  </label>

                  <label className="flex items-center gap-2 bg-[#FAF8F5] p-2 rounded-xl border border-[#E6E0D4] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newSubPerms.canManageDrivers}
                      onChange={(e) => setNewSubPerms({ ...newSubPerms, canManageDrivers: e.target.checked })}
                      className="rounded text-[#2D5A27]"
                    />
                    <span>চালকদের NID যাচাই ও তথ্য নিয়ন্ত্রণ</span>
                  </label>

                  <label className="flex items-center gap-2 bg-[#FAF8F5] p-2 rounded-xl border border-[#E6E0D4] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newSubPerms.canModerateListings}
                      onChange={(e) => setNewSubPerms({ ...newSubPerms, canModerateListings: e.target.checked })}
                      className="rounded text-[#2D5A27]"
                    />
                    <span>পল্লী হাট ও ভুয়া/রিপোর্টকৃত পোস্ট অপসারণ</span>
                  </label>

                  <label className="flex items-center gap-2 bg-[#FAF8F5] p-2 rounded-xl border border-[#E6E0D4] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newSubPerms.canManageHealth}
                      onChange={(e) => setNewSubPerms({ ...newSubPerms, canManageHealth: e.target.checked })}
                      className="rounded text-[#2D5A27]"
                    />
                    <span>রক্তদাতা ও স্বাস্থ্যসেবা নিয়ন্ত্রণ</span>
                  </label>

                  <div className="flex items-center justify-between bg-amber-50 p-2.5 rounded-xl border border-amber-200 text-amber-900 text-xs font-medium">
                    <div className="flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-amber-700 flex-shrink-0" />
                      <span>অডিট লগ ও রিপোর্ট ক্ষমতা</span>
                    </div>
                    <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.5 rounded-md font-bold">🔒 প্রধান এডমিন সংরক্ষিত</span>
                  </div>
                </div>
              </div>
              </div>

              {/* Pinned Sticky Bottom Action Bar */}
              <div className="border-t border-[#E6E0D4] p-4 bg-[#FAF8F5] shrink-0 flex items-center gap-2 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
                <button
                  type="submit"
                  className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-3 rounded-xl text-xs sm:text-sm shadow-md cursor-pointer active:scale-98 transition flex items-center justify-center gap-2"
                >
                  <Users className="w-4 h-4" />
                  <span>সহযোগী অ্যাডমিন যুক্ত করুন</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddSubAdminModal(false)}
                  className="bg-white text-[#5A6B6B] font-semibold py-3 px-5 rounded-xl text-xs border border-[#E6E0D4] hover:bg-gray-50 cursor-pointer"
                >
                  বাতিল
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* MODAL 3: EDIT SUB-ADMIN CREDENTIALS */}
      {editingSubAdmin && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl p-5 sm:p-6 w-full max-w-md border border-[#E6E0D4] shadow-2xl space-y-4 max-h-[88vh] sm:max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
              <h4 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-[#2D5A27]" />
                <span>সহযোগী অ্যাডমিনের তথ্য ও পিন পরিবর্তন</span>
              </h4>
              <button
                onClick={() => setEditingSubAdmin(null)}
                className="text-[#736B5E] hover:text-[#2D3A3A] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditSubAdmin} className="space-y-3.5 text-xs text-[#2D3A3A]">
              <div>
                <label className="block font-bold mb-1">অ্যাডমিনের নাম *</label>
                <input
                  type="text"
                  required
                  value={editSubName}
                  onChange={(e) => setEditSubName(e.target.value)}
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-medium focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">যোগাযোগ (ইমেইল বা ফোন নম্বর) *</label>
                <input
                  type="text"
                  required
                  value={editSubContact}
                  onChange={(e) => setEditSubContact(e.target.value)}
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-medium focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">লগইন পিন / পাসওয়ার্ড (৪ সংখ্যা) *</label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={editSubPin}
                  onChange={(e) => setEditSubPin(e.target.value)}
                  className="w-full bg-[#FAF8F5] border border-[#D4C3A3] rounded-xl p-2.5 font-mono text-center font-bold text-sm focus:outline-none focus:border-[#2D5A27]"
                />
              </div>

              <div className="flex items-center gap-2 pt-3">
                <button
                  type="submit"
                  className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-xl text-xs shadow-xs cursor-pointer active:scale-98 transition"
                >
                  সংরক্ষণ করুন
                </button>
                <button
                  type="button"
                  onClick={() => setEditingSubAdmin(null)}
                  className="bg-white text-[#5A6B6B] font-semibold py-2.5 px-4 rounded-xl text-xs border border-[#E6E0D4] hover:bg-gray-50 cursor-pointer"
                >
                  বাতিল
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* 🛡️ USER SECURITY AUDIT LOGBOOK & TRAVEL HISTORY MODAL (ADMIN VIEW) */}
      {selectedUserForLog && (
        <div className="fixed inset-0 z-70 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-4xl w-full p-2 sm:p-4 shadow-2xl border border-[#E6E0D4] space-y-4 my-auto max-h-[94vh] overflow-y-auto">
            <UserSecurityLogbook
              user={selectedUserForLog}
              isAdminView={true}
              onClose={() => setSelectedUserForLog(null)}
            />
          </div>
        </div>
      )}

      {/* 🪪 NID / DRIVING LICENSE INSPECTION LIGHTBOX MODAL */}
      {inspectingDocUrl && (
        <div 
          onClick={() => setInspectingDocUrl(null)}
          className="fixed inset-0 z-80 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl max-w-2xl w-full p-4 sm:p-5 shadow-2xl border border-slate-300 space-y-3 relative"
          >
            <div className="flex items-center justify-between border-b pb-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h4 className="font-bold text-sm text-slate-900">{inspectingDocTitle || 'ডকুমেন্ট স্ক্যান কপি'}</h4>
              </div>
              <button
                type="button"
                onClick={() => setInspectingDocUrl(null)}
                className="p-1.5 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-[75vh] overflow-auto flex items-center justify-center bg-slate-950 rounded-2xl p-2">
              <img
                src={inspectingDocUrl}
                alt="Document Full View"
                className="max-h-[70vh] w-auto max-w-full rounded-xl object-contain shadow-lg"
              />
            </div>

            <div className="flex items-center justify-between pt-1 text-xs">
              <span className="text-[11px] text-emerald-800 font-semibold">
                🛡️ এডমিন ভেরিফিকেশন রেকর্ড • ফায়ারবেস ক্লাউড স্টোরেজে সংরক্ষিত
              </span>
              <button
                type="button"
                onClick={() => setInspectingDocUrl(null)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ⚠️ DRIVER / BOATMAN REJECTION OR REVISION REQUEST MODAL */}
      {rejectingDriverUser && (
        <div 
          onClick={() => setRejectingDriverUser(null)}
          className="fixed inset-0 z-80 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-red-200 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <div className="flex items-center gap-2 text-red-700">
                <AlertTriangle className="w-5 h-5" />
                <h4 className="font-bold text-base text-gray-900">আবেদন বাতিল / তথ্য সংশোধন অনুরোধ</h4>
              </div>
              <button
                type="button"
                onClick={() => setRejectingDriverUser(null)}
                className="p-1 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 text-xs text-amber-900 space-y-1">
              <p><strong>আবেদনকারী:</strong> {rejectingDriverUser.name} ({rejectingDriverUser.phone})</p>
              <p><strong>রোল:</strong> {rejectingDriverUser.role === 'boatman' ? 'নৌকার মাঝি ও খেয়া চালক' : rejectingDriverUser.role === 'agri_machinery_driver' ? 'ট্র্যাক্টর ও কৃষিযন্ত্র চালক' : 'পরিবহন চালক'}</p>
              <p className="text-[11px] text-amber-800">নিচে বাতিলের কারণ বা সংশোধনের বার্তা লিখুন। এটি সরাসরি আবেদনকারীর ইনবক্সে নোটিশ হিসেবে পৌঁছাবে।</p>
            </div>

            {/* Quick Reason Suggestions */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-gray-700">সাধারণ কারণ নির্বাচন করুন:</label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'এনআইডি কার্ডের ছবি অস্পষ্ট বা পড়া যাচ্ছে না',
                  'লাইভ ফেস ছবির সাথে এনআইডি ছবির মিল পাওয়া যায়নি',
                  'গাড়ির নম্বর বা রেজিস্ট্রেশন তথ্য অসম্পূর্ণ',
                  'ভুল বা অস্তিত্বহীন স্ট্যান্ড ঠিকানা দেওয়া হয়েছে'
                ].map((reason) => (
                  <button
                    key={reason}
                    type="button"
                    onClick={() => setRejectionReasonInput(reason)}
                    className="px-2.5 py-1 text-[11px] bg-gray-100 hover:bg-red-50 text-gray-700 hover:text-red-800 rounded-lg border border-gray-200 cursor-pointer transition"
                  >
                    + {reason}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Reason Textarea */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-gray-700">বার্তা বা কারণ (বিস্তারিত):</label>
              <textarea
                rows={3}
                value={rejectionReasonInput}
                onChange={(e) => setRejectionReasonInput(e.target.value)}
                placeholder="কারণ বা করণীয় বিস্তারিত লিখুন..."
                className="w-full text-xs p-3 rounded-xl border border-gray-300 focus:border-red-500 focus:outline-none resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setRejectingDriverUser(null)}
                className="px-4 py-2 text-xs font-bold text-gray-600 hover:bg-gray-100 rounded-xl cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={() => handleRejectDriverOrBoatman(rejectingDriverUser, rejectionReasonInput)}
                className="px-4 py-2 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
              >
                <X className="w-4 h-4" />
                <span>বার্তা পাঠান ও বাতিল করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
