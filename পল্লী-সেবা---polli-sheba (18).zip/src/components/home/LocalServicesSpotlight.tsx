import React from 'react';
import { 
  ShoppingBag, 
  Car, 
  Heart, 
  Zap, 
  TrendingUp, 
  MapPin, 
  ArrowRight, 
  PhoneCall, 
  ShieldCheck, 
  Sparkles,
  Users,
  Compass,
  Moon
} from 'lucide-react';
import { ServiceCategory } from '../../types';
import { toBanglaNumber, formatTaka } from '../../utils/banglaNumbers';
import { BANGLADESH_DISTRICT_COORDINATES } from '../../data/districtCoordinates';
import { BANGLADESH_LOCATIONS } from '../../data/bangladeshLocations';

interface LocalServicesSpotlightProps {
  currentDistrict: string;
  onNavigate: (category: ServiceCategory) => void;
}

export const LocalServicesSpotlight: React.FC<LocalServicesSpotlightProps> = ({ 
  currentDistrict, 
  onNavigate 
}) => {
  const activeDistrict = currentDistrict === 'সকল জেলা' ? 'ঢাকা' : currentDistrict;

  // Retrieve existing local items count from localStorage if any
  let localHaatCount = 8;
  try {
    const savedProducts = localStorage.getItem('polli_haat_custom_products');
    if (savedProducts) {
      const parsed = JSON.parse(savedProducts);
      const matched = parsed.filter((p: any) => p.district === activeDistrict || !p.district);
      localHaatCount += matched.length;
    }
  } catch (e) {
    // fallback
  }

  let localDriversCount = 12;
  try {
    const savedDrivers = localStorage.getItem('polli_transport_drivers');
    if (savedDrivers) {
      const parsed = JSON.parse(savedDrivers);
      const matched = parsed.filter((d: any) => d.district === activeDistrict);
      localDriversCount += matched.length;
    }
  } catch (e) {
    // fallback
  }

  // Get geographic crop info
  const geoInfo = BANGLADESH_DISTRICT_COORDINATES.find(d => d.name === activeDistrict);
  const dominantCrops = geoInfo?.dominantCrops || ['ধান', 'শাকসবজি', 'আলু', 'পাট'];
  const upazilaList = BANGLADESH_LOCATIONS.find(d => d.district === activeDistrict)?.upazilas || [];

  return (
    <div className="bg-[#FAF8F5] border-2 border-[#2D5A27]/30 rounded-3xl p-4 sm:p-5 shadow-xs relative overflow-hidden">
      {/* Decorative Badge */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3.5 pb-2.5 border-b border-[#E6E0D4]">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-[#2D5A27] text-white flex items-center justify-center shadow-xs">
            <MapPin className="w-4 h-4 text-[#E8924A]" />
          </div>
          <div>
            <h3 className="font-bold text-sm sm:text-base text-[#2D5A27] font-['Noto_Sans_Bengali'] flex items-center gap-1.5">
              <span>{activeDistrict} জেলার স্থানীয় সেবা ও জরুরি হাব</span>
              <span className="text-[10px] bg-[#E8924A] text-white px-2 py-0.2 rounded-full font-semibold">
                আপনার এলাকা
              </span>
            </h3>
            <p className="text-[11px] text-gray-600">
              {activeDistrict} জেলার সকল উপজেলা, হাটবাজার, রক্তদাতা ও পরিবহন সরাসরি আপনার হাতের নাগালে
            </p>
          </div>
        </div>

        {/* Upazila count badge */}
        <div className="flex items-center gap-1.5 text-xs text-[#2D5A27] bg-[#D4E4BC]/40 px-3 py-1 rounded-xl font-semibold border border-[#2D5A27]/20">
          <Compass className="w-3.5 h-3.5 text-[#E8924A]" />
          <span>{toBanglaNumber(upazilaList.length || 5)}টি উপজেলা সংযুক্ত</span>
        </div>
      </div>

      {/* 4 Localized Priority Action Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* 1. Local Haat & Agro Listings */}
        <div 
          onClick={() => onNavigate('marketplace')}
          className="bg-white hover:bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#D4C3A3] shadow-2xs hover:shadow-xs transition cursor-pointer group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <span className="text-[10px] bg-[#2D5A27] text-white px-2 py-0.5 rounded-full font-bold">
                {toBanglaNumber(localHaatCount)}+ টি স্থানীয় পণ্য
              </span>
            </div>
            <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] group-hover:text-[#2D5A27] transition">
              {activeDistrict} পল্লী হাট ও তাজা ফসল
            </h4>
            <p className="text-[11px] text-gray-500 mt-1 line-clamp-2">
              স্থানীয় কৃষকের সরাসরি ফসল: {dominantCrops.slice(0, 3).join(', ')} ও তাজা শাকসবজি।
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-[#F0ECE1] flex items-center justify-between text-xs font-bold text-[#2D5A27]">
            <span>স্থানীয় হাট দেখুন</span>
            <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition" />
          </div>
        </div>

        {/* 2. Local Transport Drivers */}
        <div 
          onClick={() => onNavigate('transport')}
          className="bg-white hover:bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#D4C3A3] shadow-2xs hover:shadow-xs transition cursor-pointer group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-[#F9E5D4] text-[#A65E2E] flex items-center justify-center">
                <Car className="w-4 h-4" />
              </div>
              <span className="text-[10px] bg-[#A65E2E] text-white px-2 py-0.5 rounded-full font-bold">
                {toBanglaNumber(localDriversCount)}+ জন চালক
              </span>
            </div>
            <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] group-hover:text-[#A65E2E] transition">
              {activeDistrict} নিরাপদ পরিবহন
            </h4>
            <p className="text-[11px] text-gray-500 mt-1 line-clamp-2">
              অটোরিকশা, সিএনজি ও অ্যাম্বুলেন্স চালক। সেলফি ভেরিফাইড ও নাইট-রাইড সার্ভিস।
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-[#F0ECE1] flex items-center justify-between text-xs font-bold text-[#A65E2E]">
            <span>চালক খুঁজুন বা কল দিন</span>
            <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition" />
          </div>
        </div>

        {/* 3. Local Health & Blood Donors */}
        <div 
          onClick={() => onNavigate('health')}
          className="bg-white hover:bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#D4C3A3] shadow-2xs hover:shadow-xs transition cursor-pointer group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-[#FADBD8] text-[#C0392B] flex items-center justify-center">
                <Heart className="w-4 h-4" />
              </div>
              <span className="text-[10px] bg-[#C0392B] text-white px-2 py-0.5 rounded-full font-bold">
                ২৪/৭ রক্ত ও হাসপাতাল
              </span>
            </div>
            <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] group-hover:text-[#C0392B] transition">
              {activeDistrict} রক্তদাতা ও হাসপাতাল
            </h4>
            <p className="text-[11px] text-gray-500 mt-1 line-clamp-2">
              {activeDistrict} সদর হাসপাতাল, উপজেলা কমপ্লেক্স ও সরাসরি রক্তদাতাদের ফোন নম্বর।
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-[#F0ECE1] flex items-center justify-between text-xs font-bold text-[#C0392B]">
            <span>জরুরি স্বাস্থ্য সেবা</span>
            <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition" />
          </div>
        </div>

        {/* 4. Local Palli Bidyut Office */}
        <div 
          onClick={() => onNavigate('electricity')}
          className="bg-white hover:bg-[#FDFBF7] p-3.5 rounded-2xl border border-[#D4C3A3] shadow-2xs hover:shadow-xs transition cursor-pointer group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-[#FFF3CD] text-[#856404] flex items-center justify-center">
                <Zap className="w-4 h-4" />
              </div>
              <span className="text-[10px] bg-[#856404] text-white px-2 py-0.5 rounded-full font-bold">
                PBS অভিযোগ কেন্দ্র
              </span>
            </div>
            <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] group-hover:text-[#856404] transition">
              {activeDistrict} পল্লী বিদ্যুৎ সমিতি
            </h4>
            <p className="text-[11px] text-gray-500 mt-1 line-clamp-2">
              সেচ ও আবাসিক বিল হিসাব, ট্রান্সফরমার মেরামত অভিযোগ ও জরুরি লাইনম্যান নম্বর।
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-[#F0ECE1] flex items-center justify-between text-xs font-bold text-[#856404]">
            <span>বিল ও অভিযোগ ডিরেক্টরি</span>
            <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition" />
          </div>
        </div>
      </div>

      {/* Local Crop Specialization Micro-Bar */}
      <div className="mt-3 pt-2.5 border-t border-[#E6E0D4] flex flex-wrap items-center justify-between gap-2 text-xs text-gray-600">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="font-bold text-[#2D5A27] flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-[#E8924A]" />
            <span>{activeDistrict} জেলার প্রধান ফসল ও বিশেষত্ব:</span>
          </span>
          <div className="flex items-center gap-1 flex-wrap">
            {dominantCrops.map((crop, idx) => (
              <span 
                key={idx}
                className="bg-white px-2 py-0.5 rounded-md border border-[#D4C3A3] text-[11px] font-medium text-[#2D3A3A]"
              >
                {crop}
              </span>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('prayer-islamic')}
            className="text-[11px] font-bold text-[#2D5A27] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <Moon className="w-3 h-3 text-[#2D5A27]" />
            <span>{activeDistrict} জেলার নামাজের সময়</span>
          </button>
        </div>
      </div>
    </div>
  );
};
