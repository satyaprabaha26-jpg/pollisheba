import React, { useState } from 'react';
import { 
  Sprout, 
  Zap, 
  HeartPulse, 
  Landmark, 
  ShoppingBag, 
  Calculator, 
  Bot, 
  PhoneCall, 
  TrendingUp, 
  Sparkles, 
  ArrowRight,
  Beef,
  Scale,
  Building2,
  Baby,
  Search,
  Compass,
  Heart,
  Car,
  Moon,
  GraduationCap,
  Wrench,
  Users,
  Calendar,
  X,
  AlertCircle,
  Newspaper,
  ExternalLink,
  Home,
  HeartHandshake
} from 'lucide-react';
import { ServiceCategory, NavigationSubTabs } from '../../types';
import { WeatherWidget } from '../weather/WeatherWidget';
import { SevereWeatherAlertBanner } from '../weather/SevereWeatherAlertBanner';
import { LocalServicesSpotlight } from './LocalServicesSpotlight';
import { LocalEmergencyHub } from '../emergency/LocalEmergencyHub';
import { DynamicAdSection } from '../common/DynamicAdSection';
import { Prominent999Banner } from '../common/Prominent999Banner';
import { MARKET_PRICES_DATA, HOTLINES_DATA } from '../../data/mockData';
import { formatTaka } from '../../utils/banglaNumbers';
import { useLanguage } from '../../context/LanguageContext';
import { SERVICE_TRANSLATIONS } from '../../data/serviceTranslations';

interface DashboardProps {
  currentDistrict: string;
  onNavigate: (category: ServiceCategory, subTabs?: NavigationSubTabs) => void;
  onSelectDistrict?: (district: string) => void;
}

export interface QuickServiceItem {
  id: string;
  title: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  category: ServiceCategory;
  subTabs?: NavigationSubTabs;
  badge: string;
  iconBg: string;
  keywords?: string[];
}

export const ALL_QUICK_SERVICES: QuickServiceItem[] = [
  {
    id: 'rural_haat',
    title: 'পল্লী হাট ও ফসল বেচাকেনা',
    desc: 'গ্রাম, ওয়ার্ড ও উপজেলা ভিত্তিক তাজা শাকসবজি, ফলন ও সরাসরি কৃষক থেকে কেনাবেচা',
    icon: ShoppingBag,
    category: 'marketplace',
    subTabs: { market: 'products' },
    badge: '🥬 তাজা ফসল',
    iconBg: 'bg-[#D4E4BC] text-[#2D5A27]',
    keywords: ['ফসল', 'সবজি', 'শাক', 'আলু', 'পেঁয়াজ', 'ফলমূল', 'বাজার', 'হাট', 'বিক্রি', 'কেনাবেচা']
  },
  {
    id: 'rural_transport',
    title: 'নিরাপদ পরিবহন ও চালক',
    desc: 'ভেরিফাইড অটো, সিএনজি ও মোটরসাইকেল চালক কল ও নিরাপদ রাইড',
    icon: Car,
    category: 'transport',
    badge: 'NID ভেরিফাইড',
    iconBg: 'bg-[#F9E5D4] text-[#A65E2E]',
    keywords: ['পরিবহন', 'গাড়ি', 'অটো', 'সিএনজি', 'চালক', 'ড্রাইভার', 'ভাড়া', 'বাইক']
  },
  {
    id: 'agricultural_labor',
    title: 'কৃষিন ও দিনমজুর শ্রমিক বাজার',
    desc: 'ধান কাটা, জমি চাষ ও গৃহস্থালি কাজের দক্ষ শ্রমিক বা কামলা খুঁজুন',
    icon: Users,
    category: 'marketplace',
    subTabs: { market: 'labor' },
    badge: '🌾 শ্রমিক বাজার',
    iconBg: 'bg-[#FAF0E6] text-[#8B4513]',
    keywords: ['শ্রমিক', 'দিনমজুর', 'কামলা', 'কৃষিন', 'জোন', 'মজুরি', 'ধান কাটা', 'কাজের লোক']
  },
  {
    id: 'electrician_mechanic',
    title: 'ইলেকট্রিশিয়ান ও মেকানিক সেবা',
    desc: 'পল্লী বিদ্যুৎ ওয়্যারিং, পানির মোটর, ফ্রিজ, ফ্যান ও ইঞ্জিনের মিস্ত্রি',
    icon: Wrench,
    category: 'marketplace',
    subTabs: { market: 'mechanics' },
    badge: '🔧 মিস্ত্রি ও মেরামত',
    iconBg: 'bg-[#E2F1ED] text-[#0F766E]',
    keywords: ['মেকানিক', 'মিস্ত্রি', 'ইলেকট্রিশিয়ান', 'ওয়্যারিং', 'মোটর', 'পাম্প', 'ফ্রিজ', 'টিভি', 'ফ্যান', 'মেরামত']
  },
  {
    id: 'tutor_student',
    title: 'গৃহশিক্ষক ও শিক্ষার্থী সংযোগ',
    desc: '১ম-১২শ শ্রেণি ও মাদরাসার অভিজ্ঞ শিক্ষক খুঁজুন বা পড়ানোর বিজ্ঞাপন দিন',
    icon: GraduationCap,
    category: 'marketplace',
    subTabs: { market: 'tutors' },
    badge: '📚 শিক্ষক ও ছাত্র',
    iconBg: 'bg-[#D1E5F0] text-[#1B365D]',
    keywords: ['শিক্ষক', 'গৃহশিক্ষক', 'টিউশন', 'টিউলর', 'ছাত্র', 'ছাত্রী', 'পড়ানো', 'মাদরাসা', 'ইংরেজি', 'গণিত']
  },
  {
    id: 'blood_hospital',
    title: 'জরুরি রক্তদাতা ও ব্লাড ব্যাংক',
    desc: 'এ+, বি+, ও+, এবি+ রক্তের ডোনারদের তালিকা ও সরকারি ব্লাড ব্যাংক',
    icon: Heart,
    category: 'health',
    subTabs: { health: 'donors' },
    badge: 'জরুরি রক্ত',
    iconBg: 'bg-[#FADBD8] text-[#C0392B]',
    keywords: ['রক্ত', 'ব্লাড', 'রক্তদাতা', 'ডোনার', 'এ+', 'বি+', 'ও+', 'এবি+', 'ব্লাড ব্যাংক']
  },
  {
    id: 'service_finder',
    title: 'কী সেবা কোথায় কীভাবে পাবেন?',
    desc: 'কোন টেবিলে যাবেন, সরকারি ফি কত ও দালালমুক্ত সিটিজেন চার্টার',
    icon: Compass,
    category: 'service-finder',
    badge: 'দালালমুক্ত গাইড',
    iconBg: 'bg-[#D4E4BC] text-[#2D5A27]',
    keywords: ['সেবা গাইড', 'অফিস', 'কর্মকর্তা', 'টেবিল', 'দালালমুক্ত', 'কী সেবা কোথায়']
  },
  {
    id: 'prayer_islamic',
    title: 'নামাজের সময়সূচি ও সালাত',
    desc: '৬৪ জেলার ওয়াক্ত, হানাফী ও আহলে হাদিস সালাতের নিয়ম, ১০টি সূরা ও দোয়া',
    icon: Moon,
    category: 'prayer-islamic',
    badge: 'সালাত ও আমল',
    iconBg: 'bg-[#D4E4BC] text-[#2D5A27]',
    keywords: ['নামাজ', 'সালাত', 'ওয়াক্ত', 'আজান', 'সূরা', 'দোয়া', 'কিবলা', 'ইসলামিক']
  },
  {
    id: 'crop_doctor',
    title: 'ফসলের ডাক্তার ও বালাইদমন',
    desc: 'ধান, পাট, ভুট্টা ও সবজির রোগ নির্ণয়, ছবি ও কৃষিবিদ সমাধান',
    icon: Sprout,
    category: 'agriculture',
    subTabs: { agri: 'doctor' },
    badge: 'রোগ ও প্রতিকার',
    iconBg: 'bg-[#D4E4BC] text-[#2D5A27]',
    keywords: ['রোগ', 'বালাই', 'কীটনাশক', 'পোকামাকড়', 'ফসলের রোগ', 'ধানের রোগ', 'কৃষিবিদ']
  },
  {
    id: 'market_rates',
    title: 'দৈনিক কৃষি বাজারদর',
    desc: 'ধান, চাল, আলু, পেঁয়াজ, ডিম, ব্রয়লার ও সারের লাইভ পাইকারি রেট',
    icon: TrendingUp,
    category: 'agriculture',
    subTabs: { agri: 'prices' },
    badge: 'লাইভ দর',
    iconBg: 'bg-[#F9E5D4] text-[#A65E2E]',
    keywords: ['বাজারদর', 'দাম', 'রেট', 'পাইকারি', 'ধানের দাম', 'আলুর দাম', 'পেঁয়াজের দাম']
  },
  {
    id: 'power_bill',
    title: 'পল্লী বিদ্যুৎ বিল ক্যালকুলেটর',
    desc: 'আবাসিক, সেচ ও বাণিজ্যিক বিল হিসাব ও সরকারি ট্যারিফ রেট',
    icon: Zap,
    category: 'electricity',
    subTabs: { electricity: 'bill' },
    badge: 'ট্যারিফ হিসাব',
    iconBg: 'bg-[#F9E5D4] text-[#A65E2E]',
    keywords: ['বিদ্যুৎ', 'বিল', 'পল্লী বিদ্যুৎ', 'মিটার', 'ইউনিট', 'ট্যারিফ', 'সেচ বিল']
  },
  {
    id: 'power_complaint',
    title: 'বিদ্যুৎ অভিযোগ ও লোডশেডিং ট্র্যাকার',
    desc: 'বিভ্রাট, ট্রান্সফরমার বিকল ট্র্যাকিং ও অভিযোগ কেন্দ্র কন্ট্রোল রুম',
    icon: Zap,
    category: 'electricity',
    subTabs: { electricity: 'complaints' },
    badge: 'লাইভ ট্র্যাকিং',
    iconBg: 'bg-[#FADBD8] text-[#C0392B]',
    keywords: ['অভিযোগ', 'বিদ্যুৎ বিভ্রাট', 'লোডশেডিং', 'ট্রান্সফরমার', 'অভিযোগ কেন্দ্র']
  },
  {
    id: 'community_clinic',
    title: 'কমিউনিটি ক্লিনিক ও ফ্রি ওষুধ',
    desc: 'নিকটস্থ গ্রামীণ ক্লিনিক ও সরকার প্রদত্ত বিনামূল্যে ৩০ প্রকার ওষুধ',
    icon: Building2,
    category: 'health',
    subTabs: { health: 'clinics' },
    badge: 'ফ্রি ওষুধ',
    iconBg: 'bg-[#D1E5F0] text-[#2B6CB0]',
    keywords: ['ক্লিনিক', 'ওষুধ', 'ফ্রি ওষুধ', 'কমিউনিটি ক্লিনিক', 'ডাক্তার', 'স্বাস্থ্য']
  },
  {
    id: 'first_aid',
    title: 'জরুরি প্রাথমিক চিকিৎসা গাইড',
    desc: 'সাপে কাটা, পুড়ে যাওয়া, পানিতে ডোবা ও বিষক্রিয়ার তাৎক্ষণিক চিকিৎসা',
    icon: HeartPulse,
    category: 'health',
    subTabs: { health: 'firstaid' },
    badge: 'ফার্স্ট এইড',
    iconBg: 'bg-[#FADBD8] text-[#C0392B]',
    keywords: ['প্রাথমিক চিকিৎসা', 'ফার্স্ট এইড', 'সাপ', 'কাটা', 'পোড়া', 'জরুরি চিকিৎসা']
  },
  {
    id: 'emergency_hotlines',
    title: 'জরুরি জাতীয় হটলাইন ৯৯৯',
    desc: 'পুলিশ ৯৯৯, ফায়ার সার্ভিস, অ্যাম্বুলেন্স ও ২৪ ঘণ্টা জরুরি হটলাইন',
    icon: PhoneCall,
    category: 'government',
    subTabs: { gov: 'hotlines' },
    badge: 'টোল-ফ্রি ৯৯৯',
    iconBg: 'bg-[#FADBD8] text-[#C0392B]',
    keywords: ['হটলাইন', '৯৯৯', 'পুলিশ', 'ফায়ার সার্ভিস', 'অ্যাম্বুলেন্স', '১৬১২৩']
  },
  {
    id: 'legal_aid_police',
    title: 'আইন, আদালত ও সরকারি সাহায্য',
    desc: 'বিনামূল্যে সরকারি আইনি সহায়তা (১৬৪৩০), নির্বাহী আদালত, জজ কোর্ট ও থানা জিডি',
    icon: Scale,
    category: 'legal-police',
    badge: 'আইনি সহায়তা ১৬৪৩০',
    iconBg: 'bg-[#D5F5E3] text-[#1E824C]',
    keywords: ['আইন', 'আদালত', 'লিগ্যাল এইড', 'পুলিশ', 'জিডি', 'মামলা', 'জজ কোর্ট', 'ম্যাজিস্ট্রেট', '১৬৪৩০', 'সরকারি সাহায্য', 'থানা']
  },
  {
    id: 'citizen_services',
    title: 'ইউনিয়ন পরিষদ ও নাগরিক সনদ',
    desc: 'নাগরিকত্ব, ওয়ারিশান, জন্ম নিবন্ধন, নামজারি ও ইউপি ফরম',
    icon: Landmark,
    category: 'government',
    subTabs: { gov: 'services' },
    badge: 'নাগরিক সনদ',
    iconBg: 'bg-[#F9E5D4] text-[#A65E2E]',
    keywords: ['ইউনিয়ন পরিষদ', 'চেয়ারম্যান', 'নাগরিকত্ব', 'ওয়ারিশান', 'জন্ম নিবন্ধন', 'সনদ', 'ফরম']
  },
  {
    id: 'social_allowances',
    title: 'সামাজিক নিরাপত্তা ভাতা যাচাই',
    desc: 'বয়স্ক, বিধবা ও প্রতিবন্ধী ভাতা পাওয়ার সরকারি যোগ্যতা ও আবেদন',
    icon: HeartPulse,
    category: 'government',
    subTabs: { gov: 'allowances' },
    badge: 'ভাতা যোগ্যতা',
    iconBg: 'bg-[#D5F5E3] text-[#239B56]',
    keywords: ['ভাতা', 'বয়স্ক ভাতা', 'বিধবা ভাতা', 'প্রতিবন্ধী ভাতা', 'সামাজিক নিরাপত্তা']
  },
  {
    id: 'vaccine_tracker',
    title: 'শিশুর ইপিআই টিকাদান কার্ড',
    desc: '১০টি মারাত্মক রোগের টিকা শিডিউল ও ডিজিটাল টিকাদান স্মরণিকা',
    icon: Baby,
    category: 'health',
    subTabs: { health: 'vaccine' },
    badge: 'টিকাদান শিডিউল',
    iconBg: 'bg-[#E8DAEF] text-[#8E44AD]',
    keywords: ['টিকা', 'ইপিআই', 'শিশু', 'পোলিও', 'বিসিজি', 'হাম', 'টিকা কার্ড']
  },
  {
    id: 'fertilizer_calc',
    title: 'সুষম সার ক্যালকুলেটর',
    desc: 'জমির মাপ অনুযায়ী ইউরিয়া, টিএসপি, ডিএপি ও পটাশের বৈজ্ঞানিক ডোজ',
    icon: Scale,
    category: 'agriculture',
    subTabs: { agri: 'fertilizer' },
    badge: 'অনুমোদিত ডোজ',
    iconBg: 'bg-[#D5F5E3] text-[#239B56]',
    keywords: ['সার', 'ইউরিয়া', 'টিএসপি', 'ডিএপি', 'পটাশ', 'সারের হিসাব', 'জমি']
  },
  {
    id: 'crop_calendar',
    title: 'মৌসুমি ফসল ক্যালেন্ডার',
    desc: 'রবি, খরিপ-১ ও খরিপ-২ মৌসুমের উপযুক্ত ফসল ও বপন নির্দেশিকা',
    icon: Calendar,
    category: 'agriculture',
    subTabs: { agri: 'calendar' },
    badge: 'মৌসুমি চাষ',
    iconBg: 'bg-[#D4E4BC] text-[#2D5A27]',
    keywords: ['ক্যালেন্ডার', 'মৌসুম', 'রবি', 'খরিপ', 'বপন', 'রোপণ', 'ফসল চক্র']
  },
  {
    id: 'livestock_farming',
    title: 'পশুসম্পদ ও মৎস্য পালন',
    desc: 'গরুর চিকিৎসা, খুরারোগ, মুরগির টিকা ও মাছ চাষ ব্যবস্থাপনা',
    icon: Beef,
    category: 'livestock',
    badge: 'খামারি গাইড',
    iconBg: 'bg-[#F9E5D4] text-[#A65E2E]',
    keywords: ['গরু', 'ছাগল', 'মুরগি', 'পশুসম্পদ', 'ভেটেরিনারি', 'মাছ', 'পুকুর', 'খামার']
  },
  {
    id: 'land_calculator',
    title: 'আমিন ও জমি পরিমাপক',
    desc: 'শতক, কাঠা, বিঘা, একর রূপান্তর ও নিখুঁত জমি পরিমাপ',
    icon: Calculator,
    category: 'calculators',
    subTabs: { calc: 'land' },
    badge: 'নিখুঁত হিসাব',
    iconBg: 'bg-[#D1E5F0] text-[#2B6CB0]',
    keywords: ['আমিন', 'জমি', 'শতক', 'কাঠা', 'বিঘা', 'একর', 'পরিমাপ', 'হিসাব']
  },
  {
    id: 'loan_calculator',
    title: 'কৃষি ঋণ ও কিস্তি হিসাবক',
    desc: 'কৃষি ব্যাংকের সহজ শর্তের ঋণ, কিস্তি ও সুদের হিসাব ক্যালকুলেটর',
    icon: Calculator,
    category: 'calculators',
    subTabs: { calc: 'loan' },
    badge: 'ঋণ হিসাব',
    iconBg: 'bg-[#FAF0E6] text-[#8B4513]',
    keywords: ['ঋণ', 'কৃষি ঋণ', 'কিস্তি', 'ব্যাংক', 'সুদ', 'লোন']
  },
  {
    id: 'housing_rental',
    title: 'আবাসন ও বাসা ভাড়া সার্ভিস',
    desc: 'ফ্যামিলি বাসা, ব্যাচেলর মেস, সাবলেট ও দোকান ভাড়া অনুসন্ধান ও বিজ্ঞাপন',
    icon: Home,
    category: 'housing',
    badge: '🏠 বাসা ভাড়া',
    iconBg: 'bg-[#E0F2FE] text-[#0369A1]',
    keywords: ['বাসা', 'ভাড়া', 'মেস', 'রুম', 'সাবলেট', 'আবাসন', 'ফ্যামিলি', 'দোকান', 'বাড়ি']
  },
  {
    id: 'matrimony',
    title: 'পাত্র-পাত্রীর সন্ধান',
    desc: 'কঠোর গোপনীয়তা ও শতভাগ ছবিমুক্ত নিয়মে শালীন পারিবারিক মেচমেকিং',
    icon: HeartHandshake,
    category: 'matrimony',
    badge: '💍 পাত্র-পাত্রী',
    iconBg: 'bg-[#FCE7F3] text-[#BE185D]',
    keywords: ['পাত্র', 'পাত্রী', 'বিয়ে', 'বিবাহ', 'মেচমেকিং', 'বর', 'কনে', 'সন্ধান']
  }
];

export const Dashboard: React.FC<DashboardProps> = ({ currentDistrict, onNavigate, onSelectDistrict }) => {
  const { language, t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<string>('সকল');

  const featuredMarketPrices = MARKET_PRICES_DATA.slice(0, 4);
  const emergencyHotlines = HOTLINES_DATA.slice(0, 4);

  const isSearching = searchQuery.trim().length > 0;

  const getServiceGroup = (id: string): string => {
    if (['rural_haat', 'crop_doctor', 'market_rates', 'fertilizer_calc', 'crop_calendar', 'livestock_farming'].includes(id)) {
      return 'কৃষি ও হাট';
    }
    if (['housing_rental', 'matrimony'].includes(id)) {
      return 'আবাসন ও পরিবার';
    }
    if (['blood_hospital', 'community_clinic', 'vaccine_tracker', 'first_aid', 'emergency_hotlines'].includes(id)) {
      return 'স্বাস্থ্য ও জরুরি';
    }
    if (['legal_aid_police', 'citizen_services', 'social_allowances', 'service_finder'].includes(id)) {
      return 'আইন ও নাগরিক';
    }
    if (['tutor_student', 'electrician_mechanic', 'agricultural_labor', 'rural_transport'].includes(id)) {
      return 'শ্রমিক ও শিক্ষক';
    }
    return 'হিসাব ও ধর্ম';
  };

  const SERVICE_GROUPS = [
    { id: 'সকল', label: t('সকল সেবা', 'All Services'), count: ALL_QUICK_SERVICES.length },
    { id: 'কৃষি ও হাট', label: t('🌾 কৃষি ও হাট', '🌾 Agri & Haat'), count: ALL_QUICK_SERVICES.filter(s => getServiceGroup(s.id) === 'কৃষি ও হাট').length },
    { id: 'আবাসন ও পরিবার', label: t('🏠 আবাসন ও পরিবার', '🏠 Housing & Family'), count: ALL_QUICK_SERVICES.filter(s => getServiceGroup(s.id) === 'আবাসন ও পরিবার').length },
    { id: 'আইন ও নাগরিক', label: t('⚖️ আইন ও নাগরিক', '⚖️ Legal & Civil'), count: ALL_QUICK_SERVICES.filter(s => getServiceGroup(s.id) === 'আইন ও নাগরিক').length },
    { id: 'স্বাস্থ্য ও জরুরি', label: t('🩺 স্বাস্থ্য ও জরুরি', '🩺 Health & Emergency'), count: ALL_QUICK_SERVICES.filter(s => getServiceGroup(s.id) === 'স্বাস্থ্য ও জরুরি').length },
    { id: 'শ্রমিক ও শিক্ষক', label: t('👥 শ্রমিক ও শিক্ষক', '👥 Labor & Tutors'), count: ALL_QUICK_SERVICES.filter(s => getServiceGroup(s.id) === 'শ্রমিক ও শিক্ষক').length },
    { id: 'হিসাব ও ধর্ম', label: t('⚡ হিসাব ও ধর্ম', '⚡ Calc & Religion'), count: ALL_QUICK_SERVICES.filter(s => getServiceGroup(s.id) === 'হিসাব ও ধর্ম').length },
  ];

  const filteredServices = ALL_QUICK_SERVICES.filter(s => {
    if (!isSearching) return true;
    const q = searchQuery.toLowerCase().trim();
    const trans = SERVICE_TRANSLATIONS[s.id];
    const matchBn = 
      s.title.toLowerCase().includes(q) ||
      s.desc.toLowerCase().includes(q) ||
      s.badge.toLowerCase().includes(q) ||
      s.keywords?.some(k => k.toLowerCase().includes(q));

    const matchEn = trans && (
      trans.titleEn.toLowerCase().includes(q) ||
      trans.descEn.toLowerCase().includes(q) ||
      trans.badgeEn.toLowerCase().includes(q) ||
      trans.subtitleEn.toLowerCase().includes(q)
    );

    return matchBn || matchEn;
  });

  const displayedGridServices = selectedGroup === 'সকল' 
    ? ALL_QUICK_SERVICES 
    : ALL_QUICK_SERVICES.filter(s => getServiceGroup(s.id) === selectedGroup);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (filteredServices.length > 0) {
      onNavigate(filteredServices[0].category, filteredServices[0].subTabs);
    }
  };

  const handleServiceClick = (srv: QuickServiceItem) => {
    onNavigate(srv.category, srv.subTabs);
  };

  return (
    <div className="space-y-6">
      {/* Prominent Dismissible Severe Weather & Lightning Alert Banner */}
      <SevereWeatherAlertBanner district={currentDistrict} />

      {/* Search & Prompt Section */}
      <section className="bg-[#E8924A]/10 border border-[#E8924A]/25 p-6 sm:p-7 rounded-3xl shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#A65E2E] font-['Noto_Sans_Bengali']">
              {t('আপনি আজ কি খুঁজছেন?', 'What service are you looking for today?')}
            </h2>
            <p className="text-xs sm:text-sm text-[#5A6B6B] mt-0.5">
              {t(
                'শিক্ষক, মেকানিক, শ্রমিক, শস্যের রোগ, বিদ্যুৎ বিল, রক্ত বা যেকোনো সেবার নাম লিখুন',
                'Type teacher, mechanic, day laborer, crop disease, electric bill, blood donor or any service name'
              )}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs bg-white px-3 py-1.5 rounded-xl border border-[#D4C3A3] text-[#A65E2E] font-semibold shadow-2xs">
              {t('জেলা:', 'District:')} {currentDistrict}
            </span>
          </div>
        </div>

        <form onSubmit={handleSearchSubmit} className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t(
              'সেবা খুঁজুন (যেমন: শিক্ষক, মেকানিক, শ্রমিক, সার, বিদ্যুৎ বিল, রক্ত, টিকা)...',
              'Search services (e.g. tutor, mechanic, laborer, fertilizer, electricity bill, blood)...'
            )}
            className="w-full bg-white border-2 border-[#D4C3A3] rounded-2xl py-3.5 sm:py-4 pl-5 pr-28 text-sm sm:text-base text-[#2D3A3A] placeholder-[#736B5E]/60 focus:outline-none focus:border-[#2D5A27] transition-colors shadow-sm"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-24 top-1/2 -translate-y-1/2 text-[#736B5E] hover:text-[#2D3A3A] p-1 cursor-pointer"
              title={t('সার্চ মুছুন', 'Clear search')}
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button 
            type="submit"
            className="absolute right-2 top-2 sm:top-2.5 bg-[#2D5A27] hover:bg-[#23491E] text-white px-5 sm:px-6 py-2 sm:py-2 rounded-xl font-bold text-xs sm:text-sm transition-colors cursor-pointer shadow-xs"
          >
            {t('খুঁজুন', 'Search')}
          </button>
        </form>

        {/* Quick Search Chips */}
        <div className="flex items-center gap-2 pt-3 overflow-x-auto no-scrollbar text-xs">
          <span className="text-[11px] font-bold text-[#5A6B6B] whitespace-nowrap">
            {t('জনপ্রিয় সার্চ:', 'Popular Searches:')}
          </span>
          {[
            { bn: 'গৃহশিক্ষক', en: 'Home Tutor' },
            { bn: 'ইলেকট্রিশিয়ান', en: 'Electrician' },
            { bn: 'দিনমজুর শ্রমিক', en: 'Day Laborer' },
            { bn: 'সার ক্যালকুলেটর', en: 'Fertilizer' },
            { bn: 'রক্তদাতা', en: 'Blood Donor' },
            { bn: 'বিদ্যুৎ বিল', en: 'Power Bill' },
            { bn: 'নাগরিক সনদ', en: 'Citizen Certificate' }
          ].map(tag => (
            <button
              key={tag.bn}
              type="button"
              onClick={() => setSearchQuery(language === 'en' ? tag.en : tag.bn)}
              className="px-2.5 py-1 rounded-xl bg-white border border-[#D4C3A3] text-[#2D3A3A] hover:bg-[#FAF8F5] transition text-[11px] font-medium whitespace-nowrap cursor-pointer shadow-2xs"
            >
              {language === 'en' ? tag.en : tag.bn}
            </button>
          ))}
        </div>
      </section>

      {/* PRIORITY 1: SEARCH RESULTS DISPLAY FIRST WHEN USER SEARCHES */}
      {isSearching ? (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-[#2D5A27]/30 shadow-sm flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Search className="w-5 h-5 text-[#2D5A27]" />
              <div>
                <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A]">
                  {t('অনুসন্ধানের ফলাফল:', 'Search Results:')} "{searchQuery}"
                </h3>
                <p className="text-xs text-[#5A6B6B]">
                  {filteredServices.length} {t('টি প্রাসঙ্গিক সেবা পাওয়া গেছে', 'relevant services found')}
                </p>
              </div>
            </div>
            <button
              onClick={() => setSearchQuery('')}
              className="flex items-center gap-1 text-xs font-bold text-[#C0392B] bg-[#FADBD8]/40 hover:bg-[#FADBD8] px-3 py-1.5 rounded-xl transition cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>{t('সার্চ বন্ধ করুন', 'Close Search')}</span>
            </button>
          </div>

          {filteredServices.length === 0 ? (
            <div className="bg-white p-8 sm:p-12 rounded-3xl border border-[#E6E0D4] text-center space-y-4 shadow-2xs">
              <div className="w-14 h-14 bg-[#FAF8F5] rounded-full flex items-center justify-center mx-auto text-[#E8924A] border border-[#E6E0D4]">
                <AlertCircle className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-base sm:text-lg text-[#2D3A3A]">
                  {t(`"${searchQuery}" সম্পর্কিত কোনো সরাসরি সেবা পাওয়া যায়নি`, `No direct services found for "${searchQuery}"`)}
                </h4>
                <p className="text-xs sm:text-sm text-[#5A6B6B] max-w-lg mx-auto leading-relaxed">
                  {t(
                    'দয়া করে সঠিক বানান লিখুন অথবা নিচের সাহায্যকারী অপশনগুলো ব্যবহার করুন। আপনি কি কোনো শিক্ষক, শ্রমিক, মেকানিক বা কৃষি পরামর্শ খুঁজছেন?',
                    'Please check your spelling or browse the quick options below. Are you looking for a tutor, laborer, mechanic or crop advisory?'
                  )}
                </p>
              </div>

              {/* Action suggestions when search doesn't match */}
              <div className="pt-2 flex flex-wrap justify-center items-center gap-2.5">
                <button
                  onClick={() => onNavigate('marketplace', { market: 'tutors' })}
                  className="px-4 py-2 bg-[#1B365D] hover:bg-[#132742] text-white text-xs font-bold rounded-2xl shadow-xs transition cursor-pointer"
                >
                  {t('📚 গৃহশিক্ষক ও শিক্ষার্থী', '📚 Home Tutors & Students')}
                </button>
                <button
                  onClick={() => onNavigate('marketplace', { market: 'mechanics' })}
                  className="px-4 py-2 bg-[#0F766E] hover:bg-[#0d615b] text-white text-xs font-bold rounded-2xl shadow-xs transition cursor-pointer"
                >
                  {t('🔧 মেকানিক ও মিস্ত্রি', '🔧 Mechanics & Technicians')}
                </button>
                <button
                  onClick={() => onNavigate('marketplace', { market: 'products' })}
                  className="px-4 py-2 bg-[#E8924A] hover:bg-[#D97D35] text-white text-xs font-bold rounded-2xl shadow-xs transition cursor-pointer"
                >
                  {t('🥬 পল্লী হাট ও ফসল', '🥬 Rural Haat & Produce')}
                </button>
                <button
                  onClick={() => onNavigate('ai-advisor')}
                  className="px-4 py-2 bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold rounded-2xl shadow-xs transition cursor-pointer"
                >
                  {t('🤖 এআই পল্লী পরামর্শক', '🤖 AI Rural Advisor')}
                </button>
                <button
                  onClick={() => setSearchQuery('')}
                  className="px-4 py-2 bg-[#FAF8F5] border border-[#D4C3A3] text-[#2D3A3A] hover:bg-[#E6E0D4] text-xs font-bold rounded-2xl transition cursor-pointer"
                >
                  {t('🔄 সকল ২৬টি সেবা দেখুন', '🔄 View All 26 Services')}
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredServices.map((srv) => {
                  const IconComponent = srv.icon;
                  const trans = SERVICE_TRANSLATIONS[srv.id];
                  const title = language === 'en' && trans ? trans.titleEn : srv.title;
                  const desc = language === 'en' && trans ? trans.descEn : srv.desc;
                  const badge = language === 'en' && trans ? trans.badgeEn : srv.badge;

                  return (
                    <div
                      key={srv.id}
                      onClick={() => handleServiceClick(srv)}
                      className="bg-white p-5 rounded-3xl shadow-sm border border-[#2D5A27]/20 hover:border-[#2D5A27] hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-3">
                          <div className={`w-13 h-13 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-105 ${srv.iconBg}`}>
                            <IconComponent className="w-6 h-6" />
                          </div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FAF8F5] border border-[#E6E0D4] text-[#736B5E]">
                            {badge}
                          </span>
                        </div>

                        <h4 className="font-bold text-sm sm:text-base text-[#2D3A3A] group-hover:text-[#2D5A27] transition-colors leading-snug">
                          {title}
                        </h4>

                        <p className="text-xs text-[#5A6B6B] mt-1.5 leading-relaxed">
                          {desc}
                        </p>
                      </div>

                      <div className="mt-4 pt-2.5 border-t border-[#E6E0D4]/60 flex items-center justify-between text-xs font-bold text-[#2D5A27]">
                        <span>{t('সরাসরি প্রবেশ করুন', 'Enter Directly')}</span>
                        <ArrowRight className="w-3.5 h-3.5 transform transition-transform group-hover:translate-x-1" />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Other Services suggestion below search results */}
              <div className="bg-white p-5 rounded-3xl border border-[#E6E0D4] shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A]">
                    {t('অন্যান্য প্রধান গ্রামীণ সেবাসমূহ', 'Other Essential Rural Services')}
                  </h4>
                  <button
                    onClick={() => setSearchQuery('')}
                    className="text-xs font-bold text-[#2D5A27] hover:underline cursor-pointer"
                  >
                    {t('সকল সেবা দেখুন', 'View All Services')}
                  </button>
                </div>
                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
                  {ALL_QUICK_SERVICES.filter(s => !filteredServices.some(f => f.id === s.id)).slice(0, 6).map((srv) => {
                    const trans = SERVICE_TRANSLATIONS[srv.id];
                    const title = language === 'en' && trans ? trans.titleEn : srv.title;
                    return (
                      <button
                        key={srv.id}
                        onClick={() => handleServiceClick(srv)}
                        className="px-3 py-2 rounded-2xl bg-[#FDFBF7] border border-[#E6E0D4] hover:border-[#2D5A27] text-xs font-medium text-[#2D3A3A] whitespace-nowrap transition cursor-pointer flex items-center gap-2 shadow-2xs shrink-0"
                      >
                        <span className="w-2 h-2 rounded-full bg-[#2D5A27]" />
                        <span>{title}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* STANDARD HOME SCREEN (WHEN NOT SEARCHING) */
        <>
          {/* Weather & Agricultural Advisory Row */}
          <WeatherWidget district={currentDistrict} onDistrictChange={onSelectDistrict} />

          {/* Dynamic 3D / Video Sponsored Ad Banner */}
          <DynamicAdSection placement="home_weather_bottom" district={currentDistrict} />

          {/* Local Services & Emergency Spotlight for Current District */}
          <LocalServicesSpotlight 
            currentDistrict={currentDistrict} 
            onNavigate={(cat) => onNavigate(cat)} 
          />

          {/* Featured Haat & Fresh Vegetables Spotlight */}
          <div className="bg-gradient-to-r from-[#2D5A27] to-[#1E3F1A] text-white rounded-3xl p-5 sm:p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="bg-[#D4E4BC] text-[#2D5A27] font-bold text-[11px] px-3 py-0.5 rounded-full inline-flex items-center gap-1">
                  <span>🥬 {t('তাজা শাকসবজি ও গ্রামীণ হাট', 'Fresh Vegetables & Rural Haat')}</span>
                </span>
                <span className="bg-white/20 text-white text-[11px] font-semibold px-2.5 py-0.5 rounded-full">
                  ⚡ {t('মধ্যস্বত্বভোগী ছাড়া সরাসরি কৃষক থেকে ভোক্তা', 'Direct farmer-to-consumer without middlemen')}
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold font-['Noto_Sans_Bengali']">
                {t('পল্লী হাট: আপনার গ্রামের টাটকা শাকসবজি ও ফলন', 'Polli Haat: Your Village Fresh Crops & Vegetables')}
              </h3>
              <p className="text-[#D4E4BC] text-xs sm:text-sm max-w-2xl leading-relaxed">
                {t(
                  'জেলা, উপজেলা, ইউনিয়ন ও গ্রাম-পাড়া অনুযায়ী জমি থেকে সরাসরি তোলা শাকসবজি, শিক্ষক ও মেকানিক সেবা সরাসরি যোগাযোগ করে নিন।',
                  'Connect directly with local farmers for farm-fresh produce, hire neighborhood tutors, and call emergency mechanics.'
                )}
              </p>
            </div>

            <button
              onClick={() => onNavigate('marketplace', { market: 'products' })}
              className="flex items-center gap-2 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold px-5 py-3 rounded-2xl text-xs sm:text-sm shadow-md transition self-start md:self-auto cursor-pointer whitespace-nowrap shrink-0"
            >
              <span>{t('হাটে প্রবেশ করুন ও বিজ্ঞাপন দিন', 'Enter Haat & Post Listing')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Local Emergency Services Hub (Police & Fire Station) */}
          <LocalEmergencyHub
            initialDistrict={currentDistrict && currentDistrict !== 'সকল জেলা' ? currentDistrict : 'পটুয়াখালী'}
            onDistrictChange={(dist) => {
              if (onSelectDistrict) onSelectDistrict(dist);
            }}
          />

          {/* Prominent Emergency 999 National Service Banner */}
          <Prominent999Banner />

          {/* Emergency Hotlines Strip */}
          <div className="bg-white border border-[#E6E0D4] rounded-3xl p-5 shadow-xs">
            <div className="flex items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <PhoneCall className="w-4 h-4 text-[#C0392B]" />
                <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A]">
                  {t('জরুরি জাতীয় ও গ্রামীণ হটলাইন ডিরেক্টরি', 'National & Rural Emergency Hotlines Directory')}
                </h3>
              </div>
              <button
                onClick={() => onNavigate('government', { gov: 'hotlines' })}
                className="text-xs font-bold text-[#2D5A27] hover:text-[#23491E] flex items-center gap-1 cursor-pointer"
              >
                <span>{t('সব দেখুন', 'View All')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {emergencyHotlines.map((hl) => (
                <a
                  key={hl.id}
                  href={`tel:${hl.number}`}
                  className="bg-[#FDFBF7] hover:bg-[#FADBD8]/40 border border-[#E6E0D4] hover:border-[#FADBD8] p-3.5 rounded-2xl transition flex items-center gap-3 group shadow-2xs"
                >
                  <span className="w-10 h-10 rounded-xl bg-[#FADBD8] text-[#C0392B] font-extrabold text-base flex items-center justify-center font-['Noto_Sans_Bengali'] group-hover:bg-[#C0392B] group-hover:text-white transition">
                    {hl.shortCode}
                  </span>
                  <div>
                    <h4 className="font-bold text-xs text-[#2D3A3A] group-hover:text-[#C0392B] leading-tight">
                      {hl.name.split('(')[0]}
                    </h4>
                    <span className="text-[11px] text-[#736B5E] block">
                      {hl.isFree ? t('টোল-ফ্রি', 'Toll-Free') : t('সরাসরি কল', 'Direct Call')}
                    </span>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* All 25 Digital Services Grid: Reorganized with Intuitive Category Filter Bar */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="font-bold text-base sm:text-lg text-[#2D3A3A]">
                  {t('সকল গ্রামীণ ডিজিটাল সেবাসমূহ', 'All Rural Digital Services')}
                </h3>
                <p className="text-xs text-[#736B5E]">
                  {t('সহজে খুঁজে পাওয়ার জন্য ক্যাটাগরি ভিত্তিক সুবিন্যস্ত তালিকা', 'Category-organized directory for effortless service discovery')}
                </p>
              </div>
              <span className="text-xs font-semibold px-3 py-1 bg-[#D4E4BC] text-[#2D5A27] rounded-full self-start sm:self-auto">
                {displayedGridServices.length} {t('টি সেবা প্রদর্শিত', 'services shown')}
              </span>
            </div>

            {/* Intuitive Category Filter Chips for Effortless Discovery */}
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
              {SERVICE_GROUPS.map((grp) => {
                const isActive = selectedGroup === grp.id;
                return (
                  <button
                    key={grp.id}
                    type="button"
                    onClick={() => setSelectedGroup(grp.id)}
                    className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 shadow-2xs ${
                      isActive
                        ? 'bg-[#2D5A27] text-white shadow-sm ring-2 ring-[#2D5A27]/30'
                        : 'bg-white border border-[#E6E0D4] text-[#2D3A3A] hover:border-[#2D5A27] hover:bg-[#FAF8F5]'
                    }`}
                  >
                    <span>{grp.label}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                      isActive ? 'bg-white/20 text-white' : 'bg-[#FAF8F5] text-[#736B5E]'
                    }`}>
                      {grp.count}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {displayedGridServices.map((srv) => {
                const IconComponent = srv.icon;
                const trans = SERVICE_TRANSLATIONS[srv.id];
                const title = language === 'en' && trans ? trans.titleEn : srv.title;
                const desc = language === 'en' && trans ? trans.descEn : srv.desc;
                const badge = language === 'en' && trans ? trans.badgeEn : srv.badge;

                return (
                  <div
                    key={srv.id}
                    onClick={() => handleServiceClick(srv)}
                    className="bg-white p-5 rounded-3xl shadow-sm border border-[#E6E0D4] hover:border-[#2D5A27] hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-3">
                        <div className={`w-13 h-13 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-105 ${srv.iconBg}`}>
                          <IconComponent className="w-6 h-6" />
                        </div>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FDFBF7] border border-[#E6E0D4] text-[#736B5E]">
                          {badge}
                        </span>
                      </div>

                      <h4 className="font-bold text-sm sm:text-base text-[#2D3A3A] group-hover:text-[#2D5A27] transition-colors leading-snug">
                        {title}
                      </h4>

                      <p className="text-xs text-[#5A6B6B] mt-1.5 leading-relaxed line-clamp-2">
                        {desc}
                      </p>
                    </div>

                    <div className="mt-4 pt-2.5 border-t border-[#E6E0D4]/60 flex items-center justify-between text-xs font-bold text-[#2D5A27]">
                      <span>{t('সেবা গ্রহণ করুন', 'Enter Service')}</span>
                      <ArrowRight className="w-3.5 h-3.5 transform transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Featured Market Price Snapshot */}
          <div className="bg-white rounded-3xl border border-[#E6E0D4] shadow-sm overflow-hidden flex flex-col">
            <div className="bg-[#2D5A27] text-white p-4 font-bold flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-[#D4E4BC]" />
                <span>{t('বাজারের বর্তমান দর', 'Current Market Prices')} ({currentDistrict})</span>
              </div>
              <button
                onClick={() => onNavigate('agriculture', { agri: 'prices' })}
                className="text-xs font-bold bg-[#3D7A35] hover:bg-[#4E9344] text-[#D4E4BC] px-3 py-1 rounded-xl transition cursor-pointer"
              >
                {t('সম্পূর্ণ তালিকা', 'Full Price List')}
              </button>
            </div>

            <div className="p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              {featuredMarketPrices.map((item) => (
                <div key={item.id} className="p-3.5 bg-[#FDFBF7] rounded-2xl border border-[#E6E0D4] flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-semibold text-[#5A6B6B] block truncate">
                      {item.name}
                    </span>
                    <p className="text-xl font-bold text-[#2D5A27] font-['Noto_Sans_Bengali'] mt-1">
                      {formatTaka(item.retailPrice)}
                      <span className="text-xs font-normal text-[#736B5E]"> / {item.unit}</span>
                    </p>
                  </div>
                  <span className="text-[11px] text-[#736B5E] block mt-1.5 pt-1.5 border-t border-[#E6E0D4]/70">
                    {t('পাইকারি:', 'Wholesale:')} {formatTaka(item.wholesalePrice)}
                  </span>
                </div>
              ))}
            </div>

            <div className="p-3 bg-[#FDFBF7] border-t border-[#E6E0D4] text-[11px] text-center text-[#736B5E] italic">
              {t(
                'বাজারদর প্রতিদিন স্থানীয় কৃষি কর্মকর্তা ও আড়ত থেকে হালনাগাদ করা হয়',
                'Prices are updated daily from local agricultural offices and wholesale markets'
              )}
            </div>
          </div>

          {/* Satya Prabaha News Portal - Footer Clean Dedicated Card */}
          <div className="bg-white rounded-3xl p-4 sm:p-5 border border-[#E6E0D4] shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3.5 text-center sm:text-left">
              <div className="w-11 h-11 rounded-2xl bg-[#FAF8F5] border border-[#D4C3A3] flex items-center justify-center text-[#E8924A] shrink-0 shadow-2xs">
                <Newspaper className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm sm:text-base text-[#2D3A3A] font-['Noto_Sans_Bengali'] flex items-center gap-1.5 flex-wrap">
                  <span>{t('সত্য ও বস্তুনিষ্ঠ সংবাদ পেতে,', 'For true and objective news,')}</span>
                  <span className="bg-[#15803D] text-white px-2 py-0.5 rounded-lg text-xs sm:text-sm font-bold animate-pulse shadow-2xs">
                    {t('সত্য প্রবাহ', 'Satya Prabaha')}
                  </span>
                  <span>{t('এ ক্লিক করুন', 'click here')}</span>
                </h4>
                <p className="text-xs text-[#5A6B6B] mt-0.5">
                  {t(
                    'নিরপেক্ষ গ্রামীণ ও জাতীয় সত্য সংবাদের অনলাইন প্ল্যাটফর্ম (satyaprabaha.wordpress.com)',
                    'Neutral rural and national news online platform (satyaprabaha.wordpress.com)'
                  )}
                </p>
              </div>
            </div>

            <a
              href="https://satyaprabaha.wordpress.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#15803D] hover:bg-[#166534] text-white text-xs sm:text-sm font-bold px-5 py-2.5 rounded-2xl shadow-sm transition cursor-pointer shrink-0 animate-pulse border border-[#22C55E]/60"
              title="সত্য ও বস্তুনিষ্ঠ সংবাদ পেতে ভিজিট করুন সত্য প্রবাহ"
            >
              <span>{t('সত্য প্রবাহ সংবাদ পড়ুন', 'Read Satya Prabaha News')}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </>
      )}
    </div>
  );
};
