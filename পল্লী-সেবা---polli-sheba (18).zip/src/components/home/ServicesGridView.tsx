import React, { useState } from 'react';
import { 
  Sprout, 
  Zap, 
  HeartPulse, 
  Landmark, 
  ShoppingBag, 
  Calculator, 
  Bot, 
  TrendingUp, 
  Sparkles, 
  ArrowRight, 
  Beef, 
  Scale, 
  Building2, 
  Baby, 
  Search, 
  Compass, 
  Heart, 
  Car, 
  Moon,
  Filter,
  ShieldCheck,
  GraduationCap,
  Wrench,
  Users,
  Calendar,
  PhoneCall,
  AlertCircle,
  X,
  Home,
  HeartHandshake
} from 'lucide-react';
import { ServiceCategory, NavigationSubTabs } from '../../types';
import { useLanguage } from '../../context/LanguageContext';
import { SERVICE_TRANSLATIONS } from '../../data/serviceTranslations';

interface ServicesGridViewProps {
  onSelectService: (category: ServiceCategory, subTabs?: NavigationSubTabs) => void;
  currentDistrict: string;
}

export interface ServiceGridItem {
  id: string;
  title: string;
  subtitle: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  category: ServiceCategory;
  subTabs?: NavigationSubTabs;
  badge: string;
  iconBg: string;
  group: string;
}

export const ALL_EXPANDED_SERVICES: ServiceGridItem[] = [
  {
    id: 'rural_haat',
    title: '১. পল্লী হাট ও তরিতরকারি',
    subtitle: 'টাটকা শাকসবজি ও গ্রামীণ বাজার',
    desc: 'গ্রাম, ওয়ার্ড ও উপজেলা ভিত্তিক তাজা শাকসবজি, ফলন ও সরাসরি কৃষক থেকে কেনাবেচা।',
    icon: ShoppingBag,
    category: 'marketplace',
    subTabs: { market: 'products' },
    badge: '🥬 টাটকা পণ্য',
    iconBg: 'bg-[#D4E4BC] text-[#2D5A27]',
    group: 'কৃষি ও হাট'
  },
  {
    id: 'rural_transport',
    title: '২. পল্লী পরিবহন ও নিরাপদ চালক',
    subtitle: 'অটো, সিএনজি, বাইক ও ট্রিপ',
    desc: 'ভেরিফাইড চালকদের তালিকা, সরাসরি সুরক্ষিত অডিও কল, নিরাপদ ট্রিপ বুকিং ও নাইট রাইড।',
    icon: Car,
    category: 'transport',
    badge: 'সুরক্ষিত কল',
    iconBg: 'bg-[#F9E5D4] text-[#A65E2E]',
    group: 'যোগাযোগ ও পরিবহন'
  },
  {
    id: 'agricultural_labor',
    title: '৩. কৃষি শ্রমিক বা দিনমজুর',
    subtitle: 'কামলা, জোন ও খামার শ্রমিক বাজার',
    desc: 'মৌসুমি ধান কাটা, জমি চাষ ও গৃহস্থালি কাজের জন্য দক্ষ কৃষিন বা শ্রমিক দল সরাসরি যোগাযোগ করুন।',
    icon: Users,
    category: 'marketplace',
    subTabs: { market: 'labor' },
    badge: '🌾 শ্রমিক বাজার',
    iconBg: 'bg-[#FAF0E6] text-[#8B4513]',
    group: 'কৃষি ও হাট'
  },
  {
    id: 'electrician_mechanic',
    title: '৪. ইলেকট্রিশিয়ান ও মেকার',
    subtitle: 'ওয়্যারিং, মোটর ও জরুরি মেরামত',
    desc: 'পল্লী বিদ্যুৎ ওয়্যারিং, পানির পাম্প মোটর, ফ্রিজ, টিভি, ফ্যান ও শ্যালো ইঞ্জিনের দক্ষ মেকার ও মেকানিক।',
    icon: Wrench,
    category: 'marketplace',
    subTabs: { market: 'mechanics' },
    badge: '🔧 মেকার ও মেকানিক',
    iconBg: 'bg-[#E2F1ED] text-[#0F766E]',
    group: 'শিক্ষা ও কারিগর'
  },
  {
    id: 'tutor_student',
    title: '৫. গৃহ শিক্ষক',
    subtitle: 'শিক্ষক ও শিক্ষার্থী সংযোগ',
    desc: '১ম থেকে ১২শ শ্রেণি ও মাদরাসার অভিজ্ঞ শিক্ষক খুঁজুন কিংবা শিক্ষক হিসেবে পড়ানোর বিজ্ঞাপন দিন।',
    icon: GraduationCap,
    category: 'marketplace',
    subTabs: { market: 'tutors' },
    badge: '📚 গৃহ শিক্ষক',
    iconBg: 'bg-[#D1E5F0] text-[#1B365D]',
    group: 'শিক্ষা ও কারিগর'
  },
  {
    id: 'blood_hospital',
    title: '৬. জরুরি রক্তদাতা ও ব্লাড ব্যাংক',
    subtitle: 'এ+, বি+, ও+, এবি+ রক্তের ডোনার',
    desc: 'উপজেলা ও ইউনিয়ন ভিত্তিক স্বেচ্ছাসেবী রক্তদাতাদের তালিকা ও সরকারি ব্লাড ব্যাংক অনুসন্ধান।',
    icon: Heart,
    category: 'health',
    subTabs: { health: 'donors' },
    badge: 'জরুরি রক্ত',
    iconBg: 'bg-[#FADBD8] text-[#C0392B]',
    group: 'স্বাস্থ্য ও চিকিৎসা'
  },
  {
    id: 'service_finder',
    title: '৭. কী সেবা কোথায় কীভাবে পাবেন',
    subtitle: 'সরকারি অফিস ও ওয়ান-স্টপ গাইড',
    desc: 'কোন টেবিলে যাবেন, কোন কর্মকর্তার কাছে যেতে হবে, সরকারি ফি কত ও দালালমুক্ত গাইড।',
    icon: Compass,
    category: 'service-finder',
    badge: 'দালালমুক্ত গাইড',
    iconBg: 'bg-[#D4E4BC] text-[#2D5A27]',
    group: 'সরকারি ও নাগরিক'
  },
  {
    id: 'prayer_islamic',
    title: '৮. নামাজের সময়সূচি, সালাত ও সূরা',
    subtitle: 'ওয়াক্ত, সালাতের নিয়ম, ১০টি সূরা ও দোয়া',
    desc: '৬৪ জেলার ওয়াক্ত, হানাফী ও আহলে হাদিস সালাতের নিয়ম, তাশাহহুদ, দরূদ, মাসূরা, কুনূত ও ১০টি ছোট সূরা।',
    icon: Moon,
    category: 'prayer-islamic',
    badge: 'সালাত ও আমল',
    iconBg: 'bg-[#D4E4BC] text-[#2D5A27]',
    group: 'ধর্মীয় সেবা'
  },
  {
    id: 'crop_doctor',
    title: '৯. ফসলের ডাক্তার ও শস্য পরামর্শ',
    subtitle: 'রোগবালাই নির্ণয় ও নিরাময়',
    desc: 'ধান, পাট, ভুট্টা, সবজি ইত্যাদির ছবিযুক্ত রোগবালাই তথ্য, সমাধান ও কৃষি অফিসারের পরামর্শ।',
    icon: Sprout,
    category: 'agriculture',
    subTabs: { agri: 'doctor' },
    badge: 'কৃষি ও ফসল',
    iconBg: 'bg-[#D4E4BC] text-[#2D5A27]',
    group: 'কৃষি ও হাট'
  },
  {
    id: 'market_rates',
    title: '১০. দৈনিক কৃষি বাজারদর',
    subtitle: 'আড়ত ও পাইকারি লাইভ মূল্য',
    desc: 'ধান, চাল, আলু, পেঁয়াজ, ডিম, মুরগি ও সারের দৈনিক পাইকারি ও খুচরা সরকারি রেট।',
    icon: TrendingUp,
    category: 'agriculture',
    subTabs: { agri: 'prices' },
    badge: 'লাইভ দর',
    iconBg: 'bg-[#F9E5D4] text-[#A65E2E]',
    group: 'কৃষি ও হাট'
  },
  {
    id: 'power_bill',
    title: '১১. পল্লী বিদ্যুৎ বিল ক্যালকুলেটর',
    subtitle: 'আবাসিক, সেচ ও বাণিজ্যিক বিল হিসাব',
    desc: 'পল্লী বিদ্যুৎ সমিতির অনুমোদিত সরকারি ট্যারিফ রেটে নির্ভুল বিদ্যুৎ বিল নির্ণয় ও স্ল্যাব হিসাব।',
    icon: Zap,
    category: 'electricity',
    subTabs: { electricity: 'bill' },
    badge: 'বিদ্যুৎ বিল হিসাব',
    iconBg: 'bg-[#F9E5D4] text-[#A65E2E]',
    group: 'বিদ্যুৎ সেবা'
  },
  {
    id: 'power_complaint',
    title: '১২. বিদ্যুৎ অভিযোগ ও লোডশেডিং ট্র্যাকার',
    subtitle: 'বিভ্রাট ও ট্রান্সফরমার বিকল ট্র্যাকিং',
    desc: 'বিদ্যুৎ লাইন সমস্যা, ট্রান্সফরমার নষ্ট বা বিভ্রাটে কন্ট্রোল রুমে সরাসরি অভিযোগ দাখিল ও ট্র্যাকিং।',
    icon: Zap,
    category: 'electricity',
    subTabs: { electricity: 'complaints' },
    badge: 'অভিযোগ ট্র্যাকিং',
    iconBg: 'bg-[#FADBD8] text-[#C0392B]',
    group: 'বিদ্যুৎ সেবা'
  },
  {
    id: 'community_clinic',
    title: '১৩. কমিউনিটি ক্লিনিক ও ফ্রি ওষুধ',
    subtitle: 'নিকটস্থ ক্লিনিক ও ৩০ প্রকার ওষুধ',
    desc: 'গ্রামের কমিউনিটি ক্লিনিক থেকে বিনামূল্যে সরকার প্রদত্ত ৩০ প্রকার জরুরি ওষুধ ও স্বাস্থ্যসেবা।',
    icon: Building2,
    category: 'health',
    subTabs: { health: 'clinics' },
    badge: 'ফ্রি ওষুধ',
    iconBg: 'bg-[#D1E5F0] text-[#2B6CB0]',
    group: 'স্বাস্থ্য ও চিকিৎসা'
  },
  {
    id: 'first_aid',
    title: '১৪. জরুরি প্রাথমিক চিকিৎসা গাইড',
    subtitle: 'সাপে কাটা, পোড়া ও তাৎক্ষণিক যত্ন',
    desc: 'সাপে কাটা, আগুনে পোড়া, পানিতে ডোবা ও কীটনাশক বিষক্রিয়ায় হাসপাতালে নেওয়ার আগের প্রাথমিক যত্ন।',
    icon: HeartPulse,
    category: 'health',
    subTabs: { health: 'firstaid' },
    badge: 'ফার্স্ট এইড',
    iconBg: 'bg-[#FADBD8] text-[#C0392B]',
    group: 'স্বাস্থ্য ও চিকিৎসা'
  },
  {
    id: 'emergency_hotlines',
    title: '১৫. জরুরি জাতীয় হটলাইন ৯৯৯',
    subtitle: 'টোল-ফ্রি পুলিশ, ফায়ার ও অ্যাম্বুলেন্স',
    desc: 'জাতীয় জরুরি কল সেন্টার ৯৯৯, ৩৩৩, নারী ও শিশু নির্যাতন ১০৯ এবং শ্রম কল সেন্টার।',
    icon: PhoneCall,
    category: 'government',
    subTabs: { gov: 'hotlines' },
    badge: 'টোল-ফ্রি ৯৯৯',
    iconBg: 'bg-[#FADBD8] text-[#C0392B]',
    group: 'সরকারি ও নাগরিক'
  },
  {
    id: 'legal_aid_police',
    title: '১৬. আইন, আদালত ও সরকারি সাহায্য',
    subtitle: 'লিগ্যাল এইড ১৬৪৩০, কোর্ট ও থানা জিডি',
    desc: 'বিনামূল্যে সরকারি আইনি সহায়তা (১৬৪৩০), নির্বাহী আদালত, জজ কোর্ট দেওয়ানি/ফৌজদারি এবং থানা জিডি বা মামলা করার পূর্ণাঙ্গ গাইড।',
    icon: Scale,
    category: 'legal-police',
    badge: 'লিগ্যাল এইড ১৬৪৩০',
    iconBg: 'bg-[#D5F5E3] text-[#1E824C]',
    group: 'সরকারি ও নাগরিক'
  },
  {
    id: 'citizen_services',
    title: '১৭. ইউনিয়ন পরিষদ ও নাগরিক সনদ',
    subtitle: 'নাগরিকত্ব, ওয়ারিশান ও জন্মনিবন্ধন',
    desc: 'ইউপি চেয়ারম্যান সনদ, ট্রেড লাইসেন্স ও অনলাইন প্রত্যয়নপত্রের নির্দেশিকা।',
    icon: Landmark,
    category: 'government',
    subTabs: { gov: 'services' },
    badge: 'ইউপি সেবা',
    iconBg: 'bg-[#F9E5D4] text-[#A65E2E]',
    group: 'সরকারি ও নাগরিক'
  },
  {
    id: 'social_allowances',
    title: '১৮. সামাজিক নিরাপত্তা ভাতা যাচাই',
    subtitle: 'বয়স্ক, বিধবা ও প্রতিবন্ধী ভাতা',
    desc: 'ভাতা পাওয়ার সরকারি শর্তাবলী, প্রয়োজনীয় কাগজপত্র ও অনলাইন আবেদন যাচাই।',
    icon: HeartPulse,
    category: 'government',
    subTabs: { gov: 'allowances' },
    badge: 'ভাতা নির্দেশিকা',
    iconBg: 'bg-[#D5F5E3] text-[#239B56]',
    group: 'সরকারি ও নাগরিক'
  },
  {
    id: 'vaccine_tracker',
    title: '১৯. শিশুর ইপিআই টিকাদান কার্ড',
    subtitle: '১০টি মারাত্মক রোগের টিকা শিডিউল',
    desc: 'বিসিজি, পোলিও, হাম, রুবেলাসহ শিশুদের ১০টি মারাত্মক রোগের সরকারি টিকা শিডিউল ও কার্ড।',
    icon: Baby,
    category: 'health',
    subTabs: { health: 'vaccine' },
    badge: 'টিকা কার্ড',
    iconBg: 'bg-[#E8DAEF] text-[#8E44AD]',
    group: 'স্বাস্থ্য ও চিকিৎসা'
  },
  {
    id: 'fertilizer_calc',
    title: '২০. সুষম সার ক্যালকুলেটর',
    subtitle: 'ইউরিয়া, টিএসপি, ডিএপি হিসাব',
    desc: 'জমির শতাংশ বা বিঘা অনুযায়ী সরকারি কৃষি গবেষণা অনুযায়ী সুষম সারের মাত্রা হিসাব।',
    icon: Scale,
    category: 'agriculture',
    subTabs: { agri: 'fertilizer' },
    badge: 'অনুমোদিত ডোজ',
    iconBg: 'bg-[#D5F5E3] text-[#239B56]',
    group: 'কৃষি ও হাট'
  },
  {
    id: 'crop_calendar',
    title: '২১. মৌসুমি ফসল ও চাষাবাদ ক্যালেন্ডার',
    subtitle: 'রবি, খরিপ-১ ও খরিপ-২ সময়সূচি',
    desc: 'কোন মাসে কোন ফসল চাষ করবেন, বীজতলা তৈরি ও ফলন তোলার ১২ মাসের কৃষি পঞ্জিকা।',
    icon: Calendar,
    category: 'agriculture',
    subTabs: { agri: 'calendar' },
    badge: 'চাষ পঞ্জিকা',
    iconBg: 'bg-[#D4E4BC] text-[#2D5A27]',
    group: 'কৃষি ও হাট'
  },
  {
    id: 'livestock_farming',
    title: '২২. পশুসম্পদ ও মৎস্য পালন',
    subtitle: 'গরু মোটাতাজাকরণ, মুরগি ও মাছের যত্ন',
    desc: 'খুরারোগ, রানীক্ষেত ও মাছের রোগবালাই প্রতিকার এবং পুষ্টিকর খাবারের তালিকা।',
    icon: Beef,
    category: 'livestock',
    badge: 'খামারি গাইড',
    iconBg: 'bg-[#F9E5D4] text-[#A65E2E]',
    group: 'কৃষি ও হাট'
  },
  {
    id: 'land_calculator',
    title: '২৩. আমিন ও জমি পরিমাপক ক্যালকুলেটর',
    subtitle: 'শতক, কাঠা, বিঘা, একর ও ফারায়েজ',
    desc: 'জমি পরিমাপ, ত্রিভুজ-চতুর্ভুজ জমির নিখুঁত ক্ষেত্রফল ও উত্তরাধিকার ফারায়েজ বন্টন।',
    icon: Calculator,
    category: 'calculators',
    subTabs: { calc: 'land' },
    badge: 'আমিন ক্যালকুলেটর',
    iconBg: 'bg-[#D1E5F0] text-[#2B6CB0]',
    group: 'হিসাব ও ক্যালকুলেটর'
  },
  {
    id: 'loan_calculator',
    title: '২৪. কৃষি ঋণ ও কিস্তি হিসাবক',
    subtitle: 'সহজ শর্তের ব্যাংক ঋণ ও সুদ হিসাব',
    desc: 'বাংলাদেশ ব্যাংক ও কৃষি ব্যাংকের ৪% রেয়াতি সুদের কৃষি ঋণ ও কিস্তির নিখুঁত হিসাব।',
    icon: Calculator,
    category: 'calculators',
    subTabs: { calc: 'loan' },
    badge: 'ঋণ হিসাব',
    iconBg: 'bg-[#FAF0E6] text-[#8B4513]',
    group: 'হিসাব ও ক্যালকুলেটর'
  },
  {
    id: 'housing_rental',
    title: '২৫. আবাসন ও বাসা ভাড়া',
    subtitle: 'ফ্যামিলি বাসা, মেস, সাবলেট ও দোকান',
    desc: 'দালালমুক্ত বাসা ও মেস ভাড়া অনুসন্ধান, সরাসরি বাড়ির মালিকের সাথে যোগাযোগ ও নিরাপদ আবাসন।',
    icon: Home,
    category: 'housing',
    badge: '🏠 বাসা ভাড়া',
    iconBg: 'bg-[#E0F2FE] text-[#0369A1]',
    group: 'আবাসন ও পরিবার'
  },
  {
    id: 'matrimony',
    title: '২৬. পাত্র-পাত্রীর সন্ধান',
    subtitle: 'শালীন ও ছবিমুক্ত পারিবারিক মেচমেকিং',
    desc: 'কঠোর গোপনীয়তা ও শতভাগ ছবিমুক্ত নিয়মে পাত্র ও পাত্রীর সন্ধান, সরাসরি পরিবারের সাথে যোগাযোগ।',
    icon: HeartHandshake,
    category: 'matrimony',
    badge: '💍 পাত্র-পাত্রী',
    iconBg: 'bg-[#FCE7F3] text-[#BE185D]',
    group: 'আবাসন ও পরিবার'
  }
];

export const ServicesGridView: React.FC<ServicesGridViewProps> = ({
  onSelectService,
  currentDistrict
}) => {
  const { language, t } = useLanguage();
  const [selectedGroup, setSelectedGroup] = useState<string>('সকল');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const groups = [
    { id: 'সকল', label: t('সকল', 'All') },
    { id: 'কৃষি ও হাট', label: t('কৃষি ও হাট', 'Agri & Market') },
    { id: 'আবাসন ও পরিবার', label: t('আবাসন ও পরিবার', 'Housing & Family') },
    { id: 'শিক্ষা ও কারিগর', label: t('শিক্ষা ও কারিগর', 'Education & Trade') },
    { id: 'যোগাযোগ ও পরিবহন', label: t('যোগাযোগ ও পরিবহন', 'Transport') },
    { id: 'স্বাস্থ্য ও চিকিৎসা', label: t('স্বাস্থ্য ও চিকিৎসা', 'Health & Medical') },
    { id: 'সরকারি ও নাগরিক', label: t('সরকারি ও নাগরিক', 'Government & Civil') },
    { id: 'বিদ্যুৎ সেবা', label: t('বিদ্যুৎ সেবা', 'Electricity') },
    { id: 'ধর্মীয় সেবা', label: t('ধর্মীয় সেবা', 'Religious') },
    { id: 'হিসাব ও ক্যালকুলেটর', label: t('হিসাব ও ক্যালকুলেটর', 'Calculators') }
  ];

  const filtered = ALL_EXPANDED_SERVICES.filter(s => {
    const matchesGroup = selectedGroup === 'সকল' || s.group === selectedGroup;
    const trans = SERVICE_TRANSLATIONS[s.id];
    const q = searchQuery.toLowerCase().trim();
    if (!q) return matchesGroup;

    const matchesBn = 
      s.title.toLowerCase().includes(q) ||
      s.subtitle.toLowerCase().includes(q) ||
      s.desc.toLowerCase().includes(q);

    const matchesEn = trans && (
      trans.titleEn.toLowerCase().includes(q) ||
      trans.subtitleEn.toLowerCase().includes(q) ||
      trans.descEn.toLowerCase().includes(q) ||
      trans.badgeEn.toLowerCase().includes(q)
    );

    return matchesGroup && (matchesBn || matchesEn);
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 font-['Noto_Sans_Bengali'] space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 border border-[#E6E0D4] shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-xl bg-[#D4E4BC] text-[#2D5A27] font-bold flex items-center justify-center text-sm">
                ২৬
              </span>
              <h2 className="text-xl sm:text-2xl font-bold text-[#2D3A3A]">
                {t('পল্লী সেবার সকল ২৬টি উন্মুক্ত নাগরিক সেবা', 'All 26 Rural Public & Citizen Services')}
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-[#736B5E] mt-1">
              {t(
                'সহজে খুঁজে পাওয়ার জন্য সকল সেবা সরাসরি উন্মুক্ত করা হয়েছে। যেকোনো সেবায় ক্লিক করে প্রবেশ করুন',
                'All public and rural services are directly open for easy access. Click any service to enter.'
              )}
            </p>
          </div>

          <div className="text-xs bg-[#FAF8F5] px-3.5 py-1.5 rounded-xl border border-[#D4C3A3] text-[#2D5A27] font-bold self-start sm:self-auto">
            📍 {t('বর্তমান জেলা:', 'District:')} {currentDistrict}
          </div>
        </div>

        {/* Search Box */}
        <div className="relative">
          <input
            type="text"
            placeholder={t(
              'সেবা খুঁজুন (যেমন: শিক্ষক, মেকানিক, শ্রমিক, পরিবহন, ব্লাড ব্যাংক, ফসল রোগ, সার, বিদ্যুৎ বিল, ভাতা)...',
              'Search services (e.g. tutor, mechanic, laborer, transport, blood, crop disease, fertilizer, bill)...'
            )}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#FAF8F5] border-2 border-[#D4C3A3] rounded-2xl py-3 pl-10 pr-10 text-xs sm:text-sm font-semibold text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
          />
          <Search className="w-4 h-4 text-[#736B5E] absolute left-3.5 top-1/2 -translate-y-1/2" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#736B5E] hover:text-[#2D3A3A] p-1 cursor-pointer"
              title={t('সার্চ মুছুন', 'Clear Search')}
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Category Pills */}
        <div className="flex items-center overflow-x-auto no-scrollbar gap-1.5 pt-1">
          {groups.map((g) => (
            <button
              key={g.id}
              onClick={() => setSelectedGroup(g.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                selectedGroup === g.id
                  ? 'bg-[#2D5A27] text-white shadow-xs'
                  : 'bg-[#FAF8F5] text-[#5A6B6B] border border-[#E6E0D4] hover:bg-[#F9E5D4]/40'
              }`}
            >
              {g.label}
            </button>
          ))}
        </div>
      </div>

      {/* মেনু প্রধান বিশেষ সেবা সমূহ (Featured Menu Essentials) */}
      {!searchQuery && selectedGroup === 'সকল' && (
        <div className="bg-[#FAF8F5] rounded-3xl p-4 sm:p-5 border border-[#D4C3A3] shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2D5A27] animate-pulse" />
              <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A]">
                {t('মেনু বিশেষ সেবা সমূহ', 'Featured Menu Services')}
              </h3>
            </div>
            <span className="text-[11px] text-[#736B5E] font-medium hidden sm:inline">
              {t('সরাসরি সেবা নিতে ক্লিক করুন', 'Click to access directly')}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {/* ১. পল্লী পরিবহন ও নিরাপদ চালক */}
            <button
              onClick={() => onSelectService('transport')}
              className="bg-white p-3.5 rounded-2xl border border-[#E6E0D4] hover:border-[#2D5A27] hover:shadow-xs transition text-left cursor-pointer flex flex-col justify-between group"
            >
              <div className="w-10 h-10 rounded-xl bg-[#F9E5D4] text-[#A65E2E] flex items-center justify-center font-bold mb-2 group-hover:scale-105 transition-transform">
                <Car className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] group-hover:text-[#2D5A27] leading-tight">
                  পল্লী পরিবহন ও নিরাপদ চালক
                </h4>
                <span className="text-[10px] text-[#736B5E] mt-0.5 block">
                  অটো, সিএনজি, বাইক ও ট্রিপ
                </span>
              </div>
            </button>

            {/* ২. গৃহ শিক্ষক */}
            <button
              onClick={() => onSelectService('marketplace', { market: 'tutors' })}
              className="bg-white p-3.5 rounded-2xl border border-[#E6E0D4] hover:border-[#2D5A27] hover:shadow-xs transition text-left cursor-pointer flex flex-col justify-between group"
            >
              <div className="w-10 h-10 rounded-xl bg-[#D1E5F0] text-[#1B365D] flex items-center justify-center font-bold mb-2 group-hover:scale-105 transition-transform">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] group-hover:text-[#2D5A27] leading-tight">
                  গৃহ শিক্ষক
                </h4>
                <span className="text-[10px] text-[#736B5E] mt-0.5 block">
                  শিক্ষক ও শিক্ষার্থী সংযোগ
                </span>
              </div>
            </button>

            {/* ৩. ইলেকট্রিশিয়ান ও মেকার */}
            <button
              onClick={() => onSelectService('marketplace', { market: 'mechanics' })}
              className="bg-white p-3.5 rounded-2xl border border-[#E6E0D4] hover:border-[#2D5A27] hover:shadow-xs transition text-left cursor-pointer flex flex-col justify-between group"
            >
              <div className="w-10 h-10 rounded-xl bg-[#E2F1ED] text-[#0F766E] flex items-center justify-center font-bold mb-2 group-hover:scale-105 transition-transform">
                <Wrench className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] group-hover:text-[#2D5A27] leading-tight">
                  ইলেকট্রিশিয়ান ও মেকার
                </h4>
                <span className="text-[10px] text-[#736B5E] mt-0.5 block">
                  ওয়্যারিং, মোটর ও মেরামত
                </span>
              </div>
            </button>

            {/* ৪. কৃষি শ্রমিক বা দিনমজুর */}
            <button
              onClick={() => onSelectService('marketplace', { market: 'labor' })}
              className="bg-white p-3.5 rounded-2xl border border-[#E6E0D4] hover:border-[#2D5A27] hover:shadow-xs transition text-left cursor-pointer flex flex-col justify-between group"
            >
              <div className="w-10 h-10 rounded-xl bg-[#FAF0E6] text-[#8B4513] flex items-center justify-center font-bold mb-2 group-hover:scale-105 transition-transform">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-xs sm:text-sm text-[#2D3A3A] group-hover:text-[#2D5A27] leading-tight">
                  কৃষি শ্রমিক বা দিনমজুর
                </h4>
                <span className="text-[10px] text-[#736B5E] mt-0.5 block">
                  কামলা, জোন ও খামার শ্রমিক
                </span>
              </div>
            </button>
          </div>
        </div>
      )}

      {/* Empty State when Search or Filter matches 0 items */}
      {filtered.length === 0 ? (
        <div className="bg-white p-12 rounded-3xl border border-[#E6E0D4] text-center space-y-3 shadow-2xs">
          <div className="w-14 h-14 bg-[#FAF8F5] rounded-full flex items-center justify-center mx-auto text-[#736B5E]">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h4 className="font-bold text-base sm:text-lg text-[#2D3A3A]">
            {searchQuery 
              ? t(`"${searchQuery}" সম্পর্কিত কোনো সেবা পাওয়া যায়নি`, `No services found matching "${searchQuery}"`) 
              : t('এই ক্যাটাগরিতে কোনো সেবা পাওয়া যায়নি', 'No services found in this category')}
          </h4>
          <p className="text-xs text-[#5A6B6B] max-w-md mx-auto leading-relaxed">
            {t(
              'আপনার কাঙ্ক্ষিত বানানটি পরীক্ষা করুন অথবা "সকল" ক্যাটাগরি নির্বাচন করে আমাদের ২৬টি ডিজিটাল সেবার পূর্ণাঙ্গ তালিকা থেকে সেবা বেছে নিন।',
              'Check your spelling or select "All" to browse our complete list of 26 digital rural services.'
            )}
          </p>
          <div className="pt-2 flex justify-center gap-2">
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedGroup('সকল');
              }}
              className="px-5 py-2.5 bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold rounded-2xl transition cursor-pointer shadow-xs"
            >
              {t('সকল ২৬টি সেবা দেখুন', 'View All 26 Services')}
            </button>
          </div>
        </div>
      ) : (
        /* 4x4 / 3x3 Responsive Grid */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map((srv) => {
            const IconComponent = srv.icon;
            const trans = SERVICE_TRANSLATIONS[srv.id];
            const title = language === 'en' && trans ? trans.titleEn : srv.title;
            const subtitle = language === 'en' && trans ? trans.subtitleEn : srv.subtitle;
            const desc = language === 'en' && trans ? trans.descEn : srv.desc;
            const badge = language === 'en' && trans ? trans.badgeEn : srv.badge;

            return (
              <div
                key={srv.id}
                onClick={() => onSelectService(srv.category, srv.subTabs)}
                className="bg-white p-5 rounded-3xl shadow-sm border border-[#E6E0D4] hover:border-[#2D5A27] hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-105 ${srv.iconBg}`}>
                      <IconComponent className="w-7 h-7" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FDFBF7] border border-[#E6E0D4] text-[#736B5E]">
                      {badge}
                    </span>
                  </div>

                  <h4 className="font-bold text-sm sm:text-base text-[#2D3A3A] group-hover:text-[#2D5A27] transition-colors leading-snug">
                    {title}
                  </h4>
                  <span className="text-[11px] font-bold text-[#E8924A] block mt-0.5">
                    {subtitle}
                  </span>

                  <p className="text-xs text-[#5A6B6B] mt-1.5 leading-relaxed">
                    {desc}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#E6E0D4]/60 flex items-center justify-between text-xs font-bold text-[#2D5A27]">
                  <span>{t('সেবা পেজে প্রবেশ করুন', 'Enter Service Page')}</span>
                  <ArrowRight className="w-3.5 h-3.5 transform transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
