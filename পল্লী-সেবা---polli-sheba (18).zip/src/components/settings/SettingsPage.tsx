import React, { useState, useEffect } from 'react';
import { 
  Settings as SettingsIcon, 
  Bell, 
  BellOff, 
  Globe, 
  Trash2, 
  Moon, 
  Sun, 
  UserX, 
  ShieldCheck, 
  Download, 
  CheckCircle2, 
  AlertTriangle, 
  Smartphone, 
  HardDrive, 
  RefreshCw, 
  MessageSquare,
  Lock,
  ChevronRight,
  Info,
  User,
  LogIn,
  Edit,
  KeyRound,
  MapPin,
  Car,
  ShoppingBag,
  Users,
  HeartHandshake,
  Sparkles,
  HelpCircle,
  PhoneCall,
  LifeBuoy,
  Home
} from 'lucide-react';
import { UserProfile } from '../../types/auth';
import { AppSettings } from '../../types';
import { useLanguage } from '../../context/LanguageContext';

interface SettingsPageProps {
  currentUser: UserProfile | null;
  onLogout: () => void;
  onNavigateCategory: (category: string) => void;
  onOpenAuth?: (actionName?: string) => void;
  onOpenAdmin?: () => void;
  onUpdateProfile?: (profile: UserProfile) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  currentUser,
  onLogout,
  onNavigateCategory,
  onOpenAuth,
  onOpenAdmin,
  onUpdateProfile
}) => {
  const { language, setLanguage, t } = useLanguage();

  // App Settings State loaded from localStorage
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('polli_app_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return {
      notificationsEnabled: true,
      smsAlertsEnabled: true,
      weatherPriceAlerts: true,
      language: 'bn',
      themeMode: 'light'
    };
  });

  // User Profile Granular Notification Settings
  const [notifSettings, setNotifSettings] = useState({
    enableDistrictAlerts: currentUser?.notificationSettings?.enableDistrictAlerts ?? true,
    enableUpazilaAlerts: currentUser?.notificationSettings?.enableUpazilaAlerts ?? true,
    enableUnionAlerts: currentUser?.notificationSettings?.enableUnionAlerts ?? true,
    enableAgriHaatAlerts: currentUser?.notificationSettings?.enableAgriHaatAlerts ?? true,
    enableTransportAlerts: currentUser?.notificationSettings?.enableTransportAlerts ?? true,
    enableBloodAlerts: currentUser?.notificationSettings?.enableBloodAlerts ?? true,
    enableLaborTutorAlerts: currentUser?.notificationSettings?.enableLaborTutorAlerts ?? true,
    enableHousingAndMatrimonyAlerts: currentUser?.notificationSettings?.enableHousingAndMatrimonyAlerts ?? (currentUser?.notificationSwitches?.notifyHousingAndMatrimony ?? true),
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showClearCacheModal, setShowClearCacheModal] = useState<boolean>(false);
  const [showDeleteAccountModal, setShowDeleteAccountModal] = useState<boolean>(false);
  const [showGuestAuthPrompt, setShowGuestAuthPrompt] = useState<{ isOpen: boolean; action: string }>({
    isOpen: false,
    action: ''
  });
  const [deleteConfirmationText, setDeleteConfirmationText] = useState<string>('');
  const [cacheSizeEstimate, setCacheSizeEstimate] = useState<string>('৪.৬ মেগাবাইট');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem('polli_app_settings', JSON.stringify(settings));
    // Apply theme mode class to document
    if (settings.themeMode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleToggleNotification = (key: 'notificationsEnabled' | 'smsAlertsEnabled' | 'weatherPriceAlerts') => {
    setSettings((prev) => {
      const updated = { ...prev, [key]: !prev[key] };
      showToast(updated[key] ? t('নোটিফিকেশন চালু করা হয়েছে', 'Notification enabled') : t('নোটিফিকেশন বন্ধ করা হয়েছে', 'Notification disabled'));
      return updated;
    });
  };

  const handleToggleGranularNotif = (key: keyof typeof notifSettings, labelBn: string, labelEn: string) => {
    setNotifSettings((prev) => {
      const updated = { ...prev, [key]: !prev[key] };
      const statusText = updated[key] 
        ? t(`${labelBn} চালু করা হয়েছে`, `${labelEn} enabled`) 
        : t(`${labelBn} বন্ধ করা হয়েছে`, `${labelEn} disabled`);
      showToast(statusText);

      // Persist to currentUser if logged in
      if (currentUser) {
        const updatedUser: UserProfile = {
          ...currentUser,
          notificationSettings: updated
        };
        try {
          localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
          if (onUpdateProfile) {
            onUpdateProfile(updatedUser);
          }
        } catch (e) {}
      }
      try {
        localStorage.setItem('polli_user_notification_settings', JSON.stringify(updated));
      } catch (e) {}

      return updated;
    });
  };

  const handleLanguageChange = (lang: 'bn' | 'en') => {
    setSettings((prev) => ({ ...prev, language: lang }));
    setLanguage(lang);
    showToast(lang === 'bn' ? 'ভাষা বাংলা নির্বাচন করা হয়েছে' : 'Language set to English');
  };

  const handleThemeToggle = () => {
    setSettings((prev) => {
      const newMode = prev.themeMode === 'light' ? 'dark' : 'light';
      showToast(newMode === 'dark' ? 'রাতের ডার্ক মোড চালু হয়েছে' : 'স্বাভাবিক লাইট মোড চালু হয়েছে');
      return { ...prev, themeMode: newMode };
    });
  };

  const handleClearCache = () => {
    try {
      // Clear non-essential cached data (search logs, weather cache, etc.) but keep essential login & user listings
      sessionStorage.clear();
      localStorage.removeItem('polli_weather_cache');
      localStorage.removeItem('polli_search_history');
      setCacheSizeEstimate('০.০ মেগাবাইট');
      setShowClearCacheModal(false);
      showToast('অ্যাপ ক্যাশ ও অস্থায়ী ফাইল সফলভাবে পরিষ্কার করা হয়েছে! অ্যাপটি এখন আরও হালকা ও দ্রুত কাজ করবে।');
    } catch (e) {
      showToast('ক্যাশ পরিষ্কার সম্পন্ন হয়েছে');
    }
  };

  const handleProfileEditClick = () => {
    if (!currentUser) {
      setShowGuestAuthPrompt({
        isOpen: true,
        action: 'প্রোফাইল এডিট ও ব্যক্তিগত তথ্য পরিচালনা করতে'
      });
    } else {
      onNavigateCategory('account');
    }
  };

  const handleDeleteAccountClick = () => {
    if (!currentUser) {
      setShowGuestAuthPrompt({
        isOpen: true,
        action: 'অ্যাকাউন্ট ডিলিট করতে'
      });
    } else {
      setShowDeleteAccountModal(true);
    }
  };

  const handleDeleteAccount = () => {
    if (deleteConfirmationText.trim() !== 'DELETE' && deleteConfirmationText.trim() !== 'মুছুন') {
      showToast('নিশ্চিত করতে "DELETE" বা "মুছুন" শব্দটি লিখুন');
      return;
    }

    setIsDeleting(true);
    setTimeout(() => {
      // Delete user profile and user's specific listings & rides per Google Play privacy guidelines
      if (currentUser) {
        try {
          const allListings = JSON.parse(localStorage.getItem('polli_haat_listings') || '[]');
          const filteredListings = allListings.filter((l: any) => l.phone !== currentUser.phone);
          localStorage.setItem('polli_haat_listings', JSON.stringify(filteredListings));

          const allRides = JSON.parse(localStorage.getItem('polli_transport_passengers') || '[]');
          const filteredRides = allRides.filter((r: any) => r.phone !== currentUser.phone);
          localStorage.setItem('polli_transport_passengers', JSON.stringify(filteredRides));
        } catch (e) {}
      }

      localStorage.removeItem('polli_user_profile');
      sessionStorage.clear();
      setIsDeleting(false);
      setShowDeleteAccountModal(false);
      onLogout();
      showToast('আপনার একাউন্ট ও ব্যক্তিগত সকল তথ্য সফলভাবে মুছে ফেলা হয়েছে।');
      onNavigateCategory('home');
    }, 1200);
  };

  const handleTriggerInstall = () => {
    window.dispatchEvent(new CustomEvent('polli_trigger_pwa_install'));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 font-['Noto_Sans_Bengali']">
      
      {/* Toast message */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-[#2D5A27] text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs sm:text-sm font-bold animate-in fade-in duration-200">
          <CheckCircle2 className="w-5 h-5 text-[#D4E4BC]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Page Header */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center shadow-xs">
            <SettingsIcon className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#2D3A3A] font-['Noto_Sans_Bengali']">
              প্রফেশনাল সেটিংস ও নিয়ন্ত্রণ
            </h2>
            <p className="text-xs sm:text-sm text-[#5A6B6B]">
              নোটিফিকেশন, ভাষা, ক্যাশ মেমোরি, নাইট মোড ও একাউন্ট সুরক্ষা
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleTriggerInstall}
            className="flex items-center gap-2 bg-[#E8924A] hover:bg-[#D97D35] text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>অ্যাপ ইনস্টল (PWA)</span>
          </button>

          {onOpenAdmin && (
            <button
              onClick={onOpenAdmin}
              className="flex items-center gap-1.5 bg-[#23491E] hover:bg-[#1B3A17] text-[#D4E4BC] font-bold text-xs px-3 py-2.5 rounded-xl shadow-xs transition cursor-pointer border border-[#3D7A35]"
              title="মাস্টার এডমিন ড্যাশবোর্ড"
            >
              <Lock className="w-3.5 h-3.5 text-[#E8924A]" />
              <span className="hidden sm:inline">এডমিন</span>
            </button>
          )}
        </div>
      </div>

      {/* USER ACCOUNT STATUS & PROFILE SHORTCUT */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2.5">
            <User className="w-5 h-5 text-[#2D5A27]" />
            <h3 className="font-bold text-base text-[#2D3A3A]">
              ব্যবহারকারীর প্রোফাইল স্ট্যাটাস (Profile Status)
            </h3>
          </div>
          <span className={`text-xs font-bold px-2.5 py-1 rounded-xl ${
            currentUser ? 'bg-[#D4E4BC] text-[#2D5A27]' : 'bg-[#FAF8F5] text-[#736B5E] border border-[#E6E0D4]'
          }`}>
            {currentUser ? '✅ নিবন্ধিত ইউজার' : '👤 অতিথি ব্যবহারকারী (Guest)'}
          </span>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
          <div className="space-y-1">
            <h4 className="font-bold text-sm text-[#2D3A3A]">
              {currentUser ? currentUser.name : 'আপনি বর্তমানে অতিথি হিসেবে অ্যাপটি ব্যবহার করছেন'}
            </h4>
            <p className="text-xs text-[#736B5E]">
              {currentUser 
                ? `ফোন: ${currentUser.phone}${currentUser.email ? ` • ইমেইল: ${currentUser.email}` : ''} • ঠিকানা: ${currentUser.district}, ${currentUser.upazila || ''}` 
                : 'সব ফিচার দেখতে পারবেন। প্রোফাইল এডিট বা সরাসরি পোস্ট করতে ফোন নম্বর দিয়ে যুক্ত হোন।'}
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            {currentUser ? (
              <button
                onClick={handleProfileEditClick}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>প্রোফাইল ও পাসওয়ার্ড</span>
              </button>
            ) : (
              <button
                onClick={() => onOpenAuth ? onOpenAuth('লগইন বা একাউন্ট তৈরি করতে') : onNavigateCategory('account')}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>সাইন-ইন / রেজিস্টার</span>
              </button>
            )}

            <button
              onClick={handleProfileEditClick}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1 bg-white hover:bg-[#E6E0D4] text-[#2D3A3A] font-semibold text-xs px-3.5 py-2.5 rounded-xl border border-[#E6E0D4] transition cursor-pointer"
            >
              <span>অ্যাকাউন্ট পেজ</span>
              <ChevronRight className="w-3.5 h-3.5 text-[#736B5E]" />
            </button>
          </div>
        </div>
      </div>

      {/* 1. NOTIFICATIONS SETTINGS */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-xs space-y-5">
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2.5">
            <Bell className="w-5 h-5 text-[#2D5A27]" />
            <div>
              <h3 className="font-bold text-base text-[#2D3A3A]">
                {t('নোটিফিকেশন ও এলাকাভিত্তিক অ্যালার্ট সেটিংস', 'Notification & Regional Alert Settings')}
              </h3>
              <p className="text-xs text-[#736B5E]">
                {t('আপনার প্রয়োজনীয় সেবা ও নির্দিষ্ট ভৌগোলিক এলাকার সতর্কতা নিয়ন্ত্রণ করুন', 'Control alerts by service category and geographical region')}
              </p>
            </div>
          </div>
        </div>

        {/* Notice for Registered Professionals */}
        <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#D4E4BC] flex items-start gap-3">
          <Sparkles className="w-4 h-4 text-[#2D5A27] shrink-0 mt-0.5" />
          <div className="text-xs text-[#2D3A3A] space-y-1">
            <strong className="font-bold block text-[#2D5A27]">
              {t('💡 চালক, কৃষি শ্রমিক, মেকানিক ও গৃহশিক্ষক ভাইদের জন্য বিশেষ সুবিধা:', '💡 Special Feature for Drivers, Laborers, Mechanics & Tutors:')}
            </strong>
            <p className="text-[#5A6B6B]">
              {t(
                'আপনি যে পেশায় নিবন্ধিত আছেন, সেটির নোটিফিকেশন যখন ইচ্ছা এখান থেকে বন্ধ বা চালু রাখতে পারবেন। যেমন: আপনি যদি কোনো দিন কাজ করতে না চান, তবে আপনার ক্যাটাগরির বা এলাকার নোটিফিকেশন বন্ধ রাখলে আপনাকে বারবার নোটিফিকেশন পাঠিয়ে বিরক্ত করা হবে না।',
                'You can turn notifications on or off whenever you like. For example, if you do not want work on a particular day, turning off your category or area alerts stops incoming notifications.'
              )}
            </p>
          </div>
        </div>

        {/* General App Alerts */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-[#5A6B6B] uppercase tracking-wider">
            {t('সাধারণ পুশ অ্যালার্ট', 'General Push Alerts')}
          </h4>

          {/* General Push Alerts */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="space-y-0.5">
              <span className="font-bold text-sm text-[#2D3A3A] block">
                {t('জরুরি পুশ নোটিফিকেশন', 'Urgent Push Notifications')}
              </span>
              <span className="text-xs text-[#736B5E]">
                {t('জরুরি রক্তের আবেদন ও বজ্রপাত/দুর্যোগকালীন আবহাওয়া সতর্কতা', 'Emergency blood requests & lightning/weather disaster alerts')}
              </span>
            </div>
            <button
              onClick={() => handleToggleNotification('notificationsEnabled')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                settings.notificationsEnabled ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  settings.notificationsEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* SMS / Urgent Call Alerts */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="space-y-0.5">
              <span className="font-bold text-sm text-[#2D3A3A] block">
                {t('এসএমএস ও ট্রিপ অ্যালার্ট', 'SMS & Trip Alerts')}
              </span>
              <span className="text-xs text-[#736B5E]">
                {t('চালক বুকিং ও জরুরি নিরাপত্তা ট্র্যাকিং সংক্রান্ত মেসেজ', 'Driver bookings & security tracking status messages')}
              </span>
            </div>
            <button
              onClick={() => handleToggleNotification('smsAlertsEnabled')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                settings.smsAlertsEnabled ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  settings.smsAlertsEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Daily Market Price Alerts */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="space-y-0.5">
              <span className="font-bold text-sm text-[#2D3A3A] block">
                {t('দৈনিক বাজারদর ও শস্য পরামর্শ', 'Daily Haat Prices & Crop Advice')}
              </span>
              <span className="text-xs text-[#736B5E]">
                {t('সকাল ৮টায় আপনার জেলার হাটের শাকসবজি ও ফসলের লাইভ দরদাম', 'Live market updates for vegetables and agricultural crops at 8 AM')}
              </span>
            </div>
            <button
              onClick={() => handleToggleNotification('weatherPriceAlerts')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                settings.weatherPriceAlerts ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  settings.weatherPriceAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Regional Granular Alerts (District, Upazila, Union) */}
        <div className="space-y-3 pt-2 border-t border-[#E6E0D4]">
          <h4 className="text-xs font-bold text-[#5A6B6B] uppercase tracking-wider flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#2D5A27]" />
            <span>{t('এলাকাভিত্তিক নোটিফিকেশন ফিল্টার', 'Geographic Area Notification Filters')}</span>
          </h4>

          {/* District Alerts */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="space-y-0.5">
              <span className="font-bold text-sm text-[#2D3A3A] block">
                {t('জেলা পর্যায়ের নোটিফিকেশন', 'District Level Notifications')}
              </span>
              <span className="text-xs text-[#736B5E]">
                {t('পুরো জেলার আওতাধীন জরুরি নোটিশ, সার-বীজ ও বড় বিজ্ঞপ্তিসমূহ', 'District-wide urgent circulars, agri goods and major notices')}
              </span>
            </div>
            <button
              onClick={() => handleToggleGranularNotif('enableDistrictAlerts', 'জেলা পর্যায়ের নোটিফিকেশন', 'District level notifications')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                notifSettings.enableDistrictAlerts ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  notifSettings.enableDistrictAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Upazila Alerts */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="space-y-0.5">
              <span className="font-bold text-sm text-[#2D3A3A] block">
                {t('উপজেলা পর্যায়ের নোটিফিকেশন', 'Upazila Level Notifications')}
              </span>
              <span className="text-xs text-[#736B5E]">
                {t('আপনার নিজস্ব উপজেলার চালক, পণ্য ও জরুরি লোকাল নোটিফিকেশন', 'Driver requests, market posts and local notices from your Upazila')}
              </span>
            </div>
            <button
              onClick={() => handleToggleGranularNotif('enableUpazilaAlerts', 'উপজেলা পর্যায়ের নোটিফিকেশন', 'Upazila level notifications')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                notifSettings.enableUpazilaAlerts ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  notifSettings.enableUpazilaAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Union Alerts */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="space-y-0.5">
              <span className="font-bold text-sm text-[#2D3A3A] block">
                {t('ইউনিয়ন ও গ্রাম পর্যায়ের নোটিফিকেশন', 'Union & Village Level Notifications')}
              </span>
              <span className="text-xs text-[#736B5E]">
                {t('আপনার নিজ ইউনিয়ন ও গ্রামের সরাসরি দিনমজুর ডাক ও লোকাল খবর', 'Immediate neighbor day labor calls, local van calls and nearby events')}
              </span>
            </div>
            <button
              onClick={() => handleToggleGranularNotif('enableUnionAlerts', 'ইউনিয়ন ও গ্রাম পর্যায়ের নোটিফিকেশন', 'Union and village level notifications')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                notifSettings.enableUnionAlerts ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  notifSettings.enableUnionAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Category Granular Alerts */}
        <div className="space-y-3 pt-2 border-t border-[#E6E0D4]">
          <h4 className="text-xs font-bold text-[#5A6B6B] uppercase tracking-wider">
            {t('সেবা ক্যাটাগরি অনুযায়ী নোটিফিকেশন', 'Service Category Notifications')}
          </h4>

          {/* Agri Haat */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <span className="font-bold text-sm text-[#2D3A3A] block">
                  {t('পল্লী হাট ও খাঁটি কৃষিপণ্য', 'Polli Haat & Farm Products')}
                </span>
                <span className="text-xs text-[#736B5E]">
                  {t('নতুন শাকসবজি, শস্য, গবাদিপশু বা কৃষিপণ্যের বিজ্ঞাপন', 'New crop, livestock or agricultural supply listings')}
                </span>
              </div>
            </div>
            <button
              onClick={() => handleToggleGranularNotif('enableAgriHaatAlerts', 'পল্লী হাট নোটিফিকেশন', 'Polli Haat notifications')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                notifSettings.enableAgriHaatAlerts ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  notifSettings.enableAgriHaatAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Transport & Drivers */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                <Car className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <span className="font-bold text-sm text-[#2D3A3A] block">
                  {t('গ্রামীণ পরিবহন ও চালক চাহিদা', 'Rural Transport & Driver Demands')}
                </span>
                <span className="text-xs text-[#736B5E]">
                  {t('যাত্রী বা মালামাল পরিবহনে চালকের নতুন কল ও বুকিং অ্যালার্ট', 'Driver calls and transport requests from passengers & cargo senders')}
                </span>
              </div>
            </div>
            <button
              onClick={() => handleToggleGranularNotif('enableTransportAlerts', 'পরিবহন চালক নোটিফিকেশন', 'Transport driver notifications')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                notifSettings.enableTransportAlerts ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  notifSettings.enableTransportAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Blood & Health */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-800 flex items-center justify-center shrink-0">
                <HeartHandshake className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <span className="font-bold text-sm text-[#2D3A3A] block">
                  {t('জরুরি রক্তদান ও রক্তদাতার ডাক', 'Emergency Blood Requests')}
                </span>
                <span className="text-xs text-[#736B5E]">
                  {t('আপনার এলাকার রোগীদের রক্তের জরুরি আবেদন নোটিফিকেশন', 'Critical blood donor call notifications in your area')}
                </span>
              </div>
            </div>
            <button
              onClick={() => handleToggleGranularNotif('enableBloodAlerts', 'রক্তদান নোটিফিকেশন', 'Blood donation notifications')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                notifSettings.enableBloodAlerts ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  notifSettings.enableBloodAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Labor, Tutor, Mechanic */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center shrink-0">
                <Users className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <span className="font-bold text-sm text-[#2D3A3A] block">
                  {t('কৃষি শ্রমিক, দিনমজুর, শিক্ষক ও মেকানিক', 'Laborers, Day Workers, Tutors & Mechanics')}
                </span>
                <span className="text-xs text-[#736B5E]">
                  {t('মাঠে কাজের ডাক, গৃহশিক্ষক খোঁজা বা ইলেকট্রিশিয়ান মেরামতের চাহিদা', 'Field worker calls, tutor recruitment or technician demands')}
                </span>
              </div>
            </div>
            <button
              onClick={() => handleToggleGranularNotif('enableLaborTutorAlerts', 'শ্রমিক ও শিক্ষক নোটিফিকেশন', 'Labor & Tutor notifications')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                notifSettings.enableLaborTutorAlerts ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  notifSettings.enableLaborTutorAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Housing & Matrimony Notification Toggle */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center shrink-0">
                <Home className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <span className="font-bold text-sm text-[#2D3A3A] block">
                  {t('বাসা ভাড়া ও পাত্র-পাত্রীর সন্ধান চেয়ে পোস্টের বা বিজ্ঞাপনের নোটিফিকেশন পেতে চান?', 'Want notifications for house rental & matrimony matchmaking posts?')}
                </span>
                <span className="text-xs text-[#736B5E]">
                  {t('আপনার এলাকায় নতুন বাসা ও মেস ভাড়া এবং পাত্র-পাত্রীর নতুন বিজ্ঞাপনের লাইভ পুশ নোটিফিকেশন', 'Live push alerts for house/mess rentals & matrimonial posts in your area')}
                </span>
              </div>
            </div>
            <button
              onClick={() => handleToggleGranularNotif('enableHousingAndMatrimonyAlerts', 'বাসা ভাড়া ও পাত্র-পাত্রী নোটিফিকেশন', 'Housing & Matrimony notifications')}
              className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
                notifSettings.enableHousingAndMatrimonyAlerts ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                  notifSettings.enableHousingAndMatrimonyAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* 2. LANGUAGE SWITCHER */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-xs space-y-4">
        <div className="flex items-center gap-2.5 border-b border-[#E6E0D4] pb-3">
          <Globe className="w-5 h-5 text-[#2D5A27]" />
          <div>
            <h3 className="font-bold text-base text-[#2D3A3A]">
              {t('ভাষা নির্বাচন', 'Language Selection')}
            </h3>
            <p className="text-xs text-[#736B5E]">
              {t('অ্যাপের ভাষা বাংলা অথবা ইংরেজিতে পরিবর্তন করুন', 'Switch application interface between Bengali and English')}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => handleLanguageChange('bn')}
            className={`p-4 rounded-2xl border-2 flex items-center justify-between transition cursor-pointer ${
              language === 'bn'
                ? 'border-[#2D5A27] bg-[#D4E4BC]/20 text-[#2D5A27] font-bold shadow-xs'
                : 'border-[#E6E0D4] bg-[#FAF8F5] text-[#2D3A3A]'
            }`}
          >
            <div className="text-left">
              <span className="block text-base font-bold">বাংলা (ডিফল্ট)</span>
              <span className="text-xs text-[#736B5E]">সব মেনু ও তথ্য বাংলায়</span>
            </div>
            {language === 'bn' && <CheckCircle2 className="w-5 h-5 text-[#2D5A27]" />}
          </button>

          <button
            onClick={() => handleLanguageChange('en')}
            className={`p-4 rounded-2xl border-2 flex items-center justify-between transition cursor-pointer ${
              language === 'en'
                ? 'border-[#2D5A27] bg-[#D4E4BC]/20 text-[#2D5A27] font-bold shadow-xs'
                : 'border-[#E6E0D4] bg-[#FAF8F5] text-[#2D3A3A]'
            }`}
          >
            <div className="text-left">
              <span className="block text-base font-bold">English</span>
              <span className="text-xs text-[#736B5E]">English Interface Support</span>
            </div>
            {language === 'en' && <CheckCircle2 className="w-5 h-5 text-[#2D5A27]" />}
          </button>
        </div>
      </div>

      {/* 3. DISPLAY & NIGHT/DARK MODE */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-xs space-y-4">
        <div className="flex items-center gap-2.5 border-b border-[#E6E0D4] pb-3">
          {settings.themeMode === 'dark' ? <Moon className="w-5 h-5 text-[#E8924A]" /> : <Sun className="w-5 h-5 text-[#E8924A]" />}
          <h3 className="font-bold text-base text-[#2D3A3A]">
            থিম ও রাতের মোড (Dark / Night Mode)
          </h3>
        </div>

        <div className="flex items-center justify-between p-4 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4]">
          <div className="space-y-0.5">
            <span className="font-bold text-sm text-[#2D3A3A] block">রাতের চোখের সুরক্ষার জন্য ডার্ক মোড</span>
            <span className="text-xs text-[#736B5E]">রাতে বা কম আলোতে ব্যবহারের সময় স্ক্রিনের উজ্জ্বলতা হ্রাস করে</span>
          </div>
          <button
            onClick={handleThemeToggle}
            className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
              settings.themeMode === 'dark' ? 'bg-[#2D5A27]' : 'bg-[#D4C3A3]'
            }`}
          >
            <div
              className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform transform ${
                settings.themeMode === 'dark' ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      </div>

      {/* 4. CLEAR CACHE & DATA OPTIMIZATION */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2.5">
            <HardDrive className="w-5 h-5 text-[#2D5A27]" />
            <h3 className="font-bold text-base text-[#2D3A3A]">
              ক্যাশ ও অস্থায়ী ফাইল মুছে অ্যাপ দ্রুত করুন (Clear Cache)
            </h3>
          </div>
          <span className="text-xs bg-[#FAF8F5] border border-[#D4C3A3] text-[#A65E2E] font-bold px-2.5 py-1 rounded-xl">
            {cacheSizeEstimate}
          </span>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#FAF8F5] p-4 rounded-2xl border border-[#E6E0D4]">
          <div className="space-y-0.5">
            <p className="text-xs sm:text-sm text-[#2D3A3A] font-semibold">
              অপ্রয়োজনীয় ব্রাউজিং ডেটা ও পুরাতন ক্যাশ মেমোরি খালি করুন
            </p>
            <p className="text-xs text-[#736B5E]">
              ক্যাশ মুছে ফেললে আপনার লগইন বহাল থাকবে কিন্তু অ্যাপের গতি দ্রুত ও মসৃণ হবে।
            </p>
          </div>
          <button
            onClick={() => setShowClearCacheModal(true)}
            className="flex items-center gap-1.5 bg-white hover:bg-[#F9E5D4] text-[#A65E2E] border border-[#D4C3A3] font-bold text-xs px-4 py-2.5 rounded-xl shadow-2xs transition cursor-pointer whitespace-nowrap"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>ক্যাশ মেমোরি মুছুন</span>
          </button>
        </div>
      </div>

      {/* 5. HELP, GUIDELINES & SUPPORT (সাহায্য ও সাপোর্ট কেন্দ্র) */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-xs space-y-4">
        <div className="flex items-center gap-2.5 border-b border-[#E6E0D4] pb-3">
          <div className="w-10 h-10 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center font-bold shadow-xs">
            <HelpCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-[#2D3A3A]">
              {t('সাহায্য ও ব্যবহার সহায়িকা (Help & Support)', 'Help & Guidelines')}
            </h3>
            <p className="text-xs text-[#736B5E]">
              {t('অ্যাপ ব্যবহারের নিয়মাবলী, সাধারণ প্রশ্ন, সরাসরি মতামত ও জরুরি সাহায্য', 'User manual, FAQs, feedback to developer and emergency help')}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            onClick={() => onNavigateCategory('terms-help')}
            className="flex items-center justify-between p-4 bg-[#FAF8F5] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4] rounded-2xl text-left transition group cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#2D5A27] text-white flex items-center justify-center shadow-xs">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-sm text-[#2D3A3A] block group-hover:text-[#2D5A27]">
                  সাহায্য ও ব্যবহার নির্দেশিকা
                </span>
                <span className="text-xs text-[#736B5E]">
                  সকল সেবার নিয়মাবলী ও টিউটোরিয়াল
                </span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#736B5E] group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={() => onNavigateCategory('terms-help')}
            className="flex items-center justify-between p-4 bg-[#FAF8F5] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4] rounded-2xl text-left transition group cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#E8924A] text-white flex items-center justify-center shadow-xs">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-sm text-[#2D3A3A] block group-hover:text-[#E8924A]">
                  উদ্যোক্তাকে মতামত ও পরামর্শ দিন
                </span>
                <span className="text-xs text-[#736B5E]">
                  সরাসরি পরামর্শ বা অভিযোগ পাঠান
                </span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#736B5E] group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Emergency Hotlines quick reference */}
        <div className="p-3.5 bg-[#FAF8F5] rounded-2xl border border-[#E6E0D4] flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="font-bold text-[#2D5A27] flex items-center gap-1.5">
            <PhoneCall className="w-4 h-4 text-[#C0392B]" />
            জরুরি হেল্পলাইন:
          </span>
          <div className="flex flex-wrap gap-2 text-xs">
            <span className="bg-white border border-[#D4C3A3] px-2.5 py-1 rounded-lg text-[#2D3A3A] font-semibold">
              জাতীয় জরুরি: ৯৯৯
            </span>
            <span className="bg-white border border-[#D4C3A3] px-2.5 py-1 rounded-lg text-[#2D3A3A] font-semibold">
              কৃষি বাতায়ন: ১৬১২৩
            </span>
            <span className="bg-white border border-[#D4C3A3] px-2.5 py-1 rounded-lg text-[#2D3A3A] font-semibold">
              স্বাস্থ্য সেবা: ১৬২৬৩
            </span>
            <span className="bg-white border border-[#D4C3A3] px-2.5 py-1 rounded-lg text-[#2D3A3A] font-semibold">
              তথ্য সেবা: ৩৩৩
            </span>
          </div>
        </div>
      </div>

      {/* 6. PRIVACY & PLAY STORE COMPLIANT ACCOUNT DELETION */}
      <div className="bg-red-50/70 rounded-3xl p-5 sm:p-6 border border-red-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2.5 border-b border-red-200 pb-3">
          <UserX className="w-5 h-5 text-red-600" />
          <h3 className="font-bold text-base text-red-900">
            অ্যাকাউন্ট মোছার অধিকার (Delete My Account)
          </h3>
        </div>

        <div className="space-y-3">
          <p className="text-xs sm:text-sm text-red-800 leading-relaxed">
            গুগল প্লে-স্টোর ও আন্তর্জাতিক ডিজিটাল প্রাইভেসী নীতি অনুযায়ী, আপনি যেকোনো সময় 'পল্লী সেবা' থেকে আপনার প্রোফাইল, ফোন নম্বর, দেওয়া সকল হাট বিজ্ঞাপন এবং রাইড ইতিহাস স্থায়ীভাবে মুছে ফেলতে পারেন।
          </p>

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-2">
            <div className="text-xs text-red-700">
              বর্তমান একাউন্ট: <strong>{currentUser ? currentUser.name : 'অতিথি ব্যবহারকারী (Guest)'}</strong> ({currentUser?.phone ? currentUser.phone : 'ফোন রেজিস্টার নেই'})
            </div>
            <button
              onClick={handleDeleteAccountClick}
              className="flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>আমার অ্যাকাউন্ট ও ডেটা মুছুন</span>
            </button>
          </div>
        </div>
      </div>

      {/* 6. APP INFO & LEGAL */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E0D4] shadow-xs space-y-3 text-xs text-[#736B5E]">
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-2">
          <span className="font-bold text-[#2D3A3A]">অ্যাপ সংস্করণ</span>
          <span className="font-semibold text-[#2D5A27]">Polli Sheba v2.4.0 (PWA Ready)</span>
        </div>
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-2">
          <span className="font-bold text-[#2D3A3A]">নীতিমালা ও প্রাইভেসী</span>
          <button
            onClick={() => onNavigateCategory('terms-help')}
            className="text-[#2D5A27] font-bold hover:underline cursor-pointer flex items-center gap-1"
          >
            <span>শর্তাবলী ও নীতিমালা দেখুন</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <p className="text-center pt-2 text-[11px] text-[#736B5E]/80">
          বাংলাদেশের গ্রামীণ জনপদের ডিজিটাল জনসেবায় নিবেদিত • নিরাপদ, দালালমুক্ত ও উন্মুক্ত
        </p>
      </div>

      {/* GUEST AUTH PROMPT MODAL */}
      {showGuestAuthPrompt.isOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4 animate-in fade-in duration-150">
            <div className="w-12 h-12 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center mx-auto">
              <User className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h4 className="font-bold text-base text-[#2D3A3A]">লগইন বা নিবন্ধন প্রয়োজন</h4>
              <p className="text-xs text-[#736B5E] leading-relaxed">
                {showGuestAuthPrompt.action} অনুগ্রহ করে আপনার মোবাইল নম্বর দিয়ে বিনামূল্যে সাইন-ইন বা নিবন্ধন সম্পন্ন করুন।
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => {
                  setShowGuestAuthPrompt({ isOpen: false, action: '' });
                  if (onOpenAuth) {
                    onOpenAuth('প্রোফাইল পরিবর্তন বা অ্যাকাউন্ট পরিচালনায়');
                  } else {
                    onNavigateCategory('account');
                  }
                }}
                className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-xl text-xs shadow-xs cursor-pointer"
              >
                সাইন-ইন / রেজিস্টার করুন
              </button>
              <button
                onClick={() => setShowGuestAuthPrompt({ isOpen: false, action: '' })}
                className="bg-[#FAF8F5] text-[#5A6B6B] font-semibold py-2.5 px-4 rounded-xl text-xs border border-[#E6E0D4] cursor-pointer"
              >
                বন্ধ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM CLEAR CACHE MODAL */}
      {showClearCacheModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4 animate-in fade-in duration-150">
            <div className="w-12 h-12 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center mx-auto">
              <RefreshCw className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h4 className="font-bold text-base text-[#2D3A3A]">ক্যাশ মেমোরি খালি করতে চান?</h4>
              <p className="text-xs text-[#736B5E]">
                অস্থায়ী ব্রাউজিং হিস্ট্রি ও ক্যাশ মুছে ফেলা হবে। আপনার ব্যক্তিগত একাউন্ট লগইন বহাল থাকবে।
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleClearCache}
                className="flex-1 bg-[#2D5A27] hover:bg-[#23491E] text-white font-bold py-2.5 rounded-xl text-xs shadow-xs cursor-pointer"
              >
                হ্যাঁ, পরিষ্কার করুন
              </button>
              <button
                onClick={() => setShowClearCacheModal(false)}
                className="bg-[#FAF8F5] text-[#5A6B6B] font-semibold py-2.5 px-4 rounded-xl text-xs border border-[#E6E0D4] cursor-pointer"
              >
                বাতিল
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE ACCOUNT MODAL (GOOGLE PLAY COMPLIANT) */}
      {showDeleteAccountModal && (
        <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-red-200 space-y-4 animate-in fade-in duration-150">
            <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            
            <div className="text-center space-y-1">
              <h4 className="font-bold text-base text-red-900">
                স্থায়ীভাবে অ্যাকাউন্ট মুছে ফেলতে চান?
              </h4>
              <p className="text-xs text-red-700 leading-relaxed">
                এটি চূড়ান্ত পদক্ষেপ। আপনার প্রোফাইল, ফোন নম্বর, দেওয়া সকল হাট বিজ্ঞাপন ও ট্রিপ রেকর্ড সাথে সাথে ডেটাবেজ থেকে চিরতরে মুছে যাবে।
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <label className="block text-xs font-bold text-[#2D3A3A]">
                নিশ্চিত করতে নিচে <strong>"DELETE"</strong> বা <strong>"মুছুন"</strong> লিখুন:
              </label>
              <input
                type="text"
                value={deleteConfirmationText}
                onChange={(e) => setDeleteConfirmationText(e.target.value)}
                placeholder="DELETE"
                className="w-full bg-[#FAF8F5] border-2 border-red-300 rounded-xl p-2.5 text-xs text-[#2D3A3A] font-bold focus:outline-none focus:border-red-600"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleDeleteAccount}
                disabled={isDeleting}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 rounded-xl text-xs shadow-xs cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isDeleting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                <span>{isDeleting ? 'মোছা হচ্ছে...' : 'স্থায়ীভাবে ডিলিট করুন'}</span>
              </button>
              <button
                onClick={() => {
                  setShowDeleteAccountModal(false);
                  setDeleteConfirmationText('');
                }}
                className="bg-[#FAF8F5] text-[#5A6B6B] font-semibold py-2.5 px-4 rounded-xl text-xs border border-[#E6E0D4] cursor-pointer"
              >
                বাতিল
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
