import React, { useEffect, useRef } from 'react';
import { Phone, PhoneOff, ShieldCheck, User } from 'lucide-react';
import { CallSessionData } from '../../lib/cloudSync';

import { audioTones } from '../../utils/audioTones';

interface IncomingCallDialogProps {
  session: CallSessionData;
  onAccept: () => void;
  onReject: () => void;
}

export const IncomingCallDialog: React.FC<IncomingCallDialogProps> = ({
  session,
  onAccept,
  onReject
}) => {
  // Synthesized repeating loud telephone ringtone with device vibration
  useEffect(() => {
    audioTones.playRingingTone();

    return () => {
      audioTones.stopRingingTone();
    };
  }, []);

  const handleAcceptClick = () => {
    audioTones.stopRingingTone();
    onAccept();
  };

  const handleRejectClick = () => {
    audioTones.stopRingingTone();
    onReject();
  };

  return (
    <div className="fixed inset-0 z-70 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-200">
      <div className="bg-[#121B22] text-white rounded-3xl max-w-sm w-full p-6 text-center space-y-6 border border-emerald-500/30 shadow-2xl relative overflow-hidden">
        
        {/* Pulsing ring aura */}
        <div className="absolute top-12 left-1/2 -translate-x-1/2 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl animate-pulse pointer-events-none" />

        {/* Top badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-[11px] font-bold text-emerald-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>ইনকামিং ফ্রি ইন্টারনেট অডিও কল</span>
        </div>

        {/* Center Circular Profile Avatar with WhatsApp-style pulsating wave */}
        <div className="relative inline-block my-2">
          <div className="w-28 h-28 rounded-full border-4 border-emerald-500 flex items-center justify-center shadow-lg relative z-10 overflow-hidden bg-[#1E2A32]">
            {session.callerAvatar ? (
              <img 
                src={session.callerAvatar} 
                alt={session.callerName} 
                className="w-full h-full object-cover" 
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-3xl font-extrabold text-emerald-400 bg-emerald-950">
                {session.callerName ? session.callerName.charAt(0) : 'প'}
              </div>
            )}
          </div>
          {/* Animated rings */}
          <span className="absolute inset-0 rounded-full border-2 border-emerald-400 animate-ping opacity-30" />
          <span className="absolute -inset-2 rounded-full border border-emerald-500/50 animate-pulse" />
        </div>

        {/* Caller Info */}
        <div className="space-y-1">
          <h3 className="text-xl font-bold text-white tracking-wide">
            {session.callerName || 'পল্লী সেবা ব্যবহারকারী'}
          </h3>
          <p className="text-xs text-emerald-400 font-semibold animate-pulse">
            রিং হচ্ছে... (কল গ্রহণ করুন)
          </p>
          {session.callerRole && (
            <p className="text-[11px] text-gray-400">
              {session.callerRole === 'driver' ? '🚗 সম্মানিত চালক' : 
               session.callerRole === 'seller' ? '🛍️ সম্মানিত বিক্রেতা' : 
               session.callerRole === 'mechanic' ? '🔧 মেকানিক ও কারিগর' : 
               session.callerRole === 'tutor' ? '📚 শিক্ষক / শিক্ষার্থী' : 
               '👤 সম্মানিত নাগরিক'}
            </p>
          )}
        </div>

        {/* Two WhatsApp-style Call Buttons: Green (Accept) and Red (Reject) */}
        <div className="pt-4 flex items-center justify-around px-4">
          
          {/* Red Reject Button */}
          <div className="flex flex-col items-center gap-2">
            <button
              type="button"
              onClick={handleRejectClick}
              className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 active:scale-95 text-white flex items-center justify-center shadow-lg transition cursor-pointer"
              title="বাতিল করুন"
            >
              <PhoneOff className="w-7 h-7" />
            </button>
            <span className="text-xs font-semibold text-gray-300">বাতিল</span>
          </div>

          {/* Green Accept Button */}
          <div className="flex flex-col items-center gap-2">
            <button
              type="button"
              onClick={handleAcceptClick}
              className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white flex items-center justify-center shadow-lg transition cursor-pointer animate-bounce"
              title="কল ধরুন"
            >
              <Phone className="w-7 h-7" />
            </button>
            <span className="text-xs font-semibold text-emerald-400">রিসিভ করুন</span>
          </div>

        </div>

      </div>
    </div>
  );
};
