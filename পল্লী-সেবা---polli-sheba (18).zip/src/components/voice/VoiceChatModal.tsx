import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  Square, 
  Play, 
  Pause, 
  Send, 
  X, 
  RotateCcw, 
  Volume2, 
  ShieldCheck, 
  Lock, 
  Clock, 
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { UserProfile } from '../../types/auth';

interface VoiceChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipientName: string;
  recipientRole?: string;
  recipientPhone?: string;
  recipientAvatar?: string;
  itemTitle?: string;
  currentUser: UserProfile | null;
  onSendVoiceMessage: (audioUrl: string, duration: number, textSummary: string) => void;
}

export const VoiceChatModal: React.FC<VoiceChatModalProps> = ({
  isOpen,
  onClose,
  recipientName,
  recipientRole = 'service_provider',
  recipientPhone,
  recipientAvatar,
  itemTitle,
  currentUser,
  onSendVoiceMessage
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordDuration, setRecordDuration] = useState(0);
  const [audioBlobUrl, setAudioBlobUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playProgress, setPlayProgress] = useState(0);
  const [permissionError, setPermissionError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (audioBlobUrl) URL.revokeObjectURL(audioBlobUrl);
    };
  }, [audioBlobUrl]);

  if (!isOpen) return null;

  const startRecording = async () => {
    setPermissionError(null);
    setAudioBlobUrl(null);
    setRecordDuration(0);
    audioChunksRef.current = [];

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('আপনার ব্রাউজারে মাইক্রোফোন রেকর্ডিং সমর্থিত নয়।');
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Determine optimal supported MIME type
      let mimeType = 'audio/webm';
      if (typeof MediaRecorder.isTypeSupported === 'function') {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          mimeType = 'audio/mp4';
        } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
          mimeType = 'audio/ogg';
        }
      }

      const mediaRecorder = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
        // Create persistent base64 data URI so recipient can play it anywhere across devices
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64DataUri = reader.result as string;
          setAudioBlobUrl(base64DataUri);
        };
        reader.readAsDataURL(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start(200);
      setIsRecording(true);

      timerRef.current = setInterval(() => {
        setRecordDuration(prev => {
          if (prev >= 60) {
            stopRecording();
            return 60;
          }
          return prev + 1;
        });
      }, 1000);

    } catch (err: any) {
      const errMsg = err?.name === 'NotAllowedError' 
        ? 'মাইক্রোফোনের অনুমতি দেওয়া হয়নি। ব্রাউজারের উপরে তালা (Lock) আইকন চেপে Microphone Allow করুন।'
        : 'মাইক্রোফোন চালু করা সম্ভব হয়নি। অনুগ্রহ করে ডিভাইসের অডিও পারমিশন চেক করুন।';
      setPermissionError(errMsg);
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    setIsRecording(false);
  };

  const handlePlayPause = () => {
    if (!audioPlayerRef.current && audioBlobUrl) {
      const audio = new Audio(audioBlobUrl);
      audioPlayerRef.current = audio;
      
      audio.ontimeupdate = () => {
        if (audio.duration) {
          setPlayProgress((audio.currentTime / audio.duration) * 100);
        }
      };

      audio.onended = () => {
        setIsPlaying(false);
        setPlayProgress(0);
      };
    }

    if (audioPlayerRef.current) {
      if (isPlaying) {
        audioPlayerRef.current.pause();
        setIsPlaying(false);
      } else {
        audioPlayerRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const handleReset = () => {
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      audioPlayerRef.current = null;
    }
    setAudioBlobUrl(null);
    setRecordDuration(0);
    setIsPlaying(false);
    setPlayProgress(0);
  };

  const handleSend = () => {
    if (!audioBlobUrl) return;
    const durationSec = recordDuration > 0 ? recordDuration : 3;
    const textSummary = `🎙️ ভয়েস বার্তা (${durationSec} সেকেন্ড)`;
    onSendVoiceMessage(audioBlobUrl, durationSec, textSummary);
    onClose();
  };

  const formatSec = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Noto_Sans_Bengali'] animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E6E0D4] space-y-4">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-[#E6E0D4] pb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center shadow-xs">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#2D3A3A] flex items-center gap-1.5">
                <span>ভয়েস চ্যাট ও অডিও বার্তা</span>
                <span className="text-[10px] bg-[#2D5A27] text-white px-2 py-0.5 rounded-full">
                  নতুন
                </span>
              </h3>
              <p className="text-xs text-[#736B5E]">বিনা খরচে দ্রুত ভয়েস নোট পাঠান</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 text-[#736B5E] hover:text-[#2D3A3A] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Recipient Card */}
        <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E0D4] flex items-center gap-3">
          {recipientAvatar ? (
            <img src={recipientAvatar} alt={recipientName} className="w-11 h-11 rounded-xl object-cover border border-[#2D5A27]" />
          ) : (
            <div className="w-11 h-11 rounded-xl bg-[#2D5A27] text-white font-bold text-base flex items-center justify-center shadow-xs">
              {recipientName.charAt(0)}
            </div>
          )}
          <div className="space-y-0.5">
            <h4 className="font-bold text-sm text-[#2D3A3A] flex items-center gap-1.5">
              <span>{recipientName}</span>
              <span className="text-[10px] bg-[#D4E4BC] text-[#2D5A27] px-2 py-0.2 rounded-full font-bold">
                {recipientRole === 'driver' ? 'চালক' : recipientRole === 'farmer' ? 'কৃষক' : recipientRole === 'laborer' ? 'শ্রমিক' : 'সেবাদাতা'}
              </span>
            </h4>
            {itemTitle && <p className="text-xs text-[#5A6B6B] line-clamp-1">{itemTitle}</p>}
            <p className="text-[11px] text-[#27AE60] flex items-center gap-1 font-semibold">
              <Lock className="w-3 h-3" />
              <span>নম্বর গোপন রেখে সরাসরি অডিও নোট আদান-প্রদান</span>
            </p>
          </div>
        </div>

        {/* Recording Visualizer Area */}
        <div className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#D4C3A3] text-center space-y-4">
          {isRecording ? (
            <div className="space-y-3">
              <div className="relative inline-block">
                <div className="w-20 h-20 rounded-full bg-red-500/20 animate-ping absolute inset-0" />
                <div className="w-20 h-20 rounded-full bg-red-600 text-white flex items-center justify-center relative z-10 shadow-lg mx-auto">
                  <Mic className="w-9 h-9" />
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-bold text-red-600 flex items-center justify-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
                  <span>ভয়েস মেসেজ রেকর্ড হচ্ছে... আপনার বার্তা বলুন</span>
                </p>
                <p className="text-xl font-mono font-bold text-[#2D3A3A]">
                  {formatSec(recordDuration)}
                </p>
                <p className="text-[11px] text-[#736B5E]">সর্বোচ্চ ৬০ সেকেন্ড রেকর্ড করতে পারবেন</p>
              </div>
              <button
                type="button"
                onClick={stopRecording}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition shadow-xs flex items-center gap-1.5 mx-auto cursor-pointer"
              >
                <Square className="w-4 h-4 fill-white" />
                <span>রেকর্ডিং থামান</span>
              </button>
            </div>
          ) : audioBlobUrl ? (
            <div className="space-y-3">
              <div className="w-16 h-16 rounded-2xl bg-[#D4E4BC] text-[#2D5A27] flex items-center justify-center mx-auto shadow-xs">
                <Volume2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-[#2D3A3A]">আপনার রেকর্ডকৃত বার্তা প্রস্তুত</h4>
                <p className="text-xs text-[#736B5E]">দৈর্ঘ্য: {formatSec(recordDuration)}</p>
              </div>

              {/* Mini Audio Player with Progress Bar */}
              <div className="bg-white p-3 rounded-xl border border-[#E6E0D4] space-y-2 max-w-xs mx-auto">
                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={handlePlayPause}
                    className="w-9 h-9 rounded-full bg-[#2D5A27] text-white flex items-center justify-center hover:bg-[#23491E] transition cursor-pointer shadow-xs"
                  >
                    {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
                  </button>
                  <span className="text-xs font-mono font-semibold text-[#5A6B6B]">
                    {formatSec(recordDuration)}
                  </span>
                </div>
                <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-[#2D5A27] h-full transition-all duration-100" 
                    style={{ width: `${playProgress}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-3.5 py-1.5 rounded-xl border border-gray-300 text-gray-700 text-xs font-semibold hover:bg-gray-100 transition flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>পুনরায় রেকর্ড</span>
                </button>
                <button
                  type="button"
                  onClick={handleSend}
                  className="px-5 py-2 rounded-xl bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>ভয়েস বার্তা পাঠান</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="w-16 h-16 rounded-full bg-[#D4E4BC]/50 text-[#2D5A27] flex items-center justify-center mx-auto shadow-inner">
                <Mic className="w-8 h-8 text-[#2D5A27]" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-sm text-[#2D3A3A]">
                  ভয়েস বার্তা পাঠাতে নিচের বাটনে ট্যাপ করুন
                </h4>
                <p className="text-xs text-[#736B5E] max-w-xs mx-auto">
                  টাইপ করতে সমস্যা হলে মুখ দিয়ে কথা বলে দ্রুত বার্তা পাঠান। চালক বা সেবাদাতা এটি শুনতে পাবেন।
                </p>
              </div>

              {permissionError && (
                <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-1.5 text-left">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{permissionError}</span>
                </div>
              )}

              <button
                type="button"
                onClick={startRecording}
                className="px-6 py-2.5 rounded-2xl bg-[#2D5A27] hover:bg-[#23491E] text-white text-xs font-bold transition shadow-sm flex items-center gap-2 mx-auto cursor-pointer"
              >
                <Mic className="w-4 h-4" />
                <span>রেকর্ড শুরু করুন</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer Privacy Info */}
        <div className="flex items-center justify-between text-[11px] text-[#736B5E] pt-1">
          <div className="flex items-center gap-1 text-[#27AE60] font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>১০০% সুরক্ষিত ও ইন-অ্যাপ এনক্রিপ্টেড</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-xs text-gray-500 hover:text-gray-800 cursor-pointer font-medium"
          >
            বন্ধ করুন
          </button>
        </div>

      </div>
    </div>
  );
};
