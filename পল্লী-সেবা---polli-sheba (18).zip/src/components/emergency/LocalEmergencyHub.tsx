import React, { useState, useEffect } from 'react';
import { Phone, MapPin, Shield, Flame, Search, ExternalLink, RefreshCw, AlertCircle } from 'lucide-react';
import { LOCAL_EMERGENCY_DATA, LocalEmergencyContact, getEmergencyContactsForLocation } from '../../data/emergencyData';
import { BANGLADESH_DISTRICTS } from '../../data/mockData';
import { getUpazilasForDistrict } from '../../data/bangladeshLocations';

interface LocalEmergencyHubProps {
  initialDistrict?: string;
  initialUpazila?: string;
  onDistrictChange?: (district: string) => void;
}

export const LocalEmergencyHub: React.FC<LocalEmergencyHubProps> = ({
  initialDistrict = 'পটুয়াখালী',
  initialUpazila = 'সকল উপজেলা',
  onDistrictChange
}) => {
  const [selectedDistrict, setSelectedDistrict] = useState(initialDistrict);
  const [selectedUpazila, setSelectedUpazila] = useState(initialUpazila);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<'all' | 'police' | 'fire_service' | 'hospital'>('all');
  const [contacts, setContacts] = useState<LocalEmergencyContact[]>([]);

  // Available upazilas for selected district
  const availableUpazilas = ['সকল উপজেলা', ...getUpazilasForDistrict(selectedDistrict)];

  useEffect(() => {
    if (initialDistrict && initialDistrict !== selectedDistrict) {
      setSelectedDistrict(initialDistrict);
      setSelectedUpazila('সকল উপজেলা');
    }
  }, [initialDistrict]);

  useEffect(() => {
    let result = getEmergencyContactsForLocation(selectedDistrict, selectedUpazila);

    if (activeCategoryFilter !== 'all') {
      result = result.filter(c => c.category === activeCategoryFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(c => 
        c.name.toLowerCase().includes(q) || 
        c.phone.includes(q) ||
        (c.address && c.address.toLowerCase().includes(q))
      );
    }

    setContacts(result);
  }, [selectedDistrict, selectedUpazila, activeCategoryFilter, searchQuery]);

  const handleDistrictSelect = (dist: string) => {
    setSelectedDistrict(dist);
    setSelectedUpazila('সকল উপজেলা');
    if (onDistrictChange) {
      onDistrictChange(dist);
    }
  };

  const getCategoryBadge = (category: LocalEmergencyContact['category']) => {
    switch (category) {
      case 'police':
        return (
          <span className="inline-flex items-center gap-1 bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
            <Shield className="w-3 h-3" /> থানা পুলিশ
          </span>
        );
      case 'fire_service':
        return (
          <span className="inline-flex items-center gap-1 bg-red-100 text-red-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
            <Flame className="w-3 h-3" /> ফায়ার সার্ভিস
          </span>
        );
      case 'hospital':
        return (
          <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
            🏥 জরুরি হাসপাতাল
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 bg-gray-100 text-gray-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
            জরুরি সেবা
          </span>
        );
    }
  };

  return (
    <div className="emergency-container shadow-xs font-['Noto_Sans_Bengali']">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E6E0D4] pb-3 mb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-red-100 text-red-700 rounded-xl">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm sm:text-base text-[#2D3A3A] flex items-center gap-1.5">
              🚨 স্থানীয় ফায়ার সার্ভিস ও থানা জরুরি সেবা
            </h3>
            <p className="text-xs text-[#736B5E]">
              আপনার নির্বাচিত জেলা ও উপজেলার পুলিশ থানা এবং ফায়ার সার্ভিসের সার্বক্ষণিক নম্বর ও গুগল ম্যাপ লোকেশন
            </p>
          </div>
        </div>

        <span className="self-start sm:self-center text-[10px] bg-red-50 text-red-700 border border-red-200 px-2.5 py-1 rounded-full font-bold">
          ২৪ ঘণ্টা সার্বক্ষণিক জরুরি সেবা
        </span>
      </div>

      {/* District & Upazila Selectors */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-3 bg-[#FAF8F5] p-3 rounded-xl border border-[#E6E0D4]">
        <div>
          <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
            📍 জেলা নির্বাচন করুন:
          </label>
          <select
            value={selectedDistrict}
            onChange={(e) => handleDistrictSelect(e.target.value)}
            className="w-full bg-white border border-[#D4C3A3] rounded-lg p-2 text-xs font-bold text-[#2D5A27] focus:outline-none focus:border-[#2D5A27]"
          >
            {BANGLADESH_DISTRICTS.map((dist) => (
              <option key={dist} value={dist}>
                {dist}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-[#2D3A3A] mb-1">
            🏛️ উপজেলা নির্বাচন করুন:
          </label>
          <select
            value={selectedUpazila}
            onChange={(e) => setSelectedUpazila(e.target.value)}
            className="w-full bg-white border border-[#D4C3A3] rounded-lg p-2 text-xs font-semibold text-[#2D3A3A] focus:outline-none focus:border-[#2D5A27]"
          >
            {availableUpazilas.map((upz) => (
              <option key={upz} value={upz}>
                {upz}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Category Pills & Search */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          <button
            type="button"
            onClick={() => setActiveCategoryFilter('all')}
            className={`text-xs px-2.5 py-1 rounded-lg font-medium cursor-pointer transition ${
              activeCategoryFilter === 'all'
                ? 'bg-[#1e5e3a] text-white font-bold'
                : 'bg-[#FAF8F5] text-[#555] hover:bg-[#EDE8DE]'
            }`}
          >
            সকল সেবা ({contacts.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveCategoryFilter('fire_service')}
            className={`text-xs px-2.5 py-1 rounded-lg font-medium cursor-pointer transition ${
              activeCategoryFilter === 'fire_service'
                ? 'bg-red-600 text-white font-bold'
                : 'bg-[#FAF8F5] text-[#555] hover:bg-[#EDE8DE]'
            }`}
          >
            🔥 ফায়ার সার্ভিস
          </button>
          <button
            type="button"
            onClick={() => setActiveCategoryFilter('police')}
            className={`text-xs px-2.5 py-1 rounded-lg font-medium cursor-pointer transition ${
              activeCategoryFilter === 'police'
                ? 'bg-blue-600 text-white font-bold'
                : 'bg-[#FAF8F5] text-[#555] hover:bg-[#EDE8DE]'
            }`}
          >
            🛡️ থানা পুলিশ
          </button>
          <button
            type="button"
            onClick={() => setActiveCategoryFilter('hospital')}
            className={`text-xs px-2.5 py-1 rounded-lg font-medium cursor-pointer transition ${
              activeCategoryFilter === 'hospital'
                ? 'bg-emerald-700 text-white font-bold'
                : 'bg-[#FAF8F5] text-[#555] hover:bg-[#EDE8DE]'
            }`}
          >
            🏥 হাসপাতাল
          </button>
        </div>

        <div className="relative w-full sm:w-44">
          <input
            type="text"
            placeholder="নম্বর বা নাম খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#FAF8F5] border border-[#E6E0D4] rounded-lg pl-7 pr-2 py-1 text-xs focus:outline-none focus:border-[#1e5e3a]"
          />
          <Search className="w-3.5 h-3.5 text-[#736B5E] absolute left-2 top-2" />
        </div>
      </div>

      {/* Emergency Cards List */}
      <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
        {contacts.length === 0 ? (
          <div className="p-6 text-center bg-[#FAF8F5] rounded-xl border border-[#E6E0D4]">
            <AlertCircle className="w-7 h-7 text-[#736B5E] mx-auto mb-1.5" />
            <p className="text-xs font-bold text-[#2D3A3A]">কোনো জরুরি যোগাযোগ নম্বর পাওয়া যায়নি</p>
            <p className="text-[11px] text-[#736B5E] mt-1">জাতীয় জরুরি হেল্পলাইন ৯৯৯ এ সরাসরি ডায়াল করুন</p>
            <a
              href="tel:999"
              className="inline-flex items-center gap-1.5 bg-red-600 text-white text-xs font-bold px-4 py-1.5 rounded-lg mt-3"
            >
              <Phone className="w-3.5 h-3.5" /> ৯৯৯ এ কল করুন
            </a>
          </div>
        ) : (
          contacts.map((contact) => (
            <div key={contact.id} className="emergency-card">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  {getCategoryBadge(contact.category)}
                  <span className="text-[10px] text-[#736B5E]">
                    {contact.availableHours || '২৪ ঘণ্টা'}
                  </span>
                </div>
                <strong className="text-xs sm:text-sm text-[#2D3A3A] block">
                  {contact.name}
                </strong>
                {contact.address && (
                  <p className="text-[11px] text-[#736B5E] flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-[#E8924A] shrink-0" />
                    {contact.address}
                  </p>
                )}
                <p className="text-xs font-mono font-bold text-[#1e5e3a]">
                  📞 {contact.phone}
                </p>
              </div>

              <div className="flex items-center gap-1.5 shrink-0 pl-2">
                <a
                  href={`tel:${contact.phone.replace(/[^0-9+]/g, '')}`}
                  className="btn-call cursor-pointer shadow-xs active:scale-95"
                  title="সরাসরি কল করুন"
                >
                  <Phone className="w-3.5 h-3.5" /> কল
                </a>
                <a
                  href={contact.mapUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-map cursor-pointer shadow-xs active:scale-95"
                  title="গুগল ম্যাপে লোকেশন দেখুন"
                >
                  <MapPin className="w-3.5 h-3.5" /> ম্যাপ
                </a>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer National Toll Free Bar */}
      <div className="mt-3 pt-2.5 border-t border-[#E6E0D4] flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#736B5E]">
        <div className="flex items-center gap-2">
          <span className="font-bold text-[#2D3A3A]">জাতীয় টোল-ফ্রি হেল্পলাইন:</span>
          <a href="tel:999" className="font-bold text-red-600 hover:underline">৯৯৯ (জরুরি)</a>
          <span>•</span>
          <a href="tel:16123" className="font-bold text-[#2D5A27] hover:underline">১৬১২৩ (কৃষি)</a>
          <span>•</span>
          <a href="tel:16263" className="font-bold text-blue-600 hover:underline">১৬২৬৩ (স্বাস্থ্য)</a>
        </div>

        <span className="text-[10px] text-[#736B5E]">
          পল্লী সেবা হেল্পডেস্ক
        </span>
      </div>
    </div>
  );
};
