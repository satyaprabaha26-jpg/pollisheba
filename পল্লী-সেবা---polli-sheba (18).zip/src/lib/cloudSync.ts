import { 
  collection, 
  doc, 
  setDoc, 
  getDoc,
  getDocs, 
  deleteDoc, 
  onSnapshot,
  updateDoc
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { AdBanner, TransportDriver, BloodDonor, HaatListing, ChatMessage, AdminPermissions, AIComplaintRecord, AISystemQualityReport, ReturnTransportRide, ReportItemRecord } from '../types';
import { HousingListing, MatrimonyListing, HousingMatrimonyReport, isPostExpired } from '../types/housingMatrimony';
import { UserProfile } from '../types/auth';
import { INITIAL_AD_BANNERS, INITIAL_TRANSPORT_DRIVERS, INITIAL_BLOOD_DONORS, INITIAL_RETURN_TRANSPORT_RIDES } from '../data/extendedData';
import { INITIAL_HAAT_LISTINGS } from '../data/mockData';
import { INITIAL_HOUSING_LISTINGS, INITIAL_MATRIMONY_LISTINGS } from '../data/housingMatrimonyData';
import { convertRegisteredUserToTutorListing } from '../utils/tutorHelpers';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMessage = error instanceof Error ? error.message : String(error);
  const errInfo: FirestoreErrorInfo = {
    error: errMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };

  if (errMessage.includes('Missing or insufficient permissions') || (error as { code?: string })?.code === 'permission-denied') {
    console.error('Firestore Permission Error: ', JSON.stringify(errInfo));
    throw new Error(JSON.stringify(errInfo));
  } else {
    console.warn('Firestore notice: ', JSON.stringify(errInfo));
  }
}

/**
 * Deeply sanitizes an object before saving to Firestore
 * Replaces undefined with null or removes undefined keys to prevent Firestore 'Unsupported field value: undefined' errors.
 */
export function sanitizeForFirestore<T>(data: T): T {
  if (data === undefined) {
    return null as unknown as T;
  }
  if (data === null || typeof data !== 'object') {
    return data;
  }
  if (Array.isArray(data)) {
    return data.map(item => sanitizeForFirestore(item)) as unknown as T;
  }
  const sanitized: Record<string, any> = {};
  for (const [key, value] of Object.entries(data)) {
    if (value !== undefined) {
      sanitized[key] = sanitizeForFirestore(value);
    }
  }
  return sanitized as T;
}

export interface AdminCredential {
  id: string;
  name: string;
  phoneOrEmail: string;
  role: 'super_admin' | 'sub_admin';
  pin: string;
  permissions?: string[];
  assignedPermissions?: AdminPermissions;
}

const DEFAULT_SUPER_ADMIN: AdminCredential = {
  id: 'admin-super-master',
  name: 'প্রধান অ্যাডমিন (শাহিনুর রহমান)',
  phoneOrEmail: 'polliseba26@gmail.com',
  role: 'super_admin',
  pin: '7860',
  permissions: ['all'],
  assignedPermissions: {
    canManageAds: true,
    canManageDrivers: true,
    canModerateListings: true,
    canManageHealth: true,
    canViewAnalytics: true
  }
};

/**
 * 1. ADMIN CREDENTIALS CLOUD SYNC
 */
export function subscribeToAdminUsers(onUpdate: (admins: AdminCredential[]) => void) {
  try {
    const q = collection(db, 'admin_users');
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const list: AdminCredential[] = [];
        snapshot.forEach(d => list.push({ ...(d.data() as AdminCredential), id: d.id }));
        localStorage.setItem('polli_admin_users', JSON.stringify(list));
        onUpdate(list);
      } else {
        // Seed default super admin
        setDoc(doc(db, 'admin_users', DEFAULT_SUPER_ADMIN.id), sanitizeForFirestore(DEFAULT_SUPER_ADMIN));
        onUpdate([DEFAULT_SUPER_ADMIN]);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'admin_users');
      const local = localStorage.getItem('polli_admin_users');
      onUpdate(local ? JSON.parse(local) : [DEFAULT_SUPER_ADMIN]);
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'admin_users');
    const local = localStorage.getItem('polli_admin_users');
    onUpdate(local ? JSON.parse(local) : [DEFAULT_SUPER_ADMIN]);
    return () => {};
  }
}

export async function getCloudAdminCredentials(): Promise<AdminCredential[]> {
  try {
    const snap = await getDocs(collection(db, 'admin_users'));
    if (!snap.empty) {
      const list: AdminCredential[] = [];
      snap.forEach(d => list.push(d.data() as AdminCredential));
      return list;
    } else {
      // Seed default
      await setDoc(doc(db, 'admin_users', DEFAULT_SUPER_ADMIN.id), sanitizeForFirestore(DEFAULT_SUPER_ADMIN));
      return [DEFAULT_SUPER_ADMIN];
    }
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'admin_users');
    const local = localStorage.getItem('polli_admin_users');
    return local ? JSON.parse(local) : [DEFAULT_SUPER_ADMIN];
  }
}

export async function saveCloudAdminCredential(admin: AdminCredential): Promise<void> {
  try {
    await setDoc(doc(db, 'admin_users', admin.id), sanitizeForFirestore(admin), { merge: true });
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'admin_users');
  }
}

export async function deleteCloudAdminCredential(adminId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'admin_users', adminId));
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, 'admin_users');
  }
}

/**
 * 2. AD BANNERS REAL-TIME & CLOUD SYNC
 */
export function subscribeToAdBanners(onUpdate: (ads: AdBanner[]) => void) {
  try {
    const q = collection(db, 'ad_banners');
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const ads: AdBanner[] = [];
        snapshot.forEach(docSnap => {
          ads.push({ ...(docSnap.data() as AdBanner), id: docSnap.id });
        });
        localStorage.setItem('polli_ad_banners', JSON.stringify(ads));
        onUpdate(ads);
      } else {
        // Seed initial banners if empty
        INITIAL_AD_BANNERS.forEach(async (b) => {
          await setDoc(doc(db, 'ad_banners', b.id), sanitizeForFirestore(b));
        });
        onUpdate(INITIAL_AD_BANNERS);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'ad_banners');
      const local = localStorage.getItem('polli_ad_banners');
      onUpdate(local ? JSON.parse(local) : INITIAL_AD_BANNERS);
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'ad_banners');
    const local = localStorage.getItem('polli_ad_banners');
    onUpdate(local ? JSON.parse(local) : INITIAL_AD_BANNERS);
    return () => {};
  }
}

export async function saveCloudAdBanner(ad: AdBanner): Promise<void> {
  try {
    await setDoc(doc(db, 'ad_banners', ad.id), sanitizeForFirestore(ad), { merge: true });
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'ad_banners');
  }
}

export async function deleteCloudAdBanner(adId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'ad_banners', adId));
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, 'ad_banners');
  }
}

/**
 * 3. TRANSPORT DRIVERS REAL-TIME & CLOUD SYNC
 */
export function subscribeToDrivers(onUpdate: (drivers: TransportDriver[]) => void) {
  try {
    const q = collection(db, 'transport_drivers');
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const drivers: TransportDriver[] = [];
        snapshot.forEach(docSnap => {
          drivers.push({ ...(docSnap.data() as TransportDriver), id: docSnap.id });
        });
        localStorage.setItem('polli_drivers_list', JSON.stringify(drivers));
        onUpdate(drivers);
      } else {
        // Seed initial drivers
        INITIAL_TRANSPORT_DRIVERS.forEach(async (d) => {
          await setDoc(doc(db, 'transport_drivers', d.id), sanitizeForFirestore(d));
        });
        onUpdate(INITIAL_TRANSPORT_DRIVERS);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'transport_drivers');
      const local = localStorage.getItem('polli_drivers_list');
      onUpdate(local ? JSON.parse(local) : INITIAL_TRANSPORT_DRIVERS);
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'transport_drivers');
    const local = localStorage.getItem('polli_drivers_list');
    onUpdate(local ? JSON.parse(local) : INITIAL_TRANSPORT_DRIVERS);
    return () => {};
  }
}

export async function saveCloudDriver(driver: TransportDriver): Promise<void> {
  try {
    await setDoc(doc(db, 'transport_drivers', driver.id), sanitizeForFirestore(driver), { merge: true });
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'transport_drivers');
  }
}

export async function deleteCloudDriver(driverId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'transport_drivers', driverId));
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, 'transport_drivers');
  }
}

/**
 * 3.1. RETURN TRANSPORT RIDES (ফিরতি পরিবহন) REAL-TIME & CLOUD SYNC
 */
export function subscribeToReturnRides(onUpdate: (rides: ReturnTransportRide[]) => void) {
  try {
    const q = collection(db, 'return_transport_rides');
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const rides: ReturnTransportRide[] = [];
        snapshot.forEach(docSnap => {
          rides.push({ ...(docSnap.data() as ReturnTransportRide), id: docSnap.id });
        });
        localStorage.setItem('polli_return_rides_list', JSON.stringify(rides));
        onUpdate(rides);
      } else {
        // Seed initial return rides if empty
        INITIAL_RETURN_TRANSPORT_RIDES.forEach(async (r) => {
          await setDoc(doc(db, 'return_transport_rides', r.id), sanitizeForFirestore(r));
        });
        onUpdate(INITIAL_RETURN_TRANSPORT_RIDES);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'return_transport_rides');
      const local = localStorage.getItem('polli_return_rides_list');
      onUpdate(local ? JSON.parse(local) : INITIAL_RETURN_TRANSPORT_RIDES);
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'return_transport_rides');
    const local = localStorage.getItem('polli_return_rides_list');
    onUpdate(local ? JSON.parse(local) : INITIAL_RETURN_TRANSPORT_RIDES);
    return () => {};
  }
}

export async function saveCloudReturnRide(ride: ReturnTransportRide): Promise<void> {
  try {
    await setDoc(doc(db, 'return_transport_rides', ride.id), sanitizeForFirestore(ride), { merge: true });
    
    // Also update local storage
    const local = localStorage.getItem('polli_return_rides_list');
    const currentList: ReturnTransportRide[] = local ? JSON.parse(local) : INITIAL_RETURN_TRANSPORT_RIDES;
    const filtered = currentList.filter(r => r.id !== ride.id);
    localStorage.setItem('polli_return_rides_list', JSON.stringify([ride, ...filtered]));
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'return_transport_rides');
  }
}

export async function deleteCloudReturnRide(rideId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'return_transport_rides', rideId));
    const local = localStorage.getItem('polli_return_rides_list');
    if (local) {
      const currentList: ReturnTransportRide[] = JSON.parse(local);
      localStorage.setItem('polli_return_rides_list', JSON.stringify(currentList.filter(r => r.id !== rideId)));
    }
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, 'return_transport_rides');
  }
}

/**
 * FCM Routing Engine for Return Transport:
 * - Driver's Return Ride: Alert goes to ALL registered passengers/citizens in the route/district
 * - Passenger's Return Request: Alert goes ONLY to registered drivers in the route/district
 */
export async function broadcastReturnTransportNotification(ride: ReturnTransportRide): Promise<void> {
  try {
    const isDriverPost = ride.type === 'driver_return';
    const notifId = `notif-ret-${ride.id}`;
    // Dynamic Hour-based validity: নির্দিষ্ট ঘণ্টা পার হওয়ার পর নোটিফিকেশন থেকেও স্বয়ংক্রিয়ভাবে মুছে যাবে
    const expiresAt = ride.expiresAtTimestamp || (Date.now() + (ride.durationHours || 3) * 60 * 60 * 1000);
    
    const routeText = `${ride.fromLocation ? `${ride.fromLocation}, ` : ''}${ride.fromDistrict} ➔ ${ride.toLocation ? `${ride.toLocation}, ` : ''}${ride.toDistrict}`;
    
    const notifTitle = isDriverPost
      ? `🚗 খালি ফিরতি গাড়ি (${ride.vehicleType}): ${routeText}`
      : `🙋‍♂️ ফিরতি গাড়ির যাত্রী আবশ্যক: ${routeText}`;
      
    const notifMessage = isDriverPost
      ? `সাশ্রয়ী ভাড়ায় খালি ফিরতি গাড়ি! বাহন: ${ride.vehicleType} (${ride.capacity})। তারিখ ও সময়: ${ride.departureDate} (${ride.departureTime})। ভাড়া: ${ride.fareType === 'fixed' && ride.fareAmount ? `৳${ride.fareAmount}` : 'আলোচনা সাপেক্ষে'}।`
      : `কম ভাড়ায় ফিরতি গাড়ির খোঁজে যাত্রী পোস্ট দিয়েছেন। বাহন: ${ride.vehicleType} (${ride.capacity})। সময়: ${ride.departureDate} (${ride.departureTime})।`;

    const autoNotif: DemandNotification = {
      id: notifId,
      title: notifTitle,
      message: notifMessage,
      urgency: 'জরুরি',
      targetDistrict: ride.fromDistrict || 'সকল জেলা',
      targetUpazila: ride.fromUpazila || 'সকল উপজেলা',
      targetUnion: ride.fromUnion,
      // FCM Routing Rule:
      // চালকের ফিরতি গাড়ি -> সাধারণ নাগরিক/যাত্রীরা পাবেন (targetRole: 'all')
      // যাত্রীর ফিরতি গাড়ি রিকোয়েস্ট -> শুধুমাত্র চালকেরা পাবেন (targetRole: 'driver')
      targetRole: isDriverPost ? 'all' : 'driver',
      categoryName: 'ফিরতি পরিবহন',
      senderName: ride.creatorName,
      contactNumber: ride.creatorPhone,
      actionUrl: `return_ride:${ride.id}`,
      itemId: ride.id,
      targetCategory: 'transport',
      targetSubTab: 'return_transport',
      createdAt: Date.now(),
      expiresAt: expiresAt,
      createdAtFormatted: 'এইমাত্র',
      allowOfflineCall: ride.allowOfflineCall ?? true,
      senderUserId: ride.creatorId,
      senderAvatar: ride.creatorAvatar
    };

    await saveDemandNotification(autoNotif);
  } catch (err) {
    console.warn('Return transport notification broadcast error:', err);
  }
}

/**
 * 4. BLOOD DONORS REAL-TIME & CLOUD SYNC
 */
export function subscribeToDonors(onUpdate: (donors: BloodDonor[]) => void) {
  try {
    const q = collection(db, 'blood_donors');
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const donors: BloodDonor[] = [];
        snapshot.forEach(docSnap => {
          donors.push({ ...(docSnap.data() as BloodDonor), id: docSnap.id });
        });
        localStorage.setItem('polli_blood_donors', JSON.stringify(donors));
        onUpdate(donors);
      } else {
        INITIAL_BLOOD_DONORS.forEach(async (dn) => {
          await setDoc(doc(db, 'blood_donors', dn.id), sanitizeForFirestore(dn));
        });
        onUpdate(INITIAL_BLOOD_DONORS);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'blood_donors');
      const local = localStorage.getItem('polli_blood_donors');
      onUpdate(local ? JSON.parse(local) : INITIAL_BLOOD_DONORS);
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'blood_donors');
    const local = localStorage.getItem('polli_blood_donors');
    onUpdate(local ? JSON.parse(local) : INITIAL_BLOOD_DONORS);
    return () => {};
  }
}

export async function saveCloudDonor(donor: BloodDonor): Promise<void> {
  try {
    await setDoc(doc(db, 'blood_donors', donor.id), sanitizeForFirestore(donor), { merge: true });
    try {
      const localStr = localStorage.getItem('polli_blood_donors');
      const list: BloodDonor[] = localStr ? JSON.parse(localStr) : [];
      const updated = [donor, ...list.filter(d => d.id !== donor.id)];
      localStorage.setItem('polli_blood_donors', JSON.stringify(updated));
    } catch (e) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'blood_donors');
  }
}

export async function deleteCloudDonor(donorId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'blood_donors', donorId));
    try {
      const localStr = localStorage.getItem('polli_blood_donors');
      if (localStr) {
        const list: BloodDonor[] = JSON.parse(localStr);
        localStorage.setItem('polli_blood_donors', JSON.stringify(list.filter(d => d.id !== donorId)));
      }
    } catch (e) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, 'blood_donors');
  }
}

/**
 * 5. MARKETPLACE / RURAL HAAT REAL-TIME SYNC
 */
export function subscribeToHaatItems(onUpdate: (items: HaatListing[]) => void) {
  try {
    const q = collection(db, 'haat_listings');
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const items: HaatListing[] = [];
        snapshot.forEach(docSnap => {
          items.push({ ...(docSnap.data() as HaatListing), id: docSnap.id });
        });
        localStorage.setItem('polli_marketplace_items', JSON.stringify(items));
        onUpdate(items);
      } else {
        INITIAL_HAAT_LISTINGS.forEach(async (it) => {
          await setDoc(doc(db, 'haat_listings', it.id), sanitizeForFirestore(it));
        });
        onUpdate(INITIAL_HAAT_LISTINGS);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'haat_listings');
      const local = localStorage.getItem('polli_marketplace_items');
      onUpdate(local ? JSON.parse(local) : INITIAL_HAAT_LISTINGS);
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'haat_listings');
    const local = localStorage.getItem('polli_marketplace_items');
    onUpdate(local ? JSON.parse(local) : INITIAL_HAAT_LISTINGS);
    return () => {};
  }
}

export async function saveCloudHaatItem(item: HaatListing): Promise<void> {
  try {
    await setDoc(doc(db, 'haat_listings', item.id), sanitizeForFirestore(item), { merge: true });
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'haat_listings');
  }
}

export async function deleteCloudHaatItem(itemId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'haat_listings', itemId));
    // Clean up corresponding localized demand notification if any
    try {
      await deleteDoc(doc(db, 'demand_notifications', `notif-${itemId}`));
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, 'haat_listings');
  }
}

/**
 * Helper to normalize Bengali numerals (০-৯) to standard English numerals (0-9)
 */
export function normalizeDigitsToEnglish(str: string): string {
  if (!str) return '';
  const bnToEn: Record<string, string> = {
    '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
    '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
  };
  return str.replace(/[০-৯]/g, (ch) => bnToEn[ch] || ch).trim();
}

export function generateSafeUserDocId(user: { id?: string; phone?: string }): string {
  if (user.phone) {
    const enPhone = normalizeDigitsToEnglish(user.phone).replace(/[^0-9]/g, '');
    if (enPhone.length >= 6) {
      return `usr-${enPhone}`;
    }
  }
  if (user.id && user.id.trim()) {
    return user.id.trim();
  }
  return `usr-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
}

/**
 * 6. USER PROFILES & REGISTERED CITIZENS REAL-TIME CLOUD SYNC
 */
export async function saveCloudUserProfile(user: UserProfile): Promise<void> {
  try {
    const docId = generateSafeUserDocId(user);
    const normalizedPhone = normalizeDigitsToEnglish(user.phone || '');
    const updatedUser: UserProfile = {
      ...user,
      id: docId,
      phone: normalizedPhone
    };

    const sanitizedUser = sanitizeForFirestore(updatedUser);
    await setDoc(doc(db, 'registered_users', docId), sanitizedUser, { merge: true });
    
    // Update local cache ONLY if this matches the currently logged-in user
    try {
      const activeCurrentRaw = localStorage.getItem('polli_user_profile');
      if (activeCurrentRaw) {
        const activeCurrent: UserProfile = JSON.parse(activeCurrentRaw);
        const normActivePhone = normalizeDigitsToEnglish(activeCurrent.phone || '');
        if (activeCurrent.id === docId || (normActivePhone && normActivePhone === normalizedPhone)) {
          localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
        }
      } else {
        localStorage.setItem('polli_user_profile', JSON.stringify(updatedUser));
      }
    } catch (err) {}

    try {
      const existingListStr = localStorage.getItem('polli_all_registered_users');
      let existingList: UserProfile[] = existingListStr ? JSON.parse(existingListStr) : [];
      const idx = existingList.findIndex(u => u.id === docId || (u.phone && normalizeDigitsToEnglish(u.phone) === normalizedPhone));
      if (idx >= 0) {
        existingList[idx] = { ...existingList[idx], ...updatedUser };
      } else {
        existingList.unshift(updatedUser);
      }
      localStorage.setItem('polli_all_registered_users', JSON.stringify(existingList));
    } catch (err) {}

    // Track total registered count in stats document
    try {
      await setDoc(doc(db, 'app_stats', 'overview'), {
        lastUserRegisteredAt: new Date().toISOString(),
        lastUpdated: Date.now()
      }, { merge: true });
    } catch (err) {}

    // If registered as driver, auto-save/sync to transport_drivers collection ONLY IF NOT PENDING
    if (updatedUser.role === 'driver' && updatedUser.driverInfo && updatedUser.accountStatus !== 'pending') {
      const driverObj: TransportDriver = {
        id: `drv-${docId}`,
        driverName: updatedUser.name,
        phone: updatedUser.phone,
        vehicleType: updatedUser.driverInfo.vehicleType,
        vehicleNumber: updatedUser.driverInfo.vehicleNumber,
        district: updatedUser.district,
        upazila: updatedUser.upazila,
        unionOrWard: updatedUser.union,
        village: updatedUser.village,
        standLocation: updatedUser.driverInfo.regularRoutes || `${updatedUser.upazila || updatedUser.district} এলাকা`,
        regularRoutes: updatedUser.driverInfo.regularRoutes || 'সারাদেশ',
        serviceShift: updatedUser.driverInfo.serviceShift,
        isNightActive: updatedUser.driverInfo.isNightActive || updatedUser.driverInfo.serviceShift.includes('রাত'),
        isPhoneVerified: updatedUser.isPhoneVerified,
        isVerified: true,
        status: updatedUser.driverInfo.status || 'সচল',
        rating: 5.0
      };
      await saveCloudDriver(driverObj);
    }

    // If registered as tutor/teacher, also auto-save/sync to haat_listings collection
    if (updatedUser.role === 'tutor_student' || updatedUser.tutorInfo) {
      try {
        const tutorListing = convertRegisteredUserToTutorListing(updatedUser);
        await saveCloudHaatItem(tutorListing);
      } catch (err) {
        console.warn('Auto sync tutor listing failed:', err);
      }
    }
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'registered_users');
  }
}

export function subscribeToRegisteredUsers(onUpdate: (users: UserProfile[]) => void) {
  try {
    const q = collection(db, 'registered_users');
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const users: UserProfile[] = [];
        snapshot.forEach(docSnap => {
          const data = docSnap.data() as UserProfile;
          if (data && data.name) {
            users.push(data);
          }
        });
        localStorage.setItem('polli_all_registered_users', JSON.stringify(users));
        // Auto mirror registered tutors to local haat storage so tutor boards display them immediately
        try {
          const localHaat = localStorage.getItem('polli_rural_haat_items');
          const haatItems: HaatListing[] = localHaat ? JSON.parse(localHaat) : [];
          let updated = false;
          users.forEach(u => {
            if (u.role === 'tutor_student' || u.tutorInfo) {
              const tutorItem = convertRegisteredUserToTutorListing(u);
              const exists = haatItems.some(it => it.id === tutorItem.id || (it.phone && tutorItem.phone && it.phone.replace(/\D/g, '') === tutorItem.phone.replace(/\D/g, '')));
              if (!exists) {
                haatItems.unshift(tutorItem);
                updated = true;
              }
            }
          });
          if (updated) {
            localStorage.setItem('polli_rural_haat_items', JSON.stringify(haatItems));
          }
        } catch (syncErr) {
          console.warn('Tutor cache mirror failed:', syncErr);
        }
        onUpdate(users);
      } else {
        const local = localStorage.getItem('polli_all_registered_users');
        onUpdate(local ? JSON.parse(local) : []);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'registered_users');
      const local = localStorage.getItem('polli_all_registered_users');
      onUpdate(local ? JSON.parse(local) : []);
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'registered_users');
    const local = localStorage.getItem('polli_all_registered_users');
    onUpdate(local ? JSON.parse(local) : []);
    return () => {};
  }
}

/**
 * 7. VISITOR & SESSION ANALYTICS TRACKING
 */
export async function recordAppVisit(): Promise<void> {
  try {
    const sessionKey = 'polli_session_tracked';
    if (!sessionStorage.getItem(sessionKey)) {
      sessionStorage.setItem(sessionKey, '1');
      const statsRef = doc(db, 'app_stats', 'overview');
      const snap = await getDoc(statsRef);
      const currentVisits = snap.exists() ? (snap.data()?.totalVisits || 0) : 128;
      await setDoc(statsRef, {
        totalVisits: currentVisits + 1,
        lastVisitAt: new Date().toISOString(),
        lastUpdated: Date.now()
      }, { merge: true });
    }
  } catch (err) {
    // Non-blocking visitor metric recording
  }
}

export function subscribeToAppAnalytics(onUpdate: (stats: { totalVisits: number; lastVisitAt?: string }) => void) {
  try {
    return onSnapshot(doc(db, 'app_stats', 'overview'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        onUpdate({
          totalVisits: data?.totalVisits || 1,
          lastVisitAt: data?.lastVisitAt
        });
      } else {
        onUpdate({ totalVisits: 1 });
      }
    }, () => {
      onUpdate({ totalVisits: 1 });
    });
  } catch {
    return () => {};
  }
}

export async function deleteCloudUser(userIdOrPhone: string, userPhone?: string): Promise<void> {
  try {
    const rawId = userIdOrPhone;
    const phoneId = (userPhone || userIdOrPhone).replace(/[^0-9]/g, '');
    if (phoneId) {
      await deleteDoc(doc(db, 'registered_users', phoneId)).catch(() => {});
    }
    if (rawId && rawId !== phoneId) {
      await deleteDoc(doc(db, 'registered_users', rawId)).catch(() => {});
    }
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, 'registered_users');
  }
}

/**
 * Check if a phone number is already registered in the system (prevents duplicate registrations)
 */
export async function checkPhoneIsRegistered(phone: string): Promise<boolean> {
  try {
    const cleanPhone = normalizeDigitsToEnglish(phone).replace(/[^0-9]/g, '');
    if (!cleanPhone || cleanPhone.length < 6) return false;

    // 1. Check direct doc ID
    const directDocSnap = await getDoc(doc(db, 'registered_users', `usr-${cleanPhone}`));
    if (directDocSnap.exists()) return true;

    const rawSnap = await getDoc(doc(db, 'registered_users', cleanPhone));
    if (rawSnap.exists()) return true;

    // 2. Check local list
    const localStr = localStorage.getItem('polli_all_registered_users');
    if (localStr) {
      const localUsers: UserProfile[] = JSON.parse(localStr);
      if (localUsers.some(u => normalizeDigitsToEnglish(u.phone || '').replace(/[^0-9]/g, '') === cleanPhone)) {
        return true;
      }
    }

    // 3. Fallback: check all registered users collection
    const q = collection(db, 'registered_users');
    const snapshot = await getDocs(q);
    let found = false;
    snapshot.forEach(d => {
      const u = d.data() as UserProfile;
      if (u.phone && normalizeDigitsToEnglish(u.phone).replace(/[^0-9]/g, '') === cleanPhone) {
        found = true;
      }
    });
    return found;
  } catch (e) {
    console.warn('Error checking phone registration:', e);
    // fallback to local check
    const localStr = localStorage.getItem('polli_all_registered_users');
    if (localStr) {
      const cleanPhone = normalizeDigitsToEnglish(phone).replace(/[^0-9]/g, '');
      const localUsers: UserProfile[] = JSON.parse(localStr);
      return localUsers.some(u => normalizeDigitsToEnglish(u.phone || '').replace(/[^0-9]/g, '') === cleanPhone);
    }
    return false;
  }
}

/**
 * Find registered user by phone or email for login
 */
export async function findCloudUserByPhoneOrEmail(identifier: string): Promise<UserProfile | null> {
  try {
    const cleanId = normalizeDigitsToEnglish(identifier).trim();
    const cleanDigits = cleanId.replace(/[^0-9]/g, '');
    const isEmail = cleanId.includes('@');

    // 1. If phone, check direct doc
    if (cleanDigits.length >= 6) {
      const directDocSnap = await getDoc(doc(db, 'registered_users', `usr-${cleanDigits}`));
      if (directDocSnap.exists()) {
        return directDocSnap.data() as UserProfile;
      }
      const rawSnap = await getDoc(doc(db, 'registered_users', cleanDigits));
      if (rawSnap.exists()) {
        return rawSnap.data() as UserProfile;
      }
    }

    // 2. Check local list
    const localStr = localStorage.getItem('polli_all_registered_users');
    if (localStr) {
      const localUsers: UserProfile[] = JSON.parse(localStr);
      const match = localUsers.find(u => {
        if (isEmail && u.email && u.email.toLowerCase() === cleanId.toLowerCase()) return true;
        if (cleanDigits.length >= 6 && u.phone && normalizeDigitsToEnglish(u.phone).replace(/[^0-9]/g, '') === cleanDigits) return true;
        return false;
      });
      if (match) return match;
    }

    // 3. Query collection
    const q = collection(db, 'registered_users');
    const snapshot = await getDocs(q);
    let matchedUser: UserProfile | null = null;
    snapshot.forEach(d => {
      const u = d.data() as UserProfile;
      if (isEmail && u.email && u.email.toLowerCase() === cleanId.toLowerCase()) {
        matchedUser = u;
      } else if (cleanDigits.length >= 6 && u.phone && normalizeDigitsToEnglish(u.phone).replace(/[^0-9]/g, '') === cleanDigits) {
        matchedUser = u;
      }
    });
    return matchedUser;
  } catch (e) {
    console.warn('Error finding user in cloud:', e);
    const localStr = localStorage.getItem('polli_all_registered_users');
    if (localStr) {
      const cleanId = normalizeDigitsToEnglish(identifier).trim();
      const cleanDigits = cleanId.replace(/[^0-9]/g, '');
      const isEmail = cleanId.includes('@');
      const localUsers: UserProfile[] = JSON.parse(localStr);
      return localUsers.find(u => {
        if (isEmail && u.email && u.email.toLowerCase() === cleanId.toLowerCase()) return true;
        if (cleanDigits.length >= 6 && u.phone && normalizeDigitsToEnglish(u.phone).replace(/[^0-9]/g, '') === cleanDigits) return true;
        return false;
      }) || null;
    }
    return null;
  }
}

/**
 * 8. REAL-TIME IN-APP CHAT & MESSAGING CLOUD SYNC
 */
export const CHAT_RETENTION_MS = 7 * 24 * 60 * 60 * 1000; // 7 days retention

export interface ConversationSummary {
  conversationId: string;
  participants: string[];
  lastMessage: string;
  lastMessageTime: number;
  timeFormatted: string;
  senderId: string;
  senderName: string;
  senderRole?: string;
  recipientId: string;
  recipientName: string;
  unreadBy?: string;
  unreadCount?: number;
  updatedAt: number;
}

/**
 * Clean up messages older than 7 days from local cache and in-memory list
 */
export function purgeOldMessages(messages: ChatMessage[]): ChatMessage[] {
  const cutoff = Date.now() - CHAT_RETENTION_MS;
  return messages.filter(m => (m.timestamp || 0) >= cutoff);
}

export function subscribeToUserInbox(userPhoneOrId: string, onUpdate: (conversations: ConversationSummary[]) => void) {
  try {
    const cleanId = normalizeDigitsToEnglish(userPhoneOrId).replace(/[^0-9]/g, '') || userPhoneOrId;
    const q = collection(db, 'conversations_summary');

    return onSnapshot(q, (snapshot) => {
      const list: ConversationSummary[] = [];
      const cutoff = Date.now() - CHAT_RETENTION_MS;

      snapshot.forEach(docSnap => {
        const data = docSnap.data() as ConversationSummary;
        if (data && data.participants && Array.isArray(data.participants)) {
          // Check 7-day cutoff for conversations
          const lastTime = data.updatedAt || data.lastMessageTime || 0;
          if (lastTime < cutoff) return;

          const isParticipant = data.participants.some(p => {
            const cleanP = normalizeDigitsToEnglish(p).replace(/[^0-9]/g, '') || p;
            return cleanP === cleanId || p === userPhoneOrId;
          });
          if (isParticipant) {
            list.push(data);
          }
        }
      });
      list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
      localStorage.setItem(`polli_user_inbox_${cleanId}`, JSON.stringify(list));
      onUpdate(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'conversations_summary');
      const local = localStorage.getItem(`polli_user_inbox_${cleanId}`);
      if (local) {
        const parsed: ConversationSummary[] = JSON.parse(local);
        const cutoff = Date.now() - CHAT_RETENTION_MS;
        onUpdate(parsed.filter(c => (c.updatedAt || 0) >= cutoff));
      } else {
        onUpdate([]);
      }
    });
  } catch (e) {
    const cleanId = normalizeDigitsToEnglish(userPhoneOrId).replace(/[^0-9]/g, '') || userPhoneOrId;
    const local = localStorage.getItem(`polli_user_inbox_${cleanId}`);
    onUpdate(local ? JSON.parse(local) : []);
    return () => {};
  }
}

/**
 * Subscribe to the real-time unread messages count for a specific user
 */
export function subscribeToUnreadInboxCount(
  userPhoneOrId: string, 
  onCountChange: (count: number) => void
) {
  if (!userPhoneOrId) {
    onCountChange(0);
    return () => {};
  }
  const cleanId = normalizeDigitsToEnglish(userPhoneOrId).replace(/[^0-9]/g, '') || userPhoneOrId;
  
  return subscribeToUserInbox(userPhoneOrId, (convos) => {
    const unread = convos.filter(c => {
      const isUnread = c.unreadBy === cleanId || 
        c.unreadBy === userPhoneOrId || 
        (c.unreadBy && normalizeDigitsToEnglish(c.unreadBy).replace(/[^0-9]/g, '') === cleanId);
      return isUnread;
    });
    onCountChange(unread.length);
  });
}

export function subscribeToMessages(conversationId: string, onUpdate: (messages: ChatMessage[]) => void) {
  if (!conversationId) {
    onUpdate([]);
    return () => {};
  }
  const safeConvId = conversationId.replace(/[/\\#?&.\s]/g, '_');
  try {
    const q = collection(db, 'conversations', safeConvId, 'messages');
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        let msgs: ChatMessage[] = [];
        snapshot.forEach(docSnap => {
          msgs.push(docSnap.data() as ChatMessage);
        });
        // Filter by 7-day retention
        msgs = purgeOldMessages(msgs);
        // Sort by timestamp ascending
        msgs.sort((a, b) => a.timestamp - b.timestamp);
        localStorage.setItem(`polli_chat_${safeConvId}`, JSON.stringify(msgs));
        onUpdate(msgs);
      } else {
        const local = localStorage.getItem(`polli_chat_${safeConvId}`);
        if (local) {
          const parsed = purgeOldMessages(JSON.parse(local));
          onUpdate(parsed);
        } else {
          onUpdate([]);
        }
      }
    }, (error) => {
      console.warn('Real-time messages subscription notice:', error);
      const local = localStorage.getItem(`polli_chat_${safeConvId}`);
      onUpdate(local ? purgeOldMessages(JSON.parse(local)) : []);
    });
  } catch (e) {
    console.warn('subscribeToMessages error caught:', e);
    const local = localStorage.getItem(`polli_chat_${safeConvId}`);
    onUpdate(local ? purgeOldMessages(JSON.parse(local)) : []);
    return () => {};
  }
}

export async function saveCloudMessage(message: ChatMessage): Promise<void> {
  const safeConvId = (message.conversationId || 'general').replace(/[/\\#?&.\s]/g, '_');
  const safeMsgId = (message.id || `msg-${Date.now()}`).replace(/[/\\#?&.\s]/g, '_');
  const sanitizedMessage: ChatMessage = {
    ...message,
    conversationId: safeConvId,
    id: safeMsgId
  };

  try {
    // 1. Save message inside conversation subcollection
    const msgRef = doc(db, 'conversations', safeConvId, 'messages', safeMsgId);
    await setDoc(msgRef, sanitizeForFirestore({
      ...sanitizedMessage,
      isRead: false
    }));

    // 2. Also update top-level conversation summary for instant Inbox notifications
    try {
      const summaryRef = doc(db, 'conversations_summary', safeConvId);
      const cleanSender = normalizeDigitsToEnglish(message.senderId || '').replace(/[^0-9]/g, '') || message.senderId || 'user';
      const cleanRecipient = normalizeDigitsToEnglish(message.recipientId || '').replace(/[^0-9]/g, '') || message.recipientId || 'peer';

      await setDoc(summaryRef, {
        conversationId: safeConvId,
        participants: [message.senderId, message.recipientId, cleanSender, cleanRecipient].filter(Boolean),
        lastMessage: message.text,
        lastMessageTime: message.timestamp,
        timeFormatted: message.timeFormatted,
        senderId: message.senderId,
        senderName: message.senderName,
        senderRole: message.senderRole || '',
        recipientId: message.recipientId,
        recipientName: message.recipientName,
        unreadBy: cleanRecipient,
        updatedAt: Date.now()
      }, { merge: true });
    } catch (sumErr) {
      console.warn('Error saving conversation summary:', sumErr);
    }

    // 3. Update local cache immediately with 7-day retention
    try {
      const cacheKey = `polli_chat_${safeConvId}`;
      const localStr = localStorage.getItem(cacheKey);
      let list: ChatMessage[] = localStr ? JSON.parse(localStr) : [];
      if (!list.some(m => m.id === safeMsgId)) {
        list.push(sanitizedMessage);
        list = purgeOldMessages(list);
        localStorage.setItem(cacheKey, JSON.stringify(list));
      }
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `conversations/${safeConvId}/messages`);
  }
}

export async function markConversationRead(conversationId: string, currentUserId: string): Promise<void> {
  if (!conversationId) return;
  const safeConvId = conversationId.replace(/[/\\#?&.\s]/g, '_');
  const cleanId = normalizeDigitsToEnglish(currentUserId || '').replace(/[^0-9]/g, '') || currentUserId || '';
  try {
    const summaryRef = doc(db, 'conversations_summary', safeConvId);
    await setDoc(summaryRef, {
      unreadBy: ''
    }, { merge: true });

    // Update individual unread messages in Firestore to trigger double green ticks for sender
    try {
      const q = collection(db, 'conversations', safeConvId, 'messages');
      const snap = await getDocs(q);
      snap.forEach(async (docSnap) => {
        const data = docSnap.data();
        if (data && !data.isRead && (data.recipientId?.includes(cleanId) || data.senderId !== cleanId)) {
          await updateDoc(docSnap.ref, { 
            isRead: true, 
            isDelivered: true,
            deliveryStatus: 'read' 
          }).catch(() => {});
        }
      });
    } catch {}

    // Also update local messages cache
    try {
      const cacheKey = `polli_chat_${safeConvId}`;
      const localStr = localStorage.getItem(cacheKey);
      if (localStr) {
        const msgs: ChatMessage[] = JSON.parse(localStr);
        const updated = msgs.map(m => {
          if (!m.isRead && (m.recipientId?.includes(cleanId) || m.senderId !== cleanId)) {
            return { ...m, isRead: true, isDelivered: true, deliveryStatus: 'read' as const };
          }
          return m;
        });
        localStorage.setItem(cacheKey, JSON.stringify(updated));
      }
    } catch {}

    // Also update inbox summary local cache
    if (cleanId) {
      const local = localStorage.getItem(`polli_user_inbox_${cleanId}`);
      if (local) {
        const list: ConversationSummary[] = JSON.parse(local);
        const updated = list.map(c => c.conversationId === safeConvId ? { ...c, unreadBy: '' } : c);
        localStorage.setItem(`polli_user_inbox_${cleanId}`, JSON.stringify(updated));
      }
    }
  } catch (err) {
    console.warn('markConversationRead notice:', err);
  }
}

// ==========================================
// 10. SMART AREA-BASED DEMAND NOTIFICATIONS (FCM)
// ==========================================

export interface DemandNotification {
  id: string;
  title: string;
  message: string;
  urgency: 'জরুরি' | 'সাধারণ' | 'সতর্কবার্তা';
  targetDistrict: string; // e.g. 'বগুড়া', or 'সকল জেলা'
  targetUpazila: string;  // e.g. 'শিবগঞ্জ', or 'সকল উপজেলা'
  targetUnion?: string;   // e.g. 'রায়নগর', or 'সকল ইউনিয়ন'
  targetRole: string;     // e.g. 'all', 'laborer', 'farmer', 'driver', etc.
  categoryName?: string;
  senderName: string;
  contactNumber?: string;
  actionUrl?: string;
  itemId?: string;
  targetCategory?: string;
  targetSubTab?: any;
  scope?: 'upazila' | 'district';
  createdAt: number;
  expiresAt?: number;     // Timestamp when notification auto-deletes
  createdAtFormatted?: string;
  allowOfflineCall?: boolean;
  senderUserId?: string;
  senderAvatar?: string;
}

/**
 * Auto-delete TTL Duration calculation based on role:
 * - Driver: 3 hours
 * - Mechanic/Electrician: 7 days
 * - Laborer/Worker: 10 days
 * - Tutor/Teacher: 20 days
 * - Product Sale / All: 15 days
 */
export function calculateNotificationTTL(targetRole?: string): number {
  const role = (targetRole || 'all').toLowerCase().trim();
  if (role === 'driver') {
    return 3 * 60 * 60 * 1000; // 3 hours
  }
  if (role === 'boatman' || role === 'boat' || role === 'ferry_driver') {
    return 24 * 60 * 60 * 1000; // 24 hours for boat / river crossing
  }
  if (role === 'agri_machinery_driver' || role === 'tractor' || role === 'excavator' || role === 'agri_machinery') {
    return 5 * 24 * 60 * 60 * 1000; // 5 days for agricultural machinery / tractor
  }
  if (role === 'mechanic' || role === 'electrician') {
    return 7 * 24 * 60 * 60 * 1000; // 7 days
  }
  if (role === 'laborer' || role === 'worker') {
    return 10 * 24 * 60 * 60 * 1000; // 10 days
  }
  if (role === 'tutor' || role === 'teacher' || role === 'tutor_student') {
    return 20 * 24 * 60 * 60 * 1000; // 20 days
  }
  if (role === 'blood_donor' || role === 'donor') {
    return 48 * 60 * 60 * 1000; // 48 hours for urgent blood demand
  }
  if (role === 'missed_call') {
    return 24 * 60 * 60 * 1000; // 24 hours for missed call alerts
  }
  return 15 * 24 * 60 * 60 * 1000; // 15 days default for goods/crops/cattle
}

/**
 * Interface for Missed Call Audit & Callback
 */
export interface MissedCallRecord {
  id: string;
  callerName: string;
  callerPhone: string;
  callerRole?: string;
  callerSubtitle?: string;
  callerAvatar?: string;
  recipientName: string;
  recipientPhone: string;
  recipientRole?: string;
  recipientSubtitle?: string;
  recipientAvatar?: string;
  timestamp: number;
  formattedDate: string;
  formattedTime: string;
  isCallbackDone?: boolean;
  type?: 'missed' | 'received' | 'outgoing' | 'dialed';
  duration?: string;
  allowOfflineCall?: boolean;
}

/**
 * Helper to check if a user is a registered blood donor in the application
 */
export function isUserRegisteredDonor(phone?: string, role?: string): boolean {
  if (role === 'doctor') return true;
  try {
    const rawDonors = localStorage.getItem('polli_blood_donors');
    if (rawDonors && phone) {
      const donors = JSON.parse(rawDonors);
      const cleanPhone = phone.replace(/[^0-9]/g, '');
      if (Array.isArray(donors) && donors.some((d: any) => d.phone && d.phone.replace(/[^0-9]/g, '') === cleanPhone)) {
        return true;
      }
    }
    const rawProfile = localStorage.getItem('polli_user_profile');
    if (rawProfile) {
      const p = JSON.parse(rawProfile);
      if (p.isBloodDonor || p.bloodGroup) return true;
    }
  } catch (e) {}
  return false;
}

/**
 * Determine if a notification specifically targets a given citizen's location and role.
 * - Blood Requests: Notifies ALL registered blood donors in the specific district & upazila (all blood groups).
 * - Missed Calls: Notifies the specific recipient of the missed call.
 * - Local residents of matching district/upazila receive open notifications (e.g. crop/produce sales).
 * - Specific roles (mechanic, driver, laborer, tutor) receive targeted demands in their region.
 */
export function isNotificationTargetedToUser(
  notif: DemandNotification,
  userDistrict?: string,
  userUpazila?: string,
  userRole?: string,
  userUnion?: string,
  userPhone?: string,
  isRegisteredBloodDonor?: boolean,
  userProfile?: UserProfile
): boolean {
  // Check auto-delete / expiration
  if (notif.expiresAt && notif.expiresAt < Date.now()) {
    return false;
  }

  // Respect user opt-in / opt-out notification settings
  const profile: UserProfile | null = userProfile || (() => {
    try {
      const saved = localStorage.getItem('polli_user_profile');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  })();

  if (profile?.notificationSettings) {
    const s = profile.notificationSettings;
    // Level controls: District / Upazila / Union
    if (notif.targetUnion && notif.targetUnion !== 'সকল ইউনিয়ন' && s.enableUnionAlerts === false) {
      return false;
    }
    if (notif.targetUpazila && notif.targetUpazila !== 'সকল উপজেলা' && s.enableUpazilaAlerts === false) {
      return false;
    }
    if ((!notif.targetUpazila || notif.targetUpazila === 'সকল উপজেলা') && s.enableDistrictAlerts === false) {
      return false;
    }

    // Category controls
    const cat = (notif.categoryName || '').toLowerCase();
    const title = (notif.title || '').toLowerCase();
    const role = (notif.targetRole || '').toLowerCase();

    if ((cat.includes('হাট') || cat.includes('কৃষি') || cat.includes('ফসল') || cat.includes('পণ্য')) && s.enableAgriHaatAlerts === false) {
      return false;
    }
    if ((cat.includes('পরিবহন') || cat.includes('চালক') || cat.includes('গাড়ি') || role.includes('driver')) && s.enableTransportAlerts === false) {
      return false;
    }
    if ((cat.includes('রক্ত') || title.includes('রক্ত') || role.includes('donor')) && s.enableBloodAlerts === false) {
      return false;
    }
    if ((cat.includes('শ্রমিক') || cat.includes('দিনমজুর') || cat.includes('শিক্ষক') || cat.includes('মেকানিক') || role.includes('laborer') || role.includes('tutor') || role.includes('mechanic')) && s.enableLaborTutorAlerts === false) {
      return false;
    }
  }

  // 1. MISSED CALL NOTIFICATION TARGETING
  const isMissedCall = notif.categoryName === 'মিসড কল' || notif.targetRole === 'missed_call';
  if (isMissedCall) {
    if (userPhone && notif.contactNumber) {
      const cleanUserPhone = userPhone.replace(/[^0-9]/g, '');
      const cleanTargetPhone = notif.contactNumber.replace(/[^0-9]/g, '');
      return cleanUserPhone.length > 5 && (cleanUserPhone === cleanTargetPhone || cleanTargetPhone.includes(cleanUserPhone));
    }
    return false;
  }

  // 2. DISTRICT MATCH CHECK:
  // If targetDistrict is 'সকল জেলা', it applies to all.
  // Otherwise, if the user has a district, it must match.
  const isAllDistricts = !notif.targetDistrict || notif.targetDistrict === 'সকল জেলা';
  if (!isAllDistricts) {
    if (!userDistrict) return false;
    const cleanTargetDist = notif.targetDistrict.replace(/ জেলা$/, '').trim().toLowerCase();
    const cleanUserDist = userDistrict.replace(/ জেলা$/, '').trim().toLowerCase();
    if (cleanTargetDist !== cleanUserDist) return false;
  }

  // 3. UPAZILA MATCH CHECK:
  // If targetUpazila is specified and not 'সকল উপজেলা', it only targets users registered in that upazila.
  const isAllUpazilas = !notif.targetUpazila || notif.targetUpazila === 'সকল উপজেলা';
  if (!isAllUpazilas) {
    if (!userUpazila) return false;
    const cleanTargetUpz = notif.targetUpazila.replace(/ উপজেলা$/, '').trim().toLowerCase();
    const cleanUserUpz = userUpazila.replace(/ উপজেলা$/, '').trim().toLowerCase();
    if (!cleanUserUpz.includes(cleanTargetUpz) && !cleanTargetUpz.includes(cleanUserUpz)) {
      return false;
    }
  }

  // 4. UNION MATCH CHECK (if specified and not 'সকল ইউনিয়ন')
  if (notif.targetUnion && notif.targetUnion !== 'সকল ইউনিয়ন') {
    if (userUnion) {
      const cleanTargetUnion = notif.targetUnion.replace(/ ইউনিয়ন$/, '').trim().toLowerCase();
      const cleanUserUnion = userUnion.replace(/ ইউনিয়ন$/, '').trim().toLowerCase();
      if (!cleanUserUnion.includes(cleanTargetUnion) && !cleanTargetUnion.includes(cleanUserUnion)) {
        return false;
      }
    }
  }

  // 5. BLOOD DONOR NOTIFICATION LOGIC (ALL BLOOD GROUPS FOR REGISTERED DONORS IN THAT REGION)
  // Mandate: "যখনই কেউ রক্তের চাহিদা জানিয়ে কোনো নতুন পোস্ট বা আবেদন করবে,
  // সেই পোস্টের জেলা ও উপজেলার সাথে মিল রেখে ওই নির্দিষ্ট অঞ্চলের সকল নিবন্ধিত রক্তদাতার ফোনে তাৎক্ষণিক নোটিফিকেশন যাবে।
  // নোটিফিকেশনটি শুধুমাত্র নির্দিষ্ট রক্তের গ্রুপের মধ্যে সীমাবদ্ধ থাকবে না;
  // যেকোনো রক্তের গ্রুপের নিবন্ধিত রক্তদাতা ওই অঞ্চলে থাকলে সবার কাছেই নোটিফিকেশনটি পৌঁছাবে"
  const isBloodDemand = 
    notif.targetRole === 'blood_donor' ||
    notif.targetRole === 'donor' ||
    (notif.categoryName && notif.categoryName.includes('রক্ত')) ||
    (notif.title && notif.title.includes('রক্তের আবেদন'));

  if (isBloodDemand) {
    // District & Upazila location match has already succeeded above!
    // Check if the current user is a registered blood donor (any blood group):
    if (isRegisteredBloodDonor) return true;
    if (userRole === 'doctor') return true;
    if (userPhone && isUserRegisteredDonor(userPhone, userRole)) return true;
    if (isUserRegisteredDonor(undefined, userRole)) return true;
    return false; // Non-donors do not get emergency donor pings
  }

  // 6. ROLE MATCH CHECK FOR OTHER OCCUPATIONS:
  // When notif.targetRole is 'all', all local residents receive it.
  // When notif.targetRole specifies a role (mechanic, driver, laborer, tutor),
  // ONLY registered users who hold that specific role in that district/upazila receive it.
  if (notif.targetRole && notif.targetRole !== 'all') {
    if (!userRole) {
      // Unregistered or role-less users do not receive role-targeted demand alerts
      return false;
    }

    const target = notif.targetRole.toLowerCase().trim();
    const role = userRole.toLowerCase().trim();

    // Mechanics / Electricians / Makers
    if (target === 'mechanic' || target === 'electrician') {
      return role === 'mechanic';
    }
    // Drivers
    if (target === 'driver') {
      return role === 'driver';
    }
    // Tractor / Excavator / Agri-machinery Drivers
    if (target === 'agri_machinery_driver' || target === 'tractor' || target === 'excavator' || target === 'agri_machinery') {
      return role === 'agri_machinery_driver';
    }
    // Boatmen / Ferry Drivers
    if (target === 'boatman' || target === 'boat' || target === 'ferry_driver') {
      return role === 'boatman';
    }
    // Laborers / Krishin / Day Workers
    if (target === 'laborer' || target === 'worker') {
      return role === 'laborer';
    }
    // Teachers / Tutors / Education
    if (target === 'tutor' || target === 'teacher' || target === 'tutor_student') {
      if (role === 'tutor_student') {
        // If user explicitly registered as student/parent, they are seeking teachers, so do not notify them as teachers
        if (profile?.tutorInfo?.tutorType === 'student_parent') {
          return false;
        }
        return true;
      }
      return role === 'teacher' || role === 'tutor';
    }
    // Farmers
    if (target === 'farmer') {
      return role === 'farmer';
    }

    return role === target;
  }

  return true;
}

/**
 * Automatically broadcast a smart localized notification when a citizen submits a new post/demand
 */
export async function broadcastLocalizedDemandNotification(params: {
  id: string;
  title: string;
  category: string;
  scope: 'upazila' | 'district';
  district: string;
  upazila?: string;
  union?: string;
  sellerName: string;
  phone?: string;
  targetRole?: string;
  targetCategory?: string;
  targetSubTab?: any;
  allowOfflineCall?: boolean;
  senderUserId?: string;
  senderAvatar?: string;
  expiresAt?: number;
}): Promise<void> {
  try {
    const notifId = `notif-${params.id}`;
    const cleanDistrict = params.district && params.district !== 'সকল জেলা' 
      ? params.district 
      : 'সকল জেলা';

    const cleanUpazila = (params.scope === 'upazila' && params.upazila && params.upazila.trim())
      ? params.upazila.trim()
      : 'সকল উপজেলা';

    const cleanUnion = (params.union && params.union.trim() && params.union !== 'সকল ইউনিয়ন')
      ? params.union.trim()
      : undefined;

    const locationNotice = cleanUnion
      ? `${cleanDistrict} জেলার ${cleanUpazila} উপজেলার ${cleanUnion}`
      : (cleanUpazila !== 'সকল উপজেলা'
        ? `${cleanDistrict} জেলার ${cleanUpazila} উপজেলা`
        : `${cleanDistrict} জেলা`);

    const ttl = calculateNotificationTTL(params.targetRole);
    const expiresAt = params.expiresAt || (Date.now() + ttl);

    const autoNotif: DemandNotification = {
      id: notifId,
      title: `${params.category}: ${params.title}`,
      message: `${locationNotice} থেকে ${params.sellerName} এই নতুন বিজ্ঞপ্তিটি পোস্ট করেছেন। সরাসরি দেখতে ও যোগাযোগ করতে ক্লিক করুন।`,
      urgency: 'জরুরি',
      targetDistrict: cleanDistrict,
      targetUpazila: cleanUpazila,
      targetUnion: cleanUnion,
      targetRole: params.targetRole || 'all',
      categoryName: params.category,
      senderName: params.sellerName,
      contactNumber: params.phone,
      actionUrl: `item:${params.id}`,
      itemId: params.id,
      targetCategory: params.targetCategory || 'marketplace',
      targetSubTab: params.targetSubTab,
      scope: params.scope,
      createdAt: Date.now(),
      expiresAt: expiresAt,
      createdAtFormatted: 'এইমাত্র',
      allowOfflineCall: params.allowOfflineCall ?? false,
      senderUserId: params.senderUserId,
      senderAvatar: params.senderAvatar
    };

    await saveDemandNotification(autoNotif);
  } catch (err) {
    console.warn('Auto localized notification dispatch error:', err);
  }
}

export async function saveDemandNotification(notif: DemandNotification): Promise<void> {
  try {
    const notifRef = doc(db, 'demand_notifications', notif.id);
    await setDoc(notifRef, sanitizeForFirestore(notif));

    // Save to local cache
    try {
      const localStr = localStorage.getItem('polli_demand_notifications');
      const list: DemandNotification[] = localStr ? JSON.parse(localStr) : [];
      const updated = [notif, ...list.filter(n => n.id !== notif.id)];
      localStorage.setItem('polli_demand_notifications', JSON.stringify(updated.slice(0, 50)));
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `demand_notifications/${notif.id}`);
  }
}

export async function deleteDemandNotification(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'demand_notifications', id));
    try {
      const localStr = localStorage.getItem('polli_demand_notifications');
      if (localStr) {
        const list: DemandNotification[] = JSON.parse(localStr);
        localStorage.setItem('polli_demand_notifications', JSON.stringify(list.filter(n => n.id !== id)));
      }
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, `demand_notifications/${id}`);
  }
}

export function subscribeToDemandNotifications(
  onUpdate: (notifications: DemandNotification[]) => void
) {
  try {
    const q = collection(db, 'demand_notifications');
    return onSnapshot(q, (snapshot) => {
      const list: DemandNotification[] = [];
      const now = Date.now();
      snapshot.forEach(docSnap => {
        const data = docSnap.data() as DemandNotification;
        if (data) {
          // Check TTL expiration
          if (data.expiresAt && data.expiresAt < now) {
            deleteDoc(doc(db, 'demand_notifications', data.id)).catch(() => {});
          } else {
            list.push(data);
          }
        }
      });
      list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      onUpdate(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'demand_notifications');
      const localStr = localStorage.getItem('polli_demand_notifications');
      if (localStr) {
        const cached: DemandNotification[] = JSON.parse(localStr);
        const now = Date.now();
        onUpdate(cached.filter(n => !n.expiresAt || n.expiresAt >= now));
      } else {
        onUpdate([]);
      }
    });
  } catch (e) {
    const localStr = localStorage.getItem('polli_demand_notifications');
    if (localStr) {
      const cached: DemandNotification[] = JSON.parse(localStr);
      const now = Date.now();
      onUpdate(cached.filter(n => !n.expiresAt || n.expiresAt >= now));
    } else {
      onUpdate([]);
    }
    return () => {};
  }
}

/**
 * Request standard browser Notification permission for smart FCM alerts
 */
export async function requestPushNotificationPermission(): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }
  try {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  } catch (e) {
    console.warn('Push notification permission error:', e);
    return false;
  }
}

/**
 * Super Admin Exclusive: Allows ONLY the main super admin to audit citizen conversations
 * Assistant admins (sub_admin) are strictly prohibited from viewing or accessing user chats.
 */
export function subscribeToSuperAdminChatAudit(
  adminEmail: string,
  onUpdate: (conversations: ConversationSummary[]) => void
) {
  // Enforce Super Admin verification
  const isSuperAdminEmail = adminEmail && (
    adminEmail.toLowerCase().trim() === 'polliseba26@gmail.com'
  );
  if (!isSuperAdminEmail) {
    console.warn('Unauthorized attempt to access chat audits. Assistant admins cannot view user chats.');
    onUpdate([]);
    return () => {};
  }

  try {
    const q = collection(db, 'conversations_summary');
    return onSnapshot(q, (snapshot) => {
      const list: ConversationSummary[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data() as ConversationSummary;
        if (data) {
          list.push(data);
        }
      });
      list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
      onUpdate(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'conversations_summary');
      onUpdate([]);
    });
  } catch (e) {
    onUpdate([]);
    return () => {};
  }
}

// ==========================================
// 12. REAL-TIME CALL SESSIONS (Agora / WebRTC)
// ==========================================

export interface CallSessionData {
  channelId: string;
  callerId: string;
  callerName: string;
  callerAvatar?: string;
  callerRole?: string;
  callerPhone?: string;
  recipientId: string;
  recipientName: string;
  recipientPhone?: string;
  recipientAvatar?: string;
  recipientRole?: string;
  recipientSubtitle?: string;
  status: 'ringing' | 'accepted' | 'rejected' | 'ended' | 'missed';
  createdAt: number;
  acceptedAt?: number;
  endedAt?: number;
  allowOfflineCall?: boolean;
}

/**
 * Creates or updates an active call session in Firestore
 */
export async function createCallSession(session: CallSessionData): Promise<void> {
  const safeChannel = session.channelId.replace(/[/\\#?&.\s]/g, '_');
  try {
    const sessionRef = doc(db, 'call_sessions', safeChannel);
    await setDoc(sessionRef, sanitizeForFirestore({
      ...session,
      channelId: safeChannel
    }), { merge: true });
  } catch (e) {
    console.warn('createCallSession notice:', e);
  }
}

/**
 * Updates call session status (e.g. accepted, rejected, ended, missed)
 */
export async function updateCallSessionStatus(
  channelId: string, 
  status: 'ringing' | 'accepted' | 'rejected' | 'ended' | 'missed'
): Promise<void> {
  const safeChannel = channelId.replace(/[/\\#?&.\s]/g, '_');
  try {
    const sessionRef = doc(db, 'call_sessions', safeChannel);
    await updateDoc(sessionRef, {
      status,
      ...(status === 'accepted' ? { acceptedAt: Date.now() } : {}),
      ...(status === 'ended' || status === 'rejected' || status === 'missed' ? { endedAt: Date.now() } : {})
    });
  } catch (e) {
    console.warn('updateCallSessionStatus notice:', e);
  }
}

/**
 * Subscribes to changes in a specific call session
 */
export function subscribeToCallSession(
  channelId: string, 
  onUpdate: (data: CallSessionData | null) => void
): () => void {
  const safeChannel = channelId.replace(/[/\\#?&.\s]/g, '_');
  try {
    const sessionRef = doc(db, 'call_sessions', safeChannel);
    return onSnapshot(sessionRef, (snap) => {
      if (snap.exists()) {
        onUpdate(snap.data() as CallSessionData);
      } else {
        onUpdate(null);
      }
    }, (err) => {
      console.warn('subscribeToCallSession notice:', err);
    });
  } catch (e) {
    console.warn('subscribeToCallSession caught error:', e);
    return () => {};
  }
}

/**
 * Subscribes to incoming calls destined for the logged-in or guest user
 */
export function subscribeToIncomingCalls(
  myUserIdOrPhone: string,
  onIncomingCall: (session: CallSessionData) => void
): () => void {
  if (!myUserIdOrPhone) return () => {};
  const cleanMyPhone = normalizeDigitsToEnglish(myUserIdOrPhone).replace(/[^0-9]/g, '');

  try {
    const q = collection(db, 'call_sessions');
    return onSnapshot(q, (snapshot) => {
      const now = Date.now();
      snapshot.docChanges().forEach(change => {
        if (change.type === 'added' || change.type === 'modified') {
          const data = change.doc.data() as CallSessionData;
          if (!data) return;

          // Match recipient ID or phone
          const targetClean = normalizeDigitsToEnglish(data.recipientPhone || data.recipientId || '').replace(/[^0-9]/g, '');
          const isTargetMatch = 
            (cleanMyPhone && targetClean && (cleanMyPhone === targetClean || cleanMyPhone.endsWith(targetClean) || targetClean.endsWith(cleanMyPhone))) ||
            data.recipientId === myUserIdOrPhone ||
            data.recipientPhone === myUserIdOrPhone;

          // Must be currently ringing and fresh (within last 50s)
          const isFresh = (now - (data.createdAt || 0)) < 50000;
          if (isTargetMatch && data.status === 'ringing' && isFresh) {
            onIncomingCall(data);
          }
        }
      });
    }, (err) => {
      console.warn('subscribeToIncomingCalls notice:', err);
    });
  } catch (e) {
    console.warn('subscribeToIncomingCalls caught error:', e);
    return () => {};
  }
}

/**
 * 15. Real-Time Online Presence Tracking
 */
export interface UserPresenceData {
  userId: string;
  isOnline: boolean;
  lastActiveAt: number;
}

export function normalizePresenceId(idOrPhone: string): string {
  if (!idOrPhone) return '';
  const digitsOnly = idOrPhone.replace(/[^0-9]/g, '');
  if (digitsOnly.length >= 11) {
    return digitsOnly.slice(-11);
  }
  return idOrPhone.replace(/[/\\#?&.\s]/g, '_');
}

/**
 * Updates a user's online presence status and heartbeat in Firestore
 */
export async function updateUserPresence(userIdOrPhone: string, isOnline: boolean): Promise<void> {
  if (!userIdOrPhone) return;
  const safeId = normalizePresenceId(userIdOrPhone);
  try {
    const presenceRef = doc(db, 'user_presence', safeId);
    await setDoc(presenceRef, sanitizeForFirestore({
      userId: safeId,
      isOnline,
      lastActiveAt: Date.now()
    }), { merge: true });
    // Also store un-normalized key if it differs, for cross compatibility
    const altSafe = userIdOrPhone.replace(/[/\\#?&.\s]/g, '_');
    if (altSafe !== safeId) {
      const altRef = doc(db, 'user_presence', altSafe);
      await setDoc(altRef, sanitizeForFirestore({
        userId: altSafe,
        isOnline,
        lastActiveAt: Date.now()
      }), { merge: true });
    }
  } catch (e) {
    console.warn('updateUserPresence notice:', e);
  }
}

/**
 * Subscribes to a specific user's presence
 */
export function subscribeToUserPresence(
  userIdOrPhone: string,
  callback: (presence: UserPresenceData | null) => void
): () => void {
  if (!userIdOrPhone) {
    callback(null);
    return () => {};
  }
  const safeId = normalizePresenceId(userIdOrPhone);
  try {
    const presenceRef = doc(db, 'user_presence', safeId);
    return onSnapshot(presenceRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data() as UserPresenceData;
        // User considered online if isOnline is true and active within last 5 minutes
        const isFresh = (Date.now() - (data.lastActiveAt || 0)) < 300000;
        callback({
          ...data,
          isOnline: data.isOnline && isFresh
        });
      } else {
        callback(null);
      }
    }, (err) => {
      console.warn('subscribeToUserPresence error:', err);
      callback(null);
    });
  } catch (e) {
    callback(null);
    return () => {};
  }
}

/**
 * Subscribes to all active online users map
 */
export function subscribeToAllOnlineUsers(
  callback: (onlineMap: Record<string, boolean>) => void
): () => void {
  try {
    const q = collection(db, 'user_presence');
    return onSnapshot(q, (snapshot) => {
      const now = Date.now();
      const map: Record<string, boolean> = {};
      snapshot.forEach(docSnap => {
        const data = docSnap.data() as UserPresenceData;
        if (data && data.isOnline && (now - (data.lastActiveAt || 0)) < 300000) {
          map[docSnap.id] = true;
          if (data.userId) {
            map[data.userId] = true;
            const norm = normalizePresenceId(data.userId);
            if (norm) map[norm] = true;
          }
        }
      });
      callback(map);
    }, (err) => {
      console.warn('subscribeToAllOnlineUsers error:', err);
    });
  } catch (e) {
    console.warn('subscribeToAllOnlineUsers caught error:', e);
    return () => {};
  }
}

/**
 * Helper to check if a person is online given their phone or ID and the online map
 */
export function isUserKeyOnline(phoneOrId?: string, onlineMap: Record<string, boolean> = {}): boolean {
  if (!phoneOrId) return false;
  if (onlineMap[phoneOrId]) return true;
  const norm = normalizePresenceId(phoneOrId);
  if (norm && onlineMap[norm]) return true;
  const clean = phoneOrId.replace(/[^0-9]/g, '');
  if (clean && onlineMap[clean]) return true;
  return false;
}

/**
 * 16. AI-DETECTED COMPLAINT & GRIEVANCE MECHANISM
 */
export async function saveCloudAIComplaint(complaint: AIComplaintRecord): Promise<void> {
  try {
    const docRef = doc(db, 'ai_complaints', complaint.id);
    await setDoc(docRef, sanitizeForFirestore(complaint), { merge: true });

    // Also update local storage cache
    try {
      const raw = localStorage.getItem('polli_ai_complaints');
      const list: AIComplaintRecord[] = raw ? JSON.parse(raw) : [];
      const updated = [complaint, ...list.filter(c => c.id !== complaint.id)];
      localStorage.setItem('polli_ai_complaints', JSON.stringify(updated));
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'ai_complaints');
  }
}

export function subscribeToAIComplaints(onUpdate: (complaints: AIComplaintRecord[]) => void): () => void {
  try {
    const q = collection(db, 'ai_complaints');
    return onSnapshot(q, (snapshot) => {
      const list: AIComplaintRecord[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data() as AIComplaintRecord;
        if (data && data.id) {
          list.push(data);
        }
      });
      list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      localStorage.setItem('polli_ai_complaints', JSON.stringify(list));
      onUpdate(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'ai_complaints');
      try {
        const raw = localStorage.getItem('polli_ai_complaints');
        onUpdate(raw ? JSON.parse(raw) : []);
      } catch (e) {
        onUpdate([]);
      }
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'ai_complaints');
    try {
      const raw = localStorage.getItem('polli_ai_complaints');
      onUpdate(raw ? JSON.parse(raw) : []);
    } catch {
      onUpdate([]);
    }
    return () => {};
  }
}

export async function updateAIComplaintStatus(
  id: string, 
  status: 'নতুন' | 'তদন্তাধীন' | 'নিষ্পন্ন',
  adminNotes?: string
): Promise<void> {
  try {
    const docRef = doc(db, 'ai_complaints', id);
    const updateData: Record<string, any> = { status };
    if (adminNotes !== undefined) updateData.adminNotes = adminNotes;
    await updateDoc(docRef, updateData);

    try {
      const raw = localStorage.getItem('polli_ai_complaints');
      if (raw) {
        const list: AIComplaintRecord[] = JSON.parse(raw);
        const updated = list.map(c => c.id === id ? { ...c, status, ...(adminNotes ? { adminNotes } : {}) } : c);
        localStorage.setItem('polli_ai_complaints', JSON.stringify(updated));
      }
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.UPDATE, 'ai_complaints');
  }
}

/**
 * 17. AI SYSTEM QUALITY & IMPROVEMENT REPORTS
 */
export async function saveCloudAISystemReport(report: AISystemQualityReport): Promise<void> {
  try {
    const docRef = doc(db, 'ai_system_reports', report.id);
    await setDoc(docRef, sanitizeForFirestore(report), { merge: true });

    try {
      const raw = localStorage.getItem('polli_ai_system_reports');
      const list: AISystemQualityReport[] = raw ? JSON.parse(raw) : [];
      const updated = [report, ...list.filter(r => r.id !== report.id)];
      localStorage.setItem('polli_ai_system_reports', JSON.stringify(updated));
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'ai_system_reports');
  }
}

export function subscribeToAISystemReports(onUpdate: (reports: AISystemQualityReport[]) => void): () => void {
  try {
    const q = collection(db, 'ai_system_reports');
    return onSnapshot(q, (snapshot) => {
      const list: AISystemQualityReport[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data() as AISystemQualityReport;
        if (data && data.id) {
          list.push(data);
        }
      });
      list.sort((a, b) => (b.generatedAt || 0) - (a.generatedAt || 0));
      localStorage.setItem('polli_ai_system_reports', JSON.stringify(list));
      onUpdate(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'ai_system_reports');
      try {
        const raw = localStorage.getItem('polli_ai_system_reports');
        onUpdate(raw ? JSON.parse(raw) : []);
      } catch {
        onUpdate([]);
      }
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'ai_system_reports');
    try {
      const raw = localStorage.getItem('polli_ai_system_reports');
      onUpdate(raw ? JSON.parse(raw) : []);
    } catch {
      onUpdate([]);
    }
    return () => {};
  }
}

/**
 * 18. HOUSING & RENTAL LISTINGS (আবাসন মডিউল)
 */
export async function saveCloudHousingListing(listing: HousingListing): Promise<void> {
  try {
    const docRef = doc(db, 'housing_listings', listing.id);
    await setDoc(docRef, sanitizeForFirestore(listing), { merge: true });

    try {
      const raw = localStorage.getItem('polli_housing_listings');
      const list: HousingListing[] = raw ? JSON.parse(raw) : INITIAL_HOUSING_LISTINGS;
      const updated = [listing, ...list.filter(item => item.id !== listing.id)];
      localStorage.setItem('polli_housing_listings', JSON.stringify(updated));
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'housing_listings');
    try {
      const raw = localStorage.getItem('polli_housing_listings');
      const list: HousingListing[] = raw ? JSON.parse(raw) : INITIAL_HOUSING_LISTINGS;
      const updated = [listing, ...list.filter(item => item.id !== listing.id)];
      localStorage.setItem('polli_housing_listings', JSON.stringify(updated));
    } catch (err) {}
  }
}

export async function deleteCloudHousingListing(id: string): Promise<void> {
  try {
    const docRef = doc(db, 'housing_listings', id);
    await deleteDoc(docRef);

    try {
      const raw = localStorage.getItem('polli_housing_listings');
      if (raw) {
        const list: HousingListing[] = JSON.parse(raw);
        const filtered = list.filter(item => item.id !== id);
        localStorage.setItem('polli_housing_listings', JSON.stringify(filtered));
      }
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, 'housing_listings');
    try {
      const raw = localStorage.getItem('polli_housing_listings');
      if (raw) {
        const list: HousingListing[] = JSON.parse(raw);
        const filtered = list.filter(item => item.id !== id);
        localStorage.setItem('polli_housing_listings', JSON.stringify(filtered));
      }
    } catch (err) {}
  }
}

export function subscribeToHousingListings(onUpdate: (listings: HousingListing[]) => void): () => void {
  try {
    const q = collection(db, 'housing_listings');
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const list: HousingListing[] = [];
        snapshot.forEach(docSnap => {
          const data = docSnap.data() as HousingListing;
          if (data && data.id) {
            list.push(data);
          }
        });
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        localStorage.setItem('polli_housing_listings', JSON.stringify(list));
        onUpdate(list);
      } else {
        const raw = localStorage.getItem('polli_housing_listings');
        if (raw) {
          try {
            onUpdate(JSON.parse(raw));
            return;
          } catch {}
        }
        localStorage.setItem('polli_housing_listings', JSON.stringify(INITIAL_HOUSING_LISTINGS));
        onUpdate(INITIAL_HOUSING_LISTINGS);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'housing_listings');
      try {
        const raw = localStorage.getItem('polli_housing_listings');
        onUpdate(raw ? JSON.parse(raw) : INITIAL_HOUSING_LISTINGS);
      } catch {
        onUpdate(INITIAL_HOUSING_LISTINGS);
      }
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'housing_listings');
    try {
      const raw = localStorage.getItem('polli_housing_listings');
      onUpdate(raw ? JSON.parse(raw) : INITIAL_HOUSING_LISTINGS);
    } catch {
      onUpdate(INITIAL_HOUSING_LISTINGS);
    }
    return () => {};
  }
}

/**
 * 19. MATCHMAKING LISTINGS (পাত্র-পাত্রীর সন্ধান মডিউল)
 */
export async function saveCloudMatrimonyListing(listing: MatrimonyListing): Promise<void> {
  try {
    const docRef = doc(db, 'matrimony_listings', listing.id);
    await setDoc(docRef, sanitizeForFirestore(listing), { merge: true });

    try {
      const raw = localStorage.getItem('polli_matrimony_listings');
      const list: MatrimonyListing[] = raw ? JSON.parse(raw) : INITIAL_MATRIMONY_LISTINGS;
      const updated = [listing, ...list.filter(item => item.id !== listing.id)];
      localStorage.setItem('polli_matrimony_listings', JSON.stringify(updated));
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'matrimony_listings');
    try {
      const raw = localStorage.getItem('polli_matrimony_listings');
      const list: MatrimonyListing[] = raw ? JSON.parse(raw) : INITIAL_MATRIMONY_LISTINGS;
      const updated = [listing, ...list.filter(item => item.id !== listing.id)];
      localStorage.setItem('polli_matrimony_listings', JSON.stringify(updated));
    } catch (err) {}
  }
}

export async function deleteCloudMatrimonyListing(id: string): Promise<void> {
  try {
    const docRef = doc(db, 'matrimony_listings', id);
    await deleteDoc(docRef);

    try {
      const raw = localStorage.getItem('polli_matrimony_listings');
      if (raw) {
        const list: MatrimonyListing[] = JSON.parse(raw);
        const filtered = list.filter(item => item.id !== id);
        localStorage.setItem('polli_matrimony_listings', JSON.stringify(filtered));
      }
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, 'matrimony_listings');
    try {
      const raw = localStorage.getItem('polli_matrimony_listings');
      if (raw) {
        const list: MatrimonyListing[] = JSON.parse(raw);
        const filtered = list.filter(item => item.id !== id);
        localStorage.setItem('polli_matrimony_listings', JSON.stringify(filtered));
      }
    } catch (err) {}
  }
}

export function subscribeToMatrimonyListings(onUpdate: (listings: MatrimonyListing[]) => void): () => void {
  try {
    const q = collection(db, 'matrimony_listings');
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const list: MatrimonyListing[] = [];
        snapshot.forEach(docSnap => {
          const data = docSnap.data() as MatrimonyListing;
          if (data && data.id) {
            list.push(data);
          }
        });
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        localStorage.setItem('polli_matrimony_listings', JSON.stringify(list));
        onUpdate(list);
      } else {
        const raw = localStorage.getItem('polli_matrimony_listings');
        if (raw) {
          try {
            onUpdate(JSON.parse(raw));
            return;
          } catch {}
        }
        localStorage.setItem('polli_matrimony_listings', JSON.stringify(INITIAL_MATRIMONY_LISTINGS));
        onUpdate(INITIAL_MATRIMONY_LISTINGS);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'matrimony_listings');
      try {
        const raw = localStorage.getItem('polli_matrimony_listings');
        onUpdate(raw ? JSON.parse(raw) : INITIAL_MATRIMONY_LISTINGS);
      } catch {
        onUpdate(INITIAL_MATRIMONY_LISTINGS);
      }
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'matrimony_listings');
    try {
      const raw = localStorage.getItem('polli_matrimony_listings');
      onUpdate(raw ? JSON.parse(raw) : INITIAL_MATRIMONY_LISTINGS);
    } catch {
      onUpdate(INITIAL_MATRIMONY_LISTINGS);
    }
    return () => {};
  }
}

/**
 * 20. HOUSING & MATRIMONY USER REPORTS (অভিযোগ ও আংশিক নিষেধাজ্ঞা ব্যবস্থা)
 */
export async function saveCloudHousingMatrimonyReport(report: HousingMatrimonyReport): Promise<void> {
  try {
    const docRef = doc(db, 'housing_matrimony_reports', report.id);
    await setDoc(docRef, sanitizeForFirestore(report), { merge: true });

    try {
      const raw = localStorage.getItem('polli_housing_matrimony_reports');
      const list: HousingMatrimonyReport[] = raw ? JSON.parse(raw) : [];
      const updated = [report, ...list.filter(r => r.id !== report.id)];
      localStorage.setItem('polli_housing_matrimony_reports', JSON.stringify(updated));
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, 'housing_matrimony_reports');
    try {
      const raw = localStorage.getItem('polli_housing_matrimony_reports');
      const list: HousingMatrimonyReport[] = raw ? JSON.parse(raw) : [];
      const updated = [report, ...list.filter(r => r.id !== report.id)];
      localStorage.setItem('polli_housing_matrimony_reports', JSON.stringify(updated));
    } catch (err) {}
  }
}

export async function updateCloudHousingMatrimonyReportStatus(
  id: string,
  status: 'নতুন' | 'তদন্তাধীন' | 'নিষ্পন্ন',
  action?: 'banned' | 'dismissed' | 'deleted_post',
  adminNotes?: string
): Promise<void> {
  try {
    const docRef = doc(db, 'housing_matrimony_reports', id);
    const updateData: Record<string, any> = { status };
    if (action) updateData.adminActionTaken = action;
    if (adminNotes !== undefined) updateData.adminNotes = adminNotes;
    await updateDoc(docRef, updateData);

    try {
      const raw = localStorage.getItem('polli_housing_matrimony_reports');
      if (raw) {
        const list: HousingMatrimonyReport[] = JSON.parse(raw);
        const updated = list.map(r => r.id === id ? { ...r, status, ...(action ? { adminActionTaken: action } : {}), ...(adminNotes ? { adminNotes } : {}) } : r);
        localStorage.setItem('polli_housing_matrimony_reports', JSON.stringify(updated));
      }
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.UPDATE, 'housing_matrimony_reports');
  }
}

export function subscribeToHousingMatrimonyReports(onUpdate: (reports: HousingMatrimonyReport[]) => void): () => void {
  try {
    const q = collection(db, 'housing_matrimony_reports');
    return onSnapshot(q, (snapshot) => {
      const list: HousingMatrimonyReport[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data() as HousingMatrimonyReport;
        if (data && data.id) {
          list.push(data);
        }
      });
      list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      localStorage.setItem('polli_housing_matrimony_reports', JSON.stringify(list));
      onUpdate(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'housing_matrimony_reports');
      try {
        const raw = localStorage.getItem('polli_housing_matrimony_reports');
        onUpdate(raw ? JSON.parse(raw) : []);
      } catch {
        onUpdate([]);
      }
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.GET, 'housing_matrimony_reports');
    try {
      const raw = localStorage.getItem('polli_housing_matrimony_reports');
      onUpdate(raw ? JSON.parse(raw) : []);
    } catch {
      onUpdate([]);
    }
    return () => {};
  }
}

/**
 * 21. PARTIAL BAN CONTROLLER: সেট করুন ইউজার কি আবাসন ও পাত্র-পাত্রীতে নিষিদ্ধ কিনা
 */
export async function setUserHousingMatrimonyRestriction(userId: string, isRestricted: boolean): Promise<void> {
  try {
    const docRef = doc(db, 'registered_users', userId);
    await updateDoc(docRef, { isRestrictedFromHousingAndMatrimony: isRestricted });

    // Update local storage registered users
    try {
      const raw = localStorage.getItem('polli_registered_users');
      if (raw) {
        const list: UserProfile[] = JSON.parse(raw);
        const updated = list.map(u => u.id === userId ? { ...u, isRestrictedFromHousingAndMatrimony: isRestricted } : u);
        localStorage.setItem('polli_registered_users', JSON.stringify(updated));
      }
      // Also update currently active logged in user profile if matching
      const currentRaw = localStorage.getItem('polli_user_profile');
      if (currentRaw) {
        const current: UserProfile = JSON.parse(currentRaw);
        if (current.id === userId) {
          current.isRestrictedFromHousingAndMatrimony = isRestricted;
          localStorage.setItem('polli_user_profile', JSON.stringify(current));
        }
      }
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.UPDATE, 'registered_users');
    try {
      const raw = localStorage.getItem('polli_registered_users');
      if (raw) {
        const list: UserProfile[] = JSON.parse(raw);
        const updated = list.map(u => u.id === userId ? { ...u, isRestrictedFromHousingAndMatrimony: isRestricted } : u);
        localStorage.setItem('polli_registered_users', JSON.stringify(updated));
      }
      const currentRaw = localStorage.getItem('polli_user_profile');
      if (currentRaw) {
        const current: UserProfile = JSON.parse(currentRaw);
        if (current.id === userId) {
          current.isRestrictedFromHousingAndMatrimony = isRestricted;
          localStorage.setItem('polli_user_profile', JSON.stringify(current));
        }
      }
    } catch (err) {}
  }
}

/**
 * 21.1. FULL ACCOUNT BAN CONTROLLER (এডমিন কর্তৃক সম্পূর্ণ নাগরিক একাউন্ট ব্লক ও আনব্লক)
 */
export async function setUserAccountBlocked(userId: string, isBlocked: boolean): Promise<void> {
  try {
    const docRef = doc(db, 'registered_users', userId);
    await updateDoc(docRef, { isAccountBlocked: isBlocked });

    try {
      const raw = localStorage.getItem('polli_registered_users');
      if (raw) {
        const list: UserProfile[] = JSON.parse(raw);
        const updated = list.map(u => u.id === userId ? { ...u, isAccountBlocked: isBlocked } : u);
        localStorage.setItem('polli_registered_users', JSON.stringify(updated));
      }
      const currentRaw = localStorage.getItem('polli_user_profile');
      if (currentRaw) {
        const current: UserProfile = JSON.parse(currentRaw);
        if (current.id === userId) {
          current.isAccountBlocked = isBlocked;
          localStorage.setItem('polli_user_profile', JSON.stringify(current));
        }
      }
    } catch (err) {}
  } catch (e) {
    handleFirestoreError(e, OperationType.UPDATE, 'registered_users');
    try {
      const raw = localStorage.getItem('polli_registered_users');
      if (raw) {
        const list: UserProfile[] = JSON.parse(raw);
        const updated = list.map(u => u.id === userId ? { ...u, isAccountBlocked: isBlocked } : u);
        localStorage.setItem('polli_registered_users', JSON.stringify(updated));
      }
    } catch (err) {}
  }
}

/**
 * 22. USER-LEVEL BLOCK CONTROLLER (ব্যবহারকারী পর্যায়ে ব্লক/আনব্লক সিস্টেম)
 */
export async function toggleBlockUser(
  currentUserId: string,
  targetUserIdOrPhone: string,
  blockAction: boolean
): Promise<{ success: boolean; isBlocked: boolean }> {
  try {
    const cleanCurrent = normalizeDigitsToEnglish(currentUserId || '').replace(/[^0-9]/g, '') || currentUserId;
    const cleanTarget = normalizeDigitsToEnglish(targetUserIdOrPhone || '').replace(/[^0-9]/g, '') || targetUserIdOrPhone;
    if (!cleanCurrent || !cleanTarget) return { success: false, isBlocked: false };

    // Update in localStorage active user
    let userProfile: UserProfile | null = null;
    const currentRaw = localStorage.getItem('polli_user_profile');
    if (currentRaw) {
      userProfile = JSON.parse(currentRaw);
    }

    let blockedList: string[] = userProfile?.blockedUsers || [];
    if (blockAction) {
      if (!blockedList.includes(cleanTarget)) {
        blockedList.push(cleanTarget);
      }
      if (!blockedList.includes(targetUserIdOrPhone)) {
        blockedList.push(targetUserIdOrPhone);
      }
    } else {
      blockedList = blockedList.filter(id => id !== cleanTarget && id !== targetUserIdOrPhone);
    }

    if (userProfile) {
      userProfile.blockedUsers = blockedList;
      localStorage.setItem('polli_user_profile', JSON.stringify(userProfile));
      // Save to cloud user profile
      await saveCloudUserProfile(userProfile);
    }

    // Also store dedicated blocked list in localStorage for instant offline access
    localStorage.setItem(`polli_blocked_by_${cleanCurrent}`, JSON.stringify(blockedList));

    // Save blocked list mapping in Firestore
    try {
      const blockDocRef = doc(db, 'user_blocks', cleanCurrent);
      await setDoc(blockDocRef, {
        userId: cleanCurrent,
        blockedUsers: blockedList,
        updatedAt: Date.now()
      }, { merge: true });
    } catch (e) {
      console.warn('Firestore user_blocks sync note:', e);
    }

    return { success: true, isBlocked: blockAction };
  } catch (err) {
    console.warn('toggleBlockUser error:', err);
    return { success: false, isBlocked: false };
  }
}

/**
 * Checks if targetUserIdOrPhone is blocked by currentUserId or vice versa
 */
export function isUserBlocked(
  currentUserIdOrPhone?: string,
  targetUserIdOrPhone?: string,
  currentUserProfile?: UserProfile | null
): boolean {
  if (!currentUserIdOrPhone || !targetUserIdOrPhone) return false;
  const cleanCurrent = normalizeDigitsToEnglish(currentUserIdOrPhone).replace(/[^0-9]/g, '') || currentUserIdOrPhone;
  const cleanTarget = normalizeDigitsToEnglish(targetUserIdOrPhone).replace(/[^0-9]/g, '') || targetUserIdOrPhone;

  // 1. Check profile object blockedUsers list
  if (currentUserProfile?.blockedUsers && Array.isArray(currentUserProfile.blockedUsers)) {
    if (currentUserProfile.blockedUsers.some(b => {
      const cleanB = normalizeDigitsToEnglish(b).replace(/[^0-9]/g, '') || b;
      return cleanB === cleanTarget || b === targetUserIdOrPhone;
    })) {
      return true;
    }
  }

  // 2. Check localStorage blocked list
  try {
    const raw = localStorage.getItem(`polli_blocked_by_${cleanCurrent}`);
    if (raw) {
      const list: string[] = JSON.parse(raw);
      if (list.some(b => {
        const cleanB = normalizeDigitsToEnglish(b).replace(/[^0-9]/g, '') || b;
        return cleanB === cleanTarget || b === targetUserIdOrPhone;
      })) {
        return true;
      }
    }
  } catch {}

  return false;
}

/**
 * 23. MISSED CALLS BADGE & COUNTER CONTROLLER
 */
export function getStoredMissedCallsCount(userIdOrPhone?: string): number {
  try {
    const raw = localStorage.getItem('polli_missed_calls');
    if (!raw) return 0;
    const list: MissedCallRecord[] = JSON.parse(raw);
    if (!userIdOrPhone) return list.filter(m => !m.isCallbackDone).length;
    
    const cleanId = normalizeDigitsToEnglish(userIdOrPhone).replace(/[^0-9]/g, '');
    const unread = list.filter(m => {
      if (m.isCallbackDone) return false;
      const cleanRec = normalizeDigitsToEnglish(m.recipientPhone || '').replace(/[^0-9]/g, '');
      return cleanRec === cleanId || cleanRec.endsWith(cleanId) || cleanId.endsWith(cleanRec);
    });
    return unread.length;
  } catch {
    return 0;
  }
}

export function resetMissedCallsBadge(userIdOrPhone?: string): void {
  try {
    const raw = localStorage.getItem('polli_missed_calls');
    if (!raw) return;
    const list: MissedCallRecord[] = JSON.parse(raw);
    const updated = list.map(m => ({ ...m, isCallbackDone: true }));
    localStorage.setItem('polli_missed_calls', JSON.stringify(updated));
    window.dispatchEvent(new Event('polli_missed_calls_updated'));
  } catch {}
}

// 23. Citizen Reports & Fake Account Moderation Cloud Sync
export async function saveCloudCitizenReport(report: ReportItemRecord): Promise<void> {
  try {
    const docRef = doc(db, 'citizen_reports', report.id);
    await setDoc(docRef, report, { merge: true });
    try {
      const raw = localStorage.getItem('polli_reports_list');
      const list: ReportItemRecord[] = raw ? JSON.parse(raw) : [];
      const updated = [report, ...list.filter(r => r.id !== report.id)];
      localStorage.setItem('polli_reports_list', JSON.stringify(updated));
      window.dispatchEvent(new Event('polli_citizen_reports_updated'));
    } catch {}
  } catch (e) {
    handleFirestoreError(e, OperationType.CREATE, 'citizen_reports');
  }
}

export function subscribeToCitizenReports(onUpdate: (reports: ReportItemRecord[]) => void): () => void {
  try {
    const q = collection(db, 'citizen_reports');
    return onSnapshot(q, (snapshot) => {
      const list: ReportItemRecord[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data() as ReportItemRecord;
        if (data && data.id) {
          list.push(data);
        }
      });
      list.sort((a, b) => (b.createdAtTimestamp || 0) - (a.createdAtTimestamp || 0));
      localStorage.setItem('polli_reports_list', JSON.stringify(list));
      onUpdate(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'citizen_reports');
      try {
        const raw = localStorage.getItem('polli_reports_list');
        onUpdate(raw ? JSON.parse(raw) : []);
      } catch {
        onUpdate([]);
      }
    });
  } catch {
    const raw = localStorage.getItem('polli_reports_list');
    onUpdate(raw ? JSON.parse(raw) : []);
    return () => {};
  }
}

export async function updateCloudCitizenReportStatus(
  id: string, 
  status: 'নতুন' | 'তদন্তাধীন' | 'সমাধানকৃত',
  adminActionTaken?: string,
  adminNotes?: string
): Promise<void> {
  try {
    const docRef = doc(db, 'citizen_reports', id);
    const updateData: Record<string, any> = { status };
    if (adminActionTaken) updateData.adminActionTaken = adminActionTaken;
    if (adminNotes) updateData.adminNotes = adminNotes;
    await updateDoc(docRef, updateData);

    try {
      const raw = localStorage.getItem('polli_reports_list');
      if (raw) {
        const list: ReportItemRecord[] = JSON.parse(raw);
        const updated = list.map(r => r.id === id ? { ...r, status, ...(adminActionTaken ? { adminActionTaken } : {}), ...(adminNotes ? { adminNotes } : {}) } : r);
        localStorage.setItem('polli_reports_list', JSON.stringify(updated));
        window.dispatchEvent(new Event('polli_citizen_reports_updated'));
      }
    } catch {}
  } catch (e) {
    handleFirestoreError(e, OperationType.UPDATE, 'citizen_reports');
  }
}

export async function deleteCloudCitizenReport(id: string): Promise<void> {
  try {
    const docRef = doc(db, 'citizen_reports', id);
    await deleteDoc(docRef);
    try {
      const raw = localStorage.getItem('polli_reports_list');
      if (raw) {
        const list: ReportItemRecord[] = JSON.parse(raw);
        const updated = list.filter(r => r.id !== id);
        localStorage.setItem('polli_reports_list', JSON.stringify(updated));
        window.dispatchEvent(new Event('polli_citizen_reports_updated'));
      }
    } catch {}
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, 'citizen_reports');
  }
}

// 24. CLOUD CALL RECORDS & INBOX CALL HISTORY SYNC (Requirement 1 & 2)
export async function saveCloudCallRecord(record: MissedCallRecord): Promise<void> {
  try {
    const docRef = doc(db, 'call_records', record.id);
    await setDoc(docRef, record, { merge: true });
    try {
      const raw = localStorage.getItem('polli_missed_calls');
      const list: MissedCallRecord[] = raw ? JSON.parse(raw) : [];
      const updated = [record, ...list.filter(m => m.id !== record.id)];
      localStorage.setItem('polli_missed_calls', JSON.stringify(updated));
      window.dispatchEvent(new Event('polli_missed_calls_updated'));
    } catch {}
  } catch (e) {
    handleFirestoreError(e, OperationType.CREATE, 'call_records');
    try {
      const raw = localStorage.getItem('polli_missed_calls');
      const list: MissedCallRecord[] = raw ? JSON.parse(raw) : [];
      const updated = [record, ...list.filter(m => m.id !== record.id)];
      localStorage.setItem('polli_missed_calls', JSON.stringify(updated));
      window.dispatchEvent(new Event('polli_missed_calls_updated'));
    } catch {}
  }
}

export function subscribeToUserCalls(
  userPhoneOrId: string,
  onUpdate: (calls: MissedCallRecord[]) => void
): () => void {
  const cleanId = normalizeDigitsToEnglish(userPhoneOrId).replace(/[^0-9]/g, '');
  try {
    const q = collection(db, 'call_records');
    return onSnapshot(q, (snapshot) => {
      const list: MissedCallRecord[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data() as MissedCallRecord;
        if (data && data.id) {
          const recPhone = normalizeDigitsToEnglish(data.recipientPhone || '').replace(/[^0-9]/g, '');
          const callPhone = normalizeDigitsToEnglish(data.callerPhone || '').replace(/[^0-9]/g, '');
          if (!cleanId || recPhone === cleanId || recPhone.endsWith(cleanId) || cleanId.endsWith(recPhone) ||
              callPhone === cleanId || callPhone.endsWith(cleanId) || cleanId.endsWith(callPhone)) {
            list.push(data);
          }
        }
      });
      list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      try {
        const localRaw = localStorage.getItem('polli_missed_calls');
        const localList: MissedCallRecord[] = localRaw ? JSON.parse(localRaw) : [];
        const mergedMap = new Map<string, MissedCallRecord>();
        localList.forEach(item => mergedMap.set(item.id, item));
        list.forEach(item => mergedMap.set(item.id, item));
        const merged = Array.from(mergedMap.values()).sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        localStorage.setItem('polli_missed_calls', JSON.stringify(merged));
        onUpdate(merged);
      } catch {
        onUpdate(list);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'call_records');
      try {
        const raw = localStorage.getItem('polli_missed_calls');
        onUpdate(raw ? JSON.parse(raw) : []);
      } catch {
        onUpdate([]);
      }
    });
  } catch {
    const raw = localStorage.getItem('polli_missed_calls');
    onUpdate(raw ? JSON.parse(raw) : []);
    return () => {};
  }
}

export async function markCallCallbackDone(callId: string): Promise<void> {
  try {
    const docRef = doc(db, 'call_records', callId);
    await updateDoc(docRef, { isCallbackDone: true });
    try {
      const raw = localStorage.getItem('polli_missed_calls');
      if (raw) {
        const list: MissedCallRecord[] = JSON.parse(raw);
        const updated = list.map(m => m.id === callId ? { ...m, isCallbackDone: true } : m);
        localStorage.setItem('polli_missed_calls', JSON.stringify(updated));
        window.dispatchEvent(new Event('polli_missed_calls_updated'));
      }
    } catch {}
  } catch (e) {
    handleFirestoreError(e, OperationType.UPDATE, 'call_records');
    try {
      const raw = localStorage.getItem('polli_missed_calls');
      if (raw) {
        const list: MissedCallRecord[] = JSON.parse(raw);
        const updated = list.map(m => m.id === callId ? { ...m, isCallbackDone: true } : m);
        localStorage.setItem('polli_missed_calls', JSON.stringify(updated));
        window.dispatchEvent(new Event('polli_missed_calls_updated'));
      }
    } catch {}
  }
}


