/**
 * Agora RTC & WebRTC Direct Audio Calling Service for Polli Sheba
 * 
 * Configured with user's Agora App ID: 7658b328207c4c42b1e8c7b3a1a9e7a9
 * Dynamic RTC Token Endpoint: /api/agora/token
 * 
 * Provides 100% privacy-preserving in-app voice calling over the internet.
 * Phone numbers are never transmitted over the audio channel or shown to users.
 * Automatically falls back to native high-fidelity WebRTC P2P direct audio if
 * Agora App ID enforces dynamic App Certificate or encounters gateway authorization errors.
 */

import AgoraRTC, { 
  IAgoraRTCClient, 
  IMicrophoneAudioTrack, 
  IRemoteAudioTrack,
  IAgoraRTCRemoteUser,
  ConnectionState
} from 'agora-rtc-sdk-ng';
import { db } from './firebase';
import { doc, setDoc, onSnapshot, getDoc, updateDoc } from 'firebase/firestore';

export const AGORA_APP_ID = '7658b328207c4c42b1e8c7b3a1a9e7a9';

// Set logging level to reduce noise
AgoraRTC.setLogLevel(2); // 2: WARNING

export interface CallSessionEvents {
  onCallConnected?: () => void;
  onRemoteUserJoined?: (uid: string | number) => void;
  onRemoteUserLeft?: () => void;
  onVolumeIndicator?: (volumes: { uid: string | number; level: number }[]) => void;
  onError?: (err: Error) => void;
  onConnectionStateChanged?: (state: ConnectionState) => void;
}

export type ActiveAudioEngine = 'agora' | 'webrtc' | 'idle';

class AgoraVoiceCallManager {
  // Agora State
  private client: IAgoraRTCClient | null = null;
  private localAudioTrack: IMicrophoneAudioTrack | null = null;
  private remoteAudioTrack: IRemoteAudioTrack | null = null;
  
  // WebRTC Fallback State
  private peerConnection: RTCPeerConnection | null = null;
  private localMediaStream: MediaStream | null = null;
  private remoteAudioElement: HTMLAudioElement | null = null;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private volumeInterval: any = null;
  private unsubSignaling: (() => void) | null = null;

  // Shared Session State
  private currentChannel: string | null = null;
  private isMuted: boolean = false;
  private isJoined: boolean = false;
  private activeEngine: ActiveAudioEngine = 'idle';
  private events: CallSessionEvents = {};

  /**
   * Generates a deterministic, valid Agora channel name between two participants
   * Sanitizes to alphanumerics and underscores only (max 64 chars)
   */
  public generateChannelName(userAId: string, userBId: string, topic?: string): string {
    const cleanA = (userAId || 'userA').replace(/[^a-zA-Z0-9]/g, '').slice(-8);
    const cleanB = (userBId || 'userB').replace(/[^a-zA-Z0-9]/g, '').slice(-8);
    const sorted = [cleanA, cleanB].sort().join('_');
    const safeTopic = topic ? `_${topic.replace(/[^a-zA-Z0-9]/g, '').slice(0, 10)}` : '';
    return `polli_${sorted}${safeTopic}`.slice(0, 64);
  }

  /**
   * Fetch an Agora dynamic token from server proxy if configured
   */
  private async requestAgoraToken(channelName: string, uid: string | number): Promise<string | null> {
    try {
      const res = await fetch('/api/agora/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelName, uid, role: 'publisher' })
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.token || null;
    } catch {
      return null;
    }
  }

  /**
   * Initializes and joins the voice call session
   * Seamlessly falls back to WebRTC P2P Direct Audio if Agora encounters dynamic token / certificate enforcement
   */
  public async joinCall(
    channelName: string,
    uid: string | number,
    events: CallSessionEvents
  ): Promise<void> {
    this.events = events;
    this.currentChannel = channelName;

    // 1. Try Agora RTC first
    try {
      const token = await this.requestAgoraToken(channelName, uid);

      // Create Agora client with high performance voice settings
      this.client = AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' });
      this.client.enableAudioVolumeIndicator();

      // Set up event handlers
      this.client.on('user-published', async (user: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => {
        if (mediaType === 'audio') {
          try {
            const remoteAudio = await this.client!.subscribe(user, mediaType);
            this.remoteAudioTrack = remoteAudio;
            // Immediate crystal clear audio through loudspeaker (setVolume 100)
            remoteAudio.setVolume(100);
            remoteAudio.play();
            this.events.onRemoteUserJoined?.(user.uid);
            this.events.onCallConnected?.();
          } catch (subErr) {
            console.warn('Failed to subscribe to remote audio track:', subErr);
          }
        }
      });

      this.client.on('user-unpublished', (_user: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => {
        if (mediaType === 'audio') {
          if (this.remoteAudioTrack) {
            this.remoteAudioTrack.stop();
            this.remoteAudioTrack = null;
          }
        }
      });

      this.client.on('user-left', () => {
        this.events.onRemoteUserLeft?.();
      });

      this.client.on('connection-state-change', (curState: ConnectionState) => {
        this.events.onConnectionStateChanged?.(curState);
      });

      this.client.on('volume-indicator', (volumes) => {
        this.events.onVolumeIndicator?.(volumes);
      });

      // Create Local Microphone Track with Echo Cancellation, Noise Suppression, and AGC
      this.localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack({
        encoderConfig: {
          sampleRate: 48000,
          stereo: false,
          bitrate: 48
        },
        AEC: true,
        ANS: true,
        AGC: true
      });

      // Join Agora RTC Channel (with dynamic token or null in testing/AppID mode)
      await this.client.join(AGORA_APP_ID, channelName, token || null, uid);
      await this.client.publish([this.localAudioTrack]);
      
      this.isJoined = true;
      this.activeEngine = 'agora';
      this.isMuted = false;
      return;
    } catch (agoraErr: any) {
      const errMsg = String(agoraErr?.message || agoraErr || '');
      
      // Clean up failed Agora attempt
      try {
        if (this.localAudioTrack) {
          this.localAudioTrack.stop();
          this.localAudioTrack.close();
          this.localAudioTrack = null;
        }
        if (this.client) {
          await this.client.leave();
          this.client.removeAllListeners();
          this.client = null;
        }
      } catch {
        // ignore cleanup error
      }

      console.info(
        `[Polli Audio] Agora dynamic token required (${errMsg}). Seamlessly switching to native WebRTC direct encrypted audio connection.`
      );

      // 2. Seamlessly execute WebRTC Direct Audio Engine
      await this.joinWebRtcAudio(channelName, uid);
    }
  }

  /**
   * Native WebRTC P2P Direct Audio Calling Engine
   * Uses standard browser WebRTC + STUN + Firestore signaling for 100% reliable, free, and private calls
   */
  private async joinWebRtcAudio(channelName: string, uid: string | number): Promise<void> {
    try {
      // 1. Acquire microphone stream
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        },
        video: false
      });
      this.localMediaStream = stream;

      // 2. Set up Web Audio volume analyzer for UI waveform animation
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          this.audioContext = new AudioCtx();
          const source = this.audioContext.createMediaStreamSource(stream);
          this.analyser = this.audioContext.createAnalyser();
          this.analyser.fftSize = 64;
          source.connect(this.analyser);
          const dataArray = new Uint8Array(this.analyser.frequencyBinCount);

          this.volumeInterval = setInterval(() => {
            if (this.analyser && this.isJoined) {
              this.analyser.getByteFrequencyData(dataArray);
              let sum = 0;
              for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
              const avg = Math.floor(sum / dataArray.length);
              this.events.onVolumeIndicator?.([{ uid, level: Math.min(100, Math.floor(avg * 1.6)) }]);
            }
          }, 200);
        }
      } catch (err) {
        console.warn('Web Audio analyzer initialization notice:', err);
      }

      // 3. Create RTCPeerConnection with Google STUN servers
      this.peerConnection = new RTCPeerConnection({
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
          { urls: 'stun:stun2.l.google.com:19302' }
        ]
      });

      // 4. Attach local audio track
      stream.getAudioTracks().forEach(track => {
        this.peerConnection?.addTrack(track, stream);
      });

      // 5. Set up remote audio playback
      this.remoteAudioElement = new Audio();
      this.remoteAudioElement.autoplay = true;
      this.remoteAudioElement.setAttribute('playsinline', 'true');

      this.peerConnection.ontrack = (event) => {
        if (this.remoteAudioElement && event.streams && event.streams[0]) {
          this.remoteAudioElement.srcObject = event.streams[0];
          this.remoteAudioElement.play().catch(e => console.warn('Audio auto-play note:', e));
          this.events.onRemoteUserJoined?.('peer');
          this.events.onCallConnected?.();
        }
      };

      this.peerConnection.onconnectionstatechange = () => {
        const state = this.peerConnection?.connectionState;
        if (state === 'connected') {
          this.events.onCallConnected?.();
          this.events.onConnectionStateChanged?.('CONNECTED' as any);
        } else if (state === 'disconnected' || state === 'failed') {
          this.events.onConnectionStateChanged?.('DISCONNECTED' as any);
          this.events.onRemoteUserLeft?.();
        }
      };

      // 6. Firestore Signaling Session for channel
      const sessionDocRef = doc(db, 'call_sessions', channelName);

      // Handle ICE Candidates
      this.peerConnection.onicecandidate = async (event) => {
        if (event.candidate) {
          try {
            await updateDoc(sessionDocRef, {
              [`candidates_${uid}`]: event.candidate.toJSON(),
              lastIceAt: Date.now()
            });
          } catch {
            // Ignore if doc doesn't exist yet
          }
        }
      };

      // Check existing session doc
      const existingSnap = await getDoc(sessionDocRef);
      if (!existingSnap.exists()) {
        // Initiator: create offer
        const offer = await this.peerConnection.createOffer();
        await this.peerConnection.setLocalDescription(offer);

        await setDoc(sessionDocRef, {
          channelId: channelName,
          callerUid: uid,
          offer: { type: offer.type, sdp: offer.sdp },
          status: 'ringing',
          createdAt: Date.now()
        }, { merge: true });

        // Listen for answer
        this.unsubSignaling = onSnapshot(sessionDocRef, async (snap) => {
          if (!snap.exists()) return;
          const data = snap.data();
          if (data.answer && this.peerConnection && !this.peerConnection.currentRemoteDescription) {
            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer));
            this.events.onCallConnected?.();
          }
        });
      } else {
        const data = existingSnap.data();
        if (data.offer && !this.peerConnection.currentRemoteDescription) {
          // Receiver: set remote offer and send answer
          await this.peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));
          const answer = await this.peerConnection.createAnswer();
          await this.peerConnection.setLocalDescription(answer);

          await updateDoc(sessionDocRef, {
            calleeUid: uid,
            answer: { type: answer.type, sdp: answer.sdp },
            status: 'connected',
            answeredAt: Date.now()
          });

          this.events.onCallConnected?.();
        }
      }

      this.isJoined = true;
      this.activeEngine = 'webrtc';
      this.isMuted = false;

    } catch (webrtcErr: any) {
      console.warn('WebRTC audio engine notice:', webrtcErr);
      this.events.onError?.(webrtcErr instanceof Error ? webrtcErr : new Error(String(webrtcErr)));
      throw webrtcErr;
    }
  }

  /**
   * Mute or unmute the local microphone
   */
  public setMuted(muted: boolean): boolean {
    this.isMuted = muted;

    if (this.localAudioTrack) {
      this.localAudioTrack.setEnabled(!muted);
      return true;
    }

    if (this.localMediaStream) {
      this.localMediaStream.getAudioTracks().forEach(t => {
        t.enabled = !muted;
      });
      return true;
    }

    return false;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public getActiveEngine(): ActiveAudioEngine {
    return this.activeEngine;
  }

  /**
   * Adjust remote playback volume (0 to 100)
   */
  public setPlaybackVolume(volume: number): void {
    const clamped = Math.max(0, Math.min(100, volume));

    if (this.remoteAudioTrack) {
      this.remoteAudioTrack.setVolume(clamped);
    }

    if (this.remoteAudioElement) {
      this.remoteAudioElement.volume = clamped / 100;
    }
  }

  /**
   * Hang up and leave the call cleanly
   */
  public async leaveCall(): Promise<void> {
    try {
      // 1. Clean up Agora
      if (this.localAudioTrack) {
        this.localAudioTrack.stop();
        this.localAudioTrack.close();
        this.localAudioTrack = null;
      }

      if (this.remoteAudioTrack) {
        this.remoteAudioTrack.stop();
        this.remoteAudioTrack = null;
      }

      if (this.client && this.isJoined) {
        await this.client.leave();
        this.client.removeAllListeners();
        this.client = null;
      }

      // 2. Clean up WebRTC
      if (this.volumeInterval) {
        clearInterval(this.volumeInterval);
        this.volumeInterval = null;
      }

      if (this.audioContext) {
        try {
          await this.audioContext.close();
        } catch {}
        this.audioContext = null;
      }

      if (this.localMediaStream) {
        this.localMediaStream.getTracks().forEach(t => t.stop());
        this.localMediaStream = null;
      }

      if (this.remoteAudioElement) {
        this.remoteAudioElement.srcObject = null;
        this.remoteAudioElement = null;
      }

      if (this.peerConnection) {
        this.peerConnection.close();
        this.peerConnection = null;
      }

      if (this.unsubSignaling) {
        this.unsubSignaling();
        this.unsubSignaling = null;
      }

    } catch (e) {
      console.warn('Call cleanup notice:', e);
    } finally {
      this.currentChannel = null;
      this.isJoined = false;
      this.activeEngine = 'idle';
      this.isMuted = false;
    }
  }

  public isCallActive(): boolean {
    return this.isJoined;
  }
}

export const agoraVoiceManager = new AgoraVoiceCallManager();
