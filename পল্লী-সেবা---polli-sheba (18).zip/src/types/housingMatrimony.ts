/**
 * আবাসন (Housing & Rental) এবং পাত্র-পাত্রীর সন্ধান (Matchmaking)
 * ডাটা মডেল, ভ্যালিডেশন এবং সিকিউরিটি ফিল্টার
 */

export type HousingCategoryType = 
  | 'ফ্যামিলি বাসা'
  | 'ব্যাচেলর বাসা'
  | 'সাবলেট / রুম'
  | 'মেস বাসা'
  | 'দোকান / অফিস';

export type MatrimonySeekingType = 'পাত্র চাই' | 'পাত্রী চাই';

export type MatrimonyReligion = 'ইসলাম' | 'হিন্দু' | 'বৌদ্ধ' | 'খ্রিস্টান' | 'অন্যান্য';

export type MatrimonyMaritalStatus = 'অবিবাহিত' | 'ডিভোর্সড' | 'বিপত্নীক/বিধবা';

export interface HousingListing {
  id: string;
  title: string;
  category: HousingCategoryType;
  rentType: 'fixed' | 'negotiable';
  rentAmount: number; // মাসিক ভাড়া (টাকা)
  bedrooms: number;
  bathrooms: number;
  balconies: number;
  floorLevel: string; // যেমন: "৩য় তলা"
  utilities: string[]; // ['বিদ্যুৎ', 'গ্যাস', 'পানি', 'ওয়াইফাই', 'লিফট', 'বাইক পার্কিং']
  district: string;
  upazila: string;
  union?: string;
  village?: string;
  areaAddress: string;
  description: string;
  availableFrom?: string; // যেমন: "১ নভেম্বর ২০২৬"
  
  ownerId: string;
  ownerName: string;
  ownerPhone: string;
  ownerAvatarUrl?: string;
  ownerRole?: string;
  allowOfflineCall?: boolean;
  
  notificationScope: 'upazila' | 'district';
  status: 'active' | 'pending_review' | 'expired';
  reviewReason?: string;
  
  createdAt: number;
  createdAtFormatted: string;
  expiresAt: number; // সর্বোচ্চ ৩০ দিন
  viewsCount?: number;
}

export interface MatrimonyListing {
  id: string;
  seekingType: MatrimonySeekingType;
  age: number; // বয়স
  height: string; // যেমন: "৫ ফুট ৪ ইঞ্চি"
  religion: MatrimonyReligion;
  maritalStatus: MatrimonyMaritalStatus;
  education: string;
  profession?: string; // ঐচ্ছিক
  complexion?: string; // গায়ের রঙ (ঐচ্ছিক)
  bloodGroup?: string; // রক্তের গ্রুপ (ঐচ্ছিক)
  district: string;
  upazila: string;
  union?: string;
  village?: string;
  familyInfo: string;
  expectations: string;
  
  posterId: string;
  posterName: string;
  posterPhone: string;
  posterRelation: 'অভিভাবক (বাবা/মা)' | 'ভাই/বোন' | 'আত্মীয়' | 'নিজেই';
  allowOfflineCall?: boolean;
  
  notificationScope: 'upazila' | 'district';
  durationDays: number; // ১ দিন থেকে সর্বোচ্চ ৯০ দিন
  status: 'active' | 'expired';
  
  createdAt: number;
  createdAtFormatted: string;
  expiresAt: number;
  viewsCount?: number;
  // বিশেষ নিয়ম: পাত্র বা পাত্রীর কোনো ছবি প্রদর্শন বা আপলোড করা যাবে না
}

export interface HousingMatrimonyReport {
  id: string;
  reportedItemId: string;
  itemType: 'housing' | 'matrimony';
  itemTitle: string;
  accusedUserId: string;
  accusedUserName: string;
  accusedUserPhone: string;
  reporterUserId: string;
  reporterName: string;
  reporterPhone: string;
  reason: 'প্রতারণা বা অসত্য তথ্য' | 'বাণিজ্যিক হোটেল/বুকিং প্রতারণা' | 'ভুয়া পাত্র/পাত্রীর তথ্য' | 'অনুপযুক্ত আচরণ' | 'অন্যান্য';
  details: string;
  createdAt: number;
  formattedDate: string;
  status: 'নতুন' | 'তদন্তাধীন' | 'নিষ্পন্ন';
  adminActionTaken?: 'banned' | 'dismissed' | 'deleted_post';
  adminNotes?: string;
}

/**
 * কীওয়ার্ড ফিল্টারিং: হোটেল, দৈনিক ভাড়া, রুম বুকিং ইত্যাদি শব্দ যাচাই
 */
export const HOUSING_SUSPICIOUS_KEYWORDS = [
  'হোটেল',
  'দৈনিক ভাড়া',
  'দৈনিক ভাড়া',
  'রুম বুকিং',
  'বুকিং',
  'দৈনিক',
  'মোটেল',
  'রিসোর্ট',
  'hotel',
  'motel',
  'resort',
  'daily rent',
  'day rent',
  'room booking',
  'booking',
  'ঘণ্টা চুক্তি',
  'ঘন্টা চুক্তি'
];

export function checkHousingReviewKeywords(title: string, desc: string): { isSuspicious: boolean; matchedKeyword?: string } {
  const combined = `${title} ${desc}`.toLowerCase();
  for (const kw of HOUSING_SUSPICIOUS_KEYWORDS) {
    if (combined.includes(kw.toLowerCase())) {
      return { isSuspicious: true, matchedKeyword: kw };
    }
  }
  return { isSuspicious: false };
}

/**
 * পোস্টের মেয়াদোত্তীর্ণতা চেক
 */
export function isPostExpired(expiresAt: number): boolean {
  return Date.now() > expiresAt;
}
