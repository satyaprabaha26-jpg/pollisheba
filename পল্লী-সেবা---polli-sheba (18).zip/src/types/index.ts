export * from './housingMatrimony';

export type ServiceCategory = 
  | 'home'
  | 'services'
  | 'service-flow'
  | 'service-finder'
  | 'blood-health'
  | 'transport'
  | 'prayer-islamic'
  | 'agriculture'
  | 'electricity'
  | 'health'
  | 'government'
  | 'livestock'
  | 'marketplace'
  | 'calculators'
  | 'housing'
  | 'matrimony'
  | 'ai-advisor'
  | 'account'
  | 'settings'
  | 'terms-help'
  | 'legal-police';

export interface NavigationSubTabs {
  agri?: 'doctor' | 'prices' | 'fertilizer' | 'calendar';
  electricity?: 'bill' | 'complaints';
  gov?: 'services' | 'allowances' | 'hotlines' | 'legal';
  calc?: 'land' | 'loan';
  market?: 'products' | 'labor' | 'tutors' | 'mechanics';
  health?: 'donors' | 'rural_doctors' | 'ambulances' | 'hospitals' | 'doctors' | 'clinics' | 'vaccine' | 'firstaid';
}

export interface BloodDonor {
  id: string;
  name: string;
  bloodGroup: 'A+' | 'A-' | 'B+' | 'B-' | 'O+' | 'O-' | 'AB+' | 'AB-';
  phone: string;
  district: string;
  upazila: string;
  villageOrArea: string;
  lastDonationDate?: string;
  isAvailable: boolean;
  totalDonations?: number;
}

export interface HospitalInfo {
  id: string;
  name: string;
  type: 'সদর হাসপাতাল' | 'উপজেলা স্বাস্থ্য কমপ্লেক্স' | 'মেডিকেল কলেজ' | 'বিশেষায়িত হাসপাতাল';
  district: string;
  upazila: string;
  address: string;
  emergencyNumber: string;
  ambulanceNumber: string;
  googleMapsQuery: string;
  services: string[];
  doctorCount?: number;
}

export interface DoctorSchedule {
  id: string;
  doctorName: string;
  designation: string;
  speciality: string;
  hospitalOrClinic: string;
  district: string;
  visitingDays: string;
  visitingHours: string;
  serialNumber: string;
  fee: string;
}

export interface RuralDoctor {
  id: string;
  name: string;
  category: 'allopathic' | 'homeopathic' | 'village_practical' | 'veterinary';
  categoryLabel: string;
  degreeOrTraining: string;
  phone: string;
  district: string;
  upazila: string;
  unionOrBazar: string;
  village?: string;
  chamberName: string;
  visitingHours: string;
  experienceYears?: string;
  services: string[];
  addedByPhone?: string;
  addedByName?: string;
  isVerified?: boolean;
}

export interface TransportDriver {
  id: string;
  driverName: string;
  vehicleType: 'অটোরিকশা / ইজিবাইক' | 'সিএনজি' | 'বাইক রাইডার' | 'পিকআপ / নসিমন' | 'মাইক্রোবাস / কার' | 'ট্র্যাক্টর / হেস্কোভেটর / কৃষিযন্ত্র' | 'নৌকার মাঝি / খেয়া চালক' | string;
  vehicleNumber: string;
  phone: string; // Strictly masked in Passenger UI; visible only in Admin Panel
  district: string;
  upazila?: string;
  unionOrWard?: string;
  village?: string;
  standLocation: string;
  regularRoutes: string;
  serviceShift?: 'শুধুমাত্র দিনে' | 'শুধুমাত্র রাতে' | 'দিন ও রাত (২৪ ঘণ্টা)' | string; // সময়সূচি
  isNightActive: boolean; // রাতের রাইড সেবা
  isPhoneVerified?: boolean; // OTP Verified
  isVerified?: boolean;
  facePhotoUrl?: string;
  status?: 'সচল' | 'ব্যস্ত' | 'পেন্ডিং' | 'নিষ্ক্রিয়' | string;
  rating?: number;
  baseFareDay?: number; // দিনের ন্যূনতম বা আনুমানিক ভাড়া (টাকা)
  baseFareNight?: number; // রাতের ন্যূনতম বা বিশেষ নাইট ভাড়া (টাকা)
  isFareNegotiable?: boolean; // ভাড়া আলোচনা সাপেক্ষে কিনা
  pricingType?: string; // ভাড়া ধরন যেমন 'আলোচনা সাপেক্ষে' বা 'নির্দিষ্ট ভাড়া'
  farePerKm?: number; // আনুমানিক কিমি প্রতি রেট
  ratingsCount?: number;
  averageRating?: number;
  latitude?: number; // চালকের রিয়েল-টাইম বা আনুমানিক অক্ষাংশ (GPS)
  longitude?: number; // চালকের রিয়েল-টাইম বা আনুমানিক দ্রাঘিমাংশ (GPS)
  lastLocationUpdate?: number; // সর্বশেষ জিপিএস লোকেশন আপডেট সময়
}

export interface ServiceOfficeGuide {
  id: string;
  serviceName: string;
  category: 
    | 'জমিজমা ও পর্চা' 
    | 'ভোটার আইডি ও জন্ম নিবন্ধন' 
    | 'ভাতা ও আর্থিক সাহায্য' 
    | 'কৃষি ও বীজ-সার' 
    | 'চিকিৎসা ও স্বাস্থ্য' 
    | 'আইন ও পুলিশ' 
    | 'বিদ্যুৎ ও সংযোগ' 
    | 'পাসপোর্ট ও লাইসেন্স'
    | 'প্রাণিসম্পদ ও পশুপালন'
    | 'পল্লী উন্নয়ন ও সমবায় (BRDB)'
    | 'খাবার পানি ও স্যানিটেশন (DPHE)'
    | 'শিক্ষা ও উপবৃত্তি'
    | string;
  officeName: string;
  officerDesignation: string;
  roomOrDesk: string;
  fees: string;
  requiredDocuments: string[];
  steps: string[];
  tips: string;
  contactHelpline?: string;
}

export interface IslamicDua {
  id: string;
  title: string;
  category: 'দৈনন্দিন' | 'বিপদমুক্তি ও রোগমুক্তি' | 'রিজিক ও বরকত' | 'সফর ও বাহন' | 'ক্ষমা ও তওবা';
  arabic: string;
  pronunciation: string;
  meaning: string;
  virtue: string;
}

export interface CropDisease {
  id: string;
  cropName: string;
  cropCategory: 'ধান ও খাদ্যশস্য' | 'শাকসবজি' | 'ফলমূল' | 'অর্থকরী ফসল' | 'ডাল ও তেলবীজ';
  diseaseName: string;
  symptoms: string[];
  causes: string;
  chemicalRemedy: string;
  organicRemedy: string;
  preventiveMeasures: string;
  severity: 'সাধারণ' | 'মাঝারি' | 'গুরুতর';
  icon: string;
}

export interface MarketPriceItem {
  id: string;
  name: string;
  category: 'খাদ্যশস্য' | 'শাকসবজি' | 'মাছ-মাংস-ডিম' | 'তেল ও মশলা' | 'কৃষি উপকরণ/সার';
  unit: string;
  retailPrice: number;
  wholesalePrice: number;
  previousPrice: number;
  district: string;
  updatedDate: string;
  trend: 'up' | 'down' | 'stable';
}

export interface CommunityClinic {
  id: string;
  name: string;
  division: string;
  district: string;
  upazila: string;
  union: string;
  address: string;
  chcpName: string;
  contactNumber: string;
  timing: string;
  availableServices: string[];
  keyMedicines: string[];
}

export interface CitizenServiceGuide {
  id: string;
  title: string;
  category: 'সনদ ও প্রত্যয়ন' | 'জাতীয় পরিচয়পত্র' | 'ভূমি সেবা' | 'ভাতা ও সহায়তা' | 'অন্যান্য';
  fee: string;
  deliveryTime: string;
  eligibility: string[];
  requiredDocs: string[];
  stepByStepGuide: string[];
  applicationUrl?: string;
  offlinePlace: string;
}

export interface HotlineContact {
  id: string;
  name: string;
  number: string;
  shortCode: string;
  category: 'জরুরি' | 'কৃষি' | 'স্বাস্থ্য' | 'নারী ও শিশু' | 'সরকারি তথ্য' | 'ইউটিলিটি ও ব্যাংক';
  description: string;
  isFree: boolean;
  activeHours: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole?: string;
  recipientId: string;
  recipientName: string;
  conversationId: string;
  text: string;
  timestamp: number;
  timeFormatted: string;
  isRead?: boolean;
  isDelivered?: boolean;
  deliveryStatus?: 'sent' | 'delivered' | 'read';
  messageType?: 'text' | 'voice';
  audioUrl?: string; // base64 or audio blob url
  audioDuration?: number; // seconds
}

export interface ChatConversation {
  id: string;
  participants: string[];
  lastMessageText: string;
  lastMessageTimestamp: number;
  lastMessageTimeFormatted: string;
  unreadCount?: number;
}

export interface HaatListing {
  id: string;
  title: string;
  category: 'তাজা তরিতরকারি ও শাকসবজি' | 'ফসলের ফলন' | 'ফলমূল' | 'গৃহ তৈরি খাবার ও নাস্তা' | 'কৃষিন ও দিনমজুর শ্রমিক' | 'গৃহশিক্ষক ও শিক্ষার্থী' | 'ইলেকট্রিশিয়ান ও মেকানিক' | 'গবাদিপশু ও হাঁস-মুরগি' | 'বীজ ও চারা' | 'কৃষি যন্ত্রপাতি' | 'খাঁটি গ্রামীণ পণ্য' | string;
  itemType?: 'পাতাযুক্ত শাক' | 'তাজা সবজি' | 'ফলমূল' | 'আলু/পেঁয়াজ/রসুন' | 'খাদ্যশস্য' | 'গৃহ তৈরি খাবার/মিষ্টি/কেক' | 'কৃষিন / দিনমজুর' | 'ধান কাটা/রোপণ কৃষিন' | 'মাটি কাটা ও ভারী কাজ' | 'নিড়ানি ও বাগান পরিচর্যা' | 'পশু-পাখি' | 'গৃহশিক্ষক' | 'শিক্ষার্থী' | 'ইলেকট্রিশিয়ান' | 'মেকানিক' | 'অন্যান্য';
  price: number;
  unit: string;
  quantity?: string;
  sellerName: string;
  sellerRole?: string;
  sellerId?: string;
  phone: string;
  location: string;
  district: string;
  upazila?: string;
  unionOrWard?: string;
  village?: string;
  hideVillage?: boolean; // When true, only Upazila & District are shown publicly
  allowOfflineCall?: boolean; // When true, offline SIM calls permitted with privacy warning
  description: string;
  imageUrl?: string;
  createdAt: string;
  createdAtTimestamp?: number;
  isNegotiable: boolean;
  isPerishable?: boolean;
  expiryDays?: number; // Duration in days (e.g., 1, 2, 3, 5, 7, 15, 30, 90)
  expiryDateTimestamp?: number; // Exact epoch timestamp when listing auto-expires
  isSold?: boolean;
  isCompleted?: boolean; // When marked completed/hired by author or admin
  isHidden?: boolean; // When hidden from public active feeds
  is_hidden?: boolean; // Alias for auto-hide in database
  // Labor specific properties
  laborType?: 'worker_avail' | 'worker_need'; // 'worker_avail': কাজ খুঁজছেন / 'worker_need': শ্রমিক প্রয়োজন
  workType?: string; // e.g. ধান কাটা ও মাড়াই, রোয়া লাগানো, নিড়ানি, মাটি কাটা
  teamSize?: string; // e.g. ১ জন, ৫ জন, ৮ জনের দল
  wageType?: 'daily' | 'contract'; // দৈনিক হাজিরা নাকি চুক্তিভিত্তিক
  // Tutor specific properties
  tutorType?: 'tutor_avail' | 'tutor_need'; // 'tutor_avail': পড়াতে চাই (গৃহশিক্ষক) / 'tutor_need': গৃহশিক্ষক আবশ্যক (অভিভাবক/শিক্ষার্থী)
  targetClasses?: string; // শ্রেণি (যেমন: ৬ষ্ঠ - ১০ম শ্রেণি)
  subjects?: string; // বিষয়সমূহ (যেমন: সাধারণ গণিত, বিজ্ঞান, ইংরেজি)
  qualification?: string; // শিক্ষাগত যোগ্যতা / প্রতিষ্ঠান
  teachingDays?: string; // সপ্তাহে কত দিন (যেমন: সপ্তাহে ৩ দিন)
  medium?: string; // বাংলা মাধ্যম / ইংরেজি ভার্সন / মাদরাসা
  // Mechanic specific properties
  mechanicType?: 'mechanic_avail' | 'mechanic_need'; // 'mechanic_avail': সেবা দিতে প্রস্তুত / 'mechanic_need': মিস্ত্রি/মেকানিক আবশ্যক
  mechanicTrade?: string; // ট্রেড বা কাজের ধরন (যেমন: ইলেকট্রিশিয়ান ও গৃহ ওয়্যারিং, ফ্রিজ ও এসি, পানির পাম্প ও মোটর, শ্যালো মেশিন)
  experience?: string; // অভিজ্ঞতা (যেমন: ৬ বছর)
  serviceAvailability?: string; // যেমন: অন-কল জরুরি সার্ভিস / সার্বক্ষণিক, সকাল ৯টা - রাত ৮টা
}

export interface TransportPassenger {
  id: string;
  name: string;
  phone: string; // Masked in Driver UI; visible only in Admin Panel
  isPhoneVerified?: boolean; // OTP Verified
  emergencyContact?: string;
  emergencyRelation?: string;
  district: string;
  upazila?: string;
  unionOrWard?: string;
  village?: string;
  upazilaOrArea: string;
  frequentRoute: string;
  facePhotoUrl?: string;
  isFaceVerified: boolean;
  registeredAt: string;
}

export interface ReturnTransportRide {
  id: string;
  type: 'driver_return' | 'passenger_request'; // 'driver_return': চালকের খালি ফিরতি গাড়ি, 'passenger_request': যাত্রীর ফিরতি গাড়ি রিকোয়েস্ট
  creatorId: string;
  creatorName: string;
  creatorPhone: string; // 100% masked in UI, system/admin only
  creatorAvatar?: string;
  creatorRole: 'driver' | 'citizen' | 'passenger';
  
  // বাহন ও সিট ক্যাপাসিটি
  vehicleType: string; // কার, মাইক্রো, সিএনজি, অটোরিকশা, বাইক, পিকআপ, ট্রাক, ট্রলার ইত্যাদি
  capacity: string; // ১ সিট, ২ সিট, ৩ সিট, ৪ সিট, পুরো গাড়ি
  
  // যাত্রা পথ (রুট)
  fromDistrict: string;
  fromUpazila?: string;
  fromUnion?: string;
  fromLocation: string; // প্রস্থান স্থান (যেমন: "মহাখালী বাস টার্মিনাল")
  
  toDistrict: string;
  toUpazila?: string;
  toUnion?: string;
  toLocation: string; // গন্তব্য স্থান (যেমন: "ঘাটাইল বাজার স্ট্যান্ড")
  
  // তারিখ ও সময়
  departureDate: string; // YYYY-MM-DD
  departureTime: string; // যেমন: "সকাল ০৮:৩০" বা "রাত ১০:০০"
  
  // ভাড়া
  fareType: 'negotiable' | 'fixed'; // আলোচনা সাপেক্ষে বা নির্দিষ্ট পরিমাণ
  fareAmount?: number; // টাকার পরিমাণ
  
  // বিশেষ নোট
  note?: string; // ঐচ্ছিক অতিরিক্ত তথ্য
  
  // স্ট্যাটাস ও সময়
  createdAt: number;
  createdAtFormatted: string;
  durationHours?: number; // মেয়াদ ঘণ্টা হিসেবে (যেমন: ৩ ঘণ্টা, ৫ ঘণ্টা ইত্যাদি)
  expiresAtTimestamp?: number; // মেয়াদ শেষ হওয়ার সঠিক সময় (Epoch timestamp)
  status: 'active' | 'completed' | 'cancelled';
  isHidden?: boolean; // স্বয়ংক্রিয় বা ম্যানুয়াল হাইড
  is_hidden?: boolean; // ডাটাবেসে অটোমেটিক হাইড (is_hidden = true)
  allowOfflineCall?: boolean;
}

export interface TripLog {
  id: string;
  tripId: string;
  passengerId?: string;
  passengerName: string;
  passengerPhone: string; // For law enforcement / admin audit only
  driverId: string;
  driverName: string;
  driverPhone: string; // For law enforcement / admin audit only
  vehicleType: string;
  vehicleNumber: string;
  district: string;
  startLocation: string;
  destination: string;
  startTime: string;
  endTime?: string;
  startTimestamp: number;
  endTimestamp?: number;
  distanceKm: number;
  durationMinutes: number;
  status: 'সচল (Active)' | 'সম্পন্ন (Completed)' | 'বাতিল (Cancelled)';
  trackingToken: string;
  trackingLinkUrl: string;
  isTrackingExpired: boolean;
  notes?: string;
}

export interface CitizenFeedback {
  id: string;
  name: string;
  phone: string;
  email?: string;
  category: 'পরামর্শ' | 'অভিযোগ' | 'নতুন সেবা অনুরোধ' | 'অন্যান্য';
  message: string;
  createdAt: string;
  status: 'নতুন' | 'পর্যালোচিত';
}

export interface AIComplaintRecord {
  id: string;
  trackingId: string;
  userId?: string;
  userName: string;
  userPhone?: string;
  userDistrict?: string;
  userUpazila?: string;
  rawUserQuery: string;
  detectedComplaintType: 'পণ্য ও বাজার' | 'পরিবহন ও চালক' | 'স্বাস্থ্য ও রক্ত' | 'বিদ্যুৎ ও সেবা' | 'দালাল বা প্রতারণা' | 'অ্যাপস ত্রুটি' | 'সাধারণ';
  severity: 'জরুরি' | 'সাধারণ' | 'সতর্কবার্তা';
  aiSummary: string;
  aiSuggestedAction?: string;
  createdAt: number;
  formattedDate: string;
  formattedTime: string;
  status: 'নতুন' | 'তদন্তাধীন' | 'নিষ্পন্ন';
  adminNotes?: string;
}

export interface AISystemQualityReport {
  id: string;
  reportTitle: string;
  generatedAt: number;
  formattedDate: string;
  totalComplaintsAnalyzed: number;
  overallHealthScore: number; // e.g. 92
  satisfactionRating: string;
  topIssues: Array<{
    area: string;
    count: number;
    description: string;
  }>;
  aiRecommendations: string[];
  reviewedByAdmin?: boolean;
}


export interface ElectricityComplaint {
  id: string;
  trackingId: string;
  customerName: string;
  phone: string;
  accountNumber: string;
  pbsName: string; // Palli Bidyut Samity
  complainType: 'বিদ্যুৎ বিভ্রাট/লোডশেডিং' | 'ট্রান্সফরমার বিকল' | 'তার ছিঁড়ে যাওয়া' | 'মিটার ত্রুটি' | 'অতিরিক্ত বিল' | 'নতুন সংযোগ দেরি';
  village: string;
  description: string;
  status: 'গৃহীত হয়েছে' | 'তদন্তাধীন' | 'কারিগরি দল প্রেরিত' | 'সমাধান সম্পন্ন';
  submittedAt: string;
  estimatedResolution: string;
}

export interface VaccineScheduleItem {
  id: string;
  vaccineName: string;
  targetAge: string;
  diseasesPrevented: string;
  doses: string;
  route: string;
  importance: string;
}

export interface LivestockGuide {
  id: string;
  animalType: 'গরু' | 'ছাগল ও ভেড়া' | 'হাঁস-মুরগি' | 'মাছ চাষ';
  topic: string;
  symptoms?: string[];
  treatment: string;
  prevention: string;
  vaccineInfo?: string;
}

export interface AdBanner {
  id: string;
  title: string;
  sponsorName: string;
  adType: 'image' | 'gif_3d' | 'video'; // HD Image, 3D animated GIF, or Video MP4/WebM
  mediaUrl: string;
  targetUrl?: string;
  callNumber?: string;
  districtTarget?: string; // 'সকল জেলা' or specific district
  placement: 'home_weather_bottom' | 'marketplace_top' | 'transport_middle' | 'all';
  isActive: boolean;
  viewsCount?: number;
  clicksCount?: number;
  expiresAt?: string;
  badgeText?: string;
  description?: string;
}

export interface AdminPermissions {
  canManageAds: boolean;          // নতুন বিজ্ঞাপনী ব্যানার যোগ/সম্পাদনা
  canManageDrivers: boolean;      // চালকদের তথ্য পরিবর্তন/যাচাই
  canModerateListings: boolean;   // পল্লী হাট ও ভুয়া পোস্ট নিয়ন্ত্রণ
  canManageHealth: boolean;       // রক্তদাতা ও ডাক্তার তথ্য
  canViewAnalytics: boolean;      // অডিট লগ ও পরিসংখ্যান পরিদর্শন
  canManageAuditAndReports?: boolean; // বিদ্যুৎ অভিযোগ ও রিপোর্ট প্রক্রিয়াকরণ
  canExportAuditReports?: boolean;    // অডিট ও কমপ্লেন রিপোর্ট এক্সপোর্ট/প্রিন্ট
  canModerateHousingMatrimony?: boolean; // আবাসন ও পাত্র-পাত্রী মডারেশন ও আংশিক ব্যান
}

export interface ServiceReview {
  id: string;
  targetId: string; // driver ID, seller ID, laborer ID, or passenger ID
  targetName: string;
  targetRole: string; // 'driver' | 'passenger' | 'seller' | 'buyer' | 'laborer'
  authorId: string;
  authorName: string;
  authorRole: string; // 'passenger' | 'driver' | 'buyer' | 'seller' | 'farmer' | 'user'
  rating: number; // 1 to 5 stars
  comment: string;
  tags?: string[];
  createdAt: number;
  serviceType: string; // 'transport' | 'haat' | 'labor' | 'service'
}

export interface GovtAmbulanceInfo {
  id: string;
  hospitalName: string;
  type: 'উপজেলা স্বাস্থ্য কমপ্লেক্স' | 'জেলা সদর হাসপাতাল' | 'মেডিকেল কলেজ হাসপাতাল';
  district: string;
  upazila: string;
  phone: string;
  controlRoomPhone?: string;
  driverName?: string;
  baseFareInfo: string;
  perKmRate: string;
  acType: 'এসি' | 'নন-এসি' | 'আইসিইউ অ্যাম্বুলেন্স';
  isAvailable24_7: boolean;
}

export interface QuranAyah {
  id: string;
  arabicText: string;
  banglaMeaning: string;
  surahName: string;
  ayahNumber: string;
  theme: string;
}

export interface TravelSpotGuide {
  id: string;
  spotName: string;
  district: string;
  division: string;
  category: 'প্রাকৃতিক ও বনাঞ্চল' | 'ঐতিহাসিক ও প্রত্নতাত্ত্বিক' | 'পাহাড় ও ঝর্ণা' | 'নদী ও সমুদ্র' | 'গ্রামীণ লোকজ মেলা';
  bestTimeToVisit: string;
  howToGo: string;
  localTransportTips: string;
  stayAndFood: string;
  safetyRules: string[];
  culturalEtiquette: string;
  environmentalNotice: string;
}

export interface AdminUser {
  id: string;
  name: string;
  phoneOrEmail: string;
  pin: string;
  role: 'super_admin' | 'sub_admin';
  assignedPermissions: AdminPermissions;
  isActive: boolean;
  createdDate: string;
  lastLoginAt?: string;
}

export interface AppSettings {
  notificationsEnabled: boolean;
  smsAlertsEnabled: boolean;
  weatherPriceAlerts: boolean;
  language: 'bn' | 'en';
  themeMode: 'light' | 'dark';
}

export interface ReportItemRecord {
  id: string;
  targetId: string;
  targetTitle: string;
  targetType: 'listing' | 'driver' | 'passenger' | 'review' | 'other' | 'user';
  reporterName: string;
  reporterPhone: string;
  reason: string;
  details: string;
  status: 'নতুন' | 'তদন্তাধীন' | 'সমাধানকৃত';
  createdAt: string;
  createdAtTimestamp: number;
  adminActionTaken?: string;
  adminNotes?: string;
}

export interface MissedCallRecord {
  id: string;
  callerName: string;
  callerPhone: string;
  callerRole?: string;
  callerSubtitle?: string;
  callerAvatar?: string;
  recipientName: string;
  recipientPhone: string;
  recipientRole?: string;
  recipientSubtitle?: string;
  recipientAvatar?: string;
  timestamp: number;
  formattedDate: string;
  formattedTime: string;
  isCallbackDone?: boolean;
  type?: 'missed' | 'received' | 'outgoing';
  duration?: string;
  allowOfflineCall?: boolean;
}

