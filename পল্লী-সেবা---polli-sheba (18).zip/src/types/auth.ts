export * from './registration';
import { 
  MainRegistrationCategory, 
  RegistrationSubCategory, 
  UserNotificationSwitches, 
  DriverFareProfile 
} from './registration';

export type UserRole = 
  | 'driver'               // ১. চালক
  | 'electrician_mechanic' // ২. ইলেকট্রিশিয়ান ও মেকার
  | 'laborer'              // ৩. কৃষি শ্রমিক ও দিনমজুর
  | 'health_worker'        // ৪. পল্লী চিকিৎসক ও স্বাস্থ্যসেবা
  | 'tutor_student'        // ৫. গৃহশিক্ষক ও ছাত্র-ছাত্রী
  | 'blood_donor'          // ৬. রক্তদাতা
  | 'farmer'               // ৭. কৃষক ও খামারী
  | 'citizen'              // ৮. সাধারণ নাগরিক
  // পূর্ববর্তী ভার্সনের সামঞ্জস্য রক্ষার্থে (Legacy Aliases):
  | 'mechanic'
  | 'doctor'
  | 'home_entrepreneur'
  | 'trader'
  | 'agri_machinery_driver'
  | 'boatman';

export const USER_ROLES_LIST: { id: UserRole; label: string; shortLabel: string; categoryNumber: number; badgeColor: string; description: string; icon: string }[] = [
  { id: 'citizen', label: '১. সাধারণ নাগরিক', shortLabel: 'নাগরিক', categoryNumber: 1, badgeColor: 'bg-emerald-50 text-emerald-800 border-emerald-200', description: 'দৈনন্দিন নাগরিক সেবা ও তথ্য অনুসন্ধানী', icon: '👤' },
  { id: 'farmer', label: '২. কৃষক / খামারি', shortLabel: 'কৃষক/খামারি', categoryNumber: 2, badgeColor: 'bg-lime-50 text-lime-800 border-lime-200', description: 'ফসল উৎপাদন, গবাদিপশু ও ফলমূল চাষী', icon: '🌱' },
  { id: 'laborer', label: '৩. কৃষি শ্রমিক / দিনমজুর', shortLabel: 'দিনমজুর শ্রমিক', categoryNumber: 3, badgeColor: 'bg-amber-50 text-amber-800 border-amber-200', description: 'মাঠের শ্রমিক, ধান কাটা, দিনমজুর ও রাজমিস্ত্রী সহায়ক', icon: '🌾' },
  { id: 'home_entrepreneur', label: '৪. গৃহ উদ্যোক্তা', shortLabel: 'গৃহ উদ্যোক্তা', categoryNumber: 4, badgeColor: 'bg-purple-50 text-purple-800 border-purple-200', description: 'হাতের কাজ, কুটির শিল্প ও খাদ্য সামগ্রী প্রস্তুতকারক', icon: '🏡' },
  { id: 'trader', label: '৫. ব্যবসায়ী / ক্রেতা', shortLabel: 'ব্যবসায়ী/ক্রেতা', categoryNumber: 5, badgeColor: 'bg-blue-50 text-blue-800 border-blue-200', description: 'পাইকারি বা খুচরা পণ্য কেনাবেচাকারী ও পাইকার', icon: '🛍️' },
  { id: 'driver', label: '৬. পরিবহন চালক', shortLabel: 'পরিবহন চালক', categoryNumber: 6, badgeColor: 'bg-teal-50 text-teal-800 border-teal-200', description: 'ইজিবাইক, সিএনজি, নসিমন বা পিকআপ চালক', icon: '🚗' },
  { id: 'doctor', label: '৭. পল্লী চিকিৎসক', shortLabel: 'পল্লী চিকিৎসক', categoryNumber: 7, badgeColor: 'bg-rose-50 text-rose-800 border-rose-200', description: 'গ্রাম ডাক্তার, প্যারামেডিক ও স্বাস্থ্যকর্মী', icon: '👨‍⚕️' },
  { id: 'mechanic', label: '৮. মেকানিক ও কারিগর', shortLabel: 'মেকানিক/কারিগর', categoryNumber: 8, badgeColor: 'bg-orange-50 text-orange-800 border-orange-200', description: 'মোটরসাইকেল, শ্যালো মেশিন, ইলেকট্রিশিয়ান ও মিস্ত্রি', icon: '🔧' },
  { id: 'tutor_student', label: '৯. টিউটর ও শিক্ষার্থী (শিক্ষক দিচ্ছি/নিচ্ছি)', shortLabel: 'টিউটর/শিক্ষার্থী', categoryNumber: 9, badgeColor: 'bg-indigo-50 text-indigo-800 border-indigo-200', description: 'গৃহশিক্ষক ও পড়াশোনার সেবা বিনিময়', icon: '📚' },
  { id: 'agri_machinery_driver', label: '১০. ট্র্যাক্টর / হেস্কোভেটর / কৃষিযন্ত্র চালক', shortLabel: 'ট্র্যাক্টর/কৃষিযন্ত্র চালক', categoryNumber: 10, badgeColor: 'bg-amber-100 text-amber-900 border-amber-300', description: 'ট্র্যাক্টর, হেস্কোভেটর, পাওয়ার টিলার ও হার্ভেস্টার চালক', icon: '🚜' },
  { id: 'boatman', label: '১১. নৌকার মাঝি / খেয়া চালক', shortLabel: 'নৌকার মাঝি/খেয়া চালক', categoryNumber: 11, badgeColor: 'bg-cyan-100 text-cyan-900 border-cyan-300', description: 'নৌকা, খেয়া ও ট্রলার চালক (নদী ও চরাঞ্চলে পারাপার)', icon: '⛵' }
];

export interface DriverProfileInfo {
  vehicleType: 'অটোরিকশা / ইজিবাইক' | 'সিএনজি' | 'বাইক রাইডার' | 'পিকআপ / নসিমন' | 'মাইক্রোবাস / কার' | 'ট্র্যাক্টর / হেস্কোভেটর / কৃষিযন্ত্র' | 'নৌকার মাঝি / খেয়া চালক' | string;
  vehicleNumber: string;
  serviceShift: 'শুধুমাত্র দিনে' | 'শুধুমাত্র রাতে' | 'দিন ও রাত (২৪ ঘণ্টা)';
  regularRoutes: string;
  estimatedFare: string; // e.g. "১০-৫০ টাকা" বা "প্রতি কিমি ২০ টাকা"
  isNightActive: boolean;
  status: 'সচল' | 'ব্যস্ত' | 'পেন্ডিং';
  rating?: number;
  totalRatingsCount?: number;
}

export interface AgriMachineryDriverInfo {
  machineryType: 'ট্র্যাক্টর (জমি চাষ)' | 'হেস্কোভেটর (মাটি কাটা / খনন)' | 'পাওয়ার টিলার' | 'কম্বাইন হার্ভেস্টার (ধান কাটা)' | 'অন্যান্য কৃষিযন্ত্র' | string;
  machineModelOrNumber?: string;
  hourlyOrDailyRate?: string;
  availabilityArea?: string;
  availableAttachments?: string;
  isEmergencyServiceAvailable?: boolean;
  status: 'সচল' | 'ব্যস্ত' | 'পেন্ডিং';
  rating?: number;
  totalRatingsCount?: number;
}

export interface BoatmanProfileInfo {
  boatType: 'যাত্রীবাহী ট্রলার' | 'মালামাল পরিবহন নৌকা' | 'ছোট খেয়া নৌকা' | 'স্পিডবোট / ইঞ্জিন নৌকা' | string;
  ghatNameOrRoute: string; // e.g. "আমিনবাজার খেয়াঘাট থেকে কাউন্দিয়া"
  serviceShift: 'শুধুমাত্র দিনে' | 'শুধুমাত্র রাতে' | 'দিন ও রাত (জরুরি পারাপার)' | string;
  fareRate?: string;
  emergencyNightCrossing?: boolean;
  status: 'সচল' | 'ব্যস্ত' | 'পেন্ডিং';
  rating?: number;
  totalRatingsCount?: number;
}

export interface TutorProfileInfo {
  tutorType: 'teacher' | 'student_parent'; // 'শিক্ষক (পড়াতে চাই)' | 'শিক্ষার্থী / অভিভাবক (শিক্ষক খুঁজছি)'
  qualification?: string; // e.g. "অনার্স ৩য় বর্ষ (গণিত), বগুড়া সরকারি আজিজুল হক কলেজ" বা "এইচএসসি"
  targetClasses: string; // e.g. "৬ষ্ঠ - ১০ম শ্রেণি (এসএসসি)"
  preferredSubjects: string; // e.g. "গণিত, ইংরেজি, সাধারণ বিজ্ঞান"
  teachingDaysPerWeek: string; // e.g. "সপ্তাহে ৩ দিন" বা "সপ্তাহে ৪ দিন"
  hoursPerDay?: string; // e.g. "১.৫ ঘণ্টা"
  preferredMedium?: 'বাংলা মাধ্যম' | 'ইংরেজি ভার্সন' | 'মাদরাসা মাধ্যম' | 'সকল মাধ্যম';
  remuneration?: string; // e.g. "২০০০ - ৩০০০ টাকা" বা "আলোচনা সাপেক্ষে"
}

export interface MerchantProfileInfo {
  shopName: string;
  subCategory: string;
  hasHomeDelivery: boolean;
  shopAddress?: string;
  shopDescription?: string;
}

export interface PhoneChangeHistoryRecord {
  oldPhone: string;
  newPhone: string;
  changedAt: string;
  changedAtTimestamp: number;
  reason?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  phone: string; // Stored securely in database, masked in public UI
  email?: string; // Optional user email
  passwordPin?: string; // User password or PIN
  district: string;
  upazila: string;
  union: string;
  ward?: string;
  village?: string;
  role: UserRole;
  mainCategory?: MainRegistrationCategory; // ৮টি মূল ক্যাটাগরির অন্যতম (ঐচ্ছিক/আর্কিটেকচারাল)
  subCategory?: RegistrationSubCategory | string; // নির্বাচিত সাব-ক্যাটাগরি
  avatarUrl?: string; // Active display photo (mirrors customAvatarUrl if set, or verifiedFaceUrl)
  verifiedFaceUrl?: string; // Immutable verified live face scan photo (retained by authority/admin)
  customAvatarUrl?: string; // Optional custom profile picture chosen by user (visible to other users)
  isPhoneVerified: boolean;
  isVerified?: boolean; // এডমিন ভেরিফাইড ও অনুমোদিত একাউন্ট
  agreedToTerms: boolean;
  // Phone Change Regulation (Allowed only once every 26 days for safety & investigation)
  lastPhoneChangeTimestamp?: number;
  phoneChangeHistory?: PhoneChangeHistoryRecord[];
  // Blood donor profile info
  isBloodDonor?: boolean;
  bloodGroup?: 'A+' | 'A-' | 'B+' | 'B-' | 'O+' | 'O-' | 'AB+' | 'AB-';
  // Privacy Controls
  hideAddressDetails?: boolean; // Default true: shows only District & Upazila to others
  hideVillage?: boolean; // Default true: village/ward hidden by default
  hideWard?: boolean; // Default true: ward hidden by default
  hideUnion?: boolean; // Optional: user can hide union
  hideUpazila?: boolean; // Optional: user can hide upazila
  hidePhonePublicly?: boolean; // Default true: hides raw phone on public cards
  allowOfflineCall?: boolean; // Default false: opt-in toggle to allow direct offline phone calls
  allowOfflineCalls?: boolean; // Alias for allowOfflineCall
  // Live Verification
  isLiveVerified?: boolean; // Forced Live Camera Selfie verified
  liveVerificationTimestamp?: number;
  verificationBadgeText?: string;
  securityAuditLogs?: UserSecurityLogRecord[]; // Immutable 1-year retention audit logs
  latitude?: number; // ব্যবহারকারী/চালকের জিপিএস অক্ষাংশ
  longitude?: number; // ব্যবহারকারী/চালকের জিপিএস দ্রাঘিমাংশ
  lastLocationUpdate?: number;
  createdAt: string;
  createdAtTimestamp: number;
  driverInfo?: DriverProfileInfo;
  driverFareProfile?: DriverFareProfile; // ডায়নামিক ভাড়া প্রোফাইল (কিমি প্রতি বা আলোচনা সাপেক্ষে)
  agriMachineryInfo?: AgriMachineryDriverInfo;
  boatmanInfo?: BoatmanProfileInfo;
  tutorInfo?: TutorProfileInfo;
  merchantInfo?: MerchantProfileInfo;
  // Driver credentials verification (Admin inspect only)
  driverNidFrontUrl?: string; // NID or Driving License Front scan
  driverNidBackUrl?: string;  // NID or Driving License Back scan
  driverLicenseType?: 'nid' | 'driving_license';
  // চালক ও মাঝি এডমিন অনুমোদন অবস্থা ('pending' = অনুমোদনের অপেক্ষায়, 'active' = অনুমোদিত, 'rejected' = বাতিল)
  accountStatus?: 'pending' | 'active' | 'rejected';
  approvedAt?: number;
  approvedBy?: string;
  approvalNotes?: string;
  bio?: string;
  preferredLanguage?: 'bn' | 'en'; // Bilingual support
  // আংশিক নিষেধাজ্ঞা ফ্ল্যাগ: শুধুমাত্র আবাসন ও পাত্র-পাত্রীতে পোস্ট করা থেকে ব্যান (অন্যান্য সেবায় নিয়মিত থাকবে)
  isRestrictedFromHousingAndMatrimony?: boolean;
  // এডমিন লেভেল সম্পূর্ণ ব্লক/ব্যান ফ্ল্যাগ
  isAccountBlocked?: boolean;
  // ইউজার-লেভেল ব্লক লিস্ট (যাদের মেসেজ বা কল আসবে না)
  blockedUsers?: string[]; // IDs or phone digits of blocked users
  // প্রোফাইল নোটিফিকেশন সেটিংস (কৃষি পণ্য, গৃহস্থালি পণ্য, পেশাগত সেবা, বাসা ভাড়া ও পাত্র-পাত্রী)
  notificationSwitches?: UserNotificationSwitches;
  // Area & Category Notification Settings (User opt-in / opt-out controls)
  notificationSettings?: {
    enableDistrictAlerts?: boolean; // জেলা ভিত্তিক বিজ্ঞপ্তির নোটিফিকেশন
    enableUpazilaAlerts?: boolean;  // উপজেলা ভিত্তিক বিজ্ঞপ্তির নোটিফিকেশন
    enableUnionAlerts?: boolean;    // ইউনিয়ন ও গ্রাম ভিত্তিক নোটিফিকেশন
    enableAgriHaatAlerts?: boolean; // পল্লী হাট ও কৃষি পণ্য
    enableTransportAlerts?: boolean;// গ্রামীণ পরিবহন ও গাড়ি চাহিদা
    enableBloodAlerts?: boolean;    // রক্তদান ও জরুরি স্বাস্থ্য আবেদন
    enableLaborTutorAlerts?: boolean;// দিনমজুর, কৃষি শ্রমিক, শিক্ষক, ইলেকট্রিশিয়ান
    enableHousingAndMatrimonyAlerts?: boolean;// বাসা ভাড়া ও পাত্র-পাত্রীর সন্ধান পোস্টের নোটিফিকেশন
  };
}

/**
 * 1 Year (365 days) retention period in milliseconds for immutable security logbook
 */
export const LOGBOOK_RETENTION_PERIOD_MS = 365 * 24 * 60 * 60 * 1000;

export type AuditLogCategory = 
  | 'phone_change'       // ফোন নম্বর পরিবর্তন
  | 'photo_change'       // প্রোফাইল ছবি ও ফেস ভেরিফিকেশন
  | 'travel_trip'        // গ্রামীণ যাতায়াত ও চালক-যাত্রী হিস্ট্রি (কবে কোথায় গিয়েছিলেন)
  | 'security_verify'    // লাইভ সেলফি ও ওটিপি ভেরিফিকেশন
  | 'privacy_toggle';    // কল ও ঠিকানা প্রদর্শন নিয়ন্ত্রণ

export interface UserSecurityLogRecord {
  id: string;                          // e.g. "LOG-2026-1726099..."
  auditHash: string;                   // Digital tamper-evident hash
  timestamp: number;                   // Epoch milliseconds
  formattedDate: string;               // e.g. "১২ সেপ্টেম্বর ২০২৬, বিকাল ৩:৪৫"
  category: AuditLogCategory;
  categoryTitle: string;               // e.g. "যানবাহন ও ভ্রমণ হিস্ট্রি"
  summary: string;                     // e.g. "যাত্রী হিসেবে অটোরিকশা রাইড ট্রিপ সম্পন্ন"
  details: {
    // Travel & Trip details (কবে কোথায় কাদের সাথে গিয়েছিলেন)
    tripFrom?: string;
    tripTo?: string;
    driverName?: string;
    driverPhoneMasked?: string;
    passengerName?: string;
    vehicleNumber?: string;
    vehicleType?: string;
    serviceType?: string;
    // Phone change details
    oldPhone?: string;
    newPhone?: string;
    otpStatus?: string;
    // Photo change details
    photoType?: 'custom_avatar' | 'live_face_verified' | 'avatar_removed';
    // Privacy changes
    privacySetting?: string;
    notes?: string;
  };
  retentionDaysLeft: number;          // Out of 365 days
  expiresAtTimestamp: number;         // Timestamp + 365 days
  isImmutable: boolean;               // Always true, user cannot delete
}

/**
 * Helper to generate a tamper-evident audit hash stamp
 */
export const generateAuditHash = (userId: string, category: string, timestamp: number): string => {
  const seed = `${userId}-${category}-${timestamp}-${Math.random().toString(36).substring(2, 8)}`;
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    const char = seed.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0').toUpperCase();
  return `SEC-POL-${hex.slice(0, 4)}-${hex.slice(4)}`;
};

/**
 * Helper to create a standardized immutable Security Log Record
 */
export const createSecurityLogRecord = (
  userId: string,
  category: AuditLogCategory,
  categoryTitle: string,
  summary: string,
  details: UserSecurityLogRecord['details'],
  overrideTimestamp?: number
): UserSecurityLogRecord => {
  const timestamp = overrideTimestamp || Date.now();
  const expiresAtTimestamp = timestamp + LOGBOOK_RETENTION_PERIOD_MS;
  const retentionDaysLeft = Math.max(0, Math.ceil((expiresAtTimestamp - Date.now()) / (24 * 60 * 60 * 1000)));

  return {
    id: `LOG-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
    auditHash: generateAuditHash(userId, category, timestamp),
    timestamp,
    formattedDate: new Date(timestamp).toLocaleString('bn-BD', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    }),
    category,
    categoryTitle,
    summary,
    details,
    retentionDaysLeft,
    expiresAtTimestamp,
    isImmutable: true
  };
};

/**
 * Helper to append a security log entry into user profile, pruning only records older than 1 year (365 days)
 */
export const appendUserSecurityLog = (
  user: UserProfile,
  category: AuditLogCategory,
  categoryTitle: string,
  summary: string,
  details: UserSecurityLogRecord['details']
): UserProfile => {
  const newRecord = createSecurityLogRecord(user.id, category, categoryTitle, summary, details);
  const now = Date.now();
  
  // Prune only records expired beyond 365 days (1 year retention)
  const currentLogs = (user.securityAuditLogs || []).filter(log => {
    return (log.expiresAtTimestamp || (log.timestamp + LOGBOOK_RETENTION_PERIOD_MS)) > now;
  });

  return {
    ...user,
    securityAuditLogs: [newRecord, ...currentLogs]
  };
};

/**
 * 26 Days in milliseconds (26 * 24 * 60 * 60 * 1000)
 */
export const PHONE_CHANGE_LOCK_PERIOD_MS = 26 * 24 * 60 * 60 * 1000;

/**
 * Helper to get the display avatar for a user:
 * 1. If user uploaded an optional public photo (customAvatarUrl), everyone can see it.
 * 2. The live verification photo (verifiedFaceUrl / avatarUrl) is STRICTLY PRIVATE:
 *    Only the user themselves, or the app Super Admin, can see it.
 * 3. For other users, if no optional photo is uploaded, returns undefined so it renders the name initial!
 */
export const getUserDisplayAvatar = (
  user?: Partial<UserProfile> | null,
  viewerUserIdOrPhone?: string,
  isSuperAdminViewer?: boolean
): string | undefined => {
  if (!user) return undefined;

  // চালকদের ক্ষেত্রে রেজিস্ট্রেশনের সময় করা লাইভ ভেরিফিকেশন ছবিই সর্বদা প্রোফাইল ছবি হিসেবে সবার কাছে প্রদর্শিত হবে
  const isDriver = user.role === 'driver' || user.role === 'agri_machinery_driver' || user.role === 'boatman';
  if (isDriver) {
    return user.verifiedFaceUrl || user.avatarUrl || user.customAvatarUrl;
  }

  // অন্যান্য সাধারণ ব্যবহারকারীরা তাদের ইচ্ছেমতো কাস্টম গ্যালারি প্রোফাইল ছবি যোগ করতে পারবেন
  if (user.customAvatarUrl) {
    return user.customAvatarUrl;
  }

  // Check if viewer is owner or Super Admin for viewing verified face
  const isOwner = viewerUserIdOrPhone && (
    viewerUserIdOrPhone === user.id ||
    viewerUserIdOrPhone === user.phone ||
    (user.phone && viewerUserIdOrPhone.replace(/[^0-9]/g, '') === user.phone.replace(/[^0-9]/g, ''))
  );

  if (isOwner || isSuperAdminViewer) {
    return user.verifiedFaceUrl || user.avatarUrl;
  }

  // অন্যান্য ক্ষেত্রে নাম-আদ্যক্ষর (Name initials fallback)
  return undefined;
};

/**
 * Helper to verify whether a user is eligible to change their verified phone number
 * (Phone number change is locked for 26 days for investigation & safety)
 */
export const canChangePhoneNumber = (user?: UserProfile | null): {
  canChange: boolean;
  remainingDays: number;
  nextEligibleDate?: string;
  lastChangedDate?: string;
} => {
  if (!user) {
    return { canChange: false, remainingDays: 26 };
  }
  const lastChange = user.lastPhoneChangeTimestamp || user.createdAtTimestamp || Date.now();
  const elapsed = Date.now() - lastChange;
  
  if (elapsed >= PHONE_CHANGE_LOCK_PERIOD_MS) {
    return { 
      canChange: true, 
      remainingDays: 0,
      lastChangedDate: new Date(lastChange).toLocaleDateString('bn-BD')
    };
  }

  const remainingMs = PHONE_CHANGE_LOCK_PERIOD_MS - elapsed;
  const remainingDays = Math.ceil(remainingMs / (24 * 60 * 60 * 1000));
  const nextEligible = new Date(lastChange + PHONE_CHANGE_LOCK_PERIOD_MS).toLocaleDateString('bn-BD');
  const lastDate = new Date(lastChange).toLocaleDateString('bn-BD');

  return {
    canChange: false,
    remainingDays,
    nextEligibleDate: nextEligible,
    lastChangedDate: lastDate
  };
};

/**
 * Global helper to get the currently logged-in user profile from localStorage
 */
export const getStoredUserProfile = (): UserProfile | null => {
  try {
    const saved = localStorage.getItem('polli_user_profile');
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error('Failed to parse user profile', e);
  }
  return null;
};

export interface UserFormDefaults {
  name: string;
  phone: string;
  district: string;
  upazila: string;
  union: string;
  village: string;
  ward: string;
  allowOfflineCall: boolean;
  hidePhonePublicly: boolean;
  hideVillage: boolean;
  avatarUrl: string;
}

/**
 * Universal Form Defaults Helper:
 * Extracts user profile information for automatic pre-filling across all services:
 * Blood Donor, Tutor, Mechanic, Driver, Laborer, Farm Product, etc.
 */
export const getUserFormDefaults = (currentUser?: UserProfile | null): UserFormDefaults => {
  const profile = currentUser || getStoredUserProfile();
  return {
    name: profile?.name || '',
    phone: profile?.phone || '',
    district: profile?.district || '',
    upazila: profile?.upazila || '',
    union: profile?.union || '',
    village: profile?.village || '',
    ward: profile?.ward || '',
    allowOfflineCall: profile ? (profile.allowOfflineCall ?? false) : false,
    hidePhonePublicly: profile ? (profile.hidePhonePublicly ?? true) : true,
    hideVillage: profile ? (profile.hideVillage ?? true) : true,
    avatarUrl: profile ? (profile.customAvatarUrl || profile.verifiedFaceUrl || profile.avatarUrl || '') : ''
  };
};

export interface DemandNotification {
  id: string;
  title: string;
  message: string;
  demandType: 'farm_laborer' | 'mechanic' | 'emergency_driver' | 'tutor' | 'doctor' | 'agri_machinery' | 'boatman' | 'general';
  targetDistrict: string;
  targetUpazila?: string;
  targetRoles: UserRole[];
  requesterName: string;
  requesterPhone: string;
  requesterLocation: string;
  createdAt: string;
  createdAtTimestamp: number;
  readBy?: string[];
  allowOfflineCall?: boolean;
}

/**
 * Universal Admin Check:
 * Checks if a user or session is a Head Admin (প্রধান এডমিন) or Assistant Admin (সহকারী এডমিন)
 */
export const isUserAdminOrAssistantAdmin = (currentUser?: UserProfile | null): boolean => {
  if (typeof window !== 'undefined') {
    // Check sessionStorage admin login
    const sessionAdmin = sessionStorage.getItem('polli_logged_admin');
    if (sessionAdmin && sessionAdmin !== 'false') return true;
    
    // Check localStorage admin session
    const localAdmin = localStorage.getItem('polli_admin_session') || localStorage.getItem('polli_current_admin');
    if (localAdmin && localAdmin !== 'false') return true;
  }

  if (!currentUser) return false;

  const role = (currentUser as any).role;
  if (role === 'admin' || role === 'super_admin' || role === 'sub_admin' || role === 'assistant_admin') {
    return true;
  }

  const cleanPhone = currentUser.phone ? currentUser.phone.replace(/[^0-9]/g, '') : '';
  const knownAdminPhones = ['01700000000', '01712000111', '01819000222'];
  if (cleanPhone && knownAdminPhones.includes(cleanPhone)) {
    return true;
  }

  return false;
};
