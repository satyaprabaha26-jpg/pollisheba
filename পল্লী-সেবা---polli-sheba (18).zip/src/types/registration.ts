/**
 * পল্লী সেবা (Polli Sheba) - নিবন্ধন, ক্যাটাগরি, গোপনীয়তা ও নোটিফিকেশন আর্কিটেকচার
 * 
 * এই ফাইলটিতে রয়েছে:
 * ১. ৮টি মূল ক্যাটাগরি এবং সাব-ক্যাটাগরি ডেফিনিশন (একবারই নিবন্ধন)
 * ২. ডিফল্ট গোপনীয়তা এবং অফলাইন কলিং ফ্ল্যাগ
 * ৩. ৩টি স্বাধীন প্রোফাইল নোটিফিকেশন সেটিংস
 * ৪. ডায়নামিক দূরত্ব ও ভাড়া হিসাব কনফিগ
 */

// ==========================================
// ১. নিবন্ধনের ৮টি মূল ক্যাটাগরি ও সাব-ক্যাটাগরি
// ==========================================

export type MainRegistrationCategory = 
  | 'driver'               // ১. চালক (সাব-ক্যাটাগরি যুক্ত)
  | 'electrician_mechanic' // ২. ইলেকট্রিশিয়ান ও মেকার (সাব-ক্যাটাগরি যুক্ত)
  | 'laborer'              // ৩. কৃষি শ্রমিক ও দিনমজুর (সাব-ক্যাটাগরি যুক্ত)
  | 'health_worker'        // ৪. পল্লী চিকিৎসক ও স্বাস্থ্যসেবা (সাব-ক্যাটাগরি যুক্ত)
  | 'trader'               // ৫. ব্যবসায়ী ও দোকানদার (সাব-ক্যাটাগরি যুক্ত)
  | 'farmer'               // ৬. কৃষক ও খামারী (Single Role)
  | 'tutor_student'        // ৭. গৃহশিক্ষক ও ছাত্র-ছাত্রী (Single Role)
  | 'blood_donor'          // ৮. রক্তদাতা (Single Role - সব রক্তের গ্রুপের ইউজার একই পুলে)
  | 'citizen';             // ৯. সাধারণ নাগরিক (Single Role - হোমমেড পণ্য ও ক্রেতা/সেবাগ্রহীতা)

/**
 * সাব-ক্যাটাগরি কোডসমূহ
 */
export type DriverSubCategory = 
  | 'cng'           // সিএনজি অটোরিকশা
  | 'bike'          // বাইক রাইডার
  | 'easybike'      // ইজিবাইক ও ব্যাটারি রিকশা
  | 'van'           // ভ্যান ও রিক্সা
  | 'microbus'      // মাইক্রোবাস
  | 'private_car'   // প্রাইভেট কার
  | 'ambulance'     // জরুরি অ্যাম্বুলেন্স
  | 'excavator'     // হেস্কোভেটর / মাটি কাটা (বিশেষ যান)
  | 'power_tiller'  // পাওয়ার ট্রিলার / ট্রাক্টর (বিশেষ যান)
  | 'boatman';      // নৌকার মাঝি ও খেয়া (বিশেষ যান)

export type ElectricianMechanicSubCategory = 
  | 'vehicle_mechanic'    // গাড়ি মিস্ত্রি (বাইক, সিএনজি, অটো, শ্যালো)
  | 'house_electrician'   // বাসাবাড়ির ইলেকট্রিশিয়ান ও ওয়্যারিং
  | 'appliance_mechanic'  // টিভি, ফ্রিজ ও ফ্যান মেকানিক
  | 'plumber_pipe';       // প্লাম্বার ও পাইপলাইন মিস্ত্রি

export type LaborerSubCategory = 
  | 'crop_harvesting'     // ফসল কাটা ও রোয়া লাগানো
  | 'soil_earthwork'      // মাটি কাটা ও ভরাট কাজ
  | 'mason_helper'        // রাজমিস্ত্রি ও বাড়ি তৈরি সহায়তাকারী
  | 'general_labor';      // সাধারণ দিনমজুর শ্রমিক

export type HealthWorkerSubCategory = 
  | 'human_health'        // মানব স্বাস্থ্য / ফার্মেসি / প্রাথমিক চিকিৎসা
  | 'veterinary';         // পল্লী পশু চিকিৎসক / ভেটেরিনারি

export type TraderSubCategory = 
  | 'restaurant_hotel'       // রেস্টুরেন্ট / ভাতের হোটেল
  | 'pharmacy'               // ফার্মেসি ও ঔষধালয়
  | 'fertilizer_pesticide'   // সার ও কীটনাশক
  | 'hardware_electronics'   // হার্ডওয়্যার ও ইলেকট্রনিক
  | 'grocery_cosmetics'      // মুদিখানা ও কসমেটিকস
  | 'other_store';           // অন্যান্য দোকান ও ব্যবসা

export type RegistrationSubCategory = 
  | DriverSubCategory 
  | ElectricianMechanicSubCategory 
  | LaborerSubCategory 
  | HealthWorkerSubCategory 
  | TraderSubCategory
  | 'general_pool'; // সাব-ক্যাটাগরি ছাড়া সিঙ্গেল রোলদের জন্য

/**
 * ক্যাটাগরি মেটাডাটা ইন্টারফেস
 */
export interface CategoryDefinition {
  id: MainRegistrationCategory;
  nameBn: string;
  nameEn: string;
  hasSubCategories: boolean;
  icon: string;
  badgeColor: string;
  descriptionBn: string;
  descriptionEn: string;
  subCategories?: {
    id: string;
    nameBn: string;
    nameEn: string;
    isSpecialVehicle?: boolean; // দূরত্ব/কিমি হিসাব প্রযোজ্য নয় এমন যান (যেমন: হেস্কোভেটর, ট্রিলার, নৌকা)
  }[];
}

/**
 * ৮টি মূল ক্যাটাগরির বিস্তারিত কনফিগারেশন তালিকা
 */
export const OFFICIAL_REGISTRATION_CATEGORIES: CategoryDefinition[] = [
  // --- সাব-ক্যাটাগরি যুক্ত ৪টি ক্যাটাগরি ---
  {
    id: 'driver',
    nameBn: 'চালক',
    nameEn: 'Driver & Transport',
    hasSubCategories: true,
    icon: '🚗',
    badgeColor: 'bg-teal-50 text-teal-800 border-teal-200',
    descriptionBn: 'সিএনজি, বাইক, ইজিবাইক, কার, অ্যাম্বুলেন্স, ট্রাক্টর ও নৌকার চালক',
    descriptionEn: 'CNG, bike, easybike, ambulance, tractor and boat operators',
    subCategories: [
      { id: 'cng', nameBn: 'সিএনজি অটোরিকশা', nameEn: 'CNG Auto Rickshaw', isSpecialVehicle: false },
      { id: 'bike', nameBn: 'বাইক রাইডার', nameEn: 'Bike Rider', isSpecialVehicle: false },
      { id: 'easybike', nameBn: 'ইজিবাইক ও ব্যাটারি রিকশা', nameEn: 'Easybike / Electric Rickshaw', isSpecialVehicle: false },
      { id: 'van', nameBn: 'ভ্যান ও প্যাডেল রিক্সা', nameEn: 'Van & Rickshaw', isSpecialVehicle: false },
      { id: 'microbus', nameBn: 'মাইক্রোবাস', nameEn: 'Microbus', isSpecialVehicle: false },
      { id: 'private_car', nameBn: 'প্রাইভেট কার', nameEn: 'Private Car', isSpecialVehicle: false },
      { id: 'ambulance', nameBn: 'জরুরি অ্যাম্বুলেন্স', nameEn: 'Emergency Ambulance', isSpecialVehicle: false },
      // বিশেষ যানবাহন (দূরত্ব/কিমি হিসাব প্রযোজ্য নয়, সময় বা আলোচনা সাপেক্ষে)
      { id: 'excavator', nameBn: 'এক্সকাভেটর / হেস্কোভেটর (মাটি কাটা)', nameEn: 'Excavator (Earthwork)', isSpecialVehicle: true },
      { id: 'power_tiller', nameBn: 'পাওয়ার ট্রিলার / কলেরলাঙ্গল / ট্রাক্টর', nameEn: 'Power Tiller / Tractor (Cultivation)', isSpecialVehicle: true },
      { id: 'boatman', nameBn: 'নৌকার মাঝি ও ট্রলার চালক', nameEn: 'Boatman / Trawler Operator', isSpecialVehicle: true },
    ]
  },
  {
    id: 'electrician_mechanic',
    nameBn: 'ইলেকট্রিশিয়ান ও মেকার',
    nameEn: 'Electrician & Mechanic',
    hasSubCategories: true,
    icon: '🔧',
    badgeColor: 'bg-orange-50 text-orange-800 border-orange-200',
    descriptionBn: 'গাড়ি মিস্ত্রি, বাসাবাড়ির ওয়্যারিং, ফ্রিজ ও টিভি টেকনিশিয়ান',
    descriptionEn: 'Automobile, household electrical wiring and appliance technicians',
    subCategories: [
      { id: 'vehicle_mechanic', nameBn: 'গাড়ি মিস্ত্রি (বাইক/সিএনজি/অটো/শ্যালো)', nameEn: 'Vehicle Mechanic' },
      { id: 'house_electrician', nameBn: 'বাসাবাড়ির ইলেকট্রিশিয়ান ও ওয়্যারিং', nameEn: 'Household Electrician' },
      { id: 'appliance_mechanic', nameBn: 'টিভি, ফ্রিজ ও ফ্যান মিস্ত্রি', nameEn: 'Home Appliance Repair' },
      { id: 'plumber_pipe', nameBn: 'প্লাম্বার ও নলকূপ মিস্ত্রি', nameEn: 'Plumber & Water Pipe Mechanic' },
    ]
  },
  {
    id: 'laborer',
    nameBn: 'কৃষি শ্রমিক ও দিনমজুর',
    nameEn: 'Agricultural & Day Laborer',
    hasSubCategories: true,
    icon: '🌾',
    badgeColor: 'bg-amber-50 text-amber-800 border-amber-200',
    descriptionBn: 'ফসল কাটা, মাটি কাটা, রাজমিস্ত্রি ও দিনমজুর সহায়তা',
    descriptionEn: 'Crop harvesting, earthwork, construction and day labor',
    subCategories: [
      { id: 'crop_harvesting', nameBn: 'ফসল কাটা ও ধান রোয়া', nameEn: 'Crop Harvesting & Sowing' },
      { id: 'soil_earthwork', nameBn: 'মাটি কাটা ও ভরাট কাজ', nameEn: 'Soil & Earthwork' },
      { id: 'mason_helper', nameBn: 'রাজমিস্ত্রি ও বাড়ি তৈরি', nameEn: 'Mason & Construction Laborer' },
      { id: 'general_labor', nameBn: 'সাধারণ দিনমজুর ও মালামাল লোডিং', nameEn: 'General Day Labor' },
    ]
  },
  {
    id: 'health_worker',
    nameBn: 'পল্লী চিকিৎসক ও স্বাস্থ্যসেবা',
    nameEn: 'Rural Health Practitioner',
    hasSubCategories: true,
    icon: '👨‍⚕️',
    badgeColor: 'bg-rose-50 text-rose-800 border-rose-200',
    descriptionBn: 'মানব স্বাস্থ্য প্রাথমিক চিকিৎসা এবং পল্লী পশু চিকিৎসক',
    descriptionEn: 'Human primary healthcare and veterinary services',
    subCategories: [
      { id: 'human_health', nameBn: 'মানব স্বাস্থ্য / ফার্মেসি / প্রাথমিক চিকিৎসা', nameEn: 'Human Primary Health / Pharmacy' },
      { id: 'veterinary', nameBn: 'পল্লী পশু চিকিৎসক (ভেটেরিনারি)', nameEn: 'Rural Veterinary Doctor (Livestock)' },
    ]
  },
  {
    id: 'trader',
    nameBn: 'ব্যবসায়ী ও দোকানদার',
    nameEn: 'Merchant & Local Store',
    hasSubCategories: true,
    icon: '🏪',
    badgeColor: 'bg-blue-50 text-blue-800 border-blue-200',
    descriptionBn: 'রেস্টুরেন্ট, ফার্মেসি, সার-কীটনাশক, হার্ডওয়্যার ও মুদিখানার দোকানদার',
    descriptionEn: 'Restaurant, pharmacy, fertilizer, hardware and grocery merchant',
    subCategories: [
      { id: 'restaurant_hotel', nameBn: 'রেস্টুরেন্ট / ভাতের হোটেল', nameEn: 'Restaurant & Eatery' },
      { id: 'pharmacy', nameBn: 'ফার্মেসি ও ঔষধালয়', nameEn: 'Pharmacy & Medicine Store' },
      { id: 'fertilizer_pesticide', nameBn: 'সার ও কীটনাশক দোকান', nameEn: 'Fertilizer & Pesticide Store' },
      { id: 'hardware_electronics', nameBn: 'হার্ডওয়্যার ও ইলেকট্রনিক', nameEn: 'Hardware & Electronics' },
      { id: 'grocery_cosmetics', nameBn: 'মুদিখানা ও কসমেটিকস', nameEn: 'Grocery & Cosmetics' },
      { id: 'other_store', nameBn: 'অন্যান্য দোকান ও ব্যবসা', nameEn: 'Other Retail Store' },
    ]
  },

  // --- সাব-ক্যাটাগরি ছাড়া ক্যাটাগরি (Single Role) ---
  {
    id: 'farmer',
    nameBn: 'কৃষক ও খামারী',
    nameEn: 'Farmer & Livestock Producer',
    hasSubCategories: false,
    icon: '🌱',
    badgeColor: 'bg-lime-50 text-lime-800 border-lime-200',
    descriptionBn: 'ফসল উৎপাদন, সবজি চাষ, ডেইরি ও হাঁস-মুরগির খামার',
    descriptionEn: 'Crops, vegetable cultivation, dairy and poultry farming'
  },
  {
    id: 'tutor_student',
    nameBn: 'গৃহশিক্ষক ও ছাত্র-ছাত্রী',
    nameEn: 'Tutor & Student',
    hasSubCategories: false,
    icon: '📚',
    badgeColor: 'bg-indigo-50 text-indigo-800 border-indigo-200',
    descriptionBn: 'গৃহশিক্ষক দিচ্ছি বা খুঁজছি এবং স্থানীয় শিক্ষার্থীদের প্ল্যাটফর্ম',
    descriptionEn: 'Offering or seeking home tutoring and academic support'
  },
  {
    id: 'blood_donor',
    nameBn: 'রক্তদাতা',
    nameEn: 'Blood Donor',
    hasSubCategories: false,
    icon: '🩸',
    badgeColor: 'bg-red-50 text-red-800 border-red-200',
    descriptionBn: 'জরুরি প্রয়োজনে স্বেচ্ছায় রক্তদানে আগ্রহী মহৎ প্রাণ নাগরিক',
    descriptionEn: 'Voluntary community blood donors (all groups in unified pool)'
  },
  {
    id: 'citizen',
    nameBn: 'সাধারণ নাগরিক',
    nameEn: 'General Citizen',
    hasSubCategories: false,
    icon: '👤',
    badgeColor: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    descriptionBn: 'গৃহস্থালি বা হোমমেড খাবার/পণ্য বিক্রির পোস্ট ও সকল নাগরিক সেবা গ্রহণকারী',
    descriptionEn: 'Citizen buyer, consumer, and household homemade seller'
  }
];

// ==========================================
// ২. গোপনীয়তা এবং যোগাযোগ সেটিংস
// ==========================================

export interface UserPrivacySettings {
  /** ফোন নম্বর ডিফল্টভাবে গোপন (true) */
  hidePhone: boolean;
  /** গ্রাম ডিফল্টভাবে গোপন (true) */
  hideVillage: boolean;
  /** ওয়ার্ড ডিফল্টভাবে গোপন (true) */
  hideWard: boolean;
  /** অফলাইন কলিং অপশন (ডিফল্ট: false - সেবাদাতা অন করলেই শুধু ওপেন হবে) */
  allowOfflineCalls: boolean;
}

export const DEFAULT_USER_PRIVACY_SETTINGS: UserPrivacySettings = {
  hidePhone: true,
  hideVillage: true,
  hideWard: true,
  allowOfflineCalls: false
};

// ==========================================
// ৩. প্রোফাইল নোটিফিকেশন অন/অফ সেটিংস (৩টি সুইচ)
// ==========================================

export interface UserNotificationSwitches {
  /** ১. কৃষি পণ্যের নোটিফিকেশন (ডিফল্ট: true) */
  notifyAgriProducts: boolean;
  /** ২. গৃহস্থালি পণ্যের নোটিফিকেশন (ডিফল্ট: true) */
  notifyHouseholdProducts: boolean;
  /** ৩. পেশাগত সেবার নোটিফিকেশন (ডিফল্ট: true) */
  notifyProfessionalServices: boolean;
  /** ৪. বাসা ভাড়া ও পাত্র-পাত্রীর সন্ধান চেয়ে পোস্টের বা বিজ্ঞাপনের নোটিফিকেশন (ডিফল্ট: true) */
  notifyHousingAndMatrimony?: boolean;
}

export const DEFAULT_USER_NOTIFICATION_SWITCHES: UserNotificationSwitches = {
  notifyAgriProducts: true,
  notifyHouseholdProducts: true,
  notifyProfessionalServices: true,
  notifyHousingAndMatrimony: true
};

// ==========================================
// ৪. দূরত্ব ও ভাড়া হিসাব লজিক (Fare Config)
// ==========================================

export type FarePricingType = 'negotiable' | 'per_km' | 'special_unit';

export interface DriverFareProfile {
  /** ভাড়া নির্ধারণের ধরন (ঐচ্ছিক: কিমি প্রতি বা আলোচনা সাপেক্ষে) */
  fareType: FarePricingType;
  /** কিলোমিটার প্রতি ভাড়া (টাকায়) - বাইক, সিএনজি, কারের জন্য */
  ratePerKm?: number;
  /** প্রাথমিক ন্যূনতম ভাড়া / বেস ফেয়ার */
  baseFare?: number;
  /** বিশেষ যানবাহনের হিসাব (যেমন: প্রতি ঘণ্টা ৫০০ টাকা, বা বিঘা প্রতি ৮০০ টাকা) */
  specialUnitRateText?: string;
  /** বিশেষ যানবাহনের নোট */
  specialRateNote?: string;
  /** দূরত্ব বা কিমি প্রযোজ্য নয় এমন বিশেষ যান (যেমন হেস্কোভেটর, পাওয়ার ট্রিলার, নৌকা) */
  isSpecialVehicle?: boolean;
  /** অতিরিক্ত নোট */
  note?: string;
}

export const DEFAULT_DRIVER_FARE_PROFILE: DriverFareProfile = {
  fareType: 'negotiable',
  ratePerKm: undefined,
  baseFare: 20,
  specialUnitRateText: 'আলোচনা সাপেক্ষে'
};
