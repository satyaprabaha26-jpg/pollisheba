export interface ServiceTextTranslation {
  titleBn: string;
  titleEn: string;
  subtitleBn: string;
  subtitleEn: string;
  descBn: string;
  descEn: string;
  badgeBn: string;
  badgeEn: string;
  groupBn: string;
  groupEn: string;
}

export const SERVICE_TRANSLATIONS: Record<string, ServiceTextTranslation> = {
  rural_haat: {
    titleBn: '১. পল্লী হাট ও তরিতরকারি',
    titleEn: '1. Rural Haat & Fresh Produce',
    subtitleBn: 'টাটকা শাকসবজি ও গ্রামীণ বাজার',
    subtitleEn: 'Fresh Vegetables & Rural Market',
    descBn: 'গ্রাম, ওয়ার্ড ও উপজেলা ভিত্তিক তাজা শাকসবজি, ফলন ও সরাসরি কৃষক থেকে কেনাবেচা।',
    descEn: 'Village & upazila based direct farm produce, fresh vegetables and fruits marketplace.',
    badgeBn: '🥬 টাটকা পণ্য',
    badgeEn: '🥬 Fresh Produce',
    groupBn: 'কৃষি ও হাট',
    groupEn: 'Agri & Market'
  },
  rural_transport: {
    titleBn: '২. পল্লী পরিবহন ও নিরাপদ চালক',
    titleEn: '2. Rural Transport & Verified Drivers',
    subtitleBn: 'সিএনজি, অটোরিকশা, ভ্যান ও ট্রিপ ট্র্যাকিং',
    subtitleEn: 'CNG, Auto, Van & Live Trip Tracking',
    descBn: 'জরুরি প্রয়োজনে এলাকার বিশ্বস্ত চালকের সরাসরি কল, আনুমানিক ভাড়া ও পরিবারসহ লাইভ ট্র্যাকিং।',
    descEn: 'Direct call to local verified drivers, transparent fare estimate and live journey safety sharing.',
    badgeBn: '🚗 নিরাপদ পরিবহন',
    badgeEn: '🚗 Safe Transport',
    groupBn: 'যোগাযোগ ও পরিবহন',
    groupEn: 'Transport'
  },
  agricultural_labor: {
    titleBn: '৩. কৃষি শ্রমিক বা দিনমজুর',
    titleEn: '3. Agricultural & Day Labor Market',
    subtitleBn: 'ধান কাটা, রোপণ ও কামলা শ্রমিক বাজার',
    subtitleEn: 'Crop Harvesting, Planting & Day Labor',
    descBn: 'মৌসুমি ধান কাটা, রোয়া লাগানো, মাটি কাটা বা দৈনিক মজুরির বিশ্বস্ত শ্রমিক ডাকুন বা কাজের সুযোগ দিন।',
    descEn: 'Find reliable agricultural laborers for harvesting, planting or post day labor job needs.',
    badgeBn: '🌾 শ্রমিক বাজার',
    badgeEn: '🌾 Day Laborers',
    groupBn: 'কৃষি ও হাট',
    groupEn: 'Agri & Market'
  },
  electrician_mechanic: {
    titleBn: '৪. ইলেকট্রিশিয়ান ও মেকার',
    titleEn: '4. Electricians & Emergency Mechanics',
    subtitleBn: 'ওয়্যারিং, ফ্রিজ, ফ্যান ও মোটর মেরামত',
    subtitleEn: 'Wiring, Fridge, Fan & Motor Repair',
    descBn: 'বাড়ি ও খামারের বিদ্যুৎ সমস্যা, ফ্যান, পানির মোটর, ফ্রিজ ও টিভি মেরামতে অভিজ্ঞ মেকার ও মেকানিক।',
    descEn: 'Connect with skilled electricians and mechanics for household appliances and wiring.',
    badgeBn: '🔧 মেকার ও মেকানিক',
    badgeEn: '🔧 Mechanics',
    groupBn: 'শিক্ষা ও কারিগর',
    groupEn: 'Education & Trade'
  },
  tutor_student: {
    titleBn: '৫. গৃহ শিক্ষক',
    titleEn: '5. Home Tutor & Student Network',
    subtitleBn: 'গ্রাম ও ওয়ার্ড ভিত্তিক প্রাইভেট টিউটর ও শিক্ষক',
    subtitleEn: 'Local Village & Ward Tutors',
    descBn: '১ম-দ্বাদশ শ্রেণি ও মাদ্রাসার জন্য অভিজ্ঞ গৃহশিক্ষক খুঁজুন বা শিক্ষক হিসেবে টিউশন বিজ্ঞাপন দিন।',
    descEn: 'Find experienced home tutors for primary, secondary & madrasah or post tuition openings.',
    badgeBn: '📚 গৃহ শিক্ষক',
    badgeEn: '📚 Home Tutors',
    groupBn: 'শিক্ষা ও কারিগর',
    groupEn: 'Education & Trade'
  },
  blood_hospital: {
    titleBn: '৬. জরুরি রক্তদাতা ও ব্লাড ব্যাংক',
    titleEn: '6. Blood Donors & Emergency Hospitals',
    subtitleBn: 'উপজেলা ভিত্তিক লাইভ রক্তদাতা ও অ্যাম্বুলেন্স',
    subtitleEn: 'Local Donors & Ambulance Registry',
    descBn: 'যেকোনো গ্রুপের রক্তের জন্য স্থানীয় স্বেচ্ছাসেবক রক্তদাতা সন্ধান ও জরুরি অ্যাম্বুলেন্স সেবা।',
    descEn: 'Instant search for voluntary blood donors by group and district-wide ambulance dispatch.',
    badgeBn: 'রক্তদান ও সেবা',
    badgeEn: 'Blood & Aid',
    groupBn: 'স্বাস্থ্য ও চিকিৎসা',
    groupEn: 'Health & Medical'
  },
  service_finder: {
    titleBn: '৭. কী সেবা কোথায় কীভাবে পাবেন',
    titleEn: '7. Citizen Service & Office Navigator',
    subtitleBn: 'ইউনিয়ন, ভূমি অফিস, থানা ও হাসপাতালের গাইড',
    subtitleEn: 'Union, Land Office, Police & Hospital Guide',
    descBn: 'কোন সরকারি বা বেসরকারি সেবা কোন অফিসে কীভাবে পাওয়া যায় তার পূর্ণাঙ্গ অনুসন্ধান নির্দেশিকা।',
    descEn: 'Comprehensive guide on where and how to obtain essential government and civil services.',
    badgeBn: 'অফিস গাইড',
    badgeEn: 'Service Guide',
    groupBn: 'সরকারি ও নাগরিক',
    groupEn: 'Government & Civil'
  },
  prayer_islamic: {
    titleBn: '৮. নামাজের সময়সূচি, সালাত ও সূরা',
    titleEn: '8. Prayer Times, Salah & Surah Audio',
    subtitleBn: 'জেলা ভিত্তিক ওয়াক্ত, কিবলা ও অর্থসহ সূরা',
    subtitleEn: 'District Waqt, Qibla & Surah Audio',
    descBn: 'প্রতিটি জেলার ৫ ওয়াক্ত নামাজ ও সাহরি-ইফতারের সঠিক সময়, কিবলা কম্পাস ও প্রয়োজনীয় সূরা।',
    descEn: 'Accurate 5-time prayer schedule, Sahri & Iftar timings, Qibla compass and audio surahs.',
    badgeBn: 'নামাজ ও ইসলামিক',
    badgeEn: 'Prayer & Islamic',
    groupBn: 'ধর্মীয় সেবা',
    groupEn: 'Religious Services'
  },
  crop_doctor: {
    titleBn: '৯. ফসলের ডাক্তার ও শস্য পরামর্শ',
    titleEn: '9. Crop Doctor & Pest Advisory',
    subtitleBn: 'রোগবালাই নির্ণয় ও নিরাময়',
    subtitleEn: 'Disease Diagnosis & Treatment',
    descBn: 'ধান, পাট, ভুট্টা, সবজি ইত্যাদির ছবিযুক্ত রোগবালাই তথ্য, সমাধান ও কৃষি অফিসারের পরামর্শ।',
    descEn: 'Photo-based crop disease diagnosis, organic remedies, and agricultural officer advice.',
    badgeBn: 'কৃষি ও ফসল',
    badgeEn: 'Crop Health',
    groupBn: 'কৃষি ও হাট',
    groupEn: 'Agri & Market'
  },
  market_rates: {
    titleBn: '১০. দৈনিক কৃষি বাজারদর',
    titleEn: '10. Daily Agricultural Market Rates',
    subtitleBn: 'আড়ত ও পাইকারি লাইভ মূল্য',
    subtitleEn: 'Live Wholesale & Retail Prices',
    descBn: 'ধান, চাল, গম, ভুট্টা, আলু, পেঁয়াজ, ডিম, মুরগি ও সারের প্রতিদিনের নির্ভরযোগ্য দরদাম।',
    descEn: 'Daily verified wholesale and retail rates for paddy, rice, vegetables, eggs and fertilizer.',
    badgeBn: 'লাইভ দরদাম',
    badgeEn: 'Live Rates',
    groupBn: 'কৃষি ও হাট',
    groupEn: 'Agri & Market'
  },
  power_bill: {
    titleBn: '১১. পল্লী বিদ্যুৎ বিল ক্যালকুলেটর',
    titleEn: '11. Rural Electricity Bill Calculator',
    subtitleBn: 'ইউনিট অনুযায়ী আবাসিক ও কৃষি বিল হিসাব',
    subtitleEn: 'Residential & Irrigation Tariff Calculation',
    descBn: 'ব্যবহৃত ইউনিট লিখে সরকারি নির্ধারিত বর্তমান ধাপ ও শুল্ক অনুযায়ী নিখুঁত বিলের পরিমাণ হিসাব।',
    descEn: 'Calculate monthly electricity bills by unit tier for residential and irrigation meters.',
    badgeBn: 'বিল হিসাব',
    badgeEn: 'Electricity Bill',
    groupBn: 'বিদ্যুৎ সেবা',
    groupEn: 'Electricity'
  },
  power_complaint: {
    titleBn: '১২. বিদ্যুৎ অভিযোগ ও লোডশেডিং ট্র্যাকার',
    titleEn: '12. Power Outage & Complaint Tracker',
    subtitleBn: 'সমিতি ভিত্তিক অভিযোগ নম্বর ও ট্র্যাকিং',
    subtitleEn: 'PBS Outage Numbers & Quick Redressal',
    descBn: 'ট্রান্সফরমার বা লাইনের ত্রুটি, কম ভোল্টেজ বা দীর্ঘ লোডশেডিংয়ে সংশ্লিষ্ট সমিতির অভিযোগ কেন্দ্র।',
    descEn: 'Direct contact numbers for Palli Bidyut Samiti customer complaints and load-shedding info.',
    badgeBn: 'অভিযোগ কেন্দ্র',
    badgeEn: 'PBS Complaint',
    groupBn: 'বিদ্যুৎ সেবা',
    groupEn: 'Electricity'
  },
  community_clinic: {
    titleBn: '১৩. কমিউনিটি ক্লিনিক ও ফ্রি ওষুধ',
    titleEn: '13. Community Clinic & Free Medicines',
    subtitleBn: '৩০টি সরকারি ফ্রি ওষুধের পূর্ণ তালিকা',
    subtitleEn: 'List of 30 Free Government Medicines',
    descBn: 'নিকটস্থ গ্রামীণ কমিউনিটি ক্লিনিকের সেবা, খোলার সময় ও সরকারের ৩০ প্রকার বিনামূল্যে ওষুধ তালিকা।',
    descEn: 'Services and opening hours of local community clinics with 30 essential free medicines.',
    badgeBn: 'ফ্রি সরকারি ওষুধ',
    badgeEn: 'Free Medicine',
    groupBn: 'স্বাস্থ্য ও চিকিৎসা',
    groupEn: 'Health & Medical'
  },
  first_aid: {
    titleBn: '১৪. জরুরি প্রাথমিক চিকিৎসা গাইড',
    titleEn: '14. Emergency First Aid Guide',
    subtitleBn: 'সাপের কামড়, বিষক্রিয়া, পোড়া ও পানিতে ডুবা',
    subtitleEn: 'Snake Bite, Poisoning, Burns & Drowning',
    descBn: 'জরুরি মুহূর্তে হাসপাতালে নেওয়ার পূর্বের তাৎক্ষণিক জীবন রক্ষাকারী প্রাথমিক চিকিৎসা পদ্ধতি।',
    descEn: 'Crucial life-saving first-aid steps for snakebites, poisoning, heatstroke and burns.',
    badgeBn: 'প্রাথমিক চিকিৎসা',
    badgeEn: 'First Aid',
    groupBn: 'স্বাস্থ্য ও চিকিৎসা',
    groupEn: 'Health & Medical'
  },
  emergency_hotlines: {
    titleBn: '১৫. জরুরি জাতীয় হটলাইন ৯৯৯',
    titleEn: '15. National Emergency Hotlines (999)',
    subtitleBn: 'পুলিশ, ফায়ার সার্ভিস, কৃষি ও স্বাস্থ্য ১০৯',
    subtitleEn: 'Police, Fire, Agri 16123, Health 16263, Women 109',
    descBn: 'টোল-ফ্রি জাতীয় ৯৯৯, কৃষি ১৬১২৩, স্বাস্থ্য ১৬২৬৩, তথ্য ৩৩৩ ও নারী-শিশু ১০৯ সরাসরি কল।',
    descEn: 'One-touch direct dialing to all official national emergency toll-free service numbers.',
    badgeBn: 'জরুরি ৯৯৯',
    badgeEn: 'Emergency 999',
    groupBn: 'সরকারি ও নাগরিক',
    groupEn: 'Government & Civil'
  },
  legal_aid_police: {
    titleBn: '১৬. আইন, আদালত ও সরকারি সাহায্য',
    titleEn: '16. Legal Aid, Police & Court Assistance',
    subtitleBn: 'বিনামূল্যে সরকারি আইনি সহায়তা (১৬৪৩০)',
    subtitleEn: 'Free Government Legal Aid (16430)',
    descBn: 'অসহায়দের জন্য বিনা খরচে সরকারি উকিল, জাতীয় আইনগত সহায়তা (১৬৪৩০) ও জিডি করার নিয়ম।',
    descEn: 'Access free government legal aid lawyers, National Legal Aid helpline 16430 & GD info.',
    badgeBn: 'আইনি সহায়তা',
    badgeEn: 'Legal Aid',
    groupBn: 'সরকারি ও নাগরিক',
    groupEn: 'Government & Civil'
  },
  citizen_services: {
    titleBn: '১৭. ইউনিয়ন পরিষদ ও নাগরিক সনদ',
    titleEn: '17. Union Parishad & Citizen Certificates',
    subtitleBn: 'জন্ম নিবন্ধন, ওয়ারিশ ও ট্রেড লাইসেন্স গাইড',
    subtitleEn: 'Birth Reg, Inheritance & Trade License',
    descBn: 'ইউপি নাগরিক সনদ, ওয়ারিশ কায়েম, জন্ম ও মৃত্যু নিবন্ধন এবং ট্রেড লাইসেন্স প্রাপ্তির নিয়ম।',
    descEn: 'Step-by-step guidance for obtaining citizen certificates, birth registrations & licenses.',
    badgeBn: 'ইউপি নাগরিক সেবা',
    badgeEn: 'Union Services',
    groupBn: 'সরকারি ও নাগরিক',
    groupEn: 'Government & Civil'
  },
  social_allowances: {
    titleBn: '১৮. সামাজিক নিরাপত্তা ভাতা যাচাই',
    titleEn: '18. Social Safety Net Allowance Check',
    subtitleBn: 'বয়স্ক, বিধবা ও প্রতিবন্ধী ভাতা নির্দেশিকা',
    subtitleEn: 'Elderly, Widow & Disability Allowances',
    descBn: 'সরকারি বয়স্ক ভাতা, বিধবা ভাতা ও প্রতিবন্ধী ভাতা পাওয়ার যোগ্যতা, আবেদন ও তথ্য যাচাই।',
    descEn: 'Eligibility criteria, application process, and status verification for social safety nets.',
    badgeBn: 'ভাতা ও অনুদান',
    badgeEn: 'Allowances',
    groupBn: 'সরকারি ও নাগরিক',
    groupEn: 'Government & Civil'
  },
  vaccine_tracker: {
    titleBn: '১৯. শিশুর ইপিআই টিকাদান কার্ড',
    titleEn: '19. Child EPI Vaccination Tracker',
    subtitleBn: 'বিসিজি, পোলিও ও হামের ডিজিটাল শিডিউল',
    subtitleEn: 'BCG, Polio, Measles Immunization Schedule',
    descBn: 'শিশুর বয়স অনুযায়ী সরকারি টিকাদান কেন্দ্রের শিডিউল, ডোজ ট্র্যাকিং ও এসএমএস রিমাইন্ডার।',
    descEn: 'Digital immunization schedule for infants with dose tracking and reminder guidance.',
    badgeBn: 'ইপিআই টিকা',
    badgeEn: 'EPI Vaccine',
    groupBn: 'স্বাস্থ্য ও চিকিৎসা',
    groupEn: 'Health & Medical'
  },
  fertilizer_calc: {
    titleBn: '২০. সুষম সার ক্যালকুলেটর',
    titleEn: '20. Balanced Fertilizer Calculator',
    subtitleBn: 'জমির মাপ অনুযায়ী বৈজ্ঞানিক ডোজ',
    subtitleEn: 'Scientific Doses by Land Size',
    descBn: 'শতক, বিঘা বা একর অনুযায়ী ইউরিয়া, টিএসপি, ডিএপি ও পটাশ সারের সুষম বৈজ্ঞানিক পরিমাপ।',
    descEn: 'Calculate exact scientific dosages of Urea, TSP, DAP and Potash for your parcel.',
    badgeBn: 'সার হিসাব',
    badgeEn: 'Fertilizer Calc',
    groupBn: 'কৃষি ও হাট',
    groupEn: 'Agri & Market'
  },
  crop_calendar: {
    titleBn: '২১. মৌসুমি ফসল ও চাষাবাদ ক্যালেন্ডার',
    titleEn: '21. Seasonal Crop & Cultivation Calendar',
    subtitleBn: 'রবি, খরিপ-১ ও খরিপ-২ সময়সূচি',
    subtitleEn: 'Rabi, Kharif-1 & Kharif-2 Crop Timetable',
    descBn: 'কোন মাসে কোন ফসল চাষ করবেন, বীজতলা তৈরি ও ফলন তোলার ১২ মাসের কৃষি পঞ্জিকা।',
    descEn: 'Month-by-month agricultural calendar detailing sowing and harvest times across 12 months.',
    badgeBn: 'চাষ পঞ্জিকা',
    badgeEn: 'Crop Timetable',
    groupBn: 'কৃষি ও হাট',
    groupEn: 'Agri & Market'
  },
  livestock_farming: {
    titleBn: '২২. পশুসম্পদ ও মৎস্য পালন',
    titleEn: '22. Livestock Care & Fish Farming',
    subtitleBn: 'গরু-ছাগলের খামার, রোগবালাই ও মাছের চাষ',
    subtitleEn: 'Cattle, Goat & Commercial Fish Farming',
    descBn: 'গবাদিপশুর ক্ষুরা রোগ, কৃমি ও লাম্পি স্কিন প্রতিরোধ, টিকাদান এবং আধুনিক বায়োফ্লক ও পুকুরে মাছ চাষ।',
    descEn: 'Veterinary care for cattle and poultry diseases alongside scientific aquaculture practices.',
    badgeBn: 'পশুসম্পদ ও মৎস্য',
    badgeEn: 'Livestock Care',
    groupBn: 'কৃষি ও হাট',
    groupEn: 'Agri & Market'
  },
  land_calculator: {
    titleBn: '২৩. আমিন ও জমি পরিমাপক ক্যালকুলেটর',
    titleEn: '23. Land Area & Farayej Calculator',
    subtitleBn: 'শতক, কাঠা, বিঘা, একর ও ফারায়েজ',
    subtitleEn: 'Shotok, Katha, Bigha, Acre & Inheritance',
    descBn: 'জমি পরিমাপ, ত্রিভুজ-চতুর্ভুজ জমির নিখুঁত ক্ষেত্রফল ও উত্তরাধিকার ফারায়েজ বন্টন।',
    descEn: 'Accurate rural land area converter with irregular polygon solver and Islamic inheritance division.',
    badgeBn: 'আমিন ক্যালকুলেটর',
    badgeEn: 'Land Area Calc',
    groupBn: 'হিসাব ও ক্যালকুলেটর',
    groupEn: 'Calculators'
  },
  loan_calculator: {
    titleBn: '২৪. কৃষি ঋণ ও কিস্তি হিসাবক',
    titleEn: '24. Agricultural Loan & EMI Calculator',
    subtitleBn: 'সহজ শর্তের ব্যাংক ঋণ ও সুদ হিসাব',
    subtitleEn: 'Subsidized Agri Loan & Interest Calculator',
    descBn: 'বাংলাদেশ ব্যাংক ও কৃষি ব্যাংকের ৪% রেয়াতি সুদের কৃষি ঋণ ও কিস্তির নিখুঁত হিসাব।',
    descEn: 'Calculate EMIs and interest amounts for 4% subsidized agri bank loans.',
    badgeBn: 'ঋণ হিসাব',
    badgeEn: 'Loan Calc',
    groupBn: 'হিসাব ও ক্যালকুলেটর',
    groupEn: 'Calculators'
  },
  housing_rental: {
    titleBn: '২৫. আবাসন ও বাসা ভাড়া',
    titleEn: '25. Housing & House Rental',
    subtitleBn: 'ফ্যামিলি বাসা, মেস, সাবলেট ও দোকান',
    subtitleEn: 'Family Houses, Mess, Sublet & Commercial Stores',
    descBn: 'দালালমুক্ত বাসা ও মেস ভাড়া অনুসন্ধান, সরাসরি বাড়ির মালিকের সাথে যোগাযোগ ও নিরাপদ আবাসন।',
    descEn: 'Direct house and room rentals without middlemen, direct owner contact and verified rural & town living.',
    badgeBn: '🏠 বাসা ভাড়া',
    badgeEn: 'House Rental',
    groupBn: 'আবাসন ও পরিবার',
    groupEn: 'Housing & Family'
  },
  matrimony: {
    titleBn: '২৬. পাত্র-পাত্রীর সন্ধান',
    titleEn: '26. Matrimony & Matchmaking',
    subtitleBn: 'শালীন ও ছবিমুক্ত পারিবারিক মেচমেকিং',
    subtitleEn: 'Dignified & Photo-Free Family Matchmaking',
    descBn: 'কঠোর গোপনীয়তা ও শতভাগ ছবিমুক্ত নিয়মে পাত্র ও পাত্রীর সন্ধান, সরাসরি পরিবারের সাথে যোগাযোগ।',
    descEn: 'Strict privacy and 100% photo-free rural & town matchmaking with direct verified guardian contact.',
    badgeBn: '💍 পাত্র-পাত্রী',
    badgeEn: 'Matchmaking',
    groupBn: 'আবাসন ও পরিবার',
    groupEn: 'Housing & Family'
  }
};
