// Comprehensive Bangladesh Administrative Location Data (All 64 Districts, 495+ Upazilas/Thanas & Unions)
import { UpazilaData, DistrictLocationData } from './locations/types';
import { DHAKA_LOCATIONS } from './locations/dhaka';
import { CHATTOGRAM_LOCATIONS } from './locations/chattogram';
import { RAJSHAHI_LOCATIONS } from './locations/rajshahi';
import { KHULNA_LOCATIONS } from './locations/khulna';
import { BARISHAL_LOCATIONS } from './locations/barishal';
import { SYLHET_LOCATIONS } from './locations/sylhet';
import { RANGPUR_LOCATIONS } from './locations/rangpur';
import { MYMENSINGH_LOCATIONS } from './locations/mymensingh';

export type { UpazilaData, DistrictLocationData };

// All 64 districts in Bangladesh with their complete upazilas and unions
export const BANGLADESH_LOCATIONS: DistrictLocationData[] = [
  ...DHAKA_LOCATIONS,
  ...CHATTOGRAM_LOCATIONS,
  ...RAJSHAHI_LOCATIONS,
  ...KHULNA_LOCATIONS,
  ...BARISHAL_LOCATIONS,
  ...SYLHET_LOCATIONS,
  ...RANGPUR_LOCATIONS,
  ...MYMENSINGH_LOCATIONS
];

export interface CustomLocationRecord {
  id: string;
  district: string;
  upazila: string;
  union: string;
  village?: string;
  submittedBy?: string;
  phone?: string;
  timestamp: string;
  status: 'active' | 'pending' | 'verified';
}

export const getCustomLocations = (): CustomLocationRecord[] => {
  try {
    const saved = localStorage.getItem('pollisheba_custom_locations');
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error('Error loading custom locations:', e);
  }
  return [];
};

export const addCustomLocation = (record: Omit<CustomLocationRecord, 'id' | 'timestamp' | 'status'>): CustomLocationRecord => {
  const customList = getCustomLocations();
  const newRecord: CustomLocationRecord = {
    ...record,
    id: `loc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toLocaleString('bn-BD'),
    status: 'verified' // Auto-active so the user can immediately use it
  };

  customList.unshift(newRecord);
  try {
    localStorage.setItem('pollisheba_custom_locations', JSON.stringify(customList));
    window.dispatchEvent(new CustomEvent('pollisheba_location_added', { detail: newRecord }));
  } catch (e) {
    console.error('Error saving custom location:', e);
  }
  return newRecord;
};

// Helper to get upazilas for a district (always returns matching upazilas or fallback)
export const getUpazilasForDistrict = (districtName: string): string[] => {
  if (!districtName || districtName === 'সকল জেলা' || districtName.includes('সকল জেলা')) return [];
  const normalizedSearch = districtName.trim();
  const found = BANGLADESH_LOCATIONS.find(d => 
    d.district === normalizedSearch || 
    normalizedSearch.includes(d.district) || 
    d.district.includes(normalizedSearch)
  );
  
  const upazilaSet = new Set<string>();

  if (found && found.upazilas && found.upazilas.length > 0) {
    found.upazilas.forEach(u => upazilaSet.add(u.name));
  } else {
    upazilaSet.add(`${districtName} সদর`);
    upazilaSet.add('উত্তর উপজেলা');
    upazilaSet.add('দক্ষিণ উপজেলা');
    upazilaSet.add('পৌরসভা এলাকা');
  }

  // Merge any user-submitted custom upazilas for this district
  const custom = getCustomLocations();
  custom
    .filter(c => c.district.trim() === normalizedSearch && c.upazila)
    .forEach(c => upazilaSet.add(c.upazila.trim()));

  return Array.from(upazilaSet);
};

// Helper to get unions for an upazila (always returns matching unions or fallback)
export const getUnionsForUpazila = (districtName: string, upazilaName: string): string[] => {
  if (!districtName || !upazilaName || upazilaName === 'সকল উপজেলা' || upazilaName.includes('সকল উপজেলা')) return [];
  const normDistrict = districtName.trim();
  const normUpazila = upazilaName.trim();
  
  const dist = BANGLADESH_LOCATIONS.find(d => 
    d.district === normDistrict || 
    normDistrict.includes(d.district) || 
    d.district.includes(normDistrict)
  );
  
  const unionSet = new Set<string>();

  if (dist) {
    const upz = dist.upazilas.find(u => 
      u.name === normUpazila || 
      normUpazila.includes(u.name) || 
      u.name.includes(normUpazila)
    );
    if (upz && upz.unions && upz.unions.length > 0) {
      upz.unions.forEach(un => unionSet.add(un));
    }
  }

  if (unionSet.size === 0) {
    unionSet.add(`${upazilaName} সদর ইউনিয়ন`);
    unionSet.add('১নং ইউনিয়ন / পৌর ওয়ার্ড ১-৩');
    unionSet.add('২নং ইউনিয়ন / পৌর ওয়ার্ড ৪-৬');
    unionSet.add('৩নং ইউনিয়ন / পৌর ওয়ার্ড ৭-৯');
    unionSet.add('অন্যান্য ইউনিয়ন / এলাকা');
  }

  // Merge any user-submitted custom unions for this upazila & district
  const custom = getCustomLocations();
  custom
    .filter(c => 
      c.district.trim() === normDistrict && 
      c.upazila.trim() === normUpazila && 
      c.union
    )
    .forEach(c => unionSet.add(c.union.trim()));

  return Array.from(unionSet);
};

// Helper to get division for a district
export const getDivisionForDistrict = (districtName: string): string => {
  if (!districtName) return 'বাংলাদেশ';
  const found = BANGLADESH_LOCATIONS.find(d => 
    d.district === districtName || 
    districtName.includes(d.district) || 
    d.district.includes(districtName)
  );
  return found ? found.division : 'বাংলাদেশ';
};

// Helper to reliably find the parent district of any upazila name in Bangladesh
export const getDistrictForUpazila = (upazilaName: string): string | null => {
  if (!upazilaName || upazilaName === 'সকল উপজেলা') return null;
  const norm = upazilaName.trim();
  const clean = norm.replace(' সদর', '').trim();

  // Search exact or clean match across all districts
  for (const d of BANGLADESH_LOCATIONS) {
    for (const u of d.upazilas) {
      if (u.name === norm || u.name === clean || u.name.replace(' সদর', '').trim() === clean) {
        return d.district;
      }
    }
  }

  // Also check custom locations
  const custom = getCustomLocations();
  const matchCustom = custom.find(c => c.upazila === norm || c.upazila === clean);
  if (matchCustom) return matchCustom.district;

  return null;
};
