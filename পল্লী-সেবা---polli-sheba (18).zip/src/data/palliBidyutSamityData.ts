export interface PalliBidyutSamity {
  id: string;
  name: string;
  district: string;
  division: string;
  headquarters: string;
  hotline: string;
  emergencyComplainNumber: string;
}

export const ALL_PALLI_BIDYUT_SAMITIES: PalliBidyutSamity[] = [
  // খুলনা বিভাগ (Khulna Division - Including Satkhira, Khulna, Jessore, etc.)
  {
    id: 'pbs-khulna-satkhira',
    name: 'সাতক্ষীরা পল্লী বিদ্যুৎ সমিতি',
    district: 'সাতক্ষীরা',
    division: 'খুলনা',
    headquarters: 'ঝাউডাঙ্গা, সাতক্ষীরা সদর',
    hotline: '০১৭৬৯-৪০২০১৫',
    emergencyComplainNumber: '০১৩১৭-৭৩১৮৭২'
  },
  {
    id: 'pbs-khulna-main',
    name: 'খুলনা পল্লী বিদ্যুৎ সমিতি',
    district: 'খুলনা',
    division: 'খুলনা',
    headquarters: 'ফুলতলা, খুলনা',
    hotline: '০১৭৬৯-৪০২২০০',
    emergencyComplainNumber: '০১৭৬৯-৪০২২০১'
  },
  {
    id: 'pbs-jessore-1',
    name: 'যশোর পল্লী বিদ্যুৎ সমিতি-১',
    district: 'যশোর',
    division: 'খুলনা',
    headquarters: 'তপোধন, যশোর সদর',
    hotline: '০১৭৬৯-৪০২২১০',
    emergencyComplainNumber: '০১৭৬৯-৪০২২১১'
  },
  {
    id: 'pbs-jessore-2',
    name: 'যশোর পল্লী বিদ্যুৎ সমিতি-২',
    district: 'যশোর',
    division: 'খুলনা',
    headquarters: 'মনিরামপুর, যশোর',
    hotline: '০১৭৬৯-৪০২২২০',
    emergencyComplainNumber: '০১৭৬৯-৪০২২২১'
  },
  {
    id: 'pbs-bagerhat',
    name: 'বাগেরহাট পল্লী বিদ্যুৎ সমিতি',
    district: 'বাগেরহাট',
    division: 'খুলনা',
    headquarters: 'পোলঘাট, বাগেরহাট সদর',
    hotline: '০১৭৬৯-৪০২৩০০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৩০১'
  },
  {
    id: 'pbs-jhenaidah',
    name: 'ঝিনাইদহ পল্লী বিদ্যুৎ সমিতি',
    district: 'ঝিনাইদহ',
    division: 'খুলনা',
    headquarters: 'রাউতাইল, ঝিনাইদহ সদর',
    hotline: '০১৭৬৯-৪০২৩১০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৩১১'
  },
  {
    id: 'pbs-magura',
    name: 'মাগুরা পল্লী বিদ্যুৎ সমিতি',
    district: 'মাগুরা',
    division: 'খুলনা',
    headquarters: 'পারনান্দুয়ালী, মাগুরা সদর',
    hotline: '০১৭৬৯-৪০২৩২০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৩২১'
  },
  {
    id: 'pbs-narail',
    name: 'নড়াইল পল্লী বিদ্যুৎ সমিতি',
    district: 'নড়াইল',
    division: 'খুলনা',
    headquarters: 'তুলারামপুর, নড়াইল সদর',
    hotline: '০১৭৬৯-৪০২৩৩০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৩৩১'
  },
  {
    id: 'pbs-kushtia',
    name: 'কুষ্টিয়া পল্লী বিদ্যুৎ সমিতি',
    district: 'কুষ্টিয়া',
    division: 'খুলনা',
    headquarters: 'বারখাদা, কুষ্টিয়া সদর',
    hotline: '০১৭৬৯-৪০২৩৪০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৩৪১'
  },
  {
    id: 'pbs-chuadanga',
    name: 'চুয়াডাঙ্গা পল্লী বিদ্যুৎ সমিতি',
    district: 'চুয়াডাঙ্গা',
    division: 'খুলনা',
    headquarters: 'হায়দারপুর, চুয়াডাঙ্গা সদর',
    hotline: '০১৭৬৯-৪০২৩৫০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৩৫১'
  },
  {
    id: 'pbs-meherpur',
    name: 'মেহেরপুর পল্লী বিদ্যুৎ সমিতি',
    district: 'মেহেরপুর',
    division: 'খুলনা',
    headquarters: 'মেহেরপুর সদর',
    hotline: '০১৭৬৯-৪০২৩৬০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৩৬১'
  },

  // ঢাকা বিভাগ (Dhaka Division)
  {
    id: 'pbs-dhaka-1',
    name: 'ঢাকা পল্লী বিদ্যুৎ সমিতি-১',
    district: 'ঢাকা',
    division: 'ঢাকা',
    headquarters: 'পলাশবাড়ী, সাভার, ঢাকা',
    hotline: '০১৭৬৯-৪০২১০০',
    emergencyComplainNumber: '০১৭৬৯-৪০২১০১'
  },
  {
    id: 'pbs-dhaka-2',
    name: 'ঢাকা পল্লী বিদ্যুৎ সমিতি-২',
    district: 'ঢাকা',
    division: 'ঢাকা',
    headquarters: 'বাগমারা, নবাবগঞ্জ, ঢাকা',
    hotline: '০১৭৬৯-৪০২১১০',
    emergencyComplainNumber: '০১৭৬৯-৪০২১১১'
  },
  {
    id: 'pbs-dhaka-3',
    name: 'ঢাকা পল্লী বিদ্যুৎ সমিতি-৩',
    district: 'ঢাকা',
    division: 'ঢাকা',
    headquarters: 'কালিয়াকৈর, গাজীপুর / ধামরাই',
    hotline: '০১৭৬৯-৪০২১২০',
    emergencyComplainNumber: '০১৭৬৯-৪০২১২১'
  },
  {
    id: 'pbs-dhaka-4',
    name: 'ঢাকা পল্লী বিদ্যুৎ সমিতি-৪',
    district: 'ঢাকা',
    division: 'ঢাকা',
    headquarters: 'হাসনাবাদ, দক্ষিণ কেরানীগঞ্জ, ঢাকা',
    hotline: '০১৭৬৯-৪০২১৩০',
    emergencyComplainNumber: '০১৭৬৯-৪০২১৩১'
  },
  {
    id: 'pbs-gazipur-1',
    name: 'গাজীপুর পল্লী বিদ্যুৎ সমিতি-১',
    district: 'গাজীপুর',
    division: 'ঢাকা',
    headquarters: 'শ্রীপুর, গাজীপুর',
    hotline: '০১৭৬৯-৪০২১৪০',
    emergencyComplainNumber: '০১৭৬৯-৪০২১৪১'
  },
  {
    id: 'pbs-gazipur-2',
    name: 'গাজীপুর পল্লী বিদ্যুৎ সমিতি-২',
    district: 'গাজীপুর',
    division: 'ঢাকা',
    headquarters: 'রাজেন্দ্রপুর, গাজীপুর সদর',
    hotline: '০১৭৬৯-৪০২১৫০',
    emergencyComplainNumber: '০১৭৬৯-৪০২১৫১'
  },
  {
    id: 'pbs-narayanganj-1',
    name: 'নারায়ণগঞ্জ পল্লী বিদ্যুৎ সমিতি-১',
    district: 'নারায়ণগঞ্জ',
    division: 'ঢাকা',
    headquarters: 'সোনারগাঁ, নারায়ণগঞ্জ',
    hotline: '০১৭৬৯-৪০২১৬০',
    emergencyComplainNumber: '০১৭৬৯-৪০২১৬১'
  },
  {
    id: 'pbs-narayanganj-2',
    name: 'নারায়ণগঞ্জ পল্লী বিদ্যুৎ সমিতি-২',
    district: 'নারায়ণগঞ্জ',
    division: 'ঢাকা',
    headquarters: 'মদনপুর, বন্দর, নারায়ণগঞ্জ',
    hotline: '০১৭৬৯-৪০২১৭০',
    emergencyComplainNumber: '০১৭৬৯-৪০২১৭১'
  },
  {
    id: 'pbs-narsingdi-1',
    name: 'নরসিংদী পল্লী বিদ্যুৎ সমিতি-১',
    district: 'নরসিংদী',
    division: 'ঢাকা',
    headquarters: 'মাধবদী, নরসিংদী',
    hotline: '০১৭৬৯-৪০২১৮০',
    emergencyComplainNumber: '০১৭৬৯-৪০২১৮১'
  },
  {
    id: 'pbs-narsingdi-2',
    name: 'নরসিংদী পল্লী বিদ্যুৎ সমিতি-২',
    district: 'নরসিংদী',
    division: 'ঢাকা',
    headquarters: 'শিবপুর, নরসিংদী',
    hotline: '০১৭৬৯-৪০২১৯০',
    emergencyComplainNumber: '০১৭৬৯-৪০২১৯১'
  },
  {
    id: 'pbs-munshiganj',
    name: 'মুন্সীগঞ্জ পল্লী বিদ্যুৎ সমিতি',
    district: 'মুন্সীগঞ্জ',
    division: 'ঢাকা',
    headquarters: 'সিপাহীপাড়া, মুন্সীগঞ্জ সদর',
    hotline: '০১৭৬৯-৪০২৪০০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৪০১'
  },
  {
    id: 'pbs-manikganj',
    name: 'মানিকগঞ্জ পল্লী বিদ্যুৎ সমিতি',
    district: 'মানিকগঞ্জ',
    division: 'ঢাকা',
    headquarters: 'বাগজান, মানিকগঞ্জ সদর',
    hotline: '০১৭৬৯-৪০২৪১০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৪১১'
  },
  {
    id: 'pbs-tangail',
    name: 'টাঙ্গাইল পল্লী বিদ্যুৎ সমিতি',
    district: 'টাঙ্গাইল',
    division: 'ঢাকা',
    headquarters: 'আশেকপুর, টাঙ্গাইল সদর',
    hotline: '০১৭৬৯-৪০২৪২০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৪২১'
  },
  {
    id: 'pbs-kishoreganj',
    name: 'কিশোরগঞ্জ পল্লী বিদ্যুৎ সমিতি',
    district: 'কিশোরগঞ্জ',
    division: 'ঢাকা',
    headquarters: 'মটখলা, কিশোরগঞ্জ সদর',
    hotline: '০১৭৬৯-৪০২৪৩০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৪৩১'
  },
  {
    id: 'pbs-faridpur',
    name: 'ফরিদপুর পল্লী বিদ্যুৎ সমিতি',
    district: 'ফরিদপুর',
    division: 'ঢাকা',
    headquarters: 'কানাইপুর, ফরিদপুর সদর',
    hotline: '০১৭৬৯-৪০২৪৪০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৪৪১'
  },
  {
    id: 'pbs-rajbari',
    name: 'রাজবাড়ী পল্লী বিদ্যুৎ সমিতি',
    district: 'রাজবাড়ী',
    division: 'ঢাকা',
    headquarters: 'রাজবাড়ী সদর',
    hotline: '০১৭৬৯-৪০২৪৫০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৪৫১'
  },
  {
    id: 'pbs-gopalganj',
    name: 'গোপালগঞ্জ পল্লী বিদ্যুৎ সমিতি',
    district: 'গোপালগঞ্জ',
    division: 'ঢাকা',
    headquarters: 'ঘোনাপাড়া, গোপালগঞ্জ সদর',
    hotline: '০১৭৬৯-৪০২৪৬০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৪৬১'
  },
  {
    id: 'pbs-madaripur',
    name: 'মাদারীপুর পল্লী বিদ্যুৎ সমিতি',
    district: 'মাদারীপুর',
    division: 'ঢাকা',
    headquarters: 'মাদারীপুর সদর',
    hotline: '০১৭৬৯-৪০২৪৭০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৪৭১'
  },
  {
    id: 'pbs-shariatpur',
    name: 'শরীয়তপুর পল্লী বিদ্যুৎ সমিতি',
    district: 'শরীয়তপুর',
    division: 'ঢাকা',
    headquarters: 'নড়িয়া / শরীয়তপুর সদর',
    hotline: '০১৭৬৯-৪০২৪৮০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৪৮১'
  },

  // রাজশাহী বিভাগ (Rajshahi Division)
  {
    id: 'pbs-rajshahi',
    name: 'রাজশাহী পল্লী বিদ্যুৎ সমিতি',
    district: 'রাজশাহী',
    division: 'রাজশাহী',
    headquarters: 'নওদাপাড়া, রাজশাহী সদর',
    hotline: '০১৭৬৯-৪০২৫০০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৫০১'
  },
  {
    id: 'pbs-chapainawabganj',
    name: 'চাঁপাইনবাবগঞ্জ পল্লী বিদ্যুৎ সমিতি',
    district: 'চাঁপাইনবাবগঞ্জ',
    division: 'রাজশাহী',
    headquarters: 'ঝিলিম রোড, চাঁপাইনবাবগঞ্জ সদর',
    hotline: '০১৭৬৯-৪০২৫১০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৫১১'
  },
  {
    id: 'pbs-natore-1',
    name: 'নাটোর পল্লী বিদ্যুৎ সমিতি-১',
    district: 'নাটোর',
    division: 'রাজশাহী',
    headquarters: 'নাটোর সদর',
    hotline: '০১৭৬৯-৪০২৫২০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৫২১'
  },
  {
    id: 'pbs-natore-2',
    name: 'নাটোর পল্লী বিদ্যুৎ সমিতি-২',
    district: 'নাটোর',
    division: 'রাজশাহী',
    headquarters: 'বনপাড়া, বড়াইগ্রাম, নাটোর',
    hotline: '০১৭৬৯-৪০২৫৩০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৫৩১'
  },
  {
    id: 'pbs-naogaon-1',
    name: 'নওগাঁ পল্লী বিদ্যুৎ সমিতি-১',
    district: 'নওগাঁ',
    division: 'রাজশাহী',
    headquarters: 'চৌmashia, নওগাঁ সদর',
    hotline: '০১৭৬৯-৪০২৫৪০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৫৪১'
  },
  {
    id: 'pbs-naogaon-2',
    name: 'নওগাঁ পল্লী বিদ্যুৎ সমিতি-২',
    district: 'নওগাঁ',
    division: 'রাজশাহী',
    headquarters: 'পত্নীতলা, নওগাঁ',
    hotline: '০১৭৬৯-৪০২৫৫০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৫৫১'
  },
  {
    id: 'pbs-pabna-1',
    name: 'পাবনা পল্লী বিদ্যুৎ সমিতি-১',
    district: 'পাবনা',
    division: 'রাজশাহী',
    headquarters: 'চাটমোহর, পাবনা',
    hotline: '০১৭৬৯-৪০২৫৬০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৫৬১'
  },
  {
    id: 'pbs-pabna-2',
    name: 'পাবনা পল্লী বিদ্যুৎ সমিতি-২',
    district: 'পাবনা',
    division: 'রাজশাহী',
    headquarters: 'ঈশ্বরদী, পাবনা',
    hotline: '০১৭৬৯-৪০২৫৭০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৫৭১'
  },
  {
    id: 'pbs-sirajganj-1',
    name: 'সিরাজগঞ্জ পল্লী বিদ্যুৎ সমিতি-১',
    district: 'সিরাজগঞ্জ',
    division: 'রাজশাহী',
    headquarters: 'শাহজাদপুর, সিরাজগঞ্জ',
    hotline: '০১৭৬৯-৪০২৫৮০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৫৮১'
  },
  {
    id: 'pbs-sirajganj-2',
    name: 'সিরাজগঞ্জ পল্লী বিদ্যুৎ সমিতি-২',
    district: 'সিরাজগঞ্জ',
    division: 'রাজশাহী',
    headquarters: 'বেলকুচি, সিরাজগঞ্জ',
    hotline: '০১৭৬৯-৪০২৫৯০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৫৯১'
  },
  {
    id: 'pbs-bogura-1',
    name: 'বগুড়া পল্লী বিদ্যুৎ সমিতি-১',
    district: 'বগুড়া',
    division: 'রাজশাহী',
    headquarters: 'উপশহর, বগুড়া সদর',
    hotline: '০১৭৬৯-৪০২৬০০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৬০১'
  },
  {
    id: 'pbs-bogura-2',
    name: 'বগুড়া পল্লী বিদ্যুৎ সমিতি-২',
    district: 'বগুড়া',
    division: 'রাজশাহী',
    headquarters: 'দুপচাঁচিয়া, বগুড়া',
    hotline: '০১৭৬৯-৪০২৬১০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৬১১'
  },
  {
    id: 'pbs-joypurhat',
    name: 'জয়পুরহাট পল্লী বিদ্যুৎ সমিতি',
    district: 'জয়পুরহাট',
    division: 'রাজশাহী',
    headquarters: 'জয়পুরহাট সদর',
    hotline: '০১৭৬৯-৪০২৬২০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৬২১'
  },

  // রংপুর বিভাগ (Rangpur Division)
  {
    id: 'pbs-rangpur-1',
    name: 'রংপুর পল্লী বিদ্যুৎ সমিতি-১',
    district: 'রংপুর',
    division: 'রংপুর',
    headquarters: 'পাগলাপীর, রংপুর',
    hotline: '০১৭৬৯-৪০২৭০০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৭০১'
  },
  {
    id: 'pbs-rangpur-2',
    name: 'রংপুর পল্লী বিদ্যুৎ সমিতি-২',
    district: 'রংপুর',
    division: 'রংপুর',
    headquarters: 'পীরগঞ্জ, রংপুর',
    hotline: '০১৭৬৯-৪০২৭১০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৭১১'
  },
  {
    id: 'pbs-dinajpur-1',
    name: 'দিনাজপুর পল্লী বিদ্যুৎ সমিতি-১',
    district: 'দিনাজপুর',
    division: 'রংপুর',
    headquarters: 'উত্তর গোবিন্দপুর, দিনাজপুর সদর',
    hotline: '০১৭৬৯-৪০২৭২০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৭২১'
  },
  {
    id: 'pbs-dinajpur-2',
    name: 'দিনাজপুর পল্লী বিদ্যুৎ সমিতি-২',
    district: 'দিনাজপুর',
    division: 'রংপুর',
    headquarters: 'বীরগঞ্জ, দিনাজপুর',
    hotline: '০১৭৬৯-৪০২৭৩০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৭৩১'
  },
  {
    id: 'pbs-gaibandha',
    name: 'গাইবান্ধা পল্লী বিদ্যুৎ সমিতি',
    district: 'গাইবান্ধা',
    division: 'রংপুর',
    headquarters: 'তুলসীঘাট, গাইবান্ধা সদর',
    hotline: '০১৭৬৯-৪০২৭৪০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৭৪১'
  },
  {
    id: 'pbs-kurigram-lalmonirhat',
    name: 'কুড়িগ্রাম-লালমনিরহাট পল্লী বিদ্যুৎ সমিতি',
    district: 'কুড়িগ্রাম',
    division: 'রংপুর',
    headquarters: 'কুড়িগ্রাম সদর',
    hotline: '০১৭৬৯-৪০২৭৫০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৭৫১'
  },
  {
    id: 'pbs-nilphamari',
    name: 'নীলফামারী পল্লী বিদ্যুৎ সমিতি',
    district: 'নীলফামারী',
    division: 'রংপুর',
    headquarters: 'নীলফামারী সদর',
    hotline: '০১৭৬৯-৪০২৭৬০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৭৬১'
  },
  {
    id: 'pbs-thakurgaon',
    name: 'ঠাকুরগাঁও পল্লী বিদ্যুৎ সমিতি',
    district: 'ঠাকুরগাঁও',
    division: 'রংপুর',
    headquarters: 'ঠাকুরগাঁও সদর',
    hotline: '০১৭৬৯-৪০২৭৭০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৭৭১'
  },
  {
    id: 'pbs-panchagarh',
    name: 'পঞ্চগড় পল্লী বিদ্যুৎ সমিতি',
    district: 'পঞ্চগড়',
    division: 'রংপুর',
    headquarters: 'পঞ্চগড় সদর',
    hotline: '০১৭৬৯-৪০২৭৮০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৭৮১'
  },

  // ময়মনসিংহ বিভাগ (Mymensingh Division)
  {
    id: 'pbs-mymensingh-1',
    name: 'ময়মনসিংহ পল্লী বিদ্যুৎ সমিতি-১',
    district: 'ময়মনসিংহ',
    division: 'ময়মনসিংহ',
    headquarters: 'মুক্তাগাছা, ময়মনসিংহ',
    hotline: '০১৭৬৯-৪০২৮০০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৮০১'
  },
  {
    id: 'pbs-mymensingh-2',
    name: 'ময়মনসিংহ পল্লী বিদ্যুৎ সমিতি-২',
    district: 'ময়মনসিংহ',
    division: 'ময়মনসিংহ',
    headquarters: 'ভালুকা, ময়মনসিংহ',
    hotline: '০১৭৬৯-৪০২৮১০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৮১১'
  },
  {
    id: 'pbs-mymensingh-3',
    name: 'ময়মনসিংহ পল্লী বিদ্যুৎ সমিতি-৩',
    district: 'ময়মনসিংহ',
    division: 'ময়মনসিংহ',
    headquarters: 'ফুলপুর, ময়মনসিংহ',
    hotline: '০১৭৬৯-৪০২৮২০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৮২১'
  },
  {
    id: 'pbs-jamalpur',
    name: 'জামালপুর পল্লী বিদ্যুৎ সমিতি',
    district: 'জামালপুর',
    division: 'ময়মনসিংহ',
    headquarters: 'বেলটিয়া, জামালপুর সদর',
    hotline: '০১৭৬৯-৪০২৮৩০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৮৩১'
  },
  {
    id: 'pbs-netrokona',
    name: 'নেত্রকোণা পল্লী বিদ্যুৎ সমিতি',
    district: 'নেত্রকোণা',
    division: 'ময়মনসিংহ',
    headquarters: 'নেত্রকোণা সদর',
    hotline: '০১৭৬৯-৪০২৮৪০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৮৪১'
  },
  {
    id: 'pbs-sherpur',
    name: 'শেরপুর পল্লী বিদ্যুৎ সমিতি',
    district: 'শেরপুর',
    division: 'ময়মনসিংহ',
    headquarters: 'শেরপুর সদর',
    hotline: '০১৭৬৯-৪০২৮৫০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৮৫১'
  },

  // চট্টগ্রাম বিভাগ (Chattogram Division)
  {
    id: 'pbs-ctg-1',
    name: 'চট্টগ্রাম পল্লী বিদ্যুৎ সমিতি-১',
    district: 'চট্টগ্রাম',
    division: 'চট্টগ্রাম',
    headquarters: 'পটিয়া, চট্টগ্রাম',
    hotline: '০১৭৬৯-৪০২৯০০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৯০১'
  },
  {
    id: 'pbs-ctg-2',
    name: 'চট্টগ্রাম পল্লী বিদ্যুৎ সমিতি-২',
    district: 'চট্টগ্রাম',
    division: 'চট্টগ্রাম',
    headquarters: 'রাউজান, চট্টগ্রাম',
    hotline: '০১৭৬৯-৪০২৯১০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৯১১'
  },
  {
    id: 'pbs-ctg-3',
    name: 'চট্টগ্রাম পল্লী বিদ্যুৎ সমিতি-৩',
    district: 'চট্টগ্রাম',
    division: 'চট্টগ্রাম',
    headquarters: 'সীতাকুণ্ড, চট্টগ্রাম',
    hotline: '০১৭৬৯-৪০২৯২০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৯২১'
  },
  {
    id: 'pbs-coxsbazar',
    name: 'কক্সবাজার পল্লী বিদ্যুৎ সমিতি',
    district: 'কক্সবাজার',
    division: 'চট্টগ্রাম',
    headquarters: 'ঝিলংজা, কক্সবাজার সদর',
    hotline: '০১৭৬৯-৪০২৯৩০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৯৩১'
  },
  {
    id: 'pbs-cumilla-1',
    name: 'কুমিল্লা পল্লী বিদ্যুৎ সমিতি-১',
    district: 'কুমিল্লা',
    division: 'চট্টগ্রাম',
    headquarters: 'চান্দিনা, কুমিল্লা',
    hotline: '০১৭৬৯-৪০২৯৪০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৯৪১'
  },
  {
    id: 'pbs-cumilla-2',
    name: 'কুমিল্লা পল্লী বিদ্যুৎ সমিতি-২',
    district: 'কুমিল্লা',
    division: 'চট্টগ্রাম',
    headquarters: 'লাকসাম, কুমিল্লা',
    hotline: '০১৭৬৯-৪০২৯৫০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৯৫১'
  },
  {
    id: 'pbs-cumilla-3',
    name: 'কুমিল্লা পল্লী বিদ্যুৎ সমিতি-৩',
    district: 'কুমিল্লা',
    division: 'চট্টগ্রাম',
    headquarters: 'চৌদ্দগ্রাম, কুমিল্লা',
    hotline: '০১৭৬৯-৪০২৯৬০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৯৬১'
  },
  {
    id: 'pbs-cumilla-4',
    name: 'কুমিল্লা পল্লী বিদ্যুৎ সমিতি-৪',
    district: 'কুমিল্লা',
    division: 'চট্টগ্রাম',
    headquarters: 'হোমনা, কুমিল্লা',
    hotline: '০১৭৬৯-৪০২৯৭০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৯৭১'
  },
  {
    id: 'pbs-brahmanbaria',
    name: 'ব্রাহ্মণবাড়িয়া পল্লী বিদ্যুৎ সমিতি',
    district: 'ব্রাহ্মণবাড়িয়া',
    division: 'চট্টগ্রাম',
    headquarters: 'ঘাটুরা, ব্রাহ্মণবাড়িয়া সদর',
    hotline: '০১৭৬৯-৪০২৯৮০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৯৮১'
  },
  {
    id: 'pbs-chandpur-1',
    name: 'চাঁদপুর পল্লী বিদ্যুৎ সমিতি-১',
    district: 'চাঁদপুর',
    division: 'চট্টগ্রাম',
    headquarters: 'হাজীগঞ্জ, চাঁদপুর',
    hotline: '০১৭৬৯-৪০২৯৯০',
    emergencyComplainNumber: '০১৭৬৯-৪০২৯৯১'
  },
  {
    id: 'pbs-chandpur-2',
    name: 'চাঁদপুর পল্লী বিদ্যুৎ সমিতি-২',
    district: 'চাঁদপুর',
    division: 'চট্টগ্রাম',
    headquarters: 'মতলব দক্ষিণ, চাঁদপুর',
    hotline: '০১৭৬৯-৪০৩০০১',
    emergencyComplainNumber: '০১৭৬৯-৪০৩০০২'
  },
  {
    id: 'pbs-feni',
    name: 'ফেনী পল্লী বিদ্যুৎ সমিতি',
    district: 'ফেনী',
    division: 'চট্টগ্রাম',
    headquarters: 'মহিপাল, ফেনী সদর',
    hotline: '০১৭৬৯-৪০৩MDEw',
    emergencyComplainNumber: '০১৭৬৯-৪০৩MDEx'
  },
  {
    id: 'pbs-noakhali',
    name: 'নোয়াখালী পল্লী বিদ্যুৎ সমিতি',
    district: 'নোয়াখালী',
    division: 'চট্টগ্রাম',
    headquarters: 'মাইজদী, নোয়াখালী সদর',
    hotline: '০১৭৬৯-৪০৩০২০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩০২১'
  },
  {
    id: 'pbs-lakshmipur',
    name: 'লক্ষ্মীপুর পল্লী বিদ্যুৎ সমিতি',
    district: 'লক্ষ্মীপুর',
    division: 'চট্টগ্রাম',
    headquarters: 'ঝুমুর সিনেমা হল মোড়, লক্ষ্মীপুর সদর',
    hotline: '০১৭৬৯-৪০৩০৩০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩০৩১'
  },

  // সিলেট বিভাগ (Sylhet Division)
  {
    id: 'pbs-sylhet-1',
    name: 'সিলেট পল্লী বিদ্যুৎ সমিতি-১',
    district: 'সিলেট',
    division: 'সিলেট',
    headquarters: 'কদমতলী, দক্ষিণ সুরমা, সিলেট',
    hotline: '০১৭৬৯-৪০৩১০০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩১০১'
  },
  {
    id: 'pbs-sylhet-2',
    name: 'সিলেট পল্লী বিদ্যুৎ সমিতি-২',
    district: 'সিলেট',
    division: 'সিলেট',
    headquarters: 'গোলাপগঞ্জ, সিলেট',
    hotline: '০১৭৬৯-৪০৩১১০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩১১১'
  },
  {
    id: 'pbs-moulvibazar',
    name: 'মৌলভীবাজার পল্লী বিদ্যুৎ সমিতি',
    district: 'মৌলভীবাজার',
    division: 'সিলেট',
    headquarters: 'শ্রীমঙ্গল, মৌলভীবাজার',
    hotline: '০১৭৬৯-৪০৩১২০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩১২১'
  },
  {
    id: 'pbs-habiganj',
    name: 'হবিগঞ্জ পল্লী বিদ্যুৎ সমিতি',
    district: 'হবিগঞ্জ',
    division: 'সিলেট',
    headquarters: 'মাধবপুর, হবিগঞ্জ',
    hotline: '০১৭৬৯-৪০৩১৩০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩১৩১'
  },
  {
    id: 'pbs-sunamganj',
    name: 'সুনামগঞ্জ পল্লী বিদ্যুৎ সমিতি',
    district: 'সুনামগঞ্জ',
    division: 'সিলেট',
    headquarters: 'ওয়েজখালী, সুনামগঞ্জ সদর',
    hotline: '০১৭৬৯-৪০৩১৪০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩১৪১'
  },

  // বরিশাল বিভাগ (Barishal Division)
  {
    id: 'pbs-barishal-1',
    name: 'বরিশাল পল্লী বিদ্যুৎ সমিতি-১',
    district: 'বরিশাল',
    division: 'বরিশাল',
    headquarters: 'রুপাতলী, বরিশাল সদর',
    hotline: '০১৭৬৯-৪০৩২০০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩২০১'
  },
  {
    id: 'pbs-barishal-2',
    name: 'বরিশাল পল্লী বিদ্যুৎ সমিতি-২',
    district: 'বরিশাল',
    division: 'বরিশাল',
    headquarters: 'উজিরপুর, বরিশাল',
    hotline: '০১৭৬৯-৪০৩২১০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩২১১'
  },
  {
    id: 'pbs-patuakhali',
    name: 'পটুয়াখালী পল্লী বিদ্যুৎ সমিতি',
    district: 'পটুয়াখালী',
    division: 'বরিশাল',
    headquarters: 'পটুয়াখালী সদর',
    hotline: '০১৭৬৯-৪০৩২২০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩২২১'
  },
  {
    id: 'pbs-bhola',
    name: 'ভোলা পল্লী বিদ্যুৎ সমিতি',
    district: 'ভোলা',
    division: 'বরিশাল',
    headquarters: 'ভোলা সদর',
    hotline: '০১৭৬৯-৪০৩২৩০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩২৩১'
  },
  {
    id: 'pbs-pirojpur',
    name: 'পিরোজপুর পল্লী বিদ্যুৎ সমিতি',
    district: 'পিরোজপুর',
    division: 'বরিশাল',
    headquarters: 'পিরোজপুর সদর',
    hotline: '০১৭৬৯-৪০৩২৪০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩২৪১'
  },
  {
    id: 'pbs-barguna',
    name: 'বরগুনা পল্লী বিদ্যুৎ সমিতি',
    district: 'বরগুনা',
    division: 'বরিশাল',
    headquarters: 'বরগুনা সদর',
    hotline: '০১৭৬৯-৪০৩২৫০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩২৫১'
  },
  {
    id: 'pbs-jhalokathi',
    name: 'ঝালকাঠি পল্লী বিদ্যুৎ সমিতি',
    district: 'ঝালকাঠি',
    division: 'বরিশাল',
    headquarters: 'ঝালকাঠি সদর',
    hotline: '০১৭৬৯-৪০৩২৬০',
    emergencyComplainNumber: '০১৭৬৯-৪০৩২৬১'
  }
];

export const getPbsByDistrict = (district: string): PalliBidyutSamity[] => {
  if (!district || district === 'সকল জেলা') return ALL_PALLI_BIDYUT_SAMITIES;
  return ALL_PALLI_BIDYUT_SAMITIES.filter(pbs => pbs.district === district);
};
