// Coordinates and Geographic Metadata for all 64 Districts of Bangladesh
// Used for GPS auto-detection, distance calculation, live meteorological forecasting, and solar prayer times.

export interface DistrictGeoData {
  name: string;
  nameEn: string;
  division: string;
  lat: number;
  lng: number;
  elevationM: number;
  climateZone: 'coastal' | 'haor' | 'barind' | 'central' | 'hilly' | 'northern' | 'southern';
  dominantCrops: string[];
}

export const BANGLADESH_DISTRICT_COORDINATES: DistrictGeoData[] = [
  // 1. DHAKA DIVISION
  { name: 'ঢাকা', nameEn: 'Dhaka', division: 'ঢাকা', lat: 23.8103, lng: 90.4125, elevationM: 8, climateZone: 'central', dominantCrops: ['ধান', 'শাকসবজি', 'কলা'] },
  { name: 'গাজীপুর', nameEn: 'Gazipur', division: 'ঢাকা', lat: 24.0023, lng: 90.4264, elevationM: 14, climateZone: 'central', dominantCrops: ['কাঁঠাল', 'আনারস', 'ধান', 'সবজি'] },
  { name: 'নারায়ণগঞ্জ', nameEn: 'Narayanganj', division: 'ঢাকা', lat: 23.6238, lng: 90.5000, elevationM: 8, climateZone: 'central', dominantCrops: ['ধান', 'পাট', 'সবজি'] },
  { name: 'মানিকগঞ্জ', nameEn: 'Manikganj', division: 'ঢাকা', lat: 23.8617, lng: 90.0003, elevationM: 10, climateZone: 'central', dominantCrops: ['সরিষা', 'ধান', 'ভুট্টা', 'পাট'] },
  { name: 'মুন্সীগঞ্জ', nameEn: 'Munshiganj', division: 'ঢাকা', lat: 23.5422, lng: 90.5305, elevationM: 7, climateZone: 'central', dominantCrops: ['আলু', 'পাট', 'ধান', 'কলা'] },
  { name: 'নরসিংদী', nameEn: 'Narsingdi', division: 'ঢাকা', lat: 23.9322, lng: 90.7154, elevationM: 12, climateZone: 'central', dominantCrops: ['কলা', 'লটকন', 'ধান', 'বেগুন'] },
  { name: 'টাঙ্গাইল', nameEn: 'Tangail', division: 'ঢাকা', lat: 24.2513, lng: 89.9167, elevationM: 15, climateZone: 'central', dominantCrops: ['আনারস', 'সরিষা', 'ধান', 'পাট'] },
  { name: 'ফরিদপুর', nameEn: 'Faridpur', division: 'ঢাকা', lat: 23.6070, lng: 89.8429, elevationM: 10, climateZone: 'central', dominantCrops: ['পাট', 'পেঁয়াজ', 'ধান', 'রসুন'] },
  { name: 'গোপালগঞ্জ', nameEn: 'Gopalganj', division: 'ঢাকা', lat: 23.0051, lng: 89.8266, elevationM: 6, climateZone: 'southern', dominantCrops: ['ধান', 'পাট', 'মাছ', 'নারিকেল'] },
  { name: 'মাদারীপুর', nameEn: 'Madaripur', division: 'ঢাকা', lat: 23.1641, lng: 90.1897, elevationM: 7, climateZone: 'central', dominantCrops: ['পাট', 'ধান', 'সরিষা', 'খেজুর গুড়'] },
  { name: 'রাজবাড়ী', nameEn: 'Rajbari', division: 'ঢাকা', lat: 23.7574, lng: 89.6445, elevationM: 12, climateZone: 'central', dominantCrops: ['পেঁয়াজ', 'পাট', 'ধান', 'তিল'] },
  { name: 'শরীয়তপুর', nameEn: 'Shariatpur', division: 'ঢাকা', lat: 23.2423, lng: 90.4348, elevationM: 6, climateZone: 'southern', dominantCrops: ['পাট', 'ধান', 'মরিচ', 'সরিষা'] },
  { name: 'কিশোরগঞ্জ', nameEn: 'Kishoreganj', division: 'ঢাকা', lat: 24.4449, lng: 90.7766, elevationM: 13, climateZone: 'haor', dominantCrops: ['বোরো ধান', 'ভুট্টা', 'বাদাম', 'পাট'] },

  // 2. CHATTOGRAM DIVISION
  { name: 'চট্টগ্রাম', nameEn: 'Chattogram', division: 'চট্টগ্রাম', lat: 22.3569, lng: 91.7832, elevationM: 12, climateZone: 'coastal', dominantCrops: ['ধান', 'তরমুজ', 'শাকসবজি', 'পান'] },
  { name: 'কক্সবাজার', nameEn: 'Cox\'s Bazar', division: 'চট্টগ্রাম', lat: 21.4272, lng: 92.0058, elevationM: 5, climateZone: 'coastal', dominantCrops: ['লবণ', 'পান', 'সুপারি', 'ধান', 'মাছ'] },
  { name: 'কুমিল্লা', nameEn: 'Cumilla', division: 'চট্টগ্রাম', lat: 23.4682, lng: 91.1788, elevationM: 14, climateZone: 'central', dominantCrops: ['ধান', 'আলু', 'সবজি', 'সরিষা'] },
  { name: 'ব্রাহ্মণবাড়িয়া', nameEn: 'Brahmanbaria', division: 'চট্টগ্রাম', lat: 23.9571, lng: 91.1119, elevationM: 11, climateZone: 'haor', dominantCrops: ['ধান', 'পাট', 'সরিষা', 'ভুট্টা'] },
  { name: 'চাঁদপুর', nameEn: 'Chandpur', division: 'চট্টগ্রাম', lat: 23.2333, lng: 90.6667, elevationM: 6, climateZone: 'coastal', dominantCrops: ['ইলিশ/মৎস্য', 'সয়াবিন', 'ধান', 'আলু'] },
  { name: 'লক্ষ্মীপুর', nameEn: 'Lakshmipur', division: 'চট্টগ্রাম', lat: 22.9425, lng: 90.8412, elevationM: 5, climateZone: 'coastal', dominantCrops: ['সয়াবিন', 'নারিকেল', 'সুপারি', 'ধান'] },
  { name: 'নোয়াখালী', nameEn: 'Noakhali', division: 'চট্টগ্রাম', lat: 22.8696, lng: 91.0998, elevationM: 5, climateZone: 'coastal', dominantCrops: ['সয়াবিন', 'নারিকেল', 'ধান', 'মরিচ'] },
  { name: 'ফেনী', nameEn: 'Feni', division: 'চট্টগ্রাম', lat: 23.0159, lng: 91.3976, elevationM: 10, climateZone: 'coastal', dominantCrops: ['ধান', 'ডাল', 'সবজি', 'আমড়া'] },
  { name: 'খাগড়াছড়ি', nameEn: 'Khagrachhari', division: 'চট্টগ্রাম', lat: 23.1193, lng: 91.9847, elevationM: 45, climateZone: 'hilly', dominantCrops: ['আম', 'আনারস', 'কলা', 'আদা', 'হলুদ'] },
  { name: 'রাঙ্গামাটি', nameEn: 'Rangamati', division: 'চট্টগ্রাম', lat: 22.6574, lng: 92.1733, elevationM: 52, climateZone: 'hilly', dominantCrops: ['আনারস', 'কলা', 'জুম চাষ', 'কাঁঠাল', 'আম'] },
  { name: 'বান্দরবান', nameEn: 'Bandarban', division: 'চট্টগ্রাম', lat: 22.1953, lng: 92.2184, elevationM: 68, climateZone: 'hilly', dominantCrops: ['জুম ধান', 'আদা', 'হলুদ', 'কাজুবাদাম', 'কফি'] },

  // 3. RAJSHAHI DIVISION
  { name: 'রাজশাহী', nameEn: 'Rajshahi', division: 'রাজশাহী', lat: 24.3745, lng: 88.6042, elevationM: 22, climateZone: 'barind', dominantCrops: ['আম', 'ধান', 'গম', 'টমেটো', 'পেঁয়াজ'] },
  { name: 'বগুড়া', nameEn: 'Bogura', division: 'রাজশাহী', lat: 24.8465, lng: 89.3777, elevationM: 20, climateZone: 'northern', dominantCrops: ['মরিচ', 'আলু', 'ধান', 'শাকসবজি', 'ভুট্টা'] },
  { name: 'পাবনা', nameEn: 'Pabna', division: 'রাজশাহী', lat: 24.0064, lng: 89.2372, elevationM: 16, climateZone: 'central', dominantCrops: ['পেঁয়াজ', 'দুধ/দুগ্ধপণ্য', 'ধান', 'তিল'] },
  { name: 'সিরাজগঞ্জ', nameEn: 'Sirajganj', division: 'রাজশাহী', lat: 24.4534, lng: 89.7008, elevationM: 14, climateZone: 'central', dominantCrops: ['সরিষা', 'দুধ/গরু', 'ধান', 'পাট'] },
  { name: 'নাটোর', nameEn: 'Natore', division: 'রাজশাহী', lat: 24.4206, lng: 88.9324, elevationM: 18, climateZone: 'barind', dominantCrops: ['আখ', 'রসুন', 'আম', 'ধান'] },
  { name: 'নওগাঁ', nameEn: 'Naogaon', division: 'রাজশাহী', lat: 24.7936, lng: 88.9318, elevationM: 21, climateZone: 'barind', dominantCrops: ['আম (আম্রপালি)', 'ধান', 'গম', 'সরিষা'] },
  { name: 'চাঁপাইনবাবগঞ্জ', nameEn: 'Chapai Nawabganj', division: 'রাজশাহী', lat: 24.5965, lng: 88.2776, elevationM: 25, climateZone: 'barind', dominantCrops: ['ফজলি/ল্যাংড়া আম', 'ধান', 'রেশম', 'টমেটো'] },
  { name: 'জয়পুরহাট', nameEn: 'Joypurhat', division: 'রাজশাহী', lat: 25.1015, lng: 89.0270, elevationM: 24, climateZone: 'northern', dominantCrops: ['আলু', 'ধান', 'কলা', 'আখ', 'পোল্ট্রি'] },

  // 4. KHULNA DIVISION
  { name: 'খুলনা', nameEn: 'Khulna', division: 'খুলনা', lat: 22.8456, lng: 89.5403, elevationM: 4, climateZone: 'coastal', dominantCrops: ['চিংড়ি', 'ধান', 'নারিকেল', 'সুপারি'] },
  { name: 'যশোর', nameEn: 'Jashore', division: 'খুলনা', lat: 23.1664, lng: 89.2137, elevationM: 10, climateZone: 'southern', dominantCrops: ['ফুল', 'খেজুর গুড়', 'সবজি', 'ধান'] },
  { name: 'সাতক্ষীরা', nameEn: 'Satkhira', division: 'খুলনা', lat: 22.7185, lng: 89.0705, elevationM: 4, climateZone: 'coastal', dominantCrops: ['হিমসাগর আম', 'গলদা চিংড়ি', 'ধান', 'মধু'] },
  { name: 'বাগেরহাট', nameEn: 'Bagerhat', division: 'খুলনা', lat: 22.6516, lng: 89.7859, elevationM: 3, climateZone: 'coastal', dominantCrops: ['চিংড়ি', 'সুপারি', 'নারিকেল', 'ধান'] },
  { name: 'কুষ্টিয়া', nameEn: 'Kushtia', division: 'খুলনা', lat: 23.9013, lng: 89.1205, elevationM: 15, climateZone: 'central', dominantCrops: ['তামাক/বিকল্প ফসল', 'ধান', 'তিল', 'কলা'] },
  { name: 'ঝিনাইদহ', nameEn: 'Jhenaidah', division: 'খুলনা', lat: 23.5450, lng: 89.1726, elevationM: 13, climateZone: 'southern', dominantCrops: ['কলা', 'ধান', 'পান', 'ড্রাগন ফল', 'সবজি'] },
  { name: 'মাগুরা', nameEn: 'Magura', division: 'খুলনা', lat: 23.4873, lng: 89.4199, elevationM: 11, climateZone: 'southern', dominantCrops: ['পাট', 'ধান', 'সরিষা', 'পেঁয়াজ'] },
  { name: 'চুয়াডাঙ্গা', nameEn: 'Chuadanga', division: 'খুলনা', lat: 23.6402, lng: 88.8418, elevationM: 17, climateZone: 'southern', dominantCrops: ['ভুট্টা', 'তামাক', 'ধান', 'পান', 'আম'] },
  { name: 'মেহেরপুর', nameEn: 'Meherpur', division: 'খুলনা', lat: 23.7725, lng: 88.6318, elevationM: 18, climateZone: 'southern', dominantCrops: ['আম', 'কলা', 'ধান', 'ভুট্টা', 'মরিচ'] },
  { name: 'নড়াইল', nameEn: 'Narail', division: 'খুলনা', lat: 23.1725, lng: 89.5127, elevationM: 8, climateZone: 'southern', dominantCrops: ['ধান', 'পাট', 'নারিকেল', 'মাছ'] },

  // 5. BARISHAL DIVISION
  { name: 'বরিশাল', nameEn: 'Barishal', division: 'বরিশাল', lat: 22.7010, lng: 90.3535, elevationM: 3, climateZone: 'southern', dominantCrops: ['ধান (বালাম)', 'পেয়ারা', 'আমড়া', 'সুপারি'] },
  { name: 'পটুয়াখালী', nameEn: 'Patuakhali', division: 'বরিশাল', lat: 22.3596, lng: 90.3299, elevationM: 3, climateZone: 'coastal', dominantCrops: ['মুগ ডাল', 'তরমুজ', 'ধান', 'নারিকেল'] },
  { name: 'ভোলা', nameEn: 'Bhola', division: 'বরিশাল', lat: 22.6859, lng: 90.6481, elevationM: 4, climateZone: 'coastal', dominantCrops: ['মহিষের দুধ/দই', 'সুপারি', 'সয়াবিন', 'ধান', 'মরিচ'] },
  { name: 'পিরোজপুর', nameEn: 'Pirojpur', division: 'বরিশাল', lat: 22.5841, lng: 89.9720, elevationM: 3, climateZone: 'southern', dominantCrops: ['ভাসমান সবজি', 'পেয়ারা', 'আমড়া', 'মাল্টা', 'ধান'] },
  { name: 'বরগুনা', nameEn: 'Barguna', division: 'বরিশাল', lat: 22.0953, lng: 90.0770, elevationM: 3, climateZone: 'coastal', dominantCrops: ['ধান', 'মুগ ডাল', 'তরমুজ', 'মাছ'] },
  { name: 'ঝালকাঠি', nameEn: 'Jhalokati', division: 'বরিশাল', lat: 22.6406, lng: 90.1987, elevationM: 4, climateZone: 'southern', dominantCrops: ['পেয়ারা হাট', 'আমড়া', 'ধান', 'সুপারি'] },

  // 6. SYLHET DIVISION
  { name: 'সিলেট', nameEn: 'Sylhet', division: 'সিলেট', lat: 24.8949, lng: 91.8687, elevationM: 35, climateZone: 'haor', dominantCrops: ['চা', 'কমলা', 'সাতকড়া', 'আনারস', 'ধান'] },
  { name: 'মৌলভীবাজার', nameEn: 'Moulvibazar', division: 'সিলেট', lat: 24.4829, lng: 91.7774, elevationM: 28, climateZone: 'haor', dominantCrops: ['চা', 'রাবার', 'আনারস', 'লেবু', 'ধান'] },
  { name: 'হবিগঞ্জ', nameEn: 'Habiganj', division: 'সিলেট', lat: 24.3749, lng: 91.4155, elevationM: 20, climateZone: 'haor', dominantCrops: ['ধান', 'চা', 'রাবার', 'শাকসবজি'] },
  { name: 'সুনামগঞ্জ', nameEn: 'Sunamganj', division: 'সিলেট', lat: 25.0658, lng: 91.3950, elevationM: 14, climateZone: 'haor', dominantCrops: ['হাওর বোরো ধান', 'হাওর দেশি মাছ', 'বাদাম'] },

  // 7. RANGPUR DIVISION
  { name: 'রংপুর', nameEn: 'Rangpur', division: 'রংপুর', lat: 25.7439, lng: 89.2752, elevationM: 34, climateZone: 'northern', dominantCrops: ['তামাক/ভুট্টা', 'আলু', 'ধান', 'হাঁড়িভাঙা আম'] },
  { name: 'দিনাজপুর', nameEn: 'Dinajpur', division: 'রংপুর', lat: 25.6217, lng: 88.6355, elevationM: 37, climateZone: 'northern', dominantCrops: ['লিচু (মাদ্রাজি/বেদানা)', 'কাটারিভোগ ধান', 'ভুট্টা', 'গম'] },
  { name: 'গাইবান্ধা', nameEn: 'Gaibandha', division: 'রংপুর', lat: 25.3288, lng: 89.5406, elevationM: 26, climateZone: 'northern', dominantCrops: ['ভুট্টা', 'ধান', 'চরের বাদাম', 'পাট'] },
  { name: 'কুড়িগ্রাম', nameEn: 'Kurigram', division: 'রংপুর', lat: 25.8054, lng: 89.6362, elevationM: 28, climateZone: 'northern', dominantCrops: ['ধান', 'পাট', 'ভুট্টা', 'চরের বাদাম ও কুমড়া'] },
  { name: 'নীলফামারী', nameEn: 'Nilphamari', division: 'রংপুর', lat: 25.9318, lng: 88.8560, elevationM: 42, climateZone: 'northern', dominantCrops: ['আদা', 'ভুট্টা', 'ধান', 'গম', 'আলু'] },
  { name: 'লালমনিরহাট', nameEn: 'Lalmonirhat', division: 'রংপুর', lat: 25.9923, lng: 89.2847, elevationM: 38, climateZone: 'northern', dominantCrops: ['ভুট্টা', 'তামাক', 'ধান', 'আলু'] },
  { name: 'ঠাকুরগাঁও', nameEn: 'Thakurgaon', division: 'রংপুর', lat: 26.0337, lng: 88.4617, elevationM: 52, climateZone: 'northern', dominantCrops: ['আখ', 'আলু', 'গম', 'আম', 'ধান'] },
  { name: 'পঞ্চগড়', nameEn: 'Panchagarh', division: 'রংপুর', lat: 26.3411, lng: 88.5542, elevationM: 65, climateZone: 'northern', dominantCrops: ['সমতলের চা', 'কমলা', 'রসুন', 'বাদাম', 'পাথর/বালি'] },

  // 8. MYMENSINGH DIVISION
  { name: 'ময়মনসিংহ', nameEn: 'Mymensingh', division: 'ময়মনসিংহ', lat: 24.7471, lng: 90.4203, elevationM: 19, climateZone: 'central', dominantCrops: ['ধান', 'মাছের পোনা', 'বেগুন', 'সরিষা'] },
  { name: 'জামালপুর', nameEn: 'Jamalpur', division: 'ময়মনসিংহ', lat: 24.9375, lng: 89.9378, elevationM: 20, climateZone: 'central', dominantCrops: ['মরিচ', 'সরিষা', 'ধান', 'পাট', 'ভুট্টা'] },
  { name: 'নেত্রকোণা', nameEn: 'Netrokona', division: 'ময়মনসিংহ', lat: 24.8709, lng: 90.7279, elevationM: 16, climateZone: 'haor', dominantCrops: ['বোরো ধান', 'হাওর মাছ', 'সরিষা'] },
  { name: 'শেরপুর', nameEn: 'Sherpur', division: 'ময়মনসিংহ', lat: 25.0205, lng: 90.0153, elevationM: 23, climateZone: 'central', dominantCrops: ['তুলসীমালা সুগন্ধি ধান', 'সরিষা', 'শাকসবজি'] }
];

// Helper to calculate distance between two coordinates in km (Haversine formula)
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
    Math.cos(lat2 * (Math.PI / 180)) *
    Math.sin(dLon / 2) *
    Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Find nearest Bangladesh District by GPS
export function findNearestDistrict(lat: number, lng: number): DistrictGeoData {
  let closest = BANGLADESH_DISTRICT_COORDINATES[0];
  let minDistance = calculateDistanceKm(lat, lng, closest.lat, closest.lng);

  for (let i = 1; i < BANGLADESH_DISTRICT_COORDINATES.length; i++) {
    const d = BANGLADESH_DISTRICT_COORDINATES[i];
    const dist = calculateDistanceKm(lat, lng, d.lat, d.lng);
    if (dist < minDistance) {
      minDistance = dist;
      closest = d;
    }
  }

  return closest;
}

export function getDistrictGeo(districtName: string): DistrictGeoData {
  const found = BANGLADESH_DISTRICT_COORDINATES.find(d => d.name === districtName);
  if (found) return found;
  // Default to Dhaka
  return BANGLADESH_DISTRICT_COORDINATES[0];
}
