export interface UpazilaData {
  name: string;
  unions: string[];
}

export interface DistrictLocationData {
  district: string;
  division: string;
  upazilas: UpazilaData[];
}
