export interface LocalEmergencyContact {
  id: string;
  name: string;
  category: 'police' | 'fire_service' | 'hospital' | 'admin';
  phone: string;
  mapUrl: string;
  address?: string;
  availableHours?: string;
}

export interface UpazilaEmergencyData {
  upazila: string;
  contacts: LocalEmergencyContact[];
}

export interface DistrictEmergencyData {
  district: string;
  upazilas: UpazilaEmergencyData[];
}

export const LOCAL_EMERGENCY_DATA: DistrictEmergencyData[] = [
  {
    district: 'পটুয়াখালী',
    upazilas: [
      {
        upazila: 'বাউফল',
        contacts: [
          {
            id: 'pat-bfl-pol',
            name: 'বাউফল থানা পুলিশ',
            category: 'police',
            phone: '01320-153450',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Bauphal+Police+Station+Patuakhali',
            address: 'বাউফল থানা মোড়, বাউফল সদর, পটুয়াখালী',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'pat-bfl-fs',
            name: 'বাউফল ফায়ার সার্ভিস ও সিভিল ডিফেন্স স্টেশন',
            category: 'fire_service',
            phone: '01730-002488',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Bauphal+Fire+Service+Station+Patuakhali',
            address: 'কালাইয়া রোড, বাউফল পৌর এলাকা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'pat-bfl-hosp',
            name: 'বাউফল উপজেলা স্বাস্থ্য কমপ্লেক্স ও জরুরি বিভাগ',
            category: 'hospital',
            phone: '01712-334455',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Bauphal+Upazila+Health+Complex+Patuakhali',
            address: 'হাসপাতাল রোড, বাউফল পৌরসভা',
            availableHours: '২৪ ঘণ্টা ইমার্জেন্সি'
          }
        ]
      },
      {
        upazila: 'পটুয়াখালী সদর',
        contacts: [
          {
            id: 'pat-sdr-pol',
            name: 'পটুয়াখালী সদর থানা পুলিশ',
            category: 'police',
            phone: '01320-153400',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Patuakhali+Sadar+Police+Station',
            address: 'সদর রোড, পটুয়াখালী',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'pat-sdr-fs',
            name: 'পটুয়াখালী কেন্দ্রীয় ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '0441-62222',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Patuakhali+Fire+Service+Station',
            address: 'নতুন বাজার, পটুয়াখালী',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'pat-sdr-hosp',
            name: 'পটুয়াখালী ২৫০ শয্যা বিশিষ্ট জেনারেল হাসপাতাল',
            category: 'hospital',
            phone: '0441-62333',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Patuakhali+General+Hospital',
            address: 'কলেজ রোড, পটুয়াখালী সদর',
            availableHours: '২৪ ঘণ্টা ইমার্জেন্সি'
          }
        ]
      }
    ]
  },
  {
    district: 'যশোর',
    upazilas: [
      {
        upazila: 'যশোর সদর',
        contacts: [
          {
            id: 'jsh-sdr-pol',
            name: 'কোতোয়ালি মডেল থানা, যশোর সদর',
            category: 'police',
            phone: '01320-143058',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kotwali+Model+Thana+Jashore',
            address: 'দড়াটানা মোড় সংলগ্ন, যশোর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-sdr-fs',
            name: 'ফায়ার সার্ভিস ও সিভিল ডিফেন্স স্টেশন, যশোর সদর',
            category: 'fire_service',
            phone: '01715-373300',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Fire+Service+Station+Jashore+Sadar',
            address: 'মনিহার মোড়, যশোর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-sdr-hosp',
            name: 'যশোর ২৫০ শয্যা জেনারেল হাসপাতাল ও জরুরি বিভাগ',
            category: 'hospital',
            phone: '01712-456789',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=250+Bed+General+Hospital+Jashore',
            address: 'হাসপাতাল রোড, যশোর সদর',
            availableHours: '২৪ ঘণ্টা ইমার্জেন্সি'
          }
        ]
      },
      {
        upazila: 'ঝিকরগাছা',
        contacts: [
          {
            id: 'jsh-jhk-fs',
            name: 'ঝিকরগাছা ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '01730-002444',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Jhikargacha+Fire+Service+Station+Jashore',
            address: 'যশোর-বেনাপোল মহাসড়ক, ঝিকরগাছা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-jhk-pol',
            name: 'ঝিকরগাছা থানা পুলিশ (ওসি ডিউটি)',
            category: 'police',
            phone: '01320-143090',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Jhikargacha+Police+Station+Jashore',
            address: 'ঝিকরগাছা বাজার, যশোর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-jhk-hosp',
            name: 'ঝিকরগাছা উপজেলা স্বাস্থ্য কমপ্লেক্স',
            category: 'hospital',
            phone: '01716-890123',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Jhikargacha+Upazila+Health+Complex',
            address: 'হাসপাতাল রোড, ঝিকরগাছা',
            availableHours: '২৪ ঘণ্টা ইমার্জেন্সি'
          }
        ]
      },
      {
        upazila: 'শার্শা (বেনাপোল)',
        contacts: [
          {
            id: 'jsh-sha-fs',
            name: 'বেনাপোল ফায়ার সার্ভিস ও সিভিল ডিফেন্স স্টেশন',
            category: 'fire_service',
            phone: '01730-002446',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Benapole+Fire+Service+Station',
            address: 'বেনাপোল চেকপোস্ট রোড, শার্শা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-sha-pol',
            name: 'শার্শা থানা পুলিশ',
            category: 'police',
            phone: '01320-143110',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Sharsha+Police+Station+Jashore',
            address: 'শার্শা বাজার, যশোর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-ben-pol',
            name: 'বেনাপোল পোর্ট থানা',
            category: 'police',
            phone: '01320-143120',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Benapole+Port+Thana',
            address: 'বন্দর এলাকা, বেনাপোল',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      },
      {
        upazila: 'মনিরামপুর',
        contacts: [
          {
            id: 'jsh-man-fs',
            name: 'মনিরামপুর ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '01730-002448',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Manirampur+Fire+Service+Station',
            address: 'মনিরামপুর পৌরসভা এলাকা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-man-pol',
            name: 'মনিরামপুর থানা পুলিশ',
            category: 'police',
            phone: '01320-143130',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Manirampur+Police+Station',
            address: 'থানা মোড়, মনিরামপুর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      },
      {
        upazila: 'অভয়নগর (নওয়াপাড়া)',
        contacts: [
          {
            id: 'jsh-abh-fs',
            name: 'নওয়াপাড়া ফায়ার সার্ভিস ও সিভিল ডিফেন্স স্টেশন',
            category: 'fire_service',
            phone: '01730-002445',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Noapara+Fire+Service+Station+Abhaynagar',
            address: 'নওয়াপাড়া বাজার, অভয়নগর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-abh-pol',
            name: 'অভয়নগর থানা পুলিশ',
            category: 'police',
            phone: '01320-143080',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Abhaynagar+Police+Station',
            address: 'নওয়াপাড়া, অভয়নগর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      },
      {
        upazila: 'কেশবপুর',
        contacts: [
          {
            id: 'jsh-ksh-fs',
            name: 'কেশবপুর ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '01730-002447',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Keshabpur+Fire+Service+Station',
            address: 'কেশবপুর বাজার সংলগ্ন',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-ksh-pol',
            name: 'কেশবপুর থানা পুলিশ',
            category: 'police',
            phone: '01320-143100',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Keshabpur+Police+Station',
            address: 'কেশবপুর থানা রোড',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      },
      {
        upazila: 'চৌগাছা',
        contacts: [
          {
            id: 'jsh-chg-fs',
            name: 'চৌগাছা ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '01730-002449',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Chaugachha+Fire+Service+Station',
            address: 'চৌগাছা পৌর এলাকা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-chg-pol',
            name: 'চৌগাছা থানা পুলিশ',
            category: 'police',
            phone: '01320-143070',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Chaugachha+Police+Station',
            address: 'চৌগাছা বাজার',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      },
      {
        upazila: 'বাঘারপাড়া',
        contacts: [
          {
            id: 'jsh-bgh-fs',
            name: 'বাঘারপাড়া ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '01730-002450',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Bagherpara+Fire+Service+Station',
            address: 'বাঘারপাড়া সদর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'jsh-bgh-pol',
            name: 'বাঘারপাড়া থানা পুলিশ',
            category: 'police',
            phone: '01320-143060',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Bagherpara+Police+Station',
            address: 'বাঘারপাড়া থানা রোড',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      }
    ]
  },
  {
    district: 'ঢাকা',
    upazilas: [
      {
        upazila: 'ঢাকা সদর / কোতোয়ালি',
        contacts: [
          {
            id: 'dhk-sdr-pol',
            name: 'কোতোয়ালি থানা পুলিশ, ঢাকা',
            category: 'police',
            phone: '01320-039800',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kotwali+Thana+Dhaka',
            address: 'সদরঘাট, পুরান ঢাকা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'dhk-sdr-fs',
            name: 'ফায়ার সার্ভিস কেন্দ্রীয় হেডকোয়ার্টার্স (ফুলবাড়িয়া)',
            category: 'fire_service',
            phone: '02-223355555',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Fire+Service+Headquarters+Fulbaria+Dhaka',
            address: 'কাজী নজরুল ইসলাম অ্যাভিনিউ, ফুলবাড়িয়া, ঢাকা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'dhk-dmc-hosp',
            name: 'ঢাকা মেডিকেল কলেজ হাসপাতাল (DMCH)',
            category: 'hospital',
            phone: '02-55165088',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Dhaka+Medical+College+Hospital',
            address: 'বকশিবাজার, ঢাকা',
            availableHours: '২৪ ঘণ্টা ইমার্জেন্সি'
          }
        ]
      },
      {
        upazila: 'মিরপুর',
        contacts: [
          {
            id: 'dhk-mir-pol',
            name: 'মিরপুর মডেল থানা পুলিশ',
            category: 'police',
            phone: '01320-040200',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Mirpur+Model+Thana+Dhaka',
            address: 'মিরপুর-২, ঢাকা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'dhk-mir-fs',
            name: 'মিরপুর ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '01730-336644',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Mirpur+Fire+Service+Station',
            address: 'মিরপুর-১০ গোলচত্বর সংলগ্ন',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      },
      {
        upazila: 'উত্তরা',
        contacts: [
          {
            id: 'dhk-utt-pol',
            name: 'উত্তরা পূর্ব থানা পুলিশ',
            category: 'police',
            phone: '01320-041200',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Uttara+East+Thana+Dhaka',
            address: 'সেক্টর ৪, উত্তরা, ঢাকা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'dhk-utt-fs',
            name: 'উত্তরা ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '01730-336655',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Uttara+Fire+Service+Station',
            address: 'সেক্টর ৩, উত্তরা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      },
      {
        upazila: 'ধানমন্ডি',
        contacts: [
          {
            id: 'dhk-dhn-pol',
            name: 'ধানমন্ডি মডেল থানা পুলিশ',
            category: 'police',
            phone: '01320-039400',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Dhanmondi+Model+Thana+Dhaka',
            address: 'রোড নম্বর ৮/এ, ধানমন্ডি',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'dhk-dhn-fs',
            name: 'মোহাম্মদপুর / ধানমন্ডি ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '01730-336666',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Mohammadpur+Fire+Service+Station',
            address: 'আসাদ গেট সংলগ্ন, মোহাম্মদপুর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      },
      {
        upazila: 'সাভার',
        contacts: [
          {
            id: 'dhk-sav-pol',
            name: 'সাভার মডেল থানা পুলিশ',
            category: 'police',
            phone: '01320-038200',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Savar+Model+Thana',
            address: 'সাভার বাজার বাসস্ট্যান্ড',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'dhk-sav-fs',
            name: 'সাভার ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '01730-002233',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Savar+Fire+Service+Station',
            address: 'ঢাকা-আরিচা মহাসড়ক, সাভার',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      }
    ]
  },
  {
    district: 'চট্টগ্রাম',
    upazilas: [
      {
        upazila: 'কোতোয়ালি / সদর',
        contacts: [
          {
            id: 'ctg-sdr-pol',
            name: 'কোতোয়ালি থানা পুলিশ, চট্টগ্রাম',
            category: 'police',
            phone: '01320-107500',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kotwali+Thana+Chattogram',
            address: 'আন্দরকিল্লা, চট্টগ্রাম',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'ctg-sdr-fs',
            name: 'আগ্রাবাদ ফায়ার সার্ভিস ও সিভিল ডিফেন্স সদর দপ্তর',
            category: 'fire_service',
            phone: '031-716333',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Agrabad+Fire+Service+Station+Chattogram',
            address: 'আগ্রাবাদ বাণিজ্যিক এলাকা, চট্টগ্রাম',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'ctg-cmch-hosp',
            name: 'চট্টগ্রাম মেডিকেল কলেজ হাসপাতাল (CMCH)',
            category: 'hospital',
            phone: '031-616891',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Chattogram+Medical+College+Hospital',
            address: 'কেবি ফজলুল কাদের রোড, চকবাজার',
            availableHours: '২৪ ঘণ্টা ইমার্জেন্সি'
          }
        ]
      },
      {
        upazila: 'পতেঙ্গা',
        contacts: [
          {
            id: 'ctg-pat-pol',
            name: 'পতেঙ্গা থানা পুলিশ',
            category: 'police',
            phone: '01320-108100',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Patenga+Police+Station+Chattogram',
            address: 'বিমানবন্দর রোড, পতেঙ্গা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'ctg-pat-fs',
            name: 'ইপিজেড ও পতেঙ্গা ফায়ার স্টেশন',
            category: 'fire_service',
            phone: '01730-002600',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=EPZ+Fire+Service+Station+Chattogram',
            address: 'সিইপিজেড মোড়, চট্টগ্রাম',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      }
    ]
  },
  {
    district: 'রাজশাহী',
    upazilas: [
      {
        upazila: 'রাজশাহী সদর / বোয়ালিয়া',
        contacts: [
          {
            id: 'raj-boa-pol',
            name: 'বোয়ালিয়া মডেল থানা পুলিশ, রাজশাহী',
            category: 'police',
            phone: '01320-061000',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Boalia+Model+Thana+Rajshahi',
            address: 'সাহেব বাজার, বোয়ালিয়া',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'raj-sdr-fs',
            name: 'রাজশাহী সদর ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '0721-772222',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Rajshahi+Sadar+Fire+Station',
            address: 'কাদিরগঞ্জ, রাজশাহী',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'raj-rmch-hosp',
            name: 'রাজশাহী মেডিকেল কলেজ হাসপাতাল (RMCH)',
            category: 'hospital',
            phone: '0721-772150',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Rajshahi+Medical+College+Hospital',
            address: 'লক্ষ্মীপুর, রাজশাহী',
            availableHours: '২৪ ঘণ্টা ইমার্জেন্সি'
          }
        ]
      }
    ]
  },
  {
    district: 'খুলনা',
    upazilas: [
      {
        upazila: 'খুলনা সদর / সোনাডাঙ্গা',
        contacts: [
          {
            id: 'khl-sdr-pol',
            name: 'খুলনা সদর থানা পুলিশ',
            category: 'police',
            phone: '01320-140000',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Khulna+Sadar+Thana',
            address: 'কেডিএ অ্যাভিনিউ, খুলনা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'khl-sdr-fs',
            name: 'খুলনা কেন্দ্রীয় ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '041-760333',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Khulna+Fire+Service+Station',
            address: 'বয়রা মেইন রোড, খুলনা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'khl-kmch-hosp',
            name: 'খুলনা মেডিকেল কলেজ হাসপাতাল (KMCH)',
            category: 'hospital',
            phone: '041-760350',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Khulna+Medical+College+Hospital',
            address: 'বয়রা, খুলনা',
            availableHours: '২৪ ঘণ্টা ইমার্জেন্সি'
          }
        ]
      }
    ]
  },
  {
    district: 'সিলেট',
    upazilas: [
      {
        upazila: 'সিলেট সদর / কোতোয়ালি',
        contacts: [
          {
            id: 'syl-sdr-pol',
            name: 'কোতোয়ালি মডেল থানা, সিলেট',
            category: 'police',
            phone: '01320-117500',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kotwali+Model+Thana+Sylhet',
            address: 'বন্দরবাজার, সিলেট',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'syl-sdr-fs',
            name: 'সিলেট ফায়ার সার্ভিস ও সিভিল ডিফেন্স স্টেশন',
            category: 'fire_service',
            phone: '0821-713999',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Sylhet+Fire+Service+Station',
            address: 'তালতলা, সিলেট সদর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'syl-somch-hosp',
            name: 'সিলেট এম এ জি ওসমানী মেডিকেল কলেজ হাসপাতাল',
            category: 'hospital',
            phone: '0821-713487',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Sylhet+MAG+Osmani+Medical+College+Hospital',
            address: 'মেডিকেল রোড, কাজলশাহ, সিলেট',
            availableHours: '২৪ ঘণ্টা ইমার্জেন্সি'
          }
        ]
      }
    ]
  },
  {
    district: 'বগুড়া',
    upazilas: [
      {
        upazila: 'বগুড়া সদর',
        contacts: [
          {
            id: 'bog-sdr-pol',
            name: 'বগুড়া সদর থানা পুলিশ',
            category: 'police',
            phone: '01320-128000',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Bogura+Sadar+Thana',
            address: 'সাতমাথা সংলগ্ন, বগুড়া',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'bog-sdr-fs',
            name: 'বগুড়া ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '051-66000',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Bogura+Fire+Station',
            address: 'ঠনঠনিয়া, বগুড়া',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      },
      {
        upazila: 'শিবগঞ্জ',
        contacts: [
          {
            id: 'bog-shb-pol',
            name: 'শিবগঞ্জ থানা পুলিশ, বগুড়া',
            category: 'police',
            phone: '01320-128200',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Shibganj+Police+Station+Bogura',
            address: 'শিবগঞ্জ বাজার',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'bog-shb-fs',
            name: 'শিবগঞ্জ ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '01730-002888',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Shibganj+Fire+Service+Station+Bogura',
            address: 'মহাস্থান রোড, শিবগঞ্জ',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      }
    ]
  },
  {
    district: 'কুমিল্লা',
    upazilas: [
      {
        upazila: 'কুমিল্লা আদর্শ সদর',
        contacts: [
          {
            id: 'com-sdr-pol',
            name: 'কোতোয়ালি মডেল থানা, কুমিল্লা',
            category: 'police',
            phone: '01320-112000',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kotwali+Model+Thana+Cumilla',
            address: 'কান্দিরপাড়, কুমিল্লা সদর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'com-sdr-fs',
            name: 'কুমিল্লা ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '081-65555',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Cumilla+Fire+Station',
            address: 'শাসনগাছা, কুমিল্লা',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      }
    ]
  },
  {
    district: 'রংপুর',
    upazilas: [
      {
        upazila: 'রংপুর সদর / কোতোয়ালি',
        contacts: [
          {
            id: 'rng-sdr-pol',
            name: 'কোতোয়ালি থানা পুলিশ, রংপুর',
            category: 'police',
            phone: '01320-132000',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kotwali+Thana+Rangpur',
            address: 'কাচারী বাজার, রংপুর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'rng-sdr-fs',
            name: 'রংপুর ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '0521-62222',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Rangpur+Fire+Station',
            address: 'জাহাজ কোম্পানি মোড় সংলগ্ন',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      }
    ]
  },
  {
    district: 'বরিশাল',
    upazilas: [
      {
        upazila: 'বরিশাল সদর / কোতোয়ালি',
        contacts: [
          {
            id: 'bar-sdr-pol',
            name: 'কোতোয়ালি মডেল থানা, বরিশাল',
            category: 'police',
            phone: '01320-155000',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kotwali+Model+Thana+Barishal',
            address: 'সদর রোড, বরিশাল',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'bar-sdr-fs',
            name: 'বরিশাল সদর ফায়ার সার্ভিস স্টেশন',
            category: 'fire_service',
            phone: '0431-2173333',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Barishal+Fire+Station',
            address: 'নথুল্লাবাদ, বরিশাল',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      }
    ]
  },
  {
    district: 'ময়মনসিংহ',
    upazilas: [
      {
        upazila: 'ময়মনসিংহ সদর / কোতোয়ালি',
        contacts: [
          {
            id: 'mym-sdr-pol',
            name: 'কোতোয়ালি মডেল থানা, ময়মনসিংহ',
            category: 'police',
            phone: '01320-162000',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kotwali+Model+Thana+Mymensingh',
            address: 'গাঙ্গিনার পাড়, ময়মনসিংহ সদর',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          },
          {
            id: 'mym-sdr-fs',
            name: 'ময়মনসিংহ কেন্দ্রীয় ফায়ার স্টেশন',
            category: 'fire_service',
            phone: '091-65555',
            mapUrl: 'https://www.google.com/maps/search/?api=1&query=Mymensingh+Fire+Station',
            address: 'পাটগুদাম ব্রিজ মোড়, ময়মনসিংহ',
            availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
          }
        ]
      }
    ]
  }
];

// Helper to get fallback contacts if a district/upazila is selected without custom list
export const getEmergencyContactsForLocation = (district: string, upazila?: string): LocalEmergencyContact[] => {
  const normDistrict = district && district !== 'সকল জেলা' ? district.trim() : 'পটুয়াখালী';
  const foundDist = LOCAL_EMERGENCY_DATA.find(d => 
    d.district === normDistrict || 
    normDistrict.includes(d.district) || 
    d.district.includes(normDistrict)
  );

  if (foundDist) {
    if (upazila && upazila !== 'সকল উপজেলা' && !upazila.includes('সকল উপজেলা')) {
      const normUp = upazila.trim();
      const foundUp = foundDist.upazilas.find(u => 
        u.upazila === normUp || 
        normUp.includes(u.upazila) || 
        u.upazila.includes(normUp)
      );
      if (foundUp && foundUp.contacts.length > 0) {
        return foundUp.contacts;
      }
    }
    // Return all contacts across upazilas for this district
    return foundDist.upazilas.flatMap(u => u.contacts);
  }

  // Generic national emergency fallback
  return [
    {
      id: 'gen-999',
      name: `${district || 'স্থানীয়'} জরুরি সেবা হেল্পলাইন (জাতীয়)`,
      category: 'police',
      phone: '999',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Police+Station+Fire+Service+Bangladesh',
      address: `${district || 'স্থানীয়'} এলাকা`,
      availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
    },
    {
      id: 'gen-fs',
      name: `${district || 'নিকটস্থ'} ফায়ার সার্ভিস ও সিভিল ডিফেন্স হটলাইন`,
      category: 'fire_service',
      phone: '102',
      mapUrl: `https://www.google.com/maps/search/?api=1&query=Fire+Service+Station+${encodeURIComponent(district || 'Bangladesh')}`,
      address: `${district || 'নিকটস্থ'} স্টেশন`,
      availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
    },
    {
      id: 'gen-med',
      name: `${district || 'নিকটস্থ'} স্বাস্থ্য বাতায়ন ও টেলিমেডিসিন`,
      category: 'hospital',
      phone: '16263',
      mapUrl: `https://www.google.com/maps/search/?api=1&query=Hospital+Emergency+${encodeURIComponent(district || 'Bangladesh')}`,
      address: 'সরকারি জরুরি স্বাস্থ্যসেবা',
      availableHours: '২৪ ঘণ্টা সার্বক্ষণিক'
    }
  ];
};
