/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/home/Dashboard';
import { ServicesGridView } from './components/home/ServicesGridView';
import { ServiceFinder } from './components/navigator/ServiceFinder';
import { ComprehensiveHealth } from './components/health/ComprehensiveHealth';
import { RuralTransport } from './components/transport/RuralTransport';
import { PrayerAndIslamic } from './components/prayer/PrayerAndIslamic';
import { PolicyAndFeedbackModal } from './components/common/PolicyAndFeedbackModal';
import { CropDoctor } from './components/agriculture/CropDoctor';
import { MarketPrices } from './components/agriculture/MarketPrices';
import { FertilizerCalculator } from './components/agriculture/FertilizerCalculator';
import { CropCalendar } from './components/agriculture/CropCalendar';
import { ElectricityBillCalculator } from './components/electricity/ElectricityBillCalculator';
import { CitizenServices } from './components/government/CitizenServices';
import { SocialAllowances } from './components/government/SocialAllowances';
import { HotlinesDirectory } from './components/government/HotlinesDirectory';
import { LegalAidAndPolice } from './components/legal/LegalAidAndPolice';
import { LivestockCare } from './components/livestock/LivestockCare';
import { RuralHaat } from './components/marketplace/RuralHaat';
import { LandCalculator } from './components/calculator/LandCalculator';
import { LoanCalculator } from './components/calculator/LoanCalculator';
import { AIPolliAdvisor } from './components/ai/AIPolliAdvisor';
import { ServiceAreaFlow } from './components/navigator/ServiceAreaFlow';
import { AdminPanel } from './components/admin/AdminPanel';
import { AccountPage } from './components/profile/AccountPage';
import { SettingsPage } from './components/settings/SettingsPage';
import { TermsAndPolicyPage } from './components/legal/TermsAndPolicyPage';
import { HousingModule } from './components/housing/HousingModule';
import { MatrimonyModule } from './components/matrimony/MatrimonyModule';
import { PWAInstallPrompt } from './components/common/PWAInstallPrompt';
import { AuthModal } from './components/auth/AuthModal';
import { BottomNavigationBar, MainNavView } from './components/common/BottomNavigationBar';
import { UserProfile } from './types/auth';
import { ServiceCategory, NavigationSubTabs } from './types';
import { getSavedLocation } from './utils/locationService';
import { 
  saveCloudUserProfile, 
  DemandNotification, 
  subscribeToDemandNotifications, 
  subscribeToUnreadInboxCount, 
  isNotificationTargetedToUser, 
  recordAppVisit,
  subscribeToIncomingCalls,
  updateCallSessionStatus,
  CallSessionData,
  updateUserPresence,
  subscribeToAllOnlineUsers,
  getStoredMissedCallsCount,
  resetMissedCallsBadge,
  isUserBlocked,
  saveCloudCallRecord,
  MissedCallRecord
} from './lib/cloudSync';
import { 
  checkAndDispatchBackgroundAlerts, 
  requestNotificationPermission,
  showIncomingCallForegroundAlert,
  dismissIncomingCallAlert
} from './utils/notificationService';
import { UserInboxModal } from './components/chat/UserInboxModal';
import { ChatModal } from './components/chat/ChatModal';
import { AreaAlertsModal } from './components/AreaAlertsModal';
import { IncomingCallDialog } from './components/voice/IncomingCallDialog';
import { InAppVoiceCallModal } from './components/transport/InAppVoiceCallModal';
import { CitizenPublicProfileModal } from './components/profile/CitizenPublicProfileModal';
import { 
  Sprout, 
  Store, 
  Scale, 
  Calendar, 
  Zap, 
  AlertOctagon, 
  Landmark, 
  Heart, 
  PhoneCall, 
  Ruler, 
  CreditCard,
  ArrowLeft,
  ExternalLink 
} from 'lucide-react';

export default function App() {
  const [activeCategory, setActiveCategory] = useState<ServiceCategory>('home');
  const [selectedDistrict, setSelectedDistrict] = useState<string>(() => {
    const savedLoc = getSavedLocation();
    if (savedLoc && savedLoc.district) {
      return savedLoc.district;
    }
    return 'সকল জেলা';
  });
  const [selectedUpazila, setSelectedUpazila] = useState<string>(() => {
    const savedLoc = getSavedLocation();
    if (savedLoc && savedLoc.upazila) {
      return savedLoc.upazila;
    }
    return 'সকল উপজেলা';
  });
  const [fontSizeClass, setFontSizeClass] = useState<'text-base' | 'text-lg'>('text-base');

  // Record visitor count on initial load
  useEffect(() => {
    recordAppVisit();
  }, []);

  // Listen to cross-component location changes & public profile opener
  useEffect(() => {
    const handleLocationChange = (e: any) => {
      if (e.detail) {
        if (e.detail.district) {
          setSelectedDistrict(e.detail.district);
        }
        if (e.detail.upazila) {
          setSelectedUpazila(e.detail.upazila);
        }
      }
    };
    const handleOpenPublicProfile = (e: any) => {
      if (e.detail?.user) {
        setPublicProfileTarget(e.detail.user);
      }
    };
    window.addEventListener('polli_location_changed', handleLocationChange);
    window.addEventListener('polli_open_public_profile', handleOpenPublicProfile);
    return () => {
      window.removeEventListener('polli_location_changed', handleLocationChange);
      window.removeEventListener('polli_open_public_profile', handleOpenPublicProfile);
    };
  }, []);

  // User Profile & Authentication State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('polli_user_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authPromptAction, setAuthPromptAction] = useState<string>('সেবা উপভোগ করতে');

  // Policy & Feedback Modal State
  const [showPolicyModal, setShowPolicyModal] = useState<boolean>(false);
  const [policyModalTab, setPolicyModalTab] = useState<'policy' | 'feedback'>('policy');
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);
  const [isInboxOpen, setIsInboxOpen] = useState<boolean>(false);
  const [demandAlerts, setDemandAlerts] = useState<DemandNotification[]>([]);
  const [isAlertsModalOpen, setIsAlertsModalOpen] = useState<boolean>(false);

  // Sub-tab states for multi-feature modules
  const [agriSubTab, setAgriSubTab] = useState<'doctor' | 'prices' | 'fertilizer' | 'calendar'>('doctor');
  const [electricitySubTab, setElectricitySubTab] = useState<'bill' | 'complaints'>('bill');
  const [govSubTab, setGovSubTab] = useState<'services' | 'allowances' | 'hotlines' | 'legal'>('services');
  const [calcSubTab, setCalcSubTab] = useState<'land' | 'loan'>('land');
  const [marketSubTab, setMarketSubTab] = useState<'products' | 'labor' | 'tutors' | 'mechanics'>('products');
  const [healthSubTab, setHealthSubTab] = useState<'donors' | 'rural_doctors' | 'ambulances' | 'hospitals' | 'doctors' | 'clinics' | 'vaccine' | 'firstaid'>('donors');

  // Step-by-step navigation history stack to record each page transition precisely
  const navHistoryRef = useRef<Array<{
    category: ServiceCategory;
    subTabs?: NavigationSubTabs;
  }>>([{ category: 'home' }]);

  const handleNavigateWithSubTabs = (cat: ServiceCategory, subTabs?: NavigationSubTabs, pushToHistory = true) => {
    setActiveCategory(cat);
    if (subTabs) {
      if (subTabs.market) setMarketSubTab(subTabs.market);
      if (subTabs.health) setHealthSubTab(subTabs.health);
      if (subTabs.agri) setAgriSubTab(subTabs.agri);
      if (subTabs.electricity) setElectricitySubTab(subTabs.electricity);
      if (subTabs.gov) setGovSubTab(subTabs.gov);
      if (subTabs.calc) setCalcSubTab(subTabs.calc);
    } else {
      if (cat === 'marketplace') setMarketSubTab('products');
    }

    if (pushToHistory && typeof window !== 'undefined') {
      const current = navHistoryRef.current[navHistoryRef.current.length - 1];
      const isDuplicate = current && 
        current.category === cat && 
        JSON.stringify(current.subTabs || {}) === JSON.stringify(subTabs || {});

      if (!isDuplicate) {
        navHistoryRef.current.push({ category: cat, subTabs });
        window.history.pushState({
          category: cat,
          marketSubTab: subTabs?.market || (cat === 'marketplace' ? 'products' : undefined),
          healthSubTab: subTabs?.health,
          agriSubTab: subTabs?.agri,
          electricitySubTab: subTabs?.electricity,
          govSubTab: subTabs?.gov,
          calcSubTab: subTabs?.calc,
          historyDepth: navHistoryRef.current.length
        }, '');
      }
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Mobile physical back button and browser history listener
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Initialize root history state
    if (!window.history.state || window.history.state.category === undefined) {
      window.history.replaceState({ category: 'home', historyDepth: 1 }, '');
    }

    const handlePopState = (event: PopStateEvent) => {
      // 1. If any modal is active, close the modal first and stay on the current page
      if (isAdminOpen) {
        setIsAdminOpen(false);
        return;
      }
      if (isAuthModalOpen) {
        setIsAuthModalOpen(false);
        return;
      }
      if (isInboxOpen) {
        setIsInboxOpen(false);
        return;
      }
      if (isAlertsModalOpen) {
        setIsAlertsModalOpen(false);
        return;
      }
      if (publicProfileTarget) {
        setPublicProfileTarget(null);
        return;
      }
      if (showPolicyModal) {
        setShowPolicyModal(false);
        return;
      }

      // 2. Step back through the internal history stack (step-by-step navigation)
      if (navHistoryRef.current.length > 1) {
        navHistoryRef.current.pop(); // remove currently active step
        const prev = navHistoryRef.current[navHistoryRef.current.length - 1];
        if (prev) {
          setActiveCategory(prev.category);
          if (prev.subTabs) {
            if (prev.subTabs.market) setMarketSubTab(prev.subTabs.market);
            if (prev.subTabs.health) setHealthSubTab(prev.subTabs.health);
            if (prev.subTabs.agri) setAgriSubTab(prev.subTabs.agri);
            if (prev.subTabs.electricity) setElectricitySubTab(prev.subTabs.electricity);
            if (prev.subTabs.gov) setGovSubTab(prev.subTabs.gov);
            if (prev.subTabs.calc) setCalcSubTab(prev.subTabs.calc);
          } else if (prev.category === 'marketplace') {
            setMarketSubTab('products');
          }
          return;
        }
      }

      // 3. Fallback to event.state if available
      if (event.state && event.state.category) {
        setActiveCategory(event.state.category);
        if (event.state.marketSubTab) setMarketSubTab(event.state.marketSubTab);
        if (event.state.healthSubTab) setHealthSubTab(event.state.healthSubTab);
        if (event.state.agriSubTab) setAgriSubTab(event.state.agriSubTab);
        if (event.state.electricitySubTab) setElectricitySubTab(event.state.electricitySubTab);
        if (event.state.govSubTab) setGovSubTab(event.state.govSubTab);
        if (event.state.calcSubTab) setCalcSubTab(event.state.calcSubTab);
      } else {
        setActiveCategory('home');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [isAdminOpen, isAuthModalOpen, isInboxOpen, isAlertsModalOpen, showPolicyModal]);

  // Scroll to top smoothly when changing page category
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeCategory]);

  const toggleFontSize = () => {
    setFontSizeClass(prev => prev === 'text-base' ? 'text-lg' : 'text-base');
  };

  const handleOpenHotlines = () => {
    setActiveCategory('government');
    setGovSubTab('hotlines');
  };

  const handleOpenAIAdvisor = () => {
    setActiveCategory('ai-advisor');
  };

  const handleOpenPolicy = (tab: 'policy' | 'feedback') => {
    setPolicyModalTab(tab);
    setShowPolicyModal(true);
  };

  // Auto-request notification permission on mount so device shows heads-up shutter & lock-screen notifications
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
      requestNotificationPermission().catch(() => {});
    }
  }, []);

  // Deep Link Event Listener (from Web Notification clicks / Service Worker)
  useEffect(() => {
    const handleDeepLink = (e: any) => {
      const detail = e.detail;
      if (!detail) return;
      const cat = detail.targetCategory as ServiceCategory;
      const sub = detail.subTab;
      if (cat) {
        if (cat === 'marketplace' && sub) {
          handleNavigateWithSubTabs('marketplace', { market: sub as any });
        } else if (cat === 'health' && sub) {
          handleNavigateWithSubTabs('health', { health: sub as any });
        } else if (cat === 'transport') {
          handleNavigateWithSubTabs('transport');
        } else if (cat === 'account') {
          handleNavigateWithSubTabs('account');
        } else if ((cat as string) === 'alerts' || (cat as string) === 'notifications') {
          setIsAlertsModalOpen(true);
        } else {
          handleNavigateWithSubTabs(cat);
        }
      }
    };

    window.addEventListener('polli_deep_link', handleDeepLink);

    if ('serviceWorker' in navigator) {
      const handleSWMessage = (event: MessageEvent) => {
        if (event.data?.type === 'DEEP_LINK') {
          window.dispatchEvent(new CustomEvent('polli_deep_link', { detail: event.data }));
        } else if (event.data?.type === 'ACCEPT_INCOMING_CALL') {
          window.dispatchEvent(new CustomEvent('polli_accept_incoming_call', { detail: event.data }));
        } else if (event.data?.type === 'REJECT_INCOMING_CALL') {
          window.dispatchEvent(new CustomEvent('polli_reject_incoming_call', { detail: event.data }));
        }
      };
      navigator.serviceWorker.addEventListener('message', handleSWMessage);
      return () => {
        window.removeEventListener('polli_deep_link', handleDeepLink);
        navigator.serviceWorker.removeEventListener('message', handleSWMessage);
      };
    }

    return () => {
      window.removeEventListener('polli_deep_link', handleDeepLink);
    };
  }, []);

  // Parse URL query params on boot (e.g. ?category=marketplace&subtab=products)
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const cat = params.get('category') as ServiceCategory | null;
      const sub = params.get('subtab');
      if (cat) {
        if (cat === 'marketplace' && sub) {
          handleNavigateWithSubTabs('marketplace', { market: sub as any });
        } else if (cat === 'health' && sub) {
          handleNavigateWithSubTabs('health', { health: sub as any });
        } else {
          handleNavigateWithSubTabs(cat);
        }
      }
    } catch (e) {}
  }, []);

  // Subscribe to real-time demand notifications from Firestore Cloud
  useEffect(() => {
    const unsub = subscribeToDemandNotifications((notifs) => {
      setDemandAlerts(notifs);
    });
    return () => {
      if (unsub) unsub();
    };
  }, []);

  // Check and dispatch background system push alerts when data is on or demandAlerts update
  // Like WhatsApp / Messenger / YouTube: as soon as internet data is connected, alerts show on screen
  useEffect(() => {
    const userDist = currentUser?.district || (selectedDistrict !== 'সকল জেলা' ? selectedDistrict : undefined);
    const userUpz = currentUser?.upazila;
    const userRole = currentUser?.role;
    const userUnion = currentUser?.union;
    const isDonor = currentUser?.isBloodDonor || !!currentUser?.bloodGroup;

    const isTargeted = (notif: any) => {
      return isNotificationTargetedToUser(notif, userDist, userUpz, userRole, userUnion, currentUser?.phone, isDonor);
    };

    // Check alerts immediately
    if (demandAlerts.length > 0) {
      checkAndDispatchBackgroundAlerts(demandAlerts, isTargeted);
    }

    // Also check when internet / mobile data turns on (online event)
    const handleOnline = () => {
      if (demandAlerts.length > 0) {
        checkAndDispatchBackgroundAlerts(demandAlerts, isTargeted);
      }
    };

    window.addEventListener('online', handleOnline);
    return () => {
      window.removeEventListener('online', handleOnline);
    };
  }, [demandAlerts, currentUser, selectedDistrict]);

  // Real-time unread messages count & Missed calls badge for active user
  const [unreadInboxCount, setUnreadInboxCount] = useState<number>(0);
  const [missedCallsCount, setMissedCallsCount] = useState<number>(() => {
    return getStoredMissedCallsCount(currentUser?.phone || currentUser?.id);
  });

  useEffect(() => {
    const updateMissedCount = () => {
      setMissedCallsCount(getStoredMissedCallsCount(currentUser?.phone || currentUser?.id));
    };
    updateMissedCount();
    window.addEventListener('polli_missed_calls_updated', updateMissedCount);
    return () => {
      window.removeEventListener('polli_missed_calls_updated', updateMissedCount);
    };
  }, [currentUser]);

  useEffect(() => {
    if (!currentUser) {
      setUnreadInboxCount(0);
      return;
    }
    const myId = currentUser.phone ? currentUser.phone.replace(/[^0-9]/g, '') : currentUser.id;
    const unsub = subscribeToUnreadInboxCount(myId, (count) => {
      setUnreadInboxCount(count);
    });
    return () => {
      if (unsub) unsub();
    };
  }, [currentUser]);

  // Compute how many notifications target this user's district, upazila, union, role or blood donor status
  const userDist = currentUser?.district || (selectedDistrict !== 'সকল জেলা' ? selectedDistrict : undefined);
  const userUpz = currentUser?.upazila;
  const userRole = currentUser?.role;
  const userUnion = currentUser?.union;
  const isDonor = currentUser?.isBloodDonor || !!currentUser?.bloodGroup;

  const targetedAlertCount = demandAlerts.filter((notif) => {
    return isNotificationTargetedToUser(notif, userDist, userUpz, userRole, userUnion, currentUser?.phone, isDonor);
  }).length;

  const [activeDirectChat, setActiveDirectChat] = useState<{
    recipientId: string;
    recipientName: string;
    recipientRole?: string;
    recipientPhone?: string;
    itemTitle?: string;
  } | null>(null);

  const [publicProfileTarget, setPublicProfileTarget] = useState<Partial<UserProfile> | null>(null);
  const [incomingCallSession, setIncomingCallSession] = useState<CallSessionData | null>(null);
  const [activeAnsweredCall, setActiveAnsweredCall] = useState<CallSessionData | null>(null);

  // User online presence heartbeat & global status tracking
  useEffect(() => {
    if (!currentUser) return;
    const myId = currentUser.phone ? currentUser.phone.replace(/[^0-9]/g, '') : currentUser.id;
    if (!myId) return;

    // Send active online heartbeat
    updateUserPresence(myId, true);

    const interval = setInterval(() => {
      updateUserPresence(myId, true);
    }, 90000); // 90 seconds heartbeat

    const handleBeforeUnload = () => {
      updateUserPresence(myId, false);
    };
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      clearInterval(interval);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      updateUserPresence(myId, false);
    };
  }, [currentUser]);

  const incomingCallSessionRef = useRef(incomingCallSession);
  incomingCallSessionRef.current = incomingCallSession;
  const activeAnsweredCallRef = useRef(activeAnsweredCall);
  activeAnsweredCallRef.current = activeAnsweredCall;

  // Subscribe to real-time incoming voice calls
  useEffect(() => {
    const myPhoneOrId = currentUser 
      ? (currentUser.phone ? currentUser.phone.replace(/[^0-9]/g, '') : currentUser.id) 
      : '';
    if (!myPhoneOrId) return;

    const unsub = subscribeToIncomingCalls(myPhoneOrId, (session) => {
      // Only pop up if not already in another call
      if (!incomingCallSessionRef.current && !activeAnsweredCallRef.current) {
        setIncomingCallSession(session);
        // Show high-priority foreground call notification (bypasses lock screen & shows over other apps)
        showIncomingCallForegroundAlert({
          channelId: session.channelId,
          callerName: session.callerName,
          callerRole: session.callerRole,
          callerAvatar: session.callerAvatar,
          callerPhone: session.callerPhone
        });
      }
    });

    return () => {
      if (unsub) unsub();
    };
  }, [currentUser]);

  const handleAcceptIncomingCall = async (sessionToAccept?: CallSessionData) => {
    const session = sessionToAccept || incomingCallSession;
    if (!session) return;
    dismissIncomingCallAlert(session.channelId);
    await updateCallSessionStatus(session.channelId, 'accepted');
    setActiveAnsweredCall(session);
    setIncomingCallSession(null);
  };

  const handleRejectIncomingCall = async (channelIdToReject?: string) => {
    const session = incomingCallSession;
    const channelId = channelIdToReject || session?.channelId;
    if (channelId) {
      dismissIncomingCallAlert(channelId);
      await updateCallSessionStatus(channelId, 'rejected');
    }

    if (session) {
      // Record missed call entry for current user
      const now = new Date();
      const missedRecord: MissedCallRecord = {
        id: `MC-${Date.now()}`,
        callerName: session.callerName || 'পল্লী সেবা নাগরিক',
        callerPhone: session.callerPhone || '০১৭xxxxxxxx',
        callerRole: session.callerRole || 'নাগরিক',
        callerSubtitle: session.recipientSubtitle,
        callerAvatar: session.callerAvatar,
        recipientName: currentUser?.name || 'পল্লী সেবা নাগরিক',
        recipientPhone: currentUser?.phone || '',
        recipientRole: currentUser?.role,
        timestamp: Date.now(),
        formattedDate: now.toLocaleDateString('bn-BD'),
        formattedTime: now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
        isCallbackDone: false,
        type: 'missed'
      };
      saveCloudCallRecord(missedRecord).catch(() => {});
    }

    setIncomingCallSession(null);
  };

  // Listen for Call Actions from Lockscreen Notification / Service Worker
  useEffect(() => {
    const handleAcceptEvent = (e: any) => {
      if (incomingCallSessionRef.current) {
        handleAcceptIncomingCall(incomingCallSessionRef.current);
      }
    };

    const handleRejectEvent = (e: any) => {
      const channelId = e.detail?.channelId;
      handleRejectIncomingCall(channelId);
    };

    window.addEventListener('polli_accept_incoming_call', handleAcceptEvent);
    window.addEventListener('polli_reject_incoming_call', handleRejectEvent);

    return () => {
      window.removeEventListener('polli_accept_incoming_call', handleAcceptEvent);
      window.removeEventListener('polli_reject_incoming_call', handleRejectEvent);
    };
  }, []);

  const handleOpenAuth = (actionName?: string) => {
    setAuthPromptAction(actionName || 'সেবা উপভোগ করতে');
    setIsAuthModalOpen(true);
  };

  const handleAuthSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    localStorage.setItem('polli_user_profile', JSON.stringify(user));
    saveCloudUserProfile(user);
    setIsAuthModalOpen(false);
  };

  const handleUpdateProfile = (updated: UserProfile) => {
    setCurrentUser(updated);
    localStorage.setItem('polli_user_profile', JSON.stringify(updated));
    saveCloudUserProfile(updated);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('polli_user_profile');
  };

  // Convert active category to MainNavView for bottom bar
  const getBottomNavView = (): MainNavView => {
    if (activeCategory === 'home') return 'home';
    if (activeCategory === 'services') return 'services';
    if (activeCategory === 'ai-advisor') return 'ai-advisor';
    if (activeCategory === 'settings') return 'settings';
    if (activeCategory === 'account') return 'account';
    if (activeCategory === 'terms-help') return 'terms-help';
    return 'service-detail';
  };

  const handleBottomNavSelect = (view: MainNavView) => {
    const catMap: Record<MainNavView, ServiceCategory> = {
      'home': 'home',
      'services': 'services',
      'ai-advisor': 'ai-advisor',
      'settings': 'settings',
      'account': 'account',
      'terms-help': 'terms-help',
      'service-detail': 'services'
    };
    const targetCat = catMap[view] || 'home';
    if (targetCat !== activeCategory) {
      handleNavigateWithSubTabs(targetCat, undefined, true);
    }
  };

  return (
    <div className={`min-h-screen bg-[#FDFBF7] text-[#2D3A3A] flex flex-col ${fontSizeClass}`}>
      {/* Header */}
      <Header
        selectedDistrict={selectedDistrict}
        onSelectDistrict={setSelectedDistrict}
        selectedUpazila={selectedUpazila}
        onSelectUpazila={setSelectedUpazila}
        onOpenAIAdvisor={() => handleNavigateWithSubTabs('ai-advisor', undefined, true)}
        onOpenHotlines={() => handleNavigateWithSubTabs('government', { gov: 'hotlines' }, true)}
        onOpenAdmin={() => {
          setIsAdminOpen(true);
          if (typeof window !== 'undefined') window.history.pushState({ isModal: true }, '');
        }}
        onOpenSettings={() => handleNavigateWithSubTabs('settings', undefined, true)}
        fontSizeClass={fontSizeClass}
        onToggleFontSize={toggleFontSize}
        currentUser={currentUser}
        onOpenInbox={() => {
          setIsInboxOpen(true);
          resetMissedCallsBadge(currentUser?.phone || currentUser?.id);
          setMissedCallsCount(0);
          if (typeof window !== 'undefined') window.history.pushState({ isModal: true }, '');
        }}
        unreadInboxCount={unreadInboxCount + missedCallsCount}
        onOpenAuth={handleOpenAuth}
        onOpenAccount={() => handleNavigateWithSubTabs('account', undefined, true)}
      />

      {/* Main Navigation Bar */}
      <Navigation
        activeTab={activeCategory}
        onSelectTab={(cat) => handleNavigateWithSubTabs(cat, undefined, true)}
        currentUser={currentUser}
      />

      {/* Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-4 py-5 sm:py-6 pb-36 sm:pb-44">
        {/* Prominent Back to Home navigation bar when inside sub-services */}
        {activeCategory !== 'home' && (
          <div className="mb-4 flex items-center justify-between bg-white px-3.5 py-2.5 rounded-2xl border border-[#E6E0D4] shadow-2xs">
            <button
              onClick={() => {
                if (typeof window !== 'undefined' && window.history.length > 1 && navHistoryRef.current.length > 1) {
                  window.history.back();
                } else if (navHistoryRef.current.length > 1) {
                  navHistoryRef.current.pop();
                  const prev = navHistoryRef.current[navHistoryRef.current.length - 1];
                  if (prev) {
                    handleNavigateWithSubTabs(prev.category, prev.subTabs, false);
                  } else {
                    handleNavigateWithSubTabs('home', undefined, false);
                  }
                } else {
                  handleNavigateWithSubTabs('home', undefined, false);
                }
              }}
              className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-[#2D5A27] hover:bg-[#FAF8F5] px-2.5 py-1.5 rounded-xl transition cursor-pointer"
              title="পূর্বের পাতায় ফিরে যান"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>← ফিরে যান</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleNavigateWithSubTabs('home')}
                className="text-xs bg-[#FAF8F5] hover:bg-[#E6E0D4] text-[#2D3A3A] px-3 py-1.5 rounded-xl font-bold border border-[#D4C3A3] transition cursor-pointer flex items-center gap-1"
              >
                <span>🏠 হোম ড্যাশবোর্ড</span>
              </button>
            </div>
          </div>
        )}

        {/* 1. HOME DASHBOARD */}
        {activeCategory === 'home' && (
          <Dashboard
            currentDistrict={selectedDistrict}
            onNavigate={handleNavigateWithSubTabs}
            onSelectDistrict={setSelectedDistrict}
          />
        )}

        {/* 24 SERVICES FULL GRID VIEW */}
        {activeCategory === 'services' && (
          <ServicesGridView
            currentDistrict={selectedDistrict}
            onSelectService={handleNavigateWithSubTabs}
          />
        )}

        {/* SERVICE & AREA STEP-BY-STEP FLOW (NEW FEATURE) */}
        {activeCategory === 'service-flow' && (
          <ServiceAreaFlow
            currentUser={currentUser}
            onNavigateTab={(tabKey) => {
              if (tabKey === 'tutors') {
                handleNavigateWithSubTabs('marketplace', { market: 'tutors' });
              } else if (tabKey === 'mechanics') {
                handleNavigateWithSubTabs('marketplace', { market: 'mechanics' });
              } else if (tabKey === 'labor') {
                handleNavigateWithSubTabs('marketplace', { market: 'labor' });
              } else if (tabKey === 'doctor' || tabKey === 'prices' || tabKey === 'fertilizer') {
                handleNavigateWithSubTabs('agriculture', { agri: tabKey as any });
              } else {
                handleNavigateWithSubTabs(tabKey as ServiceCategory, undefined, true);
              }
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenAuth={handleOpenAuth}
          />
        )}

        {/* USER PROFILE & ACCOUNT DASHBOARD */}
        {activeCategory === 'account' && (
          <AccountPage
            currentUser={currentUser}
            onUpdateProfile={handleUpdateProfile}
            onLogout={handleLogout}
            onOpenAuthModal={handleOpenAuth}
            onNavigateToService={(cat) => handleNavigateWithSubTabs(cat as ServiceCategory, undefined, true)}
            onOpenAdmin={() => {
              setIsAdminOpen(true);
              if (typeof window !== 'undefined') window.history.pushState({ isModal: true }, '');
            }}
            onOpenAlerts={() => {
              setIsAlertsModalOpen(true);
              if (typeof window !== 'undefined') window.history.pushState({ isModal: true }, '');
            }}
            unreadAlertsCount={targetedAlertCount}
            onOpenInbox={() => {
              setIsInboxOpen(true);
              if (typeof window !== 'undefined') window.history.pushState({ isModal: true }, '');
            }}
            onStartInAppCall={(targetUser) => {
              setActiveAnsweredCall({
                channelId: `call_${Date.now()}_${targetUser.phone || targetUser.id || 'preview'}`,
                callerId: currentUser?.phone || currentUser?.id || 'guest',
                callerName: targetUser.name || 'সম্মানিত সদস্য',
                recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
                recipientName: targetUser.name || 'সম্মানিত সদস্য',
                recipientRole: targetUser.role,
                recipientPhone: targetUser.phone,
                recipientAvatar: targetUser.customAvatarUrl,
                status: 'ringing',
                createdAt: Date.now()
              });
            }}
          />
        )}

        {/* PROFESSIONAL APP SETTINGS & DATA CONTROLS */}
        {activeCategory === 'settings' && (
          <SettingsPage
            currentUser={currentUser}
            onLogout={handleLogout}
            onNavigateCategory={(cat) => handleNavigateWithSubTabs(cat as ServiceCategory, undefined, true)}
            onOpenAuth={handleOpenAuth}
            onOpenAdmin={() => {
              setIsAdminOpen(true);
              if (typeof window !== 'undefined') window.history.pushState({ isModal: true }, '');
            }}
            onUpdateProfile={handleUpdateProfile}
          />
        )}

        {/* LEGAL, TERMS & EMAIL FEEDBACK */}
        {activeCategory === 'terms-help' && (
          <TermsAndPolicyPage currentUser={currentUser} />
        )}

        {/* 2. AGRICULTURE & CROPS (FIRST CLASS PRIORITY) */}
        {activeCategory === 'agriculture' && (
          <div className="space-y-4">
            {/* Sub Tabs */}
            <div className="flex gap-2 border-b border-[#E6E0D4] pb-2 overflow-x-auto no-scrollbar">
              <button
                onClick={() => setAgriSubTab('doctor')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  agriSubTab === 'doctor'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                <Sprout className="w-4 h-4" />
                <span>শস্য ডাক্তার ও বালাইদমন</span>
              </button>

              <button
                onClick={() => setAgriSubTab('prices')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  agriSubTab === 'prices'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                <Store className="w-4 h-4" />
                <span>দৈনিক কৃষি বাজারদর</span>
              </button>

              <button
                onClick={() => setAgriSubTab('fertilizer')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  agriSubTab === 'fertilizer'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                <Scale className="w-4 h-4" />
                <span>সার প্রয়োগ ক্যালকুলেটর</span>
              </button>

              <button
                onClick={() => setAgriSubTab('calendar')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  agriSubTab === 'calendar'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>মৌসুমী ফসল পঞ্জিকা</span>
              </button>
            </div>

            {/* Sub View Rendering */}
            {agriSubTab === 'doctor' && <CropDoctor />}
            {agriSubTab === 'prices' && <MarketPrices currentDistrict={selectedDistrict} />}
            {agriSubTab === 'fertilizer' && <FertilizerCalculator />}
            {agriSubTab === 'calendar' && <CropCalendar />}
          </div>
        )}

        {/* 3. WHERE & HOW TO GET SERVICES */}
        {activeCategory === 'service-finder' && (
          <ServiceFinder />
        )}

        {/* 4. COMPREHENSIVE HEALTH, BLOOD & HOSPITALS */}
        {(activeCategory === 'health' || (activeCategory as string) === 'blood-health') && (
          <ComprehensiveHealth 
            currentDistrict={selectedDistrict} 
            currentUser={currentUser}
            initialTab={healthSubTab} 
          />
        )}

        {/* 5. RURAL TRANSPORT & VERIFIED DRIVERS */}
        {activeCategory === 'transport' && (
          <RuralTransport 
            currentDistrict={selectedDistrict} 
            currentUser={currentUser}
            onOpenAuth={() => setIsAuthModalOpen(true)}
          />
        )}

        {/* 6. PRAYER TIMES & ISLAMIC GUIDELINES */}
        {activeCategory === 'prayer-islamic' && (
          <PrayerAndIslamic 
            currentDistrict={selectedDistrict} 
            onSelectDistrict={(dist) => setSelectedDistrict(dist)}
          />
        )}

        {/* 7. ELECTRICITY & UTILITIES */}
        {activeCategory === 'electricity' && (
          <ElectricityBillCalculator initialTab={electricitySubTab} />
        )}

        {/* 8. GOVERNMENT CITIZEN SERVICES */}
        {activeCategory === 'government' && (
          <div className="space-y-4">
            <div className="flex gap-2 border-b border-[#E6E0D4] pb-2 overflow-x-auto no-scrollbar">
              <button
                onClick={() => setGovSubTab('services')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  govSubTab === 'services'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                <Landmark className="w-4 h-4" />
                <span>নাগরিক সনদ ও ইউপি সেবা</span>
              </button>

              <button
                onClick={() => setGovSubTab('allowances')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  govSubTab === 'allowances'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                <Heart className="w-4 h-4" />
                <span>সরকারি ভাতা যোগ্যতা যাচাই</span>
              </button>

              <button
                onClick={() => setGovSubTab('hotlines')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  govSubTab === 'hotlines'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                <PhoneCall className="w-4 h-4" />
                <span>জরুরি হটলাইন ডিরেক্টরি</span>
              </button>

              <button
                onClick={() => setGovSubTab('legal')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  govSubTab === 'legal'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                <Scale className="w-4 h-4" />
                <span>আইন, আদালত ও সরকারি সাহায্য</span>
              </button>
            </div>

            {govSubTab === 'services' && <CitizenServices />}
            {govSubTab === 'allowances' && <SocialAllowances />}
            {govSubTab === 'hotlines' && <HotlinesDirectory />}
            {govSubTab === 'legal' && <LegalAidAndPolice currentDistrict={selectedDistrict} />}
          </div>
        )}

        {/* 9. LEGAL AID & POLICE (STANDALONE SECTION) */}
        {activeCategory === 'legal-police' && (
          <LegalAidAndPolice currentDistrict={selectedDistrict} />
        )}

        {/* 10. LIVESTOCK & FISHERY */}
        {activeCategory === 'livestock' && (
          <LivestockCare />
        )}

        {/* 10. MARKETPLACE / HAAT */}
        {activeCategory === 'marketplace' && (
          <RuralHaat 
            currentDistrict={selectedDistrict} 
            currentUser={currentUser}
            onOpenAuth={() => setIsAuthModalOpen(true)}
            initialTab={marketSubTab}
            onTabChange={(tab) => setMarketSubTab(tab)}
          />
        )}

        {/* 11. CALCULATORS (LAND & LOAN) */}
        {activeCategory === 'calculators' && (
          <div className="space-y-4">
            <div className="flex gap-2 border-b border-[#E6E0D4] pb-2">
              <button
                onClick={() => setCalcSubTab('land')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  calcSubTab === 'land'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                <Ruler className="w-4 h-4" />
                <span>জমি পরিমাপক ও রূপান্তর</span>
              </button>

              <button
                onClick={() => setCalcSubTab('loan')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  calcSubTab === 'loan'
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'bg-white text-[#2D3A3A] hover:bg-[#F9E5D4]/40 border border-[#E6E0D4]'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>কৃষি ঋণ ও কিস্তি হিসাবক</span>
              </button>
            </div>

            {calcSubTab === 'land' && <LandCalculator />}
            {calcSubTab === 'loan' && <LoanCalculator />}
          </div>
        )}

        {/* 13. HOUSING & RENTAL (২৫. আবাসন ও বাসা ভাড়া) */}
        {activeCategory === 'housing' && (
          <HousingModule
            currentDistrict={selectedDistrict}
            currentUser={currentUser}
            onOpenAuth={handleOpenAuth}
            onStartInAppCall={(targetUser) => {
              setActiveAnsweredCall({
                channelId: `call_${Date.now()}_${targetUser.phone || targetUser.id || 'housing'}`,
                callerId: currentUser?.phone || currentUser?.id || 'guest',
                callerName: targetUser.name || 'সম্মানিত বাড়ির মালিক',
                recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
                recipientName: targetUser.name || 'সম্মানিত বাড়ির মালিক',
                recipientRole: targetUser.role || 'মালিক',
                recipientPhone: targetUser.phone,
                recipientAvatar: targetUser.customAvatarUrl,
                status: 'ringing',
                createdAt: Date.now()
              });
            }}
            onStartChat={(targetUser) => {
              setActiveDirectChat({
                recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
                recipientName: targetUser.name || 'সম্মানিত বাড়ির মালিক',
                recipientPhone: targetUser.phone,
                recipientRole: targetUser.role || 'মালিক'
              });
            }}
            onOpenVoiceNote={(targetUser) => {
              setActiveDirectChat({
                recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
                recipientName: targetUser.name || 'সম্মানিত বাড়ির মালিক',
                recipientPhone: targetUser.phone,
                recipientRole: targetUser.role || 'মালিক'
              });
            }}
          />
        )}

        {/* 14. MATCHMAKING (২৬. পাত্র-পাত্রীর সন্ধান) */}
        {activeCategory === 'matrimony' && (
          <MatrimonyModule
            currentDistrict={selectedDistrict}
            currentUser={currentUser}
            onOpenAuth={handleOpenAuth}
            onStartInAppCall={(targetUser) => {
              setActiveAnsweredCall({
                channelId: `call_${Date.now()}_${targetUser.phone || targetUser.id || 'matrimony'}`,
                callerId: currentUser?.phone || currentUser?.id || 'guest',
                callerName: targetUser.name || 'সম্মানিত অভিভাবক',
                recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
                recipientName: targetUser.name || 'সম্মানিত অভিভাবক',
                recipientRole: targetUser.role || 'অভিভাবক',
                recipientPhone: targetUser.phone,
                status: 'ringing',
                createdAt: Date.now()
              });
            }}
            onStartChat={(targetUser) => {
              setActiveDirectChat({
                recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
                recipientName: targetUser.name || 'সম্মানিত অভিভাবক',
                recipientPhone: targetUser.phone,
                recipientRole: targetUser.role || 'অভিভাবক'
              });
            }}
            onOpenVoiceNote={(targetUser) => {
              setActiveDirectChat({
                recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
                recipientName: targetUser.name || 'সম্মানিত অভিভাবক',
                recipientPhone: targetUser.phone,
                recipientRole: targetUser.role || 'অভিভাবক'
              });
            }}
          />
        )}

        {/* 12. AI GEMINI ADVISOR */}
        {activeCategory === 'ai-advisor' && (
          <AIPolliAdvisor 
            currentDistrict={selectedDistrict} 
            currentUser={currentUser}
            onOpenAuth={handleOpenAuth}
            onStartInAppCall={(targetUser) => {
              setActiveAnsweredCall({
                channelId: `call_${Date.now()}_${targetUser.phone || targetUser.id}`,
                callerId: currentUser?.phone || currentUser?.id || 'guest',
                callerName: targetUser.name || 'সম্মানিত সদস্য',
                recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
                recipientName: targetUser.name || 'সম্মানিত সদস্য',
                recipientRole: targetUser.role,
                recipientPhone: targetUser.phone,
                recipientAvatar: targetUser.avatar,
                recipientSubtitle: targetUser.vehicle || 'ইন-অ্যাপ ইন্টারনেট কল',
                status: 'ringing',
                createdAt: Date.now()
              });
            }}
            onStartChat={(targetUser) => {
              setActiveDirectChat({
                recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
                recipientName: targetUser.name || 'সম্মানিত সদস্য',
                recipientRole: targetUser.role || 'সদস্য',
                recipientPhone: targetUser.phone,
                itemTitle: targetUser.itemTitle
              });
            }}
            onViewProfile={(targetUser) => {
              setPublicProfileTarget(targetUser);
            }}
            onNavigateCategory={(cat, subTab) => {
              if (cat === 'tutors') {
                handleNavigateWithSubTabs('marketplace', { market: 'tutors' });
              } else if (cat === 'mechanics') {
                handleNavigateWithSubTabs('marketplace', { market: 'mechanics' });
              } else if (cat === 'labor') {
                handleNavigateWithSubTabs('marketplace', { market: 'labor' });
              } else if (cat === 'service-flow') {
                handleNavigateWithSubTabs('services');
              } else if (subTab) {
                const subTabs: NavigationSubTabs = {};
                if (cat === 'marketplace') subTabs.market = subTab as any;
                if (cat === 'health') subTabs.health = subTab as any;
                if (cat === 'agriculture') subTabs.agri = subTab as any;
                if (cat === 'electricity') subTabs.electricity = subTab as any;
                if (cat === 'service-finder') subTabs.gov = subTab as any;
                if (cat === 'calculators') subTabs.calc = subTab as any;
                handleNavigateWithSubTabs(cat, subTabs);
              } else {
                handleNavigateWithSubTabs(cat as ServiceCategory);
              }
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}
      </main>

      {/* Footer in Natural Tones theme */}
      <footer className="bg-[#23491E] text-[#D4E4BC] border-t border-[#3D7A35] py-7 px-4 mb-16 sm:mb-0 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-5 text-center md:text-left">
          <div>
            <div className="flex items-center justify-center md:justify-start gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-white p-0.5 shadow-xs flex items-center justify-center overflow-hidden shrink-0">
                <img src="/logo.png" alt="পল্লী সেবা" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
              </div>
              <span className="text-base font-bold text-white font-['Noto_Sans_Bengali']">
                পল্লী সেবা - ডিজিটাল গ্রামীণ জনসেবা কেন্দ্র
              </span>
            </div>
            <p className="text-[#D4E4BC]/90 text-xs mt-1">
              বাংলাদেশের কৃষক, খামারি ও গ্রামীণ নাগরিকদের সার্বক্ষণিক ডিজিটাল তথ্য ও সেবা সহায়ক
            </p>
            
            {/* Policy & Feedback Links */}
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 mt-3">
              <button
                onClick={() => handleNavigateWithSubTabs('terms-help', undefined, true)}
                className="text-xs text-[#F9E5D4] hover:text-white underline cursor-pointer flex items-center gap-1 font-medium"
              >
                📜 ব্যবহারের নীতিমালা ও প্রাইভেসী
              </button>
              <span className="text-[#D4E4BC]/40">•</span>
              <button
                onClick={() => handleNavigateWithSubTabs('terms-help', undefined, true)}
                className="text-xs text-[#F9E5D4] hover:text-white underline cursor-pointer flex items-center gap-1 font-medium"
              >
                💬 উদ্যোক্তাকে মতামত ও পরামর্শ দিন
              </button>
              <span className="text-[#D4E4BC]/40">•</span>
              <button
                onClick={() => {
                  setIsAdminOpen(true);
                  if (typeof window !== 'undefined') window.history.pushState({ isModal: true }, '');
                }}
                className="text-xs text-[#E8924A] hover:text-white underline cursor-pointer flex items-center gap-1 font-bold"
              >
                🔐 অ্যাডমিন ড্যাশবোর্ড
              </button>
              <span className="text-[#D4E4BC]/40">•</span>
              <a
                href="https://satyaprabaha.wordpress.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs text-[#D4E4BC] hover:text-white transition cursor-pointer group"
                title="সত্য ও বস্তুনিষ্ঠ সংবাদ পড়তে ভিজিট করুন সত্য প্রবাহ"
              >
                <span>📰 সত্য ও বস্তুনিষ্ঠ সংবাদ পেতে,</span>
                <span className="bg-[#15803D] hover:bg-[#166534] text-white font-bold px-2.5 py-0.5 rounded-full shadow-xs animate-pulse border border-[#22C55E]/60 inline-flex items-center gap-1">
                  <span>সত্য প্রবাহ</span>
                  <ExternalLink className="w-3 h-3 text-[#BBF7D0]" />
                </span>
                <span>এ ক্লিক করুন</span>
              </a>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-2.5 text-xs text-[#D4E4BC]">
            <span className="bg-[#2D5A27] px-2.5 py-1 rounded-lg border border-[#3D7A35]">জরুরি হেল্পলাইন: ৯৯৯</span>
            <span className="bg-[#2D5A27] px-2.5 py-1 rounded-lg border border-[#3D7A35]">কৃষি কল সেন্টার: ১৬১২৩</span>
            <span className="bg-[#2D5A27] px-2.5 py-1 rounded-lg border border-[#3D7A35]">স্বাস্থ্য বাতায়ন: ১৬২৬৩</span>
            <span className="bg-[#2D5A27] px-2.5 py-1 rounded-lg border border-[#3D7A35]">তথ্য সেবা: ৩৩৩</span>
          </div>
        </div>
      </footer>

      {/* Direct PWA Install Prompt Banner & Safari iOS Guides */}
      <PWAInstallPrompt />

      {/* Floating Bottom Navigation Bar for Mobile-First experience (hidden when modals are active) */}
      {!isAdminOpen && !isAuthModalOpen && !isInboxOpen && !activeDirectChat && !showPolicyModal && !isAlertsModalOpen && (
        <BottomNavigationBar
          currentView={getBottomNavView()}
          onSelectView={handleBottomNavSelect}
          currentUser={currentUser}
          unreadNotificationsCount={unreadInboxCount + missedCallsCount}
        />
      )}

      {/* Quick Auth Modal for phone verification */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
        onOpenTerms={() => {
          setIsAuthModalOpen(false);
          handleNavigateWithSubTabs('terms-help', undefined, true);
        }}
        promptActionName={authPromptAction}
      />

      {/* Policy & Feedback Modal */}
      {showPolicyModal && (
        <PolicyAndFeedbackModal
          initialTab={policyModalTab}
          onClose={() => setShowPolicyModal(false)}
        />
      )}

      {/* User Conversations Inbox Modal */}
      <UserInboxModal
        isOpen={isInboxOpen}
        onClose={() => setIsInboxOpen(false)}
        currentUser={currentUser}
        onOpenConversation={(params) => {
          setIsInboxOpen(false);
          setActiveDirectChat(params);
        }}
        onOpenAuth={handleOpenAuth}
      />

      {/* Direct Active Chat Modal */}
      {activeDirectChat && (
        <ChatModal
          isOpen={true}
          onClose={() => setActiveDirectChat(null)}
          currentUser={currentUser}
          recipientId={activeDirectChat.recipientId}
          recipientName={activeDirectChat.recipientName}
          recipientRole={activeDirectChat.recipientRole}
          recipientPhone={activeDirectChat.recipientPhone}
          itemTitle={activeDirectChat.itemTitle}
          onOpenAuth={handleOpenAuth}
        />
      )}

      {/* Area & Role Demand Alerts Modal */}
      <AreaAlertsModal
        isOpen={isAlertsModalOpen}
        onClose={() => setIsAlertsModalOpen(false)}
        notifications={demandAlerts}
        currentUser={currentUser}
        selectedDistrict={selectedDistrict}
        onStartChat={(params) => {
          setActiveDirectChat(params);
        }}
        onNavigateToItem={(notif) => {
          setIsAlertsModalOpen(false);
          if (notif.targetCategory) {
            const subTabsConfig: NavigationSubTabs = {};
            if (notif.targetSubTab?.main) {
              if (notif.targetCategory === 'marketplace') {
                subTabsConfig.market = notif.targetSubTab.main as any;
              } else if (notif.targetCategory === 'health') {
                subTabsConfig.health = notif.targetSubTab.main as any;
              } else if (notif.targetCategory === 'agriculture') {
                subTabsConfig.agri = notif.targetSubTab.main as any;
              }
            }
            handleNavigateWithSubTabs(notif.targetCategory as ServiceCategory, subTabsConfig);
          }
        }}
      />

      {/* Global Real-Time Incoming Call Dialog */}
      {incomingCallSession && (
        <IncomingCallDialog
          session={incomingCallSession}
          onAccept={handleAcceptIncomingCall}
          onReject={handleRejectIncomingCall}
        />
      )}

      {/* Global Real-Time Answered Call Active Screen */}
      {activeAnsweredCall && (
        <InAppVoiceCallModal
          recipientName={activeAnsweredCall.callerName}
          recipientRole={activeAnsweredCall.callerRole || 'user'}
          recipientPhoto={activeAnsweredCall.callerAvatar}
          recipientSubtitle={activeAnsweredCall.recipientSubtitle || 'ইনকামিং ফ্রি ইন্টারনেট কল'}
          maskedPhone={activeAnsweredCall.callerPhone || '০১৭xxxxxxxx'}
          rawPhone={activeAnsweredCall.callerPhone}
          currentUser={currentUser}
          initialCallState="connected"
          channelOverride={activeAnsweredCall.channelId}
          onClose={() => setActiveAnsweredCall(null)}
        />
      )}

      {/* Global Citizen Public Profile Modal */}
      {publicProfileTarget && (
        <CitizenPublicProfileModal
          isOpen={!!publicProfileTarget}
          user={publicProfileTarget}
          currentUser={currentUser}
          onClose={() => setPublicProfileTarget(null)}
          onStartInAppCall={(targetUser) => {
            setPublicProfileTarget(null);
            setActiveAnsweredCall({
              channelId: `call_${Date.now()}_${targetUser.phone || targetUser.id}`,
              callerId: currentUser?.phone || currentUser?.id || 'guest',
              callerName: targetUser.name || 'সম্মানিত সদস্য',
              recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
              recipientName: targetUser.name || 'সম্মানিত সদস্য',
              recipientRole: targetUser.role,
              recipientPhone: targetUser.phone,
              recipientAvatar: targetUser.customAvatarUrl,
              status: 'ringing',
              createdAt: Date.now()
            });
          }}
          onStartChat={(targetUser) => {
            setPublicProfileTarget(null);
            setActiveDirectChat({
              recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
              recipientName: targetUser.name || 'সম্মানিত সদস্য',
              recipientRole: targetUser.role,
              recipientPhone: targetUser.phone
            });
          }}
          onOpenVoiceNote={(targetUser) => {
            setPublicProfileTarget(null);
            setActiveDirectChat({
              recipientId: targetUser.phone ? targetUser.phone.replace(/[^0-9]/g, '') : (targetUser.id || ''),
              recipientName: targetUser.name || 'সম্মানিত সদস্য',
              recipientRole: targetUser.role,
              recipientPhone: targetUser.phone
            });
          }}
        />
      )}

      {/* Admin Control Panel Modal */}
      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
      />
    </div>
  );
}
